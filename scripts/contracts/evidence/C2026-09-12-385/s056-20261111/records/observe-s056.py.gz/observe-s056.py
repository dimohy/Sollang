from pathlib import Path
import sys,json,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
r=ROOT/'artifacts/scratch/resume-20261111';out=r/'s056-observer02'
d=json.loads((r/'product-cache-repair02/result.json').read_text())
old=d['processes'][0]['command'];sources=[x for x in old[3:old.index('-o')] if str(ROOT/'selfhost') in x or str(ROOT/'syntax') in x]
observer=r/'s056-observer.slg';source=r/'partition-controls01/selfhost-llvm-partition-reordered-mutable-effects.slg'
managed=r/'c879-managed-build02/compiler/Sollang.Compiler.exe'
initialize_output(ROOT,out,reusable_directories=[r/'c879-managed-build02',r/'event840-native05']);out.mkdir()
inputs=[Path(__file__),observer,source,managed,managed.with_suffix('.dll'),*map(Path,sources),*sorted((ROOT/'stdlib').rglob('*.slg'))]
pins={str(p):sha(p) for p in inputs};record=dict(schemaVersion=1,status='running',completed=0,total=1,inputHashes=pins,claimsGoalComplete=False,scope='S056 production scheduler observation only')
e=VerificationExecution(ROOT,out,record,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
try:
 with VerificationContractLease(inputs):
  cmd=[str(managed),'build',str(observer),*sources,'-o',str(out/'observer.exe'),'--target','windows-x64','--keep-temps','-O0','--jobs','24','--llvm',str(ROOT/'.tools/llvm-22.1.8')]
  b=e.run(cmd,out/'build',timeout=180)
  assert b.returncode==0,b.stderr
  x=e.run([str(out/'observer.exe'),str(source),str(ROOT/'stdlib')],out/'observe',timeout=90)
  assert x.returncode==0,x.stderr
  record.update(status='passed',completed=1)
except BaseException as caught:
 error=caught;raise
finally:e.finalize(error,cleanup=False)

from pathlib import Path
import sys,json,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
r=ROOT/'artifacts/scratch/resume-20261111';out=r/'s056-observer03'
d=json.loads((r/'product-cache-repair02/result.json').read_text())
old=d['processes'][0]['command'];sources=[x for x in old[3:old.index('-o')] if str(ROOT/'selfhost') in x or str(ROOT/'syntax') in x]
observer=r/'s056-observer.slg';source=r/'partition-controls01/selfhost-llvm-partition-reordered-mutable-effects.slg'
managed=r/'c879-managed-build02/compiler/Sollang.Compiler.exe'
initialize_output(ROOT,out,reusable_directories=[r/'c879-managed-build02',r/'event840-native05']);out.mkdir()
inputs=[Path(__file__),observer,source,managed,managed.with_suffix('.dll'),*map(Path,sources),*sorted((ROOT/'stdlib').rglob('*.slg'))]
pins={str(p):sha(p) for p in inputs};record=dict(schemaVersion=1,status='running',completed=0,total=1,inputHashes=pins,claimsGoalComplete=False,scope='S056 production scheduler observation only')
e=VerificationExecution(ROOT,out,record,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
try:
 with VerificationContractLease(inputs):
  cmd=[str(managed),'build',str(observer),*sources,'-o',str(out/'observer.exe'),'--target','windows-x64','--keep-temps','-O0','--jobs','24','--llvm',str(ROOT/'.tools/llvm-22.1.8')]
  b=e.run(cmd,out/'build',timeout=180)
  assert b.returncode==0,b.stderr
  x=e.run([str(out/'observer.exe'),str(source),str(ROOT/'stdlib')],out/'observe',timeout=90)
  assert x.returncode==0,x.stderr
  assert 'diagnostic=0' in x.stdout,x.stdout[:250]
  baseline=(r/'s056-observer02/observe.stdout').read_text(encoding='utf-8')
  nodes=[list(map(int,line[5:].split(','))) for line in baseline.splitlines() if line.startswith('node=')]
  order=[int(line.split(',')[1]) for line in x.stdout.splitlines() if line.startswith('order=')]
  terminals=sorted((n[8],n[0]) for n in nodes if n[8]>=0)
  assert len(terminals)==3
  positions=[order.index(index) for _,index in terminals]
  assert positions==sorted(positions)
  for _,index in terminals:assert order.count(index)==1
  first=min(positions)
  outer=[n[0] for n in nodes if n[1]==17 and n[3]==118375]
  assert all(order.index(index)<first for index in outer)
  record['assertions']=['no schedule diagnostics','three terminals exactly once in declaration order','outer bindings committed before dispatch']
  record.update(status='passed',completed=1)
except BaseException as caught:
 error=caught;raise
finally:e.finalize(error,cleanup=False)

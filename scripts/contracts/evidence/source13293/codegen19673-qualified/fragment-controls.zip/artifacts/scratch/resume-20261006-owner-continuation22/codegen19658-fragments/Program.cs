using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

if (args.Length != 3) throw new ArgumentException("compiler, actual artifact, new output required");
var compiler = Path.GetFullPath(args[0]);
var before = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(compiler)));
var bytes = File.ReadAllBytes(args[1]);
var original = Enumerable.Range(0, bytes.Length / 8)
    .Select(i => System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian(bytes.AsSpan(i * 8, 8))).ToArray();
if (original[8] != 0 || original[12] != 0 || original[14] != 1) throw new InvalidDataException("unexpected prefix");
var output = Path.GetFullPath(args[2]);
if (Directory.Exists(output)) throw new IOException("output exists");
Directory.CreateDirectory(output);
var assembly = Assembly.LoadFrom(compiler);
var cache = assembly.GetType("Sollang.Compiler.Cli.IncrementalCodegenCache", true)!;
var read = cache.GetMethod("Read", BindingFlags.Static | BindingFlags.NonPublic)!;
var checksum = cache.GetMethod("Checksum", BindingFlags.Static | BindingFlags.NonPublic)!;
var fragmentChecksum = cache.GetMethod("FragmentChecksum", BindingFlags.Static | BindingFlags.NonPublic,
    null, [typeof(IReadOnlyList<ulong>), typeof(int)], null)!;
var pack = cache.GetMethod("PackBytes", BindingFlags.Static | BindingFlags.NonPublic)!.CreateDelegate<PackBytes>();
var cases = new (string Id, byte[] Bytes, bool Accepted)[]
{
    ("invalid-ff", [0xff], false),
    ("stray-continuation", [0x80], false),
    ("overlong-two", [0xc0, 0x80], false),
    ("invalid-continuation", [0xc2, 0x41], false),
    ("overlong-three", [0xe0, 0x80, 0x80], false),
    ("surrogate", [0xed, 0xa0, 0x80], false),
    ("overlong-four", [0xf0, 0x80, 0x80, 0x80], false),
    ("beyond-unicode", [0xf4, 0x90, 0x80, 0x80], false),
    ("invalid-leading-f5", [0xf5, 0x80, 0x80, 0x80], false),
    ("truncated-two", [0xc2], false),
    ("truncated-three", [0xe0, 0xa0], false),
    ("truncated-four", [0xf0, 0x90, 0x80], false),
    ("split-word-invalid", [65, 65, 65, 65, 65, 65, 65, 0xf0, 0x90, 0x41, 0x80], false),
    ("valid-scalar-boundaries", Encoding.UTF8.GetBytes("\0\u007f\u0080\u07ff\u0800\ud7ff\ue000\uffff\U00010000\U0010ffff"), true),
    ("split-word-valid", Encoding.UTF8.GetBytes("AAAAAAA\U00010000"), true),
    ("empty-fragment", [], true)
};
var observations = new List<object>();
foreach (var item in cases)
{
    var packed = pack(item.Bytes);
    var words = original.Take(16).Concat(packed).Concat(original.Skip(17)).ToArray();
    words[13] = (ulong)item.Bytes.Length;
    words[14] = (ulong)packed.Count;
    words[15] = (ulong)fragmentChecksum.Invoke(null, [packed, item.Bytes.Length])!;
    words[6] = (ulong)words.Length;
    words[7] = (ulong)checksum.Invoke(null, [words, 8, words.Length - 8, 7809847782465536322UL])!;
    var path = Path.Combine(output, item.Id + ".cgu");
    using (var stream = File.Create(path))
    using (var writer = new BinaryWriter(stream)) foreach (var word in words) writer.Write(word);
    var accepted = false;
    try { read.Invoke(null, [path, 101UL, 202UL, 303UL]); accepted = true; }
    catch (TargetInvocationException error) when (error.InnerException is DecoderFallbackException && !item.Accepted) { }
    if (accepted != item.Accepted) throw new InvalidDataException("actual CSharp fragment decision differs: " + item.Id);
    observations.Add(new { id = item.Id, status = "passed", accepted, artifact = path,
        expectedSlgStatus = accepted ? 0 : 7, expectedDiagnostic = accepted ? "none" : nameof(DecoderFallbackException) });
}
var after = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(compiler)));
if (before != after) throw new InvalidDataException("compiler changed");
var result = new { schemaVersion = 1, status = "passed", completed = observations.Count,
    total = observations.Count, compilerSha256 = after, observations, claimsGoalComplete = false };
File.WriteAllText(Path.Combine(output, "observation.json"),
    JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine(JsonSerializer.Serialize(new { result.status, result.completed, result.total }));
delegate IReadOnlyList<ulong> PackBytes(ReadOnlySpan<byte> bytes);

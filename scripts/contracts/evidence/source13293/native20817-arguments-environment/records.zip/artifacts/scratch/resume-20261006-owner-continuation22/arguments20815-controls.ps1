$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$repoRoot = 'W:\MyWorks\Sollang'
$output = Join-Path $repoRoot 'artifacts/scratch/resume-20261006-owner-continuation22/arguments20815-controls'
[IO.Directory]::CreateDirectory($output) | Out-Null
$driver = Join-Path $repoRoot 'scripts/verify-selfhost-arguments-runtime.ps1'
. (Join-Path $repoRoot 'scripts/verification-process.ps1')
$tokens=$null; $errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($driver,[ref]$tokens,[ref]$errors)
if($errors.Count) { throw 'CONTROL_DRIVER_PARSE' }
$function=@($ast.FindAll({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Invoke-ArgumentsProcess'},$true))
if($function.Count -ne 1) { throw 'CONTROL_FUNCTION_COUNT' }
. ([ScriptBlock]::Create($function[0].Extent.Text))
$expected=[IO.File]::ReadAllText((Join-Path $repoRoot 'scripts/contracts/fixtures/arguments-runtime-s001.stderr.txt'))
$rows=[Collections.Generic.List[object]]::new()
$shell=(Get-Process -Id $PID).Path
foreach($case in @(
 @{id='exact-planned-diagnostics';actual=$expected;expected=$expected;exit=0;accept=$true},
 @{id='missing-diagnostic-rejected';actual='';expected=$expected;exit=0;accept=$false},
 @{id='extra-diagnostic-rejected';actual=($expected+"unexpected`n");expected=$expected;exit=0;accept=$false},
 @{id='unexpected-diagnostic-rejected';actual=$expected;expected='';exit=0;accept=$false},
 @{id='nonzero-compiler-exit-rejected';actual=$expected;expected=$expected;exit=1;accept=$false},
 @{id='normal-empty-diagnostics';actual='';expected='';exit=0;accept=$true}
)) {
 $encoded=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($case.actual))
 $command="[Console]::Error.Write([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('$encoded'))); exit $($case.exit)"
 $accepted=$true
 try { $null=Invoke-ArgumentsProcess $shell @('-NoProfile','-Command',$command) $case.id 5000 $case.expected (Join-Path $output $case.id) }
 catch { $accepted=$false }
 if($accepted -ne $case.accept) { throw "CONTROL_DIAGNOSTIC: $($case.id)" }
 $rows.Add(@{id=$case.id;passed=$true})
}
$originalManifest=Get-Content (Join-Path $repoRoot 'artifacts/scratch/resume-20261006-owner-continuation22/arguments20814-prepared.json') -Raw
foreach($kind in @('compiler','closure','source')) {
 $manifest=$originalManifest | ConvertFrom-Json
 $wanted=switch($kind) {
  compiler {$manifest.compilerSha256='A'*64; 'ARGUMENTS_PREPARED_COMPILER_MISMATCH'}
  closure {$manifest.producerInputHashes.PSObject.Properties.Remove('W:\MyWorks\Sollang\stdlib\std\algorithm.slg'); 'ARGUMENTS_PREPARED_INPUT_CLOSURE_INCOMPLETE'}
  source {$manifest.fixtures[0].sourceSha256='A'*64; 'ARGUMENTS_PREPARED_LLVM_DRIFT'}
 }
 $path=Join-Path $output "$kind.json"; $manifest | ConvertTo-Json -Depth 12 | Set-Content $path -Encoding utf8
 $rejected=$false
 try { & $driver -Compiler (Join-Path $repoRoot 'artifacts/scratch/resume-20261006-owner-continuation22/v20802/compiler-build01/compiler.exe') -OutputDirectory (Join-Path $output "$kind-run") -PreparedLlvmManifest $path }
 catch { $rejected=$_.Exception.Message -ceq $wanted }
 if(-not $rejected) { throw "CONTROL_PREPARED: $kind" }
 $rows.Add(@{id="prepared-$kind-rejected-before-compiler";passed=$true})
}
@{schemaVersion=1;status='passed';completed=$rows.Count;total=9;cases=@($rows.ToArray());scope='Actual tiny diagnostic children and production preflight rejection; no compiler acceptance rerun'} | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $output 'result.json') -Encoding utf8
Write-Output 'ARGUMENT_RUNTIME_CONTROLS9'

from pathlib import Path
import sys,json,hashlib,time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'owner21596-payload-origin-pairs';CPP=B/'managed21587/compiler/Sollang.Compiler.exe';receipt=B/'managed21587/result.json';producer=json.loads(receipt.read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert producer['status']=='passed' and producer['inputsStable'] and producer['processesStopped']
assert sha(CPP)==producer['generatedOutputHashes'][str(CPP)]
assert all(sha(Path(p))==h for p,h in producer['inputHashes'].items())
buildInputs=[CPP,*managed_runtime_inputs(CPP),receipt,*map(Path,producer['inputHashes']),*sorted((ROOT/'stdlib').rglob('*.slg'))]
P=ROOT/'scripts/probes/borrowed-owner-result-transfer'
nativeReceipt=B/'names21578-nominal-type-emitter/result.json'
nativeProducer=json.loads(nativeReceipt.read_text(encoding='utf-8'));emitter=nativeReceipt.parent/'observer.exe'
assert nativeProducer['status']=='passed' and nativeProducer['completed']==nativeProducer['total']==1 and nativeProducer['inputsStable'] and nativeProducer['processesStopped']
assert sha(emitter)==nativeProducer['generatedOutputHashes'][str(emitter)]
assert all(sha(Path(p))==h for p,h in nativeProducer['inputHashes'].items())
buildInputs += [nativeReceipt,emitter,*map(Path,nativeProducer['inputHashes']),B/'owner21595-payload-origin-confirmed-source-comparison.json']
subjects=[('original197',ROOT/'examples/regression/197-move-owned-struct-field.slg',ROOT/'examples/regression/expected/197-move-owned-struct-field.stdout.txt')]
subjects += [(n,P/(n+'.slg'),P/(n+'.stdout.txt')) for n in ['text-array-payload-return','text-field-payload-return','text-array-upstream-live','owned-fields-positive','byte-buffer-transfer-positive']]
negatives=[(n,P/(n+'.slg'),P/(n+'.stderr.contains.txt')) for n in ['text-array-upstream-escape','move-input-borrow-negative','byte-buffer-borrow-negative','borrowed-field-negative','upstream-loan-negative']]

caseSources={}
caseSourceManifests=[]
for label,src,oracle in subjects+negatives:
 p=oracle.with_name(label+'.sources.txt')
 if p.exists():
  caseSourceManifests.append(p)
  caseSources[label]=[ROOT/x for x in p.read_text(encoding='utf-8-sig').splitlines() if x]
 else:caseSources[label]=[src]
extraInputs=[*caseSourceManifests,*[p for paths in caseSources.values() for p in paths]]
inputs=list(dict.fromkeys([*extraInputs,*buildInputs,Path(__file__),CPP,*managed_runtime_inputs(CPP),receipt,*[p for label,src,oracle in subjects+negatives for p in [src,oracle]]]))
hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=22,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Matched CSharp/current SLG external Text payload carriers: original197 plus positive transfers and original upstream/local/move byte-owner rejection controls. No oracle change and no whole goal closure.',claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  for label,src,oracle in negatives:
   for role in ['csharp','slg']:
    d=OUT/(role+'-'+label);d.mkdir();start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));expected=oracle.read_text(encoding='utf-8-sig').strip()
    command=[str(CPP),'build',*map(str,caseSources[label]),'-o',str(d/'program.exe'),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0'] if role=='csharp' else [str(emitter),'emit','unused',str(ROOT/'stdlib'),*map(str,caseSources[label])]
    done=run.run(command,d/'reject',timeout=budget());combined=done.stdout+done.stderr;assert done.returncode!=0 and expected in combined,combined[-2200:];result['cases'].append(dict(id=role+'-'+label,passed=True,exit=done.returncode,expectedContains=expected,diagnostic=combined));result['completed']+=1;run.save()
  for label,src,oracle in subjects:
   for role in ['csharp','slg']:
    d=OUT/(role+'-'+label);d.mkdir();start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));exe=d/'program.exe'
    if role=='csharp':
     done=run.run([str(CPP),'build',*map(str,caseSources[label]),'-o',str(exe),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0'],d/'build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout[-2000:]+done.stderr
    else:
     done=run.run([str(emitter),'emit','unused',str(ROOT/'stdlib'),*map(str,caseSources[label])],d/'emit',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout[-2000:]+done.stderr;ll=d/'program.ll';ll.write_text(done.stdout,encoding='utf-8');done=run.run([str(ROOT/'.tools/llvm-22.1.8/bin/llvm-as.exe'),str(ll),'-o',str(d/'program.bc')],d/'assemble',timeout=budget());assert done.returncode==0,done.stderr;done=run.run([str(ROOT/'.tools/llvm-22.1.8/bin/clang.exe'),str(ll),'-O0','-Wno-override-module','-o',str(exe),'-lkernel32','-lshell32','-lws2_32','-lbcrypt'],d/'link',timeout=budget());assert done.returncode==0,done.stderr
    done=run.run([str(exe)],d/'run',timeout=budget());expected=oracle.read_text(encoding='utf-8-sig');assert done.returncode==0 and not done.stderr and done.stdout==expected,done.stdout+done.stderr;result['cases'].append(dict(id=role+'-'+label,passed=True,stdout=done.stdout,expected=expected));result['completed']+=1;run.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

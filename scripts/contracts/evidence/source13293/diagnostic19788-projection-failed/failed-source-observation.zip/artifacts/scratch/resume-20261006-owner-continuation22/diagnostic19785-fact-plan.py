from pathlib import Path
import importlib.util,json,subprocess,sys
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(r/'scripts'))
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
c=read(b/'diagnostic19777-contract.json');order=c['reusableCheckedProducer']['stdlibSourceOrder']
programs=['artifacts/scratch/resume-20261006-owner-continuation22/diagnostic19710-inputs/moved-main-interpolation.slg','scripts/probes/async-task-observability/affine-copy-negative.slg']
spec=importlib.util.spec_from_file_location('selection_generator',r/'scripts/generate-selection-result-emitter.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
text=g.render('',checked=True,package_paths=order,runtime_program_paths=programs,checked_files=False,runtime_program_groups={p:[p] for p in programs}).decode('utf-8')
text=text.replace('import sollang.compiler.llvm.text as compiler\n','namespace sollang.compiler.llvm.text\n\nimport sollang.compiler.llvm.target as traceTarget\n',1)
old=f'    sources! -> compiler.emitCheckedWithPaths(paths!, {len(order)}) => diagnosticCount\n    diagnosticCount != 0 -> if {{ "selection-emission-rejected" -> println }}'
assert text.count(old)==1
body='''    traceTarget.windowsX64() => target
    PrepareRequest { sources: sources!, standardLibrarySourceStart: 0, standardLibrarySourceCount: 144, pointerBitWidth: target.pointerBitWidth, targetArchitecture: target.architecture, cpuDispatchPolicy: target.dispatchPolicy, requiredCpuFeatures: target.requiredFeatures, allowedCpuFeatures: target.allowedFeatures, forbiddenCpuFeatures: target.forbiddenFeatures, supportsComputePool: false, expectedPathStyle: 0 } => request
    request -> prepare => context
    (context.ranges -> len) - 1 => sourceModule
    "SOURCE|$sourceModule|$programPath" -> println
    context.interpolationRanges[sourceModule] => fragments
    fragments.nodeStart => fragmentIndex!
    fragmentIndex! < fragments.nodeStart + fragments.nodeCount -> while {
        context.interpolations[fragmentIndex!] => node
        "INTERP|$(fragmentIndex!)|$(node.kind)|$(node.symbol)|$(node.sourceToken)|$(node.payloadStart)|$(context.unresolvedInterpolationBindingByNode[fragmentIndex!])" -> println
        fragmentIndex! + 1 => fragmentIndex!
    }
    0 => index!
    context.ir -> each node {
        node.sourceModule == sourceModule -> if {
            "IR|$(index!)|$(node.kind)|$(node.symbol)|$(node.parent)|$(node.astNode)|$(node.payloadToken)|$(node.operand0)|$(node.typeKind)|$(node.typeId)|$(node.typeFlags)" -> println
        }
        index! + 1 => index!
    }
    context.moves -> each event {
        event.sourceModule == sourceModule -> if {
            "MOVE|$(event.siteIr)|$(event.valueIr)|$(event.bindingIr)|$(event.symbol)|$(event.regionIr)|$(event.memberIr)" -> println
        }
    }
    context.ownershipDiagnostics -> each diagnostic {
        diagnostic.sourceModule == sourceModule -> if {
            "OWNERSHIP|$(diagnostic.code)|$(diagnostic.expectedSymbol)|$(diagnostic.actualSymbol)|$(diagnostic.span.start)" -> println
        }
    }
    context.consumedBindingReads -> each diagnostic {
        diagnostic.sourceModule == sourceModule -> if {
            "CONSUMED|$(diagnostic.astNode)|$(diagnostic.span.start)" -> println
        }
    }
    "TRACE_END" -> println'''
text=text.replace(old,body)
source=b/'diagnostic19785-fact-probe.slg';assert not source.exists();source.write_text(text,encoding='utf-8')
formatter=b/'v18915/compiler-build01/compiler.exe'
subprocess.run([str(formatter),'format',str(source)],check=True,capture_output=True)
subprocess.run([str(formatter),'format','--check',str(source)],check=True,capture_output=True)
plan=dict(schemaVersion=1,mode='diagnostic-only',source=source.relative_to(r).as_posix(),programs=programs,stdlibSources=order,additionalSources=c['reusableCheckedProducer']['additionalSources'],producerBuilds=1,caseBudgetSeconds=180,maxExecutions=2,retryCount=0,
 reason='The shared54 first case failed unchanged after the ownership visibility projection. Do not rebuild/replay54 again without observing actual symbol, binding, move and containing literal facts.',
 hypotheses=['Interpolation symbol or binding does not identify the moved owner','Ordinary MoveEvent does not include the transfer','Visibility predicate excludes the real literal site','Consumed visibility is lost before final context publication'],
 expectedObservations=['INTERP symbol/token/offset/unresolved flag','IR binding/source/parent/type identity','MOVE source and destination binding identity','OWNERSHIP and CONSUMED facts for the original ordinary-read control'],
 claimsFocusedFixComplete=False,claimsPhaseComplete=False,claimsGoalComplete=False)
p=b/'diagnostic19785-fact-plan.json';assert not p.exists();p.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(programs=2,builds=1,wholeCaseSeconds=180,mode='diagnostic-only')))

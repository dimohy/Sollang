from pathlib import Path
import json,re,difflib,hashlib,collections
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';P=B/'llvm24634-review';O=B/'llvm24660-naming-residual';O.mkdir(exist_ok=False)
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
notes=read(B/'llvm24633-direct-read-notes.json')['sources'];rows=[]
rules=[('local-or-global-ir-name',re.compile(r'\$\(([^()\r\n]+?) -> (valueNameId|globalValueNameId|stringGlobalName)\(state\)\)'),lambda m:'$('+m[1]+')'),('function-symbol',re.compile(r'\$\(([^()\r\n]+?) -> functionSymbolName\(([^()\r\n]+?), context\)\)'),lambda m:'m$('+m[1]+')_s$('+m[2]+')'),('declaration-symbol',re.compile(r'\$\(context -> emitterContext.declarationName\(([^()\r\n]+?), ([^()\r\n]+?)\)\)'),lambda m:'m$('+m[1]+')_s$('+m[2]+')'),('generic-instance',re.compile(r'\$\(([^()\r\n]+?) -> genericInstanceName\(context\)\)'),lambda m:'$('+m[1]+')')]
for row in read(P/'preimages.json'):
 s=row['path']
 if s in notes:continue
 old=P/(s.replace('/','__')+'.before');new=R/s;assert sha(old)==row['beforeSha256'] and sha(new)==row['sha256']
 matches=[];contexts=collections.Counter()
 def normalize(text,label):
  for name,pattern,replace in rules:
   def change(m):
    line=text.count('\n',0,m.start())+1;start=text.rfind('\n',0,m.start())+1;prefix=re.search(r'[A-Za-z0-9_%@.]*$',text[start:m.start()])[0]
    matches.append(dict(version=label,rule=name,line=line,prefix=prefix,original=m[0],replacement=replace(m)));contexts[(name,prefix)]+=1
    return replace(m)
   text=pattern.sub(change,text)
  return text
 before=normalize(old.read_text(encoding='utf-8'),'before');after=normalize(new.read_text(encoding='utf-8'),'current')
 diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='retained-reviewed-preimage',tofile='current-with-explicit-name-transforms-reversed',n=3));file=O/(s.replace('/','__')+'.residual.diff');file.write_text(diff,encoding='utf-8')
 matchesPath=O/(s.replace('/','__')+'.names.json');matchesPath.write_text(json.dumps(matches,indent=2)+'\n',encoding='utf-8')
 rows.append(dict(path=s,beforeSha256=row['beforeSha256'],currentSha256=row['sha256'],rawDeltaLines=row['deltaLines'],residualLines=len(diff.splitlines()),residualPath=str(file.relative_to(R)),mappingPath=str(matchesPath.relative_to(R)),contexts=[dict(rule=k[0],prefix=k[1],count=v) for k,v in sorted(contexts.items())],reviewState='pending-mapping-context-and-complete-residual-inspection',claimsSemanticEquivalence=False))
(O/'manifest.json').write_text(json.dumps(dict(scope='Read-only one-time review aid; explicit name transforms do not prove correct scope. Review mapping domains and full residual before credit. Exact before/current bytes unchanged and pinned.',rows=rows),indent=2)+'\n',encoding='utf-8')
print(json.dumps([dict(path=r['path'],raw=r['rawDeltaLines'],residual=r['residualLines']) for r in rows]))

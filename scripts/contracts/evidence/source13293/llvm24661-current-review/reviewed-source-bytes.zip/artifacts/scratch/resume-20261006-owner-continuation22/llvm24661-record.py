from pathlib import Path
import json,hashlib,zipfile,datetime,subprocess,copy
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/llvm24661-current-review';E.mkdir(exist_ok=True);assert not (E/'source-review.json').exists()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest().upper()
a=read(B/'llvm24632-next-review.json');notes=read(B/'llvm24633-direct-read-notes.json');detail=read(R/'scripts/contracts/structural-parity-detail.json');phase=next(p for p in detail['phaseProgress'] if p['phase']=='llvm-generation');scopes=phase['decisionInventory']['sourceScopes'];sources={}
for r in a['exactReviewSources']:
 assert sha((R/r['path']).read_bytes())==r['sha256'];sources[r['path']]=dict(currentSha256=r['sha256'],reviewMethod='exact-byte-reuse',previousReview=r['review'],physicalReviewState='current-complete')
for p,r in notes['sources'].items():
 assert p not in sources and sha((R/p).read_bytes())==r['currentSha256'],p;sources[p]=dict(r,physicalReviewState='current-complete')
assert len(sources)==156
scopeFiles=set()
for category,paths in scopes.items():
 for p in paths:
  path=R/p
  if path.is_file():scopeFiles.add(p)
  elif path.is_dir():scopeFiles.update(str(f.relative_to(R)).replace('\\','/') for f in path.rglob('*.cs' if category=='managed' else '*.slg'))
assert scopeFiles==set(sources),(sorted(scopeFiles-set(sources)),sorted(set(sources)-scopeFiles))
entries={}
def add(p,key=None):
 key=key or str(p.relative_to(R)).replace('\\','/');data=p.read_bytes();assert key not in entries or entries[key]==data;entries[key]=data
for p in sources:add(R/p)
for row in read(B/'llvm24634-review/preimages.json'):
 p=B/'llvm24634-review'/(row['path'].replace('/','__')+'.before');assert sha(p.read_bytes())==row['beforeSha256'];add(p);add(R/row['delta'])
for f in (B/'llvm24660-naming-residual').iterdir():add(f)
for f in [B/'llvm24632-next-review.json',B/'llvm24633-direct-read-notes.json',B/'llvm24660-naming-residual.py',Path(__file__)]:add(f)
zpath=E/'reviewed-source-bytes.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,data in sorted(entries.items()):z.writestr(p,data)
with zipfile.ZipFile(zpath) as z:
 assert set(z.namelist())==set(entries)
 for p,data in entries.items():assert sha(z.read(p))==sha(data)
def write(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
archive=dict(path='reviewed-source-bytes.zip',sha256=sha(zpath.read_bytes()),entries=len(entries),readbackVerified=True)
write(E/'archive-manifest.json',dict(archive=archive,entries={p:dict(sha256=sha(data),bytes=len(data)) for p,data in entries.items()}))
review=dict(schemaVersion=1,status='current-physical-file-review-complete-phase-runtime-pending',phase='llvm-generation',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),completed=156,total=156,sourceScopes=scopes,sources=sources,methods=dict(exactByteReuse=86,wholeFileRead=41,completeAuthoredDeltas=29,namingTransformDomainInspectionAndFullResidualRead=11,normalizationAloneIsNotBehavioralEquivalence=True,exactPreimageBytesPinnedAndArchived=True),reviewedBytesArchive=archive,focusedBugRepairQualification='scripts/contracts/evidence/source13293/dyn24658-current/qualification.json',sourceObservations=[dict(source='tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.slg',supportComplete=False,observation='executeNativeBuildCore rejects wasm linking and a target different from host; resolve lacks workspace route. Compare actual CSharp implementation and focused behavior before scope classification or SLG edit. These rejections are not support credit.'),dict(source='selfhost/llvm/codegen_store.slg',observation='Native failed staged cache output retained and explicitly reported by CLI, unlike CSharp temporary-finally cleanup. Interpret under existing failed-stage evidence contract; no automatic deletion or speculative cleanup change.')],testsExecutedThisReview=False,claimsPhaseComplete=False,claimsGoalComplete=False,remaining='Physical source association is reconciled for all156 files. Compare observed CLI capability boundaries against CSharp; full current phase witness matrix and strict phase closure remain pending. No original1999 unchanged replay or profiling reset.')
write(E/'source-review.json',review)
def update(j):
 p=next(p for p in j['phaseProgress'] if p['phase']=='llvm-generation');i=p['decisionInventory'];i['previousCompleteFileReviewBefore24661']=i.get('currentCompleteFileReview');i['currentCompleteFileReview']=str((E/'source-review.json').relative_to(R)).replace('\\','/');i['currentAuthoredDeltaReview']=i['currentCompleteFileReview'];p['remaining']='Current physical LLVM review156/156 complete; observed CLI linking/resolve support branches require CSharp comparison. Current exhaustive paired phase witnesses, strict source closure, original acceptance, runtime and Stage gates remain pending.'
name='scripts/contracts/structural-parity-detail.json';base=json.loads(subprocess.check_output(['git','show','HEAD:'+name]).decode('utf-8'));update(detail);update(base);write(R/name,detail);data=(json.dumps(base,ensure_ascii=False,indent=2)+'\n').encode();oid=subprocess.check_output(['git','hash-object','-w','--stdin'],input=data).decode().strip();subprocess.run(['git','update-index','--cacheinfo','100644',oid,name],check=True)
print(json.dumps(dict(currentPhysicalReviewed=156,total=156,archiveEntries=len(entries),archiveBytes=zpath.stat().st_size,phaseCompletionCredit=False)))

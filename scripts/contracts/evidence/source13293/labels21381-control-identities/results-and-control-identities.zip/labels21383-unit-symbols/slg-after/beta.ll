define i32 @sollang_m146_s0(i32 %arg) {
entry:
  %if631360192521_result = alloca i32, align 4
  %v631360192516_ptr = insertvalue %sollang.text poison, ptr @sollang_str_631360192516, 0
  %v631360192516 = insertvalue %sollang.text %v631360192516_ptr, i64 4, 1
  call void @sollang_runtime_print(ptr @sollang_str_631360192516, i64 4, i1 true)
  %v631360192518 = icmp sgt i32 %arg, 0
  br i1 %v631360192518, label %if631360192521_then, label %if631360192521_else
if631360192521_then:
  %v631360192523 = add i32 %arg, 3
  store i32 %v631360192523, ptr %if631360192521_result, align 4
  br label %if631360192521_merge
if631360192521_else:
  store i32 0, ptr %if631360192521_result, align 4
  br label %if631360192521_merge
if631360192521_merge:
  %v631360192521 = load i32, ptr %if631360192521_result, align 4
  ret i32 %v631360192521
}
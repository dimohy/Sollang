@.slg.str.module.x63616368652E62657461.0 = private unnamed_addr constant [5 x i8] c"beta=", align 1
@.slg.str.module.x63616368652E62657461.1 = private unnamed_addr constant [1 x i8] c"\0A", align 1
define internal i32 @sollang_fn_cache_beta_apply(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, i32 %it) #0 {
entry:
  %write0 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.module.x63616368652E62657461.0, i64 5, ptr %written)
  %is_ok1 = icmp ne i32 %write0, 0
  %previous_ok2 = load i1, ptr %ok_state, align 1
  %ok3 = and i1 %previous_ok2, %is_ok1
  store i1 %ok3, ptr %ok_state, align 1
  %add4 = add i32 %it, 1
  %print_integer5 = sext i32 %add4 to i64
  %write6 = call i32 @sollang_write_i64(ptr %stdout, i64 %print_integer5, ptr %written)
  %is_ok7 = icmp ne i32 %write6, 0
  %previous_ok8 = load i1, ptr %ok_state, align 1
  %ok9 = and i1 %previous_ok8, %is_ok7
  store i1 %ok9, ptr %ok_state, align 1
  %write10 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.module.x63616368652E62657461.1, i64 1, ptr %written)
  %is_ok11 = icmp ne i32 %write10, 0
  %previous_ok12 = load i1, ptr %ok_state, align 1
  %ok13 = and i1 %previous_ok12, %is_ok11
  store i1 %ok13, ptr %ok_state, align 1
  %cmp14 = icmp sgt i32 %it, 0
  br i1 %cmp14, label %bb_if_then0, label %bb_if_else1
bb_if_then0:
  %add15 = add i32 %it, 3
  br label %bb_if_end2
bb_if_else1:
  br label %bb_if_end2
bb_if_end2:
  %if16 = phi i32 [ %add15, %bb_if_then0 ], [ 0, %bb_if_else1 ]
  ret i32 %if16
}


define %sollang.int_slice @sollang_m146_s0() {
entry:
  %v631360192514_data = getelementptr [2 x i8], ptr @sollang_static_array_m146_s0_v631360192514, i64 0, i64 0
  %v631360192514_0 = insertvalue %sollang.int_slice poison, ptr %v631360192514_data, 0
  %v631360192514 = insertvalue %sollang.int_slice %v631360192514_0, i64 2, 1
  ret %sollang.int_slice %v631360192514
}
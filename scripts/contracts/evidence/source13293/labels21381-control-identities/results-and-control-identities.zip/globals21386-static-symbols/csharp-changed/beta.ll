@.slg.data.module.x63616368652E62657461.0 = private unnamed_addr constant [2 x i8] [i8 3, i8 5], align 1
define internal %sollang.int_slice @sollang_fn_cache_beta_values(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) #0 {
entry:
  %slice_value0 = insertvalue %sollang.int_slice poison, ptr @.slg.data.module.x63616368652E62657461.0, 0
  %slice_value1 = insertvalue %sollang.int_slice %slice_value0, i64 2, 1
  ret %sollang.int_slice %slice_value1
}


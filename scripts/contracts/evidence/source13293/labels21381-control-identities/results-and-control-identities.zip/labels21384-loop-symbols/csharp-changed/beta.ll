@.slg.str.module.x63616368652E62657461.0 = private unnamed_addr constant [4 x i8] c"beta", align 1
@.slg.str.module.x63616368652E62657461.1 = private unnamed_addr constant [1 x i8] c"\0A", align 1
define internal i32 @sollang_fn_cache_beta_apply(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, i32 %it) #0 {
entry:
  %mutable_scalar_slot8 = alloca i32, align 4
  %mutable_scalar_slot9 = alloca i32, align 4
  %write0 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.module.x63616368652E62657461.0, i64 4, ptr %written)
  %is_ok1 = icmp ne i32 %write0, 0
  %previous_ok2 = load i1, ptr %ok_state, align 1
  %ok3 = and i1 %previous_ok2, %is_ok1
  store i1 %ok3, ptr %ok_state, align 1
  %write4 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.module.x63616368652E62657461.1, i64 1, ptr %written)
  %is_ok5 = icmp ne i32 %write4, 0
  %previous_ok6 = load i1, ptr %ok_state, align 1
  %ok7 = and i1 %previous_ok6, %is_ok5
  store i1 %ok7, ptr %ok_state, align 1
  store i32 %it, ptr %mutable_scalar_slot8, align 4
  store i32 0, ptr %mutable_scalar_slot9, align 4
  br label %bb_while_condition0
bb_while_condition0:
  %mutable_scalar10 = load i32, ptr %mutable_scalar_slot9, align 4
  %cmp11 = icmp slt i32 %mutable_scalar10, 1
  br i1 %cmp11, label %bb_while_body1, label %bb_while_end2
bb_while_body1:
  %mutable_scalar12 = load i32, ptr %mutable_scalar_slot8, align 4
  %add13 = add i32 %mutable_scalar12, 3
  store i32 %add13, ptr %mutable_scalar_slot8, align 4
  %mutable_scalar14 = load i32, ptr %mutable_scalar_slot9, align 4
  %add15 = add i32 %mutable_scalar14, 1
  store i32 %add15, ptr %mutable_scalar_slot9, align 4
  br label %bb_while_condition0
bb_while_end2:
  %mutable_scalar16 = load i32, ptr %mutable_scalar_slot8, align 4
  %cmp17 = icmp sgt i32 %mutable_scalar16, 0
  br i1 %cmp17, label %bb_if_then3, label %bb_if_else4
bb_if_then3:
  %mutable_scalar18 = load i32, ptr %mutable_scalar_slot8, align 4
  br label %bb_if_end5
bb_if_else4:
  br label %bb_if_end5
bb_if_end5:
  %if19 = phi i32 [ %mutable_scalar18, %bb_if_then3 ], [ 0, %bb_if_else4 ]
  ret i32 %if19
}


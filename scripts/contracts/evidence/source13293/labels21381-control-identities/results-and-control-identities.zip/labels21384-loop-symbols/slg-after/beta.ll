define i32 @sollang_m146_s0(i32 %arg) {
entry:
  %if631360192539_result = alloca i32, align 4
  %slot631360192515 = alloca i32, align 4
  %slot631360192516 = alloca i32, align 4
  %v631360192520_ptr = insertvalue %sollang.text poison, ptr @sollang_str_631360192520, 0
  %v631360192520 = insertvalue %sollang.text %v631360192520_ptr, i64 4, 1
  store i32 %arg, ptr %slot631360192515, align 4
  store i32 0, ptr %slot631360192516, align 4
  call void @sollang_runtime_print(ptr @sollang_str_631360192520, i64 4, i1 true)
  br label %while631360192527_header
while631360192527_header:
  %while631360192527_v631360192525 = load i32, ptr %slot631360192516, align 4
  %while631360192527_v631360192524 = icmp slt i32 %while631360192527_v631360192525, 1
  br i1 %while631360192527_v631360192524, label %while631360192527_body, label %while631360192527_exit
while631360192527_body:
  %v631360192530 = load i32, ptr %slot631360192515, align 4
  %v631360192529 = add i32 %v631360192530, 3
  store i32 %v631360192529, ptr %slot631360192515, align 4
  %v631360192533 = load i32, ptr %slot631360192516, align 4
  %v631360192532 = add i32 %v631360192533, 1
  store i32 %v631360192532, ptr %slot631360192516, align 4
  br label %while631360192527_header
while631360192527_exit:
  %v631360192537 = load i32, ptr %slot631360192515, align 4
  %v631360192536 = icmp sgt i32 %v631360192537, 0
  br i1 %v631360192536, label %if631360192539_then, label %if631360192539_else
if631360192539_then:
  %v631360192541 = load i32, ptr %slot631360192515, align 4
  store i32 %v631360192541, ptr %if631360192539_result, align 4
  br label %if631360192539_merge
if631360192539_else:
  store i32 0, ptr %if631360192539_result, align 4
  br label %if631360192539_merge
if631360192539_merge:
  %v631360192539 = load i32, ptr %if631360192539_result, align 4
  ret i32 %v631360192539
}
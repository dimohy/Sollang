from pathlib import Path
import copy,hashlib,importlib.util,json,sys
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(r/'scripts'))
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
old=read(b/'diagnostic19740-contract.json');refs=read(r/'scripts/contracts/evidence/source13293/diagnostic19772-csharp-controls/reference10.json')
plans=read(b/'diagnostic19760-controls-plan.json')['cases'][:2]+read(b/'diagnostic19768-controls-plan.json')['cases']
source=(b/'diagnostic19777-emitter.slg').relative_to(r).as_posix();additional=old['reusableCheckedProducer']['additionalSources'];order=old['reusableCheckedProducer']['stdlibSourceOrder']
primary=copy.deepcopy(next(c for c in old['cases'] if c['id']=='control-moved-main-interpolation'));cases=[primary];binding=[]
for plan,ref in zip(plans,refs['negative']):
 assert plan['id']==ref['id'] and ref['passed'] and ref['originalConstraintSatisfied']
 for item in plan['sourceInputs']:assert hashlib.sha256((r/item['path']).read_bytes()).hexdigest().upper()==item['sha256']
 if plan['id']=='moved-main-interpolation':
  assert primary['stdout']==ref['buildStderr'].strip()+'\nselection-emission-rejected'
  binding.append(dict(caseId=primary['id'],original=plan,reference=ref));continue
 paths=[x['path'] for x in plan['sourceInputs']];assert len(paths)==1
 case=dict(id='c755-'+plan['id'],source=source,additionalSources=additional,programSource=paths[0],observedSourceOrder=order+paths,runArguments=[paths[0]],exit=0,stderr='',stdout=ref['buildStderr'].strip()+'\nselection-emission-rejected',emittedLlvm=False,runStderr='')
 cases.append(case);binding.append(dict(caseId=case['id'],original=plan,reference=ref))
positive=read(b/'diagnostic19768-positive-contract.json');proof=read(b/'diagnostic19770-managed-positive/result.json');assert proof['status']=='passed'
for original,ref in zip(positive['cases'],proof['cases']):
 assert original['id']==ref['id'] and ref['passed'] and ref['runStdout']==original['stdout']
 path=original['source'];case=dict(id='c755-'+original['id'],source=source,additionalSources=additional,programSource=path,observedSourceOrder=order+[path],runArguments=[path],exit=0,stderr='',stdout=original['stdout'],emittedLlvm=True,runStderr='')
 cases.append(case);binding.append(dict(caseId=case['id'],original=original,reference=ref))
assert len(cases)==10
for c in old['cases']:
 if c['id']!=primary['id']:cases.append(copy.deepcopy(c))
assert len(cases)==54 and len({c['programSource'] for c in cases})==54
for c in cases:c['source']=source;c['additionalSources']=additional
contract=copy.deepcopy(old)
contract.update(scope='Current C754/C755 actual SLG source checks54: C755 reference10 first, then remaining C75444. One shared producer, per-case180. Negative cases compare full current CSharp diagnostics through SDK rejection framing; positive4 link/run emitted LLVM. No general Native product, phase or goal completion.',semanticPreflightProof='artifacts/scratch/resume-20261006-owner-continuation22/diagnostic19776-semantic/result.json',stdlibSourcePreflightProof='artifacts/scratch/resume-20261006-owner-continuation22/diagnostic19778-stdlib/result.json',formatCheckSources=[source],cases=cases)
contract['reusableCheckedProducer'].update(id='c754-c755-ownership-visibility',source=source)
spec=importlib.util.spec_from_file_location('selection_generator',r/'scripts/generate-selection-result-emitter.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
order,groups=g.validated_runtime_program_groups(contract,r)
p=r/source;assert not p.exists();p.write_bytes(g.render('',checked=True,package_paths=order,runtime_program_paths=list(groups),checked_files=True,runtime_program_groups=groups))
for name,value in [('diagnostic19777-contract.json',contract),('diagnostic19777-reference-binding.json',dict(c755=binding,c754PriorBinding='artifacts/scratch/resume-20261006-owner-continuation22/diagnostic19737-reference-binding.json',reusedPrimaryCase=primary['id'],claimsPhaseComplete=False,claimsGoalComplete=False))]:
 p=b/name;assert not p.exists();p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(cases=54,c755First=10,remainingC754=44,groups=len(groups))))

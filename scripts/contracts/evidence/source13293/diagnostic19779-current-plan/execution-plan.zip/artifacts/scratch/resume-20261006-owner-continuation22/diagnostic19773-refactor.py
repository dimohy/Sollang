from pathlib import Path
r=Path.cwd();p=r/'selfhost/semantic/ownership_check.slg';t=p.read_text(encoding='utf-8-sig')
start=t.index('                                    affineReuse.kind == 5 and affineReuse.sourceModule == partialMove.sourceModule and affineReuse.symbol == partialMove.symbol')
end=t.index('                                    affineReuseIndex! + 1 => affineReuseIndex!',start)
old=t[start:end];emitStart=old.index('                                                        diagnostics! -> appendBodyDiagnostic(affineReuseIndex!, OwnershipDiagnostic {')
emitEnd=old.index('                                                        })',emitStart)+len('                                                        })')
emit=old[emitStart:emitEnd].splitlines();emit=['                                            '+line[56:] for line in emit]
replacement='''                                    affineReuse.kind == 5 and affineReuse.sourceModule == partialMove.sourceModule
                                        and affineReuse.symbol == partialMove.symbol
                                        and (partialMoveIndex! -> wholeMoveInvalidatesRead(affineReuseIndex!))
                                        -> if {
'''+ '\n'.join(emit)+'\n                                        }\n'
t=t[:start]+replacement+t[end:]
unused='                                prepared.package.nodes[affineMoveRange.astStart + affineMoveSite.astNode].start => affineMoveStart\n';assert t.count(unused)==1;t=t.replace(unused,'')
assert t.count('wholeMoveInvalidatesRead(')==2
p.write_text(t,encoding='utf-8');print('Shared whole-move visibility predicate now consumes both ordinary and interpolation read sites.')

using System.Globalization;
using System.Numerics;
using System.Text;
using Sollang.Compiler.Diagnostics;
using Sollang.Compiler.Semantics;
using Sollang.Compiler.Syntax;

namespace Sollang.Compiler.CodeGen;

internal sealed partial class LlvmEmitter
{
    private RuntimeValue EmitFunctionCall(CallExpression expression)
    {
        if (TryEmitArenaConstructor(expression, out var arena))
        {
            return arena;
        }

        if (TryEmitEnumConstructor(expression, out var enumValue))
        {
            return enumValue;
        }

        if (TryEmitNumericConversion(expression, out var numericValue))
        {
            return numericValue;
        }

        var path = string.Join('.', expression.Path);
        string? methodReceiverName = null;
        if (_program.ResolvedGenericCalls.TryGetValue(expression, out var function))
        {
            // A resolved instance call still needs its implicit receiver during
            // lowering. The semantic call table identifies the declaration;
            // recover the receiver from the typed local path instead of
            // treating every recorded call as a free function invocation.
            if (TryResolveInstanceMethodCall(
                    expression.Path,
                    out var method,
                    out var resolvedReceiver)
                && CanonicalFunctionName(method) == CanonicalFunctionName(function))
            {
                // Keep the concrete specialization selected by semantic
                // resolution. Lexical lookup is needed only to recover the
                // implicit receiver; replacing the specialization with its
                // generic declaration can inline an early return into a
                // caller with a different Result success type.
                methodReceiverName = resolvedReceiver;
            }
        }
        else if (!TryResolveFunction(expression.Path, out function))
        {
            if (!TryResolveInstanceMethodCall(expression.Path, out function, out methodReceiverName))
            {
                throw new SollangException($"unknown runtime function or method '{path}'");
            }
        }

        if (TryGetRuntimeWrapperKind(function, out var wrapperKind))
        {
            if (wrapperKind == BoundFunctionKind.RuntimePrintLine
                && expression.Arguments.Count == 0)
            {
                _mainOk = EmitWriteText("\n", _mainOk);
                return RuntimeUnit.Instance;
            }

            return EmitRuntimeWrapperCall(expression, function, wrapperKind, path);
        }

        if (function.Kind is BoundFunctionKind.RuntimePrint
            or BoundFunctionKind.RuntimePrintLine
            or BoundFunctionKind.RuntimePrintError
            or BoundFunctionKind.RuntimePrintErrorLine)
        {
            if (function.Kind == BoundFunctionKind.RuntimePrintLine
                && expression.Arguments.Count == 0)
            {
                _mainOk = EmitWriteText("\n", _mainOk);
                return RuntimeUnit.Instance;
            }

            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one argument");
            }

            var standardError = function.Kind is BoundFunctionKind.RuntimePrintError
                or BoundFunctionKind.RuntimePrintErrorLine;
            _mainOk = EmitPrintArgument(expression.Arguments[0], _mainOk, standardError);
            if (function.Kind is BoundFunctionKind.RuntimePrintLine
                or BoundFunctionKind.RuntimePrintErrorLine)
            {
                _mainOk = standardError
                    ? EmitStandardErrorNewLine(_mainOk)
                    : EmitWriteText("\n", _mainOk);
            }

            return RuntimeUnit.Instance;
        }

        if (function.Kind == BoundFunctionKind.RuntimeReadInt)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Text prompt");
            }

            var prompt = EmitExpression(expression.Arguments[0]);
            EnsureRuntimeType(prompt, BoundType.Text, path);
            return EmitReadIntPrompt(prompt);
        }

        if (function.Kind == BoundFunctionKind.RuntimeFlushStandardOutput)
        {
            if (expression.Arguments.Count != 0)
            {
                throw new SollangException($"{path} does not accept arguments");
            }
            return EmitRuntimeFlushStandardOutputIntrinsic();
        }

        if (function.Kind is BoundFunctionKind.RuntimeNowMillis
            or BoundFunctionKind.RuntimeUtcNowMillis
            or BoundFunctionKind.RuntimeMonotonicSuspendPolicy)
        {
            if (expression.Arguments.Count != 0)
            {
                throw new SollangException($"{path} does not accept arguments");
            }

            return function.Kind switch
            {
                BoundFunctionKind.RuntimeUtcNowMillis => EmitRuntimeUtcNowMillisIntrinsic(path),
                BoundFunctionKind.RuntimeMonotonicSuspendPolicy => EmitRuntimeMonotonicSuspendPolicyIntrinsic(path),
                _ => EmitRuntimeNowMillisIntrinsic(path)
            };
        }

        if (function.Kind == BoundFunctionKind.RuntimeRangeStream)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Range argument");
            }
            return EmitRuntimeRangeStream(function, EmitExpression(expression.Arguments[0]), path);
        }

        if (function.Kind == BoundFunctionKind.RuntimeMouseEvents)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Source argument");
            }
            return EmitRuntimeMouseEvents(
                function,
                EmitExpression(expression.Arguments[0]),
                path);
        }

        if (function.Kind == BoundFunctionKind.RuntimeExitProcess)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Int exit code");
            }

            return EmitRuntimeExitProcessIntrinsic(EmitExpression(expression.Arguments[0]), path);
        }

        if (function.Kind == BoundFunctionKind.RuntimePathStyle)
        {
            if (expression.Arguments.Count != 0)
            {
                throw new SollangException($"{path} does not accept arguments");
            }
            return EmitRuntimePathStyle(function);
        }

        if (function.Kind == BoundFunctionKind.RuntimeParallelWorkers)
        {
            if (expression.Arguments.Count != 0)
            {
                throw new SollangException($"{path} does not accept arguments");
            }
            return EmitRuntimeParallelWorkersIntrinsic(path);
        }

        if (function.Kind == BoundFunctionKind.RuntimeLimitParallelWorkers)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Int argument");
            }
            return EmitRuntimeLimitParallelWorkersIntrinsic(EmitExpression(expression.Arguments[0]), path);
        }

        if (function.Kind == BoundFunctionKind.RuntimeParallelPeakWorkers)
        {
            if (expression.Arguments.Count != 0)
            {
                throw new SollangException($"{path} does not accept arguments");
            }
            return EmitRuntimeParallelPeakWorkersIntrinsic(path);
        }

        if (function.Kind == BoundFunctionKind.RuntimeSleep)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Duration argument");
            }

            return EmitRuntimeSleepIntrinsic(function, EmitExpression(expression.Arguments[0]), path);
        }

        if (function.Kind == BoundFunctionKind.RuntimeArguments)
        {
            if (expression.Arguments.Count != 0)
            {
                throw new SollangException($"{path} does not accept arguments");
            }
            return EmitRuntimeArgumentsIntrinsic();
        }

        if (function.Kind == BoundFunctionKind.RuntimeEnvironment)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Text name");
            }
            return EmitRuntimeEnvironmentIntrinsic(function, EmitExpression(expression.Arguments[0]));
        }

        if (function.Kind is BoundFunctionKind.RuntimeBorrowSourceText
            or BoundFunctionKind.RuntimeMapSourceText)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Text value");
            }
            var sourceArgument = EmitExpression(expression.Arguments[0]);
            return function.Kind == BoundFunctionKind.RuntimeBorrowSourceText
                ? EmitBorrowSourceText(sourceArgument)
                : EmitMapSourceText(sourceArgument);
        }

        if (function.Kind == BoundFunctionKind.RuntimeBorrowSourceBytes)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one ref [UInt8; ~] value");
            }
            return EmitBorrowSourceBytes(
                EmitReferencePlace(expression.Arguments[0], function.InputType!.Value));
        }

        if (function.Kind == BoundFunctionKind.RuntimeReadStandardInputSourceText)
        {
            if (expression.Arguments.Count != 0)
            {
                throw new SollangException($"{path} does not accept arguments");
            }
            return EmitReadStandardInputSourceText();
        }

        if (function.Kind == BoundFunctionKind.RuntimeReadStandardInputChunk)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one UIntSize capacity");
            }
            return EmitReadStandardInputChunk(EmitExpression(expression.Arguments[0]));
        }

        if (function.Kind == BoundFunctionKind.RuntimeMapSourcePath)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Path value");
            }
            return EmitMapSourcePath(EmitExpression(expression.Arguments[0]));
        }

        if (function.Kind == BoundFunctionKind.RuntimePathText)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Path value");
            }
            var pathArgument = _program.Types.IsReference(function.InputType!.Value)
                ? EmitReferencePlace(expression.Arguments[0], function.InputType.Value)
                : EmitExpression(expression.Arguments[0]);
            return EmitRuntimePathText(pathArgument);
        }

        if (function.Kind is BoundFunctionKind.RuntimeOpenFile
            or BoundFunctionKind.RuntimeOpenWriteFile)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Text path");
            }
            return EmitRuntimeOpenFile(function, EmitExpression(expression.Arguments[0]));
        }

        if (function.Kind is BoundFunctionKind.RuntimeCreateExclusiveFile
            or BoundFunctionKind.RuntimeRemoveFile)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Text path");
            }
            return EmitRuntimeFilePathStatus(function, EmitExpression(expression.Arguments[0]));
        }

        if (function.Kind == BoundFunctionKind.RuntimeReadDirectory)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Path argument");
            }
            return EmitRuntimeReadDirectory(function, EmitExpression(expression.Arguments[0]));
        }

        if (function.Kind == BoundFunctionKind.RuntimeCreateDirectory)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Path argument");
            }
            return EmitRuntimeCreateDirectory(function, EmitExpression(expression.Arguments[0]));
        }

        if (function.Kind is BoundFunctionKind.RuntimePathQuery or BoundFunctionKind.RuntimePathAbsolute)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Path argument");
            }
            return function.Kind == BoundFunctionKind.RuntimePathAbsolute
                ? EmitRuntimePathAbsolute(function, EmitExpression(expression.Arguments[0]))
                : EmitRuntimePathQuery(function, EmitExpression(expression.Arguments[0]));
        }

        if (function.Kind is BoundFunctionKind.RuntimeSyncFile
            or BoundFunctionKind.RuntimeAtomicReplaceFile)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one argument");
            }
            var fileArgument = EmitExpression(expression.Arguments[0]) as RuntimeStruct
                ?? throw new SollangException($"{path} expects a file runtime struct");
            return function.Kind switch
            {
                BoundFunctionKind.RuntimeSyncFile => EmitRuntimeSyncFile(fileArgument),
                _ => EmitRuntimeAtomicReplaceFile(function, fileArgument)
            };
        }

        if (function.Kind is BoundFunctionKind.RuntimeOpenFileAsync
            or BoundFunctionKind.RuntimeOpenWriteFileAsync)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one Text path");
            }
            return EmitRuntimeOpenFileAsync(function, EmitExpression(expression.Arguments[0]));
        }

        if (function.Kind == BoundFunctionKind.RuntimeWriteScalar)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one scalar value");
            }
            return EmitRuntimeWriteScalar(function, EmitExpression(expression.Arguments[0]));
        }

        if (function.Kind is BoundFunctionKind.RuntimeSeedRandom
            or BoundFunctionKind.RuntimeOpenIntWriter
            or BoundFunctionKind.RuntimeWriteInt
            or BoundFunctionKind.RuntimeOpenIntReader)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one argument");
            }

            var runtimeArgument = EmitExpression(expression.Arguments[0]);
            EmitRuntimeUnitIntrinsic(function, runtimeArgument, path);
            return RuntimeUnit.Instance;
        }

        if (function.Kind is BoundFunctionKind.RuntimeRandomBelow
            or BoundFunctionKind.RuntimeClosestInt)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one argument");
            }

            var runtimeArgument = EmitExpression(expression.Arguments[0]);
            return EmitRuntimeIntIntrinsic(function, runtimeArgument, path);
        }

        if (function.Kind == BoundFunctionKind.RuntimeSecureRandomBytes)
        {
            if (expression.Arguments.Count != 1)
            {
                throw new SollangException($"{path} expects exactly one UIntSize argument");
            }
            return EmitRuntimeSecureRandomBytes(
                function,
                EmitFunctionArgumentExpression(expression.Arguments[0], BoundType.UIntSize),
                path);
        }

        if (function.Kind is BoundFunctionKind.RuntimeCloseIntWriter
            or BoundFunctionKind.RuntimeCloseIntReader)
        {
            if (expression.Arguments.Count != 0)
            {
                throw new SollangException($"{path} does not accept arguments");
            }

            EmitRuntimeUnitIntrinsic(function, argument: null, path);
            return RuntimeUnit.Instance;
        }

        if (function.Kind is not (BoundFunctionKind.User or BoundFunctionKind.Native
            or BoundFunctionKind.RuntimeSocketListen
            or BoundFunctionKind.RuntimeSocketAccept
            or BoundFunctionKind.RuntimeSocketConnect
            or BoundFunctionKind.RuntimeSocketReceive
            or BoundFunctionKind.RuntimeSocketReceiveAppend
            or BoundFunctionKind.RuntimeSocketReceiveVectored
            or BoundFunctionKind.RuntimeSocketPeek
            or BoundFunctionKind.RuntimeSocketSend
            or BoundFunctionKind.RuntimeSocketSendRange
            or BoundFunctionKind.RuntimeSocketSendVectored
            or BoundFunctionKind.RuntimeSocketTryClone
            or BoundFunctionKind.RuntimeSocketSendText
            or BoundFunctionKind.RuntimeSocketShutdown
            or BoundFunctionKind.RuntimeSocketBindDatagram
            or BoundFunctionKind.RuntimeSocketLocalPort
            or BoundFunctionKind.RuntimeSocketLocalEndpoint
            or BoundFunctionKind.RuntimeSocketRemoteEndpoint
            or BoundFunctionKind.RuntimeSocketSetNoDelay
            or BoundFunctionKind.RuntimeSocketNoDelay
            or BoundFunctionKind.RuntimeSocketSetKeepAlive
            or BoundFunctionKind.RuntimeSocketKeepAlive
            or BoundFunctionKind.RuntimeSocketSetLinger
            or BoundFunctionKind.RuntimeSocketLinger
            or BoundFunctionKind.RuntimeSocketSetReadTimeout
            or BoundFunctionKind.RuntimeSocketReadTimeout
            or BoundFunctionKind.RuntimeSocketSetWriteTimeout
            or BoundFunctionKind.RuntimeSocketWriteTimeout
            or BoundFunctionKind.RuntimeSocketSendTo
            or BoundFunctionKind.RuntimeSocketReceiveFrom
            or BoundFunctionKind.RuntimeSocketPeekFrom
            or BoundFunctionKind.RuntimeSocketClose
            or BoundFunctionKind.RuntimeSocketSetNonblocking
            or BoundFunctionKind.RuntimeSocketPoll
            or BoundFunctionKind.RuntimeSocketReactorWait
            or BoundFunctionKind.RuntimeSocketCompletionCreate
            or BoundFunctionKind.RuntimeSocketCompletionRegisterStream
            or BoundFunctionKind.RuntimeSocketCompletionRemoveStream
            or BoundFunctionKind.RuntimeSocketCompletionSubmit
            or BoundFunctionKind.RuntimeSocketCompletionCancel
            or BoundFunctionKind.RuntimeSocketCompletionDequeue
            or BoundFunctionKind.RuntimeSocketCompletionClose
            or BoundFunctionKind.RuntimeDiagnosticSessionStart
            or BoundFunctionKind.RuntimeDiagnosticSessionTrack
            or BoundFunctionKind.RuntimeDiagnosticSessionSnapshot
            or BoundFunctionKind.RuntimeDiagnosticSessionClose
            or BoundFunctionKind.RuntimeDnsLookup
            or BoundFunctionKind.RuntimeRunProcess
            or BoundFunctionKind.RuntimeRunProcessToFile
            or BoundFunctionKind.RuntimeCollectProcess
            or BoundFunctionKind.RuntimeSpawnProcess
            or BoundFunctionKind.RuntimeWaitProcess
            or BoundFunctionKind.RuntimePollChildProcess
            or BoundFunctionKind.RuntimeKillChildProcess
            or BoundFunctionKind.RuntimeChildProcessId
            or BoundFunctionKind.RuntimeProcessIdValue))
        {
            throw new SollangException($"unsupported runtime function kind '{function.Kind}'");
        }

        RuntimeValue? argument = null;
        var additionalParameterCount = function.AdditionalParameters?.Count ?? 0;
        if (methodReceiverName is not null)
        {
            if (expression.Arguments.Count != additionalParameterCount)
            {
                throw new SollangException(
                    $"method '{path}' expects {additionalParameterCount} additional argument(s)");
            }

            argument = EmitPrimaryFunctionCallArgument(
                new NameExpression(methodReceiverName, expression.Line, expression.Column), function, path);
        }
        else if (function.InputType is null)
        {
            if (expression.Arguments.Count != additionalParameterCount)
            {
                throw new SollangException(
                    $"function '{path}' expects {additionalParameterCount} argument(s)");
            }
        }
        else
        {
            if (expression.Arguments.Count != 1 + additionalParameterCount)
            {
                throw new SollangException(
                    $"function '{path}' expects {1 + additionalParameterCount} argument(s)");
            }

            argument = EmitPrimaryFunctionCallArgument(expression.Arguments[0], function, path);
        }

        var borrowedTemporaries = new List<RuntimeValue>();
        var additionalArgumentOffset = methodReceiverName is not null || function.InputType is null ? 0 : 1;
        if (additionalArgumentOffset > 0 && argument is not null
            && function.InputOwnership == BoundFunctionInputOwnership.Default)
            TrackReadonlyCallTemporary(expression.Arguments[0], argument, borrowedTemporaries);
        var savedOwners = new List<(RuntimeValue Value, AsyncExpressionCarrier? Carrier)>();
        PreserveAsyncCallOwners(borrowedTemporaries, savedOwners);
        var savedArgument = argument is null ? null : PreserveAsyncExpressionValue(argument,
            function.InputOwnership == BoundFunctionInputOwnership.Move
                && additionalArgumentOffset > 0
                && expression.Arguments[0] is not (NameExpression or FieldAccessExpression));
        var savedAdditional = new List<AsyncExpressionCarrier?>();
        var additionalArguments = (function.AdditionalParameters ?? [])
            .Select((parameter, index) =>
            {
                var argumentExpression = expression.Arguments[additionalArgumentOffset + index];
                var value = parameter.Ownership == BoundFunctionInputOwnership.MutableBorrow
                    ? CreateMutableBorrowArgument(argumentExpression, parameter.Type, path, parameter.Name)
                    : _program.Types.IsReference(parameter.Type)
                        ? CreateReadonlyReferenceArgument(argumentExpression, parameter.Type, path)
                    : EmitFunctionArgumentExpression(argumentExpression, parameter.Type);
                EnsureFunctionArgumentRuntimeType(value, parameter.Type, path);
                if (parameter.Ownership == BoundFunctionInputOwnership.Default)
                    TrackReadonlyCallTemporary(argumentExpression, value, borrowedTemporaries);
                PreserveAsyncCallOwners(borrowedTemporaries, savedOwners);
                savedAdditional.Add(PreserveAsyncExpressionValue(value,
                    parameter.Ownership == BoundFunctionInputOwnership.Move
                        && argumentExpression is not (NameExpression or FieldAccessExpression)));
                return value;
            })
            .ToArray();
        if (argument is not null)
            argument = RestoreAsyncExpressionValue(savedArgument, argument);
        for (var index = 0; index < additionalArguments.Length; index++)
            additionalArguments[index] = RestoreAsyncExpressionValue(savedAdditional[index], additionalArguments[index]);
        RestoreAsyncCallOwners(borrowedTemporaries, savedOwners);
        var value = EmitFunctionCall(function, argument, additionalArguments);
        RemoveOwnedParameterArgumentsIfNeeded(function, expression.Arguments, additionalArgumentOffset);
        if (methodReceiverName is not null && FunctionConsumesOwnedHeapInput(function))
            RemoveLocal(methodReceiverName);
        foreach (var temporary in borrowedTemporaries.AsEnumerable().Reverse())
            DropOwnedRuntimeValue(temporary);
        return value;
    }

    private RuntimeValue EmitRuntimeWrapperCall(
        CallExpression expression,
        BoundFunction wrapperFunction,
        BoundFunctionKind wrapperKind,
        string path)
    {
        if (expression.Arguments.Count != 1)
        {
            throw new SollangException($"{path} expects exactly one argument");
        }

        return wrapperKind switch
        {
            BoundFunctionKind.RuntimePrint => EmitRuntimePrintCall(expression.Arguments[0], appendNewLine: false),
            BoundFunctionKind.RuntimePrintLine => EmitRuntimePrintCall(expression.Arguments[0], appendNewLine: true),
            BoundFunctionKind.RuntimePrintError => EmitRuntimePrintErrorCall(expression.Arguments[0], appendNewLine: false),
            BoundFunctionKind.RuntimePrintErrorLine => EmitRuntimePrintErrorCall(expression.Arguments[0], appendNewLine: true),
            BoundFunctionKind.RuntimeReadInt => EmitReadIntPromptExpression(expression.Arguments[0]),
            BoundFunctionKind.RuntimeSeedRandom
                or BoundFunctionKind.RuntimeOpenIntWriter
                or BoundFunctionKind.RuntimeWriteInt
                or BoundFunctionKind.RuntimeOpenIntReader
                => EmitRuntimeUnitWrapperCall(expression.Arguments[0], wrapperKind, path),
            BoundFunctionKind.RuntimeRandomBelow
                or BoundFunctionKind.RuntimeClosestInt
                => EmitRuntimeIntWrapperCall(expression.Arguments[0], wrapperKind, path),
            BoundFunctionKind.RuntimeSecureRandomBytes
                => EmitRuntimeSecureRandomBytes(
                    wrapperFunction,
                    EmitFunctionArgumentExpression(expression.Arguments[0], BoundType.UIntSize),
                    path),
            _ => throw new SollangException($"unsupported runtime wrapper kind '{wrapperKind}'")
        };
    }

    private RuntimeUnit EmitRuntimeUnitWrapperCall(Expression argument, BoundFunctionKind kind, string path)
    {
        var value = EmitExpression(argument);
        EmitRuntimeUnitIntrinsic(kind, value, path);
        return RuntimeUnit.Instance;
    }

    private RuntimeInt EmitRuntimeIntWrapperCall(Expression argument, BoundFunctionKind kind, string path)
    {
        var value = EmitExpression(argument);
        return EmitRuntimeIntIntrinsic(kind, value, path);
    }

    private RuntimeUnit EmitRuntimePrintCall(Expression argument, bool appendNewLine)
    {
        _mainOk = EmitPrintArgument(argument, _mainOk);
        if (appendNewLine)
        {
            _mainOk = EmitWriteText("\n", _mainOk);
        }

        return RuntimeUnit.Instance;
    }

    private void PreserveAsyncCallOwners(
        List<RuntimeValue> temporaries,
        List<(RuntimeValue Value, AsyncExpressionCarrier? Carrier)> saved)
    {
        while (saved.Count < temporaries.Count)
        {
            var value = temporaries[saved.Count];
            saved.Add((value, PreserveAsyncExpressionValue(value, ownsValue: true)));
        }
    }

    private void RestoreAsyncCallOwners(
        List<RuntimeValue> temporaries,
        List<(RuntimeValue Value, AsyncExpressionCarrier? Carrier)> saved)
    {
        for (var index = 0; index < saved.Count; index++)
            temporaries[index] = RestoreAsyncExpressionValue(saved[index].Carrier, saved[index].Value);
    }

    private RuntimeValue EmitFlowFunctionCall(
        BoundFunction function,
        RuntimeValue argument,
        Expression source,
        IReadOnlyList<Expression> additionalExpressions,
        bool receivesSourcePlace, bool ownsFlowTemporary)
    {
        if (function.InputType is null)
        {
            throw new SollangException($"function '{function.Name}' does not accept a flowed input");
        }

        var borrowedTemporaries = new List<RuntimeValue>();
        if (function.InputOwnership == BoundFunctionInputOwnership.Default)
        {
            if (receivesSourcePlace)
                TrackReadonlyCallTemporary(source, argument, borrowedTemporaries);
            else if (ownsFlowTemporary && IsOwnedContainerRuntimeValue(argument))
                borrowedTemporaries.Add(argument);
        }
        var functionArgument = function.InputOwnership == BoundFunctionInputOwnership.MutableBorrow
            ? CreateMutableBorrowArgument(
                source,
                function.InputType.Value,
                function.Name,
                function.InputName ?? "it")
            : _program.Types.IsReference(function.InputType.Value)
                ? argument is RuntimeReference producedReference
                    ? producedReference
                    : receivesSourcePlace
                        ? CreateReadonlyReferenceArgument(source, function.InputType.Value, function.Name)
                        : CreateReadonlyFlowResultReference(argument, function.InputType.Value, function.Name)
                : argument;
        EnsureFunctionArgumentRuntimeType(functionArgument, function.InputType.Value, function.Name);
        var savedOwners = new List<(RuntimeValue Value, AsyncExpressionCarrier? Carrier)>();
        PreserveAsyncCallOwners(borrowedTemporaries, savedOwners);
        var savedArgument = PreserveAsyncExpressionValue(functionArgument,
            function.InputOwnership == BoundFunctionInputOwnership.Move && ownsFlowTemporary);
        var savedAdditional = new List<AsyncExpressionCarrier?>();
        var additionalArguments = (function.AdditionalParameters ?? [])
            .Select((parameter, index) =>
            {
                var value = parameter.Ownership == BoundFunctionInputOwnership.MutableBorrow
                    ? CreateMutableBorrowArgument(
                        additionalExpressions[index], parameter.Type, function.Name, parameter.Name)
                    : _program.Types.IsReference(parameter.Type)
                        ? CreateReadonlyReferenceArgument(additionalExpressions[index], parameter.Type, function.Name)
                        : EmitFlowAdditionalValue(parameter.Type, additionalExpressions[index],
                            parameter.Ownership == BoundFunctionInputOwnership.Default ? borrowedTemporaries : null);
                EnsureFunctionArgumentRuntimeType(value, parameter.Type, function.Name);
                PreserveAsyncCallOwners(borrowedTemporaries, savedOwners);
                savedAdditional.Add(PreserveAsyncExpressionValue(value,
                    parameter.Ownership == BoundFunctionInputOwnership.Move
                        && additionalExpressions[index] is not (NameExpression or FieldAccessExpression)));
                return value;
            })
            .ToArray();
        functionArgument = RestoreAsyncExpressionValue(savedArgument, functionArgument);
        for (var index = 0; index < additionalArguments.Length; index++)
            additionalArguments[index] = RestoreAsyncExpressionValue(savedAdditional[index], additionalArguments[index]);
        RestoreAsyncCallOwners(borrowedTemporaries, savedOwners);
        var value = EmitFunctionCall(function, functionArgument, additionalArguments);
        RemoveOwnedParameterFlowArgumentsIfNeeded(function, source, additionalExpressions, receivesSourcePlace);
        foreach (var temporary in borrowedTemporaries.AsEnumerable().Reverse())
            DropOwnedRuntimeValue(temporary);
        return value;
    }

    private RuntimeReference CreateReadonlyFlowResultReference(RuntimeValue value, BoundType referenceType, string path)
    {
        var elementType = _program.Types.GetReference(referenceType).ElementType;
        EnsureRuntimeType(value, elementType, path);
        return new RuntimeReference(
            referenceType,
            elementType,
            GetOrCreateReadonlyValuePointer(value, "ref_flow_result"));
    }

    private void TrackReadonlyCallTemporary(Expression expression, RuntimeValue value, List<RuntimeValue> temporaries)
    {
        if (TakeReadonlyTemporaryOwner(expression, value) is { } owner)
            temporaries.Add(owner);
    }

    private RuntimeValue? TakeReadonlyTemporaryOwner(Expression expression, RuntimeValue value)
    {
        if (_anonymousProjectionOwners.Remove(expression, out var projectedOwner))
        {
            return IsOwnedContainerRuntimeValue(projectedOwner) ? projectedOwner : null;
        }

        // A field projection without an explicitly recorded anonymous parent
        // is a stable place. Enum-pattern payload bindings, for example, are
        // stored outside _locals but remain owned by the matched subject; the
        // readonly call must not drop the projected payload independently.
        if (expression is FieldAccessExpression)
            return null;

        if (!IsAnonymousOwnedExpression(expression))
            return null;

        return IsOwnedContainerRuntimeValue(value) ? value : null;
    }

    private RuntimeValue EmitFlowAdditionalValue(BoundType expectedType, Expression expression, List<RuntimeValue>? temporaries = null)
    {
        var value = EmitFunctionArgumentExpression(expression, expectedType);
        if (temporaries is not null)
            TrackReadonlyCallTemporary(expression, value, temporaries);
        return _program.Types.IsSlice(expectedType)
            ? CreateRuntimeSlice(expectedType, value)
            : value;
    }

    private RuntimeValue EmitPrimaryFunctionCallArgument(
        Expression expression, BoundFunction function, string path)
    {
        var expectedType = function.InputType!.Value;
        if (function.InputOwnership == BoundFunctionInputOwnership.MutableBorrow)
        {
            return CreateMutableBorrowArgument(expression, expectedType, path, function.InputName ?? "it");
        }
        if (_program.Types.IsReference(expectedType))
        {
            return CreateReadonlyReferenceArgument(expression, expectedType, path);
        }
        var value = EmitFunctionArgumentExpression(expression, expectedType);
        EnsureFunctionArgumentRuntimeType(value, expectedType, path);
        return value;
    }

    private RuntimeValue EmitFunctionArgumentExpression(Expression expression, BoundType expectedType)
    {
        _expressionContinuations.Push((_currentFunction, expression));
        try { return EmitFunctionArgumentExpressionCore(expression, expectedType); }
        finally { _expressionContinuations.Pop(); }
    }

    private RuntimeValue EmitFunctionArgumentExpressionCore(Expression expression, BoundType expectedType)
    {
        if (_program.Types.IsReference(expectedType))
        {
            return CreateReadonlyReferenceArgument(
                expression,
                expectedType,
                _currentFunction?.Name ?? "reference result");
        }
        if (expression is WhenExpression whenExpression && IsIntegerType(expectedType))
        {
            return EmitWhenExpression(whenExpression, expectedType);
        }
        if (expression is EnumMatchExpression enumMatch && IsIntegerType(expectedType))
        {
            return EmitEnumMatchExpression(enumMatch, expectedType);
        }
        if (expression is IfExpression conditional && IsIntegerType(expectedType))
        {
            return EmitIfExpression(conditional, expectedType);
        }
        if (IsNumericType(expectedType)
            && expression is AddExpression
                or SubtractExpression
                or MultiplyExpression
                or DivideExpression
                or ModuloExpression)
        {
            return EmitContextualNumericBinary(expression, expectedType);
        }
        if (expression is DictionaryLiteralExpression contextualStruct
            && _program.Types.IsStruct(expectedType))
        {
            return EmitContextualStructLiteral(contextualStruct, expectedType);
        }
        if (expression is ArrayLiteralExpression contextualDynamicLiteral
            && (expectedType == BoundType.DynamicIntArray
                || _program.Types.IsDynamicArray(expectedType)))
        {
            var elementType = expectedType == BoundType.DynamicIntArray
                ? BoundType.Int
                : _program.Types.GetDynamicArray(expectedType).ElementType;
            var elements = EmitPreservedExpressionValues(contextualDynamicLiteral.Elements,
                element => EmitFunctionArgumentExpression(element, elementType),
                element => OwnsPendingExpressionValue(element));
            return expectedType == BoundType.DynamicIntArray
                ? EmitDynamicIntArrayLiteral(contextualDynamicLiteral, elements.Cast<RuntimeInt>().ToArray())
                : EmitDynamicInlineArrayLiteral(expectedType, elements);
        }
        if (expression is ArrayLiteralExpression boundedArray
            && _program.Types.IsBoundedArray(expectedType))
        {
            var elementType = _program.Types.GetBoundedArray(expectedType).ElementType;
            var elements = EmitPreservedExpressionValues(boundedArray.Elements,
                element => EmitFunctionArgumentExpression(element, elementType),
                element => OwnsPendingExpressionValue(element));
            return EmitBoundedInlineArrayLiteral(expectedType, elements);
        }
        if (expression is ArrayLiteralExpression fixedArray
            && (expectedType == BoundType.StaticIntArray
                || expectedType == BoundType.StaticTextArray
                || _program.Types.IsStaticArray(expectedType)))
        {
            var elementType = expectedType switch
            {
                BoundType.StaticIntArray => BoundType.Int,
                BoundType.StaticTextArray => BoundType.Text,
                _ => _program.Types.GetStaticArray(expectedType).ElementType
            };
            var elements = EmitPreservedExpressionValues(fixedArray.Elements,
                element => EmitFunctionArgumentExpression(element, elementType),
                element => OwnsPendingExpressionValue(element));
            if (expectedType == BoundType.StaticIntArray)
            {
                return EmitStaticIntArrayLiteral(fixedArray, elements.Cast<RuntimeInt>().ToArray());
            }
            if (expectedType == BoundType.StaticTextArray)
            {
                return EmitStaticTextArrayLiteral(fixedArray, elements.Cast<RuntimeText>().ToArray());
            }
            return EmitStaticInlineArrayLiteral(expectedType, elements);
        }
        if (expression is ArrayRepeatExpression contextualRepeat
            && (expectedType == BoundType.DynamicIntArray
                || _program.Types.IsDynamicArray(expectedType)
                || _program.Types.IsBoundedArray(expectedType)))
        {
            var elementType = expectedType == BoundType.DynamicIntArray
                ? BoundType.Int
                : _program.Types.IsBoundedArray(expectedType)
                    ? _program.Types.GetBoundedArray(expectedType).ElementType
                    : _program.Types.GetDynamicArray(expectedType).ElementType;
            return EmitArrayRepeat(contextualRepeat, elementType, expectedType);
        }
        if (expression is ArrayRepeatExpression repeat
            && _program.Types.IsStaticArray(expectedType))
        {
            return EmitArrayRepeat(
                repeat,
                _program.Types.GetStaticArray(expectedType).ElementType,
                expectedType);
        }
        if (expression is ArrayRepeatExpression sliceRepeat
            && _program.Types.IsSlice(expectedType))
        {
            return EmitArrayRepeat(
                sliceRepeat,
                _program.Types.GetSliceElement(expectedType));
        }
        if (_program.Types.IsSlice(expectedType)
            && expression is ArrayLiteralExpression array)
        {
            var elementType = _program.Types.GetSliceElement(expectedType);
            var elements = EmitPreservedExpressionValues(array.Elements,
                element => EmitFunctionArgumentExpression(element, elementType),
                element => OwnsPendingExpressionValue(element));
            if (elementType == BoundType.Int)
            {
                return EmitStaticIntArrayLiteral(array, elements.Cast<RuntimeInt>().ToArray());
            }
            var arrayType = _program.Types.GetOrAddStaticArray(elementType);
            return EmitStaticInlineArrayLiteral(arrayType, elements);
        }
        if (IsIntegerType(expectedType)
            && TryGetIntegerLiteralText(expression, out var integerLiteral))
        {
            return new RuntimeInt(expectedType, integerLiteral);
        }
        if (IsFloatType(expectedType)
            && TryGetNumericLiteralText(expression, out var floatingLiteral))
        {
            return new RuntimeFloat(expectedType,
                FormatLlvmFloatingLiteral(floatingLiteral, expectedType, expression.Line, expression.Column));
        }

        var value = EmitExpression(expression);
        if (_program.Types.IsStaticArray(expectedType)
            && _program.Types.GetStaticArray(expectedType).FixedLength is { } fixedLength
            && value.Type != expectedType)
        {
            var expectedDefinition = _program.Types.GetStaticArray(expectedType);
            if (value is RuntimeDynamicInlineArray dynamicArray
                && dynamicArray.ElementType == expectedDefinition.ElementType)
            {
                EmitFixedArrayLengthCheck(dynamicArray.LengthName, fixedLength);
                return new RuntimeStaticInlineArray(
                    expectedType,
                    expectedDefinition.ElementType,
                    dynamicArray.PointerName,
                    fixedLength.ToString(CultureInfo.InvariantCulture),
                    fixedLength,
                    fixedLength,
                    dynamicArray.Storage);
            }
            if (value is RuntimeStaticInlineArray staticArray
                && staticArray.ElementType == expectedDefinition.ElementType)
            {
                EmitFixedArrayLengthCheck(staticArray.LengthName, fixedLength);
                return new RuntimeStaticInlineArray(
                    expectedType,
                    expectedDefinition.ElementType,
                    staticArray.PointerName,
                    fixedLength.ToString(CultureInfo.InvariantCulture),
                    fixedLength,
                    fixedLength,
                    staticArray.Storage);
            }
        }
        return value;
    }

    private void EmitFixedArrayLengthCheck(string actualLength, int expectedLength)
    {
        var matches = NextTemp("fixed_array_length_matches");
        EmitCompare(
            matches,
            "eq",
            "i64",
            actualLength,
            expectedLength.ToString(CultureInfo.InvariantCulture));
        EmitTrapUnless(matches, "fixed_array_length");
    }

    private bool TryEmitNumericConversion(CallExpression expression, out RuntimeValue value)
    {
        value = null!;
        if (expression.Path.Count != 1
            || !_program.Types.TryResolve(expression.Path[0], out var targetType)
            || !IsNumericType(targetType))
        {
            return false;
        }
        if (expression.Arguments.Count != 1)
        {
            throw new SollangException($"numeric conversion '{expression.Path[0]}' expects exactly one argument");
        }
        if (IsIntegerType(targetType)
            && TryGetIntegerLiteralText(expression.Arguments[0], out var integerLiteral))
        {
            value = new RuntimeInt(targetType, integerLiteral);
            return true;
        }
        if (IsFloatType(targetType)
            && TryGetNumericLiteralText(expression.Arguments[0], out var floatingLiteral))
        {
            value = new RuntimeFloat(targetType, FormatLlvmFloatingLiteral(
                floatingLiteral, targetType, expression.Arguments[0].Line, expression.Arguments[0].Column));
            return true;
        }
        var source = EmitExpression(expression.Arguments[0]);
        if (!IsNumericType(source.Type))
        {
            throw new SollangException($"numeric conversion '{expression.Path[0]}' expects a numeric value");
        }
        if (source is RuntimeInt checkedInteger && IsIntegerType(targetType))
        {
            EmitCheckedIntegerConversion(checkedInteger, targetType);
        }
        if (source.Type == targetType
            || (NumericBitWidth(source.Type) == NumericBitWidth(targetType)
                && IsIntegerType(source.Type) && IsIntegerType(targetType)))
        {
            value = source switch
            {
                RuntimeInt sameWidthInteger => new RuntimeInt(targetType, sameWidthInteger.ValueName),
                RuntimeFloat floating => new RuntimeFloat(targetType, floating.ValueName),
                _ => throw new SollangException("numeric conversion received a non-numeric runtime value")
            };
            return true;
        }

        var converted = NextTemp("numeric_convert");
        string instruction;
        if (source is RuntimeInt integer && IsIntegerType(targetType))
        {
            instruction = NumericBitWidth(targetType) < NumericBitWidth(source.Type)
                ? "trunc"
                : IsSignedIntegerType(source.Type) ? "sext" : "zext";
            EmitAssign(converted,
                $"{instruction} {LlvmType(source.Type)} {integer.ValueName} to {LlvmType(targetType)}");
            value = new RuntimeInt(targetType, converted);
            return true;
        }
        if (source is RuntimeInt intValue && IsFloatType(targetType))
        {
            instruction = IsSignedIntegerType(source.Type) ? "sitofp" : "uitofp";
            EmitAssign(converted,
                $"{instruction} {LlvmType(source.Type)} {intValue.ValueName} to {LlvmType(targetType)}");
            value = new RuntimeFloat(targetType, converted);
            return true;
        }
        if (source is RuntimeFloat floatValue && IsIntegerType(targetType))
        {
            instruction = IsSignedIntegerType(targetType) ? "fptosi" : "fptoui";
            EmitAssign(converted,
                $"{instruction} {LlvmType(source.Type)} {floatValue.ValueName} to {LlvmType(targetType)}");
            value = new RuntimeInt(targetType, converted);
            return true;
        }
        if (source is RuntimeFloat floatingValue && IsFloatType(targetType))
        {
            instruction = NumericBitWidth(targetType) < NumericBitWidth(source.Type) ? "fptrunc" : "fpext";
            EmitAssign(converted,
                $"{instruction} {LlvmType(source.Type)} {floatingValue.ValueName} to {LlvmType(targetType)}");
            value = new RuntimeFloat(targetType, converted);
            return true;
        }
        throw new SollangException("unsupported numeric conversion");
    }

    private static bool TryGetIntegerLiteralText(Expression expression, out string text)
    {
        switch (expression)
        {
            case NumberExpression number
                when !number.Text.Contains('.', StringComparison.Ordinal)
                    && !number.Text.Contains('e', StringComparison.OrdinalIgnoreCase):
                text = number.Text;
                return true;
            case NegateExpression { Value: NumberExpression number }
                when !number.Text.Contains('.', StringComparison.Ordinal)
                    && !number.Text.Contains('e', StringComparison.OrdinalIgnoreCase):
                text = "-" + number.Text;
                return true;
            default:
                text = string.Empty;
                return false;
        }
    }

    private static bool TryGetNumericLiteralText(Expression expression, out string text)
    {
        switch (expression)
        {
            case NumberExpression number:
                text = number.Text;
                return true;
            case NegateExpression { Value: NumberExpression number }:
                text = "-" + number.Text;
                return true;
            default:
                text = string.Empty;
                return false;
        }
    }

    private void EmitCheckedIntegerConversion(RuntimeInt source, BoundType targetType)
    {
        var (sourceMin, sourceMax) = IntegerRange(source.Type);
        var (targetMin, targetMax) = IntegerRange(targetType);
        var llvmType = LlvmType(source.Type);
        var signed = IsSignedIntegerType(source.Type);
        if (sourceMin < targetMin)
        {
            var lower = NextTemp("numeric_lower_bound");
            EmitCompare(lower, signed ? "sge" : "uge", llvmType, source.ValueName,
                targetMin.ToString(CultureInfo.InvariantCulture));
            EmitTrapUnless(lower, "numeric_conversion_lower", "numeric_conversion_lower");
        }
        if (sourceMax > targetMax)
        {
            var upper = NextTemp("numeric_upper_bound");
            EmitCompare(upper, signed ? "sle" : "ule", llvmType, source.ValueName,
                targetMax.ToString(CultureInfo.InvariantCulture));
            EmitTrapUnless(upper, "numeric_conversion_upper", "numeric_conversion_upper");
        }
        if (targetType == BoundType.CodePoint && sourceMax >= 0xD800 && sourceMin <= 0xDFFF)
        {
            var below = NextTemp("codepoint_below_surrogate");
            var above = NextTemp("codepoint_above_surrogate");
            var valid = NextTemp("codepoint_not_surrogate");
            EmitCompare(below, signed ? "slt" : "ult", llvmType, source.ValueName, "55296");
            EmitCompare(above, signed ? "sgt" : "ugt", llvmType, source.ValueName, "57343");
            EmitInstruction($"{valid} = or i1 {below}, {above}");
            EmitTrapUnless(valid, "numeric_conversion_surrogate", "numeric_conversion_surrogate");
        }
    }

    private (BigInteger Minimum, BigInteger Maximum) IntegerRange(BoundType type)
    {
        var bits = NumericBitWidth(type);
        if (type == BoundType.CodePoint)
        {
            return (BigInteger.Zero, new BigInteger(0x10FFFF));
        }
        return IsSignedIntegerType(type)
            ? (-(BigInteger.One << (bits - 1)), (BigInteger.One << (bits - 1)) - 1)
            : (BigInteger.Zero, (BigInteger.One << bits) - 1);
    }

    private bool TryResolveInstanceMethodCall(
        IReadOnlyList<string> path,
        out BoundFunction function,
        out string? receiverName)
    {
        function = null!;
        receiverName = null;
        if (path.Count != 2 || !_locals.TryGetValue(path[0], out var receiver))
        {
            return false;
        }

        if (!TryResolveInstanceMethod(_program.Types.ReadValueType(receiver.Type), path[1], out function))
        {
            return false;
        }

        receiverName = path[0];
        return true;
    }

    private bool TryResolveInstanceMethod(BoundType receiverType, string methodName, out BoundFunction function)
    {
        function = null!;
        var typeName = _program.Types.IsStruct(receiverType)
            ? _program.Types.GetStruct(receiverType).Name
            : _program.Types.IsEnum(receiverType)
                ? _program.Types.GetEnum(receiverType).Name
                : null;
        if (typeName is null)
        {
            return false;
        }
        if (methodName.Contains('.', StringComparison.Ordinal))
        {
            var separator = methodName.LastIndexOf('.');
            var traitName = methodName[..separator];
            var memberName = methodName[(separator + 1)..];
            if (_currentFunctions.TryGetValue(traitName + "." + typeName + "." + memberName, out function!)
                && function.InputType == receiverType)
            {
                return true;
            }

            // Semantic import resolution may canonicalize an unqualified flow
            // target to an unrelated global. If it is not a real trait method
            // for this receiver, retain inherent receiver precedence by using
            // the final segment as the instance-method name.
            methodName = memberName;
        }

        if (_currentFunctions.TryGetValue(typeName + "." + methodName, out function!)
            && function.InputType == receiverType)
        {
            return true;
        }

        var candidates = _currentFunctions.Values
            .Where(candidate => candidate.TraitName is not null
                && candidate.InputType == receiverType
                && candidate.Name.EndsWith("." + methodName, StringComparison.Ordinal))
            .Distinct()
            .ToArray();
        if (candidates.Length != 1)
        {
            return false;
        }

        function = candidates[0];
        return true;
    }

    private RuntimeValue EmitInlineFunctionCall(
        BoundFunction function,
        RuntimeValue? argument,
        IReadOnlyList<RuntimeValue>? additionalArguments = null)
    {
        if (function.Body is null && function.ReturnType != BoundType.Unit)
        {
            throw new SollangException($"function '{function.Name}' has no body");
        }

        if (_inlineFunctionStack.Any(candidate => ReferenceEquals(candidate, function)))
        {
            throw new SollangException($"recursive inline function '{function.Name}' is not supported in the current runtime slice");
        }

        var outerLocals = CaptureLocals();
        var previousFunction = _currentFunction;
        var previousFunctions = _currentFunctions;
        var previousOwnedStructLiteralDepth = _ownedStructLiteralDepth;
        _currentFunction = function;
        _currentFunctions = CreateFunctionScope(_currentFunctions, function.LocalFunctions);
        // An inline callee owns a distinct lexical transfer boundary. A call
        // emitted while evaluating an outer literal field must not make the
        // callee's return literal look like a syntactic child of that outer
        // literal, or the callee skips its source-owner accounting and drops
        // an owner after inserting it into the returned aggregate.
        _ownedStructLiteralDepth = 0;
        _inlineFunctionStack.Add(function);
        try
        {
            RestoreLocals(KeepLocalsInScope(
                outerLocals,
                CapturedBindingsForFunction(function).Select(static capture => capture.Key)));
            var functionLocals = CaptureLocals();
            BindInlineFunctionParameters(function, argument, additionalArguments);

            EmitStatements(function.BlockBody);
            var value = function.Body is null
                ? RuntimeUnit.Instance
                : EmitFunctionArgumentExpression(function.Body, function.ReturnType);
            if (function.Body is not null)
                value = PrepareBorrowedFixedStorageReturn(function.Body, value);
            EnsureRuntimeType(value, function.ReturnType, function.Name);
            var transferredOwnerName = function.Body is not null && IsOwnedContainerRuntimeValue(value)
                ? GetFunctionResultTransferredOwnerName(function, function.Body)
                : null;
            DropOwnedLocalsCreatedSince(functionLocals, transferredOwnerName, function.Body);
            return value;
        }
        finally
        {
            _inlineFunctionStack.RemoveAt(_inlineFunctionStack.Count - 1);
            _currentFunction = previousFunction;
            _currentFunctions = previousFunctions;
            _ownedStructLiteralDepth = previousOwnedStructLiteralDepth;
            RestoreLocals(outerLocals);
        }
    }

    private RuntimeValue EmitFunctionCall(
        BoundFunction function,
        RuntimeValue? argument,
        IReadOnlyList<RuntimeValue>? additionalArguments = null)
    {
        if (function.Kind is BoundFunctionKind.RuntimeDiagnosticSessionStart
            or BoundFunctionKind.RuntimeDiagnosticSessionTrack
            or BoundFunctionKind.RuntimeDiagnosticSessionSnapshot
            or BoundFunctionKind.RuntimeDiagnosticSessionClose)
        {
            return EmitAsyncDiagnosticCall(function, argument, additionalArguments ?? []);
        }

        if (function.Kind is BoundFunctionKind.RuntimeReadBytesAt
            or BoundFunctionKind.RuntimeWriteBytesAt
            or BoundFunctionKind.RuntimeReadBytesAtAsync
            or BoundFunctionKind.RuntimeWriteBytesAtAsync)
        {
            if (argument is not RuntimeStruct file)
            {
                throw new SollangException($"{function.Name} expects an owned file runtime struct");
            }
            return EmitRuntimeFileBufferCall(function, file, additionalArguments ?? []);
        }
        if (function.Kind is BoundFunctionKind.RuntimeSocketListen
            or BoundFunctionKind.RuntimeSocketAccept
            or BoundFunctionKind.RuntimeSocketConnect
            or BoundFunctionKind.RuntimeSocketReceive
            or BoundFunctionKind.RuntimeSocketReceiveAppend
            or BoundFunctionKind.RuntimeSocketReceiveVectored
            or BoundFunctionKind.RuntimeSocketPeek
            or BoundFunctionKind.RuntimeSocketSend
            or BoundFunctionKind.RuntimeSocketSendRange
            or BoundFunctionKind.RuntimeSocketSendVectored
            or BoundFunctionKind.RuntimeSocketTryClone
            or BoundFunctionKind.RuntimeSocketSendText
            or BoundFunctionKind.RuntimeSocketShutdown
            or BoundFunctionKind.RuntimeSocketBindDatagram
            or BoundFunctionKind.RuntimeSocketLocalPort
            or BoundFunctionKind.RuntimeSocketLocalEndpoint
            or BoundFunctionKind.RuntimeSocketRemoteEndpoint
            or BoundFunctionKind.RuntimeSocketSetNoDelay
            or BoundFunctionKind.RuntimeSocketNoDelay
            or BoundFunctionKind.RuntimeSocketSetKeepAlive
            or BoundFunctionKind.RuntimeSocketKeepAlive
            or BoundFunctionKind.RuntimeSocketSetLinger
            or BoundFunctionKind.RuntimeSocketLinger
            or BoundFunctionKind.RuntimeSocketSetReadTimeout
            or BoundFunctionKind.RuntimeSocketReadTimeout
            or BoundFunctionKind.RuntimeSocketSetWriteTimeout
            or BoundFunctionKind.RuntimeSocketWriteTimeout
            or BoundFunctionKind.RuntimeSocketSendTo
            or BoundFunctionKind.RuntimeSocketReceiveFrom
            or BoundFunctionKind.RuntimeSocketPeekFrom
            or BoundFunctionKind.RuntimeSocketClose
            or BoundFunctionKind.RuntimeSocketSetNonblocking
            or BoundFunctionKind.RuntimeSocketPoll
            or BoundFunctionKind.RuntimeSocketReactorWait
            or BoundFunctionKind.RuntimeSocketCompletionCreate
            or BoundFunctionKind.RuntimeSocketCompletionRegisterStream
            or BoundFunctionKind.RuntimeSocketCompletionRemoveStream
            or BoundFunctionKind.RuntimeSocketCompletionSubmit
            or BoundFunctionKind.RuntimeSocketCompletionCancel
            or BoundFunctionKind.RuntimeSocketCompletionDequeue
            or BoundFunctionKind.RuntimeSocketCompletionClose
            or BoundFunctionKind.RuntimeDnsLookup)
        {
            return function.Kind == BoundFunctionKind.RuntimeDnsLookup
                ? EmitRuntimeDnsLookup(function, argument, additionalArguments ?? [])
                : EmitRuntimeSocketCall(function, argument, additionalArguments ?? []);
        }
        if (function.Kind == BoundFunctionKind.Native)
        {
            return EmitNativeFunctionCall(function, argument, additionalArguments);
        }

        if (function.Kind is BoundFunctionKind.RuntimePrint
            or BoundFunctionKind.RuntimePrintLine
            or BoundFunctionKind.RuntimePrintError
            or BoundFunctionKind.RuntimePrintErrorLine)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Text value");
            }

            EnsureRuntimeType(argument, BoundType.Text, function.Name);
            var standardError = function.Kind is BoundFunctionKind.RuntimePrintError
                or BoundFunctionKind.RuntimePrintErrorLine;
            _mainOk = EmitWriteValue(argument, _mainOk, standardError);
            if (function.Kind is BoundFunctionKind.RuntimePrintLine
                or BoundFunctionKind.RuntimePrintErrorLine)
            {
                _mainOk = standardError
                    ? EmitStandardErrorNewLine(_mainOk)
                    : EmitWriteText("\n", _mainOk);
            }

            return RuntimeUnit.Instance;
        }

        if (function.Kind == BoundFunctionKind.RuntimeReadInt)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Text prompt");
            }

            EnsureRuntimeType(argument, BoundType.Text, function.Name);
            return EmitReadIntPrompt(argument);
        }

        if (function.Kind is BoundFunctionKind.RuntimeNowMillis
            or BoundFunctionKind.RuntimeUtcNowMillis
            or BoundFunctionKind.RuntimeMonotonicSuspendPolicy)
        {
            if (argument is not null)
            {
                throw new SollangException($"{function.Name} does not accept an argument");
            }

            return function.Kind switch
            {
                BoundFunctionKind.RuntimeUtcNowMillis => EmitRuntimeUtcNowMillisIntrinsic(function.Name),
                BoundFunctionKind.RuntimeMonotonicSuspendPolicy => EmitRuntimeMonotonicSuspendPolicyIntrinsic(function.Name),
                _ => EmitRuntimeNowMillisIntrinsic(function.Name)
            };
        }

        if (function.Kind == BoundFunctionKind.RuntimeRangeStream)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Range argument");
            }
            return EmitRuntimeRangeStream(function, argument, function.Name);
        }

        if (function.Kind == BoundFunctionKind.RuntimeMouseEvents)
        {
            if (argument is null || additionalArguments is { Count: > 0 })
            {
                throw new SollangException(
                    $"{function.Name} expects exactly one Source argument");
            }
            return EmitRuntimeMouseEvents(
                function,
                argument,
                function.Name);
        }

        if (function.Kind == BoundFunctionKind.RuntimePathStyle)
        {
            if (argument is not null)
            {
                throw new SollangException($"{function.Name} does not accept an argument");
            }
            return EmitRuntimePathStyle(function);
        }

        if (function.Kind == BoundFunctionKind.RuntimeParallelWorkers)
        {
            if (argument is not null)
            {
                throw new SollangException($"{function.Name} does not accept an argument");
            }
            return EmitRuntimeParallelWorkersIntrinsic(function.Name);
        }

        if (function.Kind == BoundFunctionKind.RuntimeLimitParallelWorkers)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Int argument");
            }
            return EmitRuntimeLimitParallelWorkersIntrinsic(argument, function.Name);
        }

        if (function.Kind == BoundFunctionKind.RuntimeParallelPeakWorkers)
        {
            if (argument is not null)
            {
                throw new SollangException($"{function.Name} does not accept an argument");
            }
            return EmitRuntimeParallelPeakWorkersIntrinsic(function.Name);
        }

        if (function.Kind == BoundFunctionKind.RuntimeSleep)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Duration argument");
            }

            return EmitRuntimeSleepIntrinsic(function, argument, function.Name);
        }

        if (function.Kind == BoundFunctionKind.RuntimeArguments)
        {
            if (argument is not null)
            {
                throw new SollangException($"{function.Name} does not accept an argument");
            }
            return EmitRuntimeArgumentsIntrinsic();
        }

        if (function.Kind == BoundFunctionKind.RuntimeEnvironment)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Text name");
            }
            return EmitRuntimeEnvironmentIntrinsic(function, argument);
        }

        if (function.Kind == BoundFunctionKind.RuntimeRunProcess)
        {
            if (argument is not RuntimeStruct command || additionalArguments is { Count: > 0 })
            {
                throw new SollangException($"{function.Name} expects one Command receiver");
            }
            return EmitRuntimeRunProcessIntrinsic(function, command);
        }

        if (function.Kind == BoundFunctionKind.RuntimeSpawnProcess)
        {
            if (argument is not RuntimeStruct command || additionalArguments is { Count: > 0 })
            {
                throw new SollangException($"{function.Name} expects one Command receiver");
            }
            return EmitRuntimeSpawnProcessIntrinsic(function, command);
        }

        if (function.Kind == BoundFunctionKind.RuntimeRunProcessToFile)
        {
            if (argument is not RuntimeStruct command
                || additionalArguments is not { Count: 1 }
                || additionalArguments[0] is not RuntimeText output)
            {
                throw new SollangException($"{function.Name} expects a Command receiver and Text output path");
            }
            return EmitRuntimeRunProcessToFileIntrinsic(function, command, output);
        }

        if (function.Kind == BoundFunctionKind.RuntimeCollectProcess)
        {
            if (argument is not RuntimeStruct command
                || additionalArguments is not { Count: 1 }
                || additionalArguments[0] is not RuntimeStruct limits)
            {
                throw new SollangException(
                    $"{function.Name} expects a Command receiver and CaptureLimits");
            }
            return EmitRuntimeCollectProcessIntrinsic(function, command, limits);
        }


        if (function.Kind == BoundFunctionKind.RuntimeWaitProcess)
        {
            if (argument is not RuntimeStruct child || additionalArguments is { Count: > 0 })
            {
                throw new SollangException($"{function.Name} expects one Child receiver");
            }
            return EmitRuntimeWaitProcessIntrinsic(function, child);
        }

        if (function.Kind == BoundFunctionKind.RuntimePollChildProcess)
        {
            if (argument is not RuntimeInt token || additionalArguments is { Count: > 0 })
            {
                throw new SollangException($"{function.Name} expects one UInt64 token");
            }
            return EmitRuntimePollChildProcessIntrinsic(function, token);
        }

        if (function.Kind == BoundFunctionKind.RuntimeKillChildProcess)
        {
            if (argument is not RuntimeInt token || additionalArguments is { Count: > 0 })
            {
                throw new SollangException($"{function.Name} expects one UInt64 token");
            }
            return EmitRuntimeKillChildProcessIntrinsic(function, token);
        }

        if (function.Kind == BoundFunctionKind.RuntimeChildProcessId)
        {
            if (argument is not RuntimeStruct child || additionalArguments is { Count: > 0 })
            {
                throw new SollangException($"{function.Name} expects one Child receiver");
            }
            return EmitRuntimeChildProcessIdIntrinsic(function, child);
        }

        if (function.Kind == BoundFunctionKind.RuntimeProcessIdValue)
        {
            if (argument is not RuntimeStruct processId || additionalArguments is { Count: > 0 })
            {
                throw new SollangException($"{function.Name} expects one ProcessId receiver");
            }
            return EmitRuntimeProcessIdValueIntrinsic(function, processId);
        }

        if (function.Kind == BoundFunctionKind.RuntimeExitProcess)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Int exit code");
            }
            return EmitRuntimeExitProcessIntrinsic(argument, function.Name);
        }

        if (function.Kind is BoundFunctionKind.RuntimeBorrowSourceText
            or BoundFunctionKind.RuntimeMapSourceText)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Text value");
            }
            return function.Kind == BoundFunctionKind.RuntimeBorrowSourceText
                ? EmitBorrowSourceText(argument)
                : EmitMapSourceText(argument);
        }

        if (function.Kind == BoundFunctionKind.RuntimeMapSourcePath)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Path value");
            }
            return EmitMapSourcePath(argument);
        }

        if (function.Kind == BoundFunctionKind.RuntimePathText)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Path value");
            }
            return EmitRuntimePathText(argument);
        }

        if (function.Kind is BoundFunctionKind.RuntimeOpenFile
            or BoundFunctionKind.RuntimeOpenWriteFile)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Text path");
            }
            return EmitRuntimeOpenFile(function, argument);
        }

        if (function.Kind == BoundFunctionKind.RuntimeReadDirectory)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Path value");
            }
            return EmitRuntimeReadDirectory(function, argument);
        }

        if (function.Kind == BoundFunctionKind.RuntimeCreateDirectory)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Path value");
            }
            return EmitRuntimeCreateDirectory(function, argument);
        }

        if (function.Kind is BoundFunctionKind.RuntimePathQuery or BoundFunctionKind.RuntimePathAbsolute)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Path value");
            }
            return function.Kind == BoundFunctionKind.RuntimePathAbsolute
                ? EmitRuntimePathAbsolute(function, argument)
                : EmitRuntimePathQuery(function, argument);
        }

        if (function.Kind is BoundFunctionKind.RuntimeCreateExclusiveFile
            or BoundFunctionKind.RuntimeRemoveFile)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Text path");
            }
            return EmitRuntimeFilePathStatus(function, argument);
        }

        if (function.Kind is BoundFunctionKind.RuntimeSyncFile
            or BoundFunctionKind.RuntimeAtomicReplaceFile)
        {
            if (argument is not RuntimeStruct fileArgument)
            {
                throw new SollangException($"{function.Name} expects a file runtime struct");
            }
            return function.Kind switch
            {
                BoundFunctionKind.RuntimeSyncFile => EmitRuntimeSyncFile(fileArgument),
                _ => EmitRuntimeAtomicReplaceFile(function, fileArgument)
            };
        }

        if (function.Kind is BoundFunctionKind.RuntimeOpenFileAsync
            or BoundFunctionKind.RuntimeOpenWriteFileAsync)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Text path");
            }
            return EmitRuntimeOpenFileAsync(function, argument);
        }

        if (function.Kind == BoundFunctionKind.RuntimeWriteScalar)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one scalar value");
            }
            return EmitRuntimeWriteScalar(function, argument);
        }

        if (function.Kind == BoundFunctionKind.RuntimeReadScalar)
        {
            if (argument is not null)
            {
                throw new SollangException($"{function.Name} does not accept an argument");
            }
            return EmitRuntimeReadScalar(function);
        }

        if (function.Kind == BoundFunctionKind.RuntimeReadScalarAsync)
        {
            if (argument is not null)
            {
                throw new SollangException($"{function.Name} does not accept an argument");
            }
            return EmitRuntimeReadScalarAsync(function);
        }

        if (function.Kind is BoundFunctionKind.RuntimeSeedRandom
            or BoundFunctionKind.RuntimeOpenIntWriter
            or BoundFunctionKind.RuntimeWriteInt
            or BoundFunctionKind.RuntimeCloseIntWriter
            or BoundFunctionKind.RuntimeOpenIntReader
            or BoundFunctionKind.RuntimeCloseIntReader)
        {
            return EmitRuntimeUnitIntrinsic(function, argument, function.Name);
        }

        if (function.Kind is BoundFunctionKind.RuntimeRandomBelow
            or BoundFunctionKind.RuntimeClosestInt)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one Int argument");
            }

            return EmitRuntimeIntIntrinsic(function, argument, function.Name);
        }

        if (function.Kind == BoundFunctionKind.RuntimeSecureRandomBytes)
        {
            if (argument is null)
            {
                throw new SollangException($"{function.Name} expects exactly one UIntSize argument");
            }
            return EmitRuntimeSecureRandomBytes(function, argument, function.Name);
        }

        if (function.Kind is not (BoundFunctionKind.User or BoundFunctionKind.Native))
        {
            throw new SollangException($"function '{function.Name}' does not produce a runtime value");
        }

        if (function.Kind == BoundFunctionKind.UserBlock
            || (function.IsStandardLibrary && !_standaloneStandardLibraryFunctions.Contains(function)))
        {
            return EmitInlineFunctionCall(function, argument, additionalArguments);
        }

        if (function.IsAsync)
        {
            return EmitAsyncFunctionCall(function, argument, additionalArguments);
        }

        if (IsNumericType(function.ReturnType))
        {
            return EmitNumericFunctionCall(function, argument, additionalArguments);
        }

        return function.ReturnType switch
        {
            BoundType.Arguments => EmitStructFunctionCall(function, argument, additionalArguments),
            BoundType.MappedBytes or BoundType.MutableMappedBytes => EmitStructFunctionCall(function, argument, additionalArguments),
            BoundType.Unit => EmitUnitFunctionCall(function, argument, additionalArguments),
            BoundType.Text => EmitTextFunctionCall(function, argument, additionalArguments),
            BoundType.Int => EmitIntFunctionCall(function, argument, additionalArguments),
            BoundType.Bool => EmitBoolFunctionCall(function, argument, additionalArguments),
            BoundType.DynamicIntArray => EmitDynamicIntArrayFunctionCall(function, argument, additionalArguments),
            _ when _program.Types.IsBoundedArray(function.ReturnType)
                || _program.Types.IsStaticArray(function.ReturnType)
                || _program.Types.IsBoundedDictionary(function.ReturnType)
                || _program.Types.IsBitSet(function.ReturnType)
                => EmitStructFunctionCall(function, argument, additionalArguments),
            _ when _program.Types.IsDynamicArray(function.ReturnType) => EmitDynamicInlineArrayFunctionCall(function, argument, additionalArguments),
            BoundType.IntDictionary => EmitIntDictionaryFunctionCall(function, argument, additionalArguments),
            BoundType.Arena => EmitArenaFunctionCall(function, argument, additionalArguments),
            _ when _program.Types.IsDictionary(function.ReturnType) => EmitInlineDictionaryFunctionCall(function, argument, additionalArguments),
            _ when _program.Types.IsReference(function.ReturnType) => EmitReferenceFunctionCall(function, argument, additionalArguments),
            _ when _program.Types.IsSlice(function.ReturnType) => EmitStructFunctionCall(function, argument, additionalArguments),
            _ when _program.Types.IsStruct(function.ReturnType)
                || _program.Types.IsEnum(function.ReturnType)
                || _program.Types.IsBox(function.ReturnType)
                || _program.Types.IsDynTrait(function.ReturnType)
                => EmitStructFunctionCall(function, argument, additionalArguments),
            _ when _program.Types.IsStream(function.ReturnType)
                || _program.Types.IsEventStream(function.ReturnType)
                => EmitStructFunctionCall(function, argument, additionalArguments),
            _ => throw new SollangException($"unsupported function return type {function.ReturnType}")
        };
    }

    private RuntimeValue EmitStructFunctionCall(BoundFunction function, RuntimeValue? argument, IReadOnlyList<RuntimeValue>? additionalArguments)
    {
        var value = NextTemp("struct_call");
        var arguments = FunctionCallArgumentList(function, argument, additionalArguments);
        var llvmType = LlvmType(function.ReturnType);
        EmitCall(value, llvmType, SymbolForFunction(function)[1..], arguments);
        return DematerializeAggregateValue(function.ReturnType, value);
    }

    private RuntimeReference EmitReferenceFunctionCall(
        BoundFunction function,
        RuntimeValue? argument,
        IReadOnlyList<RuntimeValue>? additionalArguments)
    {
        var pointer = NextTemp("ref_call");
        var arguments = FunctionCallArgumentList(function, argument, additionalArguments);
        EmitCall(pointer, "ptr", SymbolForFunction(function)[1..], arguments);
        var elementType = _program.Types.GetReference(function.ReturnType).ElementType;
        return new RuntimeReference(function.ReturnType, elementType, pointer);
    }

    private RuntimeUnit EmitUnitFunctionCall(BoundFunction function, RuntimeValue? argument, IReadOnlyList<RuntimeValue>? additionalArguments)
    {
        var arguments = FunctionCallArgumentList(function, argument, additionalArguments);
        EmitCall(target: null, "void", SymbolForFunction(function)[1..], arguments);
        return RuntimeUnit.Instance;
    }

    private RuntimeUnit EmitRuntimePrintErrorCall(Expression argument, bool appendNewLine)
    {
        _mainOk = EmitPrintArgument(argument, _mainOk, standardError: true);
        if (appendNewLine)
        {
            _mainOk = EmitStandardErrorNewLine(_mainOk);
        }
        return RuntimeUnit.Instance;
    }

    private RuntimeText EmitTextFunctionCall(BoundFunction function, RuntimeValue? argument, IReadOnlyList<RuntimeValue>? additionalArguments)
    {
        var aggregate = NextTemp("text");
        var arguments = FunctionCallArgumentList(function, argument, additionalArguments);
        EmitCall(aggregate, "%sollang.text", SymbolForFunction(function)[1..], arguments);

        var pointer = NextTemp("text_ptr");
        EmitAssign(pointer, $"extractvalue %sollang.text {aggregate}, 0");

        var length = NextTemp("text_len");
        EmitAssign(length, $"extractvalue %sollang.text {aggregate}, 1");

        return new RuntimeText(pointer, length);
    }

    private RuntimeInt EmitIntFunctionCall(BoundFunction function, RuntimeValue? argument, IReadOnlyList<RuntimeValue>? additionalArguments)
    {
        var value = NextTemp("call");
        var arguments = FunctionCallArgumentList(function, argument, additionalArguments);
        EmitCall(value, "i64", SymbolForFunction(function)[1..], arguments);
        return new RuntimeInt(value);
    }

    private RuntimeValue EmitNumericFunctionCall(BoundFunction function, RuntimeValue? argument, IReadOnlyList<RuntimeValue>? additionalArguments)
    {
        var value = NextTemp("numeric_call");
        var arguments = FunctionCallArgumentList(function, argument, additionalArguments);
        EmitCall(value, LlvmType(function.ReturnType), SymbolForFunction(function)[1..], arguments);
        return IsIntegerType(function.ReturnType)
            ? new RuntimeInt(function.ReturnType, value)
            : new RuntimeFloat(function.ReturnType, value);
    }

    private RuntimeBool EmitBoolFunctionCall(BoundFunction function, RuntimeValue? argument, IReadOnlyList<RuntimeValue>? additionalArguments)
    {
        var value = NextTemp("call");
        var arguments = FunctionCallArgumentList(function, argument, additionalArguments);
        EmitCall(value, "i1", SymbolForFunction(function)[1..], arguments);
        return new RuntimeBool(value);
    }

    private RuntimeDynamicIntArray EmitDynamicIntArrayFunctionCall(BoundFunction function, RuntimeValue? argument, IReadOnlyList<RuntimeValue>? additionalArguments)
    {
        var aggregate = NextTemp("array");
        var arguments = FunctionCallArgumentList(function, argument, additionalArguments);
        EmitCall(aggregate, "%sollang.dynamic_int_array", SymbolForFunction(function)[1..], arguments);

        var pointer = NextTemp("array_ptr");
        EmitAssign(pointer, $"extractvalue %sollang.dynamic_int_array {aggregate}, 0");

        var length = NextTemp("array_len");
        EmitAssign(length, $"extractvalue %sollang.dynamic_int_array {aggregate}, 1");

        var capacity = NextTemp("array_capacity");
        EmitAssign(capacity, $"extractvalue %sollang.dynamic_int_array {aggregate}, 2");

        return new RuntimeDynamicIntArray(pointer, length, capacity);
    }

    private RuntimeDynamicInlineArray EmitDynamicInlineArrayFunctionCall(BoundFunction function, RuntimeValue? argument, IReadOnlyList<RuntimeValue>? additionalArguments)
    {
        var aggregate = NextTemp("generic_array");
        EmitCall(aggregate, "%sollang.dynamic_int_array", SymbolForFunction(function)[1..],
            FunctionCallArgumentList(function, argument, additionalArguments));
        var pointer = NextTemp("generic_array_ptr");
        EmitAssign(pointer, $"extractvalue %sollang.dynamic_int_array {aggregate}, 0");
        var length = NextTemp("generic_array_len");
        EmitAssign(length, $"extractvalue %sollang.dynamic_int_array {aggregate}, 1");
        var capacity = NextTemp("generic_array_capacity");
        EmitAssign(capacity, $"extractvalue %sollang.dynamic_int_array {aggregate}, 2");
        var definition = _program.Types.GetDynamicArray(function.ReturnType);
        return new RuntimeDynamicInlineArray(function.ReturnType, definition.ElementType,
            pointer, length, capacity);
    }

    private RuntimeIntDictionary EmitIntDictionaryFunctionCall(BoundFunction function, RuntimeValue? argument, IReadOnlyList<RuntimeValue>? additionalArguments)
    {
        var aggregate = NextTemp("dict");
        var arguments = FunctionCallArgumentList(function, argument, additionalArguments);
        EmitCall(aggregate, "%sollang.int_dictionary", SymbolForFunction(function)[1..], arguments);

        var pointer = NextTemp("dict_ptr");
        EmitAssign(pointer, $"extractvalue %sollang.int_dictionary {aggregate}, 0");

        var length = NextTemp("dict_len");
        EmitAssign(length, $"extractvalue %sollang.int_dictionary {aggregate}, 1");

        var capacity = NextTemp("dict_capacity");
        EmitAssign(capacity, $"extractvalue %sollang.int_dictionary {aggregate}, 2");

        return new RuntimeIntDictionary(pointer, length, capacity);
    }

    private RuntimeInlineDictionary EmitInlineDictionaryFunctionCall(BoundFunction function, RuntimeValue? argument, IReadOnlyList<RuntimeValue>? additionalArguments)
    {
        var aggregate = NextTemp("generic_dict");
        EmitCall(aggregate, "%sollang.int_dictionary", SymbolForFunction(function)[1..],
            FunctionCallArgumentList(function, argument, additionalArguments));
        var pointer = NextTemp("generic_dict_ptr");
        EmitAssign(pointer, $"extractvalue %sollang.int_dictionary {aggregate}, 0");
        var length = NextTemp("generic_dict_len");
        EmitAssign(length, $"extractvalue %sollang.int_dictionary {aggregate}, 1");
        var capacity = NextTemp("generic_dict_capacity");
        EmitAssign(capacity, $"extractvalue %sollang.int_dictionary {aggregate}, 2");
        var definition = _program.Types.GetDictionary(function.ReturnType);
        return new RuntimeInlineDictionary(function.ReturnType, definition.KeyType, definition.ValueType,
            pointer, length, capacity);
    }

    private string FunctionCallArgumentList(BoundFunction function, RuntimeValue? argument, IReadOnlyList<RuntimeValue>? additionalArguments = null)
    {
        const string runtimeContext = "ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state";
        var explicitArguments = string.Join(", ", new[]
            {
                _usesAsyncDiagnostics && function.IsAsync
                    ? $"ptr {_currentAsyncDiagnosticHeader}"
                    : string.Empty,
                CaptureFunctionCallArgumentList(function),
                ExplicitFunctionCallArgumentList(function, argument, additionalArguments)
            }
            .Where(static part => part.Length > 0));
        return explicitArguments.Length == 0
            ? runtimeContext
            : $"{runtimeContext}, {explicitArguments}";
    }

    private string CaptureFunctionCallArgumentList(BoundFunction function)
    {
        var arguments = new List<string>();
        foreach (var capture in CapturedBindingsForFunction(function))
        {
            var value = ResolveLocal(capture.Key);
            EnsureRuntimeType(value, capture.Value, function.Name);
            var materialized = MaterializeAggregateValue(value);
            if (CaptureUsesBorrowAbi(capture.Value))
            {
                if (_readonlyCaptureBorrowPointers.TryGetValue(capture.Key, out var existingPointer))
                {
                    arguments.Add($"ptr {existingPointer}");
                    continue;
                }
                var pointer = NextTemp("capture_borrow_arg");
                EmitAlloca(pointer, materialized.TypeName, RuntimeAlignment(capture.Value));
                EmitStore(
                    materialized.TypeName,
                    materialized.ValueName,
                    pointer,
                    RuntimeAlignment(capture.Value));
                // A call-site descriptor may be initialized only in a
                // short-circuit arm. It cannot be reused by later captures or
                // explicit borrows outside that arm. Only entry-bound capture
                // pointers in BindFunctionCaptures dominate every such use.
                arguments.Add($"ptr {pointer}");
                continue;
            }
            arguments.Add($"{materialized.TypeName} {materialized.ValueName}");
        }

        return string.Join(", ", arguments);
    }

    private string ExplicitFunctionCallArgumentList(BoundFunction function, RuntimeValue? argument, IReadOnlyList<RuntimeValue>? additionalArguments)
    {
        var parts = new List<string>();
        var primary = ExplicitPrimaryFunctionCallArgument(function, argument);
        if (primary.Length > 0)
        {
            parts.Add(primary);
        }

        var parameters = function.AdditionalParameters ?? [];
        additionalArguments ??= [];
        if (additionalArguments.Count != parameters.Count)
        {
            throw new SollangException(
                $"function '{function.Name}' expects {parameters.Count} additional argument(s)");
        }
        for (var index = 0; index < parameters.Count; index++)
        {
            var parameter = parameters[index];
            var value = additionalArguments[index];
            if (value is RuntimeFormattedText or RuntimeTextChoice && parameter.Type == BoundType.Text)
            {
                value = EmitTransientText(value);
            }
            EnsureFunctionArgumentRuntimeType(value, parameter.Type, function.Name);
            if (parameter.Ownership == BoundFunctionInputOwnership.MutableBorrow)
            {
                if (IsStaticArrayRuntimeValue(value, parameter.Type))
                {
                    parts.Add(BuildStaticArrayArgument(parameter.Type, value, function.Name));
                    continue;
                }
                parts.Add(value switch
                {
                    RuntimeMutableStructReference reference => $"ptr {reference.PointerAddress}",
                    RuntimeMutableContainerReference reference => BuildMutableContainerArgument(reference),
                    _ => throw new SollangException(
                        $"function '{function.Name}' parameter '{parameter.Name}' requires a mutable borrow")
                });
                continue;
            }
            if (_program.Types.IsReference(parameter.Type))
            {
                if (value is not RuntimeReference reference || reference.Type != parameter.Type)
                {
                    throw new SollangException(
                        $"function '{function.Name}' parameter '{parameter.Name}' requires {parameter.Type}");
                }
                parts.Add($"ptr {reference.PointerName}");
                continue;
            }
            if (_program.Types.IsSlice(parameter.Type))
            {
                parts.Add(BuildReadonlySliceArgument(parameter.Type, value, function.Name));
                continue;
            }
            if (_program.Types.IsStaticArray(parameter.Type))
            {
                parts.Add(BuildStaticArrayArgument(parameter.Type, value, function.Name));
                continue;
            }
            var materialized = MaterializeAggregateValue(value);
            parts.Add($"{materialized.TypeName} {materialized.ValueName}");
        }
        return string.Join(", ", parts);
    }

    private string ExplicitPrimaryFunctionCallArgument(BoundFunction function, RuntimeValue? argument)
    {
        if (function.InputType is null)
        {
            if (argument is not null)
            {
                throw new SollangException($"function '{function.Name}' does not accept arguments");
            }

            return "";
        }

        if (argument is null)
        {
            throw new SollangException($"function '{function.Name}' expects exactly one argument");
        }

        if (argument is RuntimeFormattedText or RuntimeTextChoice && function.InputType == BoundType.Text)
        {
            argument = EmitTransientText(argument);
        }

        if (function.IsAsync)
        {
            EnsureFunctionArgumentRuntimeType(argument, function.InputType.Value, function.Name);
            var value = MaterializeAsyncResult(argument);
            return $"{value.TypeName} {value.ValueName}";
        }

        if (function.HasValueGenericFixedArrayInput)
        {
            var (pointer, length, actualType, knownLength) = argument switch
            {
                RuntimeStaticIntArray array => (
                    array.PointerName,
                    array.LengthName,
                    array.Type,
                    int.TryParse(array.LengthName, out var intLength) ? intLength : (int?)null),
                RuntimeStaticTextArray array => (
                    array.PointerName,
                    array.LengthName,
                    array.Type,
                    int.TryParse(array.LengthName, out var textLength) ? textLength : (int?)null),
                RuntimeStaticInlineArray array => (
                    array.PointerName,
                    array.LengthName,
                    array.ArrayType,
                    (int?)array.Length),
                _ => throw new SollangException(
                    $"value-generic function '{function.Name}' requires a fixed array input")
            };
            if (function.InputType != actualType
                && !(_program.Types.IsStaticArray(function.InputType!.Value)
                    && _program.Types.IsStaticArray(actualType)
                    && _program.Types.GetStaticArray(function.InputType.Value).ElementType
                        == _program.Types.GetStaticArray(actualType).ElementType))
            {
                throw new SollangException(
                    $"function '{function.Name}' expects {function.InputType!.Value} "
                    + $"but received {actualType}");
            }
            var declaredLength = _program.Types.IsStaticArray(actualType)
                ? _program.Types.GetStaticArray(actualType).FixedLength
                : null;
            var actualLength = declaredLength ?? knownLength;
            if (function.SpecializedValue is not { } expectedLength
                || actualLength != expectedLength)
            {
                throw new SollangException(
                    $"function '{function.Name}' expects [{StaticArrayElementType(actualType)}; {function.SpecializedValue}] "
                    + $"but received [{StaticArrayElementType(actualType)}; {actualLength?.ToString() ?? length}]");
            }
            return BuildIntSliceArgument(pointer, length);
        }

        if (_program.Types.IsReference(function.InputType.Value))
        {
            if (argument is not RuntimeReference reference || reference.Type != function.InputType.Value)
            {
                throw new SollangException(
                    $"function '{function.Name}' expects {function.InputType.Value} but received {argument.Type}");
            }
            return $"ptr {reference.PointerName}";
        }

        if (argument is RuntimeDynamicInlineArray inlineArray
            && function.InputType == inlineArray.ArrayType)
        {
            return $"%sollang.dynamic_int_array {BuildDynamicArrayAggregate(inlineArray.PointerName, inlineArray.LengthName, inlineArray.CapacityName)}";
        }
        if (argument is RuntimeInlineDictionary inlineDictionary
            && function.InputType == inlineDictionary.DictionaryType)
        {
            return $"%sollang.int_dictionary {BuildDictionaryAggregate(inlineDictionary.PointerName, inlineDictionary.LengthName, inlineDictionary.CapacityName)}";
        }

        if (argument is RuntimeInt numericInteger && function.InputType == numericInteger.Type)
        {
            return $"{LlvmType(numericInteger.Type)} {numericInteger.ValueName}";
        }
        if (argument is RuntimeFloat numericFloat && function.InputType == numericFloat.Type)
        {
            return $"{LlvmType(numericFloat.Type)} {numericFloat.ValueName}";
        }
        if (_program.Types.IsSlice(function.InputType.Value))
        {
            return BuildReadonlySliceArgument(function, argument);
        }
        if (_program.Types.IsStaticArray(function.InputType.Value))
        {
            return BuildStaticArrayArgument(function.InputType.Value, argument, function.Name);
        }

        return argument switch
        {
            RuntimeArguments arguments when function.InputType == BoundType.Arguments =>
                $"i64 {arguments.LengthName}",
            RuntimeText text when function.InputType == BoundType.Text =>
                $"%sollang.text {BuildTextAggregate(text)}",
            RuntimeSourceText source when function.InputType == BoundType.SourceText =>
                $"%sollang.source_text {BuildSourceTextAggregate(source)}",
            RuntimeMappedBytes mapped when function.InputType == mapped.Type =>
                $"%sollang.mapped_bytes {BuildMappedBytesAggregate(mapped)}",
            RuntimeBool boolean when function.InputType == BoundType.Bool => $"i1 {boolean.ValueName}",
            RuntimeIntSlice slice when function.InputType == BoundType.IntSlice => BuildIntSliceArgument(slice.PointerName, slice.LengthName),
            RuntimeStaticIntArray array when function.InputType == BoundType.IntSlice => BuildStaticIntArraySliceArgument(array),
            RuntimeDynamicIntArray array when function.InputType == BoundType.IntSlice => BuildIntSliceArgument(array.PointerName, array.LengthName),
            RuntimeMutableStructReference reference when function.InputOwnership == BoundFunctionInputOwnership.MutableBorrow => $"ptr {reference.PointerAddress}",
            RuntimeMutableContainerReference reference when function.InputOwnership == BoundFunctionInputOwnership.MutableBorrow => BuildMutableContainerArgument(reference),
            RuntimeStaticInlineArray array when function.InputOwnership == BoundFunctionInputOwnership.MutableBorrow
                && _program.Types.IsStaticArray(function.InputType.Value) => BuildIntSliceArgument(array.PointerName, array.LengthName),
            RuntimeStaticInlineArray array when function.InputType == array.ArrayType =>
                BuildIntSliceArgument(array.PointerName, array.LengthName),
            RuntimeDynamicIntArray array when function.InputType == BoundType.DynamicIntArray => BuildDynamicIntArrayArgument(array),
            RuntimeIntDictionaryView dictionary when function.InputType == BoundType.IntDictionaryView => BuildIntDictionaryArgument(dictionary.PointerName, dictionary.LengthName, dictionary.CapacityName),
            RuntimeIntDictionary dictionary when function.InputType == BoundType.IntDictionaryView => BuildIntDictionaryArgument(dictionary.PointerName, dictionary.LengthName, dictionary.CapacityName),
            RuntimeIntDictionary dictionary when function.InputType == BoundType.IntDictionary => BuildIntDictionaryArgument(dictionary),
            RuntimeArena arena when function.InputType == BoundType.Arena =>
                $"%sollang.dynamic_int_array {BuildDynamicArrayAggregate(arena.PointerName, arena.UsedName, arena.CapacityName)}",
            RuntimeStruct structure when function.InputType == structure.Type => $"{LlvmStructType(structure.Type)} {structure.ValueName}",
            RuntimeEnum enumeration when function.InputType == enumeration.Type => $"{LlvmEnumType(enumeration.Type)} {enumeration.ValueName}",
            RuntimeBox box when function.InputType == box.Type => $"ptr {box.PointerName}",
            RuntimeDynTrait dyn when function.InputType == dyn.Type =>
                $"%sollang.dyn {BuildDynTraitAggregate(dyn)}",
            RuntimeProducerStream stream when function.InputType == stream.Type =>
                BuildProducerStreamArgument(stream),
            _ => throw new SollangException($"function '{function.Name}' expects {function.InputType} but received {argument.Type}")
        };
    }

    private string BuildReadonlySliceArgument(BoundFunction function, RuntimeValue argument)
    {
        return BuildReadonlySliceArgument(
            function.InputType!.Value,
            argument,
            function.Name);
    }

    private string BuildReadonlySliceArgument(
        BoundType expectedType,
        RuntimeValue argument,
        string functionName)
    {
        var expectedElement = _program.Types.GetSliceElement(expectedType);
        var (pointer, length, actualElement) = TryGetRuntimeArrayView(argument)
            ?? throw new SollangException(
                $"function '{functionName}' expects a readonly array view but received {argument.Type}");
        if (actualElement != expectedElement)
        {
            throw new SollangException(
                $"function '{functionName}' expects [{expectedElement}] but received an array of {actualElement}");
        }
        return BuildIntSliceArgument(pointer, length);
    }

    private string BuildStaticArrayArgument(
        BoundType expectedType,
        RuntimeValue argument,
        string functionName)
    {
        var expected = _program.Types.GetStaticArray(expectedType);
        var (pointer, length, actualElement, actualArrayType) = argument switch
        {
            RuntimeStaticIntArray array => (array.PointerName, array.LengthName, BoundType.Int, array.ArrayType),
            RuntimeStaticTextArray array => (array.PointerName, array.LengthName, BoundType.Text, array.ArrayType),
            RuntimeStaticInlineArray array => (array.PointerName, array.LengthName, array.ElementType, array.ArrayType),
            _ => throw new SollangException(
                $"function '{functionName}' expects a static array but received {argument.Type}")
        };
        if (actualElement != expected.ElementType)
        {
            throw new SollangException(
                $"function '{functionName}' expects an array of {expected.ElementType} but received {actualElement}");
        }
        int? actualLength = actualArrayType is { } staticArrayType
            && _program.Types.GetStaticArray(staticArrayType).FixedLength is { } typeLength
                ? typeLength
                : int.TryParse(length, out var literalLength)
                    ? literalLength
                    : null;
        if (expected.FixedLength is { } expectedLength && actualLength != expectedLength)
        {
            throw new SollangException(
                $"function '{functionName}' expects [{expected.ElementType}; {expectedLength}] "
                + $"but received length {actualLength?.ToString() ?? length}");
        }
        return BuildIntSliceArgument(pointer, length);
    }

    private string BuildProducerStreamArgument(RuntimeProducerStream stream)
    {
        var materialized = MaterializeAggregateValue(stream);
        return $"{materialized.TypeName} {materialized.ValueName}";
    }

    private BoundType StaticArrayElementType(BoundType arrayType)
    {
        if (arrayType == BoundType.StaticIntArray) return BoundType.Int;
        if (arrayType == BoundType.StaticTextArray) return BoundType.Text;
        return _program.Types.GetStaticArray(arrayType).ElementType;
    }

    private bool IsStaticArrayRuntimeValue(RuntimeValue value, BoundType expectedType) =>
        _program.Types.IsStaticArray(expectedType)
        && _program.Types.IsStaticArray(value.Type)
        && TryGetRuntimeArrayView(value) is not null;

    private RuntimeValue CreateMutableBorrowArgument(
        Expression argument,
        BoundType expectedType,
        string path,
        string parameterName)
    {
        if (argument is not NameExpression name)
        {
            var root = MutableBorrowPlaceRoot(argument);
            if (root is null)
            {
                throw new SollangException(
                    $"function '{path}' mutably borrows a value, so the argument must be a mutable owner place");
            }
            if (!_mutableLocals.Contains(root))
            {
                throw new SollangException(
                    $"function '{path}' mutably borrows a value; use a mutable owner binding such as '{root.TrimEnd('!')}!'");
            }

            var place = EmitReferencePlace(argument);
            if (place.ElementType != expectedType)
            {
                throw new SollangException(
                    $"function '{path}' parameter '{parameterName}' expects {expectedType} but received {place.ElementType}");
            }
            return CreateProjectedMutableBorrowArgument(place, expectedType, path);
        }

        if (!_mutableLocals.Contains(name.Name))
        {
            throw new SollangException($"function '{path}' mutably borrows a value; use a mutable owner binding such as '{name.Name.TrimEnd('!')}!'");
        }

        var value = ResolveLocal(name.Name);
        EnsureRuntimeType(value, expectedType, path);
        if (value is RuntimeBitSet bitSet && _program.Types.IsBitSet(expectedType))
        {
            return new RuntimeMutableStructReference(expectedType, bitSet.PointerName);
        }
        if (IsStaticArrayRuntimeValue(value, expectedType))
        {
            return value;
        }
        if (_mutableStructSlots.TryGetValue(name.Name, out var structPointer))
        {
            return new RuntimeMutableStructReference(expectedType, structPointer);
        }

        if (!_mutableContainerSlots.TryGetValue(name.Name, out var slot))
        {
            throw new SollangException($"mutable owner '{name.Name}' has no addressable storage");
        }

        return new RuntimeMutableContainerReference(
            expectedType,
            slot.PointerAddress,
            slot.LengthAddress,
            slot.CapacityAddress);
    }

    private static string? MutableBorrowPlaceRoot(Expression expression) => expression switch
    {
        NameExpression name => name.Name,
        FieldAccessExpression field => MutableBorrowPlaceRoot(field.Source),
        IndexExpression index => MutableBorrowPlaceRoot(index.Source),
        _ => null
    };

    private RuntimeValue CreateProjectedMutableBorrowArgument(
        RuntimeReference place,
        BoundType expectedType,
        string path)
    {
        if (_program.Types.IsStruct(expectedType) || _program.Types.IsBitSet(expectedType))
        {
            return new RuntimeMutableStructReference(expectedType, place.PointerName);
        }

        if (_program.Types.IsStaticArray(expectedType))
        {
            var definition = _program.Types.GetStaticArray(expectedType);
            var pointerAddress = NextTemp("mut_field_ptr_addr");
            EmitAssign(
                pointerAddress,
                $"getelementptr inbounds %sollang.int_slice, ptr {place.PointerName}, i32 0, i32 0");
            var pointer = NextTemp("mut_field_ptr");
            EmitLoad(pointer, "ptr", pointerAddress, RuntimeAlignment(expectedType));
            var lengthAddress = NextTemp("mut_field_len_addr");
            EmitAssign(
                lengthAddress,
                $"getelementptr inbounds %sollang.int_slice, ptr {place.PointerName}, i32 0, i32 1");
            var length = NextTemp("mut_field_len");
            EmitLoad(length, "i64", lengthAddress, 8);
            return new RuntimeStaticInlineArray(
                expectedType,
                definition.ElementType,
                pointer,
                length,
                definition.FixedLength ?? 0,
                definition.FixedLength ?? 0);
        }

        if (_program.Types.IsBoundedArray(expectedType))
        {
            var definition = _program.Types.GetBoundedArray(expectedType);
            var llvmType = LlvmBoundedArrayType(expectedType);
            var lengthAddress = NextTemp("mut_field_len_addr");
            EmitAssign(
                lengthAddress,
                $"getelementptr inbounds {llvmType}, ptr {place.PointerName}, i32 0, i32 0");
            var pointer = NextTemp("mut_field_data");
            EmitAssign(
                pointer,
                $"getelementptr inbounds {llvmType}, ptr {place.PointerName}, i32 0, i32 1, i64 0");

            // The borrow ABI uses addresses of descriptor components. Bounded
            // values store their length and elements inline, so only the data
            // pointer and constant capacity need temporary descriptor slots.
            var pointerAddress = NextTemp("mut_field_ptr_addr");
            EmitAlloca(pointerAddress, "ptr", 8);
            EmitStore("ptr", pointer, pointerAddress, 8);
            var capacityAddress = NextTemp("mut_field_cap_addr");
            EmitAlloca(capacityAddress, "i64", 8);
            EmitStore("i64", definition.Capacity.ToString(CultureInfo.InvariantCulture), capacityAddress, 8);
            return new RuntimeMutableContainerReference(
                expectedType,
                pointerAddress,
                lengthAddress,
                capacityAddress);
        }

        if (expectedType is BoundType.DynamicIntArray or BoundType.IntDictionary or BoundType.Arena
            || _program.Types.IsDynamicArray(expectedType)
            || _program.Types.IsDictionary(expectedType))
        {
            var llvmType = LlvmType(expectedType);
            var pointerAddress = NextTemp("mut_field_ptr_addr");
            EmitAssign(
                pointerAddress,
                $"getelementptr inbounds {llvmType}, ptr {place.PointerName}, i32 0, i32 0");
            var lengthAddress = NextTemp("mut_field_len_addr");
            EmitAssign(
                lengthAddress,
                $"getelementptr inbounds {llvmType}, ptr {place.PointerName}, i32 0, i32 1");
            var capacityAddress = NextTemp("mut_field_cap_addr");
            EmitAssign(
                capacityAddress,
                $"getelementptr inbounds {llvmType}, ptr {place.PointerName}, i32 0, i32 2");
            return new RuntimeMutableContainerReference(
                expectedType,
                pointerAddress,
                lengthAddress,
                capacityAddress);
        }

        throw new SollangException(
            $"function '{path}' does not support a projected mutable borrow of {expectedType}");
    }

    private RuntimeReference CreateReadonlyReferenceArgument(
        Expression expression,
        BoundType referenceType,
        string path)
    {
        var elementType = _program.Types.GetReference(referenceType).ElementType;
        if (expression is not NameExpression)
        {
            var place = EmitReferencePlace(expression);
            if (place.ElementType != elementType)
            {
                throw new SollangException(
                    $"function '{path}' expects a reference to {elementType} but received {place.ElementType}");
            }
            return new RuntimeReference(referenceType, elementType, place.PointerName);
        }

        var name = (NameExpression)expression;
        if (!_locals.TryGetValue(name.Name, out var stored))
        {
            throw new SollangException(
                $"function '{path}' requires a named addressable owner or reference");
        }
        if (stored is RuntimeReference reference)
        {
            if (reference.ElementType != elementType)
            {
                throw new SollangException(
                    $"function '{path}' expects a reference to {elementType} but received {reference.ElementType}");
            }
            return new RuntimeReference(referenceType, elementType, reference.PointerName);
        }
        if (stored.Type != elementType)
        {
            throw new SollangException(
                $"function '{path}' expects a reference to {elementType} but received {stored.Type}");
        }
        if (_mutableStructSlots.TryGetValue(name.Name, out var mutablePointer))
        {
            return new RuntimeReference(referenceType, elementType, mutablePointer);
        }
        if (_mutableScalarSlots.TryGetValue(name.Name, out var scalarPointer))
        {
            return new RuntimeReference(referenceType, elementType, scalarPointer);
        }
        if (_mutableContainerSlots.ContainsKey(name.Name))
        {
            var current = LoadMutableContainer(name.Name, stored);
            var currentPointer = GetOrCreateReadonlyValuePointer(current, "ref_arg");
            return new RuntimeReference(referenceType, elementType, currentPointer);
        }
        if (_readonlyCaptureBorrowPointers.TryGetValue(name.Name, out var capturePointer))
        {
            return new RuntimeReference(referenceType, elementType, capturePointer);
        }

        var pointer = GetOrCreateReadonlyValuePointer(stored, "ref_arg");
        return new RuntimeReference(referenceType, elementType, pointer);
    }

    private string GetOrCreateReadonlyValuePointer(RuntimeValue value, string temporaryPrefix)
    {
        if (_readonlyValueSlots.TryGetValue(value, out var existing))
        {
            // The aggregate SSA value may be produced inside a loop and its
            // first borrow may occur in only one control-flow arm.  Reusing a
            // lazily materialized slot without refreshing it leaves sibling
            // arms and later iterations observing the previous value.
            var refreshed = MaterializeAggregateValue(value);
            EmitStore(
                refreshed.TypeName,
                refreshed.ValueName,
                existing,
                RuntimeAlignment(value.Type));
            return existing;
        }

        var materialized = MaterializeAggregateValue(value);
        var pointer = NextTemp(temporaryPrefix);
        EmitAlloca(pointer, materialized.TypeName, RuntimeAlignment(value.Type));
        EmitStore(
            materialized.TypeName,
            materialized.ValueName,
            pointer,
            RuntimeAlignment(value.Type));
        _readonlyValueSlots.Add(value, pointer);
        return pointer;
    }

    private void BindInlineMutableBorrowFunctionParameter(BoundFunction function, RuntimeValue argument)
    {
        BindInlineMutableBorrowFunctionParameter(
            function.InputName ?? "it",
            function.InputType!.Value,
            argument,
            function.Name);
    }

    private void BindInlineFunctionParameters(
        BoundFunction function,
        RuntimeValue? argument,
        IReadOnlyList<RuntimeValue>? additionalArguments)
    {
        if (function.InputType is null)
        {
            if (argument is not null)
            {
                throw new SollangException($"function '{function.Name}' does not accept arguments");
            }
        }
        else
        {
            if (argument is null)
            {
                throw new SollangException($"function '{function.Name}' expects exactly one argument");
            }

            EnsureFunctionArgumentRuntimeType(argument, function.InputType.Value, function.Name);
            var inputName = function.InputName ?? "it";
            ClearShadowedLocalBinding(inputName);
            if (function.InputOwnership == BoundFunctionInputOwnership.MutableBorrow)
            {
                BindInlineMutableBorrowFunctionParameter(function, argument);
            }
            else
            {
                _locals[inputName] = _program.Types.IsSlice(function.InputType.Value)
                    ? CreateRuntimeSlice(function.InputType.Value, argument)
                    : function.InputType switch
                {
                    BoundType.IntSlice => CreateRuntimeIntSlice(argument),
                    BoundType.IntDictionaryView => CreateRuntimeIntDictionaryView(argument),
                    _ => argument
                };
                if (function.InputOwnership == BoundFunctionInputOwnership.Default
                    && _program.Types.ContainsOwnedStorage(function.InputType.Value))
                {
                    _borrowedOwnedLocals.Add(inputName);
                }
            }
        }

        var parameters = function.AdditionalParameters ?? [];
        additionalArguments ??= [];
        if (parameters.Count != additionalArguments.Count)
        {
            throw new SollangException(
                $"function '{function.Name}' expects {parameters.Count} additional argument(s)");
        }
        for (var index = 0; index < parameters.Count; index++)
        {
            var parameter = parameters[index];
            var parameterValue = additionalArguments[index];
            EnsureFunctionArgumentRuntimeType(parameterValue, parameter.Type, function.Name);
            ClearShadowedLocalBinding(parameter.Name);
            if (parameter.Ownership == BoundFunctionInputOwnership.MutableBorrow)
            {
                BindInlineMutableBorrowFunctionParameter(
                    parameter.Name, parameter.Type, parameterValue, function.Name);
                continue;
            }

            _locals[parameter.Name] = _program.Types.IsSlice(parameter.Type)
                ? CreateRuntimeSlice(parameter.Type, parameterValue)
                : parameter.Type switch
            {
                BoundType.IntSlice => CreateRuntimeIntSlice(parameterValue),
                BoundType.IntDictionaryView => CreateRuntimeIntDictionaryView(parameterValue),
                _ => parameterValue
            };
            if (parameter.Ownership == BoundFunctionInputOwnership.Default
                && _program.Types.ContainsOwnedStorage(parameter.Type))
            {
                _borrowedOwnedLocals.Add(parameter.Name);
            }
        }
    }

    private void BindInlineMutableBorrowFunctionParameter(
        string name,
        BoundType type,
        RuntimeValue argument,
        string functionName)
    {
        if (argument is RuntimeMutableStructReference structReference)
        {
            if (_program.Types.IsBitSet(type))
            {
                BindMutableBitSetFunctionParameter(name, type, structReference.PointerAddress);
                return;
            }
            if (_program.Types.IsStaticArray(type))
            {
                throw new SollangException(
                    $"internal mutable-borrow classification error: function '{functionName}' parameter '{name}' " +
                    $"received a struct reference for fixed array type id {(int)type}");
            }
            _locals[name] = new RuntimeStruct(structReference.TargetType, "");
            _mutableLocals.Add(name);
            _borrowedMutableLocals.Add(name);
            _mutableStructSlots[name] = structReference.PointerAddress;
            return;
        }

        if (argument is not RuntimeMutableContainerReference reference)
        {
            if (IsStaticArrayRuntimeValue(argument, type))
            {
                _locals[name] = argument;
                _mutableLocals.Add(name);
                _borrowedMutableLocals.Add(name);
                _borrowedOwnedLocals.Add(name);
                return;
            }
            throw new SollangException($"function '{functionName}' expects a mutable borrow argument");
        }

        _locals[name] = type switch
        {
            BoundType.DynamicIntArray => new RuntimeDynamicIntArray("", "", ""),
            _ when _program.Types.IsDynamicArray(reference.TargetType)
                || _program.Types.IsBoundedArray(reference.TargetType) => CreateEmptyRuntimeDynamicInlineArray(reference.TargetType),
            BoundType.IntDictionary => new RuntimeIntDictionary("", "", ""),
            BoundType.Arena => new RuntimeArena("", "", ""),
            _ when _program.Types.IsDictionary(reference.TargetType) => CreateEmptyRuntimeInlineDictionary(reference.TargetType),
            _ => throw new SollangException("unsupported mutable borrow input type")
        };
        _mutableLocals.Add(name);
        _borrowedMutableLocals.Add(name);
        _mutableContainerSlots[name] = new MutableContainerSlot(
            reference.PointerAddress,
            reference.LengthAddress,
            reference.CapacityAddress,
            StackAllocation: null);
    }

    private void ClearShadowedLocalBinding(string name)
    {
        // Inline calls share the emitter's local dictionaries with their caller.
        // A parameter may therefore shadow a caller binding with the same name.
        // Clear all name-keyed storage metadata before installing the parameter;
        // RestoreLocals reinstates the captured caller state after the call.
        _locals.Remove(name);
        _mutableLocals.Remove(name);
        _borrowedMutableLocals.Remove(name);
        _borrowedOwnedLocals.Remove(name);
        _mutableContainerSlots.Remove(name);
        _mutableStructSlots.Remove(name);
        _mutableScalarSlots.Remove(name);
        _readonlyCaptureBorrowPointers.Remove(name);
    }

    private string BuildMutableContainerArgument(RuntimeMutableContainerReference reference)
    {
        var aggregate0 = NextTemp("mutable_arg");
        EmitAssign(aggregate0, $"insertvalue %sollang.mutable_container poison, ptr {reference.PointerAddress}, 0");
        var aggregate1 = NextTemp("mutable_arg");
        EmitAssign(aggregate1, $"insertvalue %sollang.mutable_container {aggregate0}, ptr {reference.LengthAddress}, 1");
        var aggregate2 = NextTemp("mutable_arg");
        EmitAssign(aggregate2, $"insertvalue %sollang.mutable_container {aggregate1}, ptr {reference.CapacityAddress}, 2");
        return $"%sollang.mutable_container {aggregate2}";
    }

    private string BuildStaticIntArraySliceArgument(RuntimeStaticIntArray array)
    {
        var pointer = NextTemp("slice_ptr");
        EmitAssign(pointer, $"getelementptr inbounds [{array.AllocatedLength.ToString(CultureInfo.InvariantCulture)} x i32], ptr {array.PointerName}, i64 0, i64 0");
        return BuildIntSliceArgument(pointer, array.LengthName);
    }

    private RuntimeIntSlice CreateRuntimeIntSlice(RuntimeValue value)
    {
        if (value is RuntimeStaticIntArray array)
        {
            return CreateRuntimeIntSlice(array);
        }
        var view = TryGetRuntimeArrayView(value);
        if (view is not { Element: var element } || element != BoundType.Int)
        {
            throw new SollangException($"expected Int array view but received {value.Type}");
        }
        return new RuntimeIntSlice(view.Value.Pointer, view.Value.Length);
    }

    private RuntimeIntSlice CreateRuntimeIntSlice(RuntimeStaticIntArray array)
    {
        var pointer = NextTemp("slice_ptr");
        EmitAssign(pointer, $"getelementptr inbounds [{array.AllocatedLength.ToString(CultureInfo.InvariantCulture)} x i32], ptr {array.PointerName}, i64 0, i64 0");
        return new RuntimeIntSlice(pointer, array.LengthName);
    }

    // One runtime-shape authority for argument validation, direct-call ABI, and
    // flow/inlined view construction. A view always reuses the owner's storage.
    private static (string Pointer, string Length, BoundType Element)? TryGetRuntimeArrayView(RuntimeValue value) =>
        value switch
        {
            RuntimeIntSlice slice => (slice.PointerName, slice.LengthName, BoundType.Int),
            RuntimeInlineSlice slice => (slice.PointerName, slice.LengthName, slice.ElementType),
            RuntimeStaticIntArray array => (array.PointerName, array.LengthName, BoundType.Int),
            RuntimeStaticTextArray array => (array.PointerName, array.LengthName, BoundType.Text),
            RuntimeStaticInlineArray array => (array.PointerName, array.LengthName, array.ElementType),
            RuntimeDynamicIntArray array => (array.PointerName, array.LengthName, BoundType.Int),
            RuntimeDynamicInlineArray array => (array.PointerName, array.LengthName, array.ElementType),
            _ => null
        };

    private RuntimeValue CreateRuntimeSlice(BoundType sliceType, RuntimeValue value)
    {
        if (sliceType == BoundType.IntSlice)
        {
            return CreateRuntimeIntSlice(value);
        }
        var elementType = _program.Types.GetSliceElement(sliceType);
        var (pointer, length, actualElement) = TryGetRuntimeArrayView(value)
            ?? throw new SollangException("readonly array view requires an array value");
        if (actualElement != elementType)
        {
            throw new SollangException("readonly array view element type mismatch");
        }
        return new RuntimeInlineSlice(sliceType, elementType, pointer, length);
    }

    private static RuntimeIntDictionaryView CreateRuntimeIntDictionaryView(RuntimeValue value)
    {
        return value switch
        {
            RuntimeIntDictionaryView view => view,
            RuntimeIntDictionary dictionary => new RuntimeIntDictionaryView(
                dictionary.PointerName,
                dictionary.LengthName,
                dictionary.CapacityName),
            _ => throw new SollangException($"expected Int dictionary view but received {value.Type}")
        };
    }

    private string BuildIntSliceArgument(string pointer, string length)
    {
        var aggregate0 = NextTemp("slice_arg");
        EmitAssign(aggregate0, $"insertvalue %sollang.int_slice poison, ptr {pointer}, 0");
        var aggregate1 = NextTemp("slice_arg");
        EmitAssign(aggregate1, $"insertvalue %sollang.int_slice {aggregate0}, i64 {length}, 1");
        return $"%sollang.int_slice {aggregate1}";
    }

    private string BuildDynamicIntArrayArgument(RuntimeDynamicIntArray array)
    {
        var aggregate0 = NextTemp("array_arg");
        EmitAssign(aggregate0, $"insertvalue %sollang.dynamic_int_array poison, ptr {array.PointerName}, 0");
        var aggregate1 = NextTemp("array_arg");
        EmitAssign(aggregate1, $"insertvalue %sollang.dynamic_int_array {aggregate0}, i64 {array.LengthName}, 1");
        var aggregate2 = NextTemp("array_arg");
        EmitAssign(aggregate2, $"insertvalue %sollang.dynamic_int_array {aggregate1}, i64 {array.CapacityName}, 2");
        return $"%sollang.dynamic_int_array {aggregate2}";
    }

    private string BuildDynamicArrayAggregate(string pointer, string length, string capacity)
    {
        var aggregate0 = NextTemp("generic_array_value");
        EmitAssign(aggregate0, $"insertvalue %sollang.dynamic_int_array poison, ptr {pointer}, 0");
        var aggregate1 = NextTemp("generic_array_value");
        EmitAssign(aggregate1, $"insertvalue %sollang.dynamic_int_array {aggregate0}, i64 {length}, 1");
        var aggregate2 = NextTemp("generic_array_value");
        EmitAssign(aggregate2, $"insertvalue %sollang.dynamic_int_array {aggregate1}, i64 {capacity}, 2");
        return aggregate2;
    }

    private RuntimeDynamicInlineArray CreateEmptyRuntimeDynamicInlineArray(BoundType type)
    {
        var elementType = _program.Types.IsBoundedArray(type)
            ? _program.Types.GetBoundedArray(type).ElementType
            : _program.Types.GetDynamicArray(type).ElementType;
        return new RuntimeDynamicInlineArray(
            type, elementType, "", "", "",
            _program.Types.IsBoundedArray(type)
                ? RuntimeContainerStorage.Stack
                : RuntimeContainerStorage.Heap);
    }

    private string BuildIntDictionaryArgument(RuntimeIntDictionary dictionary)
    {
        return BuildIntDictionaryArgument(
            dictionary.PointerName,
            dictionary.LengthName,
            dictionary.CapacityName);
    }

    private string BuildIntDictionaryArgument(string pointer, string length, string capacity)
    {
        var aggregate0 = NextTemp("dict_arg");
        EmitAssign(aggregate0, $"insertvalue %sollang.int_dictionary poison, ptr {pointer}, 0");
        var aggregate1 = NextTemp("dict_arg");
        EmitAssign(aggregate1, $"insertvalue %sollang.int_dictionary {aggregate0}, i64 {length}, 1");
        var aggregate2 = NextTemp("dict_arg");
        EmitAssign(aggregate2, $"insertvalue %sollang.int_dictionary {aggregate1}, i64 {capacity}, 2");
        return $"%sollang.int_dictionary {aggregate2}";
    }

    private RuntimeInlineDictionary CreateEmptyRuntimeInlineDictionary(BoundType type)
    {
        var definition = _program.Types.GetDictionary(type);
        return new RuntimeInlineDictionary(type, definition.KeyType, definition.ValueType, "", "", "");
    }

    private void RemoveOwnedParameterArgumentsIfNeeded(
        BoundFunction function,
        IReadOnlyList<Expression> arguments,
        int additionalArgumentOffset)
    {
        if (FunctionConsumesOwnedHeapInput(function)
            && function.InputType is not null
            && additionalArgumentOffset > 0)
        {
            if (arguments[0] is NameExpression primaryName)
            {
                RemoveLocal(primaryName.Name);
            }
            else
            {
                ConsumeOwnedFieldProjection(arguments[0], function.InputType.Value);
            }
        }

        var parameters = function.AdditionalParameters ?? [];
        for (var index = 0; index < parameters.Count; index++)
        {
            if (parameters[index].Ownership != BoundFunctionInputOwnership.Move)
            {
                continue;
            }

            var argument = arguments[additionalArgumentOffset + index];
            if (argument is NameExpression name)
            {
                RemoveLocal(name.Name);
            }
            else
            {
                ConsumeOwnedFieldProjection(argument, parameters[index].Type);
            }
        }
    }

    private void RemoveOwnedParameterFlowArgumentsIfNeeded(
        BoundFunction function,
        Expression source,
        IReadOnlyList<Expression> additionalArguments,
        bool receivesSourcePlace)
    {
        // Subsequent flow edges receive an already emitted temporary. Moving
        // that result must not remove the original expression's named place.
        if (receivesSourcePlace && FunctionConsumesOwnedHeapInput(function))
        {
            if (source is NameExpression primaryName)
            {
                RemoveLocal(primaryName.Name);
            }
            else
            {
                ConsumeOwnedFieldProjection(source, function.InputType!.Value);
            }
        }

        var parameters = function.AdditionalParameters ?? [];
        for (var index = 0; index < parameters.Count; index++)
        {
            if (parameters[index].Ownership != BoundFunctionInputOwnership.Move)
            {
                continue;
            }

            var argument = additionalArguments[index];
            if (argument is NameExpression name)
            {
                RemoveLocal(name.Name);
            }
            else
            {
                ConsumeOwnedFieldProjection(argument, parameters[index].Type);
            }
        }
    }

    private static bool FunctionConsumesOwnedHeapInput(BoundFunction function)
    {
        return function.InputOwnership == BoundFunctionInputOwnership.Move
            && function.InputType is not null;
    }

    private void EnsureRuntimeType(RuntimeValue value, BoundType expected, string path)
    {
        if (value.Type != expected)
        {
            var expectedIdentity = SemanticStableIdentity.Type(_program.Types, expected);
            var actualIdentity = SemanticStableIdentity.Type(_program.Types, value.Type);
            throw new SollangException(
                $"function '{path}' expects {expectedIdentity} ({expected}) "
                + $"but received {actualIdentity} ({value.Type})");
        }
    }

    private void EnsureFunctionArgumentRuntimeType(RuntimeValue value, BoundType expected, string path)
    {
        if (_program.Types.IsReference(expected)
            && value is RuntimeReference reference
            && (reference.Type == expected
                || SemanticStableIdentity.Type(_program.Types, reference.ElementType)
                    == SemanticStableIdentity.Type(
                        _program.Types,
                        _program.Types.GetReference(expected).ElementType)))
        {
            return;
        }
        if (expected == BoundType.IntSlice
            && value.Type is BoundType.IntSlice or BoundType.StaticIntArray or BoundType.DynamicIntArray)
        {
            return;
        }
        if (_program.Types.IsSlice(expected))
        {
            var expectedElement = _program.Types.GetSliceElement(expected);
            var actualElement = TryGetRuntimeArrayView(value)?.Element;
            if (actualElement == expectedElement)
            {
                return;
            }
        }

        if (expected == BoundType.IntDictionaryView
            && value.Type is BoundType.IntDictionaryView or BoundType.IntDictionary)
        {
            return;
        }

        EnsureRuntimeType(value, expected, path);
    }

    private bool TryGetRuntimePrinterKind(BoundFunction function, out BoundFunctionKind kind)
    {
        if (function.Kind is BoundFunctionKind.RuntimePrint
            or BoundFunctionKind.RuntimePrintLine
            or BoundFunctionKind.RuntimePrintError
            or BoundFunctionKind.RuntimePrintErrorLine)
        {
            kind = function.Kind;
            return true;
        }

        if (TryGetRuntimeWrapperKind(function, out kind)
            && kind is BoundFunctionKind.RuntimePrint
                or BoundFunctionKind.RuntimePrintLine
                or BoundFunctionKind.RuntimePrintError
                or BoundFunctionKind.RuntimePrintErrorLine)
        {
            return true;
        }

        kind = default;
        return false;
    }

    private bool TryGetRuntimeWrapperKind(BoundFunction function, out BoundFunctionKind kind)
    {
        if (!function.IsStandardLibrary
            || function.Body is not FlowExpression flow
            || flow.Source is not NameExpression name
            || name.Name != (function.InputName ?? "it")
            || flow.Targets.Count != 1
            || !TryResolveFunction(flow.Targets[0].Path, out var target))
        {
            kind = default;
            return false;
        }

        if (target.Kind is BoundFunctionKind.RuntimePrint
            or BoundFunctionKind.RuntimePrintLine
            or BoundFunctionKind.RuntimePrintError
            or BoundFunctionKind.RuntimePrintErrorLine
            or BoundFunctionKind.RuntimeReadInt
            or BoundFunctionKind.RuntimeSeedRandom
            or BoundFunctionKind.RuntimeRandomBelow
            or BoundFunctionKind.RuntimeSecureRandomBytes
            or BoundFunctionKind.RuntimeOpenIntWriter
            or BoundFunctionKind.RuntimeWriteInt
            or BoundFunctionKind.RuntimeOpenIntReader
            or BoundFunctionKind.RuntimeClosestInt)
        {
            kind = target.Kind;
            return true;
        }

        kind = default;
        return false;
    }

    private void CollectStandaloneStandardLibraryFunctions()
    {
        var visited = new HashSet<BoundFunction>(ReferenceEqualityComparer.Instance);
        ScanStatementsForStandaloneStandardLibraryFunctions(
            _program.MainStatements,
            _program.Functions,
            caller: null,
            visited);

        if (!_sharedLibrary)
        {
            return;
        }

        foreach (var function in EnumerateEmittableFunctions(_program.Functions.Values)
                     .Where(function => !function.IsStandardLibrary && function.IsPublic))
        {
            ScanFunctionForStandaloneStandardLibraryFunctions(function, visited);
        }
    }

    private void CollectReachableDictionaryTraitFunctions()
    {
        var scanned = new HashSet<BoundFunction>(_reachableFunctions, ReferenceEqualityComparer.Instance);
        while (true)
        {
            var keyTypes = new HashSet<BoundType>();
            CollectDictionaryKeyTypes(_program.MainBindings.Values, keyTypes);
            foreach (var reachable in _reachableFunctions.ToArray())
            {
                if (reachable.InputType is { } inputType)
                {
                    CollectDictionaryKeyTypes([inputType], keyTypes);
                }
                CollectDictionaryKeyTypes([reachable.ReturnType], keyTypes);
                CollectDictionaryKeyTypes(
                    (reachable.AdditionalParameters ?? []).Select(static parameter => parameter.Type),
                    keyTypes);
                if (_program.FunctionBindings.TryGetValue(reachable, out var bindings))
                {
                    CollectDictionaryKeyTypes(bindings.Values, keyTypes);
                }
            }

            var dependencies = EnumerateEmittableFunctions(_program.Functions.Values)
                .Where(function => function.Kind == BoundFunctionKind.User
                    && function.InputType is { } inputType
                    && keyTypes.Contains(inputType)
                    && function.TraitName is { } traitName
                    && (traitName == "Hash"
                        || traitName.EndsWith(".Hash", StringComparison.Ordinal)
                        || traitName == "Eq"
                        || traitName.EndsWith(".Eq", StringComparison.Ordinal)))
                .Where(function => !_reachableFunctions.Contains(function))
                .ToArray();
            if (dependencies.Length == 0)
            {
                return;
            }
            foreach (var dependency in dependencies)
            {
                ScanFunctionForStandaloneStandardLibraryFunctions(dependency, scanned);
            }
        }
    }

    private void CollectDictionaryKeyTypes(
        IEnumerable<BoundType> types,
        HashSet<BoundType> keyTypes)
    {
        foreach (var type in types)
        {
            if (_program.Types.IsDictionary(type))
            {
                keyTypes.Add(_program.Types.GetDictionary(type).KeyType);
            }
        }
    }

    private void ScanFunctionForStandaloneStandardLibraryFunctions(
        BoundFunction function,
        HashSet<BoundFunction> visited)
    {
        if (!visited.Add(function))
        {
            return;
        }

        _reachableFunctions.Add(function);
        if (!_activeStandardLibraryFunctionScans.Add(function))
        {
            return;
        }
        try
        {
            var scope = FunctionScope(function);
            ScanStatementsForStandaloneStandardLibraryFunctions(function.BlockBody, scope, function, visited);
            if (function.Body is not null)
            {
                ScanExpressionForStandaloneStandardLibraryFunctions(function.Body, scope, function, visited);
            }
        }
        finally
        {
            _activeStandardLibraryFunctionScans.Remove(function);
        }
    }

    private void ScanStatementsForStandaloneStandardLibraryFunctions(
        IEnumerable<Statement> statements,
        IReadOnlyDictionary<string, BoundFunction> scope,
        BoundFunction? caller,
        HashSet<BoundFunction> visited)
    {
        foreach (var statement in statements)
        {
            switch (statement)
            {
                case BindingStatement binding:
                    ScanExpressionForStandaloneStandardLibraryFunctions(binding.Value, scope, caller, visited);
                    break;
                case IndexAssignmentStatement assignment:
                    ScanExpressionForStandaloneStandardLibraryFunctions(assignment.Index, scope, caller, visited);
                    ScanExpressionForStandaloneStandardLibraryFunctions(assignment.Value, scope, caller, visited);
                    break;
                case FieldAssignmentStatement assignment:
                    ScanExpressionForStandaloneStandardLibraryFunctions(assignment.Value, scope, caller, visited);
                    break;
                case BlockFunctionCallStatement block:
                    ScanExpressionForStandaloneStandardLibraryFunctions(block.Source, scope, caller, visited);
                    ScanStatementsForStandaloneStandardLibraryFunctions(block.Body, scope, caller, visited);
                    break;
                case BlockFunctionPipelineStatement pipeline:
                    foreach (var block in pipeline.Calls)
                    {
                        ScanExpressionForStandaloneStandardLibraryFunctions(block.Source, scope, caller, visited);
                        ScanStatementsForStandaloneStandardLibraryFunctions(block.Body, scope, caller, visited);
                    }
                    break;
                case ExpressionStatement expression:
                    ScanExpressionForStandaloneStandardLibraryFunctions(expression.Expression, scope, caller, visited);
                    break;
                case GuardLoopControlStatement guard:
                    ScanExpressionForStandaloneStandardLibraryFunctions(guard.Condition, scope, caller, visited);
                    break;
                case ReturnStatement { Value: { } value }:
                    ScanExpressionForStandaloneStandardLibraryFunctions(value, scope, caller, visited);
                    break;
            }
        }
    }

    private void ScanBlockForStandaloneStandardLibraryFunctions(
        BlockBody? block,
        IReadOnlyDictionary<string, BoundFunction> scope,
        BoundFunction? caller,
        HashSet<BoundFunction> visited)
    {
        if (block is null)
        {
            return;
        }

        ScanStatementsForStandaloneStandardLibraryFunctions(block.Statements, scope, caller, visited);
        if (block.Value is not null)
        {
            ScanExpressionForStandaloneStandardLibraryFunctions(block.Value, scope, caller, visited);
        }
    }

    private void ScanExpressionForStandaloneStandardLibraryFunctions(
        Expression expression,
        IReadOnlyDictionary<string, BoundFunction> scope,
        BoundFunction? caller,
        HashSet<BoundFunction> visited)
    {
        void RecordTarget(
            object callSite,
            IReadOnlyList<string> path,
            BoundType? receiverType = null)
        {
            BoundFunction? target = null;
            if (_program.DynTraitConversions.TryGetValue(callSite, out var conversion))
            {
                if (_reachableDynTraitConversions.Add(conversion))
                {
                    foreach (var method in conversion.Methods)
                    {
                        RecordTarget(method, CanonicalFunctionName(method).Split('.'));
                    }
                }
                return;
            }
            // A semantic generic resolution is more specific than a lexical
            // receiver lookup. Preserve that specialization so control-flow
            // facts such as early returns select the same standalone function
            // later used by emission.
            if (callSite is BoundFunction declaredFunction)
            {
                target = declaredFunction;
            }
            else if (_program.ResolvedGenericCalls.TryGetValue(callSite, out var generic))
            {
                target = generic;
            }
            else if (receiverType is { } typedReceiver
                && TryResolveInstanceMethod(typedReceiver, string.Join('.', path), out var instanceMethod))
            {
                target = instanceMethod;
            }
            else if (TryResolveFunctionForScan(path, scope, caller, out var resolved))
            {
                target = resolved;
            }

            if (target is { Kind: BoundFunctionKind.User or BoundFunctionKind.UserBlock, Body: null })
            {
                var declaredName = CanonicalFunctionName(target);
                if (scope.TryGetValue(declaredName, out var declaredTarget))
                {
                    target = declaredTarget;
                }
            }

            if (target?.Kind == BoundFunctionKind.Native)
            {
                _usedNativeFunctions.Add(target);
            }

            if (target is null)
            {
                return;
            }

            if (target.Kind is BoundFunctionKind.RuntimeReadDirectory
                or BoundFunctionKind.RuntimeCreateDirectory
                or BoundFunctionKind.RuntimePathQuery
                or BoundFunctionKind.RuntimePathAbsolute)
            {
                _usesDirectoryTraversal = true;
            }

            // Runtime intrinsics have no Sollang body to scan, but they still
            // participate in capability reachability. Recording only user and
            // stdlib functions here made directly reached async-file helpers
            // emit calls without their runtime definitions.
            if (target.Kind is not (BoundFunctionKind.User
                or BoundFunctionKind.UserBlock
                or BoundFunctionKind.Native))
            {
                _reachableFunctions.Add(target);
                return;
            }

            if (!target.IsStandardLibrary)
            {
                if (target.Kind is BoundFunctionKind.User or BoundFunctionKind.UserBlock)
                {
                    ScanFunctionForStandaloneStandardLibraryFunctions(target, visited);
                }
                return;
            }

            if (RequiresStandaloneStandardLibraryEmission(target)
                || _activeStandardLibraryFunctionScans.Contains(target))
            {
                _standaloneStandardLibraryFunctions.Add(target);
            }
            ScanFunctionForStandaloneStandardLibraryFunctions(target, visited);
        }

        switch (expression)
        {
            case TypeApplicationExpression application:
                RecordTarget(application, application.Path);
                foreach (var argument in application.Arguments ?? [])
                {
                    ScanExpressionForStandaloneStandardLibraryFunctions(argument, scope, caller, visited);
                }
                return;
            case CallExpression call:
                RecordTarget(call, call.Path);
                foreach (var argument in call.Arguments)
                {
                    ScanExpressionForStandaloneStandardLibraryFunctions(argument, scope, caller, visited);
                }
                return;
            case FlowExpression flow:
                ScanExpressionForStandaloneStandardLibraryFunctions(flow.Source, scope, caller, visited);
                BoundType? flowType = flow.Source is NameExpression sourceName
                    && caller is not null
                    && _program.FunctionBindings.TryGetValue(caller, out var callerBindings)
                    && callerBindings.TryGetValue(sourceName.Name, out var sourceType)
                        ? sourceType
                        : null;
                foreach (var target in flow.Targets)
                {
                    RecordTarget(target, target.Path, flowType);
                    if (flowType is { } receiver
                        && TryResolveInstanceMethod(receiver, string.Join('.', target.Path), out var resolvedMethod))
                    {
                        flowType = resolvedMethod.ReturnType;
                    }
                    else if (_program.ResolvedGenericCalls.TryGetValue(target, out var resolvedTarget))
                    {
                        flowType = resolvedTarget.ReturnType;
                    }
                    foreach (var argument in target.Arguments)
                    {
                        ScanExpressionForStandaloneStandardLibraryFunctions(argument, scope, caller, visited);
                    }
                }
                return;
            case BranchExpression branch:
                ScanExpressionForStandaloneStandardLibraryFunctions(branch.Source, scope, caller, visited);
                foreach (var target in branch.Arms.SelectMany(static arm => arm.Targets))
                {
                    RecordTarget(target, target.Path);
                    foreach (var argument in target.Arguments)
                    {
                        ScanExpressionForStandaloneStandardLibraryFunctions(argument, scope, caller, visited);
                    }
                }
                return;
            case TapExpression tap:
                ScanExpressionForStandaloneStandardLibraryFunctions(tap.Source, scope, caller, visited);
                foreach (var target in tap.Targets)
                {
                    RecordTarget(target, target.Path);
                    foreach (var argument in target.Arguments)
                    {
                        ScanExpressionForStandaloneStandardLibraryFunctions(argument, scope, caller, visited);
                    }
                }
                return;
            case StreamJoinExpression join:
                ScanExpressionForStandaloneStandardLibraryFunctions(join.Source, scope, caller, visited);
                return;
            case FieldAccessExpression field:
                if (TryBuildQualifiedPath(field, out var fieldPath))
                {
                    RecordTarget(field, fieldPath);
                }
                ScanExpressionForStandaloneStandardLibraryFunctions(field.Source, scope, caller, visited);
                return;
            case IfExpression conditional:
                ScanExpressionForStandaloneStandardLibraryFunctions(conditional.Condition, scope, caller, visited);
                ScanBlockForStandaloneStandardLibraryFunctions(conditional.Then, scope, caller, visited);
                ScanBlockForStandaloneStandardLibraryFunctions(conditional.Else, scope, caller, visited);
                return;
            case WhenExpression whenExpression:
                if (whenExpression.Subject is not null)
                {
                    ScanExpressionForStandaloneStandardLibraryFunctions(whenExpression.Subject, scope, caller, visited);
                }
                foreach (var arm in whenExpression.Arms)
                {
                    ScanExpressionForStandaloneStandardLibraryFunctions(arm.Condition, scope, caller, visited);
                    ScanBlockForStandaloneStandardLibraryFunctions(arm.Body, scope, caller, visited);
                }
                ScanBlockForStandaloneStandardLibraryFunctions(whenExpression.Else, scope, caller, visited);
                return;
            case EnumMatchExpression match:
                ScanExpressionForStandaloneStandardLibraryFunctions(match.Subject, scope, caller, visited);
                foreach (var arm in match.Arms)
                {
                    ScanExpressionForStandaloneStandardLibraryFunctions(arm.Condition, scope, caller, visited);
                    ScanBlockForStandaloneStandardLibraryFunctions(arm.Body, scope, caller, visited);
                }
                ScanBlockForStandaloneStandardLibraryFunctions(match.Else, scope, caller, visited);
                return;
            case FoldExpression fold:
                ScanExpressionForStandaloneStandardLibraryFunctions(fold.Source, scope, caller, visited);
                ScanExpressionForStandaloneStandardLibraryFunctions(fold.Initial, scope, caller, visited);
                ScanBlockForStandaloneStandardLibraryFunctions(fold.Body, scope, caller, visited);
                return;
            case CompileTimeEachExpression each:
                ScanExpressionForStandaloneStandardLibraryFunctions(each.Source, scope, caller, visited);
                ScanExpressionForStandaloneStandardLibraryFunctions(each.Selector, scope, caller, visited);
                if (each.DictionaryValueSelector is not null)
                {
                    ScanExpressionForStandaloneStandardLibraryFunctions(each.DictionaryValueSelector, scope, caller, visited);
                }
                return;
        }

        foreach (var child in ExpressionChildren(expression))
        {
            ScanExpressionForStandaloneStandardLibraryFunctions(child, scope, caller, visited);
        }
    }

    private static bool TryResolveFunctionForScan(
        IReadOnlyList<string> path,
        IReadOnlyDictionary<string, BoundFunction> scope,
        BoundFunction? caller,
        out BoundFunction function)
    {
        var name = string.Join('.', path);
        if (!name.Contains('.', StringComparison.Ordinal)
            && caller is { ModuleName.Length: > 0 }
            && scope.TryGetValue(caller.ModuleName + "." + name, out function!))
        {
            return true;
        }

        return scope.TryGetValue(name, out function!);
    }

    private static bool TryBuildQualifiedPath(FieldAccessExpression field, out IReadOnlyList<string> path)
    {
        var segments = new Stack<string>();
        Expression current = field;
        while (current is FieldAccessExpression access)
        {
            segments.Push(access.FieldName);
            current = access.Source;
        }
        if (current is not NameExpression root)
        {
            path = [];
            return false;
        }

        segments.Push(root.Name);
        path = segments.ToArray();
        return true;
    }

    private static IEnumerable<Expression> ExpressionChildren(Expression expression) => expression switch
    {
        StringExpression text => text.Segments.OfType<InterpolationSegment>().Select(segment => segment.Expression),
        AddExpression binary => [binary.Left, binary.Right],
        SubtractExpression binary => [binary.Left, binary.Right],
        MultiplyExpression binary => [binary.Left, binary.Right],
        DivideExpression binary => [binary.Left, binary.Right],
        ModuloExpression binary => [binary.Left, binary.Right],
        CompareExpression binary => [binary.Left, binary.Right],
        AndExpression binary => [binary.Left, binary.Right],
        OrExpression binary => [binary.Left, binary.Right],
        NegateExpression unary => [unary.Value],
        NotExpression unary => [unary.Value],
        RangeExpression range => [range.Start, range.End],
        ArrayLiteralExpression array => array.Elements,
        ArrayRepeatExpression repeat => [repeat.Value],
        DictionaryLiteralExpression dictionary => dictionary.Entries.SelectMany(entry => new[] { entry.Key, entry.Value }),
        IndexExpression index => [index.Source, index.Index],
        StructLiteralExpression structure => structure.Fields.Select(field => field.Value),
        ProductExpression product => product.Elements.Select(element => element.Value),
        PartitionExpression partition => new[] { partition.Source }
            .Concat(partition.Arms.Select(arm => arm.Condition).OfType<Expression>()),
        TryExpression attempt => [attempt.Value],
        BoxExpression box => [box.Value],
        MapExpression map => new[] { map.Path, map.Offset, map.Length, map.FileSize }.OfType<Expression>(),
        SubjectCompareExpression subject => [subject.Right],
        SubjectRangeExpression subject => [subject.Start, subject.End],
        _ => []
    };

    private static bool RequiresStandaloneStandardLibraryEmission(BoundFunction function)
    {
        return FunctionControlFlowFacts.RequiresStandaloneStandardLibraryEmission(function);
    }

}


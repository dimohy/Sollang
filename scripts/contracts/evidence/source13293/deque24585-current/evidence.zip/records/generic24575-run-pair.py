import hashlib
import json
from pathlib import Path
import shutil
import sys
import time

root = Path.cwd()
sys.path.insert(0, str(root / 'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
from verification_fingerprints import managed_compilation_inputs

b = root / 'artifacts/scratch/resume-20261006-owner-continuation22'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
plan_path = b / 'generic24561-plan/plan.json'
plan = read(plan_path)
managed = b / 'generic24558-managed/compiler/Sollang.Compiler.exe'
native_build = b / 'generic24574-native'
native = native_build / 'compiler.exe'
reference_path = b / 'generic24563-managed7/result.json'
reference = read(reference_path)
assert reference['status'] == 'passed' and reference['completed'] == reference['total'] == 7
assert reference['inputsStable'] and reference['processesStopped']
expected_diagnostics = {row['id']: row['expectedCompilerStderr'] for row in reference['cases']}
out = b / 'generic24575-paired14'
reusable = [native_build, b / 'v20050/compiler-build01', b / 'v21323/compiler-build01']
initialize_output(root, out, reusable_directories=reusable)
out.mkdir()
llvm = root / '.tools/llvm-22.1.8'
closure = root / 'scripts/verify-llvm-direct-call-closure.ps1'
pwsh = Path(shutil.which('pwsh'))
inputs = [Path(__file__), plan_path, reference_path, native, native_build / 'result.json',
          b / 'generic24558-managed/result.json', b / 'generic24561-plan/source-comparison.json', b / 'generic24561-plan/late-binding-source-comparison.json',
          closure, pwsh, *managed_compilation_inputs(managed, root / 'stdlib'),
          *map(Path, read(native_build / 'result.json')['inputHashes']),
          *map(Path, read(b / 'generic24558-managed/result.json')['inputHashes']),
          *[root / row['source'] for row in plan['cases']],
          *[llvm / 'bin' / name for name in ('clang.exe', 'llvm-as.exe', 'llvm-link.exe', 'opt.exe', 'llc.exe')],
          *[root / 'scripts' / name for name in ('verification_execution.py',
              'verification_contract_lease.py', 'verification_fingerprints.py',
              'completed_artifact_plan.py', 'ArtifactLifecycle.ps1',
              'Invoke-CompletedArtifactCleanup.ps1', 'contracts/artifact-lifecycle.json')]]
pins = {str(p.resolve()): sha(p) for p in inputs}
result = dict(schemaVersion=1, status='running', completed=0, total=14, inputHashes=pins,
              cases=[], claimsGoalComplete=False,
              scope='Current exact paired generic Deque inference7 per compiler; tools, real build sources and diagnostics pinned. Each positive assembles, checks direct calls and runs; each negative has exact full diagnostics and no generated products.')
with VerificationContractLease(list(map(Path, pins))):
    run = VerificationExecution(root, out, result,
        lambda: all(sha(p) == h for p, h in pins.items()), sha)
    error = None
    try:
        for side, compiler in [('managed', managed), ('selfhost', native)]:
            for row in plan['cases']:
                directory = out / (side + '-' + row['id'])
                directory.mkdir()
                product = directory / 'probe.exe'
                started = time.monotonic()
                def execute(command, label):
                    remaining = 180 - (time.monotonic() - started)
                    assert remaining > 0, 'WHOLE_CASE_BUDGET_EXHAUSTED'
                    return run.run(list(map(str, command)), directory / label, timeout=remaining)
                command = [compiler, 'build', root / row['source'], '-o', product,
                           '--llvm', llvm, '--target', 'windows-x64', '--jobs', '4', '-O1', '--keep-temps']
                if side == 'selfhost':
                    command += ['--stdlib', root / 'stdlib']
                done = execute(command, 'build')
                stderr = done.stderr.replace('\r\n', '\n')
                expected = expected_diagnostics[row['id']]
                assert stderr == expected, done.stdout[-1500:] + stderr
                if row['outcome'] == 'reject':
                    assert done.returncode != 0
                    assert not product.exists() and not list(directory.glob('*.ll')) and not list(directory.glob('*.bc'))
                    item = dict(id=side + ':' + row['id'], passed=True, expectedCompilerStderr=expected,
                                actualCompilerStderr=stderr, productAbsent=True)
                else:
                    assert done.returncode == 0, done.stdout[-1500:] + stderr
                    candidates = [p for p in (product.with_suffix('.ll'), Path(str(product) + '.ll')) if p.is_file()]
                    assert len(candidates) == 1
                    assembled = execute([llvm / 'bin/llvm-as.exe', candidates[0], '-o', directory / 'validated.bc'], 'assemble')
                    assert assembled.returncode == 0 and not assembled.stderr
                    checked = execute([pwsh, '-NoProfile', '-File', closure, '-LlvmPath', candidates[0]], 'closure')
                    assert checked.returncode == 0 and not checked.stderr, checked.stdout + checked.stderr
                    executed = execute([product], 'run')
                    assert executed.returncode == 0 and not executed.stderr
                    assert executed.stdout.replace('\r\n', '\n') == row['stdout'], executed.stdout
                    item = dict(id=side + ':' + row['id'], passed=True, expectedCompilerStderr=expected,
                                actualCompilerStderr=stderr, stdout=executed.stdout,
                                llvmAsExit=0, directCallExit=0, nativeExit=0)
                item.update(wholeCaseBudgetSeconds=180, wholeCaseElapsedSeconds=time.monotonic() - started)
                result['cases'].append(item)
                result['completed'] += 1
                run.save()
                print(item['id'] + ': PASS', flush=True)
        result['status'] = 'passed'
    except BaseException as exc:
        error = exc
    finally:
        run.finalize(error, cleanup=False)
    if error:
        raise error

from pathlib import Path
import sys,json,hashlib,time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'origin21436-fixed-emitter';CPP=B/'managed21139/compiler/Sollang.Compiler.exe';manifest=ROOT/'tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.sources.txt';sources=[ROOT/s for s in manifest.read_text(encoding='utf-8-sig').splitlines() if s and not s.endswith('selfhost-sollangc-driver.slg')];probe=ROOT/'scripts/probes/ownership-origin/observer.slg';subject=ROOT/'examples/regression/1199-local-function-parallel-callback.slg';oracle=ROOT/'examples/regression/expected/1199-local-function-parallel-callback.stdout.txt';reference=ROOT/'scripts/contracts/evidence/source13293/names21426-declaration-symbols/qualification.json';semantic=B/'origin21434-semantic/result.json';sem=json.loads(semantic.read_text());assert sem['status']=='passed' and sem['completed']==sem['total']==4 and sem['inputsStable'] and sem['processesStopped'];controls=['275-owned-result-role-block','1766-readonly-text-slice-direct-first'];subjects=[(label,ROOT/f'examples/regression/{label}.slg',ROOT/f'examples/regression/expected/{label}.stdout.txt') for label in controls];probeMain=ROOT/'scripts/probes/ownership-origin/main.slg';inputs=[probeMain,semantic,B/'origin21433-source-comparison.json',*[p for label,src,oracle in subjects for p in [src,oracle]],Path(__file__),CPP,*managed_runtime_inputs(CPP),manifest,probe,subject,oracle,reference,*sources,*sorted((ROOT/'stdlib').rglob('*.slg'))];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();hashes={str(p):sha(p) for p in inputs};assert sha(CPP.with_suffix('.dll'))=='B838CF7C48EF32FFA96ACA2D6B8197645AF8C070D30C48C233DDE65A94FA991E';initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=8,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Readonly input mode ignores non-ownership declaration flags: current production context and actual LLVM/link/runtime1199; all136 low-bit controls; related block ownership and readonly slice CSharp-first pairs. No full Native/whole goal claim.',claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  done=run.run([str(CPP),'build',str(probeMain),str(probe),*map(str,sources),'-o',str(OUT/'observer.exe'),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','24','-O2','--keep-temps'],OUT/'build-observer',timeout=180);assert done.returncode==0 and not done.stderr,done.stdout[-2000:]+done.stderr;result['cases'].append(dict(id='current-source-observer-build',passed=True));result['completed']+=1;run.save()
  done=run.run([str(OUT/'observer.exe'),'flags'],OUT/'flags',timeout=180);expected=''.join(f'flags={i},{str(i%4==0).lower()}\n' for i in range(136));assert done.returncode==0 and not done.stderr and done.stdout==expected,done.stdout[-1800:]+done.stderr;result['cases'].append(dict(id='readonly-flags136',passed=True,observations=136));result['completed']+=1;run.save()
  done=run.run([str(OUT/'observer.exe'),str(subject),str(ROOT/'stdlib')],OUT/'observe',timeout=180);assert done.returncode==0 and not done.stderr and 'root=0,binding=-1' in done.stdout and 'diagnostic=' not in done.stdout,done.stdout[:2200]+done.stderr;result['cases'].append(dict(id='1199-owned-origin-cleared',passed=True));result['completed']+=1;run.save()
  allSubjects=[('1199-local-function-parallel-callback',subject,oracle),*subjects]
  for ordinal,(label,src,expectedFile) in enumerate(allSubjects):
   roles=['slg'] if ordinal==0 else ['csharp','slg']
   for role in roles:
    d=OUT/(role+'-'+label);d.mkdir();start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));exe=d/'program.exe'
    if role=='csharp':
     done=run.run([str(CPP),'build',str(src),'-o',str(exe),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0'],d/'build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout[-1800:]+done.stderr
    else:
     done=run.run([str(OUT/'observer.exe'),'emit','unused',str(ROOT/'stdlib'),str(src)],d/'emit',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout[-1800:]+done.stderr;ll=d/'program.ll';ll.write_text(done.stdout,encoding='utf-8');done=run.run([str(ROOT/'.tools/llvm-22.1.8/bin/llvm-as.exe'),str(ll),'-o',str(d/'program.bc')],d/'assemble',timeout=budget());assert done.returncode==0,done.stderr;done=run.run([str(ROOT/'.tools/llvm-22.1.8/bin/clang.exe'),str(ll),'-O0','-Wno-override-module','-o',str(exe),'-lkernel32','-lshell32','-lws2_32','-lbcrypt'],d/'link',timeout=budget());assert done.returncode==0,done.stderr
    done=run.run([str(exe)],d/'run',timeout=budget());expected=expectedFile.read_text(encoding='utf-8-sig');assert done.returncode==0 and not done.stderr and done.stdout==expected,done.stdout+done.stderr;result['cases'].append(dict(id=role+'-'+label,passed=True,stdout=done.stdout,expected=expected));result['completed']+=1;run.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

from pathlib import Path
import sys,json,hashlib,time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'origin21432-observer';CPP=B/'managed21139/compiler/Sollang.Compiler.exe';manifest=ROOT/'tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.sources.txt';sources=[ROOT/s for s in manifest.read_text(encoding='utf-8-sig').splitlines() if s and not s.endswith('selfhost-sollangc-driver.slg')];probe=ROOT/'scripts/probes/ownership-origin/observer.slg';subject=ROOT/'examples/regression/1199-local-function-parallel-callback.slg';oracle=ROOT/'examples/regression/expected/1199-local-function-parallel-callback.stdout.txt';reference=ROOT/'scripts/contracts/evidence/source13293/names21426-declaration-symbols/qualification.json';inputs=[Path(__file__),CPP,*managed_runtime_inputs(CPP),manifest,probe,subject,oracle,reference,*sources,*sorted((ROOT/'stdlib').rglob('*.slg'))];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();hashes={str(p):sha(p) for p in inputs};assert sha(CPP.with_suffix('.dll'))=='B838CF7C48EF32FFA96ACA2D6B8197645AF8C070D30C48C233DDE65A94FA991E';initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=2,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Prior CSharp1199 passed in origin21431; current-source extended SLG owned-origin observation (full stdlib discovery and production preparation). Diagnosis only, no semantic rejection/whole goal closure claimed.',claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  done=run.run([str(CPP),'build',str(probe),*map(str,sources),'-o',str(OUT/'observer.exe'),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','24','-O2','--keep-temps'],OUT/'build-observer',timeout=180);assert done.returncode==0 and not done.stderr,done.stdout[-2000:]+done.stderr;result['cases'].append(dict(id='current-source-observer-build',passed=True));result['completed']+=1;run.save()
  done=run.run([str(OUT/'observer.exe'),str(subject),str(ROOT/'stdlib')],OUT/'observe',timeout=180);assert done.returncode==0 and not done.stderr and 'root=10,binding=-2' in done.stdout and 'diagnostic-origin=' in done.stdout,done.stdout[-2500:]+done.stderr;result['cases'].append(dict(id='owned-origin-captured',passed=True,stdoutFile='observe.stdout'));result['completed']+=1;result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

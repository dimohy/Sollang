"""Conservative input planning only; preserve every original assertion and scope."""
from pathlib import Path
import collections,hashlib,json
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22'
source=b/'semantic19579-normalized-candidates.json'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
d=read(source);rows=[];missing=[];counts=collections.Counter();groups={}
legacy='P:\\MyWorks\\Sollang\\'
def local(value):
    value=str(value)
    if value.casefold().startswith(legacy.casefold()):value=value[len(legacy):]
    p=Path(value)
    p=p if p.is_absolute() else r/p
    if not p.resolve().is_relative_to(r):raise ValueError('SOURCE_OUTSIDE_WORKSPACE: '+str(p))
    return p
for decision in d['decisions']:
    for candidate in decision['cases']:
        original=candidate.get('originalCase',{})
        resolved=candidate.get('resolvedCandidate',{})
        contract=candidate.get('contract')
        if contract:assert sha(local(contract['path']))==contract['sha256'].upper()
        roots=[];inline=None
        if candidate.get('currentSource'):
            roots=[candidate['currentSource']['path']]
        elif original.get('sources'):
            roots=original['sources']
        elif resolved.get('path'):
            roots=[resolved['path']]
        elif candidate.get('inlineSourceSha256'):
            inline=original['source'].encode('utf-8')
            assert hashlib.sha256(inline).hexdigest().upper()==candidate['inlineSourceSha256']
        else:
            counts['unresolvedSourceShape']+=1
        roots += original.get('additionalSources',[])
        pins=[]
        for value in roots:
            p=local(value)
            if not p.is_file():missing.append({'decision':decision['decisionId'],'case':candidate['id'],'path':str(p)});continue
            pins.append({'path':p.relative_to(r).as_posix(),'sha256':sha(p)})
        if candidate.get('currentSource'):
            assert pins[0]['sha256']==candidate['currentSource']['sha256'].upper()
        if resolved.get('path') and resolved.get('sha256'):
            assert pins[0]['sha256']==resolved['sha256'].upper()
        runtime_pins=[]
        for value in [original.get('programSource'),original.get('expectedPath'),resolved.get('expectedFile',{}).get('path')]:
            if value:
                p=local(value)
                if not p.is_file():missing.append({'decision':decision['decisionId'],'case':candidate['id'],'runtimeInput':str(p)});continue
                runtime_pins.append({'path':p.relative_to(r).as_posix(),'sha256':sha(p)})
        resolved_expectation=resolved.get('expected',{})
        explicit_exit=original.get('exit',original.get('expectedBuildExit',resolved_expectation.get('exit')))
        diag=original.get('stderr',original.get('expectedBuildStderr',resolved_expectation.get('stderr')))
        policy='exact-declared-text' if isinstance(diag,str) else 'requires-exact-stream-review'
        if policy=='requires-exact-stream-review':counts['diagnosticStreamReview']+=1
        if explicit_exit==0 and diag:counts['successfulCompileWithDiagnostics']+=1
        if explicit_exit is None:counts['buildExitReview']+=1
        special=[k for k in ['warnings','locationSelector','expectedDiagnostic','expectedDiagnosticSubstring',
                 'target','expectedPath','diagnostic','invocation','expected','programSource','observedSourceOrder',
                 'runArguments','emittedLlvm','runStderr','requireNoLlvm','expectedAllocations'] if k in original]
        for key in special:counts['assertion:'+key]+=1
        identity={'contract':contract,'originalCase':{k:v for k,v in original.items() if k!='id'},
                  'resolvedCandidate':resolved,'sources':pins,'runtimeInputs':runtime_pins,'inlineSha256':candidate.get('inlineSourceSha256')}
        group=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest().upper()
        row={'decisionId':decision['decisionId'],'id':candidate['id'],'executionGroup':group,'sourceInputs':pins,
             'inlineSourceSha256':candidate.get('inlineSourceSha256'),'declaredBuildExit':explicit_exit,
             'diagnosticPolicy':policy,'preservedSpecialAssertions':special,
             'runtimeInputFiles':runtime_pins,
             'originalCandidate':candidate,'claimsExecutionComplete':False}
        rows.append(row);groups.setdefault(group,[]).append({'decision':decision['decisionId'],'case':candidate['id']})
batch=read(b/'parsing19540/selfhost/selfhost-batch-results.json');whole={v['Fixture'] for v in batch['results']}
canonical={p for decision in d['decisions'] for c in decision['cases'] for p in c.get('byteIdenticalCanonicalCandidates',[])}
summary={'decisions':len(d['decisions']),'candidateAssociations':len(rows),'conservativeExecutionGroups':len(groups),
         'uniqueFileInputs':len({p['path'] for c in rows for p in c['sourceInputs']}),
         'uniqueRuntimeInputs':len({p['path'] for c in rows for p in c['runtimeInputFiles']}),
         'inlineSources':sum(c['inlineSourceSha256'] is not None for c in rows),'missingFiles':len(missing),
         'canonicalUniqueFiles':len(canonical),'canonicalFilesIn405':sum(Path(p).stem in whole for p in canonical),
         'sourceMembershipOnlyNotReuseApproval':True,'counts':dict(counts)}
out={'schemaVersion':1,'status':'protocol-planning-only-no-compiler-executions','input':{'path':source.relative_to(r).as_posix(),'sha256':sha(source)},
     'summary':summary,'cases':rows,'executionGroups':groups,'missingFiles':missing,
     'remaining':['Review complete branch coverage of40 source decisions before reviewed inventory.',
                  'Preserve raw diagnostic, allocation, no-LLVM, source-order, target and cache assertions.',
                  'Current exact runner telemetry mode only admits successful empty-stderr compile stages; warning cases require a deliberate compatible protocol decision, not warning suppression.',
                  '405 overlap is source membership only. Authenticate full input/expected-output/tool compatibility before reuse.',
                  'Supplemental16 case associations are retained in prior planning input and not counted as executed here.'],
     'claimsPhaseComplete':False,'claimsGoalComplete':False}
(b/'semantic19690-execution-plan.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))

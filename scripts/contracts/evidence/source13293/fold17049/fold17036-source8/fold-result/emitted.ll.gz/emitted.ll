; sollang ir error: invariant 3 at ir 118112 (kind 8, parent 118111, operand0 -1, operand1 -1, source 144, ast 12, byte 49, length 12)
selection-emission-rejected

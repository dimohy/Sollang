define i32 @sollang_x0A63616368652E62657461010701056170706C793A01067075626C696301056170706C79010576616C756518013A0105496E74333216022D3E0105496E7433320104757365730107436F6E736F6C65(i32 %arg) {
entry:
  %v4_ptr = insertvalue %sollang.text poison, ptr @sollang_str_627065225220, 0
  %v4 = insertvalue %sollang.text %v4_ptr, i64 4, 1
  call void @sollang_runtime_print(ptr @sollang_str_627065225220, i64 4, i1 true)
  %v5 = add i32 %arg, 3
  ret i32 %v5
}
from pathlib import Path
import json,hashlib,sys
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'environment25415-linux';sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_source_proof import current_build_inputs
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
reuse=[B/'environment25409-native',B/'types25384-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir();C=B/'environment25400-managed/compiler/Sollang.Compiler.exe';N=B/'environment25409-native/compiler.exe';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();paths=[Path(__file__),B/'environment25415-linux.ps1',C,N,*managed_runtime_inputs(C),B/'environment25409-native/result.json',*current_build_inputs(R,json.loads((B/'environment25409-native/result.json').read_text(encoding='utf-8-sig'))),R/'scripts/verification-process.ps1',R/'scripts/verification-compiler-build.ps1',R/'scripts/contracts/verification-compiler-build.json',R/'examples/regression/84-process-environment.slg',R/'scripts/probes/process-arguments/environment-loop-scratch.slg',R/'examples/regression/expected/84-process-environment.env.txt',R/'examples/regression/expected/84-process-environment.stdout.txt',R/'examples/regression/expected/environment-loop-fixed-scratch.stdout.txt'];pins={str(p):sha(p) for p in paths};r=dict(schemaVersion=1,status='running',completed=0,total=4,inputHashes=pins,cases=[],scope='Additional Linux environment programs, both compilers, existing O0 external-link contract; not whole platform qualification',claimsGoalComplete=False);x=VerificationExecution(R,O,r,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
try:
 for label,compiler in [('managed',C),('native',N)]:
  done=x.run(['pwsh','-NoProfile','-File',str(B/'environment25415-linux.ps1'),'-Compiler',str(compiler),'-Output',str(O/label)],O/label,timeout=390);assert done.returncode==0 and not done.stderr,(label,done.stdout,done.stderr)
  for name in ['normal','loop']:r['cases'].append(dict(id=label+'-'+name,passed=True));r['completed']+=1
 r['status']='passed'
except BaseException as e:error=e
finally:x.finalize(error,cleanup=False)
if error:raise error
print(json.dumps({k:r[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

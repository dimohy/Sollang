from pathlib import Path
import json,hashlib,textwrap
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22/environment25399';names=['src/Sollang.Compiler/Shared/Policies/NativeRuntimePolicy.cs','src/Sollang.Compiler/CodeGen/WindowsLlvmRuntimePlatform.cs','src/Sollang.Compiler/CodeGen/LinuxLlvmRuntimePlatform.cs','src/Sollang.Compiler/CodeGen/LlvmEmitter.cs','selfhost/llvm/emitter/environment_runtime.slg','selfhost/llvm/runtime.slg']
for n in names:
 p=B/'before-source'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/n).read_bytes())
read=lambda n:(R/n).read_text(encoding='utf-8-sig')
w=read(names[1]);l=read(names[2]);policy=read(names[0]);emitter=read(names[3])
start=w.index('    public override void EmitEnvironmentPrimitives(StringBuilder functions)');end=w.index('    public override void EmitMemoryPrimitives',start);old=w[start:end];prefix='        functions.AppendLine("""\n';assert old.count(prefix)==1 and old.count('            """);')==1
windows=textwrap.dedent(old.split(prefix,1)[1].rsplit('            """);',1)[0]).rstrip('\n');assert windows.startswith('define internal i1 @sollang_track_environment_allocation')
w=w[:start]+'''    public override void EmitEnvironmentPrimitives(StringBuilder functions)
    {
        functions.AppendLine(NativeRuntimePolicy.EnvironmentWindowsFunctions());
        functions.AppendLine();
    }

'''+w[end:]
oldGlobals='''        globals.AppendLine("@sollang_environment_allocations = internal global ptr null");
        globals.AppendLine("@sollang_environment_empty = internal constant [1 x i8] zeroinitializer, align 1");''';assert w.count(oldGlobals)==1;w=w.replace(oldGlobals,'        globals.AppendLine(NativeRuntimePolicy.EnvironmentWindowsGlobals());')
prefix='        functions.AppendLine("""\n            define internal %sollang.environment_result @sollang_environment';start=l.index(prefix);finish=l.index('            """);',start)+len('            """);');old=l[start:finish];linux=textwrap.dedent(old.split('        functions.AppendLine("""\n',1)[1].rsplit('            """);',1)[0]).rstrip('\n');l=l[:start]+'        functions.AppendLine(NativeRuntimePolicy.EnvironmentLinuxFunctions());\n        functions.AppendLine();'+l[finish:];l=l.replace('using System.Text;','using System.Text;\nusing Sollang.Compiler.Shared;',1)
layout='%sollang.environment_result = type { ptr, i64, i1, i1 }';assert emitter.count(layout)==1;emitter=emitter.replace(layout,'{{NativeRuntimePolicy.EnvironmentResultType()}}')
globals='@sollang_environment_allocations = internal global ptr null\n@sollang_environment_empty = internal constant [1 x i8] zeroinitializer, align 1'
methods='\n    // One compiled environment ABI and platform helper body for CSharp and SLG.\n    public static string EnvironmentResultType() => "'+layout+'";\n'
for n,s in [('EnvironmentWindowsGlobals',globals),('EnvironmentWindowsFunctions',windows),('EnvironmentLinuxFunctions',linux)]:
 assert len(s)<16384
 methods+='\n    public static string '+n+'() =>\n        """\n'+textwrap.indent(s,'        ')+'\n        """;\n'
assert policy.endswith('}\n');policy=policy[:-2]+methods+'}\n'
# CSharp emission is byte-identical after extracting the same literal value.
assert windows+'\n\n'==textwrap.dedent(read(names[1])[read(names[1]).index('        functions.AppendLine("""\n',read(names[1]).index('    public override void EmitEnvironmentPrimitives')):].split('        functions.AppendLine("""\n',1)[1].split('            """);',1)[0])
for n,s in zip(names[:4],[policy,w,l,emitter]):(R/n).write_text(s,encoding='utf-8')
(B/'csharp-extraction.json').write_text(json.dumps(dict(status='csharp-only-extracted',literalCharacters=dict(windows=len(windows),linux=len(linux),globals=len(globals)),sourceHashes={n:hashlib.sha256((R/n).read_bytes()).hexdigest().upper() for n in names},slgUnchanged=True),indent=2)+'\n',encoding='utf-8');print('Extracted CSharp environment bodies and ABI; SLG unchanged')

param([Parameter(Mandatory)][string]$Compiler,[Parameter(Mandatory)][string]$Output)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath('W:\MyWorks\Sollang')
. (Join-Path $repo 'scripts/verification-process.ps1')
. (Join-Path $repo 'scripts/verification-compiler-build.ps1')
[IO.Directory]::CreateDirectory($Output) | Out-Null
$settings=Get-Content (Join-Path $repo 'examples/regression/expected/84-process-environment.env.txt')
$envArgs=@('-u','SOLLANG_TEST_MISSING') + @($settings | Where-Object { $_ -ne '' })
$cases=@(
 @{id='normal';source='examples/regression/84-process-environment.slg';expected='examples/regression/expected/84-process-environment.stdout.txt'},
 @{id='loop';source='scripts/probes/process-arguments/environment-loop-scratch.slg';expected='examples/regression/expected/environment-loop-fixed-scratch.stdout.txt'}
)
foreach($case in $cases) {
 $directory=Join-Path $Output $case.id;[IO.Directory]::CreateDirectory($directory) | Out-Null
 $binary=Join-Path $directory 'probe.exe'
 $built=Invoke-VerificationCompilerBuild -Compiler $Compiler -Source (Join-Path $repo $case.source) -Output $binary -Target linux-x64 -WorkingDirectory $repo -Description "environment-linux-$($case.id)" -TimeoutMilliseconds 180000
 if($built.ExitCode -ne 0 -or -not [string]::IsNullOrWhiteSpace($built.Stderr)) {throw "LINUX_ENVIRONMENT_BUILD:$($case.id):$($built.Stderr)"}
 $mapped=Invoke-VerificationProcessCapture -FilePath 'C:\WINDOWS\system32\wsl.exe' -ArgumentList @('-d','Ubuntu','--','wslpath','-a',$binary.Replace('\','/')) -WorkingDirectory $repo -Description 'environment-linux-map' -TimeoutMilliseconds 15000 -ExecutionRecordPath (Join-Path $directory 'path.execution.json')
 if($mapped.ExitCode -ne 0) {throw 'LINUX_ENVIRONMENT_PATH'}
 $arguments=@('-d','Ubuntu','--','/usr/bin/timeout','--kill-after=2s','10s','/usr/bin/env')+$envArgs+@($mapped.Stdout.Trim())
 $run=Invoke-VerificationProcessCapture -FilePath 'C:\WINDOWS\system32\wsl.exe' -ArgumentList $arguments -WorkingDirectory $repo -Description "environment-linux-run-$($case.id)" -TimeoutMilliseconds 15000 -ExecutionRecordPath (Join-Path $directory 'run.execution.json')
 $expected=[IO.File]::ReadAllText((Join-Path $repo $case.expected)).ReplaceLineEndings("`n")
 if($run.ExitCode -ne 0 -or $run.Stdout.ReplaceLineEndings("`n") -cne $expected -or -not [string]::IsNullOrWhiteSpace($run.Stderr)) {throw "LINUX_ENVIRONMENT_ORACLE:$($case.id):$($run.Stdout):$($run.Stderr)"}
 Write-Host "Linux environment $($case.id): PASS"
}

from pathlib import Path
import json,hashlib,sys
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));from verification_execution import VerificationExecution
from completed_artifact_plan import initialize_output
from verification_fingerprints import managed_runtime_inputs
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=B/'environment25400-managed/compiler/Sollang.Compiler.exe';O=B/'environment25401-csharp';reuse=[B/'types25384-native',B/'array25358-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();sources=[R/'examples/regression/84-process-environment.slg',R/'scripts/probes/windows-environment-parallel.slg',R/'scripts/probes/process-arguments/environment-loop-scratch.slg'];paths=[Path(__file__),C,*managed_runtime_inputs(C),B/'environment25400-managed/result.json',*sources,*sorted((R/'stdlib').rglob('*.slg')),*[R/'scripts/probes'/n for n in ['windows-environment-programs.py','windows-environment-result.py','windows-environment-result.c','windows-environment-concurrency.py','windows-environment-concurrency.c','run-environment-fixture.py']],R/'examples/regression/expected/84-process-environment.env.txt',R/'examples/regression/expected/84-process-environment.stdout.txt',R/'examples/regression/expected/environment-loop-fixed-scratch.stdout.txt',R/'.tools/llvm-22.1.8/bin/clang.exe'];pins={str(p):sha(p) for p in paths};r=dict(schemaVersion=1,status='running',completed=0,total=6,inputHashes=pins,cases=[],claimsGoalComplete=False);x=VerificationExecution(R,O,r,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
try:
 for label,src in zip(['normal','parallel','loop'],sources):
  done=x.run([str(C),'build',str(src),'-o',str(O/(label+'.exe')),'--emit-llvm',str(O/(label+'.ll')),'--target','windows-x64','-O1','--jobs','4','--keep-temps','--llvm',str(R/'.tools/llvm-22.1.8')],O/(label+'.build'),timeout=180);assert done.returncode==0 and not done.stderr,(label,done.stdout[-1000:],done.stderr);r['cases'].append(dict(id=label+'-compile',passed=True));r['completed']+=1
 done=x.run([sys.executable,'-B',str(R/'scripts/probes/windows-environment-programs.py'),str(O/'normal.exe'),str(O/'parallel.exe'),str(O/'programs')],O/'programs',timeout=60);assert done.returncode==0 and not done.stderr,(done.stdout,done.stderr);r['cases'].append(dict(id='public-programs2',passed=True));r['completed']+=1
 done=x.run([str(O/'loop.exe')],O/'loop.run',timeout=15);expected=(R/'examples/regression/expected/environment-loop-fixed-scratch.stdout.txt').read_text(encoding='utf-8-sig');assert done.returncode==0 and done.stdout==expected and not done.stderr;r['cases'].append(dict(id='loop-runtime',passed=True));r['completed']+=1
 for label,tool in [('helper-api','windows-environment-result.py')]:
  done=x.run([sys.executable,'-B',str(R/'scripts/probes'/tool),str(O/'normal.ll'),str(O/label)],O/(label+'.runner'),timeout=60);assert done.returncode==0 and not done.stderr,(done.stdout,done.stderr);r['cases'].append(dict(id=label,passed=True));r['completed']+=1
 r['status']='passed'
except BaseException as e:error=e
finally:x.finalize(error,cleanup=False)
if error:raise error
print(json.dumps({k:r[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

from pathlib import Path
import sys,json,hashlib
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from completed_artifact_plan import initialize_output,cleanup_output
O=B/'environment25419-validation';reuse=[B/'environment25409-native',B/'types25384-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
paths=[Path(__file__),R/'scripts/contracts/structural-parity-detail.json',*[R/'scripts'/n for n in ['audit-structural-source-connections.py','verify-structural-parity-detail.py','verify-ai-slg-best-practices.ps1']],*[R/n for n in ['docs/AI_SLG_BEST_PRACTICES.md','docs/SPEC.md','docs/AI_AGENT_GUIDE.md','README.md','llms.txt','syntax/sollang.grammar','syntax/sollang.lexer','scripts/contracts/ai-slg-best-practices.json','scripts/contracts/ai-slg-best-practices.schema.json']]]
pins={str(p.resolve()):sha(p) for p in paths};r=dict(schemaVersion=1,status='running',completed=0,total=3,inputHashes=pins,cases=[])
x=VerificationExecution(R,O,r,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
try:
 for label,args in [('source-connections',[sys.executable,'-B',str(R/'scripts/audit-structural-source-connections.py')]),('phase-closure',[sys.executable,'-B',str(R/'scripts/verify-structural-parity-detail.py'),'--phase-closure-only']),('guide-contract',['pwsh','-NoProfile','-File',str(R/'scripts/verify-ai-slg-best-practices.ps1')])]:
  done=x.run(args,O/label,timeout=60);assert done.returncode==0 and not done.stderr,(label,done.stdout,done.stderr);r['cases'].append(dict(id=label,passed=True));r['completed']+=1
 r['status']='passed'
except BaseException as e:error=e
finally:x.finalize(error,cleanup=False)
if error:raise error
cleanup_output(R,O,reusable_directories=reuse)
print(json.dumps({k:r[k] for k in ['status','completed','total','inputsStable','processesStopped']}))



from pathlib import Path
import json,hashlib,sys
repo=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(repo/'scripts'))
from verification_execution import VerificationExecution
from verification_source_proof import current_build_inputs
base=Path(__file__).resolve().parent;planPath=base/'native-diagnostic-plan.json';plan=json.loads(planPath.read_text());group=plan['groups'][sys.argv[1]];out=repo/group['output'];assert not out.exists();out.mkdir();contractPath=repo/group['contract'];proofPath=repo/group['managedProof'];contract=json.loads(contractPath.read_text());proof=json.loads(proofPath.read_text(encoding='utf-8-sig'));assert proof['status']=='passed' and proof['completed']==proof['total']==len(contract['cases']) and proof['processesStopped']
buildPath=repo/plan['nativeBuild'];build=json.loads(buildPath.read_text(encoding='utf-8-sig'));assert build['status']=='passed' and build['inputsStable'] and build['processesStopped'];compiler=buildPath.parent/'compiler.exe';prototypePath=repo/plan['commandPrototype'];prototype=json.loads(prototypePath.read_text(encoding='utf-8-sig'))['processes'][0]['command'];assert '--stdlib' in prototype and '-O0' in prototype and prototype[prototype.index('--jobs')+1]=='1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert all(Path(p).is_file() and sha(p)==h for p,h in proof['inputHashes'].items())
inputs=[compiler,buildPath,planPath,Path(__file__),contractPath,proofPath,prototypePath,repo/plan['legacyContract'],repo/'scripts/verification_execution.py',*current_build_inputs(repo,build),*[Path(p) for p in proof['inputHashes']]];pins={str(p):sha(p) for p in inputs};stable=lambda:all(p.is_file() and sha(p)==pins[str(p)] for p in inputs);r={'schemaVersion':1,'status':'running','completed':0,'total':len(contract['cases']),'inputHashes':pins,'cases':[]};e=VerificationExecution(repo,out,r,stable,sha);error=None;references={c['id']:c['actualDiagnostic'] for c in proof['cases']}
try:
 for c in contract['cases']:
  folder=out/c['id'];folder.mkdir();cmd=list(prototype);cmd[0]=str(compiler);cmd[2]=c['source'];cmd[cmd.index('-o')+1]=str(folder/'program.exe');p=e.run(cmd,folder/'build',timeout=plan['maximumCaseSeconds']);text=p.stderr.strip();legacy=c['id'] in group['legacyMainCaseIds']
  accepted=p.returncode==1 and c['stderrContains'] in text and text.count(c['stderrContains'])==1 and not p.stdout.strip() and not (folder/'program.exe').exists() and not list(folder.glob('*.ll'))
  if legacy:accepted=accepted and "in main, match the Result explicitly with '-> when' and handle Ok/Err" in text and text.count('sollang')==1
  else:accepted=accepted and text==references[c['id']]
  row={'id':c['id'],'status':'passed' if accepted else 'failed','passed':accepted,'buildExit':p.returncode,'runExit':None,'actualDiagnostic':text,'referenceDiagnostic':references[c['id']],'legacyMainGuidance':legacy};r['cases'].append(row);r['completed']+=int(accepted);e.save();print(c['id']+(': PASS' if accepted else ': FAIL'),flush=True)
  if not accepted:raise ValueError('NATIVE_DIAGNOSTIC_CONTROL_FAILED:'+c['id'])
 r['status']='passed'
except BaseException as ex:error=ex
finally:e.finalize(error,cleanup=False)
print(json.dumps({'status':r['status'],'completed':r['completed'],'total':r['total']}))
if error:raise error

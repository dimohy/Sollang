from pathlib import Path
import json,hashlib,zipfile,datetime,shutil
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/dyn24658-current';E.mkdir(exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest().upper()
passed=['dyn24635-csharp','dyn24637-csharp-controls','dyn24639-seed-controls','dyn24645-seed-focused3','map24650-csharp','map24653-semantic','map24654-stdlib','map24655-native','map24656-native-after','dyn24657-native-focused4']
failed=['dyn24636-seed-reproduction','dyn24643-native-pair4','dyn24646-native-focused4','map24648-csharp','map24649-csharp','map24651-native-before']
records={n:json.loads((B/n/'result.json').read_text(encoding='utf-8')) for n in passed+failed}
for n in passed:
 j=records[n];assert j['status']=='passed' and j['completed']==j['total'] and j['inputsStable'] and j['processesStopped'],n
for n in ['map24656-native-after','dyn24657-native-focused4']:
 assert all(sha(Path(p).read_bytes())==h for p,h in records[n]['inputHashes'].items()),n
protected=json.loads((B/'block24016-protected-inputs.json').read_text());assert all(sha((R/p).read_bytes())==h for p,h in protected.items())
manifest={};entries={}
def add(path,arc=None):
 if not path.is_file():return
 key=arc or str(path.relative_to(R)).replace('\\','/');data=path.read_bytes()
 assert key not in entries or entries[key]==data,key
 entries[key]=data;manifest[key]=dict(sha256=sha(data),bytes=len(data))
for n in passed+failed:
 shutil.copyfile(B/n/'result.json',E/(n+'.json'))
 for p in (B/n).rglob('*'):
  if p.is_file() and p.suffix.lower() in ('.json','.txt','.log','.py') and '.sollang-cache' not in p.parts and 'dotnet-artifacts' not in p.parts:
   add(p)
for folder in ['dyn24638-canonical-name','map24652-source-comparison']:
 for p in (B/folder).iterdir():add(p)
for p in B.glob('dyn246*-run.py'):add(p)
for p in [B/'map24648-run.py',B/'dyn24637-fixture-syntax-observation.json',Path(__file__)]:add(p)
for folder in ['scripts/probes/codegen-resolved-type-names','scripts/probes/map-text-call-identity']:
 for p in (R/folder).rglob('*'):add(p)
inputRefs={}
for n,j in records.items():
 for p,h in j.get('inputHashes',{}).items():
  path=Path(p)
  if path.is_file() and sha(path.read_bytes())==h:
   if path.suffix.lower() in ('.slg','.cs','.py','.json','.ps1','.txt','.csproj','.props','.targets','.grammar','.lexer') and 'artifacts' not in path.relative_to(R).parts:
    add(path)
  inputRefs.setdefault(p,{})[n]=h
archive=E/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,data in sorted(entries.items()):z.writestr(p,data)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(entries)
 for p in z.namelist():assert sha(z.read(p))==manifest[p]['sha256'],p
def write(name,obj):(E/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
write('archive-manifest.json',dict(entries=manifest,archiveSha256=sha(archive.read_bytes()),readbackVerified=True))
write('input-references.json',inputRefs)
write('protected-inputs.json',dict(completed=8,total=8,hashes=protected))
write('limitations.json',dict(claimsGoalComplete=False,original1999='Native whole180/O1/jobs4 timeout remains unresolved; no unchanged original or profiling replay for these two units.',phaseScope='Focused positive metadata/runtime support only; C385/C742, complete branch parity, whole source7/runtime2708/Stage2/Stage3/frozen stdlib/runtime22/platform gates remain pending.',progressValidation='unverified; no evaluator or policy change',fullLedger='Preexisting39 missing shapingEvidence remain unresolved; no full ledger success claim.',historicalFailures='194-source helper timed out180. Existing nominal metadata dependency list50 reused without changing expected names, helper or whole180/O1/jobs4 limits. Actual direct mapText linker failure reproduced and fixed in canonical resolved declaration seal; failed records preserved. Provisional box dyn syntax rejected by CSharp remains observation, not support credit. Initial new fixed-length growable test warning and unsupported managed CLI option corrected before freezing final fixtures. Historical raw records are retained; not every superseded provisional helper source byte was snapshotted.',nonAdditive='Seed3 and semantic/std-library/build prerequisites are supporting evidence, not added to paired16; original1432 metadata and runtime are separate contracts, repeated seed/runtime executions not counted twice.'))
write('qualification.json',dict(schemaVersion=1,status='focused-qualified-final-pending',owner='C2026-09-12-385',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),managedFirst=True,pairedPrograms=dict(completed=16,total=16,canonicalResolvedDynNames=dict(completed=8,total=8,managedRecords=['dyn24635-csharp.json','dyn24637-csharp-controls.json'],nativeRecord='dyn24657-native-focused4.json'),canonicalMapTextCalls=dict(completed=8,total=8,managedRecord='map24650-csharp.json',nativeRecord='map24656-native-after.json')),sourceComparisons=['artifacts/scratch/resume-20261006-owner-continuation22/dyn24638-canonical-name/source-comparison.json','artifacts/scratch/resume-20261006-owner-continuation22/map24652-source-comparison/source-comparison.json'],nativeProducer='map24655-native.json',prerequisites=dict(semantic='passed4/4',fullStdlib='passed1/1'),archive=dict(path='evidence.zip',sha256=sha(archive.read_bytes()),entries=len(entries),readbackVerified=True),protectedInputsUnchanged=dict(completed=8,total=8),limitations='limitations.json',claimsGoalComplete=False,claimsWholeC385Closed=False,claimsWholePhaseComplete=False,nextVerification='Resolve remaining source associations and decisions before one exhaustive paired source/runtime sweep and Stage gates; no unchanged original1999 replay or profiling reset.'))
print(json.dumps(dict(evidence=str(E.relative_to(R)),entries=len(entries),archiveBytes=archive.stat().st_size,pairedCompleted=16,pairedTotal=16)))

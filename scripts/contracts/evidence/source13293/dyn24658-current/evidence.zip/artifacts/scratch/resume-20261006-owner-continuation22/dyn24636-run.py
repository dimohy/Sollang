from pathlib import Path
import sys,json,hashlib,time
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'dyn24636-seed-reproduction';C=B/'generic24558-managed/compiler/Sollang.Compiler.exe'
manifest=R/'examples/regression/expected/1999-selfhost-context-fixture-suite.sources.txt';driver=R/'scripts/probes/codegen-resolved-type-names/driver.slg';fixture=R/'scripts/probes/codegen-nominal-capture/input.slg'
sources=[driver,*[R/s for s in manifest.read_text().splitlines()[1:] if s.strip()]]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
files=[Path(__file__),C,*managed_runtime_inputs(C),manifest,fixture,*sources,*sorted((R/'stdlib').rglob('*.slg'))];pins={str(p.resolve()):sha(p) for p in files}
initialize_output(R,O,reusable_directories=[B/'parsing24622-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,cases=[],inputHashes=pins,maximumCaseSeconds=180,csharpFirst='artifacts/scratch/resume-20261006-owner-continuation22/dyn24635-csharp/result.json',scope='Compile and run actual SLG resolved type name implementation with current CSharp seed before any SLG production edit; expected canonical dyn cache.nominal.Value',claimsGoalComplete=False)
 ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None;started=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-started))
 try:
  exe=O/'probe.exe';cmd=[str(C),'build',*[str(p) for p in sources],'-o',str(exe),'--target','windows-x64','--keep-temps','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')]
  done=ex.run(cmd,O/'build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout+done.stderr
  done=ex.run([str(exe),str(fixture)],O/'run',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout+done.stderr
  result['observedStdout']=done.stdout.strip();result['expectedStdout']='dyn cache.nominal.Value';ex.save()
  assert done.stdout.strip()==result['expectedStdout'],repr(done.stdout.strip())
  result.update(status='passed',completed=1,cases=[dict(id='canonical-dyn-name',passed=True)])
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

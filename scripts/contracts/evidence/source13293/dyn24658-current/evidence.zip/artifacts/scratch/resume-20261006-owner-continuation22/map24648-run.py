from pathlib import Path
import sys,json,hashlib,time
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22'
C=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve()
fixtures=list((R/'scripts/probes/map-text-call-identity').glob('*.slg'))
payload=R/'examples/regression/fixtures/303-mapped-source-text.txt'
length=len(payload.read_bytes());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
files=[Path(__file__),C,*(managed_runtime_inputs(C) if C.name!='compiler.exe' else []),payload,*fixtures,*sorted((R/'stdlib').rglob('*.slg')),*sorted((R/'selfhost').rglob('*.slg')),*sorted((R/'src/Sollang.Compiler').rglob('*.cs'))]
pins={str(p.resolve()):sha(p) for p in files}
initialize_output(R,O,reusable_directories=[C.parent if C.name=='compiler.exe' else B/'dyn24642-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=len(fixtures),cases=[],inputHashes=pins,maximumCaseSeconds=180,claimsGoalComplete=False,scope='Canonical mapText direct, nested, ordinary-function and same-named user-function runtime controls')
 ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for fixture in fixtures:
   started=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-started));exe=O/(fixture.stem+'.exe')
   command=[str(C),'build',str(fixture),'-o',str(exe),'--target','windows-x64','--keep-temps','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')]
   if C.name=='compiler.exe':command+=['--stdlib',str(R/'stdlib')]
   done=ex.run(command,O/(fixture.stem+'-build'),timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout+done.stderr
   done=ex.run([str(exe)],O/(fixture.stem+'-run'),timeout=budget())
   expected=['41','42'] if fixture.stem=='shadow' else [str(length)]*(2 if fixture.stem=='direct' else 1)
   assert done.returncode==0 and not done.stderr and done.stdout.splitlines()==expected,done.stdout+done.stderr
   result['cases'].append(dict(id=fixture.stem,passed=True,expected=expected,actual=done.stdout.splitlines()));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

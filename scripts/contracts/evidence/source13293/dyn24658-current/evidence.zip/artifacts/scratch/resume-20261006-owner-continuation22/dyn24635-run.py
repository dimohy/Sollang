from pathlib import Path
import sys,json,hashlib,time,shutil
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'dyn24635-csharp';C=B/'generic24558-managed/compiler/Sollang.Compiler.exe'
fixture=R/'scripts/probes/codegen-nominal-capture/input.slg';control=R/'examples/regression/1432-dyn-trait-reachable-implementations.slg'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
files=[Path(__file__),C,*managed_runtime_inputs(C),fixture,control,R/'examples/regression/expected/1432-dyn-trait-reachable-implementations.stdout.txt',R/'scripts/probes/codegen-identity/Limits.cs',R/'scripts/probes/codegen-identity/CodegenLimits.csproj',R/'Directory.Build.props',R/'global.json',*sorted((R/'src/Sollang.Compiler').rglob('*.cs')),*sorted((R/'stdlib').rglob('*.slg'))]
pins={str(p.resolve()):sha(p) for p in files};initialize_output(R,O,reusable_directories=[B/'parsing24622-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=2,cases=[],inputHashes=pins,maximumCaseSeconds=180,scope='CSharp first canonical dynamic trait name and actual existing1432 compile/run',claimsGoalComplete=False)
 ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None;started=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-started))
 try:
  vec=O/'vectors';vec.mkdir();shutil.copyfile(fixture,vec/'input.slg')
  done=ex.run(['dotnet','build','--disable-build-servers','-nodeReuse:false','-p:UseSharedCompilation=false',str(R/'scripts/probes/codegen-identity/CodegenLimits.csproj'),'-c','Release','-o',str(O/'harness'),'--artifacts-path',str(O/'dotnet-artifacts')],O/'harness-build',timeout=budget());assert done.returncode==0,done.stdout+done.stderr
  done=ex.run(['dotnet',str(O/'harness/CodegenLimits.dll'),str(C.with_suffix('.dll')),str(vec),'registered-type-universe-named-vectors'],O/'names',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout+done.stderr
  observed=json.loads(done.stdout);dyn=observed['records']['DynTraits'];assert len(dyn)==1,dyn
  assert dyn[0]['TraitName']=='cache.nominal.Value',dyn
  typename=observed['typeNames'][str(dyn[0]['Id'])];assert typename=='dyn cache.nominal.Value',typename
  result['cases'].append(dict(id='canonical-dyn-name',passed=True,trait=dyn[0]['TraitName'],display=typename));result['completed']=1;ex.save()
  exe=O/'control.exe'
  done=ex.run([str(C),'build',str(control),'-o',str(exe),'--target','windows-x64','--keep-temps','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')],O/'control-build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout+done.stderr
  done=ex.run([str(exe)],O/'control-run',timeout=budget());assert done.returncode==0 and not done.stderr and done.stdout.strip()=='7',done.stdout+done.stderr
  result['cases'].append(dict(id='original1432',passed=True,stdout='7'));result.update(status='passed',completed=2)
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

from pathlib import Path
import sys,json,hashlib,time
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'dyn24639-seed-controls';C=B/'generic24558-managed/compiler/Sollang.Compiler.exe'
manifest=R/'examples/regression/expected/1999-selfhost-context-fixture-suite.sources.txt';driver=R/'scripts/probes/codegen-resolved-type-names/driver.slg'
sources=[driver,*[R/s for s in manifest.read_text().splitlines()[1:] if s.strip()]]
fixtures=[R/'scripts/probes/codegen-nominal-capture/input.slg',R/'examples/regression/1432-dyn-trait-reachable-implementations.slg',R/'scripts/probes/codegen-resolved-type-names/wrapped.slg']
expected=[['dyn cache.nominal.Value'],['dyn Value'],['Option<dyn cache.type_name.Value>','Result<dyn cache.type_name.Value, Int>','[dyn cache.type_name.Value; ~]','dyn cache.type_name.Value','ref dyn cache.type_name.Value']]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
files=[Path(__file__),C,*managed_runtime_inputs(C),manifest,*fixtures,*sources,B/'dyn24638-canonical-name/source-comparison.json',*sorted((R/'stdlib').rglob('*.slg'))];pins={str(p.resolve()):sha(p) for p in files}
initialize_output(R,O,reusable_directories=[B/'parsing24622-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=3,cases=[],inputHashes=pins,maximumCaseSeconds=180,scope='Post-fix actual SLG metadata helper compiled with CSharp seed; namespace/global/recursive admitted type names',claimsGoalComplete=False)
 ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None;started=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-started))
 try:
  exe=O/'probe.exe';cmd=[str(C),'build',*[str(p) for p in sources],'-o',str(exe),'--target','windows-x64','--keep-temps','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')]
  done=ex.run(cmd,O/'build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout+done.stderr
  for i,fixture in enumerate(fixtures):
   done=ex.run([str(exe),str(fixture)],O/('run-'+str(i)),timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout+done.stderr
   names=sorted(set(done.stdout.splitlines()));assert names==expected[i],names
   result['cases'].append(dict(id=fixture.name,passed=True,expectedNames=expected[i],actualNames=names));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

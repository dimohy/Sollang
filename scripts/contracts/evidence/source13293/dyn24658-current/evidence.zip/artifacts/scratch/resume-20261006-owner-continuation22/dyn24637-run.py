from pathlib import Path
import sys,json,hashlib,time,shutil
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'dyn24637-csharp-controls';C=B/'generic24558-managed/compiler/Sollang.Compiler.exe';H=B/'dyn24635-csharp/harness/CodegenLimits.dll'
fixtures=[R/'examples/regression/1432-dyn-trait-reachable-implementations.slg',R/'scripts/probes/codegen-resolved-type-names/wrapped.slg']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
prior=json.loads((B/'dyn24635-csharp/result.json').read_text());assert prior['status']=='passed' and prior['inputsStable'] and prior['processesStopped'];assert sha(H)==prior['generatedOutputHashes'][str(H)]
files=[Path(__file__),C,*managed_runtime_inputs(C),H,*sorted(H.parent.glob('*.json')),*fixtures,R/'scripts/probes/codegen-identity/Limits.cs',R/'scripts/probes/codegen-identity/CodegenLimits.csproj',*sorted((R/'stdlib').rglob('*.slg'))];pins={str(p.resolve()):sha(p) for p in files}
initialize_output(R,O,reusable_directories=[B/'parsing24622-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=2,cases=[],inputHashes=pins,maximumCaseSeconds=180,scope='CSharp first global dyn identity and admitted recursive wrappers',claimsGoalComplete=False)
 ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None;started=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-started))
 try:
  for index,fixture in enumerate(fixtures):
   vec=O/str(index);vec.mkdir();shutil.copyfile(fixture,vec/'input.slg')
   done=ex.run(['dotnet',str(H),str(C.with_suffix('.dll')),str(vec),'registered-type-universe-named-vectors'],O/('name-'+str(index)),timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout+done.stderr
   obs=json.loads(done.stdout);names=sorted({v for v in obs['typeNames'].values() if 'dyn ' in v});expected='Value' if index==0 else 'cache.type_name.Value';assert len(obs['records']['DynTraits'])==1 and obs['records']['DynTraits'][0]['TraitName']==expected,obs
   assert 'dyn '+expected in names and all(expected+'.'+expected not in s for s in names),names
   if index==1:
    assert len(names)==5,names
    assert 'ref dyn '+expected in names and 'Option<dyn '+expected+'>' in names and '[dyn '+expected+'; ~]' in names,names
   result['cases'].append(dict(id=fixture.name,passed=True,trait=expected,displayNames=names));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped','cases']}))

from pathlib import Path
import sys,json,hashlib,time
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'dyn24646-native-focused4';C=B/'dyn24642-native/compiler.exe'
manifest=R/'scripts/probes/codegen-resolved-type-names/sources.txt';driver=R/'scripts/probes/codegen-resolved-type-names/driver.slg'
sources=[driver,*[R/s for s in manifest.read_text().splitlines()[1:] if s.strip()]]
fixtures=[R/'scripts/probes/codegen-nominal-capture/input.slg',R/'examples/regression/1432-dyn-trait-reachable-implementations.slg',R/'scripts/probes/codegen-resolved-type-names/wrapped.slg']
expected=[['dyn cache.nominal.Value'],['dyn Value'],['Option<dyn cache.type_name.Value>','Result<dyn cache.type_name.Value, Int>','[dyn cache.type_name.Value; ~]','dyn cache.type_name.Value','ref dyn cache.type_name.Value']]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
nativeBuild=B/'dyn24642-native/result.json'
producer=json.loads(nativeBuild.read_text(encoding='utf-8'));assert producer['status']=='passed' and producer['completed']==producer['total']==1 and producer['inputsStable'] and producer['processesStopped'];assert sha(C)==producer['compilerSha256'];assert producer['inputHashesStart']==producer['inputHashesEnd'] and all(sha(p)==h for p,h in producer['inputHashes'].items())
files=[Path(__file__),C,nativeBuild,manifest,*fixtures,*sources,B/'dyn24638-canonical-name/source-comparison.json',B/'dyn24638-canonical-name/current-contract.json',*sorted((R/'stdlib').rglob('*.slg'))];pins={str(p.resolve()):sha(p) for p in files}
initialize_output(R,O,reusable_directories=[B/'dyn24642-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=4,cases=[],inputHashes=pins,maximumCaseSeconds=180,scope='Current Native compiler builds actual SLG metadata helper, then namespace/global/recursive names and original1432 actual runtime are paired with CSharp first4' ,claimsGoalComplete=False)
 ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None;started=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-started))
 try:
  exe=O/'probe.exe';cmd=[str(C),'build',*[str(p) for p in sources],'-o',str(exe),'--target','windows-x64','--keep-temps','--stdlib',str(R/'stdlib'),'-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')]
  done=ex.run(cmd,O/'build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout+done.stderr
  for i,fixture in enumerate(fixtures):
   done=ex.run([str(exe),str(fixture)],O/('run-'+str(i)),timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout+done.stderr
   names=sorted(set(done.stdout.splitlines()));assert names==expected[i],names
   result['cases'].append(dict(id=fixture.name,passed=True,expectedNames=expected[i],actualNames=names));result['completed']+=1;ex.save()
  result['metadataGroupElapsedSeconds']=time.monotonic()-started
  started=time.monotonic()
  control=O/'control.exe'
  done=ex.run([str(C),'build',str(fixtures[1]),'-o',str(control),'--target','windows-x64','--keep-temps','--stdlib',str(R/'stdlib'),'-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')],O/'control-build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout+done.stderr
  done=ex.run([str(control)],O/'control-run',timeout=budget());assert done.returncode==0 and not done.stderr and done.stdout.strip()=='7',done.stdout+done.stderr
  result['cases'].append(dict(id='original1432-runtime',passed=True,stdout='7'));result['completed']+=1
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

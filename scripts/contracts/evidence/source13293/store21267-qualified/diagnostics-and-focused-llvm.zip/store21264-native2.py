from pathlib import Path
import hashlib,json,sys,time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'store21264-native2';CPP=B/'v21262/compiler-build01/compiler.exe'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
rows=[('indexed','conditional-indexed-store.slg','store21249-baseline2'),('member','conditional-member-store.slg','store21253-member-baseline2')]
build=json.loads((CPP.parent/'result.json').read_text());supervisionPath=B/'native21262-supervision/result.json';supervision=json.loads(supervisionPath.read_text());assert build['status']=='passed' and build['inputsStable'] and supervision['processesStopped'] and supervision['inputsStable']
inputs=[Path(__file__),CPP,CPP.parent/'result.json',ROOT/'.tools/llvm-22.1.8/bin/clang.exe',*sorted((ROOT/'stdlib').rglob('*.slg'))]
expected={}
for id,source,baseline in rows:
 source=ROOT/'scripts/probes/codegen-identity'/source;baseline=B/baseline/'result.json';r=json.loads(baseline.read_text());assert sha(source)==r['inputHashes'][str(source)]
 case=next(c for c in r['cases'] if c['id']=='csharp');assert case['passed'] and case['buildExit']==case['runExit']==0
 expected[id]=case['stdout'];inputs.extend([source,baseline])
inputs.append(supervisionPath)
for p,h in build['inputHashesStart'].items():
 assert sha(p)==h,p
 inputs.append(Path(p))
inputs=list(dict.fromkeys(inputs));hashes={str(p):sha(p) for p in inputs}
initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21262']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=2,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='C767 actual current Native indexed/member stores against unchanged CSharp-first runtime oracles; ordinary binding controls included',claimsGoalComplete=False)
 run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  for id,source,baseline in rows:
   d=OUT/id;d.mkdir();start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start))
   built=run.run([str(CPP),'build',str(ROOT/'scripts/probes/codegen-identity'/source),'-o',str(d/'probe.exe'),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0','--keep-temps'],d/'build',timeout=budget())
   assert built.returncode==0 and not built.stderr,built.stdout[-1500:]+built.stderr
   ll=d/'probe.exe.ll';text=ll.read_text(encoding='utf-8');assert 'S032' not in text
   executed=run.run([str(d/'probe.exe')],d/'run',timeout=budget())
   passed=executed.returncode==0 and executed.stdout==expected[id] and not executed.stderr and time.monotonic()-start<=180
   result['cases'].append(dict(id=id,passed=passed,buildExit=built.returncode,runExit=executed.returncode,stdout=executed.stdout,stderr=executed.stderr,llvmSha256=sha(ll),wholeCaseElapsedSeconds=time.monotonic()-start,csharpBaseline=str(B/baseline/'result.json')));result['completed']+=int(passed);run.save()
  result['status']='passed' if result['completed']==result['total'] else 'failed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error

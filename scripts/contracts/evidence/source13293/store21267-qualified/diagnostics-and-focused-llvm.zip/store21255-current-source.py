from pathlib import Path
import hashlib, json, struct, sys, time
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output

B = ROOT / 'artifacts/scratch/resume-20261006-owner-continuation22'
OUT = B / 'store21255-current-source'
COMPILER = B / 'managed21139/compiler/Sollang.Compiler.exe'
CLANG = ROOT / '.tools/llvm-22.1.8/bin/clang.exe'
MANIFEST = ROOT / 'tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.sources.txt'
PROBE = ROOT / 'scripts/probes/codegen-identity/library-emitter-contract.slg'
SEMANTIC = B / 'store21256-semantic/result.json'
COMPARISON = ROOT / 'scripts/contracts/evidence/source13293/library21130-source-root/source-comparison.json'
providers = [ROOT / x for x in MANIFEST.read_text(encoding='utf-8').splitlines() if x and not x.endswith('selfhost-sollangc-driver.slg')]
base = ROOT / 'scripts/probes/codegen-identity'
positive = [dict(id='basic', source=base/'library-export.slg', oracle=B/'library21049-int32-baseline2/managed/math.windows-x64.slglib.json', values={'increase':8}),
            dict(id='shapes', source=base/'library-export-shapes.slg', oracle=B/'library21096-csharp-shapes/math.windows-x64.slglib.json', values={'increase':8,'reset':None,'sum':42})]
negative = [('no-public', 'a Sollang shared library must declare at least one public function'),
            ('native-int', "public library function 'invalid' input type 'Int' is not ABI-safe; use Unit or a fixed-width numeric scalar"),
            ('effects', "public library function 'output' must not require effects"),
            ('generic', "type 'GenericParameter' is not a fixed-width library ABI type")]
PREFIX = B / 'reserved21147-csharp7/result.json'
prefixProof = json.loads(PREFIX.read_text(encoding='utf-8'))
assert prefixProof['status']=='passed' and prefixProof['completed']==prefixProof['total']==7
prefixInputs=[PREFIX, *[B/'reserved21129-csharp7'/r['id']/'input.slg' for r in prefixProof['cases']], *[B/'reserved21147-csharp7'/r['id']/'math.windows-x64.slglib.json' for r in prefixProof['cases'] if r['exit']==0]]
ORDINARY = ROOT/'scripts/probes/codegen-identity/conditional-indexed-store.slg'
inputs = [*prefixInputs, ORDINARY, Path(__file__), MANIFEST, PROBE, SEMANTIC, COMPARISON, CLANG, *providers, *managed_runtime_inputs(COMPILER),
          *sorted((ROOT/'stdlib').rglob('*.slg')), *[row['source'] for row in positive], *[row['oracle'] for row in positive],
          *[base/('library-'+name+'.slg') for name,_ in negative],
          *[ROOT/'scripts'/x for x in ['verification_execution.py','verification_contract_lease.py','verification_fingerprints.py','verification_json_records.py','completed_artifact_plan.py','ArtifactLifecycle.ps1','contracts/artifact-lifecycle.json']]]
inputs += [ROOT/'.tools/llvm-22.1.8/bin/llvm-lib.exe', ROOT/'.tools/llvm-22.1.8/bin/llvm-as.exe', ROOT/'tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.slg']
inputs += [ROOT/'scripts/probes/codegen-identity/conditional-member-store.slg', ROOT/'scripts/contracts/evidence/source13293/store21251-baseline/source-comparison.json']
inputs = list(dict.fromkeys(p.resolve() for p in inputs))
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert sha(COMPILER.with_suffix('.dll')) == 'B838CF7C48EF32FFA96ACA2D6B8197645AF8C070D30C48C233DDE65A94FA991E'
proof = json.loads(SEMANTIC.read_text(encoding='utf-8'))
assert proof['status']=='passed' and proof['inputsStable'] and proof['processesStopped'] and proof['completed']==proof['total']==4 and not proof['codegenInvoked']
for p in providers:
    assert sha(p)==proof['inputHashes'][str(p)], p
initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21212']])
OUT.mkdir(exist_ok=False)
invoke = '''import ctypes,json,os,sys
from pathlib import Path
p=Path(sys.argv[1]).resolve();j=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'));lib=ctypes.CDLL(str(p))
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetModuleFileNameW.argtypes=[ctypes.c_void_p,ctypes.c_wchar_p,ctypes.c_uint];k.GetModuleFileNameW.restype=ctypes.c_uint
buf=ctypes.create_unicode_buffer(32768);assert k.GetModuleFileNameW(lib._handle,buf,len(buf));assert os.path.normcase(str(Path(buf.value).resolve()))==os.path.normcase(str(p))
values={}
for e in j['exports']:
 f=getattr(lib,e['symbol']);f.argtypes=[ctypes.c_int32]*len(e['parameters']);f.restype=None if e['result']=='Unit' else ctypes.c_int32
 args={'increase':[7],'sum':[20,22],'reset':[]}[e['name']];values[e['name']]=f(*args)
print(json.dumps({'module':str(p),'values':values},sort_keys=True))
'''
with VerificationContractLease(inputs):
    hashes={str(p):sha(p) for p in inputs}
    stable=lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs)
    result=dict(schemaVersion=1,status='running',completed=0,total=4,cases=[],inputHashes=hashes,maximumCaseSeconds=180,
                scope='focused-CSharp-compiled-SLG-current-emitter-product',claimsGoalComplete=False,claimsCurrentGeneralNativeCompiler=False)
    run=VerificationExecution(ROOT,OUT,result,stable,sha)
    error=None
    try:
        command=[str(COMPILER),'build',str(PROBE),*map(str,providers),'-o',str(OUT/'emitter.exe'),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0','--keep-temps']
        built=run.run(command,OUT/'build',timeout=180)
        if built.returncode:raise RuntimeError('FOCUSED_EMITTER_BUILD_FAILED: '+built.stderr[-3000:])
        result['cases'].append(dict(id='focused-emitter-build',passed=True));result['completed']+=1;run.save()
        definition=OUT/'ucrt.def';definition.write_text('LIBRARY ucrtbase.dll\nEXPORTS\n_wspawnvp\nmemcpy\nstrlen\ngetchar\n',encoding='utf-8')
        importLib=OUT/'ucrt.lib'
        importResult=run.run([str(ROOT/'.tools/llvm-22.1.8/bin/llvm-lib.exe'),'/nologo','/machine:x64','/def:'+str(definition),'/out:'+str(importLib)],OUT/'import-library',timeout=180)
        assert importResult.returncode==0,importResult.stderr
        for case in positive[:1]:
            start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start))
            directory=OUT/case['id'];directory.mkdir();interface=directory/'math.windows-x64.slglib.json'
            emitted=run.run([str(OUT/'emitter.exe'),'library',str(interface),str(ROOT/'stdlib'),str(case['source'])],directory/'emit',timeout=budget())
            if emitted.returncode:raise RuntimeError('LIBRARY_EMISSION_FAILED: '+emitted.stdout[-2000:]+emitted.stderr[-2000:])
            document=json.loads(interface.read_text(encoding='utf-8'));expected=json.loads(case['oracle'].read_text(encoding='utf-8'))
            if document!=expected:raise RuntimeError('LIBRARY_INTERFACE_VALUE_MISMATCH: '+case['id'])
            llvm=directory/'math.ll';llvm.write_bytes((directory/'emit.stdout').read_bytes())
            assert 'define void @sollang_start' not in emitted.stdout and 'define i32 @main(' not in emitted.stdout
            linked=run.run([str(CLANG),str(llvm),'-O0','-Wno-override-module','-shared','-Xlinker','/noentry','-o',str(directory/'math.dll'),str(importLib),'-lkernel32','-lshell32','-lws2_32','-lbcrypt'],directory/'link',timeout=budget())
            if linked.returncode:raise RuntimeError('LIBRARY_LINK_FAILED: '+linked.stderr[-2500:])
            binary=(directory/'math.dll').read_bytes();pe=struct.unpack_from('<I',binary,0x3c)[0];assert struct.unpack_from('<H',binary,pe+22)[0]&0x2000
            called=run.run([sys.executable,'-c',invoke,str(directory/'math.dll'),str(interface)],directory/'invoke',timeout=budget())
            if called.returncode or called.stderr:raise RuntimeError('LIBRARY_INVOCATION_FAILED: '+called.stderr[-2000:])
            actual=json.loads(called.stdout);assert actual['values']==case['values']
            assert time.monotonic()-start<=180
            result['cases'].append(dict(id=case['id'],passed=True,module=actual['module'],values=actual['values'],interfaceSha256=sha(interface),durationMilliseconds=round((time.monotonic()-start)*1000)))
            result['completed']+=1;run.save()
        directory=OUT/'native-ordinary';directory.mkdir();start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start))
        observed=run.run([str(OUT/'emitter.exe'),'ordinary','unused',str(ROOT/'stdlib'),str(ORDINARY)],directory/'emit',timeout=budget())
        assert observed.returncode==0 and not observed.stderr,observed.stdout[-2000:]+observed.stderr
        llvm=directory/'ordinary.ll';llvm.write_bytes((directory/'emit.stdout').read_bytes())
        assert 'define dllexport' not in observed.stdout
        linked=run.run([str(CLANG),str(llvm),'-O0','-Wno-override-module','-o',str(directory/'ordinary.exe'),'-Xlinker','/subsystem:console','-lkernel32','-lshell32','-lws2_32','-lbcrypt'],directory/'link',timeout=budget())
        assert linked.returncode==0,linked.stderr
        executed=run.run([str(directory/'ordinary.exe')],directory/'run',timeout=budget())
        passed=executed.returncode==0 and executed.stdout=='each-if\n1027\n1028\n1029\nwhile-if\n1027\n1028\n1029\neach-direct\n4\n5\n6\n' and not executed.stderr and time.monotonic()-start<=180
        result['cases'].append(dict(id='native-ordinary-control',passed=passed));result['completed']+=int(passed);run.save()
        directory=OUT/'member';directory.mkdir();start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start))
        observed=run.run([str(OUT/'emitter.exe'),'ordinary','unused',str(ROOT/'stdlib'),str(ROOT/'scripts/probes/codegen-identity/conditional-member-store.slg')],directory/'emit',timeout=budget())
        assert observed.returncode==0 and not observed.stderr,observed.stdout[-2000:]+observed.stderr
        llvm=directory/'member.ll';llvm.write_bytes((directory/'emit.stdout').read_bytes());assert 'S032' not in observed.stdout
        linked=run.run([str(CLANG),str(llvm),'-O0','-Wno-override-module','-o',str(directory/'member.exe'),'-Xlinker','/subsystem:console','-lkernel32','-lshell32','-lws2_32','-lbcrypt'],directory/'link',timeout=budget());assert linked.returncode==0,linked.stderr
        executed=run.run([str(directory/'member.exe')],directory/'run',timeout=budget());passed=executed.returncode==0 and executed.stdout=='42\n' and not executed.stderr and time.monotonic()-start<=180
        result['cases'].append(dict(id='member-store',passed=passed));result['completed']+=int(passed);run.save()
        result['status']='passed' if result['completed']==result['total'] else 'failed'
    except BaseException as caught:error=caught
    finally:run.finalize(error,cleanup=False)
    print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))
    if error:raise error

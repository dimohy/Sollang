from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
parentPath=B/'store21255-current-source/result.json'
parent=json.loads(parentPath.read_text())
assert parent['status']=='passed' and parent['completed']==parent['total']==4 and parent['inputsStable'] and parent['processesStopped']
paths=[Path(p) for p in parent['inputHashes']]+[parentPath,Path(__file__),ROOT/'.tools/llvm-22.1.8/bin/llvm-as.exe']
for p,h in parent['inputHashes'].items():assert sha(p)==h,p
llvmCases=[('conditional-indexed-store',B/'store21255-current-source/native-ordinary/ordinary.ll','ordinary.exe'),('conditional-member-store',B/'store21255-current-source/member/member.ll','member.exe')]
paths.extend(p for _,p,_ in llvmCases)
hashes={str(p):sha(p) for p in paths}
stable=lambda:all(Path(p).is_file() and sha(p)==h for p,h in hashes.items())
OUT=B/'store21262-emission2'
initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21212']])
OUT.mkdir(exist_ok=False)
with VerificationContractLease(paths):
 result=dict(schemaVersion=1,status='running',completed=0,total=2,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='verified-llvm-emission-subset',mode='managed',semanticPreflight=dict(status='passed-current-source',proof=str(B/'store21256-semantic/result.json'),codegenInvoked=False),parentProof=str(parentPath),claimsGoalComplete=False)
 run=VerificationExecution(ROOT,OUT,result,stable,sha);error=None
 try:
  for id,llvm,exe in llvmCases:
   p=run.run([str(ROOT/'.tools/llvm-22.1.8/bin/llvm-as.exe'),str(llvm),'-o',str(OUT/(id+'.bc'))],OUT/id,timeout=180)
   link=next(p for p in parent['processes'] if str(llvm) in p['command'] and '-o' in p['command'])
   execute=next(p for p in parent['processes'] if len(p['command'])==1 and Path(p['command'][0]).name==exe)
   assert p.returncode==link['exit']==execute['exit']==0
   result['cases'].append(dict(id=id,passed=True,status='passed',emittedLlvmSha256=sha(llvm),assemblyExit=p.returncode,nativeLinkExit=link['exit'],nativeRunExit=execute['exit'],parentConsumer=execute['command']))
   result['completed']+=1;run.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
proofs=[B/'store21256-semantic/result.json',OUT/'result.json',B/'store21258-stdlib/result.json']
plan=json.loads((B/'native21212-plan.json').read_text())
command=plan['command']
for old,new in [('v21212','v21262'),('rebind21204-semantic','store21256-semantic'),('rebind21211-emission2','store21262-emission2'),('rebind21208-stdlib','store21258-stdlib')]:command=[x.replace(old,new) for x in command]
buildPaths=[Path(__file__),ROOT/'scripts/build-focused-selfhost-compiler.ps1',ROOT/'scripts/focused-selfhost-input-contract.ps1',ROOT/'scripts/verification_execution.py',ROOT/'scripts/verification_contract_lease.py']
for proof in proofs:
 r=json.loads(proof.read_text());assert r['status']=='passed' and r['inputsStable'] and r['processesStopped']
 buildPaths.append(proof)
 for p,h in r['inputHashes'].items():
  assert sha(p)==h,p
  buildPaths.append(Path(p))
buildPaths=list(dict.fromkeys(buildPaths));buildHashes={str(p):sha(p) for p in buildPaths}
plan.update(command=command,inputHashes=buildHashes,purpose='One current Native build for C767 after CSharp-first paired baselines, source comparison, semantic4, source execution4, LLVM2 and full stdlib source1. No unchanged integration66/SLG111/Native100 replay.')
planPath=B/'native21262-plan.json';planPath.write_text(json.dumps(plan,indent=2)+'\n')
buildPaths.append(planPath);buildHashes[str(planPath)]=sha(planPath)
OUT=B/'native21262-supervision';OUT.mkdir(exist_ok=False)
with VerificationContractLease(buildPaths):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,cases=[],inputHashes=buildHashes,maximumTotalSeconds=180,claimsGoalComplete=False)
 run=VerificationExecution(ROOT,OUT,result,lambda:all(Path(p).is_file() and sha(p)==h for p,h in buildHashes.items()),sha);error=None
 try:
  p=run.run(command,OUT/'build',timeout=180)
  result['cases'].append(dict(id='canonical-native-build',passed=p.returncode==0,exit=p.returncode));result['completed']=int(p.returncode==0)
  result['status']='observed-not-qualified' if p.returncode==0 else 'failed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error

define i32 @sollang_m146_s2(i32 %arg) {
entry:
  %v631360192520_ptr = insertvalue %sollang.text poison, ptr @sollang_str_631360192520, 0
  %v631360192520 = insertvalue %sollang.text %v631360192520_ptr, i64 4, 1
  call void @sollang_runtime_print(ptr @sollang_str_631360192520, i64 4, i1 true)
  %v631360192522 = call i32 @sollang_m146_s0_g118493(i32 %arg)
  %v631360192521 = add i32 %v631360192522, 3
  ret i32 %v631360192521
}
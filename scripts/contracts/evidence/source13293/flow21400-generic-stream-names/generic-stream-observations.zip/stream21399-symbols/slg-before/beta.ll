define i32 @sollang_m146_s0(i32 %arg) {
entry:
  %slot631360192516 = alloca i32, align 4
  %v631360192519_ptr = insertvalue %sollang.text poison, ptr @sollang_str_631360192519, 0
  %v631360192519 = insertvalue %sollang.text %v631360192519_ptr, i64 4, 1
  %v631360192525 = freeze i32 %arg
  call void @sollang_runtime_print(ptr @sollang_str_631360192519, i64 4, i1 true)
  %v631360192521_start = insertvalue { i32, i32 } poison, i32 1, 0
  %v631360192521 = insertvalue { i32, i32 } %v631360192521_start, i32 3, 1
  store i32 %arg, ptr %slot631360192516, align 4
  %stream118126_index_slot = alloca i32, align 4
  %stream118126_slice1_slot = alloca i32, align 4
  store i32 0, ptr %stream118126_slice1_slot, align 4
  store i32 1, ptr %stream118126_index_slot, align 4
  %stream118126_end = add i32 3, 0
  br label %stream118126_header
stream118126_header:
  %stream118126_item = load i32, ptr %stream118126_index_slot, align 4
  %stream118126_done = icmp sgt i32 %stream118126_item, %stream118126_end
  br i1 %stream118126_done, label %stream118126_exit, label %stream118126_body
stream118126_body:
  %v631360192524 = freeze i32 %arg
  %stream118126_taken1 = load i32, ptr %stream118126_slice1_slot, align 4
  %stream118126_take_open1 = icmp slt i32 %stream118126_taken1, 1
  br i1 %stream118126_take_open1, label %stream118126_take_pass1, label %stream118126_exit
stream118126_take_pass1:
  %stream118126_taken_next1 = add i32 %stream118126_taken1, 1
  store i32 %stream118126_taken_next1, ptr %stream118126_slice1_slot, align 4
  %v631360192530 = load i32, ptr %slot631360192516, align 4
  %v631360192529 = add i32 %v631360192530, 3
  store i32 %v631360192529, ptr %slot631360192516, align 4
  br label %stream118126_continue
stream118126_continue:
  %stream118126_current = load i32, ptr %stream118126_index_slot, align 4
  %stream118126_last = icmp sge i32 %stream118126_current, %stream118126_end
  %stream118126_next = add i32 %stream118126_current, 1
  store i32 %stream118126_next, ptr %stream118126_index_slot, align 4
  %stream118126_taken_done_value = load i32, ptr %stream118126_slice1_slot, align 4
  %stream118126_taken_done = icmp sge i32 %stream118126_taken_done_value, 1
  br i1 %stream118126_taken_done, label %stream118126_exit, label %stream118126_range_continue
stream118126_range_continue:
  br i1 %stream118126_last, label %stream118126_exit, label %stream118126_header
stream118126_exit:
  %v631360192532 = load i32, ptr %slot631360192516, align 4
  ret i32 %v631360192532
}
#include "W:/MyWorks/Sollang/tests/native-interop/owned_array_audit.c"
int slg_program_main(void) { return CONTROL_RESULT; }

from pathlib import Path
import json, hashlib, re, shutil
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22'
out=b/'arguments20760-faults16';data=b/'arguments20759-fault-inputs';data.mkdir(exist_ok=True)
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
contract=json.loads((r/'scripts/contracts/arguments-runtime.json').read_text(encoding='utf-8-sig'))
faults=[x for x in contract['cases'] if 'failureKind' in x];assert len(faults)==6
c=dict(scope='Current CSharp and sourceSDK LLVM. Original argument allocation/conversion fault ordinals and allocation/release counts, six per side plus4 audit exit-oracle controls. No compiler replay.',output=str(out),total=16,totalBudgetSeconds=2880,maximumCaseSeconds=180,cases=[],inputHashes={},reusableDirectories=[str(b/f'v{n}/compiler-build01') for n in [18915,20050,20656]])
clang=r/'.tools/llvm-22.1.8/bin/clang.exe';shim=r/'tests/native-interop/arguments_runtime_audit.c';baseLog=b/'arguments20744-managed6/build'
inputs=[r/'scripts/contracts/arguments-runtime.json',shim,shim.with_name('owned_array_audit.c'),clang,Path(__file__).resolve()]
def oracle(name, stdout):
    p=data/name
    p.with_suffix('.stdout').write_text(stdout,encoding='utf-8')
    p.with_suffix('.stderr').write_text('',encoding='utf-8')
    return p
def add(name, command, arguments, expectedExit, expectedOutput):
    exe=out/name/'probe.exe';p=oracle(name,expectedOutput)
    c['cases'].append(dict(case=dict(id=name,target='windows-x64',expectedBuildExit=0),steps=[dict(kind='build',command=command+['-o',str(exe)],expectedExit=0,originalLog=str(baseLog)),dict(kind='run',command=[str(exe),*arguments],expectedExit=expectedExit,originalLog=str(p))]))
for side,path in [('managed',b/'arguments20744-managed6/probe.exe.ll'),('sdk',b/'arguments20754-source1/windows-arguments/emitted.ll')]:
    text=path.read_text(encoding='utf-8-sig')
    text=re.sub(r'@(?:sollang_start|main)\(\)','@slg_program_main()',text)
    assert len(re.findall(r'^define (?:dso_local )?i32 @slg_program_main\(',text,re.M))==1
    text=text.replace('call ptr @sollang_alloc(', 'call ptr @audit_malloc(').replace('call void @sollang_free(', 'call void @audit_free(').replace('@WideCharToMultiByte(', '@audit_WideCharToMultiByte(').replace('declare dllimport i32 @audit_WideCharToMultiByte','declare i32 @audit_WideCharToMultiByte')
    text+='\ndeclare ptr @audit_malloc(i64)\ndeclare void @audit_free(ptr)\n'
    ll=data/(side+'.ll');ll.write_text(text,encoding='utf-8');inputs.extend([path,ll])
    for f in faults:
        name=side+'-'+f['name'];n=f['allocations']
        command=[str(clang),'-Wno-override-module',str(ll),str(shim),'-O1',f'-DEXPECTED_ALLOCATIONS={n}','-DEXPECTED_EXIT_CODE=1',f'-DFAIL_{f["failureKind"]}={f["failureOrdinal"]}','-lshell32','-lbcrypt','-lws2_32','-lole32']
        add(name,command,f['arguments'],0,f'0\nallocations={n},releases={n}\n')
control=data/'control.c'
control.write_text('#include "'+str(shim.with_name('owned_array_audit.c')).replace('\\','/')+'"\nint slg_program_main(void) { return CONTROL_RESULT; }\n',encoding='utf-8')
for expected,actual in [(0,0),(1,1),(0,1),(1,0)]:
    name=f'audit-exit-{expected}-{actual}'
    command=[str(clang),str(control),'-DEXPECTED_ALLOCATIONS=0',f'-DEXPECTED_EXIT_CODE={expected}',f'-DCONTROL_RESULT={actual}']
    add(name,command,[],int(expected!=actual),'allocations=0,releases=0\n')
inputs += [control,*data.glob('*.stdout'),*data.glob('*.stderr')]
c['inputHashes']={str(p):H(p) for p in inputs}
shutil.copyfile(b/'userblock20725-run.py',b/'arguments20760-run.py')
(b/'arguments20760-run.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')

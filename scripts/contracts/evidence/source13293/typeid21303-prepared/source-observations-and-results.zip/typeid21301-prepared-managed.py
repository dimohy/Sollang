import pathlib,json,hashlib,sys
ROOT=pathlib.Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OLD=B/'typeid21280-definition-observer';OUT=B/sys.argv[1];record=json.loads((OLD/'result.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest().upper();base=ROOT/'scripts/probes/codegen-identity';probe=base/'type-registration-prepared-contract.slg';modules=[base/x for x in ['reference-type-ids-prototype.slg','reference-synthetic-type-ids-prototype.slg','reference-prepared-type-ids-prototype.slg']]
inputs=[pathlib.Path(p) for p in record['inputHashes']]
for p in inputs:assert sha(p)==record['inputHashes'][str(p)],str(p)
inputs+=[pathlib.Path(__file__),probe,*modules,OLD/'result.json',*sorted((B/'typeid21299-prepared-oracles').iterdir())];hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21262']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=4,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Current SemanticSnapshot constructor TypeId registration against preserved independently checked CSharp metadata, not production ABI diagnostic qualification',claimsGoalComplete=False)
 run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  for i,p in enumerate(record['processes']):
   label='build' if i==0 else ['readonly','struct','fixed-array'][i-1];cmd=[s.replace(str(OLD),str(OUT)).replace(str(base/'type-registration-definition-observer.slg'),str(probe)) for s in p['command']]
   if i==0:cmd[cmd.index('-o'):cmd.index('-o')]=list(map(str,modules))
   done=run.run(cmd,OUT/label,timeout=180);assert done.returncode==0 and not done.stderr,done.stdout[-1500:]+done.stderr
   if i:
    expected=(B/'typeid21299-prepared-oracles'/(label+'.expected')).read_text(encoding='utf-8');passed=done.stdout==expected;detail=dict(matchesExpected=passed,registeredTypeCount=len(done.stdout.splitlines())-1);assert passed,'OUTPUT_MISMATCH '+label
   else:detail={}
   result['cases'].append(dict(id=label,passed=True,**detail));result['completed']+=1;run.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','cases','inputsStable','processesStopped']},indent=2))

from pathlib import Path
import json,hashlib,sys
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(r/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
old=json.loads((b/'managed19361/result.json').read_text(encoding='utf-8-sig'))
command=[a.replace('managed19361','managed19729') for a in old['processes'][0]['command']]
paths=[Path(p) for p in old['inputHashes'] if 'managed19361' not in p]+[Path(__file__)]
assert all(p.is_file() for p in paths)
assert any('UseSharedCompilation=false' in a for a in command) and any('nodeReuse:false' in a for a in command)
out=b/'managed19729';out.mkdir(exist_ok=False)
with VerificationContractLease(paths):
 pins={str(p):sha(p) for p in paths};d=dict(schemaVersion=1,status='running',completed=0,total=1,inputHashes=pins,
  scope='C754 CSharp first: semantic diagnostics retain source module during main interpolation, per SPEC. Existing isolated build command,180 seconds. No acceptance claim.',claimsGoalComplete=False)
 x=VerificationExecution(r,out,d,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  observed=x.run(command,out/'build',timeout=180);assert observed.returncode==0,observed.stderr
  d.update(status='passed',completed=1,compilerDllSha256=sha(out/'compiler/Sollang.Compiler.dll'))
 except BaseException as failure:error=failure
 finally:x.finalize(error,cleanup=False)
 print(json.dumps({k:d.get(k) for k in ['status','inputsStable','processesStopped','failure','compilerDllSha256']}))
 if error:raise error

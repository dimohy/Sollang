from pathlib import Path
import json,hashlib,shutil,subprocess
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293';O=B/'ledger25396';O.mkdir(exist_ok=False)
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
write=lambda p,d:Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(R/'scripts/contracts/compiler-defects.json',O/'ledger-before.json')
units=[
(792,B/'bitset25064-native/result.json',E/'bitset25135-current/native.json',1,2,'selfhost/llvm/codegen_registered_universe.slg','Retain BitSet identity validation while applying the shared CSharp universe category selection; do not invent a standalone layout category.',E/'bitset25135-current/source-comparison.json'),
(793,B/'bitset25090-prepared-before/result.json',B/'bitset25092-prepared-after/result.json',1,1,'selfhost/semantic/reference_synthetic_type_ids.slg','Preserve positive BitSet length as a dedicated interned synthetic kind and register it before references. Exact same full225-source CSharp-built production API, not the later70-source Native run.',E/'bitset25135-current/source-comparison.json'),
(794,B/'bitset25113-tls-before/result.json',E/'bitset25135-current/managedTlsLink.json',1,1,'src/Sollang.Compiler/Shared/Policies/WindowsLinkPolicy.cs','Use the same immutable Native-generated LLVM and production CSharp linker; the shared TLS import contract supplies all four missing exports.',E/'bitset25135-current/source-comparison.json'),
(795,B/'bitset25131-native-linker/result.json',E/'ownership25175-current/nativeLinker.json',0,0,'selfhost/semantic/ownership_check.slg','Follow the canonical selected returned match through validated parent/result edges; preserve partial-move rejection on continuing branches.',E/'ownership25175-current/source-comparison.json'),
(796,B/'ownership25150-csharp-error-observe/result.json',E/'ownership25175-current/managedError.json',1,1,'src/Sollang.Compiler/CodeGen/LlvmEmitter.Enums.cs','Normalize enum outer owners through canonical DropOwnedLocal under the actual edge scope, preserving transferred fields; unchanged O0/O1 Err source now runs successfully.',E/'ownership25175-current/source-comparison.json'),
(797,B/'ownership25153-csharp/result.json',E/'ownership25175-current/managed.json',3,3,'src/Sollang.Compiler/CodeGen/LlvmEmitter.Expressions.Control.cs','E20 reports the symmetric difference of incoming move states; the dominating child move is not an affected field. Baseline runner accepted an older diagnostic, so use the raw exact diagnostic rather than its passed flag.',E/'ownership25175-current/source-comparison.json')]
manifest=[]
for n,bp,cp,bi,ci,authority,reason,source in units:
 identity=f'C2026-11-03-{n}';d=R/'scripts/contracts/evidence'/identity;assert not d.exists(),d
 before=read(bp);after=read(cp)
 assert before['inputsStable'] and before['processesStopped'] and after['inputsStable'] and after['processesStopped'] and after['status']=='passed'
 procs=[]
 for rec,index in [(before,bi),(after,ci)]:
  x=rec['processes'][index];assert x['shutdownConfirmed'];logs={}
  for field in ['stdout','stderr']:
   p=Path(x[field+'Path']);assert sha(p)==x[field+'Sha256'];logs[field]=p.read_text(encoding='utf-8-sig')
  procs.append((x,logs))
 # Explicitly inspect the actual observed failure and repaired behavior.
 bs=procs[0][1];cs=procs[1][1]
 if n==792:assert 'capture failed' in bs['stderr'] and procs[0][0]['exit']==1 and procs[1][0]['exit']==0
 if n==793:
  assert 'declarations:error:invalid-type' in bs['stdout'] and 'resolved-uses:error:invalid-type' in bs['stdout'] and ':error:' not in cs['stdout']
  assert [x for x in before['processes'][0]['command'] if x.endswith('.slg')]==[x for x in after['processes'][0]['command'] if x.endswith('.slg')]
 if n==794:assert all(x in bs['stderr'] for x in ['TlsAlloc','TlsGetValue','TlsSetValue','TlsFree']) and procs[1][0]['exit']==0
 if n==795:assert 'partial move' in bs['stderr'] and procs[1][0]['exit']==0
 if n==796:assert procs[0][0]['exit']==3221226356 and procs[1][0]['exit']==0 and cs['stdout']=='failed\n'
 if n==797:assert "'child, error, output, program'" in bs['stderr'] and "'error, output, program'" in cs['stderr']
 common={p:h for p,h in before['inputHashes'].items() if after['inputHashes'].get(p)==h}
 stable={p:h for p,h in common.items() if p.endswith('.slg') or '\\stdlib\\' in p}
 if n==794:
  ir=[p for p in common if p.endswith('.ll')];assert len(ir)==1;stable={p:h for p,h in common.items() if p in ir or p.endswith(('Program.cs','TlsLinker.csproj','WindowsLinker.cs','clang.exe','llvm-lib.exe','lld-link.exe'))};assert ir[0] in stable
 assert stable
 delta={p:dict(baseline=h,candidate=after['inputHashes'][p]) for p,h in before['inputHashes'].items() if p in after['inputHashes'] and after['inputHashes'][p]!=h}
 contract=dict(schemaVersion=1,defectId=identity,scope='Historical unchanged source/input linkage and actual observed process outputs. Compiler implementation changes and product hashes are separately preserved; this is not current compiler requalification.',stableInputHashes=stable,implementationAndRunnerDelta=delta,baselineRecord=bp.relative_to(R).as_posix(),candidateRecord=cp.relative_to(R).as_posix(),baselineRecordSha256=sha(bp),candidateRecordSha256=sha(cp),baselineSelectedProcess=bi,candidateSelectedProcess=ci,claimsDefectClosed=False,claimsCurrentCompilerVerified=False)
 raw=json.dumps(contract,sort_keys=True,separators=(',',':')).encode();finger=hashlib.sha256(raw).hexdigest().upper();d.mkdir()
 write(d/'input-contract.json',contract);shutil.copyfile(bp,d/'baseline-execution.json');shutil.copyfile(cp,d/'candidate-execution.json');shutil.copyfile(source,d/'source-comparison.json')
 for phase,(_,logs) in zip(['baseline','candidate'],procs):
  for stream,value in logs.items():(d/(phase+'.'+stream+'.txt')).write_text(value,encoding='utf-8')
 def observe(rec,logs):return json.dumps(dict(observedExit=rec['exit'],stdout=logs['stdout'],stderr=logs['stderr']),ensure_ascii=False,indent=2)
 def command(xs):return subprocess.list2cmdline(xs)
 base=d.relative_to(R).as_posix();manifest.append(dict(DefectId=identity,InputFingerprint=finger,BaselineCommand=command(procs[0][0]['command']),BaselineObservation=observe(*procs[0]),BaselineProvenance=f'Historical execution, not replayed: {bp.relative_to(R).as_posix()}, process {bi}; all preserved selected stdout/stderr SHA256 values verified.',BaselineExitCode=procs[0][0]['exit'],BaselineExpectedExitCode=procs[0][0]['exit'],CandidateCommand=command(procs[1][0]['command']),CandidateObservation=observe(*procs[1]),CandidateProvenance=f'Historical execution, not replayed: {cp.relative_to(R).as_posix()}, process {ci}; exact unchanged input contract and raw logs preserved. Final gates remain pending.',CandidateExitCode=procs[1][0]['exit'],CandidateExpectedExitCode=procs[1][0]['exit'],Reason=reason,AssetKind='invariant',AuthorityPath=authority,SourceEvidence=[base+'/baseline-execution.json',base+'/input-contract.json',base+'/source-comparison.json'],ValidatorEvidence=[base+'/candidate-execution.json'],ConsumerEvidence=[authority,base+'/candidate-execution.json']))
write(O/'preservation-inputs.json',manifest)
print(json.dumps(dict(preflight='passed',units=len(manifest),compilerBuilds=0,compilerRuns=0,excluded791='Stored CLI baseline fails at cache capture before arithmetic. No same-input arithmetic failure execution identified; do not fabricate one.')))

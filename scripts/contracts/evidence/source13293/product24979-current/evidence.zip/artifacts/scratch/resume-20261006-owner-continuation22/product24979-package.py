from pathlib import Path
import datetime,hashlib,json,subprocess,zipfile
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/product24979-current'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
write=lambda p,d:Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
records=dict(csharp='product24971-csharp',nativeBefore='product24972-native-before',nativeAfter='product24977-native-after',semantic='product24974-semantic',stdlib='product24975-stdlib',producer='product24976-native')
data={k:read(B/n/'result.json') for k,n in records.items()}
for d in data.values():assert d['status']=='passed' and d['completed']==d['total'] and d['inputsStable'] and d['processesStopped']
assert data['csharp']['completed']==data['nativeBefore']['completed']==data['nativeAfter']['completed']==4
pairs=[]
for current in data['nativeAfter']['cases']:
 name=current['id'];managed=next(x for x in data['csharp']['cases'] if x['id']==name);old=next(x for x in data['nativeBefore']['cases'] if x['id']==name)
 assert managed['observedStdout']==old['observedStdout']==current['observedStdout']
 source=current['source'];assert data['csharp']['inputHashes'][source]==data['nativeBefore']['inputHashes'][source]==data['nativeAfter']['inputHashes'][source]==sha(source)
 pairs.append(dict(id=name,source=Path(source).relative_to(R).as_posix(),sourceSha256=sha(source),stdout=current['observedStdout'],passed=True))
source=R/'selfhost/semantic/expression_type_ids_resolution_phases.slg';assert data['producer']['inputHashes'][str(source)]==sha(source)
alias=R/'examples/regression/2849-nested-product-element-result-index.slg';probe=R/'scripts/probes/product-field-index/nested.slg';assert alias.read_bytes()==probe.read_bytes()
E.mkdir()
for k,d in data.items():write(E/(k+'.json'),d)
write(E/'source-comparison.json',read(B/'product24973-source-comparison.json'));write(E/'readiness-observation.json',read(B/'product24978-readiness-observation.json'))
write(E/'paired-cases.json',dict(completed=8,total=8,programPairs=4,baselineNativeNonAdditive=True,cases=pairs,catalogAlias=dict(source=alias.relative_to(R).as_posix(),verifiedSource=probe.relative_to(R).as_posix(),sha256=sha(alias))))
entries={}
def add(p,label=None):
 p=Path(p);entries[label or p.relative_to(R).as_posix()]=p.read_bytes()
for p in [Path(__file__),B/'product24971-focused.py',B/'product24971-focused.before.py',B/'product24973-source-comparison.json',B/'product24978-readiness-observation.json',source,alias,*R.joinpath('scripts/probes/product-field-index').glob('*'),R/'examples/regression/expected/2849-nested-product-element-result-index.stdout.txt']:
 add(p)
before=subprocess.run(['git','show','HEAD:'+source.relative_to(R).as_posix()],capture_output=True,check=True).stdout;entries['before-source/'+source.relative_to(R).as_posix()]=before
for name in records.values():
 for p in (B/name).rglob('*'):
  if p.is_file() and not any(x in p.parts for x in ['.sollang-cache','.w0','compiler','obj','bin']) and not any(x.endswith('.slg-tmp') for x in p.parts) and p.suffix.lower() not in ['.exe','.dll','.pdb','.ll','.bc','.obj','.lib','.pyc']:
   add(p)
archive=E/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,raw in sorted(entries.items()):z.writestr(n,raw)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(entries)
 for n,raw in entries.items():assert z.read(n)==raw
write(E/'archive-manifest.json',dict(sha256=sha(archive),readbackVerified=True,entries={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest().upper()) for n,raw in sorted(entries.items())}))
states={}
for x in read(R/'scripts/contracts/compiler-defects.json')['defects']:states[x['state']]=states.get(x['state'],0)+1
q=dict(schemaVersion=1,status='focused-qualified-final-source-and-performance-pending',owner='C2026-09-12-385',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Structural product nearest-result lookup; append-synchronized AST index with live types and original candidate ties/barriers.',paired=dict(completed=8,total=8,percentage=100.0,programPairs=4,evidence='paired-cases.json'),baselineNative=dict(completed=4,total=4,nonAdditiveToCurrentPair=True,evidence='nativeBefore.json'),semantic=dict(completed=4,total=4,evidence='semantic.json'),stdlib=dict(completed=1,total=1,sources=144,activeBodies=2071,totalBodies=2101,inactiveBodies=30,diagnostics=0,evidence='stdlib.json'),sourceComparison='source-comparison.json',compilerStates=states,currentNativeCompiler=str((B/'product24976-native/compiler.exe').relative_to(R).as_posix()),currentManagedCompiler=str((B/'ownership24970-managed/compiler/Sollang.Compiler.exe').relative_to(R).as_posix()),readinessObservation='readiness-observation.json',operationChange='Each expression ancestry is indexed once per invocation; each product element reads its selected live expression directly. Source-ordered field enumeration and canonical interning remain unchanged.',timingLimitations='Baseline overlapped semantic preflight. No same-condition speed comparison, original1999 root-cause resolution, or whole compiler speed claim.',original1999Runs=0,wholeProfileRuns=0,nativeProducerBuilds=1,archive=dict(path='evidence.zip',sha256=sha(archive),entries=len(entries),readbackVerified=True),claimsWholeCompilerSpeedImprovement=False,claimsWholePhaseComplete=False,claimsGoalComplete=False)
write(E/'qualification.json',q);print(json.dumps(dict(status=q['status'],paired=q['paired'],archiveEntries=len(entries),compilerStates=states)))

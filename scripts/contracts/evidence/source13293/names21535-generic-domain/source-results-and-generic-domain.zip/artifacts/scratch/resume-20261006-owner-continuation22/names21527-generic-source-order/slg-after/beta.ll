define i32 @sollang_x0A63616368652E62657461010701056170706C793B01067075626C696301056170706C791E013C0101541F013E010576616C756518013A01015416022D3E0101540104757365730107436F6E736F6C65_g627065225222(i32 %arg) {
entry:
  %v4_ptr = insertvalue %sollang.text poison, ptr @sollang_str_627065225226, 0
  %v4 = insertvalue %sollang.text %v4_ptr, i64 4, 1
  call void @sollang_runtime_print(ptr @sollang_str_627065225226, i64 4, i1 true)
  ret i32 %arg
}
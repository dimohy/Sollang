using System.Globalization;
using Sollang.Compiler.Diagnostics;
using Sollang.Compiler.Semantics;
using Sollang.Compiler.Syntax;

namespace Sollang.Compiler.CodeGen;

internal sealed partial class LlvmEmitter
{
    private string BuildDictionaryAggregate(string pointer, string length, string capacity)
    {
        var aggregate0 = NextTemp("generic_dict_value");
        EmitAssign(aggregate0, $"insertvalue %sollang.int_dictionary poison, ptr {pointer}, 0");
        var aggregate1 = NextTemp("generic_dict_value");
        EmitAssign(aggregate1, $"insertvalue %sollang.int_dictionary {aggregate0}, i64 {length}, 1");
        var aggregate2 = NextTemp("generic_dict_value");
        EmitAssign(aggregate2, $"insertvalue %sollang.int_dictionary {aggregate1}, i64 {capacity}, 2");
        return aggregate2;
    }
    private RuntimeInlineDictionary EmitInlineDictionaryLiteral(
        DictionaryLiteralExpression expression,
        BoundType dictionaryType,
        IReadOnlyList<(RuntimeValue Key, RuntimeValue Value)> entries)
    {
        var definition = _program.Types.GetDictionary(dictionaryType);
        var capacity = DictionaryCapacityForLength(entries.Count);
        var dictionary = new RuntimeInlineDictionary(
            dictionaryType, definition.KeyType, definition.ValueType,
            EmitInlineDictionaryAllocate(capacity.ToString(CultureInfo.InvariantCulture), definition),
            entries.Count.ToString(CultureInfo.InvariantCulture),
            capacity.ToString(CultureInfo.InvariantCulture));
        foreach (var entry in entries)
        {
            EmitInlineDictionaryInsertUnique(dictionary, entry.Key, entry.Value);
        }
        return dictionary;
    }

    private RuntimeInlineDictionary EmitBoundedInlineDictionaryLiteral(
        BoundType dictionaryType,
        IReadOnlyList<(RuntimeValue Key, RuntimeValue Value)> entries)
    {
        var dictionary = EmitEmptyBoundedInlineDictionary(dictionaryType) with
        {
            LengthName = entries.Count.ToString(CultureInfo.InvariantCulture)
        };
        foreach (var entry in entries)
        {
            EmitInlineDictionaryInsertUnique(dictionary, entry.Key, entry.Value);
        }
        return dictionary;
    }

    private RuntimeInlineDictionary EmitEmptyBoundedInlineDictionary(BoundType dictionaryType)
    {
        var bounded = _program.Types.GetBoundedDictionary(dictionaryType);
        var pointer = NextTemp("bounded_dict_storage");
        EmitAlloca(pointer, $"[{bounded.StorageSize.ToString(CultureInfo.InvariantCulture)} x i8]", bounded.Alignment);
        EmitZeroByteBuffer(
            pointer,
            (bounded.BucketCapacity + 16).ToString(CultureInfo.InvariantCulture),
            "bounded_dict_control_init");
        return new RuntimeInlineDictionary(
            dictionaryType,
            bounded.KeyType,
            bounded.ValueType,
            pointer,
            "0",
            bounded.BucketCapacity.ToString(CultureInfo.InvariantCulture),
            RuntimeContainerStorage.Stack);
    }

    private RuntimeInlineDictionary EmitTypedEmptyInlineDictionary(
        TypedEmptyDictionaryExpression expression,
        BoundType dictionaryType)
    {
        var definition = _program.Types.GetDictionary(dictionaryType);
        if (expression.CapacityHint is null)
        {
            return new RuntimeInlineDictionary(
                dictionaryType, definition.KeyType, definition.ValueType, "null", "0", "0");
        }
        var capacity = DictionaryCapacityForLength(expression.CapacityHint.Value);
        return new RuntimeInlineDictionary(
            dictionaryType, definition.KeyType, definition.ValueType,
            EmitInlineDictionaryAllocate(capacity.ToString(CultureInfo.InvariantCulture), definition),
            "0", capacity.ToString(CultureInfo.InvariantCulture));
    }

    private string EmitInlineDictionaryAllocate(string capacity, BoundDictionaryDefinition definition)
    {
        var entriesOffset = EmitDictionaryEntriesOffset(capacity, "generic_dict_entries_offset");
        var entriesBytes = NextTemp("generic_dict_entries_bytes");
        EmitBinary(entriesBytes, "mul", "i64", capacity, definition.EntryStride.ToString(CultureInfo.InvariantCulture));
        var totalBytes = NextTemp("generic_dict_bytes");
        EmitBinary(totalBytes, "add", "i64", entriesOffset, entriesBytes);
        var pointer = EmitHeapAllocate(totalBytes);
        var controlBytes = NextTemp("generic_dict_control_bytes");
        EmitBinary(controlBytes, "add", "i64", capacity, "16");
        EmitZeroByteBuffer(pointer, controlBytes, "generic_dict_control_init");
        return pointer;
    }

    private string EmitInlineDictionaryEntryPointer(
        RuntimeInlineDictionary dictionary, string index, int fieldOffset, string prefix)
    {
        var definition = _program.Types.GetDictionary(dictionary.DictionaryType);
        var entriesOffset = EmitDictionaryEntriesOffset(dictionary.CapacityName, prefix + "_entries_offset");
        var entries = NextTemp(prefix + "_entries");
        EmitAssign(entries, $"getelementptr i8, ptr {dictionary.PointerName}, i64 {entriesOffset}");
        var entryOffset = NextTemp(prefix + "_entry_offset");
        EmitBinary(entryOffset, "mul", "i64", index, definition.EntryStride.ToString(CultureInfo.InvariantCulture));
        if (fieldOffset == 0)
        {
            var slot = NextTemp(prefix + "_slot");
            EmitAssign(slot, $"getelementptr i8, ptr {entries}, i64 {entryOffset}");
            return slot;
        }
        var offset = NextTemp(prefix + "_offset");
        EmitBinary(offset, "add", "i64", entryOffset, fieldOffset.ToString(CultureInfo.InvariantCulture));
        var fieldSlot = NextTemp(prefix + "_slot");
        EmitAssign(fieldSlot, $"getelementptr i8, ptr {entries}, i64 {offset}");
        return fieldSlot;
    }

    private void StoreInlineDictionaryEntry(
        RuntimeInlineDictionary dictionary, string index, RuntimeValue key, RuntimeValue value)
    {
        var definition = _program.Types.GetDictionary(dictionary.DictionaryType);
        var keyValue = MaterializeAggregateValue(key);
        var valueValue = MaterializeAggregateValue(value);
        EmitStore(keyValue.TypeName, keyValue.ValueName,
            EmitInlineDictionaryEntryPointer(dictionary, index, 0, "generic_dict_key"), definition.KeyAlignment);
        EmitStore(valueValue.TypeName, valueValue.ValueName,
            EmitInlineDictionaryEntryPointer(dictionary, index, definition.ValueOffset, "generic_dict_value"), definition.ValueAlignment);
    }

    private RuntimeValue LoadInlineDictionaryField(
        RuntimeInlineDictionary dictionary, string index, BoundType type, int offset, int alignment, string prefix)
    {
        var slot = EmitInlineDictionaryEntryPointer(dictionary, index, offset, prefix);
        var loaded = NextTemp(prefix);
        EmitLoad(loaded, LlvmType(type), slot, alignment);
        return DematerializeAggregateValue(type, loaded);
    }

    private string LoadInlineDictionaryControl(RuntimeInlineDictionary dictionary, string slot)
    {
        var pointer = NextTemp("generic_dict_control_slot");
        EmitAssign(pointer, $"getelementptr i8, ptr {dictionary.PointerName}, i64 {slot}");
        var control = NextTemp("generic_dict_control");
        EmitLoad(control, "i8", pointer, 1);
        return control;
    }

    private void StoreInlineDictionaryControl(RuntimeInlineDictionary dictionary, string slot, string control)
    {
        var pointer = NextTemp("generic_dict_control_slot");
        EmitAssign(pointer, $"getelementptr i8, ptr {dictionary.PointerName}, i64 {slot}");
        EmitStore("i8", control, pointer, 1);
        var mirrored = NextTemp("generic_dict_control_mirrored");
        EmitCompare(mirrored, "ult", "i64", slot, "16");
        var mirror = NextLabel("generic_dict_control_mirror");
        var done = NextLabel("generic_dict_control_done");
        EmitConditionalBranch(mirrored, mirror, done); EmitFunctionLine();
        EmitLabel(mirror);
        var mirrorIndex = NextTemp("generic_dict_control_mirror_index");
        EmitBinary(mirrorIndex, "add", "i64", dictionary.CapacityName, slot);
        var mirrorPointer = NextTemp("generic_dict_control_mirror_slot");
        EmitAssign(mirrorPointer, $"getelementptr i8, ptr {dictionary.PointerName}, i64 {mirrorIndex}");
        EmitStore("i8", control, mirrorPointer, 1);
        EmitBranch(done); EmitFunctionLine();
        EmitLabel(done);
        _currentBlockLabel = done;
    }

    private string EmitInlineDictionaryHash(RuntimeValue key)
    {
        if (key is RuntimeInt integer)
        {
            return EmitHashInteger(integer);
        }
        if (key is RuntimeStruct or RuntimeEnum)
        {
            var hashFunction = FindDictionaryKeyTraitMethod(key.Type, "Hash", "hash");
            var hashValue = EmitFunctionCall(hashFunction, key);
            return hashValue is RuntimeInt hashResult
                ? EmitHashInteger(hashResult)
                : throw new SollangException("Hash.hash must return Int");
        }
        if (key is not RuntimeText text)
        {
            throw new SollangException($"dictionary key type {key.Type} has no Hash implementation");
        }

        var entry = _currentBlockLabel;
        var loop = NextLabel("text_hash");
        var body = NextLabel("text_hash_body");
        var done = NextLabel("text_hash_done");
        var nextI = NextTemp("text_hash_next_i");
        var nextHash = NextTemp("text_hash_next");
        EmitBranch(loop);
        EmitFunctionLine();
        EmitLabel(loop);
        var i = NextTemp("text_hash_i");
        EmitPhi(i, "i64", ("0", entry), (nextI, body));
        var hash = NextTemp("text_hash_value");
        EmitPhi(hash, "i64", ("-3750763034362895579", entry), (nextHash, body));
        var active = NextTemp("text_hash_active");
        EmitCompare(active, "ult", "i64", i, text.LengthName);
        EmitConditionalBranch(active, body, done);
        EmitFunctionLine();
        EmitLabel(body);
        var bytePointer = NextTemp("text_hash_byte_ptr");
        EmitAssign(bytePointer, $"getelementptr i8, ptr {text.PointerName}, i64 {i}");
        var item = NextTemp("text_hash_byte");
        EmitLoad(item, "i8", bytePointer, 1);
        var wide = NextTemp("text_hash_wide");
        EmitAssign(wide, $"zext i8 {item} to i64");
        var mixed = NextTemp("text_hash_mixed");
        EmitBinary(mixed, "xor", "i64", hash, wide);
        EmitBinary(nextHash, "mul", "i64", mixed, "1099511628211");
        EmitBinary(nextI, "add", "i64", i, "1");
        EmitBranch(loop);
        EmitFunctionLine();
        EmitLabel(done);
        _currentBlockLabel = done;
        return hash;
    }

    private string EmitValuesEqual(RuntimeValue left, RuntimeValue right)
    {
        if (left is RuntimeInt leftInt && right is RuntimeInt rightInt)
        {
            var equal = NextTemp("generic_dict_key_equal");
            EmitCompare(equal, "eq", LlvmType(leftInt.Type), leftInt.ValueName, rightInt.ValueName);
            return equal;
        }
        if (left is RuntimeStruct or RuntimeEnum)
        {
            var eqFunction = FindDictionaryKeyTraitMethod(left.Type, "Eq", "eq");
            var leftKey = EmitFunctionCall(eqFunction, left);
            var rightKey = EmitFunctionCall(eqFunction, right);
            if (leftKey is not RuntimeInt leftEq || rightKey is not RuntimeInt rightEq)
            {
                throw new SollangException("Eq.eq must return Int");
            }
            var equal = NextTemp("generic_dict_nominal_key_equal");
            EmitCompare(equal, "eq", LlvmType(leftEq.Type), leftEq.ValueName, rightEq.ValueName);
            return equal;
        }
        if (left is not RuntimeText leftText || right is not RuntimeText rightText)
        {
            throw new SollangException($"dictionary key type {left.Type} has no Eq implementation");
        }

        var sameLength = NextTemp("text_eq_length");
        EmitCompare(sameLength, "eq", "i64", leftText.LengthName, rightText.LengthName);
        var entry = _currentBlockLabel;
        var loop = NextLabel("text_eq");
        var body = NextLabel("text_eq_body");
        var next = NextLabel("text_eq_next");
        var mismatch = NextLabel("text_eq_mismatch");
        var match = NextLabel("text_eq_match");
        var done = NextLabel("text_eq_done");
        var nextI = NextTemp("text_eq_next_i");
        EmitConditionalBranch(sameLength, loop, mismatch);
        EmitFunctionLine();
        EmitLabel(loop);
        var i = NextTemp("text_eq_i");
        EmitPhi(i, "i64", ("0", entry), (nextI, next));
        var active = NextTemp("text_eq_active");
        EmitCompare(active, "ult", "i64", i, leftText.LengthName);
        EmitConditionalBranch(active, body, match);
        EmitFunctionLine();
        EmitLabel(body);
        var lp = NextTemp("text_eq_left_ptr");
        var rp = NextTemp("text_eq_right_ptr");
        EmitAssign(lp, $"getelementptr i8, ptr {leftText.PointerName}, i64 {i}");
        EmitAssign(rp, $"getelementptr i8, ptr {rightText.PointerName}, i64 {i}");
        var lb = NextTemp("text_eq_left");
        var rb = NextTemp("text_eq_right");
        EmitLoad(lb, "i8", lp, 1);
        EmitLoad(rb, "i8", rp, 1);
        var byteEqual = NextTemp("text_eq_byte");
        EmitCompare(byteEqual, "eq", "i8", lb, rb);
        EmitConditionalBranch(byteEqual, next, mismatch);
        EmitFunctionLine();
        EmitLabel(next);
        EmitBinary(nextI, "add", "i64", i, "1");
        EmitBranch(loop);
        EmitFunctionLine();
        EmitLabel(match);
        EmitBranch(done);
        EmitFunctionLine();
        EmitLabel(mismatch);
        EmitBranch(done);
        EmitFunctionLine();
        EmitLabel(done);
        var result = NextTemp("text_eq_result");
        EmitPhi(result, "i1", ("true", match), ("false", mismatch));
        _currentBlockLabel = done;
        return result;
    }

    private BoundFunction FindDictionaryKeyTraitMethod(BoundType type, string traitName, string methodName)
    {
        var definitionModule = _program.Types.IsStruct(type)
            ? _program.Types.GetStruct(type).ModuleName
            : _program.Types.GetEnum(type).ModuleName;
        var moduleTraitName = definitionModule.Length == 0
            ? traitName
            : definitionModule + "." + traitName;
        return _program.Functions.Values.FirstOrDefault(function =>
            (function.TraitName == traitName || function.TraitName == moduleTraitName)
            && function.InputType == type
            && function.Name.EndsWith('.' + methodName, StringComparison.Ordinal))
            ?? throw new SollangException(
                $"dictionary key type {type} has no {traitName}.{methodName} implementation");
    }

    private RuntimeValue EmitInlineDictionaryLookup(RuntimeInlineDictionary dictionary, RuntimeValue key)
    {
        var definition = _program.Types.GetDictionary(dictionary.DictionaryType);
        var hash = EmitInlineDictionaryHash(key);
        var h2 = EmitDictionaryH2Byte(hash);
        var mask = EmitDictionaryCapacityMask(dictionary.CapacityName);
        var start = EmitDictionaryStartSlot(hash, mask);
        var entry = _currentBlockLabel;
        var loop = NextLabel("generic_dict_lookup");
        var body = NextLabel("generic_dict_lookup_body");
        var full = NextLabel("generic_dict_lookup_full");
        var compare = NextLabel("generic_dict_lookup_compare");
        var match = NextLabel("generic_dict_lookup_match");
        var next = NextLabel("generic_dict_lookup_next");
        var miss = NextLabel("generic_dict_lookup_miss");
        var done = NextLabel("generic_dict_lookup_done");
        var nextProbe = NextTemp("generic_dict_lookup_next_probe");
        EmitBranch(loop); EmitFunctionLine();
        EmitLabel(loop);
        var probe = NextTemp("generic_dict_lookup_probe");
        EmitPhi(probe, "i64", ("0", entry), (nextProbe, next));
        var active = NextTemp("generic_dict_lookup_active");
        EmitCompare(active, "ult", "i64", probe, dictionary.CapacityName);
        EmitConditionalBranch(active, body, miss); EmitFunctionLine();
        EmitLabel(body);
        var unwrapped = NextTemp("generic_dict_lookup_unwrapped");
        EmitBinary(unwrapped, "add", "i64", start, probe);
        var slot = NextTemp("generic_dict_lookup_slot");
        EmitBinary(slot, "and", "i64", unwrapped, mask);
        var control = LoadInlineDictionaryControl(dictionary, slot);
        var empty = NextTemp("generic_dict_lookup_empty");
        EmitCompare(empty, "eq", "i8", control, "0");
        EmitConditionalBranch(empty, miss, full); EmitFunctionLine();
        EmitLabel(full);
        var h2Match = NextTemp("generic_dict_lookup_h2");
        EmitCompare(h2Match, "eq", "i8", control, h2);
        EmitConditionalBranch(h2Match, compare, next); EmitFunctionLine();
        EmitLabel(compare);
        _currentBlockLabel = compare;
        var storedKey = LoadInlineDictionaryField(dictionary, slot, definition.KeyType, 0, definition.KeyAlignment, "generic_dict_key");
        var equal = EmitValuesEqual(storedKey, key);
        EmitConditionalBranch(equal, match, next); EmitFunctionLine();
        EmitLabel(match);
        var value = LoadInlineDictionaryField(dictionary, slot, definition.ValueType, definition.ValueOffset, definition.ValueAlignment, "generic_dict_value");
        EmitBranch(done); EmitFunctionLine();
        EmitLabel(next);
        EmitBinary(nextProbe, "add", "i64", probe, "1");
        EmitBranch(loop); EmitFunctionLine();
        EmitLabel(miss);
        EmitTrap(); EmitFunctionLine();
        EmitLabel(done);
        _currentBlockLabel = done;
        return value;
    }

    private void EmitInlineDictionaryInsertUnique(RuntimeInlineDictionary dictionary, RuntimeValue key, RuntimeValue value)
    {
        var found = EmitInlineDictionaryFindSlot(dictionary, key);
        StoreInlineDictionaryEntry(dictionary, found.SlotName, key, value);
        StoreInlineDictionaryControl(dictionary, found.SlotName, found.H2ByteName);
    }

    // Read/remove probes do not need to remember a tombstone or produce an
    // insertion slot. Keeping that work out of the lookup hot path avoids a
    // deleted-control vector comparison, cttz, mask, and loop-carried phi for
    // every contains/remove operation while retaining identical probe order.
    private DictionaryFindResult EmitInlineDictionaryFindExistingSlot(
        RuntimeInlineDictionary dictionary,
        RuntimeValue key)
    {
        if (key is not RuntimeInt)
        {
            return EmitInlineDictionaryFindExistingSlotGrouped(dictionary, key);
        }

        var definition = _program.Types.GetDictionary(dictionary.DictionaryType);
        var hash = EmitInlineDictionaryHash(key);
        var h2 = EmitDictionaryH2Byte(hash);
        var mask = EmitDictionaryCapacityMask(dictionary.CapacityName);
        var start = EmitDictionaryStartSlot(hash, mask);
        var occupied = NextLabel("generic_dict_lookup_first_occupied");
        var compare = NextLabel("generic_dict_lookup_first_compare");
        var match = NextLabel("generic_dict_lookup_first_match");
        var fallback = NextLabel("generic_dict_lookup_first_fallback");
        var miss = NextLabel("generic_dict_lookup_first_miss");
        var done = NextLabel("generic_dict_lookup_first_done");
        var control = LoadInlineDictionaryControl(dictionary, start);
        var empty = NextTemp("generic_dict_lookup_first_empty");
        EmitCompare(empty, "eq", "i8", control, "0");
        EmitConditionalBranch(empty, miss, occupied); EmitFunctionLine();

        EmitLabel(occupied); _currentBlockLabel = occupied;
        var h2Match = NextTemp("generic_dict_lookup_first_h2");
        EmitCompare(h2Match, "eq", "i8", control, h2);
        EmitConditionalBranch(h2Match, compare, fallback); EmitFunctionLine();

        EmitLabel(compare); _currentBlockLabel = compare;
        var storedKey = LoadInlineDictionaryField(
            dictionary, start, definition.KeyType, 0, definition.KeyAlignment, "generic_dict_lookup_first_key");
        var equal = EmitValuesEqual(storedKey, key);
        EmitConditionalBranch(equal, match, fallback); EmitFunctionLine();

        EmitLabel(match); _currentBlockLabel = match;
        EmitBranch(done);
        var matchEnd = _currentBlockLabel; EmitFunctionLine();

        EmitLabel(miss); _currentBlockLabel = miss;
        EmitBranch(done);
        var missEnd = _currentBlockLabel; EmitFunctionLine();

        EmitLabel(fallback); _currentBlockLabel = fallback;
        var grouped = EmitInlineDictionaryFindExistingSlotGrouped(dictionary, key);
        EmitBranch(done);
        var fallbackEnd = _currentBlockLabel; EmitFunctionLine();

        EmitLabel(done);
        var found = NextTemp("generic_dict_lookup_first_found");
        EmitPhi(found, "i1", ("true", matchEnd), ("false", missEnd), (grouped.FoundName, fallbackEnd));
        var foundSlot = NextTemp("generic_dict_lookup_first_slot_result");
        EmitPhi(foundSlot, "i64", (start, matchEnd), ("0", missEnd), (grouped.SlotName, fallbackEnd));
        _currentBlockLabel = done;
        return new DictionaryFindResult(found, foundSlot, h2);
    }

    private DictionaryFindResult EmitInlineDictionaryFindExistingSlotGrouped(
        RuntimeInlineDictionary dictionary,
        RuntimeValue key)
    {
        var definition = _program.Types.GetDictionary(dictionary.DictionaryType);
        var hash = EmitInlineDictionaryHash(key);
        var h2 = EmitDictionaryH2Byte(hash);
        var mask = EmitDictionaryCapacityMask(dictionary.CapacityName);
        var start = EmitDictionaryStartSlot(hash, mask);
        var entry = _currentBlockLabel;
        var groupLoop = NextLabel("generic_dict_lookup_group");
        var groupBody = NextLabel("generic_dict_lookup_group_body");
        var candidateLoop = NextLabel("generic_dict_lookup_candidate_loop");
        var candidateBody = NextLabel("generic_dict_lookup_candidate_body");
        var candidateNext = NextLabel("generic_dict_lookup_candidate_next");
        var groupDecision = NextLabel("generic_dict_lookup_group_decision");
        var match = NextLabel("generic_dict_lookup_group_match");
        var nextGroup = NextLabel("generic_dict_lookup_group_next");
        var miss = NextLabel("generic_dict_lookup_group_miss");
        var done = NextLabel("generic_dict_lookup_group_done");
        var nextProbe = NextTemp("generic_dict_lookup_group_next_probe");
        EmitBranch(groupLoop); EmitFunctionLine();

        EmitLabel(groupLoop); _currentBlockLabel = groupLoop;
        var probe = NextTemp("generic_dict_lookup_group_probe");
        EmitPhi(probe, "i64", ("0", entry), (nextProbe, nextGroup));
        var active = NextTemp("generic_dict_lookup_group_active");
        EmitCompare(active, "ult", "i64", probe, dictionary.CapacityName);
        EmitConditionalBranch(active, groupBody, miss); EmitFunctionLine();

        EmitLabel(groupBody); _currentBlockLabel = groupBody;
        var unwrapped = NextTemp("generic_dict_lookup_group_unwrapped");
        EmitBinary(unwrapped, "add", "i64", start, probe);
        var groupStart = NextTemp("generic_dict_lookup_group_start");
        EmitBinary(groupStart, "and", "i64", unwrapped, mask);
        var groupPointer = NextTemp("generic_dict_lookup_group_pointer");
        EmitAssign(groupPointer, $"getelementptr i8, ptr {dictionary.PointerName}, i64 {groupStart}");
        var controls = NextTemp("generic_dict_lookup_group_controls");
        EmitLoad(controls, "<16 x i8>", groupPointer, 1);
        var h2Seed = NextTemp("generic_dict_lookup_group_h2_seed");
        EmitAssign(h2Seed, $"insertelement <16 x i8> poison, i8 {h2}, i64 0");
        var h2Vector = NextTemp("generic_dict_lookup_group_h2_vector");
        EmitAssign(h2Vector, $"shufflevector <16 x i8> {h2Seed}, <16 x i8> poison, <16 x i32> zeroinitializer");
        var matchesVector = NextTemp("generic_dict_lookup_group_matches_vector");
        EmitAssign(matchesVector, $"icmp eq <16 x i8> {controls}, {h2Vector}");
        var matchBits = NextTemp("generic_dict_lookup_group_match_bits");
        EmitAssign(matchBits, $"bitcast <16 x i1> {matchesVector} to i16");
        var emptyVector = NextTemp("generic_dict_lookup_group_empty_vector");
        EmitAssign(emptyVector, $"icmp eq <16 x i8> {controls}, zeroinitializer");
        var emptyBits = NextTemp("generic_dict_lookup_group_empty_bits");
        EmitAssign(emptyBits, $"bitcast <16 x i1> {emptyVector} to i16");
        EmitBranch(candidateLoop); EmitFunctionLine();

        EmitLabel(candidateLoop); _currentBlockLabel = candidateLoop;
        var candidateBits = NextTemp("generic_dict_lookup_candidate_bits");
        var clearedBits = NextTemp("generic_dict_lookup_candidate_cleared_bits");
        EmitPhi(candidateBits, "i16", (matchBits, groupBody), (clearedBits, candidateNext));
        var hasCandidate = NextTemp("generic_dict_lookup_has_candidate");
        EmitCompare(hasCandidate, "ne", "i16", candidateBits, "0");
        EmitConditionalBranch(hasCandidate, candidateBody, groupDecision); EmitFunctionLine();

        EmitLabel(candidateBody); _currentBlockLabel = candidateBody;
        var candidateOffset16 = NextTemp("generic_dict_lookup_candidate_offset16");
        EmitCall(candidateOffset16, "i16", "llvm.cttz.i16", $"i16 {candidateBits}, i1 false");
        var candidateOffset = NextTemp("generic_dict_lookup_candidate_offset");
        EmitAssign(candidateOffset, $"zext i16 {candidateOffset16} to i64");
        var candidateUnwrapped = NextTemp("generic_dict_lookup_candidate_unwrapped");
        EmitBinary(candidateUnwrapped, "add", "i64", groupStart, candidateOffset);
        var candidateSlot = NextTemp("generic_dict_lookup_candidate_slot");
        EmitBinary(candidateSlot, "and", "i64", candidateUnwrapped, mask);
        var storedKey = LoadInlineDictionaryField(
            dictionary, candidateSlot, definition.KeyType, 0, definition.KeyAlignment, "generic_dict_lookup_key");
        var equal = EmitValuesEqual(storedKey, key);
        EmitConditionalBranch(equal, match, candidateNext); EmitFunctionLine();

        EmitLabel(candidateNext); _currentBlockLabel = candidateNext;
        var bitsMinusOne = NextTemp("generic_dict_lookup_candidate_bits_minus_one");
        EmitBinary(bitsMinusOne, "sub", "i16", candidateBits, "1");
        EmitBinary(clearedBits, "and", "i16", candidateBits, bitsMinusOne);
        EmitBranch(candidateLoop); EmitFunctionLine();

        EmitLabel(groupDecision); _currentBlockLabel = groupDecision;
        var hasEmpty = NextTemp("generic_dict_lookup_group_has_empty");
        EmitCompare(hasEmpty, "ne", "i16", emptyBits, "0");
        EmitConditionalBranch(hasEmpty, miss, nextGroup); EmitFunctionLine();

        EmitLabel(nextGroup); _currentBlockLabel = nextGroup;
        EmitBinary(nextProbe, "add", "i64", probe, "16");
        EmitBranch(groupLoop); EmitFunctionLine();

        EmitLabel(match); _currentBlockLabel = match;
        EmitBranch(done); EmitFunctionLine();

        EmitLabel(miss); _currentBlockLabel = miss;
        EmitBranch(done); EmitFunctionLine();

        EmitLabel(done);
        var found = NextTemp("generic_dict_lookup_found");
        EmitPhi(found, "i1", ("true", match), ("false", miss));
        var foundSlot = NextTemp("generic_dict_lookup_slot_result");
        EmitPhi(foundSlot, "i64", (candidateSlot, match), ("0", miss));
        _currentBlockLabel = done;
        return new DictionaryFindResult(found, foundSlot, h2);
    }

    private DictionaryFindResult EmitInlineDictionaryFindSlot(RuntimeInlineDictionary dictionary, RuntimeValue key)
    {
        if (key is not RuntimeInt)
        {
            return EmitInlineDictionaryFindSlotGrouped(dictionary, key);
        }

        var definition = _program.Types.GetDictionary(dictionary.DictionaryType);
        var hash = EmitInlineDictionaryHash(key);
        var h2 = EmitDictionaryH2Byte(hash);
        var mask = EmitDictionaryCapacityMask(dictionary.CapacityName);
        var start = EmitDictionaryStartSlot(hash, mask);
        var occupied = NextLabel("generic_dict_insert_first_occupied");
        var compare = NextLabel("generic_dict_insert_first_compare");
        var match = NextLabel("generic_dict_insert_first_match");
        var fallback = NextLabel("generic_dict_insert_first_fallback");
        var vacant = NextLabel("generic_dict_insert_first_vacant");
        var done = NextLabel("generic_dict_insert_first_done");
        var control = LoadInlineDictionaryControl(dictionary, start);
        var empty = NextTemp("generic_dict_insert_first_empty");
        EmitCompare(empty, "eq", "i8", control, "0");
        EmitConditionalBranch(empty, vacant, occupied); EmitFunctionLine();

        EmitLabel(occupied); _currentBlockLabel = occupied;
        var h2Match = NextTemp("generic_dict_insert_first_h2");
        EmitCompare(h2Match, "eq", "i8", control, h2);
        EmitConditionalBranch(h2Match, compare, fallback); EmitFunctionLine();

        EmitLabel(compare); _currentBlockLabel = compare;
        var storedKey = LoadInlineDictionaryField(
            dictionary, start, definition.KeyType, 0, definition.KeyAlignment, "generic_dict_insert_first_key");
        var equal = EmitValuesEqual(storedKey, key);
        EmitConditionalBranch(equal, match, fallback); EmitFunctionLine();

        EmitLabel(match); _currentBlockLabel = match;
        EmitBranch(done);
        var matchEnd = _currentBlockLabel; EmitFunctionLine();

        EmitLabel(vacant); _currentBlockLabel = vacant;
        EmitBranch(done);
        var vacantEnd = _currentBlockLabel; EmitFunctionLine();

        EmitLabel(fallback); _currentBlockLabel = fallback;
        var grouped = EmitInlineDictionaryFindSlotGrouped(dictionary, key);
        EmitBranch(done);
        var fallbackEnd = _currentBlockLabel; EmitFunctionLine();

        EmitLabel(done);
        var found = NextTemp("generic_dict_insert_first_found");
        EmitPhi(found, "i1", ("true", matchEnd), ("false", vacantEnd), (grouped.FoundName, fallbackEnd));
        var foundSlot = NextTemp("generic_dict_insert_first_slot_result");
        EmitPhi(foundSlot, "i64", (start, matchEnd), (start, vacantEnd), (grouped.SlotName, fallbackEnd));
        _currentBlockLabel = done;
        return new DictionaryFindResult(found, foundSlot, h2);
    }

    private DictionaryFindResult EmitInlineDictionaryFindSlotGrouped(RuntimeInlineDictionary dictionary, RuntimeValue key)
    {
        var definition = _program.Types.GetDictionary(dictionary.DictionaryType);
        var hash = EmitInlineDictionaryHash(key);
        var h2 = EmitDictionaryH2Byte(hash);
        var mask = EmitDictionaryCapacityMask(dictionary.CapacityName);
        var start = EmitDictionaryStartSlot(hash, mask);
        var entry = _currentBlockLabel;
        var groupLoop = NextLabel("generic_dict_group_find");
        var groupBody = NextLabel("generic_dict_group_body");
        var candidateLoop = NextLabel("generic_dict_candidate_loop");
        var candidateBody = NextLabel("generic_dict_candidate_body");
        var candidateNext = NextLabel("generic_dict_candidate_next");
        var groupDecision = NextLabel("generic_dict_group_decision");
        var empty = NextLabel("generic_dict_group_empty");
        var match = NextLabel("generic_dict_group_match");
        var nextGroup = NextLabel("generic_dict_group_next");
        var miss = NextLabel("generic_dict_group_miss");
        var done = NextLabel("generic_dict_group_done");
        var nextProbe = NextTemp("generic_dict_group_next_probe");
        var nextFirstDeleted = NextTemp("generic_dict_group_next_deleted");
        EmitBranch(groupLoop); EmitFunctionLine();

        EmitLabel(groupLoop); _currentBlockLabel = groupLoop;
        var probe = NextTemp("generic_dict_group_probe");
        EmitPhi(probe, "i64", ("0", entry), (nextProbe, nextGroup));
        var firstDeleted = NextTemp("generic_dict_group_deleted");
        EmitPhi(firstDeleted, "i64", (dictionary.CapacityName, entry), (nextFirstDeleted, nextGroup));
        var active = NextTemp("generic_dict_group_active");
        EmitCompare(active, "ult", "i64", probe, dictionary.CapacityName);
        EmitConditionalBranch(active, groupBody, miss); EmitFunctionLine();

        EmitLabel(groupBody); _currentBlockLabel = groupBody;
        var unwrapped = NextTemp("generic_dict_group_unwrapped");
        EmitBinary(unwrapped, "add", "i64", start, probe);
        var groupStart = NextTemp("generic_dict_group_start");
        EmitBinary(groupStart, "and", "i64", unwrapped, mask);
        var groupPointer = NextTemp("generic_dict_group_pointer");
        EmitAssign(groupPointer, $"getelementptr i8, ptr {dictionary.PointerName}, i64 {groupStart}");
        var controls = NextTemp("generic_dict_group_controls");
        EmitLoad(controls, "<16 x i8>", groupPointer, 1);
        var h2Seed = NextTemp("generic_dict_group_h2_seed");
        EmitAssign(h2Seed, $"insertelement <16 x i8> poison, i8 {h2}, i64 0");
        var h2Vector = NextTemp("generic_dict_group_h2_vector");
        EmitAssign(h2Vector, $"shufflevector <16 x i8> {h2Seed}, <16 x i8> poison, <16 x i32> zeroinitializer");
        var matchesVector = NextTemp("generic_dict_group_matches_vector");
        EmitAssign(matchesVector, $"icmp eq <16 x i8> {controls}, {h2Vector}");
        var matchBits = NextTemp("generic_dict_group_match_bits");
        EmitAssign(matchBits, $"bitcast <16 x i1> {matchesVector} to i16");
        var emptyVector = NextTemp("generic_dict_group_empty_vector");
        EmitAssign(emptyVector, $"icmp eq <16 x i8> {controls}, zeroinitializer");
        var emptyBits = NextTemp("generic_dict_group_empty_bits");
        EmitAssign(emptyBits, $"bitcast <16 x i1> {emptyVector} to i16");
        var deletedSeed = NextTemp("generic_dict_group_deleted_seed");
        EmitAssign(deletedSeed, "insertelement <16 x i8> poison, i8 -1, i64 0");
        var deletedVector = NextTemp("generic_dict_group_deleted_vector");
        EmitAssign(deletedVector, $"shufflevector <16 x i8> {deletedSeed}, <16 x i8> poison, <16 x i32> zeroinitializer");
        var deletedMatches = NextTemp("generic_dict_group_deleted_matches");
        EmitAssign(deletedMatches, $"icmp eq <16 x i8> {controls}, {deletedVector}");
        var deletedBits = NextTemp("generic_dict_group_deleted_bits");
        EmitAssign(deletedBits, $"bitcast <16 x i1> {deletedMatches} to i16");
        var hasDeleted = NextTemp("generic_dict_group_has_deleted");
        EmitCompare(hasDeleted, "ne", "i16", deletedBits, "0");
        var noPreviousDeleted = NextTemp("generic_dict_group_no_previous_deleted");
        EmitCompare(noPreviousDeleted, "eq", "i64", firstDeleted, dictionary.CapacityName);
        var captureDeleted = NextTemp("generic_dict_group_capture_deleted");
        EmitBinary(captureDeleted, "and", "i1", hasDeleted, noPreviousDeleted);
        var deletedOffset16 = NextTemp("generic_dict_group_deleted_offset16");
        EmitCall(deletedOffset16, "i16", "llvm.cttz.i16", $"i16 {deletedBits}, i1 false");
        var deletedOffset = NextTemp("generic_dict_group_deleted_offset");
        EmitAssign(deletedOffset, $"zext i16 {deletedOffset16} to i64");
        var deletedUnwrapped = NextTemp("generic_dict_group_deleted_unwrapped");
        EmitBinary(deletedUnwrapped, "add", "i64", groupStart, deletedOffset);
        var deletedSlot = NextTemp("generic_dict_group_deleted_slot");
        EmitBinary(deletedSlot, "and", "i64", deletedUnwrapped, mask);
        var capturedDeleted = NextTemp("generic_dict_group_captured_deleted");
        EmitSelect(capturedDeleted, captureDeleted, $"i64 {deletedSlot}", $"i64 {firstDeleted}");
        EmitBranch(candidateLoop); EmitFunctionLine();

        EmitLabel(candidateLoop); _currentBlockLabel = candidateLoop;
        var candidateBits = NextTemp("generic_dict_candidate_bits");
        var clearedBits = NextTemp("generic_dict_candidate_cleared_bits");
        EmitPhi(candidateBits, "i16", (matchBits, groupBody), (clearedBits, candidateNext));
        var hasCandidate = NextTemp("generic_dict_has_candidate");
        EmitCompare(hasCandidate, "ne", "i16", candidateBits, "0");
        EmitConditionalBranch(hasCandidate, candidateBody, groupDecision); EmitFunctionLine();

        EmitLabel(candidateBody); _currentBlockLabel = candidateBody;
        var candidateOffset16 = NextTemp("generic_dict_candidate_offset16");
        EmitCall(candidateOffset16, "i16", "llvm.cttz.i16", $"i16 {candidateBits}, i1 false");
        var candidateOffset = NextTemp("generic_dict_candidate_offset");
        EmitAssign(candidateOffset, $"zext i16 {candidateOffset16} to i64");
        var candidateUnwrapped = NextTemp("generic_dict_candidate_unwrapped");
        EmitBinary(candidateUnwrapped, "add", "i64", groupStart, candidateOffset);
        var candidateSlot = NextTemp("generic_dict_candidate_slot");
        EmitBinary(candidateSlot, "and", "i64", candidateUnwrapped, mask);
        var storedKey = LoadInlineDictionaryField(
            dictionary, candidateSlot, definition.KeyType, 0, definition.KeyAlignment, "generic_dict_key");
        var equal = EmitValuesEqual(storedKey, key);
        EmitConditionalBranch(equal, match, candidateNext); EmitFunctionLine();

        EmitLabel(candidateNext); _currentBlockLabel = candidateNext;
        var bitsMinusOne = NextTemp("generic_dict_candidate_bits_minus_one");
        EmitBinary(bitsMinusOne, "sub", "i16", candidateBits, "1");
        EmitBinary(clearedBits, "and", "i16", candidateBits, bitsMinusOne);
        EmitBranch(candidateLoop); EmitFunctionLine();

        EmitLabel(groupDecision); _currentBlockLabel = groupDecision;
        var hasEmpty = NextTemp("generic_dict_group_has_empty");
        EmitCompare(hasEmpty, "ne", "i16", emptyBits, "0");
        EmitConditionalBranch(hasEmpty, empty, nextGroup); EmitFunctionLine();

        EmitLabel(empty); _currentBlockLabel = empty;
        var emptyOffset16 = NextTemp("generic_dict_group_empty_offset16");
        EmitCall(emptyOffset16, "i16", "llvm.cttz.i16", $"i16 {emptyBits}, i1 false");
        var emptyOffset = NextTemp("generic_dict_group_empty_offset");
        EmitAssign(emptyOffset, $"zext i16 {emptyOffset16} to i64");
        var emptyUnwrapped = NextTemp("generic_dict_group_empty_unwrapped");
        EmitBinary(emptyUnwrapped, "add", "i64", groupStart, emptyOffset);
        var firstEmptySlot = NextTemp("generic_dict_group_empty_slot");
        EmitBinary(firstEmptySlot, "and", "i64", emptyUnwrapped, mask);
        var useEmpty = NextTemp("generic_dict_group_use_empty");
        EmitCompare(useEmpty, "eq", "i64", capturedDeleted, dictionary.CapacityName);
        var insertionSlot = NextTemp("generic_dict_group_insertion_slot");
        EmitSelect(insertionSlot, useEmpty, $"i64 {firstEmptySlot}", $"i64 {capturedDeleted}");
        EmitBranch(done); EmitFunctionLine();

        EmitLabel(match); _currentBlockLabel = match;
        EmitBranch(done); EmitFunctionLine();

        EmitLabel(nextGroup); _currentBlockLabel = nextGroup;
        EmitBinary(nextProbe, "add", "i64", probe, "16");
        EmitBinary(nextFirstDeleted, "add", "i64", capturedDeleted, "0");
        EmitBranch(groupLoop); EmitFunctionLine();

        EmitLabel(miss); _currentBlockLabel = miss;
        var missHasNoDeleted = NextTemp("generic_dict_group_miss_no_deleted");
        EmitCompare(missHasNoDeleted, "eq", "i64", firstDeleted, dictionary.CapacityName);
        var missSlot = NextTemp("generic_dict_group_miss_slot");
        EmitSelect(missSlot, missHasNoDeleted, "i64 0", $"i64 {firstDeleted}");
        EmitBranch(done); EmitFunctionLine();

        EmitLabel(done);
        var found = NextTemp("generic_dict_find_found");
        EmitPhi(found, "i1", ("false", empty), ("true", match), ("false", miss));
        var foundSlot = NextTemp("generic_dict_find_slot_result");
        EmitPhi(foundSlot, "i64", (insertionSlot, empty), (candidateSlot, match), (missSlot, miss));
        _currentBlockLabel = done;
        return new DictionaryFindResult(found, foundSlot, h2);
    }

    private RuntimeInlineDictionary EmitInlineDictionaryPut(
        RuntimeInlineDictionary dictionary, RuntimeValue key, RuntimeValue value)
    {
        var found = EmitInlineDictionaryFindSlot(dictionary, key);
        var update = NextLabel("generic_dict_put_update");
        var insert = NextLabel("generic_dict_put_insert");
        var insertCurrent = NextLabel("generic_dict_put_current");
        var insertGrown = NextLabel("generic_dict_put_grown");
        var done = NextLabel("generic_dict_put_done");
        EmitConditionalBranch(found.FoundName, update, insert); EmitFunctionLine();
        EmitLabel(update);
        _currentBlockLabel = update;
        EmitInlineDictionaryReplaceValue(dictionary, found.SlotName, key, value);
        EmitBranch(done);
        var updateEnd = _currentBlockLabel; EmitFunctionLine();
        EmitLabel(insert);
        _currentBlockLabel = insert;
        var nextLength = NextTemp("generic_dict_next_len");
        EmitBinary(nextLength, "add", "i64", dictionary.LengthName, "1");
        if (_program.Types.IsBoundedDictionary(dictionary.DictionaryType))
        {
            var bounded = _program.Types.GetBoundedDictionary(dictionary.DictionaryType);
            var withinBound = NextTemp("bounded_dict_within_capacity");
            EmitCompare(withinBound, "ule", "i64", nextLength,
                bounded.MaxEntries.ToString(CultureInfo.InvariantCulture));
            EmitTrapUnless(withinBound, "bounded_dictionary_capacity");
            StoreInlineDictionaryEntry(dictionary, found.SlotName, key, value);
            StoreInlineDictionaryControl(dictionary, found.SlotName, found.H2ByteName);
            EmitBranch(done);
            var boundedInsertEnd = _currentBlockLabel;
            EmitFunctionLine();
            EmitLabel(done);
            var boundedPointer = NextTemp("bounded_dict_ptr");
            EmitPhi(boundedPointer, "ptr",
                (dictionary.PointerName, updateEnd),
                (dictionary.PointerName, boundedInsertEnd));
            var boundedLength = NextTemp("bounded_dict_len");
            EmitPhi(boundedLength, "i64",
                (dictionary.LengthName, updateEnd),
                (nextLength, boundedInsertEnd));
            _currentBlockLabel = done;
            return dictionary with { PointerName = boundedPointer, LengthName = boundedLength };
        }
        var numerator = NextTemp("generic_dict_load_num");
        var denominator = NextTemp("generic_dict_load_den");
        EmitBinary(numerator, "mul", "i64", nextLength, "8");
        EmitBinary(denominator, "mul", "i64", dictionary.CapacityName, "7");
        var shouldGrow = NextTemp("generic_dict_should_grow");
        EmitCompare(shouldGrow, "ugt", "i64", numerator, denominator);
        EmitConditionalBranch(shouldGrow, insertGrown, insertCurrent); EmitFunctionLine();
        EmitLabel(insertCurrent);
        _currentBlockLabel = insertCurrent;
        StoreInlineDictionaryEntry(dictionary, found.SlotName, key, value);
        StoreInlineDictionaryControl(dictionary, found.SlotName, found.H2ByteName);
        EmitBranch(done);
        var currentEnd = _currentBlockLabel; EmitFunctionLine();
        EmitLabel(insertGrown);
        _currentBlockLabel = insertGrown;
        var grown = EmitInlineDictionaryGrow(dictionary);
        EmitInlineDictionaryInsertUnique(grown, key, value);
        EmitBranch(done);
        var grownEnd = _currentBlockLabel; EmitFunctionLine();
        EmitLabel(done);
        var pointer = NextTemp("generic_dict_ptr");
        EmitPhi(pointer, "ptr", (dictionary.PointerName, updateEnd), (dictionary.PointerName, currentEnd), (grown.PointerName, grownEnd));
        var length = NextTemp("generic_dict_len");
        EmitPhi(length, "i64", (dictionary.LengthName, updateEnd), (nextLength, currentEnd), (nextLength, grownEnd));
        var capacity = NextTemp("generic_dict_capacity");
        EmitPhi(capacity, "i64", (dictionary.CapacityName, updateEnd), (dictionary.CapacityName, currentEnd), (grown.CapacityName, grownEnd));
        _currentBlockLabel = done;
        return dictionary with { PointerName = pointer, LengthName = length, CapacityName = capacity };
    }

    private (RuntimeInlineDictionary Dictionary, RuntimeBool Inserted) EmitInlineDictionaryPutIfAbsent(
        RuntimeInlineDictionary dictionary,
        RuntimeValue key,
        RuntimeValue value)
    {
        var found = EmitInlineDictionaryFindSlot(dictionary, key);
        var duplicate = NextLabel("generic_dict_put_if_absent_duplicate");
        var insert = NextLabel("generic_dict_put_if_absent_insert");
        var current = NextLabel("generic_dict_put_if_absent_current");
        var grow = NextLabel("generic_dict_put_if_absent_grow");
        var done = NextLabel("generic_dict_put_if_absent_done");
        EmitConditionalBranch(found.FoundName, duplicate, insert); EmitFunctionLine();

        EmitLabel(duplicate);
        _currentBlockLabel = duplicate;
        if (_program.Types.ContainsOwnedStorage(dictionary.KeyType))
        {
            DropOwnedRuntimeValue(key);
        }
        if (_program.Types.ContainsOwnedStorage(dictionary.ValueType))
        {
            DropOwnedRuntimeValue(value);
        }
        EmitBranch(done);
        var duplicateEnd = _currentBlockLabel; EmitFunctionLine();

        EmitLabel(insert);
        _currentBlockLabel = insert;
        var nextLength = NextTemp("generic_dict_put_if_absent_length");
        EmitBinary(nextLength, "add", "i64", dictionary.LengthName, "1");
        if (_program.Types.IsBoundedDictionary(dictionary.DictionaryType))
        {
            var bounded = _program.Types.GetBoundedDictionary(dictionary.DictionaryType);
            var withinBound = NextTemp("bounded_dict_put_if_absent_within_capacity");
            EmitCompare(withinBound, "ule", "i64", nextLength,
                bounded.MaxEntries.ToString(CultureInfo.InvariantCulture));
            EmitTrapUnless(withinBound, "bounded_dictionary_capacity");
            StoreInlineDictionaryEntry(dictionary, found.SlotName, key, value);
            StoreInlineDictionaryControl(dictionary, found.SlotName, found.H2ByteName);
            EmitBranch(done);
            var insertedEnd = _currentBlockLabel; EmitFunctionLine();
            EmitLabel(done);
            var boundedLength = NextTemp("bounded_dict_put_if_absent_length_result");
            EmitPhi(boundedLength, "i64", (dictionary.LengthName, duplicateEnd), (nextLength, insertedEnd));
            var boundedInserted = NextTemp("bounded_dict_put_if_absent_inserted");
            EmitPhi(boundedInserted, "i1", ("false", duplicateEnd), ("true", insertedEnd));
            _currentBlockLabel = done;
            return (dictionary with { LengthName = boundedLength }, new RuntimeBool(boundedInserted));
        }

        var numerator = NextTemp("generic_dict_put_if_absent_load_num");
        var denominator = NextTemp("generic_dict_put_if_absent_load_den");
        EmitBinary(numerator, "mul", "i64", nextLength, "8");
        EmitBinary(denominator, "mul", "i64", dictionary.CapacityName, "7");
        var shouldGrow = NextTemp("generic_dict_put_if_absent_should_grow");
        EmitCompare(shouldGrow, "ugt", "i64", numerator, denominator);
        EmitConditionalBranch(shouldGrow, grow, current); EmitFunctionLine();

        EmitLabel(current);
        _currentBlockLabel = current;
        StoreInlineDictionaryEntry(dictionary, found.SlotName, key, value);
        StoreInlineDictionaryControl(dictionary, found.SlotName, found.H2ByteName);
        EmitBranch(done);
        var currentEnd = _currentBlockLabel; EmitFunctionLine();

        EmitLabel(grow);
        _currentBlockLabel = grow;
        var grown = EmitInlineDictionaryGrow(dictionary);
        EmitInlineDictionaryInsertUnique(grown, key, value);
        EmitBranch(done);
        var growEnd = _currentBlockLabel; EmitFunctionLine();

        EmitLabel(done);
        var pointer = NextTemp("generic_dict_put_if_absent_ptr");
        EmitPhi(pointer, "ptr", (dictionary.PointerName, duplicateEnd), (dictionary.PointerName, currentEnd), (grown.PointerName, growEnd));
        var length = NextTemp("generic_dict_put_if_absent_length_result");
        EmitPhi(length, "i64", (dictionary.LengthName, duplicateEnd), (nextLength, currentEnd), (nextLength, growEnd));
        var capacity = NextTemp("generic_dict_put_if_absent_capacity");
        EmitPhi(capacity, "i64", (dictionary.CapacityName, duplicateEnd), (dictionary.CapacityName, currentEnd), (grown.CapacityName, growEnd));
        var inserted = NextTemp("generic_dict_put_if_absent_inserted");
        EmitPhi(inserted, "i1", ("false", duplicateEnd), ("true", currentEnd), ("true", growEnd));
        _currentBlockLabel = done;
        return (dictionary with { PointerName = pointer, LengthName = length, CapacityName = capacity }, new RuntimeBool(inserted));
    }

    private void EmitInlineDictionaryAssignExisting(
        RuntimeInlineDictionary dictionary,
        RuntimeValue key,
        RuntimeValue value)
    {
        var definition = _program.Types.GetDictionary(dictionary.DictionaryType);
        var found = EmitInlineDictionaryFindSlot(dictionary, key);
        EmitTrapUnless(found.FoundName, "generic_dict_assign_missing");
        EmitInlineDictionaryReplaceValue(dictionary, found.SlotName, discardedEqualKey: null, value);
    }

    private void EmitInlineDictionaryReplaceValue(
        RuntimeInlineDictionary dictionary,
        string slot,
        RuntimeValue? discardedEqualKey,
        RuntimeValue value)
    {
        var definition = _program.Types.GetDictionary(dictionary.DictionaryType);
        if (discardedEqualKey is not null && _program.Types.ContainsOwnedStorage(definition.KeyType))
        {
            DropOwnedRuntimeValue(discardedEqualKey);
        }
        var valueSlot = EmitInlineDictionaryEntryPointer(
            dictionary,
            slot,
            definition.ValueOffset,
            "generic_dict_assign_value");
        if (_program.Types.ContainsOwnedStorage(definition.ValueType))
        {
            var previous = NextTemp("generic_dict_assign_previous");
            EmitLoad(previous, LlvmType(definition.ValueType), valueSlot, definition.ValueAlignment);
            DropOwnedRuntimeValue(DematerializeAggregateValue(definition.ValueType, previous));
        }
        var materialized = MaterializeAggregateValue(value);
        EmitStore(materialized.TypeName, materialized.ValueName, valueSlot, definition.ValueAlignment);
    }

    private (RuntimeInlineDictionary Dictionary, RuntimeValue Value) EmitInlineDictionaryTake(
        RuntimeInlineDictionary dictionary,
        RuntimeValue key)
    {
        var definition = _program.Types.GetDictionary(dictionary.DictionaryType);
        var found = EmitInlineDictionaryFindSlot(dictionary, key);
        EmitTrapUnless(found.FoundName, "generic_dict_take_missing");
        var storedKey = LoadInlineDictionaryField(
            dictionary,
            found.SlotName,
            definition.KeyType,
            0,
            definition.KeyAlignment,
            "generic_dict_take_key");
        var value = LoadInlineDictionaryField(
            dictionary,
            found.SlotName,
            definition.ValueType,
            definition.ValueOffset,
            definition.ValueAlignment,
            "generic_dict_take_value");
        if (_program.Types.ContainsOwnedStorage(definition.KeyType))
        {
            var materializedKey = MaterializeAggregateValue(storedKey);
            EmitOwnedDropCall(definition.KeyType, materializedKey.ValueName);
        }

        var nextLength = NextTemp("generic_dict_take_length");
        EmitBinary(nextLength, "sub", "i64", dictionary.LengthName, "1");
        if (_program.Types.IsBoundedDictionary(dictionary.DictionaryType))
        {
            StoreInlineDictionaryControl(dictionary, found.SlotName, "-1");
            return (dictionary with { LengthName = nextLength }, value);
        }
        var target = dictionary with
        {
            PointerName = EmitInlineDictionaryAllocate(dictionary.CapacityName, definition),
            LengthName = nextLength
        };
        EmitInlineDictionaryRehashExcept(dictionary, target, found.SlotName);
        EmitCall(target: null, "void", "sollang_free", $"ptr {dictionary.PointerName}");
        return (target, value);
    }

    private RuntimeInlineDictionary EmitInlineDictionaryGrow(RuntimeInlineDictionary dictionary)
    {
        var zero = NextTemp("generic_dict_zero_capacity");
        EmitCompare(zero, "eq", "i64", dictionary.CapacityName, "0");
        var doubled = NextTemp("generic_dict_doubled_capacity");
        EmitBinary(doubled, "mul", "i64", dictionary.CapacityName, "2");
        var capacity = NextTemp("generic_dict_new_capacity");
        EmitSelect(capacity, zero, "i64 4", $"i64 {doubled}");
        var definition = _program.Types.GetDictionary(dictionary.DictionaryType);
        var target = dictionary with
        {
            PointerName = EmitInlineDictionaryAllocate(capacity, definition),
            CapacityName = capacity
        };
        EmitInlineDictionaryRehash(dictionary, target);
        EmitCall(target: null, "void", "sollang_free", $"ptr {dictionary.PointerName}");
        return target;
    }

    private RuntimeInlineDictionary EmitInlineDictionaryReserve(
        RuntimeInlineDictionary dictionary,
        string requestedEntries)
    {
        var requestedCapacity = EmitDictionaryCapacityForEntries(requestedEntries, "generic_dict_reserve");
        var grow = NextTemp("generic_dict_reserve_grow");
        EmitCompare(grow, "ugt", "i64", requestedCapacity, dictionary.CapacityName);
        var allocate = NextLabel("generic_dict_reserve_allocate");
        var keep = NextLabel("generic_dict_reserve_keep");
        var done = NextLabel("generic_dict_reserve_done");
        EmitConditionalBranch(grow, allocate, keep); EmitFunctionLine();

        EmitLabel(keep);
        _currentBlockLabel = keep;
        EmitBranch(done);
        var keepEnd = _currentBlockLabel; EmitFunctionLine();

        EmitLabel(allocate);
        _currentBlockLabel = allocate;
        var definition = _program.Types.GetDictionary(dictionary.DictionaryType);
        var target = dictionary with
        {
            PointerName = EmitInlineDictionaryAllocate(requestedCapacity, definition),
            CapacityName = requestedCapacity
        };
        EmitInlineDictionaryRehash(dictionary, target);
        EmitCall(null, "void", "sollang_free", $"ptr {dictionary.PointerName}");
        EmitBranch(done);
        var allocateEnd = _currentBlockLabel; EmitFunctionLine();

        EmitLabel(done);
        var pointer = NextTemp("generic_dict_reserve_ptr");
        EmitPhi(pointer, "ptr", (dictionary.PointerName, keepEnd), (target.PointerName, allocateEnd));
        var capacity = NextTemp("generic_dict_reserve_capacity_result");
        EmitPhi(capacity, "i64", (dictionary.CapacityName, keepEnd), (requestedCapacity, allocateEnd));
        _currentBlockLabel = done;
        return dictionary with { PointerName = pointer, CapacityName = capacity };
    }

    private void EmitInlineDictionaryRehash(RuntimeInlineDictionary source, RuntimeInlineDictionary target)
    {
        var definition = _program.Types.GetDictionary(source.DictionaryType);
        var entry = _currentBlockLabel;
        var loop = NextLabel("generic_dict_rehash");
        var body = NextLabel("generic_dict_rehash_body");
        var move = NextLabel("generic_dict_rehash_move");
        var next = NextLabel("generic_dict_rehash_next");
        var done = NextLabel("generic_dict_rehash_done");
        var nextI = NextTemp("generic_dict_rehash_next_i");
        EmitBranch(loop); EmitFunctionLine();
        EmitLabel(loop);
        var i = NextTemp("generic_dict_rehash_i");
        EmitPhi(i, "i64", ("0", entry), (nextI, next));
        var active = NextTemp("generic_dict_rehash_active");
        EmitCompare(active, "ult", "i64", i, source.CapacityName);
        EmitConditionalBranch(active, body, done); EmitFunctionLine();
        EmitLabel(body);
        var control = LoadInlineDictionaryControl(source, i);
        var occupied = NextTemp("generic_dict_rehash_occupied");
        EmitCompare(occupied, "ne", "i8", control, "0");
        EmitConditionalBranch(occupied, move, next); EmitFunctionLine();
        EmitLabel(move);
        _currentBlockLabel = move;
        var key = LoadInlineDictionaryField(source, i, definition.KeyType, 0, definition.KeyAlignment, "generic_dict_rehash_key");
        var value = LoadInlineDictionaryField(source, i, definition.ValueType, definition.ValueOffset, definition.ValueAlignment, "generic_dict_rehash_value");
        EmitInlineDictionaryInsertUnique(target, key, value);
        EmitBranch(next); EmitFunctionLine();
        EmitLabel(next);
        EmitBinary(nextI, "add", "i64", i, "1");
        EmitBranch(loop); EmitFunctionLine();
        EmitLabel(done);
        _currentBlockLabel = done;
    }

    private void EmitInlineDictionaryRehashExcept(
        RuntimeInlineDictionary source,
        RuntimeInlineDictionary target,
        string removedSlot)
    {
        var definition = _program.Types.GetDictionary(source.DictionaryType);
        var entry = _currentBlockLabel;
        var loop = NextLabel("generic_dict_take_rehash");
        var body = NextLabel("generic_dict_take_rehash_body");
        var inspect = NextLabel("generic_dict_take_rehash_inspect");
        var move = NextLabel("generic_dict_take_rehash_move");
        var next = NextLabel("generic_dict_take_rehash_next");
        var done = NextLabel("generic_dict_take_rehash_done");
        var nextI = NextTemp("generic_dict_take_rehash_next_i");
        EmitBranch(loop); EmitFunctionLine();
        EmitLabel(loop);
        var i = NextTemp("generic_dict_take_rehash_i");
        EmitPhi(i, "i64", ("0", entry), (nextI, next));
        var active = NextTemp("generic_dict_take_rehash_active");
        EmitCompare(active, "ult", "i64", i, source.CapacityName);
        EmitConditionalBranch(active, body, done); EmitFunctionLine();
        EmitLabel(body);
        var removed = NextTemp("generic_dict_take_rehash_removed");
        EmitCompare(removed, "eq", "i64", i, removedSlot);
        EmitConditionalBranch(removed, next, inspect); EmitFunctionLine();
        EmitLabel(inspect);
        var control = LoadInlineDictionaryControl(source, i);
        var occupied = NextTemp("generic_dict_take_rehash_occupied");
        EmitCompare(occupied, "ne", "i8", control, "0");
        EmitConditionalBranch(occupied, move, next); EmitFunctionLine();
        EmitLabel(move);
        _currentBlockLabel = move;
        var key = LoadInlineDictionaryField(
            source,
            i,
            definition.KeyType,
            0,
            definition.KeyAlignment,
            "generic_dict_take_rehash_key");
        var value = LoadInlineDictionaryField(
            source,
            i,
            definition.ValueType,
            definition.ValueOffset,
            definition.ValueAlignment,
            "generic_dict_take_rehash_value");
        EmitInlineDictionaryInsertUnique(target, key, value);
        EmitBranch(next); EmitFunctionLine();
        EmitLabel(next);
        _currentBlockLabel = next;
        EmitBinary(nextI, "add", "i64", i, "1");
        EmitBranch(loop); EmitFunctionLine();
        EmitLabel(done);
        _currentBlockLabel = done;
    }

    private void DropInlineDictionaryElements(RuntimeInlineDictionary dictionary)
    {
        var definition = _program.Types.GetDictionary(dictionary.DictionaryType);
        var dropKeys = _program.Types.ContainsOwnedStorage(definition.KeyType);
        var dropValues = _program.Types.ContainsOwnedStorage(definition.ValueType);
        if (!dropKeys && !dropValues)
        {
            return;
        }
        var entry = _currentBlockLabel;
        var loop = NextLabel("drop_generic_dict");
        var body = NextLabel("drop_generic_dict_body");
        var occupied = NextLabel("drop_generic_dict_occupied");
        var next = NextLabel("drop_generic_dict_next");
        var done = NextLabel("drop_generic_dict_done");
        var nextI = NextTemp("drop_generic_dict_next_i");
        EmitBranch(loop); EmitFunctionLine();
        EmitLabel(loop);
        var i = NextTemp("drop_generic_dict_i");
        EmitPhi(i, "i64", ("0", entry), (nextI, next));
        var active = NextTemp("drop_generic_dict_active");
        EmitCompare(active, "ult", "i64", i, dictionary.CapacityName);
        EmitConditionalBranch(active, body, done); EmitFunctionLine();
        EmitLabel(body);
        var control = LoadInlineDictionaryControl(dictionary, i);
        var full = NextTemp("drop_generic_dict_full");
        EmitCompare(full, "sgt", "i8", control, "0");
        EmitConditionalBranch(full, occupied, next); EmitFunctionLine();
        EmitLabel(occupied);
        _currentBlockLabel = occupied;
        if (dropKeys)
        {
            var key = LoadInlineDictionaryField(dictionary, i, definition.KeyType, 0, definition.KeyAlignment, "drop_generic_dict_key");
            var materialized = MaterializeAggregateValue(key);
            EmitOwnedDropCall(definition.KeyType, materialized.ValueName);
        }
        if (dropValues)
        {
            var value = LoadInlineDictionaryField(dictionary, i, definition.ValueType, definition.ValueOffset, definition.ValueAlignment, "drop_generic_dict_value");
            var materialized = MaterializeAggregateValue(value);
            EmitOwnedDropCall(definition.ValueType, materialized.ValueName);
        }
        EmitBranch(next); EmitFunctionLine();
        EmitLabel(next);
        EmitBinary(nextI, "add", "i64", i, "1");
        EmitBranch(loop); EmitFunctionLine();
        EmitLabel(done);
        _currentBlockLabel = done;
    }
}

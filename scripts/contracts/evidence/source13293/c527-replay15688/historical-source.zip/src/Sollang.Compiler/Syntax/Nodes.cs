namespace Sollang.Compiler.Syntax;

internal sealed record SollangProgram(
    IReadOnlyList<string> NamespacePath,
    IReadOnlyList<ImportDeclaration> Imports,
    IReadOnlyList<StructDeclaration> Structs,
    IReadOnlyList<EnumDeclaration> Enums,
    IReadOnlyList<TraitDeclaration> Traits,
    IReadOnlyList<FunctionDeclaration> Functions,
    IReadOnlyList<Statement> Statements,
    IReadOnlyList<NativeLibraryImport>? NativeLibraries = null,
    IReadOnlyList<SourceStyleNote>? StyleNotes = null);

internal sealed record SourceStyleNote(
    string Code,
    string ModuleName,
    int Line,
    int Column,
    string Message);

internal sealed record ImportDeclaration(
    IReadOnlyList<string> Path,
    string Alias);

internal sealed record NativeLibraryImport(
    string Alias,
    string Library,
    int Line,
    int Column);

internal sealed record OpenImportCandidate(
    IReadOnlyList<string> Path,
    string ModuleAlias);

internal sealed record StructDeclaration(
    string Name,
    IReadOnlyList<StructFieldDeclaration> Fields,
    int Line,
    int Column,
    string ModuleName = "",
    bool IsPublic = false,
    string? DeclaringTypeName = null,
    bool IsAbi = false,
    ComInterfaceMetadata? ComInterface = null,
    NativeHandleMetadata? NativeHandle = null);

internal sealed record StructFieldDeclaration(
    string Name,
    string TypeName,
    int Line,
    int Column,
    bool IsPublic = false);

internal sealed record EnumDeclaration(
    string Name,
    IReadOnlyList<EnumVariantDeclaration> Variants,
    int Line,
    int Column,
    string ModuleName = "",
    bool IsPublic = false);

internal sealed record EnumVariantDeclaration(string Name, string? PayloadType, int Line, int Column);

internal sealed record TraitDeclaration(
    string Name,
    IReadOnlyList<TraitAssociatedTypeDeclaration> AssociatedTypes,
    IReadOnlyList<TraitMethodDeclaration> Methods,
    int Line,
    int Column,
    string ModuleName = "",
    bool IsPublic = false);

internal sealed record TraitAssociatedTypeDeclaration(string Name, int Line, int Column);

internal sealed record TraitMethodDeclaration(
    string Name,
    FunctionInputOwnership SelfOwnership,
    string ReturnType,
    int Line,
    int Column,
    IReadOnlyList<FunctionParameterDeclaration> AdditionalParameters);

internal sealed record GenericParameterDeclaration(
    string Name,
    IReadOnlyList<GenericConstraintDeclaration> Constraints,
    int Line,
    int Column,
    bool IsValue = false);

internal sealed record GenericConstraintDeclaration(
    string ParameterName,
    string? TraitName,
    string? AssociatedTypeName,
    string? EqualTypeName,
    int Line,
    int Column);

internal sealed record FunctionDeclaration(
    string Name,
    string? InputName,
    string? InputType,
    FunctionInputOwnership InputOwnership,
    string ReturnType,
    string? BlockInputName,
    string? BlockInputType,
    IReadOnlyList<FunctionDeclaration> LocalFunctions,
    Expression? Body,
    IReadOnlyList<Statement> BlockBody,
    int Line,
    int Column,
    bool IsIntrinsic,
    bool IsStandardLibrary,
    string? TraitName = null,
    string? GenericParameterName = null,
    string? SecondaryGenericParameterName = null,
    string? TertiaryGenericParameterName = null,
    string? GenericTraitBound = null,
    string? GenericAssociatedTypeName = null,
    string? GenericAssociatedTypeConstraint = null,
    IReadOnlyDictionary<string, string>? ImplAssociatedTypes = null,
    bool IsValueGeneric = false,
    bool HasValueGenericFixedArrayInput = false,
    string ModuleName = "",
    bool IsPublic = false,
    bool IsAsync = false,
    IReadOnlyList<string>? Effects = null,
    string? BlockResultType = null,
    IReadOnlyList<FunctionParameterDeclaration>? AdditionalParameters = null,
    IReadOnlyList<FunctionParameterDeclaration>? AdditionalBlockParameters = null,
    string? StreamElementType = null,
    string? NativeLibrary = null,
    string? NativeSymbol = null,
    ComFunctionMetadata? Com = null,
    NativeErrorConvention NativeError = NativeErrorConvention.Direct,
    string? NativeSuccessType = null,
    IReadOnlyList<GenericParameterDeclaration>? GenericParameters = null);

internal enum NativeErrorConvention
{
    Direct,
    StatusOut
}

internal enum ComApartment
{
    Sta,
    Mta
}

internal enum ComFunctionOperation
{
    Activate,
    Clone,
    Query,
    Method
}

internal sealed record ComInterfaceMetadata(
    string Alias,
    string ClassId,
    string InterfaceId,
    string? Server,
    ComApartment Apartment);

internal sealed record NativeHandleMetadata(
    string Alias,
    string Library,
    string DropSymbol);

internal sealed record ComFunctionMetadata(
    ComFunctionOperation Operation,
    string InterfaceType,
    string ClassId,
    string InterfaceId,
    string? Server,
    ComApartment Apartment,
    int VtableSlot = -1,
    string? ReceiverInterfaceType = null);

internal static class InferredFunctionType
{
    public const string Name = "<inferred>";
}

internal sealed record FunctionParameterDeclaration(
    string Name,
    string TypeName,
    FunctionInputOwnership Ownership,
    int Line,
    int Column);

internal enum FunctionInputOwnership
{
    Default,
    Move,
    MutableBorrow
}

internal abstract record Statement;

internal sealed record BindingStatement(
    string Name,
    Expression Value,
    int Line,
    int Column,
    bool IsMutable,
    bool IsStreamState = false) : Statement;

internal sealed record IndexAssignmentStatement(string Name, Expression Index, Expression Value, int Line, int Column)
    : Statement;

internal sealed record FieldAssignmentStatement(
    string Name,
    string FieldName,
    Expression Value,
    int Line,
    int Column)
    : Statement;

internal sealed record BlockFunctionCallStatement(
    Expression Source,
    IReadOnlyList<string> Target,
    string ItemName,
    IReadOnlyList<Statement> Body,
    string? ResultName,
    bool ResultIsMutable,
    int Line,
    int Column,
    bool UsesDefaultItemName,
    bool ResultIsSynthetic = false,
    IReadOnlyList<Expression>? Arguments = null,
    IReadOnlyList<string>? AdditionalItemNames = null, FlowTarget? SourceFlowTarget = null)
    : Statement
{
    public object ResolutionSite => SourceFlowTarget ?? (object)this;
}

internal sealed record BlockFunctionPipelineStatement(
    IReadOnlyList<BlockFunctionCallStatement> Calls,
    int Line,
    int Column)
    : Statement;

internal sealed record ExpressionStatement(Expression Expression) : Statement;

internal enum LoopControlKind
{
    Break,
    Continue
}

internal sealed record LoopControlStatement(LoopControlKind Kind, int Line, int Column) : Statement;

internal sealed record StreamStopStatement(int Line, int Column) : Statement;

internal sealed record GuardLoopControlStatement(
    Expression Condition,
    LoopControlKind Kind,
    int Line,
    int Column) : Statement;

internal sealed record ReturnStatement(Expression? Value, int Line, int Column) : Statement;

internal abstract record Expression(int Line, int Column);

internal sealed record StringExpression(IReadOnlyList<StringSegment> Segments, int Line, int Column)
    : Expression(Line, Column);

internal sealed record NumberExpression(string Text, int Line, int Column) : Expression(Line, Column);

internal sealed record BoolExpression(bool Value, int Line, int Column) : Expression(Line, Column);

internal sealed record NameExpression(string Name, int Line, int Column, int ByteOffset = -1)
    : Expression(Line, Column);

internal sealed record AddExpression(Expression Left, Expression Right, int Line, int Column)
    : Expression(Line, Column);

internal sealed record SubtractExpression(Expression Left, Expression Right, int Line, int Column)
    : Expression(Line, Column);

internal sealed record MultiplyExpression(Expression Left, Expression Right, int Line, int Column)
    : Expression(Line, Column);

internal sealed record DivideExpression(Expression Left, Expression Right, int Line, int Column)
    : Expression(Line, Column);

internal sealed record ModuloExpression(Expression Left, Expression Right, int Line, int Column)
    : Expression(Line, Column);

internal sealed record NegateExpression(Expression Value, int Line, int Column)
    : Expression(Line, Column);

internal sealed record CompareExpression(
    Expression Left,
    ComparisonOperator Operator,
    Expression Right,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record AndExpression(Expression Left, Expression Right, int Line, int Column)
    : Expression(Line, Column);

internal sealed record OrExpression(Expression Left, Expression Right, int Line, int Column)
    : Expression(Line, Column);

internal sealed record NotExpression(Expression Value, int Line, int Column)
    : Expression(Line, Column);

internal sealed record RangeExpression(
    Expression Start,
    Expression End,
    int Line,
    int Column,
    bool IsEndExclusive = false)
    : Expression(Line, Column);

internal sealed record CompileTimeEachExpression(
    Expression Source,
    string ItemName,
    Expression Selector,
    Expression? DictionaryValueSelector,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record FoldExpression(
    Expression Source,
    Expression Initial,
    string AccumulatorName,
    string ItemName,
    BlockBody Body,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record IfExpression(
    Expression Condition,
    BlockBody Then,
    BlockBody? Else,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record WhenExpression(
    Expression? Subject,
    IReadOnlyList<WhenArm> Arms,
    BlockBody Else,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record FlowExpression(
    Expression Source,
    IReadOnlyList<FlowTarget> Targets,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record FlowTarget(
    IReadOnlyList<string> Path,
    IReadOnlyList<Expression> Arguments,
    bool UsesCallSyntax,
    string? TypeArgument,
    int? CompileTimeValueArgument,
    int Line,
    int Column,
    IReadOnlyList<OpenImportCandidate>? OpenImportCandidates = null,
    int ByteOffset = -1);

internal enum BranchInputMode
{
    Default,
    ReadonlyBorrow,
    MutableBorrow,
    Move
}

internal sealed record BranchExpression(
    Expression Source,
    IReadOnlyList<BranchArm> Arms,
    bool IsParallel,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record BranchArm(
    string Label,
    BranchInputMode InputMode,
    IReadOnlyList<FlowTarget> Targets,
    int Line,
    int Column);

internal sealed record TapExpression(
    Expression Source,
    IReadOnlyList<FlowTarget> Targets,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record PartitionExpression(
    Expression Source,
    string ItemName,
    IReadOnlyList<PartitionArm> Arms,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record PartitionArm(
    string Label,
    Expression? Condition,
    int Line,
    int Column);

internal enum StreamJoinPolicy
{
    Zip,
    Merge,
    Concat,
    Latest
}

internal sealed record StreamJoinExpression(
    Expression Source,
    StreamJoinPolicy Policy,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record CallExpression(
    IReadOnlyList<string> Path,
    IReadOnlyList<Expression> Arguments,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record ArrayLiteralExpression(
    IReadOnlyList<Expression> Elements,
    bool IsDynamic,
    int Line,
    int Column,
    string? ElementType = null,
    int? BoundedCapacity = null)
    : Expression(Line, Column);

internal sealed record TypeApplicationExpression(
    IReadOnlyList<string> Path,
    string TypeArgument,
    int Line,
    int Column,
    IReadOnlyList<Expression>? Arguments = null,
    IReadOnlyList<string>? AdditionalTypeArguments = null)
    : Expression(Line, Column);

internal sealed record ArrayRepeatExpression(
    Expression Value,
    int? Count,
    string? CountParameterName,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record TypedEmptyArrayExpression(
    string ElementType,
    int? CapacityHint,
    int Line,
    int Column,
    int? BoundedCapacity = null)
    : Expression(Line, Column);

internal sealed record DictionaryLiteralExpression(
    IReadOnlyList<DictionaryEntryExpression> Entries,
    int Line,
    int Column,
    string? KeyType = null,
    string? ValueType = null,
    int? BoundedCapacity = null)
    : Expression(Line, Column);

internal sealed record TypedEmptyDictionaryExpression(
    string KeyType,
    string ValueType,
    int? CapacityHint,
    int Line,
    int Column,
    int? BoundedCapacity = null)
    : Expression(Line, Column);

internal sealed record DictionaryEntryExpression(Expression Key, Expression Value);

internal sealed record ProductExpression(
    IReadOnlyList<ProductElement> Elements,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record ProductElement(string? Label, Expression Value, int Line, int Column);

internal sealed record IndexExpression(Expression Source, Expression Index, int Line, int Column)
    : Expression(Line, Column);

internal sealed record StructLiteralExpression(
    string TypeName,
    IReadOnlyList<StructFieldInitializer> Fields,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record StructFieldInitializer(string Name, Expression Value, int Line, int Column);

internal sealed record FieldAccessExpression(Expression Source, string FieldName, int Line, int Column)
    : Expression(Line, Column);

internal sealed record TryExpression(Expression Value, int Line, int Column)
    : Expression(Line, Column);

internal sealed record BoxExpression(Expression Value, int Line, int Column)
    : Expression(Line, Column);

internal enum MapAccessMode
{
    Read,
    Write
}

internal sealed record MapExpression(
    MapAccessMode Mode,
    Expression Path,
    Expression? Offset,
    Expression? Length,
    Expression? FileSize,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record EnumPatternExpression(
    string TypeName,
    string VariantName,
    string? BindingName,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record EnumMatchExpression(
    Expression Subject,
    IReadOnlyList<WhenArm> Arms,
    BlockBody? Else,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record BlockBody(IReadOnlyList<Statement> Statements, Expression? Value, int Line, int Column);

internal sealed record WhenArm(Expression Condition, BlockBody Body, int Line, int Column);

internal sealed record SubjectCompareExpression(
    ComparisonOperator Operator,
    Expression Right,
    int Line,
    int Column)
    : Expression(Line, Column);

internal sealed record SubjectRangeExpression(
    Expression Start,
    Expression End,
    int Line,
    int Column,
    bool IsEndExclusive = false)
    : Expression(Line, Column);

internal enum ComparisonOperator
{
    Equal,
    NotEqual,
    Less,
    LessOrEqual,
    Greater,
    GreaterOrEqual
}

internal abstract record StringSegment;

internal sealed record TextSegment(string Text) : StringSegment;

internal sealed record InterpolationSegment(Expression Expression, bool IsParenthesized = false) : StringSegment;

from pathlib import Path
import sys,json,hashlib
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'names21562-csharp-type-metadata-pinned';receipt=B/'names21561-csharp-type-metadata/result.json';producer=json.loads(receipt.read_text());exe=receipt.parent/'compiler/Sollang.ExampleTests.exe';cpp=B/'managed21139/compiler/Sollang.Compiler.exe';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();assert producer['status']=='passed' and producer['inputsStable'] and producer['processesStopped'];assert all(sha(Path(p))==h for p,h in producer['inputHashes'].items());assert sha(exe)==producer['generatedOutputHashes'][str(exe)]
inputs=list(dict.fromkeys([receipt,exe,*managed_runtime_inputs(exe),cpp,*managed_runtime_inputs(cpp),*map(Path,producer['inputHashes'])]));hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir()
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=21,inputHashes=hashes,scope='Existing baseline CSharp complete type identity despite intern-order changes, recursively and with distinct fixed values; no codegen/private name changes',claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  done=run.run([str(exe),'--semantic-type-cache-codec',str(cpp.with_suffix('.dll')),str(OUT/'metadata-result.json')],OUT/'metadata',timeout=180);assert done.returncode==0,done.stdout+done.stderr;m=json.loads((OUT/'metadata-result.json').read_text());assert m['status']=='passed' and m['completed']==m['total']==21 and m['compilerSha256']==hashes[str(cpp.with_suffix('.dll'))];result['cases']=m['cases'];result['completed']=21;result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

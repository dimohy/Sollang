from pathlib import Path
import hashlib, json, sys
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'scripts'))
from verification_contract_lease import VerificationContractLease
from verification_execution import VerificationExecution
from completed_artifact_plan import initialize_output

B = ROOT / 'artifacts/scratch/resume-20261006-owner-continuation22'
OUT = B / 'library21089-selection'
COMPILER = B / 'managed20949/compiler/Sollang.Compiler.exe'
MANIFEST = ROOT / 'tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.sources.txt'
PROBE = ROOT / 'scripts/probes/codegen-identity/library-selection-contract.slg'
sources = [ROOT / x for x in MANIFEST.read_text().splitlines() if x and not x.endswith('selfhost-sollangc-driver.slg')]
inputs = [Path(__file__), MANIFEST, PROBE, *sources, *COMPILER.parent.glob('Sollang.Compiler.*'), *sorted((ROOT / 'stdlib').rglob('*.slg')),
          *[ROOT / 'scripts' / x for x in ['verification_execution.py', 'verification_contract_lease.py', 'verification_json_records.py', 'verification_fingerprints.py', 'completed_artifact_plan.py', 'ArtifactLifecycle.ps1', 'contracts/artifact-lifecycle.json']]]
inputs = list(dict.fromkeys(p.resolve() for p in inputs if p.is_file()))
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert sha(COMPILER.with_suffix('.dll')) == '3526E75684F08D41699409E59FBD6A58ECBE86BDF6629B6D8A0D3DDBECB17962'
reuse = [B / x / 'compiler-build01' for x in ['v18915', 'v20050', 'v21004']]
initialize_output(ROOT, OUT, reusable_directories=reuse)
OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
    hashes = {str(p): sha(p) for p in inputs}
    stable = lambda: all(p.is_file() and sha(p) == hashes[str(p)] for p in inputs)
    result = dict(schemaVersion=1, status='running', completed=0, total=5, cases=[], inputHashes=hashes,
                  maximumCaseSeconds=180, scope='library-export-selection-source-unit', claimsGoalComplete=False)
    run = VerificationExecution(ROOT, OUT, result, stable, sha)
    error = None
    try:
        command = [str(COMPILER), 'build', str(PROBE), *map(str, sources), '-o', str(OUT / 'probe.exe'), '--target', 'windows-x64', '--llvm', str(ROOT / '.tools/llvm-22.1.8'), '--jobs', '1', '-O0', '--keep-temps']
        build = run.run(command, OUT / 'build', timeout=180)
        if build.returncode: raise RuntimeError('SELECTION_BUILD_FAILED: ' + build.stderr[-2000:])
        observed = run.run([str(OUT / 'probe.exe')], OUT / 'run', timeout=180)
        result['observedStdout'] = observed.stdout
        if observed.returncode or observed.stderr: raise RuntimeError('SELECTION_EXECUTION_FAILED')
        expected = ['count=3', 'a.first|first', 'z.extra.member|member', 'z.last|last', 'all-stdlib=0']
        lines = observed.stdout.splitlines()
        result['cases'] = [dict(id=name, passed=i < len(lines) and lines[i] == value) for i, (name,value) in enumerate(zip(['selection-count','namespace-order','qualified-name','ordinal-order','stdlib-provenance'], expected))]
        result['completed'] = sum(c['passed'] for c in result['cases'])
        result['status'] = 'passed' if lines == expected else 'failed'
    except BaseException as caught:
        error = caught
    finally:
        run.finalize(error, cleanup=False)
    print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))
    if error: raise error

param([ValidateSet('managed','selfhost')][string]$Side)
$ErrorActionPreference='Stop'
$fixture = @(Get-Content -Raw -LiteralPath 'artifacts/scratch/resume-20261006-owner-continuation22/oracle23232/plan.json' | ConvertFrom-Json)
$compiler = if ($Side -eq 'managed') {'artifacts/scratch/resume-20261006-owner-continuation22/managed23194/compiler/Sollang.Compiler.dll'} else {'artifacts/scratch/resume-20261006-owner-continuation22/parsing23195-native/compiler.exe'}
& ./scripts/verify-native-exact-fixture-batch.ps1 -Compiler $compiler -Label $Side -Platform windows -LlvmRoot ./.tools/llvm-22.1.8 -StdlibRoot ./stdlib -RepositoryRoot (Get-Location).Path -OutputDirectory ('artifacts/scratch/resume-20261006-owner-continuation22/oracle23232/' + $Side) -Jobs 4 -TimeoutMilliseconds 180000 -Fixture $fixture

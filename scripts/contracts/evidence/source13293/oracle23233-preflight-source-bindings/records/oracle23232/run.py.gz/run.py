from pathlib import Path
import json,sys,hashlib
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';o=b/'oracle23232';sys.path.insert(0,str(r/'scripts'))
from verification_execution import VerificationExecution
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
fixtures=read(o/'plan.json');paths=[Path(__file__).resolve(),o/'run.ps1',o/'plan.json',r/'scripts/verify-native-exact-fixture-batch.ps1',r/'scripts/verify-native-exact-fixture.ps1',r/'scripts/native-exact-fixture-receipt.ps1',r/'scripts/verification_build_stdout.py']
for f in fixtures:paths.extend([r/'examples/regression'/(f+'.slg'),*list((r/'examples/regression/expected').glob(f+'.*'))])
pins={}
for p in [b/'parsing23194-managed-pdb.json',b/'parsing23212/managed-build-view.json',b/'parsing23212/selfhost-build-view.json']:
 pins[str(p)]=sha(p)
for name in ['managed-build-view.json','selfhost-build-view.json']:
 q=read(b/'parsing23212'/name)
 for field in ['sourceHashesStart','inputHashesStart']:
  for p,h in q.get(field,{}).items():pins[str(r/p)]=h
for p in [*paths,b/'managed23194/compiler/Sollang.Compiler.dll',b/'parsing23195-native/compiler.exe']:pins[str(p)]=sha(p)
assert all(sha(Path(p))==h for p,h in pins.items())
d=dict(schemaVersion=1,status='running',completed=0,total=4,caseBudgetSeconds=180,aggregateBudgetSeconds=4*180,scope='Two original fixtures, CSharp first then Native. Only LLVM identity checks were linked to exact source declarations; source/stdout/ABI/ownership/count conditions retained. This is focused proof, no whole-phase credit.',inputHashes=pins,cases=[],claimsGoalComplete=False)
x=VerificationExecution(r,o/'supervised',d,lambda:all(sha(Path(p))==h for p,h in pins.items()),sha);error=None
try:
 for side in ['managed','selfhost']:
  a=x.run(['pwsh','-NoProfile','-File',str(o/'run.ps1'),'-Side',side],o/(side+'-execution'),timeout=2*180);q=read(o/side/(side+'-batch-results.json'));assert a.returncode==0 and q['state']=='passed' and q['passed']==q['total']==2,(side,a.returncode,q.get('state'));d['cases'].append(dict(side=side,passed=2,total=2,batchReport=str(o/side/(side+'-batch-results.json'))));d['completed']+=2;x.save()
 d['status']='passed'
except BaseException as e:error=e
finally:x.finalize(error,cleanup=False)
print(json.dumps({k:d.get(k)for k in ['status','completed','total','failure','inputsStable','processesStopped']}));sys.exit(0 if d['status']=='passed'else 1)

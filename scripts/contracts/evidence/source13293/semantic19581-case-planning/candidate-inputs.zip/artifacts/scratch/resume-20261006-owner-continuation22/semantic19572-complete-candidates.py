"""Resolve the eight remaining historical case links without running compilers."""
from pathlib import Path
import hashlib
import json

root = Path.cwd()
base = root / 'artifacts/scratch/resume-20261006-owner-continuation22'
read = lambda p: json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
data = read(base / 'semantic19566-case-candidates.json')
rows = {row['decisionId']: row for row in data['rows']}


def local(path):
    value = str(path).replace('\\', '/')
    if value.lower().startswith('p:/myworks/sollang/'):
        value = value[len('P:/MyWorks/Sollang/'):]
    return (root / value).resolve()


def candidate(path, expected=None):
    source = local(path)
    assert source.is_relative_to(root) and source.is_file(), source
    value = {'path': source.relative_to(root).as_posix(), 'sha256': sha(source)}
    if expected is not None:
        value['expected'] = expected
    return value


def canonical(identity):
    negative = identity.startswith('diagnostic/')
    identity = identity.removeprefix('diagnostic/')
    source = root / 'examples/regression' / ('diagnostics' if negative else '') / (identity + '.slg')
    oracle = source.with_suffix('.stderr.contains.txt') if negative else root / 'examples/regression/expected' / (identity + '.stdout.txt')
    assert oracle.is_file(), oracle
    value = candidate(source)
    value['expectedFile'] = {'path': oracle.relative_to(root).as_posix(), 'sha256': sha(oracle)}
    value['expectedPolicy'] = 'contains-diagnostic-needs-exact-current-observation' if negative else 'exact-stdout'
    return value


def attach(identity, source_record, cases, **extra):
    row = rows[identity]
    assert 'linked' not in row['status']
    record = local(source_record)
    assert record.is_file(), record
    row.update(status='candidate-case-source-linked-not-current-execution',
               resolvedSourceRecord={'path': record.relative_to(root).as_posix(), 'sha256': sha(record)},
               resolvedCandidates=cases, **extra)


p = base / 'type-delimiter-current-managed6938/result.json'
attach('semantic.type-storage-delimiter-admission', p,
       [candidate(row['fixture'], {'stdout': row['expectedStdout']}) for row in read(p)['cases']])

p = base / 'cache15102-managed4/result.json'
attach('semantic.stable-cache-identity-and-production-restoration', p,
       [canonical('2752-semantic-cache-solver-owner-consumption'), canonical('433-persistent-module-cache')],
       supplementalCurrentProductionCacheProof='pending-after-whole-case-deadline-fix; use verify-contextual-numeric-cache.py on current products')

p = root / 'artifacts/c9232-lifetime/result.json'
attach('semantic.storage-origin-and-loop-borrow-lifetime', p,
       [canonical(row['id']) for row in read(p)['cases']])

p = base / 'c9975-C367-original13/result.json'
attach('semantic.recursive-declared-value-layout-admission', p,
       [canonical(identity) for identity in read(p)['expectedSelectedCases']])
attach('semantic.borrowed-pattern-enum-storage-provenance', p,
       [canonical(identity) for identity in read(p)['expectedSelectedCases']
        if identity.startswith('diagnostic/1625-') or identity.startswith('diagnostic/1644-')])

p = root / 'scripts/contracts/evidence/source-review12931/records/reference12971-contract.json'
attach('semantic.readonly-name-read-versus-reference-argument-admission', p,
       [candidate(row['source'], {key: row[key] for key in ['stdout','stderr','exit','expectedDiagnostic'] if key in row})
        for row in read(p)['cases']],
       sideEffectReview='field-named-read uses directory.create on existing current directory; review all sources before execution')

p = root / 'scripts/contracts/evidence/source13293/value17227/value17222-managed5/result.json'
original = root / 'examples/user/663-arbitrary-generic-parameters.slg'
regression = root / 'examples/regression/663-arbitrary-generic-parameters.slg'
attach('semantic-analysis.unbounded-generic-declaration-identity', p,
       [canonical('663-arbitrary-generic-parameters')],
       userAndRegressionByteIdentical=sha(original) == sha(regression))

p = base / 'task17431-managed9.json'
attach('semantic.anonymous-task-immediate-consumer', p,
       [candidate(row['source'], {key: row[key] for key in ['stdout','stderr','exit','requireNoLlvm'] if key in row})
        for row in read(p)['cases']])

assert all('linked' in row['status'] for row in data['rows'])
data.update(status='all40-candidate-source-links-resolved-not-executed', linked=40,
            claimsPhaseComplete=False, claimsGoalComplete=False,
            limitations=['Historical contracts identify candidates only; no current execution or source-phase credit.',
                         'Positive probes outside regression require a qualified canonical witness before the existing phase runner.',
                         'Contains-only negative oracles cannot be silently converted to exact diagnostic claims.',
                         'Current production cache restoration remains separately unverified after deadline enforcement.'])
out = base / 'semantic19573-case-candidates.json'
assert not out.exists()
out.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'linked':40,'total':40,'currentExecution':False,'phaseCredit':0,'output':str(out)}))

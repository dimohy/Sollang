from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'names21428-prechange-owned-origin';birth=B/'flow21405-emitter/result.json';old=json.loads(birth.read_text());exe=birth.parent/'emitter.exe';current=B/'names21427-selected-symbol-consumers/slg-1199-local-function-parallel-callback/emit.stdout';fixture=ROOT/'examples/regression/1199-local-function-parallel-callback.slg';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();assert old['status']=='failed' and old['cases'][0]['passed'];assert sha(exe)==old['generatedOutputHashes'][str(exe)]
frontend=[Path(p) for p in old['inputHashes'] if any(t in p.replace('\\','/') for t in ['/selfhost/semantic/','/selfhost/ir/','/selfhost/llvm/emitter/diagnostics.slg','/stdlib/'])];assert len(frontend)==227
assert all(sha(p)==old['inputHashes'][str(p)] for p in frontend)
inputs=[Path(__file__),birth,exe,current,fixture,*frontend];hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Diagnostic-only prechange reproduction using a preserved FAILED producer artifact whose own build passed. All227 frontend/IR/diagnostic/stdlib inputs match. Not a qualified compiler baseline; original generic-stream assembly failure remains failed.',claimsCompilerQualified=False,claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  done=run.run([str(exe),'ordinary','unused',str(ROOT/'stdlib'),str(fixture)],OUT/'prechange',timeout=180);expected=current.read_text(encoding='utf-8');assert done.returncode!=0 and not done.stderr and done.stdout==expected and 'owned binding diagnostic has no verified binding origin' in expected,done.stdout+done.stderr;result['cases'].append(dict(id='prechange-owned-binding-origin-failure-present',passed=True,exit=done.returncode,stdout=done.stdout));result['completed']=1;result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

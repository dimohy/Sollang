from pathlib import Path
import sys,json,hashlib,time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'names21427-selected-symbol-consumers';CPP=B/'managed21139/compiler/Sollang.Compiler.exe';receipt=B/'names21422-emitter/result.json';producer=json.loads(receipt.read_text());emitter=receipt.parent/'emitter.exe';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert producer['status']=='passed' and producer['completed']==producer['total']==29 and producer['inputsStable'] and producer['processesStopped']
assert sha(emitter)==producer['generatedOutputHashes'][str(emitter)]
assert all(sha(Path(p))==h for p,h in producer['inputHashes'].items())
cases=['1199-local-function-parallel-callback','1431-trait-constant-method-receiver','71-user-defined-dictionary-keys'];subjects=[(label,ROOT/f'examples/regression/{label}.slg',ROOT/f'examples/regression/expected/{label}.stdout.txt') for label in cases]
inputs=list(dict.fromkeys([Path(__file__),CPP,*managed_runtime_inputs(CPP),receipt,emitter,*map(Path,producer['inputHashes']),*[p for label,src,oracle in subjects for p in [src,oracle]]]))
hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=6,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Complete declaration names: local function callback reachability, dyn trait implementation dispatch and user hash/equals calls. CSharp first per case then current-source SLG LLVM/link/run. No whole source-order or cache claim.',claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  for label,src,oracle in subjects:
   for role in ['csharp','slg']:
    d=OUT/(role+'-'+label);d.mkdir();start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));exe=d/'program.exe'
    if role=='csharp':
     done=run.run([str(CPP),'build',str(src),'-o',str(exe),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0'],d/'build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout[-2000:]+done.stderr
    else:
     done=run.run([str(emitter),'ordinary','unused',str(ROOT/'stdlib'),str(src)],d/'emit',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout[-2000:]+done.stderr;ll=d/'program.ll';ll.write_text(done.stdout,encoding='utf-8');done=run.run([str(ROOT/'.tools/llvm-22.1.8/bin/llvm-as.exe'),str(ll),'-o',str(d/'program.bc')],d/'assemble',timeout=budget());assert done.returncode==0,done.stderr;done=run.run([str(ROOT/'.tools/llvm-22.1.8/bin/clang.exe'),str(ll),'-O0','-Wno-override-module','-o',str(exe),'-lkernel32','-lshell32','-lws2_32','-lbcrypt'],d/'link',timeout=budget());assert done.returncode==0,done.stderr
    done=run.run([str(exe)],d/'run',timeout=budget());expected=oracle.read_text(encoding='utf-8-sig');assert done.returncode==0 and not done.stderr and done.stdout==expected,done.stdout+done.stderr;result['cases'].append(dict(id=role+'-'+label,passed=True,stdout=done.stdout,expected=expected));result['completed']+=1;run.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

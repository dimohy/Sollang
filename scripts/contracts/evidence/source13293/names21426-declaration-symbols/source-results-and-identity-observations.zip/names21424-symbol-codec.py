from pathlib import Path
import sys,json,hashlib,time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'names21424-symbol-codec';managed=B/'managed21139/compiler/Sollang.Compiler.exe';native=B/'v21323/compiler-build01/compiler.exe';manifest=ROOT/'tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.sources.txt';sources=[ROOT/'scripts/probes/codegen-identity/scoped-symbol-name-store.slg',ROOT/'selfhost/llvm/scoped_names.slg'];oracle=ROOT/'scripts/contracts/evidence/source13293/identity21413-source-order/source-comparison-and-gap.json';inputs=[Path(__file__),managed,*managed_runtime_inputs(managed),native,native.parent/'result.json',manifest,*sources,oracle,*sorted((ROOT/'stdlib').rglob('*.slg'))];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False);expected='bounds=true\nfull-key=true\norder-a=true\norder-b=true\ndistinct-key=true\nunassigned=true\n'
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=2,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Dependency-separated canonical symbol codec only: complete declaration-key words encoded without hashes or lookup ordinals; word boundaries, UInt64 extremes, distinct complete identities (hashes are not accepted by this codec API), reordered slots and borrowed views. CSharp first then retained Native seed; not production consumer or full source-order fix.',claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  for role,compiler in [('managed',managed),('retained-native',native)]:
   d=OUT/role;d.mkdir();start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));done=run.run([str(compiler),'build',*map(str,sources),'-o',str(d/'probe.exe'),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0','--keep-temps'],d/'build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout[-1800:]+done.stderr;built=done.returncode;done=run.run([str(d/'probe.exe')],d/'run',timeout=budget());passed=done.returncode==0 and not done.stderr and done.stdout==expected;result['cases'].append(dict(id=role,passed=passed,buildExit=built,runExit=done.returncode,stdout=done.stdout,expected=expected,checks=6));result['completed']+=int(passed);run.save();assert passed,done.stdout+done.stderr
  result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','cases','inputsStable','processesStopped']},indent=2))

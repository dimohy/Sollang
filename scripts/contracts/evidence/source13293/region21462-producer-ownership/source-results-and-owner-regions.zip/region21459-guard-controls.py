from pathlib import Path
import sys,json,hashlib,time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'region21459-guard-controls';CPP=B/'managed21139/compiler/Sollang.Compiler.exe';receipt=B/'region21457-fixed-emitter/result.json';producer=json.loads(receipt.read_text());emitter=receipt.parent/'observer.exe';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert producer['status']=='failed' and producer['inputsStable'] and producer['processesStopped'] and producer['cases'][0]['passed'] and any(c['id']=='slg-275-owned-result-role-block' and c['passed'] for c in producer['cases'])
assert sha(emitter)==producer['generatedOutputHashes'][str(emitter)]
manifest=ROOT/'tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.sources.txt'
buildInputs=[CPP,*managed_runtime_inputs(CPP),manifest,ROOT/'scripts/probes/ownership-origin/main.slg',ROOT/'scripts/probes/ownership-origin/observer.slg',*[ROOT/p for p in manifest.read_text(encoding='utf-8-sig').splitlines() if p and not p.endswith('selfhost-sollangc-driver.slg')],*sorted((ROOT/'stdlib').rglob('*.slg'))]
assert all(sha(p)==producer['inputHashes'][str(p)] for p in buildInputs)
# The old producer also pinned FUTURE consumer fixtures; that is not a compiler
# build dependency. The revised public fixture is independently pinned below.

subjects=[('1766-readonly-text-slice-direct-first',ROOT/'examples/regression/1766-readonly-text-slice-direct-first.slg',ROOT/'examples/regression/expected/1766-readonly-text-slice-direct-first.stdout.txt'),('public-readonly-block',ROOT/'scripts/probes/ownership-origin/public-readonly-block.slg',ROOT/'scripts/probes/ownership-origin/public-readonly-block.stdout.txt')]
negatives=[(label,ROOT/f'examples/regression/diagnostics/{label}.slg',ROOT/f'examples/regression/diagnostics/{label}.stderr.contains.txt') for label in ['borrowed-text-block-local-arena-escape','block-owned-result-unbound']];subjects=[]
warnSource=ROOT/'scripts/probes/ownership-origin/fixed-growable-warning.slg';warnOracle=warnSource.with_suffix('.warning.contains.txt');inputs=list(dict.fromkeys([warnSource,warnOracle,*buildInputs,Path(__file__),CPP,*managed_runtime_inputs(CPP),receipt,emitter,*[p for label,src,oracle in subjects+negatives for p in [src,oracle]]]))
hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=6,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Called borrowed-Text escape, unbound owned block result rejection, and preserved straight-line S003 warning; original unused-function rejection failure remains1/8 and is not reclassified. The public fixture now grows its array to avoid S003; expected output is unchanged. Reused compiler is checked against ALL build dependencies, not future consumer fixtures. Original failed2/8 is preserved. Uses current producer whose build and1199 passed but whose original10-case run remains FAILED5/10 on275. Does not reclassify or replace that failure. CSharp first per case, current SLG LLVM/run for positives and original contains rejection oracles for negatives.',claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  for label,src,oracle in negatives:
   for role in ['csharp','slg']:
    d=OUT/(role+'-'+label);d.mkdir();start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));expected=oracle.read_text(encoding='utf-8-sig').strip()
    command=[str(CPP),'build',str(src),'-o',str(d/'program.exe'),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0'] if role=='csharp' else [str(emitter),'emit','unused',str(ROOT/'stdlib'),str(src)]
    done=run.run(command,d/'reject',timeout=budget());combined=done.stdout+done.stderr;assert done.returncode!=0 and expected in combined,combined[-2200:];result['cases'].append(dict(id=role+'-'+label,passed=True,exit=done.returncode,expectedContains=expected,diagnostic=combined));result['completed']+=1;run.save()
  for label,src,oracle in subjects:
   for role in ['csharp','slg']:
    d=OUT/(role+'-'+label);d.mkdir();start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));exe=d/'program.exe'
    if role=='csharp':
     done=run.run([str(CPP),'build',str(src),'-o',str(exe),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0'],d/'build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout[-2000:]+done.stderr
    else:
     done=run.run([str(emitter),'emit','unused',str(ROOT/'stdlib'),str(src)],d/'emit',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout[-2000:]+done.stderr;ll=d/'program.ll';ll.write_text(done.stdout,encoding='utf-8');done=run.run([str(ROOT/'.tools/llvm-22.1.8/bin/llvm-as.exe'),str(ll),'-o',str(d/'program.bc')],d/'assemble',timeout=budget());assert done.returncode==0,done.stderr;done=run.run([str(ROOT/'.tools/llvm-22.1.8/bin/clang.exe'),str(ll),'-O0','-Wno-override-module','-o',str(exe),'-lkernel32','-lshell32','-lws2_32','-lbcrypt'],d/'link',timeout=budget());assert done.returncode==0,done.stderr
    done=run.run([str(exe)],d/'run',timeout=budget());expected=oracle.read_text(encoding='utf-8-sig');assert done.returncode==0 and not done.stderr and done.stdout==expected,done.stdout+done.stderr;result['cases'].append(dict(id=role+'-'+label,passed=True,stdout=done.stdout,expected=expected));result['completed']+=1;run.save()
  expectedWarning=warnOracle.read_text(encoding='utf-8-sig').strip()
  for role in ['csharp','slg']:
   d=OUT/(role+'-s003-positive');d.mkdir();command=[str(CPP),'build',str(warnSource),'-o',str(d/'program.exe'),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0'] if role=='csharp' else [str(emitter),'emit','unused',str(ROOT/'stdlib'),str(warnSource)]
   done=run.run(command,d/'warning',timeout=180);assert done.returncode==0 and 'warning S003' in done.stderr and expectedWarning in done.stderr,done.stdout[-1400:]+done.stderr;result['cases'].append(dict(id=role+'-s003-required-warning',passed=True,expectedContains=expectedWarning,diagnostic=done.stderr));result['completed']+=1;run.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

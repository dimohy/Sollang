from pathlib import Path
import json,sys,hashlib
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'region21458-runtime-observation';parent=B/'region21454-fixed-emitter';raw=parent/'slg-275-owned-result-role-block/emit.stdout';warning=raw.with_name('emit.stderr');oracle=ROOT/'examples/regression/expected/275-owned-result-role-block.stdout.txt';inputs=[Path(__file__),parent/'result.json',raw,warning,oracle];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();hashes={str(p):sha(p) for p in inputs};assert 'warning S003' in warning.read_text();initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Diagnostic continuation of275 emitted LLVM with KNOWN S003. Runtime observation never promotes original failed5/10 or this warning-bearing case.',claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  ll=OUT/'program.ll';ll.write_bytes(raw.read_bytes());done=run.run([str(ROOT/'.tools/llvm-22.1.8/bin/llvm-as.exe'),str(ll),'-o',str(OUT/'program.bc')],OUT/'assemble',timeout=180);assert done.returncode==0,done.stderr;done=run.run([str(ROOT/'.tools/llvm-22.1.8/bin/clang.exe'),str(ll),'-O0','-Wno-override-module','-o',str(OUT/'program.exe'),'-lkernel32','-lshell32','-lws2_32','-lbcrypt'],OUT/'link',timeout=180);assert done.returncode==0,done.stderr;done=run.run([str(OUT/'program.exe')],OUT/'run',timeout=180);expected=oracle.read_text(encoding='utf-8-sig');assert done.returncode==0 and not done.stderr and done.stdout==expected,done.stdout+done.stderr;result['cases'].append(dict(id='warning-bearing275-runtime',passed=False,runtimeMatchesCSharp=True,warningStillUnresolved=True,stdout=done.stdout));result['status']='observed-not-qualified'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'region21460-prechange-unbound-result';birth=B/'origin21439-fixed-emitter/result.json';old=json.loads(birth.read_text());exe=birth.parent/'observer.exe';current=B/'origin21439-fixed-emitter/slg-275-owned-result-role-block/emit.stdout';fixture=ROOT/'examples/regression/diagnostics/block-owned-result-unbound.slg';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();assert old['status']=='failed' and old['cases'][0]['passed'];assert sha(exe)==old['generatedOutputHashes'][str(exe)]
frontend=[Path(p) for p in old['inputHashes'] if any(t in p.replace('\\','/') for t in ['/selfhost/semantic/','/selfhost/ir/','/selfhost/llvm/emitter/diagnostics.slg','/stdlib/'])];assert len(frontend)==227
# Prechange artifact is used only for diagnostic reproduction; current source has changed by this turn.
assert len(frontend)==227
inputs=[Path(__file__),birth,exe,current,fixture,*frontend];hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Diagnostic-only reproduction with producer39 from before producer-region reparenting fix. Its original failed5/10 status remains unchanged. Artifact predates this turn; do not assert current source equivalence after the implementation changes. Not a qualified compiler baseline; original generic-stream assembly failure remains failed.',claimsCompilerQualified=False,claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  done=run.run([str(exe),'emit','unused',str(ROOT/'stdlib'),str(fixture)],OUT/'prechange',timeout=180);expected="owned result of block function 'collect' must be bound with '=> name'";assert done.returncode==0 and not done.stderr and expected not in done.stdout and 'define ' in done.stdout,done.stdout[-1200:]+done.stderr;result['cases'].append(dict(id='unbound-owned-block-result-missing-rejection',passed=False,exit=done.returncode,expectedContains=expected,unexpectedAcceptanceConfirmed=True));result['status']='observed-not-qualified'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

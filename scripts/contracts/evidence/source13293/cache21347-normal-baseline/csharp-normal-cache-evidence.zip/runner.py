from pathlib import Path
import json,hashlib,sys,re,time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'cache21346-csharp-normal';CPP=B/'managed21139/compiler/Sollang.Compiler.exe';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False);variants=OUT/'variants';variants.mkdir()
texts={'main.slg':'import cache.alpha as alpha\nimport cache.beta as beta\n\nmain { alpha.value() + beta.value() -> println }\n','beta.slg':'namespace cache.beta\n\npublic value: -> Int32 => 3\n','alpha-before.slg':'namespace cache.alpha\n\npublic value: -> Int32 => 7\n','alpha-after.slg':'namespace cache.alpha\n\npublic value: -> Int32 => 8\n'}
for name,value in texts.items():(variants/name).write_text(value,encoding='utf-8')
inputs=[Path(__file__),CPP,*managed_runtime_inputs(CPP),*variants.iterdir(),ROOT/'src/Sollang.Compiler/Cli/IncrementalCodegenCache.cs',ROOT/'src/Sollang.Compiler/Cli/CompilerApp.cs',*sorted((ROOT/'stdlib').rglob('*.slg'))];hashes={str(p):sha(p) for p in inputs};project=OUT/'project';project.mkdir();(project/'main.slg').write_bytes((variants/'main.slg').read_bytes());(project/'beta.slg').write_bytes((variants/'beta.slg').read_bytes());exe=project/'program.exe'
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=3,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='CSharp-first actual ordinary build cache cold/warm/body-change observations on same output and same source paths. Immutable variant files are pinned; live source only changes between stopped builds and is separately fingerprinted per case.',claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  for phase,variant,expected in [('cold','alpha-before.slg','10\n'),('warm','alpha-before.slg','10\n'),('implementation-change','alpha-after.slg','11\n')]:
   (project/'alpha.slg').write_bytes((variants/variant).read_bytes());liveHashes={str(p):sha(p) for p in project.glob('*.slg')};d=OUT/phase;d.mkdir();start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));done=run.run([str(CPP),'build',str(project/'main.slg'),str(project/'alpha.slg'),str(project/'beta.slg'),'-o',str(exe),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0','--keep-temps'],d/'build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout[-1600:]+done.stderr;observed=re.search(r'\[codegen-cache\] ([^;]+); reused (\d+)/(\d+) units;',done.stdout);assert observed,done.stdout;status,reused,total=observed.group(1),int(observed.group(2)),int(observed.group(3));built=done.returncode;executed=run.run([str(exe)],d/'run',timeout=budget());assert executed.returncode==0 and executed.stdout==expected and not executed.stderr,executed.stdout+executed.stderr;assert all(sha(Path(p))==h for p,h in liveHashes.items());assert (phase!='cold' or reused==0) and (phase!='warm' or status=='exact' and reused==total) and (phase!='implementation-change' or 0<reused<total);cacheFiles={p.name:sha(p) for p in (project/'.sollang-cache').glob('*') if p.is_file()};result['cases'].append(dict(id=phase,passed=True,buildExit=built,runExit=executed.returncode,stdout=executed.stdout,codegenStatus=status,reused=reused,units=total,sourceHashesStart=liveHashes,sourceHashesEnd=liveHashes,cacheHashes=cacheFiles,wholeCaseSeconds=time.monotonic()-start));result['completed']+=1;run.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','cases','inputsStable','processesStopped']},indent=2))

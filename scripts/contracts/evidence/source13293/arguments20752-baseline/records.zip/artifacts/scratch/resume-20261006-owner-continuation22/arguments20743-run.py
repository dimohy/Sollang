from pathlib import Path
import hashlib,json,sys,time
root=Path.cwd();sys.path.insert(0,str(root/'scripts'))
from verification_execution import VerificationExecution
from verification_fingerprints import managed_compilation_inputs
from verification_source_proof import current_build_inputs
from completed_artifact_plan import initialize_output
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
B=root/'artifacts/scratch/resume-20261006-owner-continuation22'
mode=sys.argv[1];assert mode in ('managed','native')
source=root/'scripts/probes/process-arguments/windows-unicode-initialization.slg'
helper=root/'scripts/probes/process-arguments/run-utf16-process.py'
compiler=B/('managed19729/compiler/Sollang.Compiler.exe' if mode=='managed' else 'v20656/compiler-build01/compiler.exe')
out=B/('arguments20744-'+mode+'6')
llvm=root/'.tools/llvm-22.1.8/bin'
providers=list((root/'scripts').glob('verification_*.py'))
providers += [root/'scripts/completed_artifact_plan.py',Path(__file__),source,helper,llvm/'clang.exe',llvm/'llvm-as.exe']
if mode=='managed':providers+=managed_compilation_inputs(compiler,root/'stdlib')
else:
    build=B/'v20656/compiler-build01/result.json'
    providers += [compiler,build,*current_build_inputs(root,json.loads(build.read_text(encoding='utf-8-sig')))]
pins={str(p.resolve()):H(p) for p in providers};stable=lambda:all(Path(p).is_file() and H(p)==h for p,h in pins.items())
assert stable()
reusable=[B/f'v{n}/compiler-build01' for n in (18915,20050,20656)]
initialize_output(root,out,reusable_directories=reusable);out.mkdir()
cases=[('none',[],0,'1\n'),('unicode',[[0xC194,0xD83D,0xDE00]],0,'2\n솔😀\n'),
       ('empty',[[]],0,'2\n\n'),('high',[[0xD800]],1,'0\n'),
       ('low',[[0xDC00]],1,'0\n'),('partial',[[65],[0xD800]],1,'0\n')]
r=dict(schemaVersion=1,status='running',mode=mode,completed=0,total=len(cases),inputHashes=pins,
       maximumCaseSeconds=180,sharedCompilationAndAllCasesBudgetSeconds=180,cases=[],claimsGoalComplete=False)
x=VerificationExecution(root,out,r,stable,H);error=None;start=time.monotonic()
def run(command,prefix):
    left=180-(time.monotonic()-start);assert left>0
    return x.run(command,out/prefix,timeout=min(180,left))
try:
    exe=out/'probe.exe'
    command=[str(compiler),'build',str(source),'-o',str(exe),'--target','windows-x64','--llvm',str(llvm.parent),'--jobs','1','-O1','--keep-temps']
    if mode=='native':command+=['--stdlib',str(root/'stdlib')]
    done=run(command,'build')
    assert done.returncode==0,('build',done.returncode)
    assert (out/'build.stderr').read_bytes()==b''
    assert run([str(llvm/'llvm-as.exe'),str(exe)+'.ll','-o',str(exe)+'.bc'],'assemble').returncode==0
    assert run(['pwsh','-NoProfile','-File',str(root/'scripts/verify-llvm-direct-call-closure.ps1'),'-LlvmPath',str(exe)+'.ll'],'closure').returncode==0
    for name,units,expectedExit,expectedOutput in cases:
        done=run([sys.executable,str(helper),str(exe),json.dumps(units),str(out/(name+'-child.json'))],name)
        stdout=(out/(name+'.stdout')).read_bytes().replace(b'\r\n',b'\n')
        stderr=(out/(name+'.stderr')).read_bytes()
        row=dict(id=name,argumentCodeUnits=units,exit=done.returncode,expectedExit=expectedExit,
                 stdoutHex=stdout.hex(),expectedStdoutHex=expectedOutput.encode().hex(),stderrHex=stderr.hex())
        row['passed']=done.returncode==expectedExit and stdout==expectedOutput.encode() and stderr==b''
        r['cases'].append(row);r['completed']+=int(row['passed']);x.save()
    assert all(c['passed'] for c in r['cases']),'ARGUMENT_INITIALIZATION_PARITY_MISMATCH'
    r['status']='passed'
except BaseException as caught:error=caught
finally:
    r['durationSeconds']=time.monotonic()-start
    x.finalize(error,cleanup=False)
print(json.dumps({k:r.get(k) for k in ('status','completed','total','failure','durationSeconds','inputsStable','processesStopped')}))
sys.exit(0 if r['status']=='passed' else 1)

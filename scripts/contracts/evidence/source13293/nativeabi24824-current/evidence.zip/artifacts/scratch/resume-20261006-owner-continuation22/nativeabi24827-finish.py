from pathlib import Path
import json,hashlib,zipfile,datetime,re,collections,subprocess
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/nativeabi24824-current';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));write=lambda p,j:Path(p).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');sha=lambda b:hashlib.sha256(b).hexdigest().upper();rel=lambda p:Path(p).relative_to(R).as_posix()
for ident in ['C2026-11-03-782','C2026-11-03-783']:
 d=R/'scripts/contracts/evidence'/ident;t=read(d/'as-us-001.json')
 for phase in ['baseline','candidate']:
  j=read(d/(phase+'.json'));assert sha((R/j['outputPath']).read_bytes())==j['outputSha256']
 write(d/'evaluation.json',dict(allowed=True,code='AS-US-001-STRUCTURED-AND-APPLIED',command='node ../AgenticShaping/evals/unstructured-to-structured.mjs --trace '+rel(d/'as-us-001.json'),traceSha256=sha((d/'as-us-001.json').read_bytes()),scope='Direct existing local evaluator returned allowed=true; focused compiler repair only, not Slogs policy or final goal completion.',measurementScope='Shared parent fixture failure is not an additive per-defect improvement.'))
names=['processor24776-csharp','processor24785-managed','processor24797-managed','nativeabi24787-csharp','nativeabi24805-csharp-values','nativeabi24808-style-csharp','nativeabi24810-csharp','nativeabi24811-csharp-values','nativeabi24816-native','nativeabi24817-native-values','nativeabi24818-native-style','processor24819-managed','processor24820-native','nativeabi24815-native','nativeabi24789-semantic','nativeabi24790-stdlib','nativeabi24822-semantic','nativeabi24813-stdlib','workspace24738-native','nativeabi24791-native']
rows=[]
for name in names:
 receipt=B/name/'artifact-cleanup-plan.json.execution.json';j=read(receipt);assert j['status']=='completed';rows.append(dict(output=name,reclaimedBytes=j['reclaimedBytes'],receipt=rel(receipt)));write(E/(name+'-cleanup.json'),j)
roots=[B/'nativeabi24815-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01'];assert all((p/'compiler.exe').is_file() for p in roots)
generated=re.compile(r'\.(?:ll|bc\d*|obj|o|exe|dll|pdb|lib|a|wasm)$',re.I)
for name in names[:13]:assert not [p for p in (B/name).rglob('*') if p.is_file() and generated.search(p.name)],name
residual=[dict(path=rel(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in (B/'processor24776-csharp').rglob('*.cache') if p.is_file()]
write(E/'artifact-lifecycle.json',dict(status='completed-for-listed-owned-generated-files-and-recognized-cache-directories',reclaimedBytes=sum(x['reclaimedBytes'] for x in rows),outputs=rows,reusableNativeCompilers=[rel(p) for p in roots],reusableNativeCompilerCount=3,managedCompiler='linker24766-managed retained for pending compiler consumers',failedOutputsPreserved=True,remainingOwnershipReview=dict(msbuildMetadataCaches=residual,historicalExtensionlessElf='target24666 remains outside the current generated-extension matcher; preserved pending a common ownership repair'),claimsAllHistoricalArtifactsCleaned=False))
# Independent contracts repeat one identical NBSP environment; count unique
# implementation/input pairs rather than adding execution totals.
P=R/'scripts/probes/windows-linker';plans=[read(P/n)['cases'] for n in ['processor-contract.json','processor-configuration-controls.json','processor-unicode-controls.json','processor-high-count-controls.json']];keys=[]
for cases in plans:
 for case in cases:keys.append(json.dumps({k:v for k,v in case.items() if k in ['environment','affinity','cpuRate','minMax']},sort_keys=True))
assert len(keys)==58 and len(set(keys))==57
write(E/'processor-input-deduplication.json',dict(executionsPerImplementation=58,distinctInputsPerImplementation=57,pairedDistinctTotal=114,duplicateInputs=[dict(input=json.loads(k),occurrences=v) for k,v in collections.Counter(keys).items() if v>1],observedHardware=read(E/'cpuReference.json')['hardware']))
q=read(E/'qualification.json');q['artifactLifecycle']='artifact-lifecycle.json';q['processorInputDeduplication']='processor-input-deduplication.json';q['scopedShapingEvaluations']=['scripts/contracts/evidence/'+x+'/evaluation.json' for x in ['C2026-11-03-782','C2026-11-03-783']];q['limitations'].append('Completed MSBuild probe metadata caches are preserved outside current canonical cache recognition; common ownership review remains pending.');write(E/'qualification.json',q)
archive=E/'evidence.zip';manifest=read(E/'archive-manifest.json')
with zipfile.ZipFile(archive) as z:
 entries={p:z.read(p) for p in z.namelist()};assert set(entries)==set(manifest['entries'])
 for p,data in entries.items():assert sha(data)==manifest['entries'][p]['sha256']
for ident in ['C2026-11-03-782','C2026-11-03-783']:
 for p in (R/'scripts/contracts/evidence'/ident).rglob('*'):
  if p.is_file():entries[rel(p)]=p.read_bytes()
for p in [B/'nativeabi24824-package.py',B/'nativeabi24825-receipts.py',Path(__file__),*E.glob('*-cleanup.json'),E/'artifact-lifecycle.json',E/'processor-input-deduplication.json',E/'processor-source-comparison.json',E/'abi-source-comparison.json',E/'style-source-comparison.json',B/'nativeabi24826-cleanup.stdout.log',B/'nativeabi24826-cleanup.stderr.log']:
 entries[rel(p)]=p.read_bytes()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,data in sorted(entries.items()):z.writestr(p,data)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(entries)
 for p,data in entries.items():assert z.read(p)==data
write(E/'archive-manifest.json',dict(sha256=sha(archive.read_bytes()),entries={p:dict(bytes=len(data),sha256=sha(data)) for p,data in sorted(entries.items())},readbackVerified=True));q['archive'].update(sha256=sha(archive.read_bytes()),entries=len(entries));write(E/'qualification.json',q)
protected=read(B/'block24016-protected-inputs.json');assert all(sha((R/p).read_bytes())==h for p,h in protected.items())
ledger=read(R/'scripts/contracts/compiler-defects.json');missing=[x['id'] for x in ledger['defects'] if int(x['id'].rsplit('-',1)[-1])>=208 and not x.get('shapingEvidence')];assert len(missing)==39
write(E/'ledger-scope.json',dict(total=779,closed=363,candidateFixed=414,open=2,knownMissingShapingEvidenceCount=39,newScopedShapingEvaluationsPassed=2,claimsFullLedgerValidationPassed=False))
print(json.dumps(dict(status='finished',reclaimedBytes=sum(x['reclaimedBytes'] for x in rows),archiveEntries=len(entries),archiveBytes=archive.stat().st_size,distinctCpuPair=114,protectedInputs='8/8',remainingMetadataCacheFiles=len(residual))))

from pathlib import Path
import sys,json,hashlib,time
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'nativeabi24787-csharp';C=B/'linker24766-managed/compiler/Sollang.Compiler.exe';source=R/'scripts/probes/windows-linker/native-mut-places.slg';L=R/'.tools/llvm-22.1.8';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();oracles=['primary','additional','condition','member','forwarded','readonly','while','indexed'];expected=''.join(name+'=ok\n' for name in oracles)
pins={str(p.resolve()):sha(p) for p in [Path(__file__),source,C,*managed_runtime_inputs(C),*sorted((R/'stdlib').rglob('*.slg'))]}
initialize_output(R,O,reusable_directories=[B/'workspace24738-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=8,inputHashes=pins,scope='Native ABI mutable original-place oracles and readonly control',expectedStdout=expected,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None;start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start))
 try:
  exe=O/'probe.exe';r=ex.run([str(C),'build',str(source),'-o',str(exe),'--target','windows-x64','--keep-temps','-O1','--jobs','4','--llvm',str(L)],O/'build',timeout=budget());assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  r=ex.run([str(exe)],O/'run',timeout=budget());assert r.returncode==0 and not r.stderr and r.stdout==expected,r.stdout+r.stderr
  result.update(status='passed',completed=8,actualStdout=r.stdout,oracles=oracles)
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

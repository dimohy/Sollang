from pathlib import Path
import json,hashlib,subprocess
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/nativeabi24824-current';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));write=lambda p,j:Path(p).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');sha=lambda b:hashlib.sha256(b).hexdigest().upper()
row=next(x for x in read(E/'nativeAbi.json')['processes'] if str(x['command'][0]).endswith('probe.exe'));assert row['exit']==0
for ident in ['C2026-11-03-782','C2026-11-03-783']:
 d=R/'scripts/contracts/evidence'/ident
 (d/'baseline.output.txt').write_bytes((B/'nativeabi24796-native/build.stderr').read_bytes());(d/'candidate.output.txt').write_bytes((B/'nativeabi24816-native/run.stdout').read_bytes())
 for phase in ['baseline','candidate']:
  j=read(d/(phase+'.json'));j['outputSha256']=sha((d/(phase+'.output.txt')).read_bytes())
  if phase=='candidate':j['command']=subprocess.list2cmdline(row['command']);j['outputProjection']='Exact stdout bytes of the actual successful generated consumer process.'
  else:j['outputProjection']='Exact stderr bytes of the actual failing compiler process.'
  write(d/(phase+'.json'),j)
 t=read(d/'as-us-001.json');b=read(d/'baseline.json');a=read(d/'candidate.json');t['orchestratorEvidence']['executedCommands']=[dict(purpose=purpose,command=j['command'],exitCode=j['exitCode'],expectedExitCode=j['expectedExitCode'],outputSha256=j['outputSha256']) for purpose,j in [('baseline',b),('validator',a),('consumer',a),('candidate',a)]];write(d/'as-us-001.json',t)
j=read(B/'processor24777-comparison.json');j['decisions'][3]='Keep raw Win32 ABI calls in a private compiler-host runtime adapter. Native Text is not an ABI-safe C input: use an explicit checked DWORD numeric-prefix parser and query Windows NLS C1_SPACE via GetStringTypeW, which matches all30 current CSharp Unicode observations including legacy U+180E. Never substitute the configured/capped compute pool count.';j['finalProofs']=['processor24819-managed','processor24820-native','processor24821-controls','processor24823-high'];j['unicodeReference']='processor24794-unicode-csharp';j['nlsClassificationReference']='processor24795-nls.json';write(E/'processor-source-comparison.json',j)
write(E/'abi-source-comparison.json',read(B/'nativeabi24814-plan.json'));write(E/'style-source-comparison.json',read(B/'nativeabi24809-style-comparison.json'))
q=read(E/'qualification.json');q['sourceComparisonFiles']=['abi-source-comparison.json','style-source-comparison.json','processor-source-comparison.json'];write(E/'qualification.json',q)
print('Exact process-output receipts and final source-comparison links updated.')

from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'processor24821-controls';P=R/'scripts/probes/windows-linker';extra=P/'processor-configuration-controls.json';unicode=P/'processor-unicode-controls.json';controller=B/'processor24776-csharp/controller/bin/controller.dll';reference=B/'processor24776-csharp/reference/bin/reference.dll';managed=B/'processor24819-managed/probe.exe';native=B/'processor24820-native/probe.exe';baseline=B/'processor24776-csharp/result.json';unicodeBaseline=B/'processor24794-unicode-csharp/result.json';default=json.loads(baseline.read_text())['cases'][0]['actual']['processors'];observed={x['id']:x['actual'] for x in json.loads(unicodeBaseline.read_text())['cases']};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
plans=[(extra,[(x,default if x['expected']=='default' else x['expected']) for x in json.loads(extra.read_text())['cases']]),(unicode,[(x,observed[x['id']]) for x in json.loads(unicode.read_text())['cases']])]
pins={str(p.resolve()):sha(p) for p in [Path(__file__),extra,unicode,baseline,unicodeBaseline,*managed_runtime_inputs(controller.with_suffix('.exe')),*managed_runtime_inputs(reference.with_suffix('.exe')),managed,native,R/'selfhost/runtime/windows_processors.slg']}
for proof in ['processor24819-managed','processor24820-native']:
 j=json.loads((B/proof/'result.json').read_text());assert j['status']=='passed' and j['inputsStable'] and j['processesStopped'];assert j['inputHashes'][str(R/'selfhost/runtime/windows_processors.slg')]==sha(R/'selfhost/runtime/windows_processors.slg')
initialize_output(R,O,reusable_directories=[B/'nativeabi24815-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=sum(len(cases) for _,cases in plans)*2,cases=[],inputHashes=pins,scope='Current managed/Native source adapters; CSharp baseline oracles retained without rerunning unchanged reference processes',claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for side,exe in [('managed',managed),('native',native)]:
   for contract,cases in plans:
    for index,(case,expected) in enumerate(cases):
     name=side+'-'+contract.stem+'-'+case['id'].replace('+','');r=ex.run(['dotnet',str(controller),str(contract),str(index),str(exe)],O/name,timeout=30);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr;actual=int(r.stdout.strip());assert actual==expected,(side,case,actual,expected)
     result['cases'].append(dict(side=side,contract=contract.name,id=case['id'],passed=True,expected=expected,actual=actual));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

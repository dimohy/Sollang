from pathlib import Path
import sys,json,hashlib,re,time
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'nativeabi24818-native-style';C=B/'nativeabi24815-native/compiler.exe';L=R/'.tools/llvm-22.1.8';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();names=['886-fixed-length-growable-array-warning','975-growable-contract-suppresses-fixed-array-warning','953-conditional-push-not-fixed-length'];cases=[(name,R/'examples/regression'/(name+'.slg'),R/'examples/regression/expected'/(name+'.stdout.txt')) for name in names]
pins={str(p.resolve()):sha(p) for p in [Path(__file__),C,*[p for row in cases for p in row[1:]],*sorted((R/'stdlib').rglob('*.slg'))]}
initialize_output(R,O,reusable_directories=[B/'nativeabi24815-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=3,cases=[],inputHashes=pins,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for name,source,expected in cases:
   folder=O/name;folder.mkdir();exe=folder/'probe.exe';start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));r=ex.run([str(C),'build',str(source),'-o',str(exe),'--target','windows-x64','--keep-temps','-O1','--jobs','4','--llvm',str(L)],folder/'build',timeout=budget());assert r.returncode==0,r.stdout+r.stderr;codes=re.findall(r'\b(?:warning|note) ([A-Z][0-9]{3})\b',r.stderr);assert codes==(['S003'] if name.startswith('886') else []),(name,r.stderr)
   run=ex.run([str(exe)],folder/'run',timeout=budget());assert run.returncode==0 and not run.stderr and run.stdout==expected.read_text(),run.stdout+run.stderr;result['cases'].append(dict(id=name,passed=True,diagnosticCodes=codes,compilerStderr=r.stderr,stdout=run.stdout));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))


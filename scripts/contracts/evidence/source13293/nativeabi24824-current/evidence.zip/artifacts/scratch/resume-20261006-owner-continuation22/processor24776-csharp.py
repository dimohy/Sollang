from pathlib import Path
import sys,json,hashlib,ctypes,math
from xml.sax.saxutils import escape
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'processor24776-csharp';P=R/'scripts/probes/windows-linker';contract=P/'processor-contract.json';plan=json.loads(contract.read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
api=ctypes.WinDLL('kernel32',use_last_error=True);api.GetActiveProcessorCount.argtypes=[ctypes.c_ushort];api.GetActiveProcessorCount.restype=ctypes.c_uint;api.GetActiveProcessorGroupCount.restype=ctypes.c_ushort
hardware=dict(activeProcessors=api.GetActiveProcessorCount(65535),activeGroups=api.GetActiveProcessorGroupCount());assert hardware['activeGroups']==1,'PROCESSOR_BASELINE_ORACLE_REQUIRES_GROUP_POLICY_INSPECTION'
initialize_output(R,O,reusable_directories=[B/'workspace24738-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
projects=[]
for name in ['reference','controller']:
 folder=O/name;folder.mkdir();project=folder/(name+'.csproj');project.write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net11.0</TargetFramework><EnableDefaultCompileItems>false</EnableDefaultCompileItems><RestoreSources></RestoreSources></PropertyGroup><ItemGroup><Compile Include="'+escape(str(P/('processor-'+name+'.cs')))+'" /></ItemGroup></Project>');projects.append(project)
pins={str(p.resolve()):sha(p) for p in [Path(__file__),contract,*projects,P/'processor-reference.cs',P/'processor-controller.cs',R/'global.json',R/'Directory.Build.props']}
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=len(plan['cases']),cases=[],hardware=hardware,inputHashes=pins,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for project in projects:
   r=ex.run(['dotnet','build',str(project),'-c','Release','-o',str(project.parent/'bin'),'--nologo','-v','minimal','/nodeReuse:false','/p:UseSharedCompilation=false','/warnaserror'],O/('build-'+project.stem),timeout=180);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  for index,case in enumerate(plan['cases']):
   r=ex.run(['dotnet',str(O/'controller/bin/controller.dll'),str(contract),str(index),'dotnet',str(O/'reference/bin/reference.dll')],O/case['id'],timeout=30);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr;actual=json.loads(r.stdout)
   if 'expected' in case:expected=case['expected']
   elif case['id']=='override-complus':expected=3
   elif 'cpuRate' in case:expected=min(result['cases'][0]['actual']['processors'],math.ceil(hardware['activeProcessors']*case['cpuRate']/10000))
   else:expected=result['cases'][0]['actual']['processors'] if result['cases'] else actual['processors']
   assert 1<=actual['processors']<=65535 and actual['processors']==expected,(case,actual,expected)
   result['cases'].append(dict(id=case['id'],passed=True,expected=expected,actual=actual));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped','hardware']}))

from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'processor24800-extra';P=R/'scripts/probes/windows-linker';contract=P/'processor-configuration-controls.json';plan=json.loads(contract.read_text());reference=B/'processor24776-csharp/result.json';baseline=json.loads(reference.read_text());controller=B/'processor24776-csharp/controller/bin/controller.dll';managed=B/'processor24797-managed/probe.exe';ref=B/'processor24776-csharp/reference/bin/reference.dll';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
pins={str(p.resolve()):sha(p) for p in [Path(__file__),contract,reference,controller,*managed_runtime_inputs(controller.with_suffix('.exe')),managed,ref,*managed_runtime_inputs(ref.with_suffix('.exe')),R/'selfhost/runtime/windows_processors.slg']}
initialize_output(R,O,reusable_directories=[B/'nativeabi24791-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=20,cases=[],inputHashes=pins,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for side,command in [('csharp',['dotnet',str(ref)]),('managed-source',[str(managed)])]:
   for index,case in enumerate(plan['cases']):
    r=ex.run(['dotnet',str(controller),str(contract),str(index),*command],O/(side+'-'+case['id']),timeout=30);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr;actual=json.loads(r.stdout)['processors'] if side=='csharp' else int(r.stdout.strip());expected=baseline['cases'][0]['actual']['processors'] if case['expected']=='default' else case['expected'];assert actual==expected,(side,case,actual,expected)
    result['cases'].append(dict(side=side,id=case['id'],passed=True,expected=expected,actual=actual));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))


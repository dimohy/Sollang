; sollang workers = 4
; sollang.codegen.unit 0:
; sollang.codegen.key 6335269229529931319:13756067416925304071
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"
declare ptr @GetProcessHeap()
declare ptr @HeapAlloc(ptr, i32, i64)
declare i32 @HeapFree(ptr, i32, ptr)
define internal ptr @sollang_alloc(i64 %bytes) {
entry:
  %heap = call ptr @GetProcessHeap()
  %value = call ptr @HeapAlloc(ptr %heap, i32 0, i64 %bytes)
  ret ptr %value
}
define internal void @sollang_free(ptr %value) {
entry:
  %is_null = icmp eq ptr %value, null
  br i1 %is_null, label %done, label %release
release:
  %heap = call ptr @GetProcessHeap()
  %ignored = call i32 @HeapFree(ptr %heap, i32 0, ptr %value)
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1 immarg)
define internal ptr @sollang_resize(ptr %old, i64 %used_bytes, i64 %new_bytes) {
entry:
  %value = call ptr @sollang_alloc(i64 %new_bytes)
  %allocated = icmp ne ptr %value, null
  br i1 %allocated, label %inspect_old, label %failure
inspect_old:
  %has_old = icmp ne ptr %old, null
  %has_bytes = icmp ne i64 %used_bytes, 0
  %copy_needed = and i1 %has_old, %has_bytes
  br i1 %copy_needed, label %copy, label %release
copy:
  %fits = icmp ule i64 %used_bytes, %new_bytes
  %copy_bytes = select i1 %fits, i64 %used_bytes, i64 %new_bytes
  call void @llvm.memcpy.p0.p0.i64(ptr %value, ptr %old, i64 %copy_bytes, i1 false)
  br label %release
release:
  call void @sollang_free(ptr %old)
  ret ptr %value
failure:
  ret ptr null
}
declare ptr @GetStdHandle(i32)
declare i32 @GetConsoleMode(ptr, ptr)
declare i32 @WriteConsoleW(ptr, ptr, i32, ptr, ptr)
declare i32 @WriteFile(ptr, ptr, i32, ptr, ptr)
declare i32 @MultiByteToWideChar(i32, i32, ptr, i32, ptr, i32)
define internal i32 @sollang_write_stream_chunk(ptr %handle, ptr %data, i32 %len, ptr %written, i1 %is_console) {
entry:
  %empty = icmp eq i32 %len, 0
  br i1 %empty, label %success_empty, label %classify

success_empty:
  store i32 0, ptr %written, align 4
  ret i32 1

classify:
  br i1 %is_console, label %console_prepare, label %redirected

redirected:
  br label %redirected_write

redirected_write:
  %redirected_offset = phi i32 [ 0, %redirected ], [ %redirected_next, %redirected_advance ]
  %redirected_remaining = sub i32 %len, %redirected_offset
  %redirected_offset64 = zext i32 %redirected_offset to i64
  %redirected_data = getelementptr i8, ptr %data, i64 %redirected_offset64
  store i32 0, ptr %written, align 4
  %redirected_ok = call i32 @WriteFile(ptr %handle, ptr %redirected_data, i32 %redirected_remaining, ptr %written, ptr null)
  %redirected_count = load i32, ptr %written, align 4
  %redirected_succeeded = icmp ne i32 %redirected_ok, 0
  %redirected_progress = icmp ugt i32 %redirected_count, 0
  %redirected_bounded = icmp ule i32 %redirected_count, %redirected_remaining
  %redirected_valid0 = and i1 %redirected_succeeded, %redirected_progress
  %redirected_valid = and i1 %redirected_valid0, %redirected_bounded
  br i1 %redirected_valid, label %redirected_advance, label %write_failed

redirected_advance:
  %redirected_next = add i32 %redirected_offset, %redirected_count
  %redirected_complete = icmp eq i32 %redirected_next, %len
  br i1 %redirected_complete, label %write_succeeded, label %redirected_write

console_prepare:
  %wide_chars = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %len, ptr null, i32 0)
  %valid_utf8 = icmp sgt i32 %wide_chars, 0
  br i1 %valid_utf8, label %allocate, label %conversion_failed

allocate:
  %wide_bytes32 = shl i32 %wide_chars, 1
  %wide_bytes = zext i32 %wide_bytes32 to i64
  %heap = call ptr @GetProcessHeap()
  %wide = call ptr @HeapAlloc(ptr %heap, i32 0, i64 %wide_bytes)
  %wide_written = alloca i32, align 4
  %allocated = icmp ne ptr %wide, null
  br i1 %allocated, label %convert, label %conversion_failed

convert:
  %converted = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %len, ptr %wide, i32 %wide_chars)
  %converted_all = icmp eq i32 %converted, %wide_chars
  br i1 %converted_all, label %console_write, label %conversion_free

console_write:
  %console_offset = phi i32 [ 0, %convert ], [ %console_next, %console_advance ]
  %console_remaining = sub i32 %wide_chars, %console_offset
  %console_offset64 = zext i32 %console_offset to i64
  %console_data = getelementptr i16, ptr %wide, i64 %console_offset64
  store i32 0, ptr %wide_written, align 4
  %console_ok = call i32 @WriteConsoleW(ptr %handle, ptr %console_data, i32 %console_remaining, ptr %wide_written, ptr null)
  %console_count = load i32, ptr %wide_written, align 4
  %console_succeeded = icmp ne i32 %console_ok, 0
  %console_progress = icmp ugt i32 %console_count, 0
  %console_bounded = icmp ule i32 %console_count, %console_remaining
  %console_valid0 = and i1 %console_succeeded, %console_progress
  %console_valid = and i1 %console_valid0, %console_bounded
  br i1 %console_valid, label %console_advance, label %console_write_failed

console_advance:
  %console_next = add i32 %console_offset, %console_count
  %console_complete = icmp eq i32 %console_next, %wide_chars
  br i1 %console_complete, label %console_write_succeeded, label %console_write

console_write_succeeded:
  %freed = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %write_succeeded

console_write_failed:
  %freed_after_write_failure = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %write_failed

write_succeeded:
  store i32 %len, ptr %written, align 4
  ret i32 1

write_failed:
  store i32 0, ptr %written, align 4
  ret i32 0

conversion_free:
  %freed_after_failure = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %conversion_failed

conversion_failed:
  store i32 0, ptr %written, align 4
  ret i32 0
}

define internal i32 @sollang_write_stream(ptr %handle, ptr %data, i64 %len64, ptr %written, i1 %is_console) {
entry:
  %empty = icmp eq i64 %len64, 0
  br i1 %empty, label %success_empty, label %prepare

success_empty:
  store i32 0, ptr %written, align 4
  ret i32 1

prepare:
  %offset = phi i64 [ 0, %entry ], [ %next, %advance ]
  %remaining = sub i64 %len64, %offset
  %current = getelementptr i8, ptr %data, i64 %offset
  %more = icmp ugt i64 %remaining, 1048576
  %proposed = select i1 %more, i64 1048576, i64 %remaining
  %split_console = and i1 %more, %is_console
  br i1 %split_console, label %trim_boundary, label %write

trim_boundary:
  %boundary = phi i64 [ 1048576, %prepare ], [ %previous, %trim_next ]
  %boundary_ptr = getelementptr i8, ptr %current, i64 %boundary
  %boundary_byte = load i8, ptr %boundary_ptr, align 1
  %prefix = and i8 %boundary_byte, -64
  %continuation = icmp eq i8 %prefix, -128
  br i1 %continuation, label %trim_next, label %write

trim_next:
  %can_trim = icmp ugt i64 %boundary, 1048573
  %previous = sub i64 %boundary, 1
  br i1 %can_trim, label %trim_boundary, label %failure

write:
  %chunk64 = phi i64 [ %proposed, %prepare ], [ %boundary, %trim_boundary ]
  %chunk32 = trunc i64 %chunk64 to i32
  %ok = call i32 @sollang_write_stream_chunk(ptr %handle, ptr %current, i32 %chunk32, ptr %written, i1 %is_console)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %advance, label %failure

advance:
  %next = add i64 %offset, %chunk64
  %complete = icmp eq i64 %next, %len64
  br i1 %complete, label %success, label %prepare

success:
  ret i32 1

failure:
  store i32 0, ptr %written, align 4
  ret i32 0
}

define internal i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %len) {
entry:
  %written = alloca i32, align 4
  %mode = alloca i32, align 4
  %empty = icmp eq i64 %len, 0
  br i1 %empty, label %success, label %classify
classify:
  %console_status = call i32 @GetConsoleMode(ptr %handle, ptr %mode)
  %is_console = icmp ne i32 %console_status, 0
  %ok = call i32 @sollang_write_stream(ptr %handle, ptr %data, i64 %len, ptr %written, i1 %is_console)
  ret i32 %ok
success:
  ret i32 1
}
define internal i32 @sollang_runtime_write_stdout_bytes(ptr %handle, ptr %data, i32 %len) {
entry:
  %length = zext i32 %len to i64
  %ok = call i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %length)
  ret i32 %ok
}
@sollang_runtime_newline = private constant [1 x i8] c"\0A"
@sollang_runtime_stdout_buffer = private global [1048576 x i8] zeroinitializer
@sollang_runtime_stdout_count = private global i64 0
define internal void @sollang_runtime_flush_stdout() {
entry:
  %count = load i64, ptr @sollang_runtime_stdout_count, align 8
  %has_data = icmp ugt i64 %count, 0
  br i1 %has_data, label %write, label %done
write:
  %handle = call ptr @GetStdHandle(i32 -11)
  %count32 = trunc i64 %count to i32
  %ok = call i32 @sollang_runtime_write_stdout_bytes(ptr %handle, ptr @sollang_runtime_stdout_buffer, i32 %count32)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %clear, label %failure
clear:
  store i64 0, ptr @sollang_runtime_stdout_count, align 8
  br label %done
failure:
  call void @llvm.trap()
  unreachable
done:
  ret void
}
define internal void @sollang_runtime_append_stdout(ptr %data, i64 %len) {
entry:
  %count = load i64, ptr @sollang_runtime_stdout_count, align 8
  %total = add i64 %count, %len
  %available = sub i64 1048576, %count
  %fits = icmp ule i64 %len, %available
  br i1 %fits, label %append, label %flush
flush:
  call void @sollang_runtime_flush_stdout()
  %large = icmp ugt i64 %len, 1048576
  br i1 %large, label %direct, label %append_empty
direct:
  %handle = call ptr @GetStdHandle(i32 -11)
  %ok = call i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %len)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %direct_done, label %direct_failure
direct_done:
  ret void
direct_failure:
  call void @llvm.trap()
  unreachable
append_empty:
  call void @llvm.memcpy.p0.p0.i64(ptr @sollang_runtime_stdout_buffer, ptr %data, i64 %len, i1 false)
  store i64 %len, ptr @sollang_runtime_stdout_count, align 8
  ret void
append:
  %slot = getelementptr i8, ptr @sollang_runtime_stdout_buffer, i64 %count
  call void @llvm.memcpy.p0.p0.i64(ptr %slot, ptr %data, i64 %len, i1 false)
  store i64 %total, ptr @sollang_runtime_stdout_count, align 8
  ret void
}
define internal void @sollang_runtime_print(ptr %data, i64 %len, i1 %newline) {
entry:
  call void @sollang_runtime_append_stdout(ptr %data, i64 %len)
  br i1 %newline, label %write_newline, label %done
write_newline:
  call void @sollang_runtime_append_stdout(ptr @sollang_runtime_newline, i64 1)
  br label %done
done:
  ret void
}
@sollang_runtime_error_newline = private constant [2 x i8] c"\0D\0A"
define internal void @sollang_runtime_eprint(ptr %data, i64 %len, i1 %newline) {
entry:
  %handle = call ptr @GetStdHandle(i32 -12)
  %ok = call i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %len)
  br i1 %newline, label %write_newline, label %done
write_newline:
  %newline_ok = call i32 @sollang_runtime_write_stdout_bytes(ptr %handle, ptr @sollang_runtime_error_newline, i32 2)
  br label %done
done:
  ret void
}
define internal void @sollang_runtime_eprintln(ptr %data, i64 %len) {
entry:
  call void @sollang_runtime_eprint(ptr %data, i64 %len, i1 true)
  ret void
}
define internal i64 @sollang_format_u64(ptr %dest, i64 %value) {
entry:
  br label %count
count:
  %count_n = phi i64 [ %value, %entry ], [ %count_q, %count_more ]
  %length = phi i64 [ 1, %entry ], [ %next_length, %count_more ]
  %count_q = udiv i64 %count_n, 10
  %count_done = icmp eq i64 %count_q, 0
  br i1 %count_done, label %write_entry, label %count_more
count_more:
  %next_length = add i64 %length, 1
  br label %count
write_entry:
  %last_index = sub i64 %length, 1
  br label %write
write:
  %write_n = phi i64 [ %value, %write_entry ], [ %write_q, %write ]
  %index = phi i64 [ %last_index, %write_entry ], [ %previous_index, %write ]
  %digit = urem i64 %write_n, 10
  %write_q = udiv i64 %write_n, 10
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  %slot = getelementptr i8, ptr %dest, i64 %index
  store i8 %ascii, ptr %slot, align 1
  %previous_index = sub i64 %index, 1
  %write_done = icmp eq i64 %write_q, 0
  br i1 %write_done, label %return, label %write
return:
  ret i64 %length
}
define internal i64 @sollang_format_i64(ptr %dest, i64 %value) {
entry:
  %negative = icmp slt i64 %value, 0
  br i1 %negative, label %negative_value, label %positive_value
negative_value:
  store i8 45, ptr %dest, align 1
  %digits_dest = getelementptr i8, ptr %dest, i64 1
  %magnitude = sub i64 0, %value
  %negative_digits = call i64 @sollang_format_u64(ptr %digits_dest, i64 %magnitude)
  %negative_length = add i64 %negative_digits, 1
  ret i64 %negative_length
positive_value:
  %positive_length = call i64 @sollang_format_u64(ptr %dest, i64 %value)
  ret i64 %positive_length
}
define internal void @sollang_runtime_print_i32(i32 %value, i1 %newline) {
entry:
  %buffer = alloca [12 x i8], align 1
  %end = getelementptr [12 x i8], ptr %buffer, i64 0, i64 12
  %wide = sext i32 %value to i64
  %negative = icmp slt i64 %wide, 0
  %negated = sub i64 0, %wide
  %magnitude = select i1 %negative, i64 %negated, i64 %wide
  br label %digits
digits:
  %current = phi i64 [ %magnitude, %entry ], [ %quotient, %digits ]
  %cursor = phi ptr [ %end, %entry ], [ %digit_slot, %digits ]
  %digit = urem i64 %current, 10
  %quotient = udiv i64 %current, 10
  %digit_slot = getelementptr i8, ptr %cursor, i64 -1
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  store i8 %ascii, ptr %digit_slot, align 1
  %more = icmp ne i64 %quotient, 0
  br i1 %more, label %digits, label %digits_done
digits_done:
  br i1 %negative, label %write_sign, label %emit
write_sign:
  %sign_slot = getelementptr i8, ptr %digit_slot, i64 -1
  store i8 45, ptr %sign_slot, align 1
  br label %emit
emit:
  %start = phi ptr [ %digit_slot, %digits_done ], [ %sign_slot, %write_sign ]
  %end_address = ptrtoint ptr %end to i64
  %start_address = ptrtoint ptr %start to i64
  %length = sub i64 %end_address, %start_address
  call void @sollang_runtime_print(ptr %start, i64 %length, i1 %newline)
  ret void
}
define internal void @sollang_runtime_print_i64(i64 %value, i1 %signed, i1 %newline) {
entry:
  %buffer = alloca [21 x i8], align 1
  %end = getelementptr [21 x i8], ptr %buffer, i64 0, i64 21
  %negative_value = icmp slt i64 %value, 0
  %negative = and i1 %signed, %negative_value
  %negated = sub i64 0, %value
  %magnitude = select i1 %negative, i64 %negated, i64 %value
  br label %digits
digits:
  %current = phi i64 [ %magnitude, %entry ], [ %quotient, %digits ]
  %cursor = phi ptr [ %end, %entry ], [ %digit_slot, %digits ]
  %digit = urem i64 %current, 10
  %quotient = udiv i64 %current, 10
  %digit_slot = getelementptr i8, ptr %cursor, i64 -1
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  store i8 %ascii, ptr %digit_slot, align 1
  %more = icmp ne i64 %quotient, 0
  br i1 %more, label %digits, label %digits_done
digits_done:
  br i1 %negative, label %write_sign, label %emit
write_sign:
  %sign_slot = getelementptr i8, ptr %digit_slot, i64 -1
  store i8 45, ptr %sign_slot, align 1
  br label %emit
emit:
  %start = phi ptr [ %digit_slot, %digits_done ], [ %sign_slot, %write_sign ]
  %end_address = ptrtoint ptr %end to i64
  %start_address = ptrtoint ptr %start to i64
  %length = sub i64 %end_address, %start_address
  call void @sollang_runtime_print(ptr %start, i64 %length, i1 %newline)
  ret void
}
define internal void @sollang_runtime_eprint_i32(i32 %value, i1 %newline) {
entry:
  %buffer = alloca [12 x i8], align 1
  %end = getelementptr [12 x i8], ptr %buffer, i64 0, i64 12
  %wide = sext i32 %value to i64
  %negative = icmp slt i64 %wide, 0
  %negated = sub i64 0, %wide
  %magnitude = select i1 %negative, i64 %negated, i64 %wide
  br label %digits
digits:
  %current = phi i64 [ %magnitude, %entry ], [ %quotient, %digits ]
  %cursor = phi ptr [ %end, %entry ], [ %digit_slot, %digits ]
  %digit = urem i64 %current, 10
  %quotient = udiv i64 %current, 10
  %digit_slot = getelementptr i8, ptr %cursor, i64 -1
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  store i8 %ascii, ptr %digit_slot, align 1
  %more = icmp ne i64 %quotient, 0
  br i1 %more, label %digits, label %digits_done
digits_done:
  br i1 %negative, label %write_sign, label %emit
write_sign:
  %sign_slot = getelementptr i8, ptr %digit_slot, i64 -1
  store i8 45, ptr %sign_slot, align 1
  br label %emit
emit:
  %start = phi ptr [ %digit_slot, %digits_done ], [ %sign_slot, %write_sign ]
  %end_address = ptrtoint ptr %end to i64
  %start_address = ptrtoint ptr %start to i64
  %length = sub i64 %end_address, %start_address
  call void @sollang_runtime_eprint(ptr %start, i64 %length, i1 %newline)
  ret void
}
define internal void @sollang_runtime_eprint_i64(i64 %value, i1 %signed, i1 %newline) {
entry:
  %buffer = alloca [21 x i8], align 1
  %end = getelementptr [21 x i8], ptr %buffer, i64 0, i64 21
  %negative_value = icmp slt i64 %value, 0
  %negative = and i1 %signed, %negative_value
  %negated = sub i64 0, %value
  %magnitude = select i1 %negative, i64 %negated, i64 %value
  br label %digits
digits:
  %current = phi i64 [ %magnitude, %entry ], [ %quotient, %digits ]
  %cursor = phi ptr [ %end, %entry ], [ %digit_slot, %digits ]
  %digit = urem i64 %current, 10
  %quotient = udiv i64 %current, 10
  %digit_slot = getelementptr i8, ptr %cursor, i64 -1
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  store i8 %ascii, ptr %digit_slot, align 1
  %more = icmp ne i64 %quotient, 0
  br i1 %more, label %digits, label %digits_done
digits_done:
  br i1 %negative, label %write_sign, label %emit
write_sign:
  %sign_slot = getelementptr i8, ptr %digit_slot, i64 -1
  store i8 45, ptr %sign_slot, align 1
  br label %emit
emit:
  %start = phi ptr [ %digit_slot, %digits_done ], [ %sign_slot, %write_sign ]
  %end_address = ptrtoint ptr %end to i64
  %start_address = ptrtoint ptr %start to i64
  %length = sub i64 %end_address, %start_address
  call void @sollang_runtime_eprint(ptr %start, i64 %length, i1 %newline)
  ret void
}
declare dllimport ptr @CreateFileA(ptr, i32, i32, ptr, i32, i32, ptr)
declare dllimport ptr @CreateFileW(ptr, i32, i32, ptr, i32, i32, ptr)
declare dllimport i32 @CloseHandle(ptr)
declare dllimport i32 @GetEnvironmentVariableW(ptr, ptr, i32)
declare dllimport void @SetLastError(i32)
declare dllimport i32 @GetLastError()
declare dllimport i32 @WideCharToMultiByte(i32, i32, ptr, i32, ptr, i32, ptr, ptr)
%sollang.environment_result = type { ptr, i64, i1, i1 }
@sollang_bool_true_bytes = private constant [4 x i8] c"true"
@sollang_bool_false_bytes = private constant [5 x i8] c"false"
%sollang.source_text = type { ptr, i64, ptr, i64 }
%sollang.text = type { ptr, i64 }
%sollang.stream = type { ptr, ptr, ptr }
%sollang.event_stream = type { ptr, ptr, ptr }
%sollang.enum.t464 = type { i32, [0 x i64] }
%sollang.enum.t465 = type { i32, [0 x i64] }
%sollang.enum.t466 = type { i32, [0 x i64] }
%sollang.enum.t467 = type { i32, [0 x i64] }
%sollang.enum.t468 = type { i32, [0 x i64] }
%sollang.enum.t469 = type { i32, [0 x i64] }
%sollang.enum.t470 = type { i32, [0 x i64] }
%sollang.enum.t471 = type { i32, [0 x i64] }
%sollang.enum.t472 = type { i32, [0 x i64] }
%sollang.enum.t473 = type { i32, [0 x i64] }
%sollang.enum.t474 = type { i32, [0 x i64] }
%sollang.enum.t475 = type { i32, [0 x i64] }
%sollang.enum.t476 = type { i32, [0 x i64] }
%sollang.enum.t477 = type { i32, [1 x i64] }
%sollang.enum.t478 = type { i32, [1 x i64] }
%sollang.enum.t479 = type { i32, [0 x i64] }
%sollang.enum.t480 = type { i32, [0 x i64] }
%sollang.enum.t481 = type { i32, [5 x i64] }
%sollang.enum.t482 = type { i32, [4 x i64] }
%sollang.enum.t483 = type { i32, [0 x i64] }
%sollang.enum.t484 = type { i32, [1 x i64] }
%sollang.enum.t485 = type { i32, [0 x i64] }
%sollang.enum.t486 = type { i32, [1 x i64] }
%sollang.enum.t487 = type { i32, [0 x i64] }
%sollang.enum.t488 = type { i32, [1 x i64] }
%sollang.enum.t489 = type { i32, [0 x i64] }
%sollang.enum.t490 = type { i32, [1 x i64] }
%sollang.enum.t491 = type { i32, [1 x i64] }
%sollang.enum.t492 = type { i32, [0 x i64] }
%sollang.enum.t493 = type { i32, [66 x i64] }
%sollang.enum.t494 = type { i32, [1 x i64] }
%sollang.enum.t495 = type { i32, [1 x i64] }
%sollang.enum.t496 = type { i32, [0 x i64] }
%sollang.enum.t497 = type { i32, [4 x i64] }
%sollang.enum.t498 = type { i32, [1 x i64] }
%sollang.enum.t499 = type { i32, [1 x i64] }
%sollang.enum.t500 = type { i32, [0 x i64] }
%sollang.enum.t501 = type { i32, [0 x i64] }
%sollang.enum.t502 = type { i32, [0 x i64] }
%sollang.enum.t503 = type { i32, [0 x i64] }
%sollang.enum.t504 = type { i32, [0 x i64] }
%sollang.enum.t505 = type { i32, [1 x i64] }
%sollang.enum.t506 = type { i32, [0 x i64] }
%sollang.enum.t507 = type { i32, [4 x i64] }
%sollang.enum.t508 = type { i32, [1 x i64] }
%sollang.enum.t509 = type { i32, [0 x i64] }
%sollang.enum.t510 = type { i32, [1 x i64] }
%sollang.enum.t511 = type { i32, [1 x i64] }
%sollang.enum.t512 = type { i32, [0 x i64] }
%sollang.enum.t513 = type { i32, [0 x i64] }
%sollang.enum.t514 = type { i32, [0 x i64] }
%sollang.enum.t515 = type { i32, [1 x i64] }
%sollang.enum.t516 = type { i32, [0 x i64] }
%sollang.enum.t517 = type { i32, [0 x i64] }
%sollang.enum.t518 = type { i32, [0 x i64] }
%sollang.enum.t519 = type { i32, [0 x i64] }
%sollang.enum.t520 = type { i32, [0 x i64] }
%sollang.enum.t521 = type { i32, [0 x i64] }
%sollang.enum.t522 = type { i32, [0 x i64] }
%sollang.enum.t523 = type { i32, [0 x i64] }
%sollang.enum.t524 = type { i32, [0 x i64] }
%sollang.enum.t525 = type { i32, [3 x i64] }
%sollang.enum.t526 = type { i32, [0 x i64] }
%sollang.enum.t527 = type { i32, [0 x i64] }
%sollang.enum.t528 = type { i32, [0 x i64] }
%sollang.enum.t529 = type { i32, [0 x i64] }
%sollang.enum.t530 = type { i32, [0 x i64] }
%sollang.enum.t531 = type { i32, [0 x i64] }
%sollang.enum.t532 = type { i32, [0 x i64] }
%sollang.enum.t533 = type { i32, [0 x i64] }
%sollang.enum.t534 = type { i32, [0 x i64] }
%sollang.enum.t535 = type { i32, [0 x i64] }
%sollang.enum.t536 = type { i32, [3 x i64] }
%sollang.enum.t537 = type { i32, [0 x i64] }
%sollang.enum.t538 = type { i32, [2 x i64] }
%sollang.enum.t539 = type { i32, [0 x i64] }
%sollang.enum.t540 = type { i32, [2 x i64] }
%sollang.enum.t541 = type { i32, [4 x i64] }
%sollang.enum.t542 = type { i32, [0 x i64] }
%sollang.enum.t543 = type { i32, [0 x i64] }
%sollang.enum.t544 = type { i32, [0 x i64] }
%sollang.enum.t545 = type { i32, [1 x i64] }
%sollang.enum.t546 = type { i32, [0 x i64] }
%sollang.enum.t547 = type { i32, [0 x i64] }
%sollang.enum.t548 = type { i32, [2 x i64] }
%sollang.enum.t549 = type { i32, [7 x i64] }
%sollang.enum.t550 = type { i32, [0 x i64] }
%sollang.enum.t551 = type { i32, [2 x i64] }
%sollang.enum.t552 = type { i32, [0 x i64] }
%sollang.enum.t553 = type { i32, [0 x i64] }
%sollang.enum.t554 = type { i32, [0 x i64] }
%sollang.enum.t555 = type { i32, [0 x i64] }
%sollang.enum.t556 = type { i32, [2 x i64] }
%sollang.enum.t557 = type { i32, [8 x i64] }
%sollang.enum.t558 = type { i32, [0 x i64] }
%sollang.enum.t559 = type { i32, [0 x i64] }
%sollang.enum.t560 = type { i32, [7 x i64] }
%sollang.enum.t561 = type { i32, [0 x i64] }
%sollang.enum.t562 = type { i32, [0 x i64] }
%sollang.enum.t563 = type { i32, [0 x i64] }
%sollang.enum.t564 = type { i32, [0 x i64] }
%sollang.enum.t565 = type { i32, [0 x i64] }
%sollang.enum.t566 = type { i32, [0 x i64] }
%sollang.enum.t567 = type { i32, [0 x i64] }
%sollang.enum.t568 = type { i32, [1 x i64] }
%sollang.enum.t569 = type { i32, [0 x i64] }
%sollang.enum.t570 = type { i32, [0 x i64] }
%sollang.enum.t571 = type { i32, [16 x i64] }
%sollang.enum.t572 = type { i32, [16 x i64] }
%sollang.enum.t573 = type { i32, [0 x i64] }
%sollang.enum.t574 = type { i32, [0 x i64] }
%sollang.enum.t575 = type { i32, [0 x i64] }
%sollang.enum.t576 = type { i32, [0 x i64] }
%sollang.enum.t577 = type { i32, [0 x i64] }
%sollang.enum.t578 = type { i32, [0 x i64] }
%sollang.enum.t579 = type { i32, [0 x i64] }
%sollang.enum.t580 = type { i32, [0 x i64] }
%sollang.enum.t581 = type { i32, [0 x i64] }
%sollang.enum.t582 = type { i32, [0 x i64] }
%sollang.enum.t583 = type { i32, [0 x i64] }
%sollang.enum.t584 = type { i32, [0 x i64] }
%sollang.enum.t585 = type { i32, [0 x i64] }
%sollang.enum.t586 = type { i32, [0 x i64] }
%sollang.enum.t587 = type { i32, [0 x i64] }
%sollang.enum.t588 = type { i32, [3 x i64] }
%sollang.enum.t589 = type { i32, [1 x i64] }
%sollang.enum.t590 = type { i32, [12 x i64] }
%sollang.enum.t591 = type { i32, [0 x i64] }
%sollang.enum.t592 = type { i32, [0 x i64] }
%sollang.enum.t593 = type { i32, [0 x i64] }
%sollang.enum.t594 = type { i32, [0 x i64] }
%sollang.enum.t595 = type { i32, [0 x i64] }
%sollang.enum.t596 = type { i32, [4 x i64] }
%sollang.enum.t597 = type { i32, [3 x i64] }
%sollang.enum.t598 = type { i32, [0 x i64] }
%sollang.enum.t599 = type { i32, [2 x i64] }
%sollang.enum.t600 = type { i32, [0 x i64] }
%sollang.enum.t601 = type { i32, [0 x i64] }
%sollang.enum.t602 = type { i32, [0 x i64] }
%sollang.enum.t603 = type { i32, [0 x i64] }
%sollang.enum.t604 = type { i32, [2 x i64] }
%sollang.enum.t605 = type { i32, [2 x i64] }
%sollang.enum.t606 = type { i32, [1 x i64] }
%sollang.enum.t651 = type { i32, [1 x i64] }
%sollang.enum.t658 = type { i32, [1 x i64] }
%sollang.enum.t661 = type { i32, [1 x i64] }
%sollang.enum.t674 = type { i32, [3 x i64] }
%sollang.enum.t675 = type { i32, [44 x i64] }
%sollang.enum.t676 = type { i32, [2 x i64] }
%sollang.enum.t677 = type { i32, [13 x i64] }
%sollang.enum.t678 = type { i32, [2 x i64] }
%sollang.enum.t681 = type { i32, [1 x i64] }
%sollang.enum.t682 = type { i32, [7 x i64] }
%sollang.enum.t683 = type { i32, [1 x i64] }
%sollang.enum.t686 = type { i32, [3 x i64] }
%sollang.enum.t689 = type { i32, [1 x i64] }
%sollang.enum.t690 = type { i32, [3 x i64] }
%sollang.enum.t691 = type { i32, [4 x i64] }
%sollang.enum.t692 = type { i32, [105 x i64] }
%sollang.enum.t693 = type { i32, [2 x i64] }
%sollang.enum.t694 = type { i32, [9 x i64] }
%sollang.enum.t695 = type { i32, [26 x i64] }
%sollang.enum.t696 = type { i32, [81 x i64] }
%sollang.enum.t697 = type { i32, [2 x i64] }
%sollang.enum.t700 = type { i32, [3 x i64] }
%sollang.enum.t702 = type { i32, [26 x i64] }
%sollang.enum.t703 = type { i32, [4 x i64] }
%sollang.enum.t704 = type { i32, [2 x i64] }
%sollang.enum.t705 = type { i32, [2 x i64] }
%sollang.enum.t706 = type { i32, [2 x i64] }
%sollang.enum.t707 = type { i32, [50 x i64] }
%sollang.enum.t708 = type { i32, [2 x i64] }
%sollang.enum.t709 = type { i32, [3 x i64] }
%sollang.enum.t710 = type { i32, [2 x i64] }
%sollang.enum.t711 = type { i32, [2 x i64] }
%sollang.enum.t713 = type { i32, [2 x i64] }
%sollang.enum.t714 = type { i32, [2 x i64] }
%sollang.enum.t719 = type { i32, [9 x i64] }
%sollang.enum.t720 = type { i32, [24 x i64] }
%sollang.enum.t721 = type { i32, [2 x i64] }
%sollang.enum.t722 = type { i32, [12 x i64] }
%sollang.enum.t723 = type { i32, [11 x i64] }
%sollang.enum.t724 = type { i32, [2 x i64] }
%sollang.enum.t725 = type { i32, [32 x i64] }
%sollang.enum.t726 = type { i32, [34 x i64] }
%sollang.enum.t727 = type { i32, [2 x i64] }
%sollang.enum.t728 = type { i32, [9 x i64] }
%sollang.enum.t729 = type { i32, [31 x i64] }
%sollang.enum.t730 = type { i32, [2 x i64] }
%sollang.enum.t731 = type { i32, [15 x i64] }
%sollang.enum.t732 = type { i32, [34 x i64] }
%sollang.enum.t733 = type { i32, [2 x i64] }
%sollang.enum.t734 = type { i32, [2 x i64] }
%sollang.enum.t735 = type { i32, [6 x i64] }
%sollang.enum.t736 = type { i32, [2 x i64] }
%sollang.enum.t737 = type { i32, [2 x i64] }
%sollang.enum.t738 = type { i32, [2 x i64] }
%sollang.enum.t740 = type { i32, [14 x i64] }
%sollang.enum.t741 = type { i32, [9 x i64] }
%sollang.enum.t742 = type { i32, [5 x i64] }
%sollang.enum.t743 = type { i32, [5 x i64] }
%sollang.enum.t744 = type { i32, [4 x i64] }
%sollang.enum.t745 = type { i32, [2 x i64] }
%sollang.enum.t747 = type { i32, [2 x i64] }
%sollang.enum.t748 = type { i32, [2 x i64] }
%sollang.enum.t749 = type { i32, [81 x i64] }
%sollang.enum.t750 = type { i32, [2 x i64] }
%sollang.enum.t751 = type { i32, [3 x i64] }
%sollang.enum.t752 = type { i32, [3 x i64] }
%sollang.enum.t753 = type { i32, [5 x i64] }
%sollang.enum.t754 = type { i32, [2 x i64] }
%sollang.enum.t755 = type { i32, [14 x i64] }
%sollang.enum.t756 = type { i32, [2 x i64] }
%sollang.enum.t757 = type { i32, [32 x i64] }
%sollang.enum.t758 = type { i32, [4 x i64] }
%sollang.enum.t759 = type { i32, [2 x i64] }
%sollang.enum.t761 = type { i32, [5 x i64] }
%sollang.enum.t762 = type { i32, [2 x i64] }
%sollang.enum.t763 = type { i32, [2 x i64] }
%sollang.enum.t764 = type { i32, [5 x i64] }
%sollang.enum.t765 = type { i32, [2 x i64] }
%sollang.enum.t766 = type { i32, [2 x i64] }
%sollang.enum.t767 = type { i32, [32 x i64] }
%sollang.enum.t768 = type { i32, [2 x i64] }
%sollang.enum.t769 = type { i32, [4 x i64] }
%sollang.enum.t772 = type { i32, [2 x i64] }
%sollang.enum.t773 = type { i32, [2 x i64] }
%sollang.enum.t774 = type { i32, [4 x i64] }
%sollang.enum.t775 = type { i32, [2 x i64] }
%sollang.enum.t776 = type { i32, [2 x i64] }
%sollang.enum.t777 = type { i32, [2 x i64] }
%sollang.enum.t778 = type { i32, [2 x i64] }
%sollang.enum.t779 = type { i32, [2 x i64] }
%sollang.enum.t780 = type { i32, [2 x i64] }
%sollang.enum.t781 = type { i32, [3 x i64] }
%sollang.enum.t782 = type { i32, [2 x i64] }
%sollang.enum.t784 = type { i32, [3 x i64] }
%sollang.enum.t785 = type { i32, [4 x i64] }
%sollang.enum.t786 = type { i32, [9 x i64] }
%sollang.enum.t787 = type { i32, [2 x i64] }
%sollang.enum.t788 = type { i32, [32 x i64] }
%sollang.enum.t789 = type { i32, [3 x i64] }
%sollang.enum.t791 = type { i32, [5 x i64] }
%sollang.enum.t792 = type { i32, [2 x i64] }
%sollang.enum.t793 = type { i32, [2 x i64] }
%sollang.enum.t794 = type { i32, [4 x i64] }
%sollang.enum.t795 = type { i32, [4 x i64] }
%sollang.enum.t796 = type { i32, [72 x i64] }
%sollang.enum.t797 = type { i32, [2 x i64] }
%sollang.enum.t798 = type { i32, [2 x i64] }
%sollang.enum.t799 = type { i32, [2 x i64] }
%sollang.enum.t800 = type { i32, [13 x i64] }
%sollang.enum.t801 = type { i32, [26 x i64] }
%sollang.enum.t802 = type { i32, [5 x i64] }
%sollang.enum.t803 = type { i32, [2 x i64] }
%sollang.enum.t806 = type { i32, [2 x i64] }
%sollang.enum.t807 = type { i32, [72 x i64] }
%sollang.enum.t808 = type { i32, [3 x i64] }
%sollang.enum.t809 = type { i32, [3 x i64] }
%sollang.enum.t810 = type { i32, [13 x i64] }
%sollang.enum.t811 = type { i32, [70 x i64] }
%sollang.enum.t812 = type { i32, [2 x i64] }
%sollang.enum.t813 = type { i32, [40 x i64] }
%sollang.enum.t817 = type { i32, [3 x i64] }
%sollang.enum.t818 = type { i32, [10 x i64] }
%sollang.enum.t819 = type { i32, [11 x i64] }
%sollang.enum.t820 = type { i32, [2 x i64] }
%sollang.enum.t821 = type { i32, [1 x i64] }
%sollang.enum.t822 = type { i32, [5 x i64] }
%sollang.enum.t823 = type { i32, [3 x i64] }
%sollang.enum.t824 = type { i32, [3 x i64] }
%sollang.enum.t825 = type { i32, [10 x i64] }
%sollang.enum.t826 = type { i32, [33 x i64] }
%sollang.enum.t827 = type { i32, [35 x i64] }
%sollang.enum.t828 = type { i32, [1 x i64] }
%sollang.enum.t835 = type { i32, [8 x i64] }
%sollang.enum.t836 = type { i32, [1 x i64] }
%sollang.enum.t837 = type { i32, [2 x i64] }
%sollang.enum.t838 = type { i32, [2 x i64] }
%sollang.enum.t839 = type { i32, [2 x i64] }
%sollang.enum.t843 = type { i32, [3 x i64] }
%sollang.enum.t846 = type { i32, [2 x i64] }
%sollang.enum.t847 = type { i32, [2 x i64] }
%sollang.enum.t848 = type { i32, [2 x i64] }
%sollang.enum.t849 = type { i32, [5 x i64] }
%sollang.enum.t850 = type { i32, [11 x i64] }
%sollang.enum.t851 = type { i32, [9 x i64] }
%sollang.enum.t853 = type { i32, [3 x i64] }
%sollang.enum.t854 = type { i32, [2 x i64] }
%sollang.enum.t855 = type { i32, [2 x i64] }
%sollang.enum.t856 = type { i32, [2 x i64] }
%sollang.enum.t857 = type { i32, [2 x i64] }
%sollang.enum.t858 = type { i32, [2 x i64] }
%sollang.enum.t859 = type { i32, [2 x i64] }
%sollang.enum.t860 = type { i32, [2 x i64] }
%sollang.enum.t861 = type { i32, [2 x i64] }
%sollang.enum.t862 = type { i32, [3 x i64] }
%sollang.enum.t863 = type { i32, [4 x i64] }
%sollang.enum.t864 = type { i32, [2 x i64] }
%sollang.enum.t865 = type { i32, [3 x i64] }
%sollang.enum.t870 = type { i32, [1 x i64] }
%sollang.enum.t871 = type { i32, [4 x i64] }
%sollang.enum.t872 = type { i32, [4 x i64] }
%sollang.enum.t873 = type { i32, [2 x i64] }
%sollang.enum.t874 = type { i32, [8 x i64] }
%sollang.enum.t875 = type { i32, [2 x i64] }
%sollang.enum.t876 = type { i32, [4 x i64] }
%sollang.enum.t877 = type { i32, [2 x i64] }
%sollang.enum.t878 = type { i32, [2 x i64] }
%sollang.enum.t880 = type { i32, [3 x i64] }
%sollang.enum.t881 = type { i32, [5 x i64] }
%sollang.enum.t882 = type { i32, [10 x i64] }
%sollang.enum.t883 = type { i32, [10 x i64] }
%sollang.enum.t884 = type { i32, [11 x i64] }
%sollang.enum.t885 = type { i32, [11 x i64] }
%sollang.enum.t888 = type { i32, [7 x i64] }
%sollang.enum.t889 = type { i32, [8 x i64] }
%sollang.enum.t890 = type { i32, [7 x i64] }
%sollang.enum.t891 = type { i32, [8 x i64] }
%sollang.enum.t892 = type { i32, [2 x i64] }
%sollang.enum.t893 = type { i32, [7 x i64] }
%sollang.enum.t894 = type { i32, [7 x i64] }
%sollang.enum.t895 = type { i32, [3 x i64] }
%sollang.enum.t897 = type { i32, [2 x i64] }
%sollang.enum.t898 = type { i32, [3 x i64] }
%sollang.enum.t899 = type { i32, [2 x i64] }
%sollang.enum.t900 = type { i32, [2 x i64] }
%sollang.enum.t902 = type { i32, [2 x i64] }
%sollang.enum.t903 = type { i32, [4 x i64] }
%sollang.enum.t905 = type { i32, [3 x i64] }
%sollang.enum.t906 = type { i32, [3 x i64] }
%sollang.enum.t907 = type { i32, [13 x i64] }
%sollang.enum.t908 = type { i32, [12 x i64] }
%sollang.enum.t909 = type { i32, [4 x i64] }
%sollang.enum.t910 = type { i32, [2 x i64] }
%sollang.enum.t911 = type { i32, [2 x i64] }
%sollang.enum.t913 = type { i32, [2 x i64] }
%sollang.enum.t914 = type { i32, [5 x i64] }
%sollang.enum.t915 = type { i32, [3 x i64] }
%sollang.enum.t916 = type { i32, [15 x i64] }
%sollang.enum.t917 = type { i32, [3 x i64] }
%sollang.enum.t918 = type { i32, [2 x i64] }
%sollang.enum.t919 = type { i32, [3 x i64] }
%sollang.enum.t924 = type { i32, [2 x i64] }
%sollang.enum.t925 = type { i32, [3 x i64] }
%sollang.enum.t926 = type { i32, [3 x i64] }
%sollang.enum.t927 = type { i32, [15 x i64] }
%sollang.enum.t928 = type { i32, [25 x i64] }
%sollang.enum.t929 = type { i32, [7 x i64] }
%sollang.enum.t930 = type { i32, [5 x i64] }
%sollang.enum.t931 = type { i32, [9 x i64] }
%sollang.enum.t932 = type { i32, [31 x i64] }
%sollang.enum.t933 = type { i32, [3 x i64] }
%sollang.enum.t934 = type { i32, [8 x i64] }
%sollang.enum.t935 = type { i32, [2 x i64] }
%sollang.enum.t936 = type { i32, [12 x i64] }
%sollang.enum.t937 = type { i32, [6 x i64] }
%sollang.enum.t938 = type { i32, [2 x i64] }
%sollang.enum.t939 = type { i32, [9 x i64] }
%sollang.enum.t940 = type { i32, [6 x i64] }
%sollang.enum.t941 = type { i32, [3 x i64] }
%sollang.enum.t942 = type { i32, [26 x i64] }
%sollang.enum.t943 = type { i32, [4 x i64] }
%sollang.enum.t944 = type { i32, [5 x i64] }
%sollang.enum.t945 = type { i32, [8 x i64] }
%sollang.enum.t946 = type { i32, [40 x i64] }
%sollang.enum.t947 = type { i32, [9 x i64] }
%sollang.enum.t948 = type { i32, [3 x i64] }
%sollang.enum.t959 = type { i32, [2 x i64] }
%sollang.enum.t960 = type { i32, [2 x i64] }
%sollang.enum.t961 = type { i32, [9 x i64] }
%sollang.enum.t962 = type { i32, [21 x i64] }
%sollang.enum.t963 = type { i32, [4 x i64] }
%sollang.enum.t964 = type { i32, [9 x i64] }
%sollang.enum.t965 = type { i32, [2 x i64] }
%sollang.enum.t966 = type { i32, [5 x i64] }
%sollang.enum.t967 = type { i32, [2 x i64] }
%sollang.enum.t968 = type { i32, [14 x i64] }
%sollang.enum.t970 = type { i32, [11 x i64] }
%sollang.enum.t971 = type { i32, [16 x i64] }
%sollang.enum.t972 = type { i32, [7 x i64] }
%sollang.enum.t975 = type { i32, [7 x i64] }
%sollang.enum.t976 = type { i32, [4 x i64] }
%sollang.enum.t977 = type { i32, [6 x i64] }
%sollang.enum.t978 = type { i32, [7 x i64] }
%sollang.enum.t979 = type { i32, [6 x i64] }
%sollang.enum.t980 = type { i32, [5 x i64] }
%sollang.enum.t981 = type { i32, [2 x i64] }
%sollang.enum.t982 = type { i32, [4 x i64] }
%sollang.enum.t983 = type { i32, [10 x i64] }
%sollang.enum.t984 = type { i32, [131 x i64] }
%sollang.enum.t985 = type { i32, [2 x i64] }
%sollang.enum.t986 = type { i32, [16 x i64] }
%sollang.enum.t987 = type { i32, [7 x i64] }
%sollang.enum.t988 = type { i32, [10 x i64] }
%sollang.enum.t990 = type { i32, [5 x i64] }
%sollang.enum.t992 = type { i32, [2 x i64] }
%sollang.enum.t993 = type { i32, [17 x i64] }
%sollang.enum.t994 = type { i32, [2 x i64] }
%sollang.enum.t995 = type { i32, [2 x i64] }
%sollang.enum.t996 = type { i32, [3 x i64] }
%sollang.enum.t998 = type { i32, [10 x i64] }
%sollang.enum.t999 = type { i32, [5 x i64] }
%sollang.enum.t1000 = type { i32, [3 x i64] }
%sollang.enum.t1001 = type { i32, [8 x i64] }
%sollang.enum.t1003 = type { i32, [2 x i64] }
%sollang.enum.t1004 = type { i32, [4 x i64] }
%sollang.enum.t1006 = type { i32, [2 x i64] }
%sollang.enum.t1007 = type { i32, [9 x i64] }
%sollang.enum.t1008 = type { i32, [3 x i64] }
%sollang.enum.t1009 = type { i32, [7 x i64] }
%sollang.enum.t1010 = type { i32, [11 x i64] }
%sollang.enum.t1011 = type { i32, [7 x i64] }
%sollang.enum.t1015 = type { i32, [6 x i64] }
%sollang.enum.t1017 = type { i32, [11 x i64] }
%sollang.enum.t1018 = type { i32, [18 x i64] }
%sollang.enum.t1020 = type { i32, [149 x i64] }
%sollang.enum.t1021 = type { i32, [3 x i64] }
%sollang.enum.t1022 = type { i32, [2 x i64] }
%sollang.enum.t1023 = type { i32, [2 x i64] }
%sollang.enum.t1024 = type { i32, [2 x i64] }
%sollang.enum.t1026 = type { i32, [12 x i64] }
%sollang.enum.t1027 = type { i32, [9 x i64] }
%sollang.enum.t1028 = type { i32, [5 x i64] }
%sollang.enum.t1029 = type { i32, [5 x i64] }
%sollang.enum.t1030 = type { i32, [6 x i64] }
%sollang.enum.t1031 = type { i32, [6 x i64] }
%sollang.enum.t1032 = type { i32, [2 x i64] }
%sollang.enum.t1034 = type { i32, [14 x i64] }
%sollang.enum.t1037 = type { i32, [6 x i64] }
%sollang.enum.t1038 = type { i32, [6 x i64] }
%sollang.enum.t1040 = type { i32, [4 x i64] }
%sollang.enum.t1041 = type { i32, [5 x i64] }
%sollang.enum.t1042 = type { i32, [4 x i64] }
%sollang.enum.t1043 = type { i32, [21 x i64] }
%sollang.enum.t1044 = type { i32, [4 x i64] }
%sollang.enum.t1045 = type { i32, [5 x i64] }
%sollang.enum.t1046 = type { i32, [2 x i64] }
%sollang.enum.t1048 = type { i32, [3 x i64] }
%sollang.enum.t1049 = type { i32, [4 x i64] }
%sollang.enum.t1050 = type { i32, [2 x i64] }
%sollang.enum.t1051 = type { i32, [6 x i64] }
%sollang.enum.t1052 = type { i32, [5 x i64] }
%sollang.enum.t1053 = type { i32, [5 x i64] }
%sollang.enum.t1056 = type { i32, [16 x i64] }
%sollang.enum.t1057 = type { i32, [7 x i64] }
%sollang.enum.t1058 = type { i32, [6 x i64] }
%sollang.enum.t1059 = type { i32, [4 x i64] }
%sollang.enum.t1060 = type { i32, [5 x i64] }
%sollang.enum.t1061 = type { i32, [2 x i64] }
%sollang.enum.t1062 = type { i32, [2 x i64] }
%sollang.enum.t1064 = type { i32, [4 x i64] }
%sollang.enum.t1066 = type { i32, [9 x i64] }
%sollang.enum.t1067 = type { i32, [4 x i64] }
%sollang.enum.t1071 = type { i32, [1 x i64] }
%sollang.enum.t1072 = type { i32, [2 x i64] }
%sollang.enum.t1073 = type { i32, [3 x i64] }
%sollang.enum.t1074 = type { i32, [17 x i64] }
%sollang.enum.t1076 = type { i32, [2 x i64] }
%sollang.enum.t1077 = type { i32, [3 x i64] }
%sollang.enum.t1078 = type { i32, [12 x i64] }
%sollang.enum.t1079 = type { i32, [3 x i64] }
%sollang.enum.t1080 = type { i32, [4 x i64] }
%sollang.enum.t1094 = type { i32, [12 x i64] }
%sollang.enum.t1095 = type { i32, [4 x i64] }
%sollang.enum.t1096 = type { i32, [3 x i64] }
%sollang.enum.t1097 = type { i32, [3 x i64] }
%sollang.enum.t1098 = type { i32, [4 x i64] }
%sollang.enum.t1099 = type { i32, [2 x i64] }
%sollang.enum.t1101 = type { i32, [3 x i64] }
%sollang.enum.t1102 = type { i32, [6 x i64] }
%sollang.enum.t1103 = type { i32, [3 x i64] }
%sollang.enum.t1106 = type { i32, [2 x i64] }
%sollang.enum.t1107 = type { i32, [2 x i64] }
%sollang.enum.t1108 = type { i32, [2 x i64] }
%sollang.enum.t1109 = type { i32, [2 x i64] }
%sollang.enum.t1110 = type { i32, [2 x i64] }
%sollang.enum.t1111 = type { i32, [12 x i64] }
%sollang.enum.t1112 = type { i32, [6 x i64] }
%sollang.enum.t1113 = type { i32, [3 x i64] }
%sollang.enum.t1114 = type { i32, [2 x i64] }
%sollang.enum.t1115 = type { i32, [8 x i64] }
%sollang.enum.t1117 = type { i32, [2 x i64] }
%sollang.enum.t1118 = type { i32, [4 x i64] }
%sollang.enum.t1121 = type { i32, [3 x i64] }
%sollang.enum.t1122 = type { i32, [4 x i64] }
%sollang.enum.t1123 = type { i32, [4 x i64] }
%sollang.enum.t1124 = type { i32, [7 x i64] }
%sollang.enum.t1125 = type { i32, [4 x i64] }
%sollang.enum.t1127 = type { i32, [9 x i64] }
%sollang.enum.t1128 = type { i32, [2 x i64] }
%sollang.enum.t1129 = type { i32, [4 x i64] }
%sollang.enum.t1130 = type { i32, [1 x i64] }
%sollang.enum.t1131 = type { i32, [1 x i64] }
%sollang.enum.t1132 = type { i32, [2 x i64] }
%sollang.enum.t1133 = type { i32, [2 x i64] }
%sollang.enum.t1134 = type { i32, [2 x i64] }
%sollang.enum.t1135 = type { i32, [6 x i64] }
%sollang.enum.t1136 = type { i32, [1 x i64] }
%sollang.enum.t1137 = type { i32, [1 x i64] }
%sollang.enum.t1138 = type { i32, [1 x i64] }
%sollang.enum.t1139 = type { i32, [1 x i64] }
%sollang.enum.t1140 = type { i32, [11 x i64] }
%sollang.enum.t1141 = type { i32, [29 x i64] }
%sollang.enum.t1142 = type { i32, [12 x i64] }
%sollang.enum.t1143 = type { i32, [2 x i64] }
%sollang.enum.t1144 = type { i32, [2 x i64] }
%sollang.enum.t1146 = type { i32, [3 x i64] }
%sollang.enum.t1147 = type { i32, [2 x i64] }
%sollang.enum.t1148 = type { i32, [3 x i64] }
%sollang.enum.t1149 = type { i32, [2 x i64] }
%sollang.enum.t1150 = type { i32, [1 x i64] }
%sollang.enum.t1151 = type { i32, [1 x i64] }
%sollang.enum.t1158 = type { i32, [2 x i64] }
%sollang.enum.t1159 = type { i32, [2 x i64] }
%sollang.enum.t1160 = type { i32, [2 x i64] }
%sollang.enum.t1161 = type { i32, [0 x i64] }
%sollang.enum.t1162 = type { i32, [0 x i64] }
%sollang.enum.t1163 = type { i32, [2 x i64] }
%sollang.enum.t1164 = type { i32, [2 x i64] }
%sollang.enum.t1165 = type { i32, [2 x i64] }
%sollang.enum.t1166 = type { i32, [7 x i64] }
%sollang.enum.t1167 = type { i32, [4 x i64] }
%sollang.enum.t1168 = type { i32, [2 x i64] }
%sollang.enum.t1171 = type { i32, [2 x i64] }
%sollang.enum.t1173 = type { i32, [3 x i64] }
%sollang.enum.t1184 = type { i32, [0 x i64] }
%sollang.enum.t1185 = type { i32, [3 x i64] }
%sollang.enum.t1186 = type { i32, [6 x i64] }
%sollang.enum.t1187 = type { i32, [2 x i64] }
%sollang.enum.t1188 = type { i32, [3 x i64] }
%sollang.enum.t1189 = type { i32, [8 x i64] }
%sollang.enum.t1190 = type { i32, [2 x i64] }
%sollang.enum.t1191 = type { i32, [1 x i64] }
%sollang.enum.t1192 = type { i32, [2 x i64] }
%sollang.enum.t1193 = type { i32, [3 x i64] }
%sollang.enum.t1194 = type { i32, [2 x i64] }
%sollang.enum.t1196 = type { i32, [2 x i64] }
%sollang.enum.t1197 = type { i32, [4 x i64] }
%sollang.enum.t1198 = type { i32, [3 x i64] }
%sollang.enum.t1199 = type { i32, [18 x i64] }
%sollang.enum.t1200 = type { i32, [3 x i64] }
%sollang.enum.t1201 = type { i32, [16 x i64] }
%sollang.enum.t1202 = type { i32, [2 x i64] }
%sollang.enum.t1203 = type { i32, [2 x i64] }
%sollang.enum.t1204 = type { i32, [2 x i64] }
%sollang.enum.t1206 = type { i32, [1 x i64] }
%sollang.enum.t1207 = type { i32, [2 x i64] }
%sollang.enum.t1208 = type { i32, [2 x i64] }
%sollang.enum.t1209 = type { i32, [5 x i64] }
%sollang.enum.t1210 = type { i32, [2 x i64] }
%sollang.enum.t1213 = type { i32, [9 x i64] }
%sollang.enum.t1214 = type { i32, [7 x i64] }
%sollang.enum.t1215 = type { i32, [3 x i64] }
%sollang.enum.t1216 = type { i32, [2 x i64] }
%sollang.enum.t1217 = type { i32, [1 x i64] }
%sollang.struct.x0D7374642E616C676F726974686D010301084F72646572696E6700 = type { %sollang.enum.t464 }
%sollang.struct.x0D7374642E616C676F726974686D0103010A416C676F726974686D7300 = type {  }
%sollang.struct.x0D7374642E616C676F726974686D0103010C536561726368526573756C7400 = type { i32, i1 }
%sollang.struct.x0D7374642E616C676F726974686D0103010A457175616C52616E676500 = type { i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A6970010301054572726F7200 = type { %sollang.enum.t470, i64 }
%sollang.struct.x0F7374642E617263686976652E7A6970010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A697001030105436F64656300 = type { %sollang.struct.x0F7374642E617263686976652E7A6970010301064C696D69747300 }
%sollang.struct.x0F7374642E617263686976652E7A69700103010D4465666C6174654C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A6970010301074465636F64657200 = type { %sollang.struct.x0F7374642E617263686976652E7A6970010301064C696D69747300, %sollang.enum.t468, i32, %sollang.array.i32, %sollang.array.i32, i32, i32, i32, %sollang.array.i32, i32, i32, i32, i32, %sollang.array.i32, i1, %sollang.struct.x0F7374642E617263686976652E7A69700103010D4465666C6174654C696D69747300, i32, %sollang.struct.x0E7374642E686173682E63726333320103010648617368657200, %sollang.array.i32, %sollang.array.i32, i32, i32, i32, %sollang.array.i32, i32, i32, %sollang.array.i32, i32, i1, %sollang.struct.x0F7374642E617263686976652E7A6970010301054572726F7200 }
%sollang.struct.x0F7374642E617263686976652E7A69700103010C5772697465724C696D69747300 = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A69700103010657726974657200 = type { %sollang.struct.x0F7374642E617263686976652E7A69700103010C5772697465724C696D69747300, %sollang.enum.t469, i32, i32, i32, i32, i32, i32, %sollang.struct.x0E7374642E686173682E63726333320103010648617368657200, %sollang.array.i32 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030110446961676E6F737469634C696D69747300 = type { i32 }
%sollang.struct.x157374642E6173796E632E646961676E6F73746963730103011153757370656E73696F6E4C6F6361746F7200 = type { %sollang.text, %sollang.text, i32, i64, i32, i32 }
%sollang.struct.x157374642E6173796E632E646961676E6F73746963730103010C5461736B536E617073686F7400 = type { i64, %sollang.enum.t681, %sollang.enum.t471, %sollang.enum.t472, %sollang.enum.t681, i64, %sollang.enum.t682 }
%sollang.struct.x157374642E6173796E632E646961676E6F73746963730103010E536E617073686F74526573756C7400 = type { i64, i64, i64, i1 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030111446961676E6F7374696353756D6D61727900 = type { i64, i64, i64 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030111446961676E6F7374696353657373696F6E00 = type { i64 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030116446961676E6F73746963436C6F73654661696C75726500 = type { %sollang.struct.x157374642E6173796E632E646961676E6F737469637301030111446961676E6F7374696353657373696F6E00, %sollang.enum.t475 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301054572726F7200 = type { %sollang.enum.t502, i64 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C6901030105436F64656300 = type { %sollang.struct.x137374642E636F6D70726573732E62726F746C69010301064C696D69747300 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C6901030107456E636F64657200 = type { i32, i32, i32, i32, i32, i32, i1 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301074465636F64657200 = type { i32, i32, i32, i32, i32, i32, %sollang.enum.t501, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010657696E646F7700, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010652656164657200, i32, i1, i32, i32, i32, %sollang.array.i32, i1, %sollang.struct.x137374642E636F6D70726573732E62726F746C69010301054572726F7200 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C690103010942697457726974657200 = type { i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C690103010942697452656164657200 = type { i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C690103010C53747265616D437572736F7200 = type { i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301074269745265616400 = type { i1, i64 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301054572726F7200 = type { %sollang.enum.t479, i64 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301084578656375746F7200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273656400, i32, i32, i32, i32 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301074465636F64656400 = type { %sollang.array.i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E640103010652656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273656400, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301085265736F6C76657200, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32, i32, %sollang.enum.t476, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.t476 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E640103010853747265616D656400 = type { %sollang.array.i32 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301054572726F7200 = type { %sollang.enum.t492, i64 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301064C696D69747300 = type { i32, i32, i32, i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010650617273657200, %sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010650617273657200, i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D5072656C75646552656164657200 = type { %sollang.enum.t480, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.t503, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301075072656C75646500 = type { i32, i32, i32, i32, i32, %sollang.enum.t503, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F68656164657201030111426C6F636B53747265616D52656164657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, %sollang.enum.t483, i32, i32, i32, i32, %sollang.enum.t482, %sollang.enum.t482 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010C48656164657252656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F68656164657201030111426C6F636B53747265616D52656164657200, %sollang.enum.t485, i32, %sollang.array.i32, i32, i32, %sollang.array.i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D4865616465725072656C75646500 = type { %sollang.array.i32, i32, i32, i32, %sollang.array.i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D436F6E7465787452656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D4865616465725072656C75646500, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010652656164657200, %sollang.enum.t487, %sollang.array.i32, %sollang.array.i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010E436F6E746578745072656C75646500 = type { %sollang.array.i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010A5472656552656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010E436F6E746578745072656C75646500, %sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010652656164657200, %sollang.enum.t489, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010B426C6F636B53747265616D00 = type { i32, i32, %sollang.enum.t482, %sollang.enum.t482 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010B426C6F636B53776974636800 = type { i32, i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273656400 = type { %sollang.array.i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F68656164657201030111506172736564426C6F636B53747265616D00 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010B426C6F636B53747265616D00, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D010301054572726F7200 = type { %sollang.enum.t502, i64 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010C48656164657250726566697800 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010C48656164657252656164657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010D436F6E7465787450726566697800 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D436F6E7465787452656164657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010A5472656550726566697800 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010A5472656552656164657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010652656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D010301064C696D69747300, i32, %sollang.array.i32, %sollang.enum.t493 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D6170010301054572726F7200 = type { %sollang.enum.t500, i64 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D6170010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010650617273657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010650617273656400 = type { %sollang.array.i32, i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010652656164657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, i32, %sollang.enum.t496, i32, i32, i32, %sollang.array.i32, %sollang.enum.t497 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010853747265616D656400 = type { %sollang.array.i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D6170010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301054572726F7200 = type { %sollang.enum.t509, i64 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301064C696D69747300 = type { i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200 = type { %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074275696C64657200, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273656400 = type { %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301055461626C6500, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301154669786564436F64654C656E67746852656164657200 = type { %sollang.enum.t504, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 = type { %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074275696C64657200, i32, i32, i32, %sollang.enum.t506, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301154669786564436F64654C656E67746852656164657200, %sollang.array.i32, i32, i32, i32, %sollang.enum.t507, i32, i32, i32, i32, i32, i32, %sollang.enum.t507 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301054572726F7200 = type { %sollang.enum.t512, i64 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301064C696D69747300 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074275696C64657200 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301055461626C6500 = type { %sollang.array.i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074465636F64656400 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010650726F62656400 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010C57696E646F774C696D69747300 = type { i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010657696E646F7700 = type { i64, i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301065065656B656400 = type { i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301054572726F7200 = type { %sollang.enum.t514, i64 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301064C696D69747300 = type { i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301085265736F6C76657200 = type { i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E6172790103010A44657363726970746F7200 = type { i32, %sollang.enum.t513, i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F7570010301054572726F7200 = type { %sollang.enum.t516, i64 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F7570010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010650617273657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010650617273656400 = type { %sollang.array.i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010652656164657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.array.i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010853747265616D656400 = type { %sollang.array.i32 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301054572726F7200 = type { %sollang.enum.t518, i64 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301064C696D69747300 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030105436F64656300 = type { %sollang.struct.x117374642E636F6D70726573732E677A6970010301064C696D69747300 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010D4465636F6465724C696D69747300 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030107456E636F64657200 = type { i32, i32, i32, i32, i1, i1, %sollang.struct.x117374642E636F6D70726573732E677A69700103010942697457726974657200 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301074465636F64657200 = type { %sollang.struct.x117374642E636F6D70726573732E677A697001030105436F64656300, i32, i32, i32, i32, i32, i32, %sollang.enum.t517, i32, i32, i32, i32, i32, i32, i32, i1, i32, i32, i32, i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, i32, i32, i32, i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, i32, i1, %sollang.struct.x117374642E636F6D70726573732E677A6970010301054572726F7200, i1, i1 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301115261774465666C6174654465636F64657200 = type { %sollang.struct.x117374642E636F6D70726573732E677A6970010301074465636F64657200 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A456E636F6465506C616E00 = type { i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A4465636F6465506C616E00 = type { i32, i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030109426974437572736F7200 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010942697457726974657200 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010B4465666C617465436F646500 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A4C656E677468436F646500 = type { i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C44697374616E6365436F646500 = type { i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301054D6174636800 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00 = type { %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010B487566666D616E5061697200 = type { %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C496E666C617465537461746500 = type { %sollang.struct.x117374642E636F6D70726573732E677A697001030109426974437572736F7200, i32, %sollang.array.i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C4D656D6265724465636F646500 = type { i32, %sollang.array.i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C496E666C617465436F756E7400 = type { i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C53747265616D437572736F7200 = type { i32 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301074269745265616400 = type { i1, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A55496E7433325265616400 = type { i1, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A53796D626F6C5265616400 = type { i1, i32 }
%sollang.struct.x117374642E636F6D70726573732E7A737464010301054572726F7200 = type { %sollang.enum.t520, i64 }
%sollang.struct.x117374642E636F6D70726573732E7A7374640103010F436F6D70726573736564426C6F636B00 = type { %sollang.array.i32, %sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500, i1, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E7A737464010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E7A7374640103010C4672616D654F7074696F6E7300 = type { i1 }
%sollang.struct.x117374642E636F6D70726573732E7A73746401030105436F64656300 = type { %sollang.struct.x117374642E636F6D70726573732E7A737464010301064C696D69747300, %sollang.struct.x117374642E636F6D70726573732E7A7374640103010C4672616D654F7074696F6E7300 }
%sollang.struct.x117374642E636F6D70726573732E7A73746401030107456E636F64657200 = type { i32, i32, i32, i32, i1, i1, %sollang.struct.x117374642E686173682E78786861736836340103010648617368657200 }
%sollang.struct.x117374642E636F6D70726573732E7A737464010301074465636F64657200 = type { i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.t519, i64, i32, i32, i32, i32, i32, i1, i64, i1, %sollang.struct.x117374642E686173682E78786861736836340103010648617368657200, i32, i32, i32, i32, i1, %sollang.array.i32, %sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500, i1, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32, %sollang.array.i32, i1, %sollang.struct.x117374642E636F6D70726573732E7A737464010301054572726F7200 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500 = type { %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E6673650103010B4465736372697074696F6E00 = type { %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i32 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E6673650103010B466F72776172644269747300 = type { i32 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E6673650103010B526576657273654269747300 = type { i32, i32, i32 }
%sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500 = type { %sollang.array.i32, i32 }
%sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E0103010B4465736372697074696F6E00 = type { %sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E636501030106437572736F7200 = type { i32, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E636501030108507265706172656400 = type { %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E63650103010D526563656E744F66667365747300 = type { i32, i32, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E6365010301074465636F64656400 = type { %sollang.array.i32, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32 }
%sollang.struct.x117374642E63727970746F2E616573313238010301034B657900 = type { %sollang.array.i32 }
%sollang.struct.x117374642E63727970746F2E6165733132380103010A426C6F636B56616C756500 = type { %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E6165733132385F67636D010301065365616C656400 = type { %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E6165733132385F67636D010301034B657900 = type { %sollang.struct.x117374642E63727970746F2E616573313238010301034B657900, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E6165733132385F67636D0103010A426C6F636B56616C756500 = type { %sollang.int_slice }
%sollang.struct.x127374642E63727970746F2E65643235353139010301054572726F7200 = type { %sollang.enum.t526 }
%sollang.struct.x127374642E63727970746F2E6564323535313901030105506F696E7400 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x167374642E63727970746F2E686D61635F7368613235360103010648617368657200 = type { %sollang.struct.x117374642E63727970746F2E7368613235360103010648617368657200, %sollang.struct.x117374642E63727970746F2E7368613235360103010648617368657200 }
%sollang.struct.x117374642E63727970746F2E72616E646F6D0103010C53656375726552616E646F6D00 = type { i8 }
%sollang.struct.x117374642E63727970746F2E7368613235360103010648617368657200 = type { %sollang.int_slice, %sollang.int_slice, i32, i64 }
%sollang.struct.x157374642E63727970746F2E746C7331335F6B6579730103011048616E647368616B655365637265747300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E746C7331335F6B6579730103010C4561726C795365637265747300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E746C7331335F6B657973010301124170706C69636174696F6E5365637265747300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x137374642E656E636F64696E672E626173653634010301054572726F7200 = type { %sollang.enum.t528, i64 }
%sollang.struct.x137374642E656E636F64696E672E6261736536340103010A456E636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x137374642E656E636F64696E672E6261736536340103010A4465636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x137374642E656E636F64696E672E62617365363401030105436F64656300 = type { %sollang.enum.t529, %sollang.enum.t530 }
%sollang.struct.x137374642E656E636F64696E672E62617365363401030107456E636F64657200 = type { %sollang.struct.x137374642E656E636F64696E672E62617365363401030105436F64656300, i32, i32, i64, i8, i8, i32 }
%sollang.struct.x137374642E656E636F64696E672E626173653634010301074465636F64657200 = type { %sollang.struct.x137374642E656E636F64696E672E62617365363401030105436F64656300, i32, i32, i64, i32, i32, i32, i32, i64, i64, i64, i64, i32, i1 }
%sollang.struct.x137374642E656E636F64696E672E6261736536340103010F4465636F64655772697465506C616E00 = type { i32, i32, i64, i32, i32, i32, i32, i64, i64, i64, i64, i32, i1 }
%sollang.struct.x137374642E656E636F64696E672E62696E617279010301054572726F7200 = type { %sollang.enum.t532, i64 }
%sollang.struct.x137374642E656E636F64696E672E62696E6172790103010652656164657200 = type { %sollang.enum.t531, i64 }
%sollang.struct.x137374642E656E636F64696E672E62696E6172790103010657726974657200 = type { %sollang.enum.t531, i32, i32 }
%sollang.struct.x107374642E656E636F64696E672E686578010301054572726F7200 = type { %sollang.enum.t533, i64 }
%sollang.struct.x107374642E656E636F64696E672E6865780103010A456E636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x107374642E656E636F64696E672E6865780103010A4465636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x107374642E656E636F64696E672E68657801030105436F64656300 = type { i1 }
%sollang.struct.x107374642E656E636F64696E672E68657801030107456E636F64657200 = type { %sollang.struct.x107374642E656E636F64696E672E68657801030105436F64656300, i32, i32, i64 }
%sollang.struct.x107374642E656E636F64696E672E686578010301074465636F64657200 = type { i32, i32, i64, i32, i64 }
%sollang.struct.x0E7374642E686173682E63726333320103010648617368657200 = type { %sollang.enum.t534, i32 }
%sollang.struct.x117374642E686173682E7878686173683634010301045365656400 = type { i64 }
%sollang.struct.x117374642E686173682E78786861736836340103010648617368657200 = type { i64, i64, i64, i64, i64, i64, i64, %sollang.int_slice, i32 }
%sollang.struct.x067374642E696F010301054572726F7200 = type { %sollang.enum.t535, i64 }
%sollang.struct.x067374642E696F0103010B436F70794F7574636F6D6500 = type { i32, %sollang.enum.t537 }
%sollang.struct.x067374642E696F0103010E5472616E73666572506F6C69637900 = type { i32, i32 }
%sollang.struct.x067374642E696F0103010C5265706C617942756666657200 = type { %sollang.array.i32, i32, %sollang.array.i32, i32, i32 }
%sollang.struct.x067374642E696F0103010C4D656D6F727952656164657200 = type { %sollang.array.i32, i32, i32 }
%sollang.struct.x067374642E696F0103010C4D656D6F727957726974657200 = type { %sollang.array.i32, i32 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C43616E63656C6C6174696F6E00 = type { i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010B526561645375636365737300 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727952656164657200, %sollang.array.i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010B526561644661696C75726500 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727952656164657200, %sollang.array.i32, %sollang.enum.t538 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C57726974655375636365737300 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727957726974657200, %sollang.array.i32, i32 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C57726974654661696C75726500 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727957726974657200, %sollang.array.i32, %sollang.enum.t538 }
%sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500 = type { %sollang.array.i32, i32, i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C4F666665725375636365737300 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C4F666665724661696C75726500 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, %sollang.enum.t538 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C447261696E5375636365737300 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C447261696E4661696C75726500 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, %sollang.enum.t538 }
%sollang.struct.x0B7374642E696F2E66696C650103010A4279746552656164657200 = type { %sollang.struct.x087379732E66696C650103010446696C6500, i64 }
%sollang.struct.x0B7374642E696F2E66696C650103010A4279746557726974657200 = type { %sollang.struct.x087379732E66696C650103010A46696C6557726974657200, i64 }
%sollang.struct.x0B7374642E696F2E66696C65010301104173796E63526561645375636365737300 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746552656164657200, %sollang.array.i32, i32, i1 }
%sollang.struct.x0B7374642E696F2E66696C65010301104173796E63526561644661696C75726500 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746552656164657200, %sollang.array.i32, %sollang.enum.t599 }
%sollang.struct.x0B7374642E696F2E66696C65010301114173796E6357726974655375636365737300 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746557726974657200, %sollang.array.i32, i32 }
%sollang.struct.x0B7374642E696F2E66696C65010301114173796E6357726974654661696C75726500 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746557726974657200, %sollang.array.i32, %sollang.enum.t599 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, i64 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010D4372656174654661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010B526561645375636365737300 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, i64, i1 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010B526561644661696C75726500 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010C57726974655375636365737300 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, i64 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010C57726974654661696C75726500 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x077374642E6C6F67010301054669656C6400 = type { %sollang.text, %sollang.text }
%sollang.struct.x077374642E6C6F67010301054572726F7200 = type { %sollang.text }
%sollang.struct.x077374642E6C6F67010301065265636F726400 = type { %sollang.enum.t539, %sollang.text }
%sollang.struct.x077374642E6C6F67010301064C6F6767657200 = type { %sollang.enum.t539 }
%sollang.struct.x077374642E6E65740103010B497076344164647265737300 = type { i8, i8, i8, i8 }
%sollang.struct.x077374642E6E65740103010C49707634456E64706F696E7400 = type { %sollang.struct.x077374642E6E65740103010B497076344164647265737300, i16 }
%sollang.struct.x077374642E6E65740103010B497076364164647265737300 = type { i16, i16, i16, i16, i16, i16, i16, i16 }
%sollang.struct.x077374642E6E65740103010C49707636456E64706F696E7400 = type { %sollang.struct.x077374642E6E65740103010B497076364164647265737300, i16, i32, i32 }
%sollang.struct.x077374642E6E65740103010A50617273654572726F7200 = type { %sollang.enum.t558, i64 }
%sollang.struct.x0B7374642E6E65742E646E73010301054572726F7200 = type { %sollang.enum.t543, i32 }
%sollang.struct.x0B7374642E6E65742E646E73010301085265736F6C76657200 = type { %sollang.enum.t542, i64, i64 }
%sollang.struct.x0C7374642E6E65742E68747470010301054572726F7200 = type { %sollang.enum.t550, i64 }
%sollang.struct.x0C7374642E6E65742E68747470010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x0C7374642E6E65742E68747470010301045370616E00 = type { i64, i64 }
%sollang.struct.x0C7374642E6E65742E68747470010301054669656C6400 = type { %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00 }
%sollang.struct.x0C7374642E6E65742E687474700103010650617273657200 = type { %sollang.struct.x0C7374642E6E65742E68747470010301064C696D69747300 }
%sollang.struct.x0C7374642E6E65742E687474700103010B526571756573744865616400 = type { %sollang.source_text, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.enum.t544, %sollang.array.i32, i64 }
%sollang.struct.x0C7374642E6E65742E687474700103010C526573706F6E73654865616400 = type { %sollang.source_text, %sollang.enum.t544, i32, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.array.i32, i64 }
%sollang.struct.x0C7374642E6E65742E687474700103010C5061727365644669656C647300 = type { %sollang.array.i32, i64 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900 = type { %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300 }
%sollang.struct.x117374642E6E65742E687474702E626F647901030113526573706F6E7365426F6479436F6E7465787400 = type { %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, %sollang.text }
%sollang.struct.x117374642E6E65742E687474702E626F647901030108426F6479506C616E00 = type { %sollang.enum.t545, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010C426F647950726F677265737300 = type { i64, i64, i1 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010B426F64794465636F64657200 = type { %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300, %sollang.enum.t546, %sollang.enum.t547, i64, i64, i64, i64, %sollang.array.i32, i1, i64, i32 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010D4865616465724672616D696E6700 = type { i1, i64, i1, i1 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E740103010D436C69656E744F7074696F6E7300 = type { %sollang.enum.t541, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E7401030106436C69656E7400 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E740103010845786368616E676500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32, %sollang.enum.t553, %sollang.enum.t552 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E7401030108526573706F6E736500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32, %sollang.enum.t553, %sollang.enum.t552, %sollang.array.i32, %sollang.struct.x0C7374642E6E65742E687474700103010C526573706F6E73654865616400, i64 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E740103010C526573706F6E7365426F647900 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32, %sollang.array.i32, i64, %sollang.array.i32, i64, %sollang.struct.x117374642E6E65742E687474702E626F64790103010B426F64794465636F64657200, i1, i1, i1 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010D526571756573744C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010D52657175657374506F6C69637900 = type { %sollang.struct.x147374642E6E65742E687474702E726571756573740103010D526571756573744C696D69747300 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010D5265717565737457726974657200 = type { %sollang.struct.x147374642E6E65742E687474702E726571756573740103010D526571756573744C696D69747300, %sollang.array.i32, %sollang.text, i32, i32, i1, i1, i1, i64, %sollang.enum.t552, %sollang.enum.t553 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010B526571756573744865616400 = type { %sollang.array.i32, i64, %sollang.enum.t552, %sollang.enum.t553 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E73654C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E7365506F6C69637900 = type { %sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E73654C696D69747300 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E736557726974657200 = type { %sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E73654C696D69747300, %sollang.array.i32, i32, i32, i1, i1, i1, i64, %sollang.enum.t555 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010C526573706F6E73654865616400 = type { %sollang.array.i32, i64, %sollang.enum.t555, %sollang.enum.t554 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010D5365727665724F7074696F6E7300 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4C697374656E4F7074696F6E7300, %sollang.struct.x0C7374642E6E65742E68747470010301064C696D69747300 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010653657276657200 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010B5463704C697374656E657200, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010A436F6E6E656374696F6E00 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32, %sollang.array.i32, i64 }
%sollang.struct.x137374642E6E65742E687474702E736572766572010301075265717565737400 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32, %sollang.array.i32, %sollang.struct.x0C7374642E6E65742E687474700103010B526571756573744865616400, i64, %sollang.array.i32, i64, i1 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010B52657175657374426F647900 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32, %sollang.array.i32, %sollang.struct.x0C7374642E6E65742E687474700103010B526571756573744865616400, i64, %sollang.array.i32, i64, %sollang.struct.x117374642E6E65742E687474702E626F64790103010B426F64794465636F64657200 }
%sollang.struct.x0C7374642E6E65742E7175696301030109517569634572726F7200 = type { %sollang.enum.t559, i64 }
%sollang.struct.x0C7374642E6E65742E71756963010301084964656E7469747900 = type { %sollang.int_slice }
%sollang.struct.x0C7374642E6E65742E7175696301030108456E64706F696E7400 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030109556470536F636B657400, %sollang.enum.t541, i1, %sollang.array.i32, %sollang.array.i32, i64 }
%sollang.struct.x0C7374642E6E65742E71756963010301125265636569766557696E646F7753697A657300 = type { i64, i64, i64, i64 }
%sollang.struct.x0C7374642E6E65742E7175696301030111436F6E6E656374696F6E4F7074696F6E7300 = type { i64, i64, i32, i32, i32, i64, %sollang.struct.x0C7374642E6E65742E71756963010301125265636569766557696E646F7753697A657300 }
%sollang.struct.x0C7374642E6E65742E71756963010301084C697374656E657200 = type { %sollang.struct.x0C7374642E6E65742E71756963010301084964656E7469747900, %sollang.enum.t541, %sollang.struct.x0C7374642E6E65742E7175696301030111436F6E6E656374696F6E4F7074696F6E7300, i1 }
%sollang.struct.x0C7374642E6E65742E717569630103010A436F6E6E656374696F6E00 = type { %sollang.array.i32, %sollang.enum.t541, %sollang.enum.t541, i1, i32, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301084B6579537461746500, %sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301084B6579537461746500, i64, i64, i1, %sollang.int_slice, %sollang.array.i32, %sollang.int_slice, %sollang.array.i32, i1, i1, %sollang.array.i32, %sollang.struct.x177374642E6E65742E717569632E7265617373656D626C7901030105517565756500, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i64, i32, i64, i1, i1, %sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F76657279010301074A6F75726E616C00, %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F7665727901030108527474537461746500, %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F766572790103010F436F6E67657374696F6E537461746500, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E436F6E6E656374696F6E466C6F7700, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E53747265616D526567697374727900, i64, i64, i64, i64, i64, i64, i8, i64, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103010D53656E64446972656374696F6E00 = type { %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010853656E64466C6F7700, i1, i1, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103011052656365697665446972656374696F6E00 = type { %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010B52656365697665466C6F7700, i1, i1, i64, i1, i64 }
%sollang.struct.x0C7374642E6E65742E7175696301030108426953747265616D00 = type { i64, %sollang.struct.x0C7374642E6E65742E717569630103010D53656E64446972656374696F6E00, %sollang.struct.x0C7374642E6E65742E717569630103011052656365697665446972656374696F6E00 }
%sollang.struct.x0C7374642E6E65742E717569630103010A53656E6453747265616D00 = type { i64, %sollang.struct.x0C7374642E6E65742E717569630103010D53656E64446972656374696F6E00 }
%sollang.struct.x0C7374642E6E65742E717569630103010D5265636569766553747265616D00 = type { i64, %sollang.struct.x0C7374642E6E65742E717569630103011052656365697665446972656374696F6E00 }
%sollang.struct.x0C7374642E6E65742E7175696301030105526F75746500 = type { i64, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103010B5061636B6574526F75746500 = type { i64, i8 }
%sollang.struct.x0C7374642E6E65742E717569630103010D506565725472616E73706F727400 = type { i64, i64, i64, i64, i64, i64, i64, i8, i64, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103011048616E647368616B654D65737361676500 = type { %sollang.array.i32, i64 }
%sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301084B6579537461746500 = type { i1, i32, %sollang.int_slice, %sollang.struct.x197374642E6E65742E717569632E747261666669635F6B657973010301044B65797300 }
%sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301064F70656E656400 = type { i64, i1, %sollang.enum.t560 }
%sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E650103010A4F70656E65644D616E7900 = type { i64, i1, %sollang.array.i32 }
%sollang.struct.x1D7374642E6E65742E717569632E636F6E6E656374696F6E5F737461746501030105537461746500 = type { i1, i1, i1, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E436F6E6E656374696F6E466C6F7700, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010C53747265616D4C696D69747300 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D010301084279746543656C6C00 = type { i64, i8 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D0103010D5265636569766542756666657200 = type { %sollang.array.i32, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D0103010A53656E6442756666657200 = type { %sollang.array.i32, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D010301045265616400 = type { %sollang.array.i32, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D010301054368756E6B00 = type { i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6572726F72010301054572726F7200 = type { %sollang.enum.t559, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010643727970746F00 = type { i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010653747265616D00 = type { i64, i64, i1, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010B526573657453747265616D00 = type { i64, i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010B53746F7053656E64696E6700 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D6501030108446174616772616D00 = type { %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010D4D617853747265616D4461746100 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010A4D617853747265616D7300 = type { i1, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103011153747265616D44617461426C6F636B656400 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010E53747265616D73426C6F636B656400 = type { i1, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010F436F6E6E656374696F6E436C6F736500 = type { i1, i64, i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010F4E6577436F6E6E656374696F6E496400 = type { i64, i64, %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010841636B52616E676500 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010341636B00 = type { i64, i64, i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D65010301074465636F64656400 = type { %sollang.enum.t560, i64 }
%sollang.struct.x1D7374642E6E65742E717569632E68616E647368616B655F656E67696E65010301064F70656E656400 = type { i32, i64, i64, %sollang.array.i32, i64 }
%sollang.struct.x1B7374642E6E65742E717569632E696E697469616C5F656E67696E65010301154163636570746564436C69656E74496E697469616C00 = type { i32, %sollang.array.i32, %sollang.array.i32, i64, %sollang.array.i32 }
%sollang.struct.x1B7374642E6E65742E717569632E696E697469616C5F656E67696E65010301134F70656E6564536572766572496E697469616C00 = type { %sollang.array.i32, i64, %sollang.array.i32 }
%sollang.struct.x117374642E6E65742E717569632E6B6579730103010B496E697469616C4B65797300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F7665727901030108527474537461746500 = type { i1, i64, i64, i64, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F766572790103010F436F6E67657374696F6E537461746500 = type { i64, i64, i64, i64, i1 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400 = type { %sollang.int_slice }
%sollang.struct.x107374642E6E65742E717569632E703270010301084964656E7469747900 = type { %sollang.struct.x0C7374642E6E65742E71756963010301084964656E7469747900, %sollang.int_slice, %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010A506565725265636F726400 = type { %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400, %sollang.int_slice, %sollang.struct.x077374642E6E65740103010C49707634456E64706F696E7400, i64, %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x107374642E6E65742E717569632E7032700103010753657373696F6E00 = type { %sollang.struct.x0C7374642E6E65742E717569630103010A436F6E6E656374696F6E00, %sollang.struct.x0C7374642E6E65742E7175696301030108426953747265616D00, %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010E50726F746F636F6C53747265616D00 = type { %sollang.array.i32 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010D41757468656E7469636174656400 = type { %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400, %sollang.struct.x0C7374642E6E65742E7175696301030108426953747265616D00 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010D4F70656E6564496E697469616C00 = type { i32, i64, %sollang.array.i32, i64 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010D496E697469616C48656164657200 = type { i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i64, i64 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010F4F70656E656448616E647368616B6500 = type { i32, i64, %sollang.array.i32, i64 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010F48616E647368616B6548656164657200 = type { i32, %sollang.array.i32, %sollang.array.i32, i64, i64 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010C4F70656E65644F6E6552747400 = type { i1, i64, %sollang.array.i32 }
%sollang.struct.x137374642E6E65742E717569632E7061636B6574010301134F70656E656450726F7465637465644C6F6E6700 = type { i8, i64, %sollang.array.i32 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010950726F746563746F7200 = type { %sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E0103011150726570617265645061636B65744B657900, %sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301094865616465724B657900 }
%sollang.struct.x1A7374642E6E65742E717569632E7061636B65745F6E756D626572010301095472756E636174656400 = type { i32, i64 }
%sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F766572790103010A53656E745061636B657400 = type { i64, i64, i64, i1, i1 }
%sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F766572790103010655706461746500 = type { %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F7665727901030108527474537461746500, %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F766572790103010F436F6E67657374696F6E537461746500, i64, i64, i64, i64 }
%sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F76657279010301074A6F75726E616C00 = type { %sollang.array.i32 }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301094D61736B56616C756500 = type { %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E0103010A4E6F6E636556616C756500 = type { %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301095061636B65744B657900 = type { %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301094865616465724B657900 = type { %sollang.struct.x117374642E63727970746F2E616573313238010301034B657900 }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E0103011150726570617265645061636B65744B657900 = type { %sollang.struct.x157374642E63727970746F2E6165733132385F67636D010301034B657900, %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E7265617373656D626C79010301094163636F756E74656400 = type { %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010B52656365697665466C6F7700, i64 }
%sollang.struct.x177374642E6E65742E717569632E7265617373656D626C7901030105517565756500 = type { %sollang.array.i32, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E53747265616D4964656E7469747900 = type { i64, i64, %sollang.enum.t561, %sollang.enum.t562 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010B52656365697665466C6F7700 = type { i64, i64, i64, i1, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010853656E64466C6F7700 = type { i64, i64, i1, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E436F6E6E656374696F6E466C6F7700 = type { i64, i64, i64, i64, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010C53747265616D4C696D69747300 = type { i64, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E53747265616D526567697374727900 = type { i1, i64, i64, i1, i1, i64, i64, i64, i64, i64, i64, i32, %sollang.array.i32, i32, i32, i32, i32, %sollang.array.i32, i32, i32, i32 }
%sollang.struct.x157374642E6E65742E717569632E746C735F617574680103010B436572746966696361746500 = type { %sollang.array.i32 }
%sollang.struct.x157374642E6E65742E717569632E746C735F6175746801030111436572746966696361746556657269667900 = type { i16, %sollang.array.i32 }
%sollang.struct.x1D7374642E6E65742E717569632E746C735F636C69656E745F737461746501030105537461746500 = type { %sollang.enum.t563, %sollang.struct.x1B7374642E6E65742E717569632E746C735F7472616E7363726970740103010A5472616E73637269707400, %sollang.int_slice }
%sollang.struct.x1A7374642E6E65742E717569632E746C735F68616E647368616B65010301074465636F64656400 = type { i8, %sollang.array.i32, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E746C735F68616E647368616B65010301104465636F646564457874656E73696F6E00 = type { i16, %sollang.array.i32, i64 }
%sollang.struct.x167374642E6E65742E717569632E746C735F68656C6C6F0103010B436C69656E7448656C6C6F00 = type { %sollang.int_slice, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.int_slice, %sollang.array.i32 }
%sollang.struct.x167374642E6E65742E717569632E746C735F68656C6C6F0103010B53657276657248656C6C6F00 = type { %sollang.int_slice, %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x167374642E6E65742E717569632E746C735F68656C6C6F01030113456E63727970746564457874656E73696F6E7300 = type { %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x1D7374642E6E65742E717569632E746C735F7365727665725F737461746501030105537461746500 = type { %sollang.enum.t564, %sollang.struct.x1B7374642E6E65742E717569632E746C735F7472616E7363726970740103010A5472616E73637269707400 }
%sollang.struct.x1B7374642E6E65742E717569632E746C735F7472616E7363726970740103010A5472616E73637269707400 = type { %sollang.array.i32 }
%sollang.struct.x197374642E6E65742E717569632E747261666669635F6B657973010301044B65797300 = type { %sollang.struct.x137374642E6E65742E717569632E7061636B65740103010950726F746563746F7200 }
%sollang.struct.x217374642E6E65742E717569632E7472616E73706F72745F706172616D6574657273010301074465636F64656400 = type { i64, %sollang.array.i32, i64 }
%sollang.struct.x217374642E6E65742E717569632E7472616E73706F72745F706172616D65746572730103010B53747265616D436F756E7400 = type { i64 }
%sollang.struct.x137374642E6E65742E717569632E766172696E74010301074465636F64656400 = type { i64, i64 }
%sollang.struct.x207374642E6E65742E717569632E76657273696F6E5F6E65676F74696174696F6E0103010B496E666F726D6174696F6E00 = type { i32, %sollang.array.i32 }
%sollang.struct.x1B7374642E6E65742E717569632E76657273696F6E5F7061636B6574010301065061636B657400 = type { %sollang.array.i32, %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x197374642E6E65742E717569632E783530395F6564323535313901030107456C656D656E7400 = type { i8, i64, i64, i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D4C697374656E4F7074696F6E7300 = type { %sollang.enum.t541, i32, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030113446174616772616D42696E644F7074696F6E7300 = type { %sollang.enum.t541, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010B5463704C697374656E657200 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030109556470536F636B657400 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010A53656E6442756666657200 = type { ptr, i64, i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D5265636569766542756666657200 = type { %sollang.array.i32 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030108496E74657265737400 = type { i64, %sollang.enum.t568, %sollang.enum.t567 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010A52656164794576656E7400 = type { i64, i1, i1, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030118436F6D706C6574696F6E52656163746F724F7074696F6E7300 = type { i64, i64, i64 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400 = type { i64, %sollang.enum.t569, %sollang.array.i32, i64, i64, %sollang.enum.t570, %sollang.enum.t1071, %sollang.enum.t1072, %sollang.enum.t681 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030119536F636B6574526567697374726174696F6E4661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D52656D6F76656453747265616D00 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030115436F6D706C6574696F6E576169744661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030110536F636B6574436F6D706C6574696F6E00 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103011B436F6D706C6574696F6E5375626D697373696F6E4661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030115536C6F745472616E736974696F6E4661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010752656163746F7200 = type { i64, %sollang.array.i32 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030108446174616772616D00 = type { %sollang.enum.t541, %sollang.array.i32, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010F446174616772616D5265636569707400 = type { %sollang.enum.t541, i64, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 = type { %sollang.enum.t573, i32 }
%sollang.struct.x087374642E70617468010301054572726F7200 = type { %sollang.enum.t575, i64 }
%sollang.struct.x087374642E70617468010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x087374642E7061746801030109436F6D706F6E656E7400 = type { %sollang.enum.t574, i64, i64 }
%sollang.struct.x087374642E706174680103010648656164657200 = type { %sollang.enum.t574, i64, i1 }
%sollang.struct.x087374642E706174680103010A436F6D706F6E656E747300 = type { %sollang.source_text, i64, i64, i32, i1, %sollang.struct.x087374642E70617468010301064C696D69747300, %sollang.struct.x087374642E706174680103010648656164657200 }
%sollang.struct.x0C7374642E746578742E637376010301054572726F7200 = type { %sollang.enum.t577, i64, i32 }
%sollang.struct.x0C7374642E746578742E637376010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0C7374642E746578742E6373760103010C5772697465724C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0C7374642E746578742E63737601030106466F726D617400 = type { %sollang.enum.t576, i32 }
%sollang.struct.x0C7374642E746578742E637376010301054669656C6400 = type { i32, i32, i32, i1 }
%sollang.struct.x0C7374642E746578742E6373760103010652656164657200 = type { %sollang.source_text, i64, i64, i32, i32, i1, %sollang.struct.x0C7374642E746578742E63737601030106466F726D617400, %sollang.struct.x0C7374642E746578742E637376010301064C696D69747300 }
%sollang.struct.x0C7374642E746578742E6373760103010657726974657200 = type { %sollang.struct.x0C7374642E746578742E6373760103010C5772697465724C696D69747300, i32, i32, i32, i32 }
%sollang.struct.x0C7374642E746578742E6373760103010C5363616E6E65644669656C6400 = type { i64, i64, i64, i32, i1, i1 }
%sollang.struct.x0D7374642E746578742E676C6F62010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x0D7374642E746578742E676C6F62010301054572726F7200 = type { %sollang.enum.t578, i64, i64 }
%sollang.struct.x0D7374642E746578742E676C6F62010301075061747465726E00 = type { %sollang.source_text, i64, i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E010301054572726F7200 = type { %sollang.enum.t581, i64 }
%sollang.struct.x0D7374642E746578742E6A736F6E010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E01030105546F6B656E00 = type { %sollang.enum.t579, i64, i64, i64, i64, i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E010301064D656D62657200 = type { %sollang.array.i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010556616C756500 = type { %sollang.enum.t580, i64, i64, i1, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E01030108446F63756D656E7400 = type { %sollang.array.i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010652656164657200 = type { %sollang.source_text, i64, i64, i8, i32, %sollang.struct.x0D7374642E746578742E6A736F6E010301064C696D69747300, %sollang.array.i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010657726974657200 = type { %sollang.array.i32, i32, i32, i32, i8, %sollang.array.i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010A537472696E675363616E00 = type { i64, i64, i32 }
%sollang.struct.x0E7374642E746578742E7265676578010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0E7374642E746578742E7265676578010301054572726F7200 = type { %sollang.enum.t582, i64, i64, i64 }
%sollang.struct.x0E7374642E746578742E7265676578010301054D6174636800 = type { i64, i64 }
%sollang.struct.x0E7374642E746578742E7265676578010301075061747465726E00 = type { %sollang.source_text, i64, i64, i32, i32, i1, i1, i32, i32 }
%sollang.struct.x0E7374642E746578742E72656765780103010441746F6D00 = type { %sollang.enum.t583, i64, i64, i64, i1, %sollang.enum.t584, i64 }
%sollang.struct.x0E7374642E746578742E726567657801030109436C617373556E697400 = type { i8, i64 }
%sollang.struct.x0E7374642E746578742E726567657801030104576F726B00 = type { i32 }
%sollang.struct.x087374642E74696D65010301084475726174696F6E00 = type { i64 }
%sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400 = type { i64, i64 }
%sollang.struct.x087374642E74696D650103010A557463496E7374616E7400 = type { i64 }
%sollang.struct.x087374642E74696D650103010C43616C656E6461724461746500 = type { i64, i64, i64 }
%sollang.struct.x087374642E74696D650103010E4D6F6E6F746F6E6963436C6F636B00 = type { i8 }
%sollang.struct.x087374642E74696D650103010957616C6C436C6F636B00 = type { i8 }
%sollang.struct.x087374642E74696D650103010B4D616E75616C436C6F636B00 = type { i64, i64 }
%sollang.struct.x087374642E74696D650103010F4D616E75616C57616C6C436C6F636B00 = type { i64 }
%sollang.struct.x087374642E74696D6501030108446561646C696E6500 = type { %sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400 }
%sollang.struct.x087374642E74696D650103010A4669786564436C6F636B00 = type { %sollang.struct.x087374642E74696D650103010A557463496E7374616E7400 }
%sollang.struct.x087374642E74696D650103010B4F6666736574436C6F636B00 = type { i64 }
%sollang.struct.x087374642E74696D6501030111436C6F636B4361706162696C697469657300 = type { %sollang.struct.x087374642E74696D65010301084475726174696F6E00, %sollang.enum.t585, %sollang.struct.x087374642E74696D65010301084475726174696F6E00 }
%sollang.struct.x087374642E74696D650103010554696D657200 = type { %sollang.array.i32, %sollang.struct.x087374642E74696D65010301084475726174696F6E00, i64, %sollang.enum.t586 }
%sollang.struct.x087374642E74696D650103010954696D65725469636B00 = type { %sollang.struct.x087374642E74696D650103010554696D657200, %sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400, %sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400, i64 }
%sollang.struct.x087374642E74696D65010301054572726F7200 = type { %sollang.enum.t587 }
%sollang.struct.x077374642E757269010301054572726F7200 = type { %sollang.enum.t591, i64 }
%sollang.struct.x077374642E757269010301045370616E00 = type { i64, i64, i1 }
%sollang.struct.x077374642E75726901030109417574686F7269747900 = type { %sollang.struct.x077374642E757269010301045370616E00, %sollang.enum.t588, %sollang.enum.t589, %sollang.struct.x077374642E757269010301045370616E00 }
%sollang.struct.x077374642E757269010301095265666572656E636500 = type { %sollang.source_text, %sollang.struct.x077374642E757269010301045370616E00, %sollang.enum.t590, %sollang.struct.x077374642E757269010301045370616E00, %sollang.struct.x077374642E757269010301045370616E00, %sollang.struct.x077374642E757269010301045370616E00 }
%sollang.struct.x077374642E757269010301134E6F726D616C697A6174696F6E506F6C69637900 = type { i1, i1, i1, i1, i1 }
%sollang.struct.x0F7374642E7572692E70657263656E74010301054572726F7200 = type { %sollang.enum.t592, i64 }
%sollang.struct.x0F7374642E7572692E70657263656E7401030104506C616E00 = type { i32, i32 }
%sollang.struct.x0F7374642E7572692E70657263656E7401030105436F64656300 = type { %sollang.enum.t593 }
%sollang.struct.x087374642E75756964010301054572726F7200 = type { %sollang.enum.t595, i64 }
%sollang.struct.x087374642E75756964010301045575696400 = type { %sollang.int_slice }
%sollang.struct.x087374642E7575696401030105436F64656300 = type { i8 }
%sollang.struct.x087374642E757569640103010947656E657261746F7200 = type { %sollang.struct.x087374642E74696D650103010957616C6C436C6F636B00, %sollang.struct.x117374642E63727970746F2E72616E646F6D0103010C53656375726552616E646F6D00 }
%sollang.struct.x0D7379732E6469726563746F72790103010352617700 = type { %sollang.array.i32, i64 }
%sollang.struct.x0D7379732E6469726563746F727901030105456E74727900 = type { %sollang.struct.x087379732E70617468010301045061746800, %sollang.enum.t598 }
%sollang.struct.x087379732E66696C650103010446696C6500 = type { i64 }
%sollang.struct.x087379732E66696C650103010A46696C6557726974657200 = type { i64 }
%sollang.struct.x087379732E66696C650103011441746F6D69635265706C6163655265717565737400 = type { %sollang.text, %sollang.text }
%sollang.struct.x087379732E66696C650103010A536F757263655465787400 = type {  }
%sollang.struct.x087379732E66696C650103010D5265616441745375636365737300 = type { %sollang.struct.x087379732E66696C650103010446696C6500, %sollang.array.i32, i64, i1 }
%sollang.struct.x087379732E66696C650103010D5265616441744661696C75726500 = type { %sollang.struct.x087379732E66696C650103010446696C6500, %sollang.array.i32, %sollang.enum.t599 }
%sollang.struct.x087379732E66696C650103010E577269746541745375636365737300 = type { %sollang.struct.x087379732E66696C650103010A46696C6557726974657200, %sollang.array.i32, i64 }
%sollang.struct.x087379732E66696C650103010E577269746541744661696C75726500 = type { %sollang.struct.x087379732E66696C650103010A46696C6557726974657200, %sollang.array.i32, %sollang.enum.t599 }
%sollang.struct.x0F7379732E696E7075742E6D6F757365010301054576656E7400 = type { i32, i32, i32, i32, %sollang.enum.t600 }
%sollang.struct.x0F7379732E696E7075742E6D6F757365010301054572726F7200 = type { %sollang.enum.t602, i32 }
%sollang.struct.x0F7379732E696E7075742E6D6F75736501030106536F7572636500 = type { i32, %sollang.enum.t601 }
%sollang.struct.x087379732E70617468010301045061746800 = type { %sollang.array.i32, %sollang.enum.t603 }
%sollang.struct.x087379732E7061746801030107526177496E666F00 = type { %sollang.array.i32, i8, i64, i64 }
%sollang.struct.x087379732E7061746801030104496E666F00 = type { %sollang.struct.x087379732E70617468010301045061746800, %sollang.enum.t598, i64, i64 }
%sollang.struct.x0B7379732E70726F6365737301030111456E7669726F6E6D656E744368616E676500 = type { %sollang.text, %sollang.text, i1 }
%sollang.struct.x0B7379732E70726F636573730103010D436170747572654C696D69747300 = type { i64, i64 }
%sollang.struct.x0B7379732E70726F636573730103010E43617074757265644F757470757400 = type { %sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300, %sollang.array.i32, %sollang.array.i32, i1, i1 }
%sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 = type { %sollang.array.i32, %sollang.text, i1, %sollang.array.i32, i1, %sollang.enum.t604, %sollang.enum.t605, %sollang.enum.t605 }
%sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 = type { i32 }
%sollang.struct.x0B7379732E70726F636573730103010C5369676E616C53746174757300 = type { i32 }
%sollang.struct.x0B7379732E70726F636573730103010950726F63657373496400 = type { i64 }
%sollang.struct.x0B7379732E70726F63657373010301054368696C6400 = type { i64, %sollang.struct.x0B7379732E70726F636573730103010950726F63657373496400, i32, i32 }
%sollang.struct.x0B7379732E70726F63657373010301094368696C64506F6C6C00 = type { i32, i32 }
%sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500 = type { i32, i32 }
%sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00 = type { i64 }
%sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103011150726F6365737347726F7570436F756E7400 = type { i16 }
%sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 = type { i16, i16, i32, i64, i64, i64, i32, i32, i32, i16, i16 }
%sollang.struct.x067374642E696F0105010652656164657200 = type {  }
%sollang.struct.x067374642E696F0105010657726974657200 = type {  }
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture)
%sollang.dyn = type { ptr, ptr }
%sollang.mutable_container = type { ptr, ptr, ptr }
%sollang.int_slice = type { ptr, i64 }
%sollang.array.i32 = type { ptr, i64, i64 }
define internal void @sollang_drop_t460(%sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500 %value) {
entry:
  ret void
}
define internal void @sollang_drop_t461(%sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00 %value) {
entry:
  ret void
}
define internal void @sollang_drop_t462(%sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103011150726F6365737347726F7570436F756E7400 %value) {
entry:
  ret void
}
define internal void @sollang_drop_t463(%sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 %value) {
entry:
  ret void
}
declare void @llvm.trap()
define ptr @sollang_raw_arena_create(i64 %bytes, i1 %size_valid) {
entry:
  br i1 %size_valid, label %allocate, label %fail
allocate:
  %data = call ptr @sollang_alloc(i64 %bytes)
  %allocated = icmp ne ptr %data, null
  br i1 %allocated, label %done, label %fail
done:
  ret ptr %data
fail:
  call void @llvm.trap()
  unreachable
}
declare dllimport ptr @LoadLibraryA(ptr)
declare dllimport ptr @GetProcAddress(ptr, ptr)
declare dllimport i32 @FreeLibrary(ptr)
@sollang_native_library_name_m145_a54 = private unnamed_addr constant [13 x i8] c"kernel32.dll\00"
@sollang_native_library_m145_a54 = internal global ptr null, align 8
@sollang_native_symbol_name_m145_s19 = private unnamed_addr constant [18 x i8] c"GetCurrentProcess\00"
@sollang_native_function_m145_s19 = internal global ptr null, align 8
@sollang_native_symbol_name_m145_s20 = private unnamed_addr constant [23 x i8] c"GetProcessAffinityMask\00"
@sollang_native_function_m145_s20 = internal global ptr null, align 8
@sollang_native_symbol_name_m145_s23 = private unnamed_addr constant [24 x i8] c"GetProcessGroupAffinity\00"
@sollang_native_function_m145_s23 = internal global ptr null, align 8
@sollang_native_symbol_name_m145_s26 = private unnamed_addr constant [29 x i8] c"GetActiveProcessorGroupCount\00"
@sollang_native_function_m145_s26 = internal global ptr null, align 8
@sollang_native_symbol_name_m145_s27 = private unnamed_addr constant [24 x i8] c"GetActiveProcessorCount\00"
@sollang_native_function_m145_s27 = internal global ptr null, align 8
@sollang_native_symbol_name_m145_s28 = private unnamed_addr constant [13 x i8] c"GetLastError\00"
@sollang_native_function_m145_s28 = internal global ptr null, align 8
@sollang_native_symbol_name_m145_s29 = private unnamed_addr constant [14 x i8] c"GetSystemInfo\00"
@sollang_native_function_m145_s29 = internal global ptr null, align 8
@sollang_native_symbol_name_m145_s30 = private unnamed_addr constant [26 x i8] c"QueryInformationJobObject\00"
@sollang_native_function_m145_s30 = internal global ptr null, align 8
define internal ptr @sollang_native_require(ptr %value) {
entry:
  %found = icmp ne ptr %value, null
  br i1 %found, label %done, label %fail
fail:
  call void @llvm.trap()
  unreachable
done:
  ret ptr %value
}
define internal void @sollang_native_init() {
entry:
  %native_library_raw_m145_a54 = call ptr @LoadLibraryA(ptr @sollang_native_library_name_m145_a54)
  %native_library_checked_m145_a54 = call ptr @sollang_native_require(ptr %native_library_raw_m145_a54)
  store ptr %native_library_checked_m145_a54, ptr @sollang_native_library_m145_a54, align 8
  %native_library_m145_s19 = load ptr, ptr @sollang_native_library_m145_a54, align 8
  %native_symbol_raw_m145_s19 = call ptr @GetProcAddress(ptr %native_library_m145_s19, ptr @sollang_native_symbol_name_m145_s19)
  %native_symbol_checked_m145_s19 = call ptr @sollang_native_require(ptr %native_symbol_raw_m145_s19)
  store ptr %native_symbol_checked_m145_s19, ptr @sollang_native_function_m145_s19, align 8
  %native_library_m145_s20 = load ptr, ptr @sollang_native_library_m145_a54, align 8
  %native_symbol_raw_m145_s20 = call ptr @GetProcAddress(ptr %native_library_m145_s20, ptr @sollang_native_symbol_name_m145_s20)
  %native_symbol_checked_m145_s20 = call ptr @sollang_native_require(ptr %native_symbol_raw_m145_s20)
  store ptr %native_symbol_checked_m145_s20, ptr @sollang_native_function_m145_s20, align 8
  %native_library_m145_s23 = load ptr, ptr @sollang_native_library_m145_a54, align 8
  %native_symbol_raw_m145_s23 = call ptr @GetProcAddress(ptr %native_library_m145_s23, ptr @sollang_native_symbol_name_m145_s23)
  %native_symbol_checked_m145_s23 = call ptr @sollang_native_require(ptr %native_symbol_raw_m145_s23)
  store ptr %native_symbol_checked_m145_s23, ptr @sollang_native_function_m145_s23, align 8
  %native_library_m145_s26 = load ptr, ptr @sollang_native_library_m145_a54, align 8
  %native_symbol_raw_m145_s26 = call ptr @GetProcAddress(ptr %native_library_m145_s26, ptr @sollang_native_symbol_name_m145_s26)
  %native_symbol_checked_m145_s26 = call ptr @sollang_native_require(ptr %native_symbol_raw_m145_s26)
  store ptr %native_symbol_checked_m145_s26, ptr @sollang_native_function_m145_s26, align 8
  %native_library_m145_s27 = load ptr, ptr @sollang_native_library_m145_a54, align 8
  %native_symbol_raw_m145_s27 = call ptr @GetProcAddress(ptr %native_library_m145_s27, ptr @sollang_native_symbol_name_m145_s27)
  %native_symbol_checked_m145_s27 = call ptr @sollang_native_require(ptr %native_symbol_raw_m145_s27)
  store ptr %native_symbol_checked_m145_s27, ptr @sollang_native_function_m145_s27, align 8
  %native_library_m145_s28 = load ptr, ptr @sollang_native_library_m145_a54, align 8
  %native_symbol_raw_m145_s28 = call ptr @GetProcAddress(ptr %native_library_m145_s28, ptr @sollang_native_symbol_name_m145_s28)
  %native_symbol_checked_m145_s28 = call ptr @sollang_native_require(ptr %native_symbol_raw_m145_s28)
  store ptr %native_symbol_checked_m145_s28, ptr @sollang_native_function_m145_s28, align 8
  %native_library_m145_s29 = load ptr, ptr @sollang_native_library_m145_a54, align 8
  %native_symbol_raw_m145_s29 = call ptr @GetProcAddress(ptr %native_library_m145_s29, ptr @sollang_native_symbol_name_m145_s29)
  %native_symbol_checked_m145_s29 = call ptr @sollang_native_require(ptr %native_symbol_raw_m145_s29)
  store ptr %native_symbol_checked_m145_s29, ptr @sollang_native_function_m145_s29, align 8
  %native_library_m145_s30 = load ptr, ptr @sollang_native_library_m145_a54, align 8
  %native_symbol_raw_m145_s30 = call ptr @GetProcAddress(ptr %native_library_m145_s30, ptr @sollang_native_symbol_name_m145_s30)
  %native_symbol_checked_m145_s30 = call ptr @sollang_native_require(ptr %native_symbol_raw_m145_s30)
  store ptr %native_symbol_checked_m145_s30, ptr @sollang_native_function_m145_s30, align 8
  ret void
}
define internal void @sollang_native_cleanup() {
entry:
  %native_close_handle_m145_a54 = load ptr, ptr @sollang_native_library_m145_a54, align 8
  %native_closed_m145_a54 = call i32 @FreeLibrary(ptr %native_close_handle_m145_a54)
  ret void
}
declare dllimport void @ExitProcess(i32)
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011764657269766545787465726E616C42696E6465724B65794E01067075626C6963011764657269766545787465726E616C42696E6465724B6579010370736B18013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [10 x i8] c"ext binder"
@sollang_str_x157374642E63727970746F2E746C7331335F6B65797301070119646572697665526573756D7074696F6E42696E6465724B65795001067075626C69630119646572697665526573756D7074696F6E42696E6465724B6579010370736B18013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [10 x i8] c"res binder"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701136465726976654561726C7946726F6D486173687201067075626C696301136465726976654561726C7946726F6D48617368010370736B18013A07015B010555496E743808015D0E012C0119636C69656E7448656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E010C4561726C7953656372657473_00 = private unnamed_addr constant [11 x i8] c"c e traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701136465726976654561726C7946726F6D486173687201067075626C696301136465726976654561726C7946726F6D48617368010370736B18013A07015B010555496E743808015D0E012C0119636C69656E7448656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E010C4561726C7953656372657473_01 = private unnamed_addr constant [12 x i8] c"e exp master"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_00 = private unnamed_addr constant [7 x i8] c"derived"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_01 = private unnamed_addr constant [12 x i8] c"c hs traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_02 = private unnamed_addr constant [12 x i8] c"s hs traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_03 = private unnamed_addr constant [7 x i8] c"derived"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701196465726976654170706C69636174696F6E46726F6D48617368880101067075626C696301196465726976654170706C69636174696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C73657276657246696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E01124170706C69636174696F6E53656372657473_00 = private unnamed_addr constant [12 x i8] c"c ap traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701196465726976654170706C69636174696F6E46726F6D48617368880101067075626C696301196465726976654170706C69636174696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C73657276657246696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E01124170706C69636174696F6E53656372657473_01 = private unnamed_addr constant [12 x i8] c"s ap traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701196465726976654170706C69636174696F6E46726F6D48617368880101067075626C696301196465726976654170706C69636174696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C73657276657246696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E01124170706C69636174696F6E53656372657473_02 = private unnamed_addr constant [10 x i8] c"exp master"
@sollang_str_x157374642E63727970746F2E746C7331335F6B65797301070118646572697665526573756D7074696F6E46726F6D48617368870101067075626C69630118646572697665526573756D7074696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C636C69656E7446696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [10 x i8] c"res master"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011A66696E69736865645665726966794461746146726F6D486173687801067075626C6963011A66696E69736865645665726966794461746146726F6D486173680107626173654B657918013A07015B010555496E743808015D0E012C010E7472616E7363726970744861736818013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [8 x i8] c"finished"
@sollang_str_x157374642E63727970746F2E746C7331335F6B65797301070113757064617465547261666669635365637265744D01067075626C6963011375706461746554726166666963536563726574010673656372657418013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [11 x i8] c"traffic upd"
@sollang_str_x0C7374642E6E65742E687474700107010C706172736556657273696F6E8401010C706172736556657273696F6E0106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C0105737461727418013A010855496E7453697A650E012C0103656E6418013A010855496E7453697A6516022D3E0106526573756C741E013C010756657273696F6E0E012C01054572726F721F013E_00 = private unnamed_addr constant [8 x i8] c"HTTP/1.0"
@sollang_str_x0C7374642E6E65742E687474700107010C706172736556657273696F6E8401010C706172736556657273696F6E0106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C0105737461727418013A010855496E7453697A650E012C0103656E6418013A010855496E7453697A6516022D3E0106526573756C741E013C010756657273696F6E0E012C01054572726F721F013E_01 = private unnamed_addr constant [8 x i8] c"HTTP/1.1"
@sollang_str_x117374642E6E65742E687474702E626F64790107011570617273655472616E73666572456E636F64696E678301011570617273655472616E73666572456E636F64696E670106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C010576616C756518013A0104687474700D012E01045370616E16022D3E0106526573756C741E013C0104426F6F6C0E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [7 x i8] c"chunked"
@sollang_str_x117374642E6E65742E687474702E626F64790107010D6865616465724672616D696E67B101010D6865616465724672616D696E670106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C01066669656C647318013A010372656607015B0104687474700D012E01054669656C640F013B0C017E08015D0E012C01066C696D69747318013A010A426F64794C696D69747316022D3E0106526573756C741E013C010D4865616465724672616D696E670E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x117374642E6E65742E687474702E626F64790107010D6865616465724672616D696E67B101010D6865616465724672616D696E670106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C01066669656C647318013A010372656607015B0104687474700D012E01054669656C640F013B0C017E08015D0E012C01066C696D69747318013A010A426F64794C696D69747316022D3E0106526573756C741E013C010D4865616465724672616D696E670E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F76616C6964617465547261696C65725A010F76616C6964617465547261696C657201076465636F64657218013A0103726566010B426F64794465636F64657216022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F76616C6964617465547261696C65725A010F76616C6964617465547261696C657201076465636F64657218013A0103726566010B426F64794465636F64657216022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F73656C6563745265706C79426F64798901010F73656C6563745265706C79426F64790107636F6E7465787418013A0113526573706F6E7365426F6479436F6E746578740E012C01046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0108426F6479506C616E0E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F73656C6563745265706C79426F64798901010F73656C6563745265706C79426F64790107636F6E7465787418013A0113526573706F6E7365426F6479436F6E746578740E012C01046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0108426F6479506C616E0E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x137374642E6E65742E687474702E636C69656E7401070119726573706F6E7365416C6C6F777350657273697374656E6365620119726573706F6E7365416C6C6F777350657273697374656E636501046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_00 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x137374642E6E65742E687474702E636C69656E7401070119726573706F6E7365416C6C6F777350657273697374656E6365620119726573706F6E7365416C6C6F777350657273697374656E636501046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"close"
@sollang_str_x137374642E6E65742E687474702E636C69656E7401070119726573706F6E7365416C6C6F777350657273697374656E6365620119726573706F6E7365416C6C6F777350657273697374656E636501046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_02 = private unnamed_addr constant [10 x i8] c"keep-alive"
@sollang_str_x137374642E6E65742E687474702E636C69656E7402060108526573706F6E7365100104696D706C0108526573706F6E73651F01086F70656E426F64794B01067075626C696301086F70656E426F647918013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365426F64790E012C01054572726F721F013E_00 = private unnamed_addr constant [3 x i8] c"GET"
@sollang_str_x137374642E6E65742E687474702E636C69656E7402060108526573706F6E7365100104696D706C0108526573706F6E73651F01086F70656E426F64794B01067075626C696301086F70656E426F647918013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365426F64790E012C01054572726F721F013E_01 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x137374642E6E65742E687474702E636C69656E7402060108526573706F6E7365100104696D706C0108526573706F6E73651F01086F70656E426F64794B01067075626C696301086F70656E426F647918013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365426F64790E012C01054572726F721F013E_02 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E7265717565737401070119636C617373696679526573706F6E736553656D616E74696373430119636C617373696679526573706F6E736553656D616E7469637301066D6574686F6418013A01045465787416022D3E0111526573706F6E736553656D616E74696373_00 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x147374642E6E65742E687474702E7265717565737401070119636C617373696679526573706F6E736553656D616E74696373430119636C617373696679526573706F6E736553656D616E7469637301066D6574686F6418013A01045465787416022D3E0111526573706F6E736553656D616E74696373_01 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_00 = private unnamed_addr constant [4 x i8] c"Host"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_01 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_02 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_03 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_04 = private unnamed_addr constant [7 x i8] c"Trailer"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_00 = private unnamed_addr constant [8 x i8] c"HTTP/1.0"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_01 = private unnamed_addr constant [8 x i8] c"HTTP/1.1"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_00 = private unnamed_addr constant [2 x i8] c": "
@sollang_str_x147374642E6E65742E687474702E726571756573740107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x147374642E6E65742E687474702E7265717565737401070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_00 = private unnamed_addr constant [16 x i8] c"Content-Length: "
@sollang_str_x147374642E6E65742E687474702E7265717565737401070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_03 = private unnamed_addr constant [7 x i8] c"OPTIONS"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374506F6C696379150104696D706C010D52657175657374506F6C6963791F010772657175657374F50101067075626C696301077265717565737418013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C0109617574686F7269747918013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010D526571756573745772697465720E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"Host"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [5 x i8] c"close"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_03 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_04 = private unnamed_addr constant [10 x i8] c"keep-alive"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_05 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_00 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_01 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_02 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_03 = private unnamed_addr constant [7 x i8] c"Trailer"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_00 = private unnamed_addr constant [8 x i8] c"HTTP/1.0"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_01 = private unnamed_addr constant [8 x i8] c"HTTP/1.1"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_00 = private unnamed_addr constant [2 x i8] c": "
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E736501070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_00 = private unnamed_addr constant [16 x i8] c"Content-Length: "
@sollang_str_x157374642E6E65742E687474702E726573706F6E736501070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365506F6C696379160104696D706C010E526573706F6E7365506F6C6963791F0108726573706F6E7365EA0101067075626C69630108726573706F6E736518013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C010673746174757318013A0103496E740E012C0106726561736F6E18013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010E526573706F6E73655772697465720E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365506F6C696379160104696D706C010E526573706F6E7365506F6C6963791F0108726573706F6E7365EA0101067075626C69630108726573706F6E736518013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C010673746174757318013A0103496E740E012C0106726561736F6E18013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010E526573706F6E73655772697465720E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365506F6C696379160104696D706C010E526573706F6E7365506F6C6963791F0108726573706F6E7365EA0101067075626C69630108726573706F6E736518013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C010673746174757318013A0103496E740E012C0106726561736F6E18013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010E526573706F6E73655772697465720E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"close"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_03 = private unnamed_addr constant [10 x i8] c"keep-alive"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_04 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_00 = private unnamed_addr constant [9 x i8] c"client in"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_01 = private unnamed_addr constant [9 x i8] c"server in"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_02 = private unnamed_addr constant [10 x i8] c"quicv2 key"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_03 = private unnamed_addr constant [8 x i8] c"quic key"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_04 = private unnamed_addr constant [9 x i8] c"quicv2 iv"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_05 = private unnamed_addr constant [7 x i8] c"quic iv"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_06 = private unnamed_addr constant [9 x i8] c"quicv2 hp"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_07 = private unnamed_addr constant [7 x i8] c"quic hp"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_00 = private unnamed_addr constant [10 x i8] c"quicv2 key"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_01 = private unnamed_addr constant [8 x i8] c"quic key"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_02 = private unnamed_addr constant [9 x i8] c"quicv2 iv"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_03 = private unnamed_addr constant [7 x i8] c"quic iv"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_04 = private unnamed_addr constant [9 x i8] c"quicv2 hp"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_05 = private unnamed_addr constant [7 x i8] c"quic hp"
@sollang_str_x0D7374642E746578742E6A736F6E020601065265616465720E0104696D706C01065265616465721F0107626F6F6C65616E5001067075626C69630107626F6F6C65616E18013A010473656C660E012C0105746F6B656E18013A0105546F6B656E16022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E020601065265616465720E0104696D706C01065265616465721F0107626F6F6C65616E5001067075626C69630107626F6F6C65616E18013A010473656C660E012C0105746F6B656E18013A0105546F6B656E16022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x0D7374642E746578742E6A736F6E020601065265616465720E0104696D706C01065265616465721F01096E756C6C56616C75655201067075626C696301096E756C6C56616C756518013A010473656C660E012C0105746F6B656E18013A0105546F6B656E16022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E010701097363616E56616C75655801097363616E56616C7565010672656164657218013A01036D757401065265616465720E012C0105646570746818013A0103496E7416022D3E0106526573756C741E013C0105546F6B656E0E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E010701097363616E56616C75655801097363616E56616C7565010672656164657218013A01036D757401065265616465720E012C0105646570746818013A0103496E7416022D3E0106526573756C741E013C0105546F6B656E0E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x0D7374642E746578742E6A736F6E010701097363616E56616C75655801097363616E56616C7565010672656164657218013A01036D757401065265616465720E012C0105646570746818013A0103496E7416022D3E0106526573756C741E013C0105546F6B656E0E012C01054572726F721F013E_02 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E0107011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E748501011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E74010576616C756518013A0103726566010556616C75650E012C01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C0108646F63756D656E7418013A01037265660108446F63756D656E7416022D3E0104556E6974_00 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E0107011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E748501011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E74010576616C756518013A0103726566010556616C75650E012C01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C0108646F63756D656E7418013A01037265660108446F63756D656E7416022D3E0104556E6974_01 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E0107011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E748501011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E74010576616C756518013A0103726566010556616C75650E012C01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C0108646F63756D656E7418013A01037265660108446F63756D656E7416022D3E0104556E6974_02 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F0105696E7436345301067075626C69630105696E74363418013A01036D7574010473656C660E012C010576616C756518013A0105496E74363416022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [6 x i8] c"$value"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F010675696E7436345501067075626C6963010675696E74363418013A01036D7574010473656C660E012C010576616C756518013A010655496E74363416022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [6 x i8] c"$value"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F01096E756C6C56616C75654301067075626C696301096E756C6C56616C756518013A01036D7574010473656C6616022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F0107626F6F6C65616E5401067075626C69630107626F6F6C65616E18013A01036D7574010473656C660E012C010576616C756518013A0104426F6F6C16022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F0107626F6F6C65616E5401067075626C69630107626F6F6C65616E18013A01036D7574010473656C660E012C010576616C756518013A0104426F6F6C16022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F0115617574686F7269747955736572496E666F546578743201067075626C69630115617574686F7269747955736572496E666F5465787418013A010473656C6616022D3E010454657874_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F010E726567697374657265644E616D652B01067075626C6963010E726567697374657265644E616D6518013A010473656C6616022D3E010454657874_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F010E726567697374657265644E616D652B01067075626C6963010E726567697374657265644E616D6518013A010473656C6616022D3E010454657874_01 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F010E726567697374657265644E616D652B01067075626C6963010E726567697374657265644E616D6518013A010473656C6616022D3E010454657874_02 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_00 = private unnamed_addr constant [1 x i8] c"0"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_01 = private unnamed_addr constant [1 x i8] c"1"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_02 = private unnamed_addr constant [1 x i8] c"2"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_03 = private unnamed_addr constant [1 x i8] c"3"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_04 = private unnamed_addr constant [1 x i8] c"4"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_05 = private unnamed_addr constant [1 x i8] c"5"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_06 = private unnamed_addr constant [1 x i8] c"6"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_07 = private unnamed_addr constant [1 x i8] c"7"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_08 = private unnamed_addr constant [1 x i8] c"8"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_09 = private unnamed_addr constant [1 x i8] c"9"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0A = private unnamed_addr constant [1 x i8] c"a"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0B = private unnamed_addr constant [1 x i8] c"b"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0C = private unnamed_addr constant [1 x i8] c"c"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0D = private unnamed_addr constant [1 x i8] c"d"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0E = private unnamed_addr constant [1 x i8] c"e"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0F = private unnamed_addr constant [1 x i8] c"f"
@sollang_str_x087374642E7575696402060104557569640C0104696D706C0104557569641F0104746578743C01067075626C696301047465787418013A010473656C660E012C010773746F7261676518013A01036D757401054172656E6116022D3E010454657874_00 = private unnamed_addr constant [1296 x i8] c"$((Int(self.bytes[0]) / 16) -> hexDigit)$((Int(self.bytes[0]) % 16) -> hexDigit)$((Int(self.bytes[1]) / 16) -> hexDigit)$((Int(self.bytes[1]) % 16) -> hexDigit)$((Int(self.bytes[2]) / 16) -> hexDigit)$((Int(self.bytes[2]) % 16) -> hexDigit)$((Int(self.bytes[3]) / 16) -> hexDigit)$((Int(self.bytes[3]) % 16) -> hexDigit)-$((Int(self.bytes[4]) / 16) -> hexDigit)$((Int(self.bytes[4]) % 16) -> hexDigit)$((Int(self.bytes[5]) / 16) -> hexDigit)$((Int(self.bytes[5]) % 16) -> hexDigit)-$((Int(self.bytes[6]) / 16) -> hexDigit)$((Int(self.bytes[6]) % 16) -> hexDigit)$((Int(self.bytes[7]) / 16) -> hexDigit)$((Int(self.bytes[7]) % 16) -> hexDigit)-$((Int(self.bytes[8]) / 16) -> hexDigit)$((Int(self.bytes[8]) % 16) -> hexDigit)$((Int(self.bytes[9]) / 16) -> hexDigit)$((Int(self.bytes[9]) % 16) -> hexDigit)-$((Int(self.bytes[10]) / 16) -> hexDigit)$((Int(self.bytes[10]) % 16) -> hexDigit)$((Int(self.bytes[11]) / 16) -> hexDigit)$((Int(self.bytes[11]) % 16) -> hexDigit)$((Int(self.bytes[12]) / 16) -> hexDigit)$((Int(self.bytes[12]) % 16) -> hexDigit)$((Int(self.bytes[13]) / 16) -> hexDigit)$((Int(self.bytes[13]) % 16) -> hexDigit)$((Int(self.bytes[14]) / 16) -> hexDigit)$((Int(self.bytes[14]) % 16) -> hexDigit)$((Int(self.bytes[15]) / 16) -> hexDigit)$((Int(self.bytes[15]) % 16) -> hexDigit)"
@sollang_str_x0D7379732E6469726563746F727901070104726561644701067075626C696301047265616401096469726563746F727918013A0104706174680D012E01045061746816022D3E010A52656164526573756C74010475736573010446696C65_00 = private unnamed_addr constant [2 x i8] c"io"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F010571756572794501067075626C69630105717565727918013A010473656C6616022D3E0106526573756C741E013C0104496E666F0E012C0104546578741F013E010475736573010446696C65_00 = private unnamed_addr constant [2 x i8] c"io"
@sollang_str_x087379732E706174680107010966726F6D42797465736B01067075626C6963010966726F6D4279746573010576616C756518013A01046D6F766507015B010555496E74380F013B0C017E08015D0E012C01057374796C6518013A01055374796C6516022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [23 x i8] c"path is not valid UTF-8"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01046A6F696E5101067075626C696301046A6F696E18013A01046D6F7665010473656C660E012C01056368696C6418013A01045465787416022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [19 x i8] c"absolute child path"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01086A6F696E506174685401067075626C696301086A6F696E5061746818013A010473656C660E012C01056368696C6418013A010372656601045061746816022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [18 x i8] c"path styles differ"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01086A6F696E506174685401067075626C696301086A6F696E5061746818013A010473656C660E012C01056368696C6418013A010372656601045061746816022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_01 = private unnamed_addr constant [29 x i8] c"cannot join an absolute child"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F0111636F6E7461696E734C65786963616C6C796101067075626C69630111636F6E7461696E734C65786963616C6C7918013A010473656C660E012C010963616E64696461746518013A010372656601045061746816022D3E0106526573756C741E013C0104426F6F6C0E012C0104546578741F013E_00 = private unnamed_addr constant [18 x i8] c"path styles differ"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [17 x i8] c"path contains NUL"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_01 = private unnamed_addr constant [20 x i8] c"invalid drive prefix"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_02 = private unnamed_addr constant [26 x i8] c"unsupported path namespace"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_03 = private unnamed_addr constant [26 x i8] c"unsupported path namespace"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_04 = private unnamed_addr constant [16 x i8] c"invalid UNC path"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_05 = private unnamed_addr constant [17 x i8] c"path escapes root"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_06 = private unnamed_addr constant [19 x i8] c"incomplete UNC path"
@sollang_str_x0B7379732E70726F6365737301070107636F6D6D616E643001067075626C69630107636F6D6D616E64010770726F6772616D18013A01045465787416022D3E0107436F6D6D616E64_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x0B7379732E70726F6365737302060107436F6D6D616E640F0104696D706C0107436F6D6D616E641F011172656D6F7665456E7669726F6E6D656E744501067075626C6963011172656D6F7665456E7669726F6E6D656E7418013A01036D7574010473656C660E012C01046E616D6518013A01045465787416022D3E0104556E6974_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F0112747279576169745465726D696E6174696F6E7501067075626C69630112747279576169745465726D696E6174696F6E18013A01036D7574010473656C6616022D3E0106526573756C741E013C01064F7074696F6E1E013C01115465726D696E6174696F6E5374617475731F013E0E012C0104546578741F013E010475736573010750726F63657373_00 = private unnamed_addr constant [4 x i8] c"wait"
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F0112747279576169745465726D696E6174696F6E7501067075626C69630112747279576169745465726D696E6174696F6E18013A01036D7574010473656C6616022D3E0106526573756C741E013C01064F7074696F6E1E013C01115465726D696E6174696F6E5374617475731F013E0E012C0104546578741F013E010475736573010750726F63657373_01 = private unnamed_addr constant [4 x i8] c"wait"
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F0107747279576169746301067075626C696301077472795761697418013A01036D7574010473656C6616022D3E0106526573756C741E013C01064F7074696F6E1E013C010A457869745374617475731F013E0E012C0104546578741F013E010475736573010750726F63657373_00 = private unnamed_addr constant [6 x i8] c"signal"
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F01046B696C6C4C01067075626C696301046B696C6C18013A01036D7574010473656C6616022D3E0106526573756C741E013C0104556E69740E012C0104546578741F013E010475736573010750726F63657373_00 = private unnamed_addr constant [4 x i8] c"kill"
@sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010D636F6E66696775726174696F6E5E010D636F6E66696775726174696F6E01036B657918013A0104546578740E012C0105726164697818013A0105496E74333216022D3E01064F7074696F6E1E013C010655496E7433321F013E010475736573010B456E7669726F6E6D656E74_00 = private unnamed_addr constant [11 x i8] c"DOTNET_$key"
@sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010D636F6E66696775726174696F6E5E010D636F6E66696775726174696F6E01036B657918013A0104546578740E012C0105726164697818013A0105496E74333216022D3E01064F7074696F6E1E013C010655496E7433321F013E010475736573010B456E7669726F6E6D656E74_01 = private unnamed_addr constant [12 x i8] c"COMPlus_$key"
@sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010D636F6E66696775726174696F6E5E010D636F6E66696775726174696F6E01036B657918013A0104546578740E012C0105726164697818013A0105496E74333216022D3E01064F7074696F6E1E013C010655496E7433321F013E010475736573010B456E7669726F6E6D656E74_02 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010D636F6E66696775726174696F6E5E010D636F6E66696775726174696F6E01036B657918013A0104546578740E012C0105726164697818013A0105496E74333216022D3E01064F7074696F6E1E013C010655496E7433321F013E010475736573010B456E7669726F6E6D656E74_03 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F727301070109617661696C61626C653201067075626C69630109617661696C61626C6518013A16022D3E0103496E74010475736573010B456E7669726F6E6D656E74_00 = private unnamed_addr constant [15 x i8] c"PROCESSOR_COUNT"
@sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F727301070109617661696C61626C653201067075626C69630109617661696C61626C6518013A16022D3E0103496E74010475736573010B456E7669726F6E6D656E74_01 = private unnamed_addr constant [10 x i8] c"GCCpuGroup"
@sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F727301070109617661696C61626C653201067075626C69630109617661696C61626C6518013A16022D3E0103496E74010475736573010B456E7669726F6E6D656E74_02 = private unnamed_addr constant [22 x i8] c"Thread_UseAllCpuGroups"
; sollang.codegen.unit 1:sollang.compiler.runtime.windows_processors
; sollang.codegen.key 16472193156553601820:14578569146703288944
define i32 @sollang_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010564696769742101056469676974010576616C756518013A010555496E743816022D3E0103496E74(i8 %arg) {
entry:
  %while11_v5 = icmp uge i8 %arg, 48
  br i1 %while11_v5, label %while11_bool118143_rhs, label %while11_exit
while11_bool118143_rhs:
  %while11_v8 = icmp ule i8 %arg, 57
  br i1 %while11_v8, label %while11_body, label %while11_exit
while11_body:
  br label %if11_then
while11_exit:
  br label %if11_merge
if11_then:
  %v15 = sub i8 %arg, 48
  %v14 = zext i8 %v15 to i32
  ret i32 %v14
if11_merge:
  %while26_v20 = icmp uge i8 %arg, 97
  br i1 %while26_v20, label %while26_bool118158_rhs, label %while26_exit
while26_bool118158_rhs:
  %while26_v23 = icmp ule i8 %arg, 102
  br i1 %while26_v23, label %while26_body, label %while26_exit
while26_body:
  br label %if26_then
while26_exit:
  br label %if26_merge
if26_then:
  %v31 = sub i8 %arg, 97
  %v30 = zext i8 %v31 to i32
  %v29 = add i32 %v30, 10
  ret i32 %v29
if26_merge:
  %v52 = sub i32 0, 1
  %while43_v37 = icmp uge i8 %arg, 65
  br i1 %while43_v37, label %while43_bool118175_rhs, label %while43_exit
while43_bool118175_rhs:
  %while43_v40 = icmp ule i8 %arg, 70
  br i1 %while43_v40, label %while43_body, label %while43_exit
while43_body:
  br label %if43_then
while43_exit:
  br label %if43_merge
if43_then:
  %v48 = sub i8 %arg, 65
  %v47 = zext i8 %v48 to i32
  %v46 = add i32 %v47, 10
  ret i32 %v46
if43_merge:
  ret i32 %v52
}
define i32 @sollang_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F727301070109617661696C61626C653201067075626C69630109617661696C61626C6518013A16022D3E0103496E74010475736573010B456E7669726F6E6D656E74() {
entry:
  %v24_subject_slot = alloca %sollang.enum.t1217, align 8
  %if84_result = alloca i32, align 4
  %if101_result = alloca i32, align 4
  %if129_result = alloca i32, align 4
  %if165_result = alloca i64, align 8
  %if182_result = alloca i64, align 8
  %if204_result = alloca i64, align 8
  %slot3 = alloca %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103011150726F6365737347726F7570436F756E7400, align 2
  %slot8 = alloca i32, align 4
  %slot9 = alloca %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00, align 8
  %slot10 = alloca %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00, align 8
  %slot13 = alloca %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500, align 4
  %slot17 = alloca %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00, align 8
  %v22_ptr = insertvalue %sollang.text poison, ptr @sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F727301070109617661696C61626C653201067075626C69630109617661696C61626C6518013A16022D3E0103496E74010475736573010B456E7669726F6E6D656E74_00, 0
  %v22 = insertvalue %sollang.text %v22_ptr, i64 15, 1
  %v64_ptr = insertvalue %sollang.text poison, ptr @sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F727301070109617661696C61626C653201067075626C69630109617661696C61626C6518013A16022D3E0103496E74010475736573010B456E7669726F6E6D656E74_01, 0
  %v64 = insertvalue %sollang.text %v64_ptr, i64 10, 1
  %v75_ptr = insertvalue %sollang.text poison, ptr @sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F727301070109617661696C61626C653201067075626C69630109617661696C61626C6518013A16022D3E0103496E74010475736573010B456E7669726F6E6D656E74_02, 0
  %v75 = insertvalue %sollang.text %v75_ptr, i64 22, 1
  %v21 = call %sollang.enum.t1217 @sollang_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010D636F6E66696775726174696F6E5E010D636F6E66696775726174696F6E01036B657918013A0104546578740E012C0105726164697818013A0105496E74333216022D3E01064F7074696F6E1E013C010655496E7433321F013E010475736573010B456E7669726F6E6D656E74(%sollang.text %v22, i32 10)
  %v24_tag = extractvalue %sollang.enum.t1217 %v21, 0
  store %sollang.enum.t1217 %v21, ptr %v24_subject_slot, align 8
  %v24_is_arm0 = icmp eq i32 %v24_tag, 1
  br i1 %v24_is_arm0, label %match118493_arm0, label %match118493_next0
match118493_arm0:
  %v24_arm0_payload = getelementptr inbounds %sollang.enum.t1217, ptr %v24_subject_slot, i32 0, i32 1
  %v26 = load i32, ptr %v24_arm0_payload, align 4
  %while36_v30 = icmp ugt i32 %v26, 0
  br i1 %while36_v30, label %while36_bool118498_rhs, label %while36_exit
while36_bool118498_rhs:
  %while36_v33 = icmp ule i32 %v26, 65535
  br i1 %while36_v33, label %while36_body, label %while36_exit
while36_body:
  br label %if36_then
while36_exit:
  br label %if36_merge
if36_then:
  %v40 = freeze i32 %v26
  %v39_conversion_upper_valid = icmp ule i32 %v26, 2147483647
  br i1 %v39_conversion_upper_valid, label %v39_conversion_upper_ok, label %v39_conversion_upper_fail
v39_conversion_upper_fail:
  %v39_conversion_upper_diagnostic = alloca [122 x i8], align 1
  store [122 x i8] c"\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\61\76\61\69\6C\61\62\6C\65\3A\6E\75\6D\65\72\69\63\5F\63\6F\6E\76\65\72\73\69\6F\6E\5F\75\70\70\65\72", ptr %v39_conversion_upper_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v39_conversion_upper_diagnostic, i64 122, i1 false)
  call void @llvm.trap()
  unreachable
v39_conversion_upper_ok:
  %v39 = add i32 %v26, 0
  ret i32 %v39
if36_merge:
  br label %match118493_merge
match118493_next0:
  %v24_is_arm1 = icmp eq i32 %v24_tag, 0
  br i1 %v24_is_arm1, label %match118493_arm1, label %match118493_next1
match118493_arm1:
  %v24_arm1_payload = getelementptr inbounds %sollang.enum.t1217, ptr %v24_subject_slot, i32 0, i32 1
  %v42 = load i32, ptr %v24_arm1_payload, align 4
  br label %match118493_merge
match118493_next1:
  call void @llvm.trap()
  unreachable
match118493_merge:
  %native_target_118513 = load ptr, ptr @sollang_native_function_m145_s19, align 8
  %v44 = call i64 %native_target_118513()
  %v45 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103011150726F6365737347726F7570436F756E7400 poison, i16 0, 0
  %v48 = freeze i64 %v44
  store %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103011150726F6365737347726F7570436F756E7400 %v45, ptr %slot3, align 2
  %v49 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103011150726F6365737347726F7570436F756E7400, ptr %slot3, align 2
  %native_target_118516 = load ptr, ptr @sollang_native_function_m145_s23, align 8
  %v47 = call i32 %native_target_118516(i64 %v48, ptr %callref47_arg1_address, i64 0)
  %while59_v54 = freeze i32 %v47
  %while59_v53 = icmp ne i32 %while59_v54, 0
  br i1 %while59_v53, label %while59_body, label %while59_bool118521_rhs
while59_bool118521_rhs:
  %while59_v57 = call i32 %native_target_118526()
  %while59_v56 = icmp ne i32 %while59_v57, 122
  br i1 %while59_v56, label %while59_body, label %while59_exit
while59_body:
  br label %if59_then
while59_exit:
  br label %if59_merge
if59_then:
  %member_assign118530_field_address = getelementptr inbounds %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103011150726F6365737347726F7570436F756E7400, ptr %slot3, i32 0, i32 0
  store i16 1, ptr %member_assign118530_field_address, align 2
  br label %if59_merge
if59_merge:
  %v67 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103011150726F6365737347726F7570436F756E7400, ptr %slot3, align 2
  %v66 = extractvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103011150726F6365737347726F7570436F756E7400 %v67, 0
  %v65 = icmp ugt i16 %v66, 1
  %v63 = call i1 @sollang_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010E636F6E66696775726564466C616751010E636F6E66696775726564466C616701036B657918013A0104546578740E012C010866616C6C6261636B18013A0104426F6F6C16022D3E0104426F6F6C010475736573010B456E7669726F6E6D656E74(%sollang.text %v64, i1 %v65)
  %v78 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103011150726F6365737347726F7570436F756E7400, ptr %slot3, align 2
  %v77 = extractvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103011150726F6365737347726F7570436F756E7400 %v78, 0
  %v76 = icmp ugt i16 %v77, 1
  %while69_v71 = call i16 %native_target_118540()
  %while69_v70 = icmp ugt i16 %while69_v71, 1
  br i1 %while69_v70, label %while69_bool118538_rhs, label %while69_exit
while69_bool118538_rhs:
  %while69_v73 = freeze i1 %v63
  br i1 %while69_v73, label %while69_body, label %while69_exit
while69_body:
  br label %logical118538_merge
while69_exit:
  br label %logical118538_merge
logical118538_merge:
  %v69 = phi i1 [ true, %while69_body ], [ false, %while69_exit ]
  %v74 = call i1 @sollang_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010E636F6E66696775726564466C616751010E636F6E66696775726564466C616701036B657918013A0104546578740E012C010866616C6C6261636B18013A0104426F6F6C16022D3E0104426F6F6C010475736573010B456E7669726F6E6D656E74(%sollang.text %v75, i1 %v76)
  %while84_v82 = freeze i1 %v69
  br i1 %while84_v82, label %while84_bool118550_rhs, label %while84_exit
while84_bool118550_rhs:
  %while84_v83 = freeze i1 %v74
  br i1 %while84_v83, label %while84_body, label %while84_exit
while84_body:
  br label %if84_then
while84_exit:
  br label %if84_else
if84_then:
  %native_target_118556 = load ptr, ptr @sollang_native_function_m145_s27, align 8
  %v87 = call i32 %native_target_118556(i16 zeroext 65535)
  %v86_conversion_upper_valid = icmp ule i32 %v87, 2147483647
  br i1 %v86_conversion_upper_valid, label %v86_conversion_upper_ok, label %v86_conversion_upper_fail
v86_conversion_upper_fail:
  %v86_conversion_upper_diagnostic = alloca [122 x i8], align 1
  store [122 x i8] c"\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\61\76\61\69\6C\61\62\6C\65\3A\6E\75\6D\65\72\69\63\5F\63\6F\6E\76\65\72\73\69\6F\6E\5F\75\70\70\65\72", ptr %v86_conversion_upper_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v86_conversion_upper_diagnostic, i64 122, i1 false)
  call void @llvm.trap()
  unreachable
v86_conversion_upper_ok:
  %v86 = add i32 %v87, 0
  store i32 %v86, ptr %if84_result, align 4
  br label %if84_merge
if84_else:
  %v90 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00 poison, i64 0, 0
  store %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00 %v90, ptr %slot9, align 8
  %v92 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00 poison, i64 0, 0
  store %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00 %v92, ptr %slot10, align 8
  %v97 = freeze i64 %v44
  %v98 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00, ptr %slot9, align 8
  %v99 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00, ptr %slot10, align 8
  %native_target_118565 = load ptr, ptr @sollang_native_function_m145_s20, align 8
  %v96 = call i32 %native_target_118565(i64 %v97, ptr %callref96_arg1_address, ptr %callref96_arg2_address)
  %v95 = icmp eq i32 %v96, 0
  br i1 %v95, label %if101_then, label %if101_else
if101_then:
  store i32 1, ptr %if101_result, align 4
  br label %if101_merge
if101_else:
  store i32 0, ptr %slot8, align 4
  br label %while111_header
while111_header:
  %while111_v109 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00, ptr %slot9, align 8
  %while111_v108 = extractvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00 %while111_v109, 0
  %while111_v107 = icmp ugt i64 %while111_v108, 0
  br i1 %while111_v107, label %while111_body, label %while111_exit
while111_body:
  %v114 = load i32, ptr %slot8, align 4
  %v118 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00, ptr %slot9, align 8
  %v117 = extractvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00 %v118, 0
  %v116 = urem i64 %v117, 2
  %v115_conversion_upper_valid = icmp ule i64 %v116, 2147483647
  br i1 %v115_conversion_upper_valid, label %v115_conversion_upper_ok, label %v115_conversion_upper_fail
v115_conversion_upper_fail:
  %v115_conversion_upper_diagnostic = alloca [122 x i8], align 1
  store [122 x i8] c"\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\61\76\61\69\6C\61\62\6C\65\3A\6E\75\6D\65\72\69\63\5F\63\6F\6E\76\65\72\73\69\6F\6E\5F\75\70\70\65\72", ptr %v115_conversion_upper_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v115_conversion_upper_diagnostic, i64 122, i1 false)
  call void @llvm.trap()
  unreachable
v115_conversion_upper_ok:
  %v115 = trunc i64 %v116 to i32
  %v113 = add i32 %v114, %v115
  store i32 %v113, ptr %slot8, align 4
  %v123 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00, ptr %slot9, align 8
  %v122 = extractvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00 %v123, 0
  %v121 = udiv i64 %v122, 2
  %member_assign118589_field_address = getelementptr inbounds %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00, ptr %slot9, i32 0, i32 0
  store i64 %v121, ptr %member_assign118589_field_address, align 8
  br label %while111_header
while111_exit:
  %v127 = load i32, ptr %slot8, align 4
  %v126 = icmp eq i32 %v127, 0
  br i1 %v126, label %if129_then, label %if129_else
if129_then:
  store i32 64, ptr %if129_result, align 4
  br label %if129_merge
if129_else:
  %v133 = load i32, ptr %slot8, align 4
  store i32 %v133, ptr %if129_result, align 4
  br label %if129_merge
if129_merge:
  %v129 = load i32, ptr %if129_result, align 4
  store i32 %v129, ptr %if101_result, align 4
  br label %if101_merge
if101_merge:
  %v101 = load i32, ptr %if101_result, align 4
  store i32 %v101, ptr %if84_result, align 4
  %cleanup1185532_b118479_current = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00, ptr %slot10, align 8
  call void @sollang_drop_t461(%sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00 %cleanup1185532_b118479_current)
  %cleanup1185532_b118478_current = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00, ptr %slot9, align 8
  call void @sollang_drop_t461(%sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010C416666696E6974794D61736B00 %cleanup1185532_b118478_current)
  br label %if84_merge
if84_merge:
  %v84 = load i32, ptr %if84_result, align 4
  store i32 %v84, ptr %slot8, align 4
  %v134_f0 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500 poison, i32 0, 0
  %v134 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500 %v134_f0, i32 0, 1
  store %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500 %v134, ptr %slot13, align 4
  %v142 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500, ptr %slot13, align 4
  %native_target_118608 = load ptr, ptr @sollang_native_function_m145_s30, align 8
  %v139 = call i32 %native_target_118608(i64 0, i32 15, ptr %callref139_arg2_address, i32 8, i64 0)
  %v138 = icmp ne i32 %v139, 0
  br i1 %v138, label %if146_then, label %if146_merge
if146_then:
  %v151 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500, ptr %slot13, align 4
  %v150 = extractvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500 %v151, 0
  %v149 = urem i32 %v150, 2
  %v148 = icmp eq i32 %v149, 1
  %while165_v156 = freeze i1 %v148
  br i1 %while165_v156, label %while165_bool118624_rhs, label %while165_exit
while165_bool118624_rhs:
  %while165_v161 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500, ptr %slot13, align 4
  %while165_v160 = extractvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500 %while165_v161, 0
  %while165_v159 = udiv i32 %while165_v160, 4
  %while165_v158 = urem i32 %while165_v159, 2
  %while165_v157 = icmp eq i32 %while165_v158, 1
  br i1 %while165_v157, label %while165_body, label %while165_exit
while165_body:
  br label %if165_then
while165_exit:
  br label %if165_else
if165_then:
  %v169 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500, ptr %slot13, align 4
  %v168 = extractvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500 %v169, 1
  %v167 = zext i32 %v168 to i64
  store i64 %v167, ptr %if165_result, align 8
  br label %if165_merge
if165_else:
  %while182_v173 = freeze i1 %v148
  br i1 %while182_v173, label %while182_bool118641_rhs, label %while182_exit
while182_bool118641_rhs:
  %while182_v178 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500, ptr %slot13, align 4
  %while182_v177 = extractvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500 %while182_v178, 0
  %while182_v176 = udiv i32 %while182_v177, 16
  %while182_v175 = urem i32 %while182_v176, 2
  %while182_v174 = icmp eq i32 %while182_v175, 1
  br i1 %while182_v174, label %while182_body, label %while182_exit
while182_body:
  br label %if182_then
while182_exit:
  br label %if182_else
if182_then:
  %v187 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500, ptr %slot13, align 4
  %v186 = extractvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500 %v187, 1
  %v185 = udiv i32 %v186, 65536
  %v184 = zext i32 %v185 to i64
  store i64 %v184, ptr %if182_result, align 8
  br label %if182_merge
if182_else:
  %v190 = add i64 0, 0
  store i64 %v190, ptr %if182_result, align 8
  br label %if182_merge
if182_merge:
  %v182 = load i64, ptr %if182_result, align 8
  store i64 %v182, ptr %if165_result, align 8
  br label %if165_merge
if165_merge:
  %v165 = load i64, ptr %if165_result, align 8
  %while200_v195 = freeze i64 %v165
  %while200_v194 = icmp ugt i64 %while200_v195, 0
  br i1 %while200_v194, label %while200_bool118662_rhs, label %while200_exit
while200_bool118662_rhs:
  %while200_v198 = freeze i64 %v165
  %while200_v197 = icmp ult i64 %while200_v198, 10000
  br i1 %while200_v197, label %while200_body, label %while200_exit
while200_body:
  br label %if200_then
while200_exit:
  br label %if200_merge
if200_then:
  %v203 = freeze i1 %v69
  br i1 %v203, label %if204_then, label %if204_else
if204_then:
  %native_target_118676 = load ptr, ptr @sollang_native_function_m145_s27, align 8
  %v207 = call i32 %native_target_118676(i16 zeroext 65535)
  %v206 = zext i32 %v207 to i64
  store i64 %v206, ptr %if204_result, align 8
  br label %if204_merge
if204_else:
  %v210_f0 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 poison, i16 0, 0
  %v210_f1 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 %v210_f0, i16 0, 1
  %v210_f2 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 %v210_f1, i32 0, 2
  %v210_f3 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 %v210_f2, i64 0, 3
  %v210_f4 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 %v210_f3, i64 0, 4
  %v210_f5 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 %v210_f4, i64 0, 5
  %v210_f6 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 %v210_f5, i32 0, 6
  %v210_f7 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 %v210_f6, i32 0, 7
  %v210_f8 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 %v210_f7, i32 0, 8
  %v210_f9 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 %v210_f8, i16 0, 9
  %v210 = insertvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 %v210_f9, i16 0, 10
  store %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 %v210, ptr %slot17, align 8
  %v223 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00, ptr %slot17, align 8
  %native_target_118691 = load ptr, ptr @sollang_native_function_m145_s29, align 8
  call void %native_target_118691(ptr %callref222_arg0_address)
  %v226 = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00, ptr %slot17, align 8
  %v225 = extractvalue %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 %v226, 6
  %v224 = zext i32 %v225 to i64
  store i64 %v224, ptr %if204_result, align 8
  %cleanup1186732_b118486_current = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00, ptr %slot17, align 8
  call void @sollang_drop_t463(%sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103010A53797374656D496E666F00 %cleanup1186732_b118486_current)
  br label %if204_merge
if204_merge:
  %v204 = load i64, ptr %if204_result, align 8
  %v231 = freeze i64 %v165
  %v232 = freeze i64 %v204
  %v230 = mul i64 %v231, %v232
  %v229 = add i64 %v230, 9999
  %v228 = udiv i64 %v229, 10000
  %v227_conversion_upper_valid = icmp ule i64 %v228, 2147483647
  br i1 %v227_conversion_upper_valid, label %v227_conversion_upper_ok, label %v227_conversion_upper_fail
v227_conversion_upper_fail:
  %v227_conversion_upper_diagnostic = alloca [122 x i8], align 1
  store [122 x i8] c"\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\61\76\61\69\6C\61\62\6C\65\3A\6E\75\6D\65\72\69\63\5F\63\6F\6E\76\65\72\73\69\6F\6E\5F\75\70\70\65\72", ptr %v227_conversion_upper_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v227_conversion_upper_diagnostic, i64 122, i1 false)
  call void @llvm.trap()
  unreachable
v227_conversion_upper_ok:
  %v227 = trunc i64 %v228 to i32
  %v237 = freeze i32 %v227
  %v238 = load i32, ptr %slot8, align 4
  %v236 = icmp slt i32 %v237, %v238
  br i1 %v236, label %if239_then, label %if239_merge
if239_then:
  %v241 = freeze i32 %v227
  store i32 %v241, ptr %slot8, align 4
  br label %if239_merge
if239_merge:
  br label %if200_merge
if200_merge:
  br label %if146_merge
if146_merge:
  %v242 = load i32, ptr %slot8, align 4
  %drop3_current = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103011150726F6365737347726F7570436F756E7400, ptr %slot3, align 2
  call void @sollang_drop_t462(%sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730103011150726F6365737347726F7570436F756E7400 %drop3_current)
  %drop13_current = load %sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500, ptr %slot13, align 4
  call void @sollang_drop_t460(%sollang.struct.x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F7273010301074370755261746500 %drop13_current)
  ret i32 %v242
}
define %sollang.enum.t1217 @sollang_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010D636F6E66696775726174696F6E5E010D636F6E66696775726174696F6E01036B657918013A0104546578740E012C0105726164697818013A0105496E74333216022D3E01064F7074696F6E1E013C010655496E7433321F013E010475736573010B456E7669726F6E6D656E74(%sollang.text %arg, i32 %arg1) {
entry:
  %v36_environment_slot = alloca %sollang.enum.t1187, align 8
  %v38_subject_slot = alloca %sollang.enum.t1187, align 8
  %v38_result = alloca %sollang.text, align 8
  %if47_result = alloca %sollang.text, align 8
  %v52_environment_slot = alloca %sollang.enum.t1187, align 8
  %v54_subject_slot = alloca %sollang.enum.t1187, align 8
  %v54_result = alloca %sollang.text, align 8
  %v67_environment_slot = alloca %sollang.enum.t1187, align 8
  %v69_subject_slot = alloca %sollang.enum.t1187, align 8
  %v69_result = alloca %sollang.text, align 8
  %slot4 = alloca %sollang.array.i32, align 1
  %slot6 = alloca %sollang.array.i32, align 1
  %slot9 = alloca i64, align 8
  %slot12 = alloca i1, align 1
  %slot20 = alloca i64, align 8
  %v25_capacity_i64 = add i64 0, 0
  %v25_capacity_positive = icmp ugt i64 %v25_capacity_i64, 0
  %v25_allocation = select i1 %v25_capacity_positive, i64 %v25_capacity_i64, i64 1
  %v25_capacity_valid = icmp sge i64 %v25_capacity_i64, 0
  %v25_data = call ptr @sollang_raw_arena_create(i64 %v25_allocation, i1 %v25_capacity_valid)
  %v25_0 = insertvalue %sollang.array.i32 poison, ptr %v25_data, 0
  %v25_1 = insertvalue %sollang.array.i32 %v25_0, i64 0, 1
  %v25 = insertvalue %sollang.array.i32 %v25_1, i64 %v25_allocation, 2
  store %sollang.array.i32 %v25, ptr %slot4, align 1
  %v28_ptr = insertvalue %sollang.text poison, ptr @sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010D636F6E66696775726174696F6E5E010D636F6E66696775726174696F6E01036B657918013A0104546578740E012C0105726164697818013A0105496E74333216022D3E01064F7074696F6E1E013C010655496E7433321F013E010475736573010B456E7669726F6E6D656E74_00, 0
  %v28 = insertvalue %sollang.text %v28_ptr, i64 11, 1
  %v29 = load %sollang.array.i32, ptr %slot4, align 1
  %materialize27_root0_ptr = extractvalue %sollang.text %arg, 0
  %materialize27_root0_length = extractvalue %sollang.text %arg, 1
  %materialize27_source_length0 = add i64 0, 7
  %materialize27_source_length1 = add i64 %materialize27_source_length0, %materialize27_root0_length
  %materialize27_ptr_addr = getelementptr inbounds %sollang.array.i32, ptr %slot4, i32 0, i32 0
  %materialize27_length_addr = getelementptr inbounds %sollang.array.i32, ptr %slot4, i32 0, i32 1
  %materialize27_capacity_addr = getelementptr inbounds %sollang.array.i32, ptr %slot4, i32 0, i32 2
  %materialize27_data = load ptr, ptr %materialize27_ptr_addr, align 8
  %materialize27_used = load i64, ptr %materialize27_length_addr, align 8
  %materialize27_capacity = load i64, ptr %materialize27_capacity_addr, align 8
  %materialize27_end = add i64 %materialize27_used, %materialize27_source_length1
  %materialize27_fits = icmp ule i64 %materialize27_end, %materialize27_capacity
  br i1 %materialize27_fits, label %materialize27_keep, label %materialize27_grow
materialize27_keep:
  br label %materialize27_ready
materialize27_grow:
  %materialize27_doubled = shl i64 %materialize27_capacity, 1
  %materialize27_doubled_enough = icmp uge i64 %materialize27_doubled, %materialize27_end
  %materialize27_new_capacity = select i1 %materialize27_doubled_enough, i64 %materialize27_doubled, i64 %materialize27_end
  %materialize27_grown = call ptr @sollang_resize(ptr %materialize27_data, i64 %materialize27_used, i64 %materialize27_new_capacity)
  %materialize27_allocation_ok = icmp ne ptr %materialize27_grown, null
  br i1 %materialize27_allocation_ok, label %materialize27_allocation_ready, label %materialize27_allocation_failed
materialize27_allocation_failed:
  %materialize27_allocation_diagnostic = alloca [119 x i8], align 1
  store [119 x i8] c"\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\63\6F\6E\66\69\67\75\72\61\74\69\6F\6E\3A\61\6C\6C\6F\63\61\74\69\6F\6E\5F\66\61\69\6C\65\64", ptr %materialize27_allocation_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %materialize27_allocation_diagnostic, i64 119, i1 false)
  call void @llvm.trap()
  unreachable
materialize27_allocation_ready:
  br label %materialize27_ready
materialize27_ready:
  %materialize27_pointer = phi ptr [ %materialize27_data, %materialize27_keep ], [ %materialize27_grown, %materialize27_allocation_ready ]
  %materialize27_final_capacity = phi i64 [ %materialize27_capacity, %materialize27_keep ], [ %materialize27_new_capacity, %materialize27_allocation_ready ]
  %materialize27_target = getelementptr i8, ptr %materialize27_pointer, i64 %materialize27_used
  %materialize27_copy_offset0 = add i64 0, 0
  %materialize27_literal0_target = getelementptr i8, ptr %materialize27_target, i64 %materialize27_copy_offset0
  %materialize27_literal0_source = getelementptr i8, ptr @sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010D636F6E66696775726174696F6E5E010D636F6E66696775726174696F6E01036B657918013A0104546578740E012C0105726164697818013A0105496E74333216022D3E01064F7074696F6E1E013C010655496E7433321F013E010475736573010B456E7669726F6E6D656E74_00, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr %materialize27_literal0_target, ptr %materialize27_literal0_source, i64 7, i1 false)
  %materialize27_copy_offset1 = add i64 %materialize27_copy_offset0, 7
  %materialize27_root0_target = getelementptr i8, ptr %materialize27_target, i64 %materialize27_copy_offset1
  call void @llvm.memcpy.p0.p0.i64(ptr %materialize27_root0_target, ptr %materialize27_root0_ptr, i64 %materialize27_root0_length, i1 false)
  %materialize27_copy_offset2 = add i64 %materialize27_copy_offset1, %materialize27_root0_length
  %materialize27_suffix_target = getelementptr i8, ptr %materialize27_target, i64 %materialize27_copy_offset2
  %materialize27_suffix_source = getelementptr i8, ptr @sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010D636F6E66696775726174696F6E5E010D636F6E66696775726174696F6E01036B657918013A0104546578740E012C0105726164697818013A0105496E74333216022D3E01064F7074696F6E1E013C010655496E7433321F013E010475736573010B456E7669726F6E6D656E74_00, i64 11
  call void @llvm.memcpy.p0.p0.i64(ptr %materialize27_suffix_target, ptr %materialize27_suffix_source, i64 0, i1 false)
  store ptr %materialize27_pointer, ptr %materialize27_ptr_addr, align 8
  store i64 %materialize27_end, ptr %materialize27_length_addr, align 8
  store i64 %materialize27_final_capacity, ptr %materialize27_capacity_addr, align 8
  %v27_0 = insertvalue %sollang.text poison, ptr %materialize27_target, 0
  %v27 = insertvalue %sollang.text %v27_0, i64 %materialize27_source_length1, 1
  %v30_capacity_i64 = add i64 0, 0
  %v30_capacity_positive = icmp ugt i64 %v30_capacity_i64, 0
  %v30_allocation = select i1 %v30_capacity_positive, i64 %v30_capacity_i64, i64 1
  %v30_capacity_valid = icmp sge i64 %v30_capacity_i64, 0
  %v30_data = call ptr @sollang_raw_arena_create(i64 %v30_allocation, i1 %v30_capacity_valid)
  %v30_0 = insertvalue %sollang.array.i32 poison, ptr %v30_data, 0
  %v30_1 = insertvalue %sollang.array.i32 %v30_0, i64 0, 1
  %v30 = insertvalue %sollang.array.i32 %v30_1, i64 %v30_allocation, 2
  store %sollang.array.i32 %v30, ptr %slot6, align 1
  %v33_ptr = insertvalue %sollang.text poison, ptr @sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010D636F6E66696775726174696F6E5E010D636F6E66696775726174696F6E01036B657918013A0104546578740E012C0105726164697818013A0105496E74333216022D3E01064F7074696F6E1E013C010655496E7433321F013E010475736573010B456E7669726F6E6D656E74_01, 0
  %v33 = insertvalue %sollang.text %v33_ptr, i64 12, 1
  %v34 = load %sollang.array.i32, ptr %slot6, align 1
  %materialize32_root0_ptr = extractvalue %sollang.text %arg, 0
  %materialize32_root0_length = extractvalue %sollang.text %arg, 1
  %materialize32_source_length0 = add i64 0, 8
  %materialize32_source_length1 = add i64 %materialize32_source_length0, %materialize32_root0_length
  %materialize32_ptr_addr = getelementptr inbounds %sollang.array.i32, ptr %slot6, i32 0, i32 0
  %materialize32_length_addr = getelementptr inbounds %sollang.array.i32, ptr %slot6, i32 0, i32 1
  %materialize32_capacity_addr = getelementptr inbounds %sollang.array.i32, ptr %slot6, i32 0, i32 2
  %materialize32_data = load ptr, ptr %materialize32_ptr_addr, align 8
  %materialize32_used = load i64, ptr %materialize32_length_addr, align 8
  %materialize32_capacity = load i64, ptr %materialize32_capacity_addr, align 8
  %materialize32_end = add i64 %materialize32_used, %materialize32_source_length1
  %materialize32_fits = icmp ule i64 %materialize32_end, %materialize32_capacity
  br i1 %materialize32_fits, label %materialize32_keep, label %materialize32_grow
materialize32_keep:
  br label %materialize32_ready
materialize32_grow:
  %materialize32_doubled = shl i64 %materialize32_capacity, 1
  %materialize32_doubled_enough = icmp uge i64 %materialize32_doubled, %materialize32_end
  %materialize32_new_capacity = select i1 %materialize32_doubled_enough, i64 %materialize32_doubled, i64 %materialize32_end
  %materialize32_grown = call ptr @sollang_resize(ptr %materialize32_data, i64 %materialize32_used, i64 %materialize32_new_capacity)
  %materialize32_allocation_ok = icmp ne ptr %materialize32_grown, null
  br i1 %materialize32_allocation_ok, label %materialize32_allocation_ready, label %materialize32_allocation_failed
materialize32_allocation_failed:
  %materialize32_allocation_diagnostic = alloca [119 x i8], align 1
  store [119 x i8] c"\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\63\6F\6E\66\69\67\75\72\61\74\69\6F\6E\3A\61\6C\6C\6F\63\61\74\69\6F\6E\5F\66\61\69\6C\65\64", ptr %materialize32_allocation_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %materialize32_allocation_diagnostic, i64 119, i1 false)
  call void @llvm.trap()
  unreachable
materialize32_allocation_ready:
  br label %materialize32_ready
materialize32_ready:
  %materialize32_pointer = phi ptr [ %materialize32_data, %materialize32_keep ], [ %materialize32_grown, %materialize32_allocation_ready ]
  %materialize32_final_capacity = phi i64 [ %materialize32_capacity, %materialize32_keep ], [ %materialize32_new_capacity, %materialize32_allocation_ready ]
  %materialize32_target = getelementptr i8, ptr %materialize32_pointer, i64 %materialize32_used
  %materialize32_copy_offset0 = add i64 0, 0
  %materialize32_literal0_target = getelementptr i8, ptr %materialize32_target, i64 %materialize32_copy_offset0
  %materialize32_literal0_source = getelementptr i8, ptr @sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010D636F6E66696775726174696F6E5E010D636F6E66696775726174696F6E01036B657918013A0104546578740E012C0105726164697818013A0105496E74333216022D3E01064F7074696F6E1E013C010655496E7433321F013E010475736573010B456E7669726F6E6D656E74_01, i64 0
  call void @llvm.memcpy.p0.p0.i64(ptr %materialize32_literal0_target, ptr %materialize32_literal0_source, i64 8, i1 false)
  %materialize32_copy_offset1 = add i64 %materialize32_copy_offset0, 8
  %materialize32_root0_target = getelementptr i8, ptr %materialize32_target, i64 %materialize32_copy_offset1
  call void @llvm.memcpy.p0.p0.i64(ptr %materialize32_root0_target, ptr %materialize32_root0_ptr, i64 %materialize32_root0_length, i1 false)
  %materialize32_copy_offset2 = add i64 %materialize32_copy_offset1, %materialize32_root0_length
  %materialize32_suffix_target = getelementptr i8, ptr %materialize32_target, i64 %materialize32_copy_offset2
  %materialize32_suffix_source = getelementptr i8, ptr @sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010D636F6E66696775726174696F6E5E010D636F6E66696775726174696F6E01036B657918013A0104546578740E012C0105726164697818013A0105496E74333216022D3E01064F7074696F6E1E013C010655496E7433321F013E010475736573010B456E7669726F6E6D656E74_01, i64 12
  call void @llvm.memcpy.p0.p0.i64(ptr %materialize32_suffix_target, ptr %materialize32_suffix_source, i64 0, i1 false)
  store ptr %materialize32_pointer, ptr %materialize32_ptr_addr, align 8
  store i64 %materialize32_end, ptr %materialize32_length_addr, align 8
  store i64 %materialize32_final_capacity, ptr %materialize32_capacity_addr, align 8
  %v32_0 = insertvalue %sollang.text poison, ptr %materialize32_target, 0
  %v32 = insertvalue %sollang.text %v32_0, i64 %materialize32_source_length1, 1
  %v37 = freeze %sollang.text %v27
  %v36_environment_name_ptr = extractvalue %sollang.text %v37, 0
  %v36_environment_name_len = extractvalue %sollang.text %v37, 1
  %v36_environment_raw = call %sollang.environment_result @sollang_environment(ptr %v36_environment_name_ptr, i64 %v36_environment_name_len)
  %v36_environment_ptr = extractvalue %sollang.environment_result %v36_environment_raw, 0
  %v36_environment_len = extractvalue %sollang.environment_result %v36_environment_raw, 1
  %v36_environment_found = extractvalue %sollang.environment_result %v36_environment_raw, 2
  %v36_environment_ok = extractvalue %sollang.environment_result %v36_environment_raw, 3
  br i1 %v36_environment_ok, label %environment118229_prepare, label %environment118229_trap
environment118229_trap:
  call void @llvm.trap()
  unreachable
environment118229_prepare:
  store %sollang.enum.t1187 zeroinitializer, ptr %v36_environment_slot, align 8
  br i1 %v36_environment_found, label %environment118229_some, label %environment118229_merge
environment118229_some:
  %v36_environment_some_tag = getelementptr inbounds %sollang.enum.t1187, ptr %v36_environment_slot, i32 0, i32 0
  store i32 1, ptr %v36_environment_some_tag, align 4
  %v36_environment_text0 = insertvalue %sollang.text poison, ptr %v36_environment_ptr, 0
  %v36_environment_text = insertvalue %sollang.text %v36_environment_text0, i64 %v36_environment_len, 1
  %v36_environment_some_payload = getelementptr inbounds %sollang.enum.t1187, ptr %v36_environment_slot, i32 0, i32 1
  store %sollang.text %v36_environment_text, ptr %v36_environment_some_payload, align 8
  br label %environment118229_merge
environment118229_merge:
  %v36 = load %sollang.enum.t1187, ptr %v36_environment_slot, align 8
  %v38_tag = extractvalue %sollang.enum.t1187 %v36, 0
  store %sollang.enum.t1187 %v36, ptr %v38_subject_slot, align 8
  %v38_is_arm0 = icmp eq i32 %v38_tag, 1
  br i1 %v38_is_arm0, label %match118231_arm0, label %match118231_next0
match118231_arm0:
  %v38_arm0_payload = getelementptr inbounds %sollang.enum.t1187, ptr %v38_subject_slot, i32 0, i32 1
  %v40 = load %sollang.text, ptr %v38_arm0_payload, align 8
  %v45 = freeze %sollang.text %v40
  %v44 = extractvalue %sollang.text %v40, 1
  %v43 = icmp ugt i64 %v44, 0
  br i1 %v43, label %if47_then, label %if47_else
if47_then:
  %v49 = freeze %sollang.text %v40
  store %sollang.text %v40, ptr %if47_result, align 8
  br label %if47_merge
if47_else:
  %v53 = freeze %sollang.text %v32
  %v52_environment_name_ptr = extractvalue %sollang.text %v53, 0
  %v52_environment_name_len = extractvalue %sollang.text %v53, 1
  %v52_environment_raw = call %sollang.environment_result @sollang_environment(ptr %v52_environment_name_ptr, i64 %v52_environment_name_len)
  %v52_environment_ptr = extractvalue %sollang.environment_result %v52_environment_raw, 0
  %v52_environment_len = extractvalue %sollang.environment_result %v52_environment_raw, 1
  %v52_environment_found = extractvalue %sollang.environment_result %v52_environment_raw, 2
  %v52_environment_ok = extractvalue %sollang.environment_result %v52_environment_raw, 3
  br i1 %v52_environment_ok, label %environment118245_prepare, label %environment118245_trap
environment118245_trap:
  call void @llvm.trap()
  unreachable
environment118245_prepare:
  store %sollang.enum.t1187 zeroinitializer, ptr %v52_environment_slot, align 8
  br i1 %v52_environment_found, label %environment118245_some, label %environment118245_merge
environment118245_some:
  %v52_environment_some_tag = getelementptr inbounds %sollang.enum.t1187, ptr %v52_environment_slot, i32 0, i32 0
  store i32 1, ptr %v52_environment_some_tag, align 4
  %v52_environment_text0 = insertvalue %sollang.text poison, ptr %v52_environment_ptr, 0
  %v52_environment_text = insertvalue %sollang.text %v52_environment_text0, i64 %v52_environment_len, 1
  %v52_environment_some_payload = getelementptr inbounds %sollang.enum.t1187, ptr %v52_environment_slot, i32 0, i32 1
  store %sollang.text %v52_environment_text, ptr %v52_environment_some_payload, align 8
  br label %environment118245_merge
environment118245_merge:
  %v52 = load %sollang.enum.t1187, ptr %v52_environment_slot, align 8
  %v54_tag = extractvalue %sollang.enum.t1187 %v52, 0
  store %sollang.enum.t1187 %v52, ptr %v54_subject_slot, align 8
  %v54_is_arm0 = icmp eq i32 %v54_tag, 1
  br i1 %v54_is_arm0, label %match118247_arm0, label %match118247_next0
match118247_arm0:
  %v54_arm0_payload = getelementptr inbounds %sollang.enum.t1187, ptr %v54_subject_slot, i32 0, i32 1
  %v56 = load %sollang.text, ptr %v54_arm0_payload, align 8
  %v58 = freeze %sollang.text %v56
  store %sollang.text %v56, ptr %v54_result, align 8
  br label %match118247_merge
match118247_next0:
  %v54_is_arm1 = icmp eq i32 %v54_tag, 0
  br i1 %v54_is_arm1, label %match118247_arm1, label %match118247_next1
match118247_arm1:
  %v54_arm1_payload = getelementptr inbounds %sollang.enum.t1187, ptr %v54_subject_slot, i32 0, i32 1
  %v60 = load %sollang.text, ptr %v54_arm1_payload, align 8
  %v62_ptr = insertvalue %sollang.text poison, ptr @sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010D636F6E66696775726174696F6E5E010D636F6E66696775726174696F6E01036B657918013A0104546578740E012C0105726164697818013A0105496E74333216022D3E01064F7074696F6E1E013C010655496E7433321F013E010475736573010B456E7669726F6E6D656E74_02, 0
  %v62 = insertvalue %sollang.text %v62_ptr, i64 0, 1
  store %sollang.text %v62, ptr %v54_result, align 8
  br label %match118247_merge
match118247_next1:
  call void @llvm.trap()
  unreachable
match118247_merge:
  %v54 = load %sollang.text, ptr %v54_result, align 8
  store %sollang.text %v54, ptr %if47_result, align 8
  br label %if47_merge
if47_merge:
  %v47 = load %sollang.text, ptr %if47_result, align 8
  store %sollang.text %v47, ptr %v38_result, align 8
  br label %match118231_merge
match118231_next0:
  %v38_is_arm1 = icmp eq i32 %v38_tag, 0
  br i1 %v38_is_arm1, label %match118231_arm1, label %match118231_next1
match118231_arm1:
  %v38_arm1_payload = getelementptr inbounds %sollang.enum.t1187, ptr %v38_subject_slot, i32 0, i32 1
  %v64 = load %sollang.text, ptr %v38_arm1_payload, align 8
  %v68 = freeze %sollang.text %v32
  %v67_environment_name_ptr = extractvalue %sollang.text %v68, 0
  %v67_environment_name_len = extractvalue %sollang.text %v68, 1
  %v67_environment_raw = call %sollang.environment_result @sollang_environment(ptr %v67_environment_name_ptr, i64 %v67_environment_name_len)
  %v67_environment_ptr = extractvalue %sollang.environment_result %v67_environment_raw, 0
  %v67_environment_len = extractvalue %sollang.environment_result %v67_environment_raw, 1
  %v67_environment_found = extractvalue %sollang.environment_result %v67_environment_raw, 2
  %v67_environment_ok = extractvalue %sollang.environment_result %v67_environment_raw, 3
  br i1 %v67_environment_ok, label %environment118260_prepare, label %environment118260_trap
environment118260_trap:
  call void @llvm.trap()
  unreachable
environment118260_prepare:
  store %sollang.enum.t1187 zeroinitializer, ptr %v67_environment_slot, align 8
  br i1 %v67_environment_found, label %environment118260_some, label %environment118260_merge
environment118260_some:
  %v67_environment_some_tag = getelementptr inbounds %sollang.enum.t1187, ptr %v67_environment_slot, i32 0, i32 0
  store i32 1, ptr %v67_environment_some_tag, align 4
  %v67_environment_text0 = insertvalue %sollang.text poison, ptr %v67_environment_ptr, 0
  %v67_environment_text = insertvalue %sollang.text %v67_environment_text0, i64 %v67_environment_len, 1
  %v67_environment_some_payload = getelementptr inbounds %sollang.enum.t1187, ptr %v67_environment_slot, i32 0, i32 1
  store %sollang.text %v67_environment_text, ptr %v67_environment_some_payload, align 8
  br label %environment118260_merge
environment118260_merge:
  %v67 = load %sollang.enum.t1187, ptr %v67_environment_slot, align 8
  %v69_tag = extractvalue %sollang.enum.t1187 %v67, 0
  store %sollang.enum.t1187 %v67, ptr %v69_subject_slot, align 8
  %v69_is_arm0 = icmp eq i32 %v69_tag, 1
  br i1 %v69_is_arm0, label %match118262_arm0, label %match118262_next0
match118262_arm0:
  %v69_arm0_payload = getelementptr inbounds %sollang.enum.t1187, ptr %v69_subject_slot, i32 0, i32 1
  %v71 = load %sollang.text, ptr %v69_arm0_payload, align 8
  %v73 = freeze %sollang.text %v71
  store %sollang.text %v71, ptr %v69_result, align 8
  br label %match118262_merge
match118262_next0:
  %v69_is_arm1 = icmp eq i32 %v69_tag, 0
  br i1 %v69_is_arm1, label %match118262_arm1, label %match118262_next1
match118262_arm1:
  %v69_arm1_payload = getelementptr inbounds %sollang.enum.t1187, ptr %v69_subject_slot, i32 0, i32 1
  %v75 = load %sollang.text, ptr %v69_arm1_payload, align 8
  %v77_ptr = insertvalue %sollang.text poison, ptr @sollang_str_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010D636F6E66696775726174696F6E5E010D636F6E66696775726174696F6E01036B657918013A0104546578740E012C0105726164697818013A0105496E74333216022D3E01064F7074696F6E1E013C010655496E7433321F013E010475736573010B456E7669726F6E6D656E74_03, 0
  %v77 = insertvalue %sollang.text %v77_ptr, i64 0, 1
  store %sollang.text %v77, ptr %v69_result, align 8
  br label %match118262_merge
match118262_next1:
  call void @llvm.trap()
  unreachable
match118262_merge:
  %v69 = load %sollang.text, ptr %v69_result, align 8
  store %sollang.text %v69, ptr %v38_result, align 8
  br label %match118231_merge
match118231_next1:
  call void @llvm.trap()
  unreachable
match118231_merge:
  %v38 = load %sollang.text, ptr %v38_result, align 8
  %v78 = add i64 0, 0
  store i64 %v78, ptr %slot9, align 8
  br label %while85_header
while85_header:
  %while85_v82 = load i64, ptr %slot9, align 8
  %while85_v84 = freeze %sollang.text %v38
  %while85_v83 = extractvalue %sollang.text %while85_v84, 1
  %while85_v81 = icmp ult i64 %while85_v82, %while85_v83
  br i1 %while85_v81, label %while85_body, label %while85_exit
while85_body:
  %v88 = freeze %sollang.text %v38
  %v89 = load i64, ptr %slot9, align 8
  %v87_base = extractvalue %sollang.text %v88, 0
  %v87_address = getelementptr i8, ptr %v87_base, i64 %v89
  %v87 = load i8, ptr %v87_address, align 1
  %while102_v93 = freeze i8 %v87
  %while102_v92 = icmp eq i8 %while102_v93, 32
  br i1 %while102_v92, label %while102_body, label %while102_bool118284_rhs
while102_bool118284_rhs:
  %while102_v97 = freeze i8 %v87
  %while102_v96 = icmp uge i8 %while102_v97, 9
  br i1 %while102_v96, label %while102_bool118288_rhs, label %while102_exit
while102_bool118288_rhs:
  %while102_v100 = freeze i8 %v87
  %while102_v99 = icmp ule i8 %while102_v100, 13
  br i1 %while102_v99, label %while102_body, label %while102_exit
while102_body:
  br label %if102_merge
while102_exit:
  br label %if102_then
if102_then:
  br label %cleanup118297
cleanup118297:
  br label %while85_exit
if102_merge:
  %v106 = load i64, ptr %slot9, align 8
  %v105 = add i64 %v106, 1
  store i64 %v105, ptr %slot9, align 8
  br label %while85_header
while85_exit:
  store i1 0, ptr %slot12, align 1
  %v111 = load i64, ptr %slot9, align 8
  %v113 = freeze %sollang.text %v38
  %v112 = extractvalue %sollang.text %v113, 1
  %v110 = icmp ult i64 %v111, %v112
  br i1 %v110, label %if114_then, label %if114_merge
if114_then:
  %v117 = freeze %sollang.text %v38
  %v118 = load i64, ptr %slot9, align 8
  %v116_base = extractvalue %sollang.text %v117, 0
  %v116_address = getelementptr i8, ptr %v116_base, i64 %v118
  %v116 = load i8, ptr %v116_address, align 1
  %v120 = freeze i8 %v116
  %v119 = icmp eq i8 %v120, 45
  store i1 %v119, ptr %slot12, align 1
  %while130_v125 = freeze i8 %v116
  %while130_v124 = icmp eq i8 %while130_v125, 43
  br i1 %while130_v124, label %while130_body, label %while130_bool118316_rhs
while130_bool118316_rhs:
  %while130_v128 = freeze i8 %v116
  %while130_v127 = icmp eq i8 %while130_v128, 45
  br i1 %while130_v127, label %while130_body, label %while130_exit
while130_body:
  br label %if130_then
while130_exit:
  br label %if130_merge
if130_then:
  %v133 = load i64, ptr %slot9, align 8
  %v132 = add i64 %v133, 1
  store i64 %v132, ptr %slot9, align 8
  br label %if130_merge
if130_merge:
  br label %if114_merge
if114_merge:
  %v137 = load i64, ptr %slot9, align 8
  %v139 = freeze %sollang.text %v38
  %v138 = extractvalue %sollang.text %v139, 1
  %v136 = icmp uge i64 %v137, %v138
  br i1 %v136, label %if140_then, label %if140_merge
if140_then:
  %v143_enum_slot = alloca %sollang.enum.t1217, align 8
  store %sollang.enum.t1217 zeroinitializer, ptr %v143_enum_slot, align 8
  %v143_enum_tag = getelementptr inbounds %sollang.enum.t1217, ptr %v143_enum_slot, i32 0, i32 0
  store i32 0, ptr %v143_enum_tag, align 4
  %v143 = load %sollang.enum.t1217, ptr %v143_enum_slot, align 8
  ret %sollang.enum.t1217 %v143
if140_merge:
  %while155_v146 = icmp eq i32 %arg1, 16
  br i1 %while155_v146, label %while155_bool118338_rhs, label %while155_exit
while155_bool118338_rhs:
  %while155_v151 = load i64, ptr %slot9, align 8
  %while155_v150 = add i64 %while155_v151, 2
  %while155_v154 = freeze %sollang.text %v38
  %while155_v153 = extractvalue %sollang.text %while155_v154, 1
  %while155_v149 = icmp ult i64 %while155_v150, %while155_v153
  br i1 %while155_v149, label %while155_body, label %while155_exit
while155_body:
  br label %if155_then
while155_exit:
  br label %if155_merge
if155_then:
  %v158 = freeze %sollang.text %v38
  %v160 = load i64, ptr %slot9, align 8
  %v159 = add i64 %v160, 1
  %v157_base = extractvalue %sollang.text %v158, 0
  %v157_address = getelementptr i8, ptr %v157_base, i64 %v159
  %v157 = load i8, ptr %v157_address, align 1
  %v163 = freeze %sollang.text %v38
  %v165 = load i64, ptr %slot9, align 8
  %v164 = add i64 %v165, 2
  %v255_base = extractvalue %sollang.text %v163, 0
  %v255_address = getelementptr i8, ptr %v255_base, i64 %v164
  %v255 = load i8, ptr %v255_address, align 1
  %v162 = call i32 @sollang_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010564696769742101056469676974010576616C756518013A010555496E743816022D3E0103496E74(i8 %v255)
  %while184_v171 = freeze %sollang.text %v38
  %while184_v172 = load i64, ptr %slot9, align 8
  %while184_v170_base = extractvalue %sollang.text %while184_v171, 0
  %while184_v170_address = getelementptr i8, ptr %while184_v170_base, i64 %while184_v172
  %while184_v170 = load i8, ptr %while184_v170_address, align 1
  %while184_v169 = icmp eq i8 %while184_v170, 48
  br i1 %while184_v169, label %while184_bool118447_rhs, label %while184_exit
while184_bool118447_rhs:
  %while184_v176 = freeze i8 %v157
  %while184_v175 = icmp eq i8 %while184_v176, 120
  br i1 %while184_v175, label %while184_bool118361_rhs, label %while184_bool118367_rhs
while184_bool118367_rhs:
  %while184_v179 = freeze i8 %v157
  %while184_v178 = icmp eq i8 %while184_v179, 88
  br i1 %while184_v178, label %while184_bool118361_rhs, label %while184_exit
while184_bool118361_rhs:
  %while184_v182 = freeze i32 %v162
  %while184_v181 = icmp sge i32 %while184_v182, 0
  br i1 %while184_v181, label %while184_body, label %while184_exit
while184_body:
  br label %if184_then
while184_exit:
  br label %if184_merge
if184_then:
  %v187 = load i64, ptr %slot9, align 8
  %v186 = add i64 %v187, 2
  store i64 %v186, ptr %slot9, align 8
  br label %if184_merge
if184_merge:
  br label %if155_merge
if155_merge:
  %v189 = load i64, ptr %slot9, align 8
  %v190 = add i64 0, 0
  store i64 %v190, ptr %slot20, align 8
  br label %while197_header
while197_header:
  %while197_v194 = load i64, ptr %slot9, align 8
  %while197_v196 = freeze %sollang.text %v38
  %while197_v195 = extractvalue %sollang.text %while197_v196, 1
  %while197_v193 = icmp ult i64 %while197_v194, %while197_v195
  br i1 %while197_v193, label %while197_body, label %while197_exit
while197_body:
  %v200 = freeze %sollang.text %v38
  %v201 = load i64, ptr %slot9, align 8
  %v256_base = extractvalue %sollang.text %v200, 0
  %v256_address = getelementptr i8, ptr %v256_base, i64 %v201
  %v256 = load i8, ptr %v256_address, align 1
  %v199 = call i32 @sollang_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010564696769742101056469676974010576616C756518013A010555496E743816022D3E0103496E74(i8 %v256)
  %while211_v205 = freeze i32 %v199
  %while211_v204 = icmp slt i32 %while211_v205, 0
  br i1 %while211_v204, label %while211_body, label %while211_bool118396_rhs
while211_bool118396_rhs:
  %while211_v208 = freeze i32 %v199
  %while211_v209 = add i32 %arg1, 0
  %while211_v207 = icmp sge i32 %while211_v208, %while211_v209
  br i1 %while211_v207, label %while211_body, label %while211_exit
while211_body:
  br label %if211_then
while211_exit:
  br label %if211_merge
if211_then:
  br label %cleanup118406
cleanup118406:
  br label %while197_exit
if211_merge:
  %v216 = load i64, ptr %slot20, align 8
  %v218 = freeze i32 %arg1
  %v220 = freeze i32 %v199
  %v217_conversion_lower_valid = icmp sge i32 %arg1, 0
  br i1 %v217_conversion_lower_valid, label %v217_conversion_lower_ok, label %v217_conversion_lower_fail
v217_conversion_lower_fail:
  %v217_conversion_lower_diagnostic = alloca [126 x i8], align 1
  store [126 x i8] c"\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\63\6F\6E\66\69\67\75\72\61\74\69\6F\6E\3A\6E\75\6D\65\72\69\63\5F\63\6F\6E\76\65\72\73\69\6F\6E\5F\6C\6F\77\65\72", ptr %v217_conversion_lower_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v217_conversion_lower_diagnostic, i64 126, i1 false)
  call void @llvm.trap()
  unreachable
v217_conversion_lower_ok:
  %v217 = sext i32 %arg1 to i64
  %v219_conversion_lower_valid = icmp sge i32 %v220, 0
  br i1 %v219_conversion_lower_valid, label %v219_conversion_lower_ok, label %v219_conversion_lower_fail
v219_conversion_lower_fail:
  %v219_conversion_lower_diagnostic = alloca [126 x i8], align 1
  store [126 x i8] c"\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\63\6F\6E\66\69\67\75\72\61\74\69\6F\6E\3A\6E\75\6D\65\72\69\63\5F\63\6F\6E\76\65\72\73\69\6F\6E\5F\6C\6F\77\65\72", ptr %v219_conversion_lower_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v219_conversion_lower_diagnostic, i64 126, i1 false)
  call void @llvm.trap()
  unreachable
v219_conversion_lower_ok:
  %v219 = sext i32 %v220 to i64
  %v215 = mul i64 %v216, %v217
  %v214 = add i64 %v215, %v219
  store i64 %v214, ptr %slot20, align 8
  %v223 = load i64, ptr %slot20, align 8
  %v222 = icmp ugt i64 %v223, 4294967295
  br i1 %v222, label %if225_then, label %if225_merge
if225_then:
  %v228_enum_slot = alloca %sollang.enum.t1217, align 8
  store %sollang.enum.t1217 zeroinitializer, ptr %v228_enum_slot, align 8
  %v228_enum_tag = getelementptr inbounds %sollang.enum.t1217, ptr %v228_enum_slot, i32 0, i32 0
  store i32 0, ptr %v228_enum_tag, align 4
  %v228 = load %sollang.enum.t1217, ptr %v228_enum_slot, align 8
  ret %sollang.enum.t1217 %v228
if225_merge:
  %v230 = load i64, ptr %slot9, align 8
  %v229 = add i64 %v230, 1
  store i64 %v229, ptr %slot9, align 8
  br label %while197_header
while197_exit:
  %v234 = load i64, ptr %slot9, align 8
  %v235 = freeze i64 %v189
  %v233 = icmp eq i64 %v234, %v235
  br i1 %v233, label %if236_then, label %if236_merge
if236_then:
  %v239_enum_slot = alloca %sollang.enum.t1217, align 8
  store %sollang.enum.t1217 zeroinitializer, ptr %v239_enum_slot, align 8
  %v239_enum_tag = getelementptr inbounds %sollang.enum.t1217, ptr %v239_enum_slot, i32 0, i32 0
  store i32 0, ptr %v239_enum_tag, align 4
  %v239 = load %sollang.enum.t1217, ptr %v239_enum_slot, align 8
  ret %sollang.enum.t1217 %v239
if236_merge:
  %while246_v242 = load i1, ptr %slot12, align 1
  br i1 %while246_v242, label %while246_bool118434_rhs, label %while246_exit
while246_bool118434_rhs:
  %while246_v244 = load i64, ptr %slot20, align 8
  %while246_v243 = icmp ugt i64 %while246_v244, 0
  br i1 %while246_v243, label %while246_body, label %while246_exit
while246_body:
  br label %if246_then
while246_exit:
  br label %if246_merge
if246_then:
  %v250 = load i64, ptr %slot20, align 8
  %v248 = sub i64 4294967296, %v250
  store i64 %v248, ptr %slot20, align 8
  br label %if246_merge
if246_merge:
  %v253 = load i64, ptr %slot20, align 8
  %v252_conversion_upper_valid = icmp ule i64 %v253, 4294967295
  br i1 %v252_conversion_upper_valid, label %v252_conversion_upper_ok, label %v252_conversion_upper_fail
v252_conversion_upper_fail:
  %v252_conversion_upper_diagnostic = alloca [126 x i8], align 1
  store [126 x i8] c"\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\73\6F\6C\6C\61\6E\67\2E\63\6F\6D\70\69\6C\65\72\2E\72\75\6E\74\69\6D\65\2E\77\69\6E\64\6F\77\73\5F\70\72\6F\63\65\73\73\6F\72\73\2E\63\6F\6E\66\69\67\75\72\61\74\69\6F\6E\3A\6E\75\6D\65\72\69\63\5F\63\6F\6E\76\65\72\73\69\6F\6E\5F\75\70\70\65\72", ptr %v252_conversion_upper_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v252_conversion_upper_diagnostic, i64 126, i1 false)
  call void @llvm.trap()
  unreachable
v252_conversion_upper_ok:
  %v252 = trunc i64 %v253 to i32
  %v251_enum_slot = alloca %sollang.enum.t1217, align 8
  store %sollang.enum.t1217 zeroinitializer, ptr %v251_enum_slot, align 8
  %v251_enum_tag = getelementptr inbounds %sollang.enum.t1217, ptr %v251_enum_slot, i32 0, i32 0
  store i32 1, ptr %v251_enum_tag, align 4
  %v251_enum_payload = getelementptr inbounds %sollang.enum.t1217, ptr %v251_enum_slot, i32 0, i32 1
  store i32 %v252, ptr %v251_enum_payload, align 4
  %v251 = load %sollang.enum.t1217, ptr %v251_enum_slot, align 8
  ret %sollang.enum.t1217 %v251
}
define i1 @sollang_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010E636F6E66696775726564466C616751010E636F6E66696775726564466C616701036B657918013A0104546578740E012C010866616C6C6261636B18013A0104426F6F6C16022D3E0104426F6F6C010475736573010B456E7669726F6E6D656E74(%sollang.text %arg, i1 %arg1) {
entry:
  %v8_subject_slot = alloca %sollang.enum.t1217, align 8
  %v8_result = alloca i1, align 1
  %v5 = call %sollang.enum.t1217 @sollang_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F72730107010D636F6E66696775726174696F6E5E010D636F6E66696775726174696F6E01036B657918013A0104546578740E012C0105726164697818013A0105496E74333216022D3E01064F7074696F6E1E013C010655496E7433321F013E010475736573010B456E7669726F6E6D656E74(%sollang.text %arg, i32 16)
  %v8_tag = extractvalue %sollang.enum.t1217 %v5, 0
  store %sollang.enum.t1217 %v5, ptr %v8_subject_slot, align 8
  %v8_is_arm0 = icmp eq i32 %v8_tag, 1
  br i1 %v8_is_arm0, label %match118458_arm0, label %match118458_next0
match118458_arm0:
  %v8_arm0_payload = getelementptr inbounds %sollang.enum.t1217, ptr %v8_subject_slot, i32 0, i32 1
  %v10 = load i32, ptr %v8_arm0_payload, align 4
  %v13 = freeze i32 %v10
  %v12 = icmp ne i32 %v13, 0
  store i1 %v12, ptr %v8_result, align 1
  br label %match118458_merge
match118458_next0:
  %v8_is_arm1 = icmp eq i32 %v8_tag, 0
  br i1 %v8_is_arm1, label %match118458_arm1, label %match118458_next1
match118458_arm1:
  %v8_arm1_payload = getelementptr inbounds %sollang.enum.t1217, ptr %v8_subject_slot, i32 0, i32 1
  %v16 = load i32, ptr %v8_arm1_payload, align 4
  %v18 = freeze i1 %arg1
  store i1 %arg1, ptr %v8_result, align 1
  br label %match118458_merge
match118458_next1:
  call void @llvm.trap()
  unreachable
match118458_merge:
  %v8 = load i1, ptr %v8_result, align 1
  ret i1 %v8
}
; sollang.codegen.unit 2:
; sollang.codegen.key 15401771409445967692:2472194529643805222
define i32 @main() {
entry:
  call void @sollang_native_init()
  %v2 = call i32 @sollang_x2B736F6C6C616E672E636F6D70696C65722E72756E74696D652E77696E646F77735F70726F636573736F727301070109617661696C61626C653201067075626C69630109617661696C61626C6518013A16022D3E0103496E74010475736573010B456E7669726F6E6D656E74()
  %v4 = freeze i32 %v2
  call void @sollang_runtime_print_i32(i32 %v4, i1 true)
  call void @sollang_native_cleanup()
  call void @sollang_dispose_environment()
  call void @sollang_runtime_flush_stdout()
  ret i32 0
}
@sollang_environment_allocations = internal global ptr null
@sollang_environment_empty = internal constant [1 x i8] zeroinitializer, align 1
define internal i1 @sollang_track_environment_allocation(ptr %allocation) {
entry:
%node = call ptr @sollang_alloc(i64 16)
%ok = icmp ne ptr %node, null
br i1 %ok, label %store, label %fail

store:
store ptr %allocation, ptr %node, align 8
%next_slot = getelementptr i8, ptr %node, i64 8
%initial_head = load atomic ptr, ptr @sollang_environment_allocations acquire, align 8
br label %publish

publish:
%head = phi ptr [ %initial_head, %store ], [ %observed_head, %publish ]
store ptr %head, ptr %next_slot, align 8
%exchange = cmpxchg ptr @sollang_environment_allocations, ptr %head, ptr %node acq_rel acquire, align 8
%observed_head = extractvalue { ptr, i1 } %exchange, 0
%published = extractvalue { ptr, i1 } %exchange, 1
br i1 %published, label %done, label %publish

done:
ret i1 true

fail:
ret i1 false
}

define internal %sollang.environment_result @sollang_environment(ptr %name, i64 %name_len) {
entry:
  %empty = icmp eq i64 %name_len, 0
  br i1 %empty, label %missing, label %check_length

check_length:
  %name_fits_i32 = icmp ule i64 %name_len, 2147483647
  br i1 %name_fits_i32, label %validate, label %error

validate:
  %vi = phi i64 [ 0, %check_length ], [ %vnext, %valid_byte ]
  %validated = icmp eq i64 %vi, %name_len
  br i1 %validated, label %key_size, label %check_byte

check_byte:
  %name_byte_ptr = getelementptr i8, ptr %name, i64 %vi
  %name_byte = load i8, ptr %name_byte_ptr, align 1
  %name_byte_valid = icmp ne i8 %name_byte, 0
  br i1 %name_byte_valid, label %valid_byte, label %error

valid_byte:
  %vnext = add i64 %vi, 1
  br label %validate

key_size:
  %name_len32 = trunc i64 %name_len to i32
  %wide_chars = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %name, i32 %name_len32, ptr null, i32 0)
  %wide_valid = icmp sgt i32 %wide_chars, 0
  br i1 %wide_valid, label %key_alloc, label %error

key_alloc:
  %wide_chars_plus_null = add i32 %wide_chars, 1
  %wide_chars64 = zext i32 %wide_chars_plus_null to i64
  %key_bytes = mul i64 %wide_chars64, 2
  %wide_key = call ptr @sollang_alloc(i64 %key_bytes)
  %key_ok = icmp ne ptr %wide_key, null
  br i1 %key_ok, label %key_convert, label %error

key_convert:
  %key_written = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %name, i32 %name_len32, ptr %wide_key, i32 %wide_chars)
  %key_converted = icmp eq i32 %key_written, %wide_chars
  br i1 %key_converted, label %key_terminate, label %free_key_error

key_terminate:
  %key_end = getelementptr i16, ptr %wide_key, i32 %wide_chars
  store i16 0, ptr %key_end, align 2
  call void @SetLastError(i32 0)
  %required = call i32 @GetEnvironmentVariableW(ptr %wide_key, ptr null, i32 0)
  %last_error = call i32 @GetLastError()
  %has_size = icmp ne i32 %required, 0
  br i1 %has_size, label %value_alloc, label %zero_result

zero_result:
  call void @sollang_free(ptr %wide_key)
  br label %classify_zero

classify_zero:
  %zero_error = phi i32 [ %last_error, %zero_result ], [ %value_error, %free_wide_empty ]
  %not_found = icmp eq i32 %zero_error, 203
  br i1 %not_found, label %missing, label %check_empty_value

check_empty_value:
  %empty_succeeded = icmp eq i32 %zero_error, 0
  br i1 %empty_succeeded, label %empty_present, label %error

empty_present:
  %empty_ptr = getelementptr inbounds [1 x i8], ptr @sollang_environment_empty, i64 0, i64 0
  %e0 = insertvalue %sollang.environment_result zeroinitializer, ptr %empty_ptr, 0
  %e1 = insertvalue %sollang.environment_result %e0, i1 true, 2
  %e2 = insertvalue %sollang.environment_result %e1, i1 true, 3
  ret %sollang.environment_result %e2

value_alloc:
  %required64 = zext i32 %required to i64
  %wide_bytes = mul i64 %required64, 2
  %wide_value = call ptr @sollang_alloc(i64 %wide_bytes)
  %wide_value_ok = icmp ne ptr %wide_value, null
  br i1 %wide_value_ok, label %value_read, label %free_key_error

value_read:
  call void @SetLastError(i32 0)
  %value_chars = call i32 @GetEnvironmentVariableW(ptr %wide_key, ptr %wide_value, i32 %required)
  %value_error = call i32 @GetLastError()
  call void @sollang_free(ptr %wide_key)
  %value_empty = icmp eq i32 %value_chars, 0
  br i1 %value_empty, label %free_wide_empty, label %value_read_check

free_wide_empty:
  call void @sollang_free(ptr %wide_value)
  br label %classify_zero

value_read_check:
  %value_read_ok = icmp ult i32 %value_chars, %required
  br i1 %value_read_ok, label %utf8_size, label %free_wide_error

utf8_size:
  %utf8_bytes32 = call i32 @WideCharToMultiByte(i32 65001, i32 128, ptr %wide_value, i32 %value_chars, ptr null, i32 0, ptr null, ptr null)
  %utf8_size_ok = icmp sgt i32 %utf8_bytes32, 0
  br i1 %utf8_size_ok, label %utf8_alloc, label %free_wide_error

utf8_alloc:
  %utf8_bytes = zext i32 %utf8_bytes32 to i64
  %utf8 = call ptr @sollang_alloc(i64 %utf8_bytes)
  %utf8_ok = icmp ne ptr %utf8, null
  br i1 %utf8_ok, label %utf8_convert, label %free_wide_error

utf8_convert:
  %utf8_written = call i32 @WideCharToMultiByte(i32 65001, i32 128, ptr %wide_value, i32 %value_chars, ptr %utf8, i32 %utf8_bytes32, ptr null, ptr null)
  call void @sollang_free(ptr %wide_value)
  %utf8_converted = icmp eq i32 %utf8_written, %utf8_bytes32
  br i1 %utf8_converted, label %track, label %free_utf8_error

track:
  %tracked = call i1 @sollang_track_environment_allocation(ptr %utf8)
  br i1 %tracked, label %present, label %free_utf8_error

present:
  %p0 = insertvalue %sollang.environment_result poison, ptr %utf8, 0
  %p1 = insertvalue %sollang.environment_result %p0, i64 %utf8_bytes, 1
  %p2 = insertvalue %sollang.environment_result %p1, i1 true, 2
  %p3 = insertvalue %sollang.environment_result %p2, i1 true, 3
  ret %sollang.environment_result %p3

free_utf8_error:
  call void @sollang_free(ptr %utf8)
  br label %error

free_wide_error:
  call void @sollang_free(ptr %wide_value)
  br label %error

free_key_error:
  call void @sollang_free(ptr %wide_key)
  br label %error

missing:
  %m0 = insertvalue %sollang.environment_result zeroinitializer, i1 true, 3
  ret %sollang.environment_result %m0

error:
  ret %sollang.environment_result zeroinitializer
}

define internal void @sollang_dispose_environment() {
entry:
  %head = load ptr, ptr @sollang_environment_allocations, align 8
  br label %loop

loop:
  %node = phi ptr [ %head, %entry ], [ %next, %free_node ]
  %done = icmp eq ptr %node, null
  br i1 %done, label %finish, label %free_node

free_node:
  %allocation = load ptr, ptr %node, align 8
  %next_slot = getelementptr i8, ptr %node, i64 8
  %next = load ptr, ptr %next_slot, align 8
  call void @sollang_free(ptr %allocation)
  call void @sollang_free(ptr %node)
  br label %loop

finish:
  ret void
}
%sollang.legacy_int_result = type { i64, i32 }
@sollang_legacy_int_writer_buffer = internal global [8192 x i64] zeroinitializer
@sollang_legacy_int_writer_buffer_count = internal global i64 0
define internal i32 @sollang_legacy_int_copy_text_to_c_path(ptr %data, i64 %len, ptr %out) {
entry:
  %too_long = icmp ugt i64 %len, 259
  br i1 %too_long, label %fail, label %copy

copy:
  %i = phi i64 [ 0, %entry ], [ %next, %copy_body ]
  %done = icmp eq i64 %i, %len
  br i1 %done, label %nul, label %copy_body

copy_body:
  %src = getelementptr i8, ptr %data, i64 %i
  %ch = load i8, ptr %src, align 1
  %dst = getelementptr i8, ptr %out, i64 %i
  store i8 %ch, ptr %dst, align 1
  %next = add i64 %i, 1
  br label %copy

nul:
  %nul_ptr = getelementptr i8, ptr %out, i64 %len
  store i8 0, ptr %nul_ptr, align 1
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_open_write_i64_file(ptr %path, i64 %len) {
entry:
  store i64 0, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %ok = call i32 @sollang_legacy_int_platform_open_write_file(ptr %path, i64 %len)
  ret i32 %ok
}

define internal i32 @sollang_legacy_int_flush_i64_file() {
entry:
  %count = load i64, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %success, label %flush

flush:
  %bytes = mul i64 %count, 8
  %ok = call i32 @sollang_legacy_int_platform_write_file_bytes(ptr @sollang_legacy_int_writer_buffer, i64 %bytes)
  %is_ok = icmp ne i32 %ok, 0
  br i1 %is_ok, label %reset, label %fail

reset:
  store i64 0, ptr @sollang_legacy_int_writer_buffer_count, align 8
  br label %success

success:
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_write_i64_file(i64 %value) {
entry:
  %count = load i64, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %slot = getelementptr inbounds [8192 x i64], ptr @sollang_legacy_int_writer_buffer, i64 0, i64 %count
  store i64 %value, ptr %slot, align 8
  %next = add i64 %count, 1
  store i64 %next, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %full = icmp eq i64 %next, 8192
  br i1 %full, label %flush, label %success

flush:
  %ok = call i32 @sollang_legacy_int_flush_i64_file()
  ret i32 %ok

success:
  ret i32 1
}

define internal i32 @sollang_legacy_int_close_write_i64_file() {
entry:
  %flush_ok = call i32 @sollang_legacy_int_flush_i64_file()
  %flush_is_ok = icmp ne i32 %flush_ok, 0
  br i1 %flush_is_ok, label %close, label %fail

close:
  %close_ok = call i32 @sollang_legacy_int_platform_close_write_file()
  ret i32 %close_ok

fail:
  ret i32 0
}

define internal %sollang.legacy_int_result @sollang_legacy_int_closest_i64_file(i64 %target) {
entry:
  %count_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_i64_file_count()
  %count = extractvalue %sollang.legacy_int_result %count_result, 0
  %count_ok = extractvalue %sollang.legacy_int_result %count_result, 1
  %count_is_ok = icmp ne i32 %count_ok, 0
  %has_values = icmp sgt i64 %count, 0
  %can_search = and i1 %count_is_ok, %has_values
  br i1 %can_search, label %search, label %fail

search:
  br label %loop

loop:
  %low = phi i64 [ 0, %search ], [ %next_low, %step ]
  %high = phi i64 [ %count, %search ], [ %next_high, %step ]
  %active = icmp slt i64 %low, %high
  br i1 %active, label %probe, label %choose

probe:
  %span = sub i64 %high, %low
  %half = sdiv i64 %span, 2
  %mid = add i64 %low, %half
  %mid_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %mid)
  %mid_value = extractvalue %sollang.legacy_int_result %mid_result, 0
  %mid_ok = extractvalue %sollang.legacy_int_result %mid_result, 1
  %mid_is_ok = icmp ne i32 %mid_ok, 0
  br i1 %mid_is_ok, label %compare_mid, label %fail

compare_mid:
  %less = icmp slt i64 %mid_value, %target
  br i1 %less, label %move_low, label %move_high

move_low:
  %low_plus = add i64 %mid, 1
  br label %step

move_high:
  br label %step

step:
  %next_low = phi i64 [ %low_plus, %move_low ], [ %low, %move_high ]
  %next_high = phi i64 [ %high, %move_low ], [ %mid, %move_high ]
  br label %loop

choose:
  %at_start = icmp eq i64 %low, 0
  br i1 %at_start, label %read_low, label %check_end

check_end:
  %at_end = icmp eq i64 %low, %count
  br i1 %at_end, label %read_prev_only, label %read_pair

read_low:
  %first_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 0)
  ret %sollang.legacy_int_result %first_result

read_prev_only:
  %last_index = sub i64 %count, 1
  %last_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %last_index)
  ret %sollang.legacy_int_result %last_result

read_pair:
  %prev_index = sub i64 %low, 1
  %prev_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %prev_index)
  %next_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %low)
  %prev_ok = extractvalue %sollang.legacy_int_result %prev_result, 1
  %next_ok = extractvalue %sollang.legacy_int_result %next_result, 1
  %prev_is_ok = icmp ne i32 %prev_ok, 0
  %next_is_ok = icmp ne i32 %next_ok, 0
  %both_ok = and i1 %prev_is_ok, %next_is_ok
  br i1 %both_ok, label %compare_pair, label %fail

compare_pair:
  %prev_value = extractvalue %sollang.legacy_int_result %prev_result, 0
  %next_value = extractvalue %sollang.legacy_int_result %next_result, 0
  %prev_diff = sub i64 %target, %prev_value
  %next_diff = sub i64 %next_value, %target
  %prefer_prev = icmp sle i64 %prev_diff, %next_diff
  br i1 %prefer_prev, label %return_prev, label %return_next

return_prev:
  ret %sollang.legacy_int_result %prev_result

return_next:
  ret %sollang.legacy_int_result %next_result

fail:
  %fail0 = insertvalue %sollang.legacy_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.legacy_int_result %fail0, i32 0, 1
  ret %sollang.legacy_int_result %fail1
}
define internal void @sollang_legacy_int_require(i32 %status) {
entry:
  %ok = icmp ne i32 %status, 0
  br i1 %ok, label %done, label %failure
failure:
  call void @ExitProcess(i32 1)
unreachable
done:
  ret void
}
define void @sollang_x0B7379732E72756E74696D650107010D6F70656E496E745772697465723E01067075626C6963010D6F70656E496E7457726974657201047061746818013A01045465787416022D3E0104556E697420013D0109696E7472696E736963(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  %ok = call i32 @sollang_legacy_int_open_write_i64_file(ptr %data, i64 %length)
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define void @sollang_x0B7379732E72756E74696D65010701087772697465496E743901067075626C696301087772697465496E74010576616C756518013A0103496E7416022D3E0104556E697420013D0109696E7472696E736963(i32 %arg) {
entry:
  %wide = sext i32 %arg to i64
  %ok = call i32 @sollang_legacy_int_write_i64_file(i64 %wide)
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define void @sollang_x0B7379732E72756E74696D650107010E636C6F7365496E745772697465723301067075626C6963010E636C6F7365496E7457726974657218013A16022D3E0104556E697420013D0109696E7472696E736963() {
entry:
  %ok = call i32 @sollang_legacy_int_close_write_i64_file()
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define void @sollang_x0B7379732E72756E74696D650107010D6F70656E496E745265616465723E01067075626C6963010D6F70656E496E7452656164657201047061746818013A01045465787416022D3E0104556E697420013D0109696E7472696E736963(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  %ok = call i32 @sollang_legacy_int_platform_open_read_file(ptr %data, i64 %length)
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define void @sollang_x0B7379732E72756E74696D650107010E636C6F7365496E745265616465723301067075626C6963010E636C6F7365496E7452656164657218013A16022D3E0104556E697420013D0109696E7472696E736963() {
entry:
  %ok = call i32 @sollang_legacy_int_platform_close_read_file()
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define i32 @sollang_x0B7379732E72756E74696D650107010A636C6F73657374496E743B01067075626C6963010A636C6F73657374496E74010674617267657418013A0103496E7416022D3E0103496E7420013D0109696E7472696E736963(i32 %arg) {
entry:
  %wide = sext i32 %arg to i64
  %result = call %sollang.legacy_int_result @sollang_legacy_int_closest_i64_file(i64 %wide)
  %status = extractvalue %sollang.legacy_int_result %result, 1
  call void @sollang_legacy_int_require(i32 %status)
  %value = extractvalue %sollang.legacy_int_result %result, 0
  %narrow = trunc i64 %value to i32
  ret i32 %narrow
}
declare dllimport i32 @ReadFile(ptr, ptr, i32, ptr, ptr)
declare dllimport i32 @SetFilePointerEx(ptr, i64, ptr, i32)
@sollang_legacy_int_file_writer = internal global ptr null
@sollang_legacy_int_file_reader = internal global ptr null

define internal i32 @sollang_legacy_int_platform_open_write_file(ptr %path, i64 %len) {
entry:
  %buf = alloca [260 x i8], align 1
  %buf_ptr = getelementptr inbounds [260 x i8], ptr %buf, i64 0, i64 0
  %copy_ok = call i32 @sollang_legacy_int_copy_text_to_c_path(ptr %path, i64 %len, ptr %buf_ptr)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileA(ptr %buf_ptr, i32 1073741824, i32 0, ptr null, i32 2, i32 128, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  store ptr %handle, ptr @sollang_legacy_int_file_writer, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_platform_write_file_bytes(ptr %data, i64 %len64) {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_writer, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %write, label %fail

write:
  %written = alloca i32, align 4
  %len = trunc i64 %len64 to i32
  %ok = call i32 @WriteFile(ptr %handle, ptr %data, i32 %len, ptr %written, ptr null)
  %written32 = load i32, ptr %written, align 4
  %written64 = zext i32 %written32 to i64
  %write_ok = icmp ne i32 %ok, 0
  %full = icmp eq i64 %written64, %len64
  %all_ok = and i1 %write_ok, %full
  %result = zext i1 %all_ok to i32
  ret i32 %result

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_platform_close_write_file() {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_writer, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %close, label %fail

close:
  %ok = call i32 @CloseHandle(ptr %handle)
  %close_ok = icmp ne i32 %ok, 0
  br i1 %close_ok, label %success, label %fail

success:
  store ptr null, ptr @sollang_legacy_int_file_writer, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_platform_open_read_file(ptr %path, i64 %len) {
entry:
  %buf = alloca [260 x i8], align 1
  %buf_ptr = getelementptr inbounds [260 x i8], ptr %buf, i64 0, i64 0
  %copy_ok = call i32 @sollang_legacy_int_copy_text_to_c_path(ptr %path, i64 %len, ptr %buf_ptr)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileA(ptr %buf_ptr, i32 -2147483648, i32 1, ptr null, i32 3, i32 128, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  store ptr %handle, ptr @sollang_legacy_int_file_reader, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal %sollang.legacy_int_result @sollang_legacy_int_platform_i64_file_count() {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %size, label %fail

size:
  %size_ptr = alloca i64, align 8
  %ok = call i32 @GetFileSizeEx(ptr %handle, ptr %size_ptr)
  %size_ok = icmp ne i32 %ok, 0
  br i1 %size_ok, label %check, label %fail

check:
  %bytes = load i64, ptr %size_ptr, align 8
  %rem = urem i64 %bytes, 8
  %aligned = icmp eq i64 %rem, 0
  br i1 %aligned, label %success, label %fail

success:
  %count = udiv i64 %bytes, 8
  %ok0 = insertvalue %sollang.legacy_int_result poison, i64 %count, 0
  %ok1 = insertvalue %sollang.legacy_int_result %ok0, i32 1, 1
  ret %sollang.legacy_int_result %ok1

fail:
  %fail0 = insertvalue %sollang.legacy_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.legacy_int_result %fail0, i32 0, 1
  ret %sollang.legacy_int_result %fail1
}

define internal %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %index) {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %seek, label %fail

seek:
  %offset = mul i64 %index, 8
  %seek_ok = call i32 @SetFilePointerEx(ptr %handle, i64 %offset, ptr null, i32 0)
  %seek_is_ok = icmp ne i32 %seek_ok, 0
  br i1 %seek_is_ok, label %read, label %fail

read:
  %value_ptr = alloca i64, align 8
  %read_bytes = alloca i32, align 4
  %ok = call i32 @ReadFile(ptr %handle, ptr %value_ptr, i32 8, ptr %read_bytes, ptr null)
  %read_ok = icmp ne i32 %ok, 0
  %read_count = load i32, ptr %read_bytes, align 4
  %read_full = icmp eq i32 %read_count, 8
  %all_ok = and i1 %read_ok, %read_full
  br i1 %all_ok, label %success, label %fail

success:
  %value = load i64, ptr %value_ptr, align 8
  %ok0 = insertvalue %sollang.legacy_int_result poison, i64 %value, 0
  %ok1 = insertvalue %sollang.legacy_int_result %ok0, i32 1, 1
  ret %sollang.legacy_int_result %ok1

fail:
  %fail0 = insertvalue %sollang.legacy_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.legacy_int_result %fail0, i32 0, 1
  ret %sollang.legacy_int_result %fail1
}

define internal i32 @sollang_legacy_int_platform_close_read_file() {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %close, label %fail

close:
  %ok = call i32 @CloseHandle(ptr %handle)
  %close_ok = icmp ne i32 %ok, 0
  br i1 %close_ok, label %success, label %fail

success:
  store ptr null, ptr @sollang_legacy_int_file_reader, align 8
  ret i32 1

fail:
  ret i32 0
}
declare i32 @getchar()
declare dllimport i32 @GetFileSizeEx(ptr, ptr)
declare dllimport ptr @CreateFileMappingA(ptr, ptr, i32, i32, i32, ptr)
declare dllimport ptr @MapViewOfFile(ptr, i32, i32, i32, i64)
declare dllimport i32 @UnmapViewOfFile(ptr)
declare dllimport i64 @GetTickCount64()
declare dllimport void @GetSystemTimePreciseAsFileTime(ptr)
@sollang_stage2_random_state = internal global i64 88172645463325252
define void @sollang_x0B7379732E72756E74696D65010701057072696E743701067075626C696301057072696E74010576616C756518013A01045465787416022D3E0104556E697420013D0109696E7472696E736963(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_print(ptr %data, i64 %length, i1 false)
  ret void
}
define void @sollang_x0B7379732E72756E74696D65010701077072696E746C6E3901067075626C696301077072696E746C6E010576616C756518013A01045465787416022D3E0104556E697420013D0109696E7472696E736963(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_print(ptr %data, i64 %length, i1 true)
  ret void
}
define i32 @sollang_x0B7379732E72756E74696D650107010772656164496E743901067075626C6963010772656164496E74010670726F6D707418013A01045465787416022D3E0103496E7420013D0109696E7472696E736963(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_print(ptr %data, i64 %length, i1 false)
  %value_slot = alloca i32, align 4
  %started_slot = alloca i1, align 1
  %negative_slot = alloca i1, align 1
  store i32 0, ptr %value_slot, align 4
  store i1 false, ptr %started_slot, align 1
  store i1 false, ptr %negative_slot, align 1
  br label %read
read:
  %character = call i32 @getchar()
  %eof = icmp eq i32 %character, -1
  br i1 %eof, label %done, label %classify
classify:
  %digit_low = icmp sge i32 %character, 48
  %digit_high = icmp sle i32 %character, 57
  %digit = and i1 %digit_low, %digit_high
  br i1 %digit, label %append, label %non_digit
append:
  %previous = load i32, ptr %value_slot, align 4
  %scaled = mul i32 %previous, 10
  %digit_value = sub i32 %character, 48
  %updated = add i32 %scaled, %digit_value
  store i32 %updated, ptr %value_slot, align 4
  store i1 true, ptr %started_slot, align 1
  br label %read
non_digit:
  %started = load i1, ptr %started_slot, align 1
  br i1 %started, label %done, label %prefix
prefix:
  %minus = icmp eq i32 %character, 45
  br i1 %minus, label %mark_negative, label %read
mark_negative:
  store i1 true, ptr %negative_slot, align 1
  br label %read
done:
  %magnitude = load i32, ptr %value_slot, align 4
  %negative = load i1, ptr %negative_slot, align 1
  %negated = sub i32 0, %magnitude
  %result = select i1 %negative, i32 %negated, i32 %magnitude
  ret i32 %result
}
define void @sollang_x0B7379732E72756E74696D650107010A7365656452616E646F6D3B01067075626C6963010A7365656452616E646F6D010576616C756518013A0103496E7416022D3E0104556E697420013D0109696E7472696E736963(i32 %arg) {
entry:
  %seed = sext i32 %arg to i64
  store i64 %seed, ptr @sollang_stage2_random_state, align 8
  ret void
}
define i32 @sollang_x0B7379732E72756E74696D650107010B72616E646F6D42656C6F774201067075626C6963010B72616E646F6D42656C6F77010C6D61784578636C757369766518013A0103496E7416022D3E0103496E7420013D0109696E7472696E736963(i32 %arg) {
entry:
  %valid = icmp sgt i32 %arg, 0
  br i1 %valid, label %next, label %failure
next:
  %state = load i64, ptr @sollang_stage2_random_state, align 8
  %product = mul i64 %state, 6364136223846793005
  %updated = add i64 %product, 1442695040888963407
  store i64 %updated, ptr @sollang_stage2_random_state, align 8
  %bound = zext i32 %arg to i64
  %value = urem i64 %updated, %bound
  %result = trunc i64 %value to i32
  ret i32 %result
failure:
  ret i32 0
}

define i64 @sollang_x0B7379732E72756E74696D65010701096E6F774D696C6C69732E01067075626C696301096E6F774D696C6C697318013A16022D3E01044C6F6E6720013D0109696E7472696E736963() {
entry:
  %value = call i64 @GetTickCount64()
  ret i64 %value
}
define i64 @sollang_x0B7379732E72756E74696D650107010C7574634E6F774D696C6C69733101067075626C6963010C7574634E6F774D696C6C697318013A16022D3E01044C6F6E6720013D0109696E7472696E736963() {
entry:
  %filetime = alloca [2 x i32], align 4
  call void @GetSystemTimePreciseAsFileTime(ptr %filetime)
  %low_ptr = getelementptr inbounds [2 x i32], ptr %filetime, i64 0, i64 0
  %high_ptr = getelementptr inbounds [2 x i32], ptr %filetime, i64 0, i64 1
  %low32 = load i32, ptr %low_ptr, align 4
  %high32 = load i32, ptr %high_ptr, align 4
  %low = zext i32 %low32 to i64
  %high = zext i32 %high32 to i64
  %shifted = shl i64 %high, 32
  %ticks = or i64 %shifted, %low
  %unix_ticks = sub i64 %ticks, 116444736000000000
  %millis = udiv i64 %unix_ticks, 10000
  ret i64 %millis
}
define i8 @sollang_x0B7379732E72756E74696D65010701166D6F6E6F746F6E696353757370656E64506F6C6963793C01067075626C696301166D6F6E6F746F6E696353757370656E64506F6C69637918013A16022D3E010555496E743820013D0109696E7472696E736963() { ret i8 0 }
define void @sollang_x0B7379732E72756E74696D6501070106657072696E743801067075626C69630106657072696E74010576616C756518013A01045465787416022D3E0104556E697420013D0109696E7472696E736963(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_eprint(ptr %data, i64 %length, i1 false)
  ret void
}
define void @sollang_x0B7379732E72756E74696D6501070108657072696E746C6E3A01067075626C69630108657072696E746C6E010576616C756518013A01045465787416022D3E0104556E697420013D0109696E7472696E736963(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_eprintln(ptr %data, i64 %length)
  ret void
}
define void @sollang_x0B7379732E72756E74696D6501070113666C7573685374616E646172644F75747075744701067075626C69630113666C7573685374616E646172644F757470757418013A16022D3E0104556E69740104757365730107436F6E736F6C6520013D0109696E7472696E736963() {
entry:
  call void @sollang_runtime_flush_stdout()
  ret void
}
; sollang.codegen.end

from pathlib import Path
import sys,json,hashlib,time
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'processor24797-managed';C=B/'linker24766-managed/compiler/Sollang.Compiler.exe';L=R/'.tools/llvm-22.1.8';P=R/'scripts/probes/windows-linker';contract=P/'processor-contract.json';plan=json.loads(contract.read_text());manifest=P/'processor.sources.txt';sources=[R/p for p in manifest.read_text().splitlines() if p];reference=B/'processor24776-csharp/result.json';baseline=json.loads(reference.read_text());controller=B/'processor24776-csharp/controller/bin/controller.dll';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert baseline['status']=='passed' and baseline['completed']==16
pins={str(p.resolve()):sha(p) for p in [Path(__file__),contract,manifest,*sources,reference,controller,*managed_runtime_inputs(controller.with_suffix('.exe')),C,*managed_runtime_inputs(C),*sorted((R/'stdlib').rglob('*.slg'))]}
initialize_output(R,O,reusable_directories=[B/'nativeabi24791-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=16,cases=[],inputHashes=pins,baseline=str(reference),claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  exe=O/'probe.exe';r=ex.run([str(C),'build',*map(str,sources),'-o',str(exe),'--target','windows-x64','--keep-temps','-O1','--jobs','4','--llvm',str(L)],O/'build',timeout=180);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  for index,case in enumerate(plan['cases']):
   r=ex.run(['dotnet',str(controller),str(contract),str(index),str(exe)],O/case['id'],timeout=30);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr;actual=dict(processors=int(r.stdout.strip()));expected=baseline['cases'][index]['actual']['processors'];assert actual['processors']==expected,(case,actual,expected)
   result['cases'].append(dict(id=case['id'],passed=True,expected=expected,actual=actual));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))









from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'processor24794-unicode-csharp';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();P=R/'scripts/probes/windows-linker';contract=P/'processor-unicode-controls.json';controller=B/'processor24776-csharp/controller/bin/controller.dll';reference=B/'processor24776-csharp/reference/bin/reference.dll';baseline=B/'processor24776-csharp/result.json';default=json.loads(baseline.read_text())['cases'][0]['actual']['processors']
points=[9,10,11,12,13,32,0x85,0xa0,0x1680,*range(0x2000,0x200b),0x2028,0x2029,0x202f,0x205f,0x3000,0x180e,0x200b,0xfeff,0x200c,0x1c]
plan=dict(schemaVersion=1,scope='Observed CSharp Windows DWORD leading-whitespace behavior; not a claim of SLG parity',cases=[dict(id=f'U+{p:04X}',codepoint=p,environment={'DOTNET_PROCESSOR_COUNT':chr(p)+'3'}) for p in points]);assert not contract.exists();contract.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
pins={str(p.resolve()):sha(p) for p in [Path(__file__),contract,baseline,*managed_runtime_inputs(controller.with_suffix('.exe')),*managed_runtime_inputs(reference.with_suffix('.exe'))]}
initialize_output(R,O,reusable_directories=[B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=len(points),cases=[],inputHashes=pins,scope='CSharp reference observations only',claimsSlgEquivalent=False,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for index,case in enumerate(plan['cases']):
   r=ex.run(['dotnet',str(controller),str(contract),str(index),'dotnet',str(reference)],O/str(case['codepoint']),timeout=30);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr;actual=json.loads(r.stdout)['processors'];assert actual in [3,default],(case,actual)
   result['cases'].append(dict(id=case['id'],codepoint=case['codepoint'],actual=actual,acceptedWhitespace=actual==3));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps(dict(status=result['status'],observations=len(points),accepted=[row['id'] for row in result['cases'] if row['acceptedWhitespace']],rejected=[row['id'] for row in result['cases'] if not row['acceptedWhitespace']])))

define i32 @sollang_m146_s0(i32 %arg) {
entry:
  %if118125_result = alloca i32, align 4
  %v631360192516_ptr = insertvalue %sollang.text poison, ptr @sollang_str_118120, 0
  %v631360192516 = insertvalue %sollang.text %v631360192516_ptr, i64 4, 1
  call void @sollang_runtime_print(ptr @sollang_str_118120, i64 4, i1 true)
  %v631360192518 = icmp sgt i32 %arg, 0
  br i1 %v631360192518, label %if118125_then, label %if118125_else
if118125_then:
  %v631360192523 = add i32 %arg, 3
  store i32 %v631360192523, ptr %if118125_result, align 4
  br label %if118125_merge
if118125_else:
  store i32 0, ptr %if118125_result, align 4
  br label %if118125_merge
if118125_merge:
  %v631360192521 = load i32, ptr %if118125_result, align 4
  ret i32 %v631360192521
}
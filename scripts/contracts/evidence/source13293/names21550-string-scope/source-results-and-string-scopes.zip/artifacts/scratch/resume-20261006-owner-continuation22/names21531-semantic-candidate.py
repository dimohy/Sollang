from pathlib import Path
import json,sys,hashlib
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
proof=json.loads((B/'names21525-semantic/result.json').read_text());cmd=proof['processes'][-1]['command'];original=str(R/'selfhost/llvm/scoped_names.slg');candidate=B/'names21530-scoped-names-candidate.slg';extra=B/'names21530-string-names-candidate.slg';assert original in cmd;cmd=[str(candidate) if p==original else p for p in cmd]+[str(extra)];inputs=list(dict.fromkeys([Path(p) for p in cmd if Path(p).is_file()]+sorted((R/'stdlib').rglob('*.slg'))));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper();hashes={str(p):sha(p) for p in inputs};out=B/'names21531-semantic-candidate';initialize_output(R,out,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);out.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result={'schemaVersion':1,'status':'running','completed':0,'total':1,'cases':[],'inputHashes':hashes,'scope':'Candidate source-only semantic check, actual current compiler API; extra string naming planner and codec; not integrated or codegen proof.','claimsGoalComplete':False};run=VerificationExecution(R,out,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  done=run.run(cmd,out/'check',timeout=180);j=json.loads(done.stdout);assert done.returncode==0 and not done.stderr and j['status']=='passed' and not j['warnings'] and j['codegenInvoked'] is False,done.stdout+done.stderr;result['cases'].append({'id':'candidate-semantics','passed':True,'facts':j});result['completed']=1;result['status']='passed'
 except BaseException as ex:error=ex
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

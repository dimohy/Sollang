using System.Globalization;
using System.Text;
using Sollang.Compiler.Diagnostics;
using Sollang.Compiler.Semantics;
using Sollang.Compiler.Syntax;

namespace Sollang.Compiler.CodeGen;

internal sealed partial class LlvmEmitter
{
    private RuntimeValue EmitFlowExpressionValue(FlowExpression expression)
    {
        var result = EmitFlowExpression(expression, ok: "true", allowBindingTarget: false);
        return result.Value
            ?? RuntimeUnit.Instance;
    }

    private RuntimeFlowResult EmitFlowExpression(FlowExpression expression, string ok, bool allowBindingTarget)
    {
        if (!_platform.SupportsChildProcesses
            && expression.Targets.Any(target => TryResolveFunction(target.Path, out var function)
                && function.Kind is BoundFunctionKind.RuntimeRunProcess
                    or BoundFunctionKind.RuntimeRunProcessToFile
                    or BoundFunctionKind.RuntimeCollectProcess
                    or BoundFunctionKind.RuntimeSpawnProcess
                    or BoundFunctionKind.RuntimeWaitProcess
                    or BoundFunctionKind.RuntimePollChildProcess
                    or BoundFunctionKind.RuntimeKillChildProcess))
        {
            throw new SollangException("child processes are unavailable on the current target");
        }
        if (expression.Targets.Count == 1
            && expression.Targets[0].Arguments.Count == 0
            && TryResolveFunction(expression.Targets[0].Path, out var directFunction)
            && TryGetRuntimePrinterKind(directFunction, out var directPrinterKind))
        {
            var standardError = directPrinterKind is BoundFunctionKind.RuntimePrintError
                or BoundFunctionKind.RuntimePrintErrorLine;
            ok = EmitPrintFlowSource(expression.Source, ok, standardError);
            if (directPrinterKind is BoundFunctionKind.RuntimePrintLine
                or BoundFunctionKind.RuntimePrintErrorLine)
            {
                ok = standardError
                    ? EmitStandardErrorNewLine(ok)
                    : EmitWriteText("\n", ok);
            }

            return new RuntimeFlowResult(
                Value: null,
                Binding: null,
                Ok: ok);
        }

        var current = expression.Targets.Count > 0
            && TryResolveFunction(expression.Targets[0].Path, out var contextualFirstFunction)
            && contextualFirstFunction.InputType is { } contextualFirstInput
            && expression.Source is (ArrayLiteralExpression
                or ArrayRepeatExpression
                or DictionaryLiteralExpression)
                ? EmitFunctionArgumentExpression(expression.Source, contextualFirstInput)
                : EmitFlowSource(expression.Source);
        // Function results own their temporary storage independently of the original flow place.
        var ownsFlowTemporary = false;
        for (var i = 0; i < expression.Targets.Count; i++)
        {
            var target = expression.Targets[i];
            var isLast = i == expression.Targets.Count - 1;
            var path = string.Join('.', target.Path);

            if (_program.DynTraitConversions.TryGetValue(target, out var conversion))
            {
                current = EmitDynTraitConversion(current, conversion);
                continue;
            }
            if (_program.DynTraitDispatches.TryGetValue(target, out var dispatch))
            {
                current = current is RuntimeDynTrait dyn
                    ? EmitDynTraitDispatch(dyn, dispatch)
                    : throw new SollangException("dyn trait dispatch requires a dyn trait object");
                continue;
            }

            if (TryEmitContainerFlowTarget(expression.Source, target, path, current, isLast, ownsFlowTemporary, out var containerResult))
            {
                if ((path is "len" or "byte") && containerResult.Value is RuntimeInt)
                {
                    // Scalar reads no longer borrow the source after this stage.
                    // Retain the same complete-parent ownership as readonly calls.
                    var temporaryOwner = i == 0
                        ? TakeReadonlyTemporaryOwner(expression.Source, current)
                        : ownsFlowTemporary && IsOwnedContainerRuntimeValue(current) ? current : null;
                    if (temporaryOwner is not null)
                        DropOwnedRuntimeValue(temporaryOwner);
                    ownsFlowTemporary = false;
                }
                if (containerResult.Value is null)
                {
                    return new RuntimeFlowResult(
                        Value: null,
                        Binding: null,
                        Ok: ok);
                }

                current = containerResult.Value;
                continue;
            }

            if (path == "yield")
            {
                if (_currentBlockInvocation is null)
                {
                    throw new SollangException("yield is only valid inside a block function");
                }

                if (!isLast
                    && (expression.Targets[i + 1].Path.Count != 1
                        || expression.Targets[i + 1].Path[0] != "emit"))
                {
                    throw new SollangException("yield may only flow onward to emit");
                }

                var additionalValues = target.Arguments.Select(EmitExpression).ToArray();
                var yielded = EmitYield(current, additionalValues, _currentBlockInvocation);
                if (isLast)
                {
                    return new RuntimeFlowResult(
                        Value: yielded is RuntimeUnit ? null : yielded,
                        Binding: null,
                        Ok: ok);
                }
                current = yielded;
                continue;
            }

            if (path == "emit" && _currentStreamContinuation is not null)
            {
                if (!isLast || target.Arguments.Count != 0)
                {
                    throw new SollangException("emit must be the final argument-free value-flow target");
                }
                EmitStreamValue(current, _currentStreamContinuation);
                return new RuntimeFlowResult(Value: null, Binding: null, Ok: ok);
            }

            if (_program.ResolvedGenericCalls.TryGetValue(target, out var function)
                || TryResolveInstanceMethod(current.Type, path, out function)
                || TryResolveFunction(target.Path, out function))
            {
                var flowKind = TryGetRuntimePrinterKind(function, out var printerKind)
                    ? printerKind
                    : function.Kind;
                if (flowKind is not (
                        BoundFunctionKind.User
                        or BoundFunctionKind.Native
                        or BoundFunctionKind.RuntimeMouseEvents
                        or BoundFunctionKind.RuntimeReadBytesAt
                        or BoundFunctionKind.RuntimeWriteBytesAt
                        or BoundFunctionKind.RuntimeReadBytesAtAsync
                        or BoundFunctionKind.RuntimeWriteBytesAtAsync
                        or BoundFunctionKind.RuntimeDiagnosticSessionStart
                        or BoundFunctionKind.RuntimeDiagnosticSessionTrack
                        or BoundFunctionKind.RuntimeDiagnosticSessionSnapshot
                        or BoundFunctionKind.RuntimeDiagnosticSessionClose
                        or BoundFunctionKind.RuntimeSocketReceive
                        or BoundFunctionKind.RuntimeSocketReceiveAppend
                        or BoundFunctionKind.RuntimeSocketReceiveVectored
                        or BoundFunctionKind.RuntimeSocketPeek
                        or BoundFunctionKind.RuntimeSocketSend
                        or BoundFunctionKind.RuntimeSocketSendRange
                        or BoundFunctionKind.RuntimeSocketSendVectored
                        or BoundFunctionKind.RuntimeSocketTryClone
                        or BoundFunctionKind.RuntimeSocketSendText
                        or BoundFunctionKind.RuntimeSocketShutdown
                         or BoundFunctionKind.RuntimeSocketLocalPort
                         or BoundFunctionKind.RuntimeSocketLocalEndpoint
                         or BoundFunctionKind.RuntimeSocketRemoteEndpoint
                        or BoundFunctionKind.RuntimeSocketSetNoDelay
                        or BoundFunctionKind.RuntimeSocketNoDelay
                        or BoundFunctionKind.RuntimeSocketSetKeepAlive
                        or BoundFunctionKind.RuntimeSocketKeepAlive
                        or BoundFunctionKind.RuntimeSocketSetLinger
                        or BoundFunctionKind.RuntimeSocketLinger
                        or BoundFunctionKind.RuntimeSocketSetReadTimeout
                        or BoundFunctionKind.RuntimeSocketReadTimeout
                        or BoundFunctionKind.RuntimeSocketSetWriteTimeout
                        or BoundFunctionKind.RuntimeSocketWriteTimeout
                        or BoundFunctionKind.RuntimeSocketSendTo
                        or BoundFunctionKind.RuntimeSocketReceiveFrom
                        or BoundFunctionKind.RuntimeSocketPeekFrom
                        or BoundFunctionKind.RuntimeSocketClose
                        or BoundFunctionKind.RuntimeSocketSetNonblocking
                        or BoundFunctionKind.RuntimeSocketPoll
                        or BoundFunctionKind.RuntimeSocketReactorWait
                        or BoundFunctionKind.RuntimeSocketCompletionCreate
                        or BoundFunctionKind.RuntimeSocketCompletionRegisterStream
                        or BoundFunctionKind.RuntimeSocketCompletionRemoveStream
                        or BoundFunctionKind.RuntimeSocketCompletionSubmit
                        or BoundFunctionKind.RuntimeSocketCompletionCancel
                        or BoundFunctionKind.RuntimeSocketCompletionDequeue
                        or BoundFunctionKind.RuntimeSocketCompletionClose
                        or BoundFunctionKind.RuntimeDnsLookup
                        or BoundFunctionKind.RuntimeRunProcess
                        or BoundFunctionKind.RuntimeRunProcessToFile
                        or BoundFunctionKind.RuntimeCollectProcess
                        or BoundFunctionKind.RuntimeSpawnProcess
                        or BoundFunctionKind.RuntimeWaitProcess
                        or BoundFunctionKind.RuntimePollChildProcess
                        or BoundFunctionKind.RuntimeKillChildProcess
                        or BoundFunctionKind.RuntimeChildProcessId
                        or BoundFunctionKind.RuntimeProcessIdValue)
                    && target.Arguments.Count != 0)
                {
                    throw new SollangException($"function value-flow target '{path}' does not accept additional arguments in this slice");
                }
                if (i == 0
                    && function.InputType is { } contextualInput
                    && IsIntegerType(contextualInput)
                    && TryGetIntegerLiteralText(expression.Source, out var integerLiteral))
                {
                    current = new RuntimeInt(contextualInput, integerLiteral);
                }

                switch (flowKind)
                {
                    case BoundFunctionKind.RuntimePrint:
                    case BoundFunctionKind.RuntimePrintLine:
                    case BoundFunctionKind.RuntimePrintError:
                    case BoundFunctionKind.RuntimePrintErrorLine:
                        if (!isLast)
                        {
                            throw new SollangException($"{path} must be the final value-flow target");
                        }

                        var standardError = flowKind is BoundFunctionKind.RuntimePrintError
                            or BoundFunctionKind.RuntimePrintErrorLine;
                        ok = EmitWriteValue(current, ok, standardError);
                        if (flowKind is BoundFunctionKind.RuntimePrintLine
                            or BoundFunctionKind.RuntimePrintErrorLine)
                        {
                            ok = standardError
                                ? EmitStandardErrorNewLine(ok)
                                : EmitWriteText("\n", ok);
                        }

                        return new RuntimeFlowResult(
                            Value: null,
                            Binding: null,
                            Ok: ok);
                    case BoundFunctionKind.RuntimeReadInt:
                        EnsureRuntimeType(current, BoundType.Text, path);
                        current = EmitReadIntPrompt(current);
                        ok = _mainOk;
                        continue;
                    case BoundFunctionKind.RuntimeSeedRandom:
                    case BoundFunctionKind.RuntimeOpenIntWriter:
                    case BoundFunctionKind.RuntimeWriteInt:
                    case BoundFunctionKind.RuntimeOpenIntReader:
                        if (!isLast)
                        {
                            throw new SollangException($"{path} must be the final value-flow target");
                        }

                        EmitRuntimeUnitIntrinsic(function, current, path);
                        return new RuntimeFlowResult(
                            Value: null,
                            Binding: null,
                            Ok: _mainOk);
                    case BoundFunctionKind.RuntimeWriteScalar:
                        if (!isLast)
                        {
                            throw new SollangException($"{path} must be the final value-flow target");
                        }
                        EmitRuntimeWriteScalar(function, current);
                        return new RuntimeFlowResult(
                            Value: null,
                            Binding: null,
                            Ok: _mainOk);
                    case BoundFunctionKind.RuntimeRandomBelow:
                    case BoundFunctionKind.RuntimeClosestInt:
                        current = EmitRuntimeIntIntrinsic(function, current, path);
                        ok = _mainOk;
                        continue;
                    case BoundFunctionKind.RuntimeSecureRandomBytes:
                        current = EmitRuntimeSecureRandomBytes(function, current, path);
                        continue;
                    case BoundFunctionKind.RuntimeLimitParallelWorkers:
                        current = EmitRuntimeLimitParallelWorkersIntrinsic(current, path);
                        continue;
                    case BoundFunctionKind.RuntimeReadStandardInputChunk:
                        current = EmitReadStandardInputChunk(current);
                        continue;
                    case BoundFunctionKind.RuntimeCloseIntWriter:
                    case BoundFunctionKind.RuntimeCloseIntReader:
                        throw new SollangException($"{path} does not accept a flowed input");
                    case BoundFunctionKind.RuntimeExitProcess:
                        if (!isLast)
                        {
                            throw new SollangException($"{path} must be the final value-flow target");
                        }
                        EmitRuntimeExitProcessIntrinsic(current, path);
                        return new RuntimeFlowResult(
                            Value: null,
                            Binding: null,
                            Ok: _mainOk);
                    case BoundFunctionKind.RuntimeSyncFile:
                        current = current is RuntimeStruct syncWriter
                            ? EmitRuntimeSyncFile(syncWriter)
                            : throw new SollangException($"{path} expects a FileWriter");
                        continue;
                    case BoundFunctionKind.RuntimeAtomicReplaceFile:
                        current = current is RuntimeStruct replaceRequest
                            ? EmitRuntimeAtomicReplaceFile(function, replaceRequest)
                            : throw new SollangException($"{path} expects an AtomicReplaceRequest");
                        continue;
                    case BoundFunctionKind.RuntimeCreateExclusiveFile:
                    case BoundFunctionKind.RuntimeRemoveFile:
                        current = EmitRuntimeFilePathStatus(function, current);
                        continue;
                    case BoundFunctionKind.RuntimeBorrowSourceText:
                        current = EmitBorrowSourceText(current);
                        continue;
                    case BoundFunctionKind.RuntimeBorrowSourceBytes:
                        current = EmitBorrowSourceBytes(current);
                        continue;
                    case BoundFunctionKind.RuntimeMapSourceText:
                        current = EmitMapSourceText(current);
                        continue;
                    case BoundFunctionKind.RuntimeMapSourcePath:
                        current = EmitMapSourcePath(current);
                        continue;
                    case BoundFunctionKind.RuntimePathText:
                        current = EmitRuntimePathText(current);
                        continue;
                    case BoundFunctionKind.RuntimeOpenFile:
                    case BoundFunctionKind.RuntimeOpenWriteFile:
                        current = EmitRuntimeOpenFile(function, current);
                        continue;
                    case BoundFunctionKind.RuntimeReadDirectory:
                        current = EmitRuntimeReadDirectory(function, current);
                        continue;
                    case BoundFunctionKind.RuntimeCreateDirectory:
                        current = EmitRuntimeCreateDirectory(function, current);
                        continue;
                    case BoundFunctionKind.RuntimePathAbsolute:
                        current = EmitRuntimePathAbsolute(function, current);
                        continue;
                    case BoundFunctionKind.RuntimePathQuery:
                        current = EmitRuntimePathQuery(function, current);
                        continue;
                    case BoundFunctionKind.RuntimeRangeStream:
                        current = EmitRuntimeRangeStream(function, current, path);
                        continue;
                    case BoundFunctionKind.RuntimeMouseEvents:
                        if (target.Arguments.Count != 0)
                        {
                            throw new SollangException(
                                $"{path} does not accept arguments after the flowed Source");
                        }
                        current = EmitRuntimeMouseEvents(
                            function,
                            current,
                            path);
                        continue;
                    case BoundFunctionKind.RuntimeSocketListen:
                    case BoundFunctionKind.RuntimeReadBytesAt:
                    case BoundFunctionKind.RuntimeWriteBytesAt:
                    case BoundFunctionKind.RuntimeReadBytesAtAsync:
                    case BoundFunctionKind.RuntimeWriteBytesAtAsync:
                    case BoundFunctionKind.RuntimeSocketAccept:
                    case BoundFunctionKind.RuntimeSocketConnect:
                    case BoundFunctionKind.RuntimeSocketReceive:
                    case BoundFunctionKind.RuntimeSocketReceiveAppend:
                    case BoundFunctionKind.RuntimeSocketReceiveVectored:
                    case BoundFunctionKind.RuntimeSocketPeek:
                    case BoundFunctionKind.RuntimeSocketSend:
                    case BoundFunctionKind.RuntimeSocketSendRange:
                    case BoundFunctionKind.RuntimeSocketSendVectored:
                    case BoundFunctionKind.RuntimeSocketTryClone:
                    case BoundFunctionKind.RuntimeSocketSendText:
                    case BoundFunctionKind.RuntimeSocketShutdown:
                    case BoundFunctionKind.RuntimeSocketBindDatagram:
                    case BoundFunctionKind.RuntimeSocketLocalPort:
                    case BoundFunctionKind.RuntimeSocketLocalEndpoint:
                    case BoundFunctionKind.RuntimeSocketRemoteEndpoint:
                    case BoundFunctionKind.RuntimeSocketSetNoDelay:
                    case BoundFunctionKind.RuntimeSocketNoDelay:
                    case BoundFunctionKind.RuntimeSocketSetKeepAlive:
                    case BoundFunctionKind.RuntimeSocketKeepAlive:
                    case BoundFunctionKind.RuntimeSocketSetLinger:
                    case BoundFunctionKind.RuntimeSocketLinger:
                    case BoundFunctionKind.RuntimeSocketSetReadTimeout:
                    case BoundFunctionKind.RuntimeSocketReadTimeout:
                    case BoundFunctionKind.RuntimeSocketSetWriteTimeout:
                    case BoundFunctionKind.RuntimeSocketWriteTimeout:
                    case BoundFunctionKind.RuntimeSocketSendTo:
                    case BoundFunctionKind.RuntimeSocketReceiveFrom:
                    case BoundFunctionKind.RuntimeSocketPeekFrom:
                    case BoundFunctionKind.RuntimeSocketClose:
                    case BoundFunctionKind.RuntimeSocketSetNonblocking:
                    case BoundFunctionKind.RuntimeSocketPoll:
                    case BoundFunctionKind.RuntimeSocketReactorWait:
                    case BoundFunctionKind.RuntimeSocketCompletionCreate:
                    case BoundFunctionKind.RuntimeSocketCompletionRegisterStream:
                    case BoundFunctionKind.RuntimeSocketCompletionRemoveStream:
                    case BoundFunctionKind.RuntimeSocketCompletionSubmit:
                    case BoundFunctionKind.RuntimeSocketCompletionCancel:
                    case BoundFunctionKind.RuntimeSocketCompletionDequeue:
                    case BoundFunctionKind.RuntimeSocketCompletionClose:
                    case BoundFunctionKind.RuntimeDnsLookup:
                    case BoundFunctionKind.RuntimeRunProcess:
                    case BoundFunctionKind.RuntimeRunProcessToFile:
                    case BoundFunctionKind.RuntimeCollectProcess:
                    case BoundFunctionKind.RuntimeSpawnProcess:
                    case BoundFunctionKind.RuntimeWaitProcess:
                    case BoundFunctionKind.RuntimePollChildProcess:
                    case BoundFunctionKind.RuntimeKillChildProcess:
                    case BoundFunctionKind.RuntimeChildProcessId:
                    case BoundFunctionKind.RuntimeProcessIdValue:
                    case BoundFunctionKind.RuntimeDiagnosticSessionStart:
                    case BoundFunctionKind.RuntimeDiagnosticSessionTrack:
                    case BoundFunctionKind.RuntimeDiagnosticSessionSnapshot:
                    case BoundFunctionKind.RuntimeDiagnosticSessionClose:
                        current = EmitFlowFunctionCall(function, current, expression.Source, target.Arguments, i == 0, ownsFlowTemporary);
                        ownsFlowTemporary = IsOwnedContainerRuntimeValue(current);
                        continue;
                    case BoundFunctionKind.RuntimeOpenFileAsync:
                    case BoundFunctionKind.RuntimeOpenWriteFileAsync:
                        current = EmitRuntimeOpenFileAsync(function, current);
                        continue;
                    case BoundFunctionKind.RuntimeSleep:
                        current = EmitRuntimeSleepIntrinsic(function, current, path);
                        continue;
                    case BoundFunctionKind.User:
                    case BoundFunctionKind.Native:
                        current = EmitFlowFunctionCall(function, current, expression.Source, target.Arguments, i == 0, ownsFlowTemporary);
                        ownsFlowTemporary = IsOwnedContainerRuntimeValue(current);
                        continue;
                    default:
                        throw new SollangException($"unsupported runtime function kind '{function.Kind}'");
                }
            }

            throw new SollangException($"unknown runtime value-flow target '{path}'");
        }

        return new RuntimeFlowResult(
            Value: current,
            Binding: null,
            Ok: ok);
    }

    private bool TryEmitContainerFlowTarget(
        Expression source,
        FlowTarget target,
        string path,
        RuntimeValue current,
        bool isLast,
        bool ownsFlowTemporary,
        out RuntimeFlowResult result)
    {
        result = new RuntimeFlowResult(null, null, _mainOk);

        if ((path is "len" or "capacity")
            && current is RuntimeReference reference
            && !_program.ResolvedGenericCalls.ContainsKey(target))
        {
            current = LoadReference(reference);
        }

        if (_program.ContainerIntrinsics.TryGetValue(target, out var intrinsic))
        {
            result = intrinsic switch
            {
                ContainerIntrinsicKind.ArrayExchange => EmitArrayExchange(source, target, current),
                _ => throw new SollangException($"unsupported container intrinsic '{intrinsic}'")
            };
            return true;
        }

        if (current is RuntimeStruct writer
            && _program.Types.IsStruct(writer.Type)
            && string.Equals(
                _program.Types.GetStruct(writer.Type).Name,
                "sys.file.FileWriter",
                StringComparison.Ordinal)
            && path is "writeAt" or "writeAtAsync" or "syncAsync")
        {
            if (!_program.ResolvedGenericCalls.TryGetValue(target, out var writeFunction))
            {
                throw new SollangException($"unresolved file operation '{path}'");
            }
            RuntimeValue value = path switch
            {
                "writeAtAsync" => EmitRuntimeWriteScalarAtAsync(
                    writeFunction,
                    writer,
                    target.Arguments[0],
                    target.Arguments[1]),
                "syncAsync" => EmitRuntimeSyncFileAsync(writeFunction, writer),
                _ => EmitRuntimeWriteScalarAt(
                    writeFunction,
                    writer,
                    target.Arguments[0],
                    target.Arguments[1])
            };
            result = new RuntimeFlowResult(value, null, _mainOk);
            return true;
        }

        if (current is RuntimeStruct file
            && _program.Types.IsStruct(file.Type)
            && string.Equals(
                _program.Types.GetStruct(file.Type).Name,
                "sys.file.File",
                StringComparison.Ordinal)
            && path is "readAt" or "readAtAsync")
        {
            if (!_program.ResolvedGenericCalls.TryGetValue(target, out var fileFunction))
            {
                throw new SollangException($"unresolved generic file operation '{path}'");
            }
            var value = path == "readAtAsync"
                ? (RuntimeValue)EmitRuntimeReadScalarAsync(
                    fileFunction,
                    file,
                    target.Arguments[0])
                : EmitRuntimeReadScalar(
                    fileFunction,
                    file: file,
                    offsetExpression: target.Arguments[0]);
            result = new RuntimeFlowResult(value, null, _mainOk);
            return true;
        }

        // Match semantic call precedence before selecting a container intrinsic by name.
        if (TryResolveFlowTargetFunction(target, current.Type, out var declaredFunction)
            && declaredFunction.IsVisibleFrom(_currentFunction?.ModuleName ?? "")
            && declaredFunction.Kind is BoundFunctionKind.User or BoundFunctionKind.Native)
        {
            return false;
        }

        switch (path)
        {
            case "await" when current is RuntimeTask task:
                if (target.Arguments.Count != 0)
                {
                    throw new SollangException("await does not accept arguments");
                }
                if (TryEmitCfgFlowAwait(source, target, task, out var suspendedValue))
                {
                    result = new RuntimeFlowResult(suspendedValue, null, _mainOk);
                    return true;
                }
                var awaited = EmitAwaitTask(task);
                if (source is NameExpression awaitedSource
                    && _locals.TryGetValue(awaitedSource.Name, out var sourceValue)
                    && ReferenceEquals(sourceValue, task))
                {
                    RemoveLocal(awaitedSource.Name);
                }
                else if (source is FieldAccessExpression)
                {
                    ConsumeOwnedFieldProjection(source, task.Type);
                }
                result = new RuntimeFlowResult(awaited, null, _mainOk);
                return true;
            case "cancel" when current is RuntimeTask task:
                if (!isLast || target.Arguments.Count != 0)
                {
                    throw new SollangException("cancel must be final and takes no arguments");
                }
                EmitCancelTask(task);
                if (source is NameExpression cancelledSource
                    && _locals.TryGetValue(cancelledSource.Name, out var cancelledSourceValue)
                    && ReferenceEquals(cancelledSourceValue, task))
                {
                    RemoveLocal(cancelledSource.Name);
                }
                else if (source is FieldAccessExpression)
                {
                    ConsumeOwnedFieldProjection(source, task.Type);
                }
                result = new RuntimeFlowResult(RuntimeUnit.Instance, null, _mainOk);
                return true;
            case "used" when current is RuntimeArena usedArena:
                if (target.Arguments.Count != 0)
                {
                    throw new SollangException("used does not accept arguments");
                }
                result = new RuntimeFlowResult(
                    new RuntimeInt(BoundType.UIntSize, EmitUIntSizeFromI64(usedArena.UsedName)),
                    null,
                    _mainOk);
                return true;
            case "alloc" when current is RuntimeArena allocationArena:
                if (!isLast || target.Arguments.Count != 2)
                {
                    throw new SollangException("arena alloc must be final and expects byte-count and alignment");
                }
                var arenaName = RequireMutableContainerSource(source, "alloc");
                var bytes = EmitIntExpression(target.Arguments[0]);
                var alignment = EmitIntExpression(target.Arguments[1]);
                var allocation = EmitArenaAllocate(allocationArena, bytes, alignment);
                StoreMutableContainer(arenaName, allocation.Arena);
                _locals[arenaName] = allocation.Arena;
                result = new RuntimeFlowResult(allocation.Offset, null, _mainOk);
                return true;
            case "store" when current is RuntimeArena storeArena:
                if (!isLast || target.Arguments.Count != 2)
                {
                    throw new SollangException("arena store must be final and expects offset and UInt8 value");
                }
                RequireMutableContainerSource(source, "store");
                EmitArenaStore(
                    storeArena,
                    EmitIntExpression(target.Arguments[0]),
                    EmitIntExpression(target.Arguments[1]));
                result = new RuntimeFlowResult(RuntimeUnit.Instance, null, _mainOk);
                return true;
            case "load" when current is RuntimeArena loadArena:
                if (target.Arguments.Count != 1)
                {
                    throw new SollangException("arena load expects one offset");
                }
                result = new RuntimeFlowResult(
                    EmitArenaLoad(loadArena, EmitIntExpression(target.Arguments[0])),
                    null,
                    _mainOk);
                return true;
            case "reset" when current is RuntimeArena resetArena:
                if (!isLast || target.Arguments.Count != 0)
                {
                    throw new SollangException("arena reset must be final and takes no arguments");
                }
                var resetName = RequireMutableContainerSource(source, "reset");
                var reset = resetArena with { UsedName = "0" };
                StoreMutableContainer(resetName, reset);
                _locals[resetName] = reset;
                result = new RuntimeFlowResult(RuntimeUnit.Instance, null, _mainOk);
                return true;
            case "materialize" when current.Type == BoundType.Text:
                if (target.Arguments.Count != 1)
                {
                    throw new SollangException("Text materialize expects one mutable Arena owner");
                }
                var materializeOwner = CreateMutableBorrowArgument(
                    target.Arguments[0],
                    BoundType.Arena,
                    "materialize",
                    "storage");
                if (materializeOwner is not RuntimeMutableContainerReference arenaReference)
                {
                    throw new SollangException("Text materialize requires an addressable mutable Arena owner");
                }
                result = new RuntimeFlowResult(
                    EmitMaterializedText(current, arenaReference),
                    null,
                    _mainOk);
                return true;
            case "flush" when current is RuntimeMappedBytes mapped:
                if (!isLast || target.Arguments.Count != 0)
                {
                    throw new SollangException("flush must be final and takes no arguments");
                }
                RequireMutableContainerSource(source, "flush");
                var flushOk = NextTemp("mapped_flush_ok");
                EmitCall(flushOk, "i32", "sollang_mapped_flush", $"ptr {mapped.BasePointerName}, i64 {mapped.MappedLengthName}");
                var flushSucceeded = NextTemp("mapped_flush_succeeded");
                EmitCompare(flushSucceeded, "ne", "i32", flushOk, "0");
                EmitTrapUnless(flushSucceeded, "mapped_flush");
                result = new RuntimeFlowResult(RuntimeUnit.Instance, null, _mainOk);
                return true;
            case "len":
                if (target.Arguments.Count != 0)
                {
                    throw new SollangException("len does not accept arguments");
                }

                result = current switch
                {
                    RuntimeText text => new RuntimeFlowResult(
                        new RuntimeInt(BoundType.UIntSize, EmitUIntSizeFromI64(text.LengthName)), null, _mainOk),
                    RuntimeIntSlice slice => new RuntimeFlowResult(EmitSizeAsInt(slice.LengthName, "slice_len_value"), null, _mainOk),
                    RuntimeInlineSlice slice => new RuntimeFlowResult(EmitSizeAsInt(slice.LengthName, "slice_len_value"), null, _mainOk),
                    RuntimeStaticIntArray staticArray => new RuntimeFlowResult(EmitSizeAsInt(staticArray.LengthName, "array_len_value"), null, _mainOk),
                    RuntimeStaticTextArray staticArray => new RuntimeFlowResult(EmitSizeAsInt(staticArray.LengthName, "array_len_value"), null, _mainOk),
                    RuntimeStaticInlineArray staticArray => new RuntimeFlowResult(EmitSizeAsInt(staticArray.LengthName, "array_len_value"), null, _mainOk),
                    RuntimeDynamicIntArray dynamicArray => new RuntimeFlowResult(EmitSizeAsInt(dynamicArray.LengthName, "array_len_value"), null, _mainOk),
                    RuntimeDynamicInlineArray dynamicArray => new RuntimeFlowResult(EmitSizeAsInt(dynamicArray.LengthName, "array_len_value"), null, _mainOk),
                    RuntimeIntDictionaryView dictionaryView => new RuntimeFlowResult(EmitSizeAsInt(dictionaryView.LengthName, "dict_len_value"), null, _mainOk),
                    RuntimeIntDictionary intDictionary => new RuntimeFlowResult(EmitSizeAsInt(intDictionary.LengthName, "dict_len_value"), null, _mainOk),
                    RuntimeInlineDictionary inlineMap => new RuntimeFlowResult(EmitSizeAsInt(inlineMap.LengthName, "dict_len_value"), null, _mainOk),
                    RuntimeMappedBytes mapped => new RuntimeFlowResult(
                        new RuntimeInt(BoundType.UIntSize, EmitUIntSizeFromI64(mapped.LengthName)), null, _mainOk),
                    RuntimeSourceText sourceText => new RuntimeFlowResult(
                        new RuntimeInt(BoundType.UIntSize, EmitUIntSizeFromI64(sourceText.LengthName)), null, _mainOk),
                    RuntimeArguments arguments => new RuntimeFlowResult(
                        new RuntimeInt(BoundType.UIntSize, EmitUIntSizeFromI64(arguments.LengthName)), null, _mainOk),
                    RuntimeBitSet bitSet => new RuntimeFlowResult(
                        new RuntimeInt(_program.Types.GetBitSet(bitSet.Type).BitCount.ToString(CultureInfo.InvariantCulture)),
                        null, _mainOk),
                    _ => result
                };
                return result.Value is not null;
            case "count" when current is RuntimeBitSet countBitSet:
                result = new RuntimeFlowResult(EmitBitSetCount(countBitSet), null, _mainOk);
                return true;
            case "contains" when current is RuntimeBitSet containsBitSet:
                result = new RuntimeFlowResult(
                    EmitBitSetContains(containsBitSet, EmitIntExpression(target.Arguments[0])), null, _mainOk);
                return true;
            case "contains" when current is RuntimeInlineDictionary set
                                     && _program.Types.IsSet(set.DictionaryType):
            {
                var setKey = target.Arguments[0] is DictionaryLiteralExpression contextualSetKey
                    && _program.Types.IsStruct(set.KeyType)
                        ? EmitContextualStructLiteral(contextualSetKey, set.KeyType)
                        : EmitExpression(target.Arguments[0]);
                result = new RuntimeFlowResult(EmitSetContains(set, setKey), null, _mainOk);
                return true;
            }
            case "insert" when current is RuntimeInlineDictionary set
                                   && _program.Types.IsSet(set.DictionaryType):
            {
                var setName = RequireMutableContainerSource(source, "insert");
                var setKey = target.Arguments[0] is DictionaryLiteralExpression contextualSetKey
                    && _program.Types.IsStruct(set.KeyType)
                        ? EmitContextualStructLiteral(contextualSetKey, set.KeyType)
                        : EmitExpression(target.Arguments[0]);
                var inserted = EmitSetInsert(set, setKey);
                StoreMutableContainer(setName, inserted.Set);
                _locals[setName] = inserted.Set;
                RemoveOwnedLiteralSources(target.Arguments[0], set.KeyType);
                result = new RuntimeFlowResult(inserted.Inserted, null, _mainOk);
                return true;
            }
            case "remove" when current is RuntimeInlineDictionary set
                                   && _program.Types.IsSet(set.DictionaryType):
            {
                var setName = RequireMutableContainerSource(source, "remove");
                var setKey = target.Arguments[0] is DictionaryLiteralExpression contextualSetKey
                    && _program.Types.IsStruct(set.KeyType)
                        ? EmitContextualStructLiteral(contextualSetKey, set.KeyType)
                        : EmitExpression(target.Arguments[0]);
                var removed = EmitSetRemove(set, setKey);
                StoreMutableContainer(setName, removed.Set);
                _locals[setName] = removed.Set;
                result = new RuntimeFlowResult(removed.Removed, null, _mainOk);
                return true;
            }
            case "set" when current is RuntimeBitSet setBitSet:
                RequireMutableContainerSource(source, "set");
                EmitBitSetMutation(setBitSet, EmitIntExpression(target.Arguments[0]), set: true);
                result = new RuntimeFlowResult(RuntimeUnit.Instance, null, _mainOk);
                return true;
            case "clear" when current is RuntimeBitSet clearBitSet:
                RequireMutableContainerSource(source, "clear");
                EmitBitSetMutation(clearBitSet, EmitIntExpression(target.Arguments[0]), set: false);
                result = new RuntimeFlowResult(RuntimeUnit.Instance, null, _mainOk);
                return true;
            case "byte" when current is RuntimeSourceText sourceText:
                if (target.Arguments.Count != 1)
                {
                    throw new SollangException("SourceText byte expects one index");
                }
                var sourceByteIndex = EmitMapInteger(target.Arguments[0], BoundType.UIntSize, "source_text_byte_index");
                var sourceByteInBounds = NextTemp("source_text_byte_in_bounds");
                EmitCompare(sourceByteInBounds, "ult", "i64", sourceByteIndex, sourceText.LengthName);
                EmitTrapUnless(sourceByteInBounds, "source_text_byte_bounds");
                var sourceBytePointer = NextTemp("source_text_byte_ptr");
                EmitAssign(sourceBytePointer, $"getelementptr i8, ptr {sourceText.DataPointerName}, i64 {sourceByteIndex}");
                var sourceByteValue = NextTemp("source_text_byte");
                EmitLoad(sourceByteValue, "i8", sourceBytePointer, 1);
                result = new RuntimeFlowResult(new RuntimeInt(BoundType.UInt8, sourceByteValue), null, _mainOk);
                return true;
            case "slice" when current is RuntimeSourceText sourceText:
                if (target.Arguments.Count != 2)
                {
                    throw new SollangException("SourceText slice expects start and byte length");
                }
                var sourceSliceStart = EmitMapInteger(target.Arguments[0], BoundType.UIntSize, "source_text_slice_start");
                var sourceSliceLength = EmitMapInteger(target.Arguments[1], BoundType.UIntSize, "source_text_slice_length");
                result = new RuntimeFlowResult(
                    EmitTextSlice(new RuntimeText(sourceText.DataPointerName, sourceText.LengthName), sourceSliceStart, sourceSliceLength),
                    null,
                    _mainOk);
                return true;
            case "byte" when current is RuntimeText text:
                if (target.Arguments.Count != 1)
                {
                    throw new SollangException("Text byte expects one index");
                }
                var byteIndex = EmitMapInteger(target.Arguments[0], BoundType.UIntSize, "text_byte_index");
                var byteInBounds = NextTemp("text_byte_in_bounds");
                EmitCompare(byteInBounds, "ult", "i64", byteIndex, text.LengthName);
                EmitTrapUnless(byteInBounds, "text_byte_bounds");
                var bytePointer = NextTemp("text_byte_ptr");
                EmitAssign(bytePointer, $"getelementptr i8, ptr {text.PointerName}, i64 {byteIndex}");
                var byteValue = NextTemp("text_byte");
                EmitLoad(byteValue, "i8", bytePointer, 1);
                result = new RuntimeFlowResult(new RuntimeInt(BoundType.UInt8, byteValue), null, _mainOk);
                return true;
            case "slice" when current is RuntimeText text:
                if (target.Arguments.Count != 2)
                {
                    throw new SollangException("Text slice expects start and byte length");
                }
                var sliceStart = EmitMapInteger(target.Arguments[0], BoundType.UIntSize, "text_slice_start");
                var sliceLength = EmitMapInteger(target.Arguments[1], BoundType.UIntSize, "text_slice_length");
                result = new RuntimeFlowResult(EmitTextSlice(text, sliceStart, sliceLength), null, _mainOk);
                return true;
            case "capacity":
                if (target.Arguments.Count != 0)
                {
                    throw new SollangException("capacity does not accept arguments");
                }

                result = current switch
                {
                    RuntimeDynamicIntArray dynamicArray => new RuntimeFlowResult(EmitCapacityAsInt(dynamicArray.CapacityName, "array_capacity_value"), null, _mainOk),
                    RuntimeDynamicInlineArray dynamicArray => new RuntimeFlowResult(EmitCapacityAsInt(dynamicArray.CapacityName, "array_capacity_value"), null, _mainOk),
                    RuntimeIntDictionaryView dictionaryView => new RuntimeFlowResult(EmitCapacityAsInt(dictionaryView.CapacityName, "dict_capacity_value"), null, _mainOk),
                    RuntimeIntDictionary intDictionary => new RuntimeFlowResult(EmitCapacityAsInt(intDictionary.CapacityName, "dict_capacity_value"), null, _mainOk),
                    RuntimeInlineDictionary inlineMap => new RuntimeFlowResult(
                        EmitCapacityAsInt(
                            _program.Types.IsBoundedDictionary(inlineMap.DictionaryType)
                                ? _program.Types.GetBoundedDictionary(inlineMap.DictionaryType).MaxEntries.ToString(CultureInfo.InvariantCulture)
                                : inlineMap.CapacityName,
                            "dict_capacity_value"),
                        null,
                        _mainOk),
                    RuntimeArena arena => new RuntimeFlowResult(
                        new RuntimeInt(BoundType.UIntSize, EmitUIntSizeFromI64(arena.CapacityName)), null, _mainOk),
                    _ => result
                };
                return result.Value is not null;
            case "reserve":
            {
                var ownerName = RequireMutableContainerSource(source, "reserve");
                var requestedInt = EmitIntExpression(target.Arguments[0]);
                var nonnegative = NextTemp("reserve_nonnegative");
                EmitCompare(nonnegative, "sge", "i32", requestedInt.ValueName, "0");
                EmitTrapUnless(nonnegative, "reserve_negative_capacity");
                var requested = EmitIntAsSize(requestedInt, "reserve_capacity");
                RuntimeValue reserved = current switch
                {
                    RuntimeDynamicIntArray array => EmitDynamicArrayReserve(array, requested),
                    RuntimeDynamicInlineArray array when _program.Types.IsDeque(array.ArrayType) =>
                        EmitDequeReserve(array, requested),
                    RuntimeDynamicInlineArray array => EmitDynamicInlineArrayReserve(array, requested),
                    RuntimeIntDictionary reserveIntDictionary => EmitDictionaryReserve(reserveIntDictionary, requested),
                    RuntimeInlineDictionary reserveSet when _program.Types.IsSet(reserveSet.DictionaryType) =>
                        EmitSetReserve(reserveSet, requested),
                    RuntimeInlineDictionary reserveDictionary => EmitInlineDictionaryReserve(reserveDictionary, requested),
                    _ => throw new SollangException("reserve expects a mutable heap collection owner")
                };
                StoreMutableContainer(ownerName, reserved);
                _locals[ownerName] = reserved;
                result = new RuntimeFlowResult(null, null, _mainOk);
                return true;
            }
            case "pushAll":
            {
                var ownerName = RequireMutableContainerSource(source, "pushAll");
                var bulkSource = EmitExpression(target.Arguments[0]);
                RuntimeValue bulkResult = current switch
                {
                    RuntimeDynamicIntArray array when bulkSource is RuntimeStaticIntArray fixedArray =>
                        EmitDynamicArrayPushAll(array, fixedArray),
                    RuntimeDynamicInlineArray array when !_program.Types.IsBinaryHeap(array.ArrayType)
                                                         && !_program.Types.IsDeque(array.ArrayType) =>
                        EmitDynamicInlineArrayPushAll(array, bulkSource),
                    _ => throw new SollangException("pushAll expects a mutable heap array and a compatible fixed array")
                };
                StoreMutableContainer(ownerName, bulkResult);
                _locals[ownerName] = bulkResult;
                result = new RuntimeFlowResult(null, null, _mainOk);
                return true;
            }
            case "push":
                if (current is not (RuntimeDynamicIntArray or RuntimeDynamicInlineArray))
                {
                    return false;
                }
                if (current is RuntimeDynamicInlineArray invariantArray
                    && _program.Types.IsDeque(invariantArray.ArrayType))
                {
                    return false;
                }

                if (!isLast)
                {
                    throw new SollangException("push must be the final value-flow target");
                }

                if (target.Arguments.Count != 1)
                {
                    throw new SollangException("push expects exactly one Int argument");
                }

                var arrayName = source is NameExpression
                    ? RequireMutableContainerSource(source, "push")
                    : RequireMutableContainerProjection(source, "push");
                var pushed = current is RuntimeDynamicInlineArray contextualArray
                    && target.Arguments[0] is DictionaryLiteralExpression contextualElement
                    && _program.Types.IsStruct(contextualArray.ElementType)
                        ? EmitContextualStructLiteral(contextualElement, contextualArray.ElementType)
                        : EmitFunctionArgumentExpression(
                            target.Arguments[0],
                            current is RuntimeDynamicInlineArray contextualPushArray
                                ? contextualPushArray.ElementType
                                : BoundType.Int);
                var pushedArray = current switch
                {
                    RuntimeDynamicIntArray array when pushed is RuntimeInt integer =>
                        (RuntimeValue)EmitDynamicArrayPush(array, integer.ValueName),
                    RuntimeDynamicInlineArray array when _program.Types.IsBinaryHeap(array.ArrayType) =>
                        EmitBinaryHeapPush(array, pushed),
                    RuntimeDynamicInlineArray array => EmitDynamicInlineArrayPush(array, pushed),
                    _ => throw new SollangException("push argument does not match array element type")
                };
                if (arrayName is not null)
                {
                    StoreMutableContainer(arrayName, pushedArray);
                    _locals[arrayName] = pushedArray;
                }
                else
                {
                    StoreMutableContainerProjection(source, pushedArray, "push");
                }
                if (current is RuntimeDynamicInlineArray ownedElementArray
                    && _program.Types.ContainsOwnedStorage(ownedElementArray.ElementType))
                {
                    RemoveOwnedLiteralSources(target.Arguments[0], ownedElementArray.ElementType);
                }
                result = new RuntimeFlowResult(null, null, _mainOk);
                return true;
            case "pushFront" or "pushBack" when current is RuntimeDynamicInlineArray deque
                                                   && _program.Types.IsDeque(deque.ArrayType):
            {
                if (target.Arguments.Count != 1)
                {
                    throw new SollangException($"Deque {path} expects exactly one argument");
                }
                var dequeName = RequireMutableContainerSource(source, path);
                var item = target.Arguments[0] is DictionaryLiteralExpression contextualDequeElement
                    && _program.Types.IsStruct(deque.ElementType)
                        ? EmitContextualStructLiteral(contextualDequeElement, deque.ElementType)
                        : EmitFunctionArgumentExpression(target.Arguments[0], deque.ElementType);
                var pushedDeque = EmitDequePush(deque, item, front: path == "pushFront");
                StoreMutableContainer(dequeName, pushedDeque);
                _locals[dequeName] = pushedDeque;
                if (_program.Types.ContainsOwnedStorage(deque.ElementType))
                {
                    RemoveOwnedLiteralSources(target.Arguments[0], deque.ElementType);
                }
                result = new RuntimeFlowResult(null, null, _mainOk);
                return true;
            }
            case "front" or "back" when current is RuntimeDynamicInlineArray deque
                                            && _program.Types.IsDeque(deque.ArrayType):
                result = new RuntimeFlowResult(EmitDequePeek(deque, front: path == "front"), null, _mainOk);
                return true;
            case "popFront" or "popBack" when current is RuntimeDynamicInlineArray deque
                                                  && _program.Types.IsDeque(deque.ArrayType):
            {
                var dequeName = RequireMutableContainerSource(source, path);
                var popped = EmitDequePop(deque, front: path == "popFront");
                StoreMutableContainer(dequeName, popped.Deque);
                _locals[dequeName] = popped.Deque;
                result = new RuntimeFlowResult(popped.Value, null, _mainOk);
                return true;
            }
            case "peek" when current is RuntimeDynamicInlineArray peekHeap
                                  && _program.Types.IsBinaryHeap(peekHeap.ArrayType):
                if (target.Arguments.Count != 0)
                {
                    throw new SollangException("BinaryHeap peek does not accept arguments");
                }
                result = new RuntimeFlowResult(EmitBinaryHeapPeek(peekHeap), null, _mainOk);
                return true;
            case "pop" when current is RuntimeDynamicInlineArray popHeap
                                 && _program.Types.IsBinaryHeap(popHeap.ArrayType):
            {
                if (target.Arguments.Count != 0)
                {
                    throw new SollangException("BinaryHeap pop does not accept arguments");
                }
                var heapName = RequireMutableContainerSource(source, "pop");
                var popped = EmitBinaryHeapPop(popHeap);
                StoreMutableContainer(heapName, popped.Heap);
                _locals[heapName] = popped.Heap;
                result = new RuntimeFlowResult(popped.Value, null, _mainOk);
                return true;
            }
            case "take":
            {
                if (current is not (RuntimeDynamicIntArray
                    or RuntimeDynamicInlineArray
                    or RuntimeIntDictionary
                    or RuntimeInlineDictionary))
                {
                    return false;
                }

                if (target.Arguments.Count != 1)
                {
                    throw new SollangException("take expects exactly one index or key argument");
                }

                var takeName = source is NameExpression
                    ? RequireMutableContainerSource(source, "take")
                    : RequireMutableContainerProjection(source, "take");
                RuntimeValue takenValue;
                RuntimeValue remainingContainer;
                switch (current)
                {
                    case RuntimeDynamicIntArray intArray:
                    {
                        var index = EmitIntAsSize(EmitIntExpression(target.Arguments[0]), "take_index");
                        var taken = EmitDynamicArrayTake(intArray, index);
                        takenValue = taken.Value;
                        remainingContainer = taken.Array;
                        break;
                    }
                    case RuntimeDynamicInlineArray inlineArray:
                    {
                        var index = EmitIntAsSize(EmitIntExpression(target.Arguments[0]), "take_index");
                        var taken = EmitDynamicInlineArrayTake(inlineArray, index);
                        takenValue = taken.Value;
                        remainingContainer = taken.Array;
                        break;
                    }
                    case RuntimeIntDictionary intDictionary:
                    {
                        var takeIntKey = EmitIntExpression(target.Arguments[0]);
                        var taken = EmitDictionaryTake(intDictionary, takeIntKey.ValueName);
                        takenValue = taken.Value;
                        remainingContainer = taken.Dictionary;
                        break;
                    }
                    case RuntimeInlineDictionary takeInlineDictionary:
                    {
                        var takeInlineKey = target.Arguments[0] is DictionaryLiteralExpression contextualTakeKey
                            && _program.Types.IsStruct(takeInlineDictionary.KeyType)
                                ? EmitContextualStructLiteral(contextualTakeKey, takeInlineDictionary.KeyType)
                                : EmitExpression(target.Arguments[0]);
                        var taken = EmitInlineDictionaryTake(takeInlineDictionary, takeInlineKey);
                        takenValue = taken.Value;
                        remainingContainer = taken.Dictionary;
                        break;
                    }
                    default:
                        throw new SollangException("take expects a dynamic array or dictionary owner");
                }

                if (takeName is not null)
                {
                    StoreMutableContainer(takeName, remainingContainer);
                    _locals[takeName] = remainingContainer;
                }
                else
                {
                    StoreMutableContainerProjection(source, remainingContainer, "take");
                }
                result = new RuntimeFlowResult(takenValue, null, _mainOk);
                return true;
            }
            case "append":
                if (current is not RuntimeDynamicIntArray appendArray)
                {
                    return false;
                }

                if (!isLast)
                {
                    throw new SollangException("append must be bound directly with '=>'");
                }

                // A preceding call owns its returned container independently of the source place.
                if (!ownsFlowTemporary)
                    RequireMoveContainerSource(source, "append");

                if (target.Arguments.Count != 1)
                {
                    throw new SollangException("append expects exactly one Int argument");
                }

                var appended = EmitIntExpression(target.Arguments[0]);
                result = new RuntimeFlowResult(
                    EmitDynamicArrayAppendMove(appendArray, appended.ValueName),
                    null,
                    _mainOk);
                return true;
            case "putIfAbsent":
                if (current is RuntimeInlineDictionary conditionalDictionary)
                {
                    if (!isLast || target.Arguments.Count != 2)
                    {
                        throw new SollangException("putIfAbsent must be final and expects key and value arguments");
                    }
                    var conditionalName = RequireMutableContainerSource(source, "putIfAbsent");
                    var conditionalKey = target.Arguments[0] is DictionaryLiteralExpression contextualKey
                        && _program.Types.IsStruct(conditionalDictionary.KeyType)
                            ? EmitContextualStructLiteral(contextualKey, conditionalDictionary.KeyType)
                            : EmitExpression(target.Arguments[0]);
                    var conditionalValue = target.Arguments[1] is DictionaryLiteralExpression contextualValue
                        && _program.Types.IsStruct(conditionalDictionary.ValueType)
                            ? EmitContextualStructLiteral(contextualValue, conditionalDictionary.ValueType)
                            : EmitExpression(target.Arguments[1]);
                    var conditional = EmitInlineDictionaryPutIfAbsent(
                        conditionalDictionary, conditionalKey, conditionalValue);
                    RemoveOwnedLiteralSources(target.Arguments[0], conditionalDictionary.KeyType);
                    RemoveOwnedLiteralSources(target.Arguments[1], conditionalDictionary.ValueType);
                    StoreMutableContainer(conditionalName, conditional.Dictionary);
                    _locals[conditionalName] = conditional.Dictionary;
                    result = new RuntimeFlowResult(conditional.Inserted, null, _mainOk);
                    return true;
                }
                if (current is RuntimeIntDictionary conditionalIntDictionary)
                {
                    if (!isLast || target.Arguments.Count != 2)
                    {
                        throw new SollangException("putIfAbsent must be final and expects key and value arguments");
                    }
                    var conditionalName = RequireMutableContainerSource(source, "putIfAbsent");
                    var conditionalKey = EmitIntExpression(target.Arguments[0]);
                    var conditionalValue = EmitIntExpression(target.Arguments[1]);
                    var conditional = EmitDictionaryPutIfAbsent(
                        conditionalIntDictionary, conditionalKey.ValueName, conditionalValue.ValueName);
                    StoreMutableContainer(conditionalName, conditional.Dictionary);
                    _locals[conditionalName] = conditional.Dictionary;
                    result = new RuntimeFlowResult(conditional.Inserted, null, _mainOk);
                    return true;
                }
                return false;
            case "put":
                if (current is RuntimeInlineDictionary inlineDictionary)
                {
                    if (!isLast || target.Arguments.Count != 2)
                    {
                        throw new SollangException("put must be final and expects key and value arguments");
                    }
                    var inlineName = RequireMutableContainerSource(source, "put");
                    var inlineKey = target.Arguments[0] is DictionaryLiteralExpression contextualKey
                        && _program.Types.IsStruct(inlineDictionary.KeyType)
                            ? EmitContextualStructLiteral(contextualKey, inlineDictionary.KeyType)
                            : EmitExpression(target.Arguments[0]);
                    var inlineValue = target.Arguments[1] is DictionaryLiteralExpression contextualValue
                        && _program.Types.IsStruct(inlineDictionary.ValueType)
                            ? EmitContextualStructLiteral(contextualValue, inlineDictionary.ValueType)
                            : EmitExpression(target.Arguments[1]);
                    var inlineUpdated = EmitInlineDictionaryPut(inlineDictionary, inlineKey, inlineValue);
                    RemoveOwnedLiteralSources(target.Arguments[0], inlineDictionary.KeyType);
                    RemoveOwnedLiteralSources(target.Arguments[1], inlineDictionary.ValueType);
                    StoreMutableContainer(inlineName, inlineUpdated);
                    _locals[inlineName] = inlineUpdated;
                    result = new RuntimeFlowResult(null, null, _mainOk);
                    return true;
                }
                if (current is not RuntimeIntDictionary dictionary)
                {
                    return false;
                }

                if (!isLast)
                {
                    throw new SollangException("put must be the final value-flow target");
                }

                if (target.Arguments.Count != 2)
                {
                    throw new SollangException("put expects key and value Int arguments");
                }

                var dictionaryName = RequireMutableContainerSource(source, "put");
                var key = EmitIntExpression(target.Arguments[0]);
                var value = EmitIntExpression(target.Arguments[1]);
                var updatedDictionary = EmitDictionaryPut(dictionary, key.ValueName, value.ValueName);
                StoreMutableContainer(dictionaryName, updatedDictionary);
                _locals[dictionaryName] = updatedDictionary;
                result = new RuntimeFlowResult(null, null, _mainOk);
                return true;
            case "updated":
                if (current is not (RuntimeDynamicIntArray or RuntimeIntDictionary))
                {
                    return false;
                }

                if (!isLast)
                {
                    throw new SollangException("updated must be bound directly with '=>'");
                }

                if (!ownsFlowTemporary)
                    RequireMoveContainerSource(source, "updated");

                if (target.Arguments.Count != 2)
                {
                    throw new SollangException("updated expects two Int arguments");
                }

                var updateKeyOrIndex = EmitIntExpression(target.Arguments[0]);
                var updateValue = EmitIntExpression(target.Arguments[1]);
                result = current switch
                {
                    RuntimeDynamicIntArray updateArray => new RuntimeFlowResult(
                        EmitDynamicArrayUpdatedMove(updateArray, EmitIntAsSize(updateKeyOrIndex, "updated_index"), updateValue.ValueName),
                        null,
                        _mainOk),
                    RuntimeIntDictionary updateDictionary => new RuntimeFlowResult(
                        EmitDictionaryUpdatedMove(updateDictionary, updateKeyOrIndex.ValueName, updateValue.ValueName),
                        null,
                        _mainOk),
                    _ => result
                };
                return result.Value is not null;
            default:
                return false;
        }
    }

    private string RequireMutableContainerSource(Expression source, string operation)
    {
        if (source is not NameExpression name)
        {
            throw new SollangException($"{operation} requires a named mutable owner in the current slice");
        }

        if (!_mutableLocals.Contains(name.Name))
        {
            throw new SollangException($"{operation} requires writable owner storage; change a readonly parameter from '{name.Name.TrimEnd('!')}: Type' to '{name.Name.TrimEnd('!')}: mut Type', declare an instance receiver as 'mut self', or bind local owned storage with '=> {name.Name.TrimEnd('!')}!'");
        }

        return name.Name;
    }

    private string? RequireMutableContainerProjection(Expression source, string operation)
    {
        if (source is not FieldAccessExpression { Source: NameExpression owner }
            || !_mutableLocals.Contains(owner.Name)
            || !_mutableStructSlots.ContainsKey(owner.Name))
        {
            throw new SollangException($"{operation} requires a mutable container owner or mutable struct-field place");
        }
        return null;
    }

    private void StoreMutableContainerProjection(Expression source, RuntimeValue value, string operation)
    {
        var place = EmitReferencePlace(source);
        if (place.ElementType != value.Type)
        {
            throw new SollangException($"{operation} projected container type changed from {place.ElementType} to {value.Type}");
        }
        var materialized = MaterializeAggregateValue(value);
        EmitStore(
            materialized.TypeName,
            materialized.ValueName,
            place.PointerName,
            RuntimeAlignment(value.Type));
    }

    private string RequireMoveContainerSource(Expression source, string operation)
    {
        if (source is not NameExpression name)
        {
            throw new SollangException($"{operation} requires a named container owner so ownership can move");
        }

        if (!_locals.ContainsKey(name.Name))
        {
            throw new SollangException($"{operation} source owner '{name.Name}' is not live");
        }

        return name.Name;
    }

}


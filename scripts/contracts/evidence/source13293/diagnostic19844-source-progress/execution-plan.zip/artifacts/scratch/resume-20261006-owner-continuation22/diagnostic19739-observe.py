from pathlib import Path
import argparse,datetime,json
parser=argparse.ArgumentParser();parser.add_argument('--result',default='diagnostic19741-slg-source');parser.add_argument('--epoch',default='19743');parser.add_argument('--contract',default='diagnostic19740-contract.json');parser.add_argument('--wasm-result');args=parser.parse_args()
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';e=r/f'scripts/contracts/evidence/source13293/diagnostic{args.epoch}-source-progress'
e.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def rel(p):return p.relative_to(r).as_posix()
p=b/args.result/'result.json';result=read(p)
contract=read(b/args.contract)
assert result['total']==len(contract['cases'])
if args.wasm_result:
    wasm=read(b/args.wasm_result/'result.json');assert wasm['total']==1
    windows=result
    result=dict(status='failed' if any(x['status']=='failed' for x in (windows,wasm)) else 'passed' if all(x['status']=='passed' for x in (windows,wasm)) else 'running',completed=windows['completed']+wasm['completed'],total=46,cases=windows['cases']+wasm['cases'],windows=windows,wasm=wasm)
    contract['cases']+=read(b/'diagnostic19744-wasm-contract.json')['cases']
total=result['total']
snapshot=dict(schemaVersion=1,observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),result=result,claimsPhaseComplete=False,claimsGoalComplete=False)
snapshotPath=e/('snapshot-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%f')+'.json');put(snapshotPath,snapshot)
byid={x['id']:x for x in result['cases']}
rows=[]
for c in contract['cases']:
 x=byid.get(c['id'],{});state=x.get('status','pending')
 if state=='running' and result['status'] not in ('running','pending'):state='failed'
 rows.append(dict(id=c['id'],status='complete' if x.get('passed') else state))
gate=dict(schemaVersion=1,id=f'C754-current-source-diagnostic{total}-epoch{args.epoch}',status='running' if result['status']=='running' else 'complete' if result['status']=='passed' else 'failed',completed=result['completed'],total=total,cases=rows,evidence=rel(snapshotPath),claimsPhaseComplete=False,claimsGoalComplete=False)
gate['steps']=rows
put(e/'focused-gate.json',gate)
p=r/'scripts/contracts/active-goal-progress.json';a=read(p)
a['currentFocusedGate']=gate['id'];a['currentDiagnosticModuleSourceProgressEvidence']=rel(snapshotPath)
entry=dict(name=gate['id'],evidence=rel(e/'focused-gate.json'),status='complete' if result['status']=='passed' else 'active',completed=result['completed'],total=total)
old=next((x for x in a['focusedGates'] if x['name']==gate['id']),None)
if old is None:a['focusedGates'].append(entry)
else:old.update(entry)
a['currentWork'].update(focus=f'C754 current CSharp37+controls9 and current SLG semantic4/stdlib1 passed. Actual SLG source diagnostics{total}: {result["status"]}; no general Native product acceptance.',checkpoint=rel(snapshotPath))
a['currentWork']['activeExecutions']=[rel(b/args.result/'result.json')] if result['status']=='running' else []
if total==54:
    a['currentWork']['focus']=f'C754/C755 current CSharp references and controls10, SLG semantic4/stdlib1 passed. Current source suite54: {result["status"]}; no general Native product or phase acceptance.'
    selections={
        'C755':[x for x in rows if x['id'].startswith('c755-') or x['id']=='control-moved-main-interpolation'],
        'C754':[x for x in rows if not x['id'].startswith('c755-')],
        'C756':[x for x in rows if x['id']=='c755-borrowed'],
    }
    assert {key:len(value) for key,value in selections.items()}=={'C755':10,'C754':45,'C756':1}
    for prefix,selected in selections.items():
        completed=sum(x['status']=='complete' for x in selected)
        unitGate=e/(prefix.lower()+'-focused-gate.json')
        put(unitGate,dict(schemaVersion=1,status='complete' if completed==len(selected) else 'failed' if any(x['status']=='failed' for x in selected) else 'running',completed=completed,total=len(selected),steps=selected,evidence=rel(snapshotPath),claimsGoalComplete=False))
        unit=next(x for x in a['queuedUnits']+a['completedUnits'] if x['id'].startswith(prefix+'-'))
        unit.update(focusedComplete=completed,focusedTotal=len(selected),focusedEvidence=rel(unitGate),focusedCountScope='Observed current source subset of shared54. No general Native or phase acceptance.')
put(p,a)
print(json.dumps(dict(status=result['status'],completed=result['completed'],total=total,evidence=rel(snapshotPath))))

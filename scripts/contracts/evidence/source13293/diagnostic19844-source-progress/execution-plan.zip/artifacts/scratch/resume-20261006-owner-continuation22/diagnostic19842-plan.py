from pathlib import Path
import copy,importlib.util,json
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';p=b/'diagnostic19837-contract.json';c=json.loads(p.read_text(encoding='utf-8-sig'))
source=(b/'diagnostic19842-emitter.slg').relative_to(r).as_posix();c['reusableCheckedProducer']['source']=source;c['formatCheckSources']=[source]
for case in c['cases']:case['source']=source
spec=importlib.util.spec_from_file_location('selection_generator',r/'scripts/generate-selection-result-emitter.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
order,groups=g.validated_runtime_program_groups(c,r)
wrapper=r/source;rendered=g.render('',checked=True,package_paths=order,runtime_program_paths=list(groups),checked_files=True,runtime_program_groups=groups)
if wrapper.exists():assert wrapper.read_bytes()==rendered
else:wrapper.write_bytes(rendered)
spec=importlib.util.spec_from_file_location('checked_validator',r/'scripts/verify-checked-package-emitter.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);v.validate_reusable(c,r)
old=json.loads((b/'diagnostic19818-contract.json').read_text(encoding='utf-8-sig'))
def assertions(c):
 result=copy.deepcopy(c['cases'])
 for row in result:row.pop('source')
 return sorted(result,key=lambda x:x['id'])
assert assertions(old)==assertions(c)
p=b/'diagnostic19842-contract.json';assert not p.exists();p.write_text(json.dumps(c,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps(dict(cases=len(c['cases']),first=c['cases'][0]['id'],canonicalWrapper=True,originalAssertionsUnchanged=True)))

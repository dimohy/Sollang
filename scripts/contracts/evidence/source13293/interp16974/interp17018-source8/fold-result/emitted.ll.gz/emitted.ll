sollang: semantic error at 2:5: [module '<main>'] string interpolation expects Text, Int, or Bool but received Range
selection-emission-rejected

from pathlib import Path
import json,sys,hashlib
import argparse
parser=argparse.ArgumentParser();parser.add_argument('--side',choices=['managed','selfhost'],required=True);args=parser.parse_args();side=args.side
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';o=b/f'parsing20105-{side}-negatives';o.mkdir(exist_ok=False);sys.path.insert(0,str(r/'scripts'))
from verification_execution import VerificationExecution
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
plan=b/'parsing19045/negative-plan.json';rows=read(plan)['cases'];assert len(rows)==11;base=read(b/f'parsing20105-{side}-command.json');assert base[-1]==side
paths=[Path(__file__),plan,b/f'parsing20105-{side}-command.json',b/'parsing20070/execution-contract.json',b/'parsing20070/reviewed-inventory.json',r/'scripts/verify-compiler-parity-negative-fixture.ps1',r/'scripts/native-exact-fixture-receipt.ps1',r/'scripts/verification-process.ps1',r/'scripts/verification_execution.py']+[Path(row[k]) for row in rows for k in ['source','expected']];pins={str(p):sha(p) for p in paths}
d=dict(schemaVersion=1,status='running',completed=0,total=11,inputHashes=pins,cases=[],scope='Execute the11 missing compile-only negative phase witnesses using the existing parity runner with the explicitly selected compiler side. Current18 decisions and all24 witnesses; current405 must pass first and is not rerun.',caseBudgetSeconds=180,aggregateBudgetSeconds=1980,claimsGoalComplete=False)
x=VerificationExecution(r,o,d,lambda:all(sha(p)==v for p,v in pins.items()),sha);error=None
try:
 batch=read(b/f'parsing20070/{side}/{side}-batch-results.json');assert batch['state']=='passed' and batch['completed']==batch['passed']==batch['total']==405 and batch['failed']==batch['missing']==0
 for row in rows:
  command=list(base)
  for key,value in [('-Source',row['source']),('-Expected',row['expected']),('-OutputDirectory',str(b/'parsing20070'/('negative-'+side)/row['id']))]:command[command.index(key)+1]=value
  a=x.run(command,o/row['id'],timeout=180);assert a.returncode==0,('PARSING_NEGATIVE_FAILED',row['id'],a.stderr[:1800]);d['completed']+=1;d['cases'].append(dict(id=row['id'],status='passed'));x.save()
 canonical=b/f'parsing20070/evidence/{side}-phase-execution.json';proof=read(canonical);assert proof['status']=='passed' and proof['completed']==proof['total']==24 and proof['inputStable'];d.update(status='passed',canonicalPhaseRecord=str(canonical))
except BaseException as e:error=e
finally:x.finalize(error,cleanup=False)
print(json.dumps({k:d.get(k) for k in ['status','completed','total','failure','inputsStable','processesStopped']}));sys.exit(0 if d['status']=='passed' else 1)

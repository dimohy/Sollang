from pathlib import Path
import json,sys,hashlib
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from completed_artifact_plan import initialize_output,cleanup_output
from verification_fingerprints import managed_runtime_inputs
C=B/'task25328-managed/compiler/Sollang.Compiler.exe';O=B/'array25356-format-controls';reuse=[B/'array25358-native',B/'task25340-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir()
old=B/'array25349-export/runtime-policy-probe.slg';new=B/'array25353-export/runtime-policy-probe.slg';contract=B/'array25353-export/runtime-policy-contract.json';plan=json.loads(contract.read_text());assert str(new) in plan['formatCheckSources']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();pins={str(p.resolve()):sha(p) for p in [Path(__file__),old,new,contract,*managed_runtime_inputs(C)]};r=dict(schemaVersion=1,status='running',completed=0,total=2,inputHashes=pins,cases=[],codegenInvoked=False,guardConnected=True)
x=VerificationExecution(R,O,r,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
try:
 for label,source,expected in [('previous-invalid-probe-rejected',old,1),('current-probe-accepted',new,0)]:
  done=x.run([str(C),'format','--check',str(source)],O/label,timeout=20);assert done.returncode==expected,(label,done.stdout,done.stderr)
  if expected:assert 'expected expression' in done.stderr
  else:assert not done.stdout and not done.stderr
  r['cases'].append(dict(id=label,passed=True,exit=done.returncode));r['completed']+=1
 r['status']='passed'
except BaseException as e:error=e
finally:x.finalize(error,cleanup=False)
if error:raise error
cleanup_output(R,O,reusable_directories=reuse)
print(json.dumps({k:r[k] for k in ['status','completed','total','inputsStable','processesStopped','codegenInvoked']}))

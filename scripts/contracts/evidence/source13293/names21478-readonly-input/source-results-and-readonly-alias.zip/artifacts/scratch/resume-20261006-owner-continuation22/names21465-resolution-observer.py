from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'names21465-resolution-observer';CPP=B/'managed21139/compiler/Sollang.Compiler.exe';planFile=B/'names21463-plan.json';plan=json.loads(planFile.read_text());probe=ROOT/plan['probe'];sources=[ROOT/p for p in plan['sources']];std=sorted((ROOT/'stdlib').rglob('*.slg'));subject=ROOT/'scripts/probes/ownership-origin/public-readonly-block.slg';oracle=subject.with_suffix('.stdout.txt');reference=B/'region21457-fixed-emitter/result.json';old=json.loads(reference.read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();assert next(c for c in old['cases'] if c['id']=='csharp-public-readonly-block')['stdout']==oracle.read_text();assert all(sha(p)==old['inputHashes'][str(p)] for p in [CPP,*managed_runtime_inputs(CPP),subject,oracle]);inputs=[Path(__file__),planFile,ROOT/'scripts/source-module-header.ps1',CPP,*managed_runtime_inputs(CPP),probe,subject,oracle,reference,*sources,*std];hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=4,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Exact production analysis/symbol/local name resolution on public empty dynamic mutable binding source: dependency-closed19 compiler providers, single-file and full stdlib comparison. CSharp positive runtime reference reverified; diagnosis only.',claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  done=run.run([str(CPP),'build',str(probe),*map(str,sources),'-o',str(OUT/'observer.exe'),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','24','-O0','--keep-temps'],OUT/'build',timeout=180);assert done.returncode==0 and not done.stderr,done.stdout[-1600:]+done.stderr;result['cases'].append(dict(id='analysis-observer-build',passed=True));result['completed']+=1;run.save();outputs=[]
  for label,paths in [('single',[subject]),('full-stdlib',std+[subject])]:
   done=run.run([str(OUT/'observer.exe'),*map(str,paths)],OUT/label,timeout=180);assert done.returncode==0 and not done.stderr and done.stdout.startswith('counts='),done.stdout[-1600:]+done.stderr;lines=[x for x in done.stdout.splitlines() if not x.startswith('owners=')];outputs.append(lines);result['cases'].append(dict(id=label,passed=True,sourceCount=len(paths)));result['completed']+=1;run.save()
  assert outputs[0]==outputs[1],'Local resolution facts changed with stdlib';result['cases'].append(dict(id='single-vs-full-identical-local-facts',passed=True));result['completed']+=1;result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

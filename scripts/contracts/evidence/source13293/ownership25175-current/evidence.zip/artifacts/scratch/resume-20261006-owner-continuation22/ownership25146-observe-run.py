from pathlib import Path
import sys,json,hashlib
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output,cleanup_output
P=B/'ownership25145-ir-observation';O=B/'ownership25146-ir-run';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));old=read(P/'result.json');assert old['status']=='timed-out' and old['inputsStable'] and old['processesStopped']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();pins=old['inputHashes'];assert all(sha(p)==h for p,h in pins.items());pins={**pins,str((P/'observer.exe').resolve()):sha(P/'observer.exe'),str(Path(__file__).resolve()):sha(Path(__file__))};reuse=[B/'bitset25123-native',B/'layout25036-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir()
plan=dict(reason='Existing O0 diagnostic executable exceeded20s without output while corresponding O1 Native CLI completed the narrow fixture. Reuse exact successful build and full source/tool fingerprint; no compiler build, original1999 or unchanged whole profile replay.',maximumAdditionalRuns=1,maximumAdditionalRunSeconds=60,previousRunSeconds=20,cumulativeRunBudgetSeconds=80,maximumCompilerBuilds=0)
(O/'execution-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(status='running',completed=0,total=1,cases=[],inputHashes=pins,scope='C795 IR observation only',budget=plan,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  d=ex.run([str(P/'observer.exe')],O/'run',timeout=60);assert d.returncode==0 and not d.stderr and 'kind=27,' in d.stdout,(d.stdout[-1000:],d.stderr)
  result.update(status='passed',completed=1,cases=[dict(id='production-native-preparation-IR-observed',passed=True)],observedStdout=d.stdout)
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reuse)
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))


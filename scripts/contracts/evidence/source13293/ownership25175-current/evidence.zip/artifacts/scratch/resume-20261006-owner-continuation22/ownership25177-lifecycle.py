from pathlib import Path
import sys,json
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(R/'scripts'))
from completed_artifact_plan import cleanup_output,assert_output_shutdown
reuse=[B/'ownership25157-native',B/'bitset25123-native',B/'v20050/compiler-build01'];rows=[]
for name in ['ownership25157-native','ownership25152-managed','ownership25169-managed']:
 assert_output_shutdown(R,B/name);p=cleanup_output(R,B/name,reusable_directories=reuse,temporary_only=True);d=json.loads(Path(str(p)+'.execution.json').read_text());assert d['status']=='completed';rows.append(dict(output=name,temporaryOnly=True,reclaimedBytes=d['reclaimedBytes'],execution=str(p)+'.execution.json'))
for name in ['layout25036-native','review24984-managed','layout25031-managed']:
 p=B/name/'artifact-cleanup-plan.json.execution.json';d=json.loads(p.read_text());assert d['status']=='completed';rows.append(dict(output=name,reclaimedBytes=d['reclaimedBytes'],execution=str(p)))
for p in reuse:assert (p/'compiler.exe').is_file()
for n in ['bitset25114-managed','ownership25152-managed','ownership25169-managed']:assert (B/n/'compiler/Sollang.Compiler.exe').is_file()
d=dict(status='completed',cleanup=rows,reusableNative=list(map(str,reuse)),reusableManaged=[str(B/n) for n in ['bitset25114-managed','ownership25152-managed','ownership25169-managed']],retainedSchemaLimitedOutput='ownership25156-csharp-error',schemaLimitation='Two expected-oracle rows omitted completion passed; immutable result retained. Fresh25158 and current25171 independently execute unchanged O0/O1 expectations with valid completion rows and successful lifecycle.',failedAndTimedOutOutputsPreserved=True,claimsGoalComplete=False)
(B/'ownership25177-lifecycle.json').write_text(json.dumps(d,indent=2)+'\n');print('lifecycle verified; exactly three declared Native and three managed products retained')

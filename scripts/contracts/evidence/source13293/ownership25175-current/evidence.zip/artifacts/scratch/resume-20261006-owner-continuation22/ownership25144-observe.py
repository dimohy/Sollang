from pathlib import Path
import sys,json,hashlib
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output,cleanup_output
C=B/'bitset25114-managed/compiler/Sollang.Compiler.exe';O=B/'ownership25144-ir-observation';reuse=[B/'bitset25123-native',B/'layout25036-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir()
helper=O/'observer.slg';helper.write_text((R/'scripts/probes/selection-result/context-branch-ir-observer.slg').read_text().replace('sources: sources!, pointerBitWidth:', 'sources: sources!, standardLibrarySourceStart: 1, standardLibrarySourceCount: 144, pointerBitWidth:').replace(',target=$(node.targetModule)',',operand1=$(node.operand1),next=$(node.nextOperand),target=$(node.targetModule)'),encoding='utf-8')
F=R/'scripts/probes/ownership-tail/result-owner-fields-tail.slg';std=sorted((R/'stdlib').rglob('*.slg'));M=R/'tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.sources.txt';sources=[R/x for x in M.read_text(encoding='utf-8-sig').splitlines() if x.strip() and not x.endswith('selfhost-sollangc-driver.slg')]
driver=O/'driver.slg';driver.write_text('import sollang.compiler.llvm.text as observer\nmain {\n    [Text; ~] => paths!\n'+''.join('    paths! -> push('+json.dumps(p.as_posix())+')\n' for p in [F,*std])+f'    paths! -> observer.traceNativeContextBranchIr(0, 0, {F.stat().st_size})\n}}\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();paths=[Path(__file__),C,*managed_runtime_inputs(C),M,helper,driver,F,*std,*sources];pins={str(p.resolve()):sha(p) for p in paths}
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(status='running',completed=0,total=1,cases=[],inputHashes=pins,scope='One source IR observation of C795 narrow fixture; no compiler producer or parity claim',maximumBuilds=1,previousPreparationFailure='ownership25143: obsolete observer PrepareRequest lacked explicit stdlib range; corrected to exact input start1/count144',buildTimeoutSeconds=180,runTimeoutSeconds=20,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  d=ex.run([str(C),'build',str(driver),str(helper),*map(str,sources),'-o',str(O/'observer.exe'),'--target','windows-x64','--llvm',str(R/'.tools/llvm-22.1.8'),'--jobs','24','-O0'],O/'build',timeout=180);assert d.returncode==0 and not d.stderr,(d.stdout[-1000:],d.stderr)
  d=ex.run([str(O/'observer.exe')],O/'run',timeout=20);assert d.returncode==0 and not d.stderr and 'kind=27,' in d.stdout,(d.stdout[-1000:],d.stderr)
  result.update(status='passed',completed=1,cases=[dict(id='exact-current-native-preparation-IR-observed',passed=True)],observedStdout=d.stdout)
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reuse)
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

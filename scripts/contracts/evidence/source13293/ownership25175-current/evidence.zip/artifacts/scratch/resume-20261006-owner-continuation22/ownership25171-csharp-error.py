from pathlib import Path
import sys,json,hashlib
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output,cleanup_output
C=B/'ownership25169-managed/compiler/Sollang.Compiler.exe';O=B/'ownership25171-csharp-error';F=R/'scripts/probes/ownership-tail/result-owner-fields-tail-error.slg';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();paths=[Path(__file__),F,C,*managed_runtime_inputs(C),*sorted((R/'stdlib').rglob('*.slg'))];pins={str(p.resolve()):sha(p) for p in paths};initialize_output(R,O,reusable_directories=[B/'bitset25123-native',B/'ownership25157-native',B/'v20050/compiler-build01']);O.mkdir()
with VerificationContractLease(paths):
 result=dict(status='running',completed=0,total=2,cases=[],inputHashes=pins,claimsGoalComplete=False,scope='Focused CSharp corrected Err arm at O0 and O1; exact failed newline and zero exit required');ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for opt in ['O0','O1']:
   out=O/(opt+'.exe');d=ex.run([str(C),'build',str(F),'-o',str(out),'--target','windows-x64','--llvm',str(R/'.tools/llvm-22.1.8'),'--jobs','4','--keep-temps','-'+opt],O/(opt+'.build'),timeout=60);assert d.returncode==0 and not d.stderr,(d.stdout,d.stderr)
   d=ex.run([str(out)],O/(opt+'.run'),timeout=10);result['cases'].append(dict(id=opt,expectedStdout='failed\n',stdout=d.stdout,stderr=d.stderr,exit=d.returncode,passed=d.returncode==0 and not d.stderr and d.stdout=='failed\n',oraclePassed=d.returncode==0 and not d.stderr and d.stdout=='failed\n'));result['completed']+=1
  assert all(c['oraclePassed'] for c in result['cases']),result['cases']
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=[B/'bitset25123-native',B/'ownership25157-native',B/'v20050/compiler-build01'])
print(json.dumps(result['cases']))

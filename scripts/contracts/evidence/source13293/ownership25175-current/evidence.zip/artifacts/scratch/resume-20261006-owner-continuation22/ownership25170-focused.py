from pathlib import Path
import argparse, hashlib, json, sys
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output, cleanup_output
p=argparse.ArgumentParser();p.add_argument('--compiler',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--baseline',action='store_true');p.add_argument('--tail-only',action='store_true');a=p.parse_args()
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=a.compiler.resolve();O=a.output.resolve()
cases=[('scripts/probes/windows-linker/owned-task-mixed.slg',None)]
if not a.baseline:
 cases += [('scripts/probes/windows-linker/owned-task-branch.slg','finished\n0\n1\n')]
 for n in ['301-owned-array-push-move','708-owned-branch-merge-move']:
  cases.append((f'examples/regression/{n}.slg',(R/f'examples/regression/expected/{n}.stdout.txt').read_text(encoding='utf-8-sig')))
 for n in ['1550-mixed-owned-continuing-branches','1551-partially-terminating-owned-branch']:
  cases.append((f'examples/regression/diagnostics/{n}.slg',None))
 if a.tail_only:cases=[]
 for f in sorted((R/'scripts/probes/ownership-tail').glob('*.slg')):
  expected=f.with_suffix('.stdout.txt');cases.append((str(f),expected.read_text(encoding='utf-8-sig') if expected.exists() else None))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
paths=[Path(__file__),C,*[R/f for f,_ in cases],*sorted((R/'stdlib').rglob('*.slg'))]
paths += list((R/'scripts/probes/ownership-tail').glob('*.txt')) if not a.baseline else []
if C.with_suffix('.dll').exists():paths+=managed_runtime_inputs(C)
pins={str(f.resolve()):sha(f) for f in paths}
initialize_output(R,O,reusable_directories=[B/'bitset25123-native',B/'ownership25157-native',B/'v20050/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(f) for f in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=len(cases),inputHashes=pins,claimsGoalComplete=False,cases=[])
 ex=VerificationExecution(R,O,result,lambda:all(sha(f)==h for f,h in pins.items()),sha);error=None
 try:
  for f,expected in cases:
   f=R/f;out=O/(f.stem+'.exe');r=ex.run([str(C),'build',str(f),'-o',str(out),'--target','windows-x64','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')],O/(f.stem+'.build'),timeout=60)
   row=dict(source=str(f),returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
   if expected is None:
    assert r.returncode==1 and not out.exists(),row
    if str(f).endswith('result-owner-fields-continuation.slg'):assert r.stderr==f.with_suffix('.stderr.txt').read_text(encoding='utf-8-sig').replace('\r\n','\n'),row
    elif not a.baseline:assert 'must be consumed on every control-flow branch or on none of them' in r.stderr,row
   else:
    assert r.returncode==0 and not r.stderr,row
    done=ex.run([str(out)],O/(f.stem+'.run'),timeout=10)
    assert done.returncode==0 and not done.stderr and done.stdout==expected.replace('\r\n','\n'),(done.stdout,done.stderr,expected)
    row['observedStdout']=done.stdout
   row['passed']=True;result['cases'].append(row);result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=[B/'bitset25123-native',B/'ownership25157-native',B/'v20050/compiler-build01'])
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

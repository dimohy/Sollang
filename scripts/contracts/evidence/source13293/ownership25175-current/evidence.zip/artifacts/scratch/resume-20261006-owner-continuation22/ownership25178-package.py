from pathlib import Path
import json,zipfile,hashlib,subprocess,datetime,collections
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/ownership25175-current';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));write=lambda p,d:Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
v=read(B/'ownership25176-validation/result.json');assert v['status']=='passed' and v['completed']==4;write(E/'validation.json',v);write(E/'source-connections.json',v['sourceConnections']);write(E/'artifact-lifecycle.json',read(B/'ownership25177-lifecycle.json'))
protected=read(B/'block24016-protected-inputs.json');assert all(sha(R/p)==h for p,h in protected.items())
counts=collections.Counter(x['state'] for x in read(R/'scripts/contracts/compiler-defects.json')['defects']);assert counts==dict(closed=363,**{'candidate-fixed':428},open=2)
entries={}
def add(p):
 p=Path(p);entries[p.relative_to(R).as_posix()]=p.read_bytes()
sources=['src/Sollang.Compiler/CodeGen/LlvmEmitter.Enums.cs','src/Sollang.Compiler/CodeGen/LlvmEmitter.Expressions.Control.cs','src/Sollang.Compiler/CodeGen/LlvmEmitter.Utilities.cs','selfhost/semantic/ownership_check.slg','selfhost/llvm/text/ownership.slg','docs/SPEC.md','scripts/verification_execution.py','scripts/completed_artifact_plan.py']
for name in sources:
 add(R/name);entries['before-source/'+name]=subprocess.run(['git','show','HEAD:'+name],capture_output=True,check=True).stdout
for p in (R/'scripts/probes/ownership-tail').rglob('*'):
 if p.is_file():add(p)
for item in sorted(B.glob('ownership251*')):
 if item.name.endswith('-goal-before.json') or item.name.endswith('-detail-before.json'):continue
 paths=item.rglob('*') if item.is_dir() else [item]
 for p in paths:
  if not p.is_file() or p.stat().st_size>8_000_000:continue
  if any(x in ['.sollang-cache','compiler','bin','obj','dotnet-artifacts','.w0'] or x.endswith('.slg-tmp') for x in p.parts):continue
  if p.suffix.lower() in ['.exe','.dll','.pdb','.ll','.bc','.obj','.lib','.pyc','.semantic','.zip']:continue
  add(p)
# Preserve the exact unoptimized heap-corruption LLVM baseline, rather than a rewritten record.
add(B/'ownership25150-csharp-error-observe/O0.exe.ll');add(Path(__file__));add(B/'block24016-protected-inputs.json')
archive=E/'evidence.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(entries.items()):z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(entries)
 for name,raw in entries.items():assert z.read(name)==raw
write(E/'archive-manifest.json',dict(sha256=sha(archive),readbackVerified=True,entries={n:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest().upper()) for n,v in sorted(entries.items())}))
q=dict(schemaVersion=1,status='current-windows-focused-qualified-final-gates-pending',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseCommit=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,check=True,text=True).stdout.strip(),scope='Canonical returned match boundary, per-edge live-field cleanup and exact E20 affected-field diagnostics',defectIds=['C2026-11-03-'+str(i) for i in [795,796,797]],focused=dict(completed=16,total=16,percentage=100.0,programPairs=8,exactNegativeDiagnostics=True),related=dict(completed=12,total=12),productionWindowsLinker=dict(completed=8,total=8,managed=4,native=4),managedErrorO0O1=dict(completed=2,total=2),semantic=dict(completed=4,total=4),stdlib=dict(completed=1,total=1,sources=144,activeBodies=2071),closureControls=112,layoutControls=2,associated=dict(completed=459,total=712,percentage=64.47,remaining=253,added=0),compilerStabilization=dict(completed=363,total=793,percentage=45.78,candidateFixed=428,open=2),nativeCompilerProducerBuilds=1,managedCompilerProducerBuilds=2,sourceComparison='source-comparison.json',pairedCases='paired-cases.json',nativeProducerBootstrap='ownership25152-managed; subsequent CSharp change only corrects diagnostic names. No SLG source changed after this Native product, all producer pins match; no producer replay.',historicalIrObservation='irObservation.json observes before fix; exact prior ownership_check bytes are archived as ownership25154-before.slg; it is not current acceptance evidence.',failures=dict(currentFocused=0,remainingOpen=['C2026-09-12-385','C2026-10-27-742'],runtimeBaseline='CSharp O0/O1 heap corruption exit3221226356; ownership25150 retained',nativeBaseline='C795 E20 rejected valid returned match; ownership25142 preserved as baseline observation',diagnosticBaseline='C797 unchanged child incorrectly listed by CSharp; raw current Native diagnostic already correct',toolPreparationFailures=['ownership25143 obsolete stdlib range','ownership25144 missing Process in old observer helper'],diagnosticTimeout='ownership25145 run20 timeout; one exact-binary reuse ownership25146 passed within60; cumulative80, no rebuild',fixturePreparationFailures=['ownership25147 invalid expression statement','ownership25148 invalid outer return syntax'],schemaLimited='ownership25156 lacks per-case passed; protected immutable output, fresh25158 and current25171 regenerate same O0/O1 expectations with valid completion'),lifecycle='artifact-lifecycle.json',protectedInputsVerified=8,original1999Runs=0,wholeProfileRuns=0,fullSourcePhases=dict(completed=0,total=7),overall=dict(completed=None,total=None,percentage=None,unknownReason='Platform and performance denominators are not frozen'),progressReportAutomaticValidation='unverified: pre-existing progress status schema and prior Slogs count contract error; no enforcement claim',platformScope='windows-x64',archive=dict(path='evidence.zip',sha256=sha(archive),entries=len(entries),bytes=archive.stat().st_size,readbackVerified=True),claimsWholePhaseComplete=False,claimsGoalComplete=False)
write(E/'qualification.json',q);print(json.dumps(dict(status=q['status'],archiveEntries=len(entries),archiveBytes=archive.stat().st_size,focused='16/16',related='12/12',closed='363/793',candidateFixed=428)))

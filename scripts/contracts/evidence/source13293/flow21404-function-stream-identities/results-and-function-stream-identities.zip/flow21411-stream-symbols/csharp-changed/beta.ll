@.slg.str.module.x63616368652E62657461.0 = private unnamed_addr constant [4 x i8] c"beta", align 1
@.slg.str.module.x63616368652E62657461.1 = private unnamed_addr constant [1 x i8] c"\0A", align 1
define internal i32 @sollang_fn_cache_beta_apply(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, i32 %it) #0 {
entry:
  %mutable_scalar_slot8 = alloca i32, align 4
  %stream_cancelled9 = alloca i1, align 1
  %mutable_scalar_slot10 = alloca i32, align 4
  %write0 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.module.x63616368652E62657461.0, i64 4, ptr %written)
  %is_ok1 = icmp ne i32 %write0, 0
  %previous_ok2 = load i1, ptr %ok_state, align 1
  %ok3 = and i1 %previous_ok2, %is_ok1
  store i1 %ok3, ptr %ok_state, align 1
  %write4 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.module.x63616368652E62657461.1, i64 1, ptr %written)
  %is_ok5 = icmp ne i32 %write4, 0
  %previous_ok6 = load i1, ptr %ok_state, align 1
  %ok7 = and i1 %previous_ok6, %is_ok5
  store i1 %ok7, ptr %ok_state, align 1
  store i32 %it, ptr %mutable_scalar_slot8, align 4
  store i1 false, ptr %stream_cancelled9, align 1
  store i32 0, ptr %mutable_scalar_slot10, align 4
  %range11 = insertvalue %sollang.struct.43 poison, i32 1, 0
  %range12 = insertvalue %sollang.struct.43 %range11, i32 3, 1
  %range_start13 = extractvalue %sollang.struct.43 %range12, 0
  %range_end14 = extractvalue %sollang.struct.43 %range12, 1
  %each_done16 = icmp sgt i32 %range_start13, %range_end14
  br i1 %each_done16, label %bb_each_end2, label %bb_each_body0
bb_each_body0:
  %item17 = phi i32 [ %range_start13, %entry ], [ %each_next15, %bb_each_continue1 ]
  %mutable_scalar18 = load i32, ptr %mutable_scalar_slot10, align 4
  %cmp19 = icmp slt i32 %mutable_scalar18, 1
  br i1 %cmp19, label %bb_if_then3, label %bb_if_else4
bb_if_then3:
  %mutable_scalar20 = load i32, ptr %mutable_scalar_slot10, align 4
  %add21 = add i32 %mutable_scalar20, 1
  store i32 %add21, ptr %mutable_scalar_slot10, align 4
  %mutable_scalar22 = load i32, ptr %mutable_scalar_slot10, align 4
  %cmp23 = icmp sge i32 %mutable_scalar22, 1
  br i1 %cmp23, label %bb_if_then6, label %bb_if_end7
bb_if_then6:
  store i1 true, ptr %stream_cancelled9, align 1
  br label %bb_if_end7
bb_if_end7:
  %mutable_scalar24 = load i32, ptr %mutable_scalar_slot8, align 4
  %add25 = add i32 %mutable_scalar24, 3
  store i32 %add25, ptr %mutable_scalar_slot8, align 4
  br label %bb_if_end5
bb_if_else4:
  store i1 true, ptr %stream_cancelled9, align 1
  br label %bb_if_end5
bb_if_end5:
  %stream_cancelled26 = load i1, ptr %stream_cancelled9, align 1
  br i1 %stream_cancelled26, label %bb_stream_cancel8, label %bb_stream_continue9
bb_stream_cancel8:
  br label %bb_each_end2
bb_stream_continue9:
  br label %bb_each_continue1
bb_each_continue1:
  %each_next15 = add i32 %item17, 1
  %each_done27 = icmp sge i32 %item17, %range_end14
  br i1 %each_done27, label %bb_each_end2, label %bb_each_body0
bb_each_end2:
  %mutable_scalar28 = load i32, ptr %mutable_scalar_slot8, align 4
  ret i32 %mutable_scalar28
}


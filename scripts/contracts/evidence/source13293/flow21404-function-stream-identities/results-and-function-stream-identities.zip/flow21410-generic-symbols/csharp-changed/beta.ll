@.slg.str.module.x63616368652E62657461.0 = private unnamed_addr constant [4 x i8] c"beta", align 1
@.slg.str.module.x63616368652E62657461.1 = private unnamed_addr constant [1 x i8] c"\0A", align 1
define internal i32 @sollang_fn_cache_beta_apply(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, i32 %it) #0 {
entry:
  %write0 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.module.x63616368652E62657461.0, i64 4, ptr %written)
  %is_ok1 = icmp ne i32 %write0, 0
  %previous_ok2 = load i1, ptr %ok_state, align 1
  %ok3 = and i1 %previous_ok2, %is_ok1
  store i1 %ok3, ptr %ok_state, align 1
  %write4 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.module.x63616368652E62657461.1, i64 1, ptr %written)
  %is_ok5 = icmp ne i32 %write4, 0
  %previous_ok6 = load i1, ptr %ok_state, align 1
  %ok7 = and i1 %previous_ok6, %is_ok5
  store i1 %ok7, ptr %ok_state, align 1
  %numeric_call8 = call i32 @sollang_fn_$63616368652E626574612E6964656E746974792432(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, i32 %it)
  %add9 = add i32 %numeric_call8, 3
  ret i32 %add9
}

define internal i32 @sollang_fn_$63616368652E626574612E6964656E746974792432(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, i32 %it) #0 {
entry:
  ret i32 %it
}


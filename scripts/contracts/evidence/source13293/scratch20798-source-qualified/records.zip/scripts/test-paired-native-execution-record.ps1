[CmdletBinding()]
param([Parameter(Mandatory)][string]$OutputDirectory, [string]$PreviousWrapper = '', [string]$PreviousBudgetWrapper = '')

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$output = [IO.Path]::GetFullPath($OutputDirectory, $root)
if (-not $output.StartsWith((Join-Path $root 'artifacts') + [IO.Path]::DirectorySeparatorChar,
        [StringComparison]::OrdinalIgnoreCase) -or (Test-Path -LiteralPath $output)) {
    throw 'PAIRED_EXECUTION_CONTROL_FRESH_OUTPUT_REQUIRED'
}
$wrapper = Join-Path $PSScriptRoot 'verify-compiler-paired-native-fixtures.ps1'
$helper = Join-Path $PSScriptRoot 'verification-process.ps1'
$paths = @($PSCommandPath, $wrapper, $helper,
    (Join-Path $PSScriptRoot 'native-exact-fixture-receipt.ps1'),
    (Join-Path $PSScriptRoot 'stage2-artifact-receipt.ps1'))
if ($PreviousWrapper) { $paths += (Resolve-Path -LiteralPath $PreviousWrapper).Path }
if ($PreviousBudgetWrapper) { $paths += (Resolve-Path -LiteralPath $PreviousBudgetWrapper).Path }
$before = [ordered]@{}
foreach ($path in $paths) { $before[$path] = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash }
$tokens = $null
$errors = $null
$ast = [Management.Automation.Language.Parser]::ParseFile($wrapper, [ref]$tokens, [ref]$errors)
if ($errors.Count -ne 0) { throw 'PAIRED_EXECUTION_WRAPPER_PARSE_FAILED' }
$functions = @($ast.FindAll({ param($node)
    $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq 'Invoke-CaseProcess'
}, $true))
if ($functions.Count -ne 1) { throw 'PAIRED_EXECUTION_WRAPPER_FUNCTION_NOT_UNIQUE' }
. $helper
. (Join-Path $PSScriptRoot 'native-exact-fixture-receipt.ps1')
. ([ScriptBlock]::Create($functions[0].Extent.Text))
$script:pairedCaseClock = $null
[IO.Directory]::CreateDirectory($output) | Out-Null
$shellPath = (Get-Process -Id $PID).Path
$rows = [Collections.Generic.List[object]]::new()
$failure = $null
$expectedControls = 26 + [int]([bool]$PreviousWrapper) + [int]([bool]$PreviousBudgetWrapper)
try {
    foreach ($functionName in @('Get-PairedSharedLlvmInputs', 'Assert-PairedSharedLlvm')) {
        $sharedFunction = @($ast.FindAll({ param($node)
            $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq $functionName
        }, $true))
        if ($sharedFunction.Count -ne 1) { throw 'PAIRED_SHARED_FUNCTION_NOT_UNIQUE' }
        . ([ScriptBlock]::Create($sharedFunction[0].Extent.Text))
    }
    $sharedRoot = Join-Path $output 'shared-contract'
    [IO.Directory]::CreateDirectory($sharedRoot) | Out-Null
    if (@(Get-PairedSharedLlvmInputs $sharedRoot profile).Count -ne 0) { throw 'SHARED_OPT_IN_CHANGED' }
    $rows.Add(@{ id='shared-absent-keeps-legacy-scope'; passed=$true })
    $sharedCounts = Join-Path $sharedRoot 'profile.common.llvm.regex-counts.txt'
    $managedCounts = Join-Path $sharedRoot 'profile.llvm.regex-counts.txt'
    $nativeCounts = Join-Path $sharedRoot 'profile.selfhost.llvm.regex-counts.txt'
    $managedLlvm = Join-Path $sharedRoot 'managed.ll'
    $nativeLlvm = Join-Path $sharedRoot 'native.ll'
    [IO.File]::WriteAllText($sharedCounts, "1`tshared-marker`n")
    [IO.File]::WriteAllText($managedCounts, "1`tmanaged-marker`n")
    [IO.File]::WriteAllText($nativeCounts, "1`tnative-marker`n")
    [IO.File]::WriteAllText($managedLlvm, '; managed-marker shared-marker')
    [IO.File]::WriteAllText($nativeLlvm, '; native-marker shared-marker')
    if (@(Get-PairedSharedLlvmInputs $sharedRoot profile).Count -ne 3) { throw 'SHARED_INPUTS_INCOMPLETE' }
    $rows.Add(@{ id='shared-and-both-producer-inputs-pinned'; passed=$true })
    Assert-PairedSharedLlvm $managedLlvm $sharedRoot profile $true
    $rows.Add(@{ id='managed-uses-shared-contract'; passed=$true })
    Assert-PairedSharedLlvm $nativeLlvm $sharedRoot profile $false
    $rows.Add(@{ id='native-uses-identical-shared-contract'; passed=$true })
    [IO.File]::WriteAllText($nativeLlvm, '; native-marker')
    $rejected = $false
    try { Assert-PairedSharedLlvm $nativeLlvm $sharedRoot profile $false }
    catch { $rejected = $_.Exception.Message.StartsWith('EXACT_LLVM_REGEX_COUNT') }
    if (-not $rejected) { throw 'SHARED_LEGACY_OVERRIDE_BYPASS' }
    $rows.Add(@{ id='legacy-producer-check-cannot-bypass-shared'; passed=$true })
    foreach ($invalid in @(
        @{id='shared-empty-rejected-before-build';text='';error='PAIRED_SHARED_LLVM_EMPTY'},
        @{id='shared-invalid-pattern-rejected-before-build';text="1`t[`n";error='PAIRED_SHARED_LLVM_REGEX_INVALID'},
        @{id='shared-negative-count-rejected-before-build';text="-1`tshared-marker`n";error='PAIRED_SHARED_LLVM_COUNT_INVALID'}
    )) {
        [IO.File]::WriteAllText($sharedCounts, $invalid.text)
        $rejection = $null
        try { $null = @(Get-PairedSharedLlvmInputs $sharedRoot profile) }
        catch { $rejection = $_.Exception.Message }
        if ($rejection -cne $invalid.error) { throw "SHARED_INVALID_INPUT_NOT_REJECTED: $($invalid.id)" }
        $rows.Add(@{ id=$invalid.id; passed=$true })
    }
    $selectionFunctions = @($ast.FindAll({ param($node)
        $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq 'Get-PairedFixtureCompilers'
    }, $true))
    if ($selectionFunctions.Count -ne 1) { throw 'PAIRED_SELECTION_FUNCTION_NOT_UNIQUE' }
    . ([ScriptBlock]::Create($selectionFunctions[0].Extent.Text))
    foreach ($selection in @(
        @{ id = 'both-keep-managed-first'; sides = @('selfhost', 'managed'); expected = 'managed,selfhost' },
        @{ id = 'native-only-does-not-select-managed'; sides = @('selfhost'); expected = 'selfhost' },
        @{ id = 'managed-only-does-not-select-native'; sides = @('managed'); expected = 'managed' }
    )) {
        $selected = @(Get-PairedFixtureCompilers 'managed-artifact' 'native-artifact' $selection.sides)
        if (($selected.Name -join ',') -cne $selection.expected -or
            @($selected | Where-Object { $_.Path -cne $(if ($_.Name -ceq 'managed') { 'managed-artifact' } else { 'native-artifact' }) }).Count -ne 0) {
            throw "PAIRED_COMPILER_SELECTION_MISMATCH: $($selection.id)"
        }
        $rows.Add([ordered]@{ id = $selection.id; passed = $true })
    }
    foreach ($selection in @(
        @{ id = 'empty-selection-rejected'; sides = @() },
        @{ id = 'duplicate-selection-rejected'; sides = @('selfhost', 'selfhost') },
        @{ id = 'unknown-selection-rejected'; sides = @('alternate') }
    )) {
        $rejection = $null
        try { $null = Get-PairedFixtureCompilers 'managed-artifact' 'native-artifact' $selection.sides }
        catch { $rejection = $_.Exception.Message }
        if ($rejection -cne 'PAIRED_COMPILER_SELECTION_INVALID') { throw "PAIRED_SELECTION_NOT_REJECTED: $($selection.id)" }
        $rows.Add([ordered]@{ id = $selection.id; passed = $true })
    }
    $overbudgetOutput = Join-Path $output 'overbudget-must-not-start'
    $overbudgetRejected = $false
    try {
        & $wrapper -ManagedCompiler 'missing-managed' -SelfhostCompiler 'missing-native' `
            -Fixture @('unused') -OutputDirectory $overbudgetOutput -TimeoutMilliseconds 180001
    } catch [System.Management.Automation.ParameterBindingException] {
        $overbudgetRejected = $_.FullyQualifiedErrorId -like 'ParameterArgumentValidationError*'
    }
    if (-not $overbudgetRejected -or (Test-Path -LiteralPath $overbudgetOutput)) {
        throw 'PAIRED_CASE_BUDGET_PERMISSION_EXPANSION_NOT_REJECTED'
    }
    $rows.Add([ordered]@{ id = 'case-budget-above180-seconds-rejected-before-launch'; passed = $true })
    $checkCaseBudget = {
        param($functionText, $controlPrefix)
        . ([ScriptBlock]::Create($functionText))
        $TimeoutMilliseconds = 1000
        $timeouts = [Collections.Generic.List[int]]::new()
        function Invoke-VerificationProcessCapture {
            param($FilePath, $ArgumentList, $WorkingDirectory, $Description, $TimeoutMilliseconds, $ExecutionRecordPath)
            $timeouts.Add($TimeoutMilliseconds)
            [pscustomobject]@{ Stdout = ''; Stderr = ''; ExitCode = 0 }
        }
        $script:pairedCaseClock = [pscustomobject]@{ ElapsedMilliseconds = 600L }
        try {
            $null = Invoke-CaseProcess 'unused' @() 'build' "$controlPrefix-build"
            $script:pairedCaseClock.ElapsedMilliseconds = 850L
            $null = Invoke-CaseProcess 'unused' @() 'assemble' "$controlPrefix-assemble"
            if ($timeouts.Count -ne 2 -or $timeouts[0] -ne 400 -or $timeouts[1] -ne 150) {
                throw 'PAIRED_CASE_BUDGET_RESET_BETWEEN_STAGES'
            }
            $script:pairedCaseClock.ElapsedMilliseconds = 1000L
            $budgetFailure = $null
            try { $null = Invoke-CaseProcess 'unused' @() 'run' "$controlPrefix-run" }
            catch { $budgetFailure = $_.Exception.Message }
            if ($budgetFailure -notlike 'PAIRED_CASE_BUDGET_EXHAUSTED:*' -or $timeouts.Count -ne 2) {
                throw 'PAIRED_CASE_BUDGET_EXHAUSTION_DID_NOT_BLOCK_LAUNCH'
            }
        } finally { $script:pairedCaseClock = $null }
    }
    & $checkCaseBudget $functions[0].Extent.Text (Join-Path $output 'budget-current')
    $rows.Add([ordered]@{ id = 'case-budget-shared-across-build-and-assemble'; passed = $true })
    $rows.Add([ordered]@{ id = 'case-budget-exhaustion-blocks-next-launch'; passed = $true })
    if ($PreviousBudgetWrapper) {
        $oldTokens = $null; $oldErrors = $null
        $oldAst = [Management.Automation.Language.Parser]::ParseFile(
            (Resolve-Path -LiteralPath $PreviousBudgetWrapper).Path, [ref]$oldTokens, [ref]$oldErrors)
        if ($oldErrors.Count -ne 0) { throw 'PAIRED_PREVIOUS_BUDGET_WRAPPER_PARSE_FAILED' }
        $oldFunctions = @($oldAst.FindAll({ param($node)
            $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -ceq 'Invoke-CaseProcess'
        }, $true))
        if ($oldFunctions.Count -ne 1) { throw 'PAIRED_PREVIOUS_BUDGET_FUNCTION_NOT_UNIQUE' }
        $oldFailure = $null
        try { & $checkCaseBudget $oldFunctions[0].Extent.Text (Join-Path $output 'budget-previous') }
        catch { $oldFailure = $_.Exception.Message }
        if ($oldFailure -cne 'PAIRED_CASE_BUDGET_RESET_BETWEEN_STAGES') {
            throw 'PAIRED_PREVIOUS_CASE_BUDGET_FAILURE_NOT_REPRODUCED'
        }
        $rows.Add([ordered]@{ id = 'previous-per-command-budget-reset-rejected'; passed = $true })
    }
    $finalizationSource = {
        param($wrapperAst)
        $mainTry = @($wrapperAst.EndBlock.Statements | Where-Object {
            $_ -is [Management.Automation.Language.TryStatementAst]
        })[-1]
        (@($wrapperAst.EndBlock.Statements | Where-Object {
            $_.Extent.StartOffset -ge $mainTry.Extent.EndOffset
        }) | ForEach-Object { $_.Extent.Text }) -join "`n"
    }
    $checkOwnership = {
        param($tail, $controlRoot, $activeSeed)
        $output = Join-Path $controlRoot 'owned'
        $seedOutput = Join-Path $controlRoot 'shared-seed'
        [IO.Directory]::CreateDirectory($output) | Out-Null
        [IO.Directory]::CreateDirectory($seedOutput) | Out-Null
        $seedFile = Join-Path $seedOutput 'product.bin'
        [IO.File]::WriteAllText($seedFile, 'pending-consumer-product')
        $seedHash = (Get-FileHash -LiteralPath $seedFile -Algorithm SHA256).Hash
        $requests = [Collections.Generic.List[string]]::new()
        $failure = $null
        $ownsSeed = $true
        $usesPrivateSeed = $true
        $ReusableCompilerDirectories = @($seedOutput)
        $cases = @('fixture')
        $CompilerSide = @('managed', 'selfhost')
        function Write-Host { }
        function Complete-VerifiedArtifactOutput {
            param([string]$OutputDirectory, [switch]$KeepCompiler, [string[]]$ReusableCompilerDirectories)
            if ($OutputDirectory -cne $output) { throw 'PAIRED_UNOWNED_COMPILER_CLEANUP' }
            $requests.Add($OutputDirectory)
        }
        $reader = if ($activeSeed) {
            [IO.File]::Open($seedFile, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
        } else { $null }
        try { & ([ScriptBlock]::Create($tail)) }
        finally { if ($null -ne $reader) { $reader.Dispose() } }
        if ($requests.Count -ne 1 -or
            (Get-FileHash -LiteralPath $seedFile -Algorithm SHA256).Hash -cne $seedHash) {
            throw 'PAIRED_ARTIFACT_OWNERSHIP_VIOLATION'
        }
    }
    $tail = & $finalizationSource $ast
    foreach ($activeSeed in @($false, $true)) {
        & $checkOwnership $tail (Join-Path $output "ownership-$activeSeed") $activeSeed
    }
    $rows.Add([ordered]@{ id = 'consumer-cleans-owned-output-only'; passed = $true; controls = 2 })
    if ($PreviousWrapper) {
        $previousTokens = $null
        $previousErrors = $null
        $previousAst = [Management.Automation.Language.Parser]::ParseFile(
            (Resolve-Path -LiteralPath $PreviousWrapper).Path, [ref]$previousTokens, [ref]$previousErrors)
        if ($previousErrors.Count -ne 0) { throw 'PAIRED_PREVIOUS_WRAPPER_PARSE_FAILED' }
        $previousFailure = $null
        try {
            & $checkOwnership (& $finalizationSource $previousAst) (Join-Path $output 'previous-ownership') $true
        } catch { $previousFailure = $_.Exception.Message }
        if ($previousFailure -cne 'PAIRED_UNOWNED_COMPILER_CLEANUP') {
            throw 'PAIRED_PREVIOUS_OWNERSHIP_FAILURE_NOT_REPRODUCED'
        }
        $rows.Add([ordered]@{ id = 'previous-shared-seed-cleanup-rejected'; passed = $true })
    }
    $countExpressions = [regex]::Matches([IO.File]::ReadAllText($wrapper), '(?m)^\s*completed = (.+)\r?$')
    if ($countExpressions.Count -ne 1) { throw 'PAIRED_COMPLETION_EXPRESSION_NOT_UNIQUE' }
    $countCompleted = [ScriptBlock]::Create('param($rows, $CompilerSide) ' + $countExpressions[0].Groups[1].Value)
    foreach ($countCase in @(
        @{ runs = 0; expected = 0 }, @{ runs = 1; expected = 0 },
        @{ runs = 2; expected = 1 }, @{ runs = 3; expected = 1 },
        @{ runs = 15; expected = 7 }, @{ runs = 16; expected = 8 }
    )) {
        $actual = & $countCompleted ([pscustomobject]@{ Count = $countCase.runs }) @('managed', 'selfhost')
        if ($actual -ne $countCase.expected) { throw "PAIRED_INCOMPLETE_PAIR_COUNTED: $($countCase.runs)" }
        $single = & $countCompleted ([pscustomobject]@{ Count = $countCase.runs }) @('selfhost')
        if ($single -ne $countCase.runs) { throw "PAIRED_SINGLE_SIDE_COUNT_MISMATCH: $($countCase.runs)" }
    }
    $rows.Add([ordered]@{ id = 'completed-pairs'; passed = $true; controls = 6; previousFailure = 'Three successful runs are one completed pair, not two.' })
    Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Threading;
public static class VerificationRecordReaderControl {
    public static void ReleaseAfter(FileStream stream, int milliseconds) {
        var thread = new Thread(() => { Thread.Sleep(milliseconds); stream.Dispose(); });
        thread.IsBackground = true;
        thread.Start();
    }
}
'@
    $publicationPath = Join-Path $output 'publication.execution.json'
    Write-VerificationExecutionRecord $publicationPath ([ordered]@{ status = 'running' })
    Write-VerificationExecutionRecord $publicationPath ([ordered]@{ status = 'passed'; value = 1 })
    if ((Get-Content -LiteralPath $publicationPath -Raw | ConvertFrom-Json).value -ne 1) { throw 'PUBLICATION_NORMAL_FAILED' }
    $rows.Add([ordered]@{ id = 'publication-normal'; passed = $true })
    $reader = [IO.File]::Open($publicationPath, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
    [VerificationRecordReaderControl]::ReleaseAfter($reader, 80)
    Write-VerificationExecutionRecord $publicationPath ([ordered]@{ status = 'passed'; value = 2 })
    if ((Get-Content -LiteralPath $publicationPath -Raw | ConvertFrom-Json).value -ne 2 -or
        @(Get-ChildItem -LiteralPath $output -Filter 'publication.execution.json.tmp-*.publication.json').Count -ne 1) {
        throw 'PUBLICATION_TRANSIENT_READER_NOT_RECOVERED'
    }
    $rows.Add([ordered]@{ id = 'publication-transient-reader'; passed = $true; childRerun = $false })
    $reader = [IO.File]::Open($publicationPath, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
    $publishFailure = $null
    $watch = [Diagnostics.Stopwatch]::StartNew()
    try { Write-VerificationExecutionRecord $publicationPath ([ordered]@{ status = 'passed'; value = 3 }) }
    catch { $publishFailure = $_.Exception.Message }
    finally { $reader.Dispose(); $watch.Stop() }
    $pending = @(Get-ChildItem -LiteralPath $output -Filter 'publication.execution.json.tmp-*' |
        Where-Object Name -NotLike '*.publication.json')
    if ($publishFailure -notlike 'VERIFICATION_RECORD_PUBLISH_FAILED:*' -or $watch.ElapsedMilliseconds -gt 3000 -or
        $pending.Count -ne 1 -or (Get-Content -LiteralPath $pending[0].FullName -Raw | ConvertFrom-Json).value -ne 3 -or
        (Get-Content -LiteralPath $publicationPath -Raw | ConvertFrom-Json).value -ne 2) {
        throw 'PUBLICATION_PERMANENT_READER_NOT_BOUNDED_OR_DURABLE'
    }
    $rows.Add([ordered]@{ id = 'publication-persistent-reader'; passed = $true; pendingSnapshot = $pending[0].FullName })
    [IO.File]::SetAttributes($publicationPath, [IO.FileAttributes]::ReadOnly)
    $publishFailure = $null
    try { Write-VerificationExecutionRecord $publicationPath ([ordered]@{ status = 'passed'; value = 4 }) }
    catch { $publishFailure = $_.Exception.Message }
    finally { [IO.File]::SetAttributes($publicationPath, [IO.FileAttributes]::Normal) }
    if ($publishFailure -notlike 'VERIFICATION_RECORD_PUBLISH_FAILED:*attempts=1*' -or
        (Get-Content -LiteralPath $publicationPath -Raw | ConvertFrom-Json).value -ne 2) { throw 'PUBLICATION_READONLY_BYPASSED' }
    $rows.Add([ordered]@{ id = 'publication-readonly'; passed = $true })
    foreach ($case in @(
        @{ id = 'normal'; exit = 0; timeout = 5000; script = "[Console]::Out.Write('normal-out'); [Console]::Error.Write('normal-err'); exit 0" },
        @{ id = 'nonzero'; exit = 7; timeout = 5000; script = "[Console]::Out.Write('failure-out'); [Console]::Error.Write('failure-err'); exit 7" },
        @{ id = 'timeout'; exit = $null; timeout = 1500; script = "[Console]::Out.Write('timeout-out'); [Console]::Error.Write('timeout-err'); Start-Sleep -Seconds 30" }
    )) {
        $TimeoutMilliseconds = $case.timeout
        $prefix = Join-Path $output $case.id
        $thrown = $null
        $run = $null
        try { $run = Invoke-CaseProcess $shellPath @('-NoProfile', '-Command', $case.script) $case.id $prefix }
        catch { $thrown = $_.Exception.Message }
        $recordPath = "$prefix.execution.json"
        $record = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json
        $stdout = [IO.File]::ReadAllText($record.stdoutPath)
        $stderr = [IO.File]::ReadAllText($record.stderrPath)
        if (-not $record.processesStopped -or $record.pid -le 0 -or -not $record.finishedAtUtc -or
            $stdout -cne "$($case.id -replace 'nonzero','failure')-out" -or
            $stderr -cne "$($case.id -replace 'nonzero','failure')-err") {
            throw "PAIRED_EXECUTION_CONTROL_LOG_OR_TERMINAL_MISMATCH: $($case.id)"
        }
        if ($case.id -ceq 'timeout') {
            if (-not $thrown -or $record.status -cne 'failed' -or
                $record.failure -notlike '*configured verification limit*1500 ms*' -or
                $thrown -notlike '*timeout-out*' -or $thrown -notlike '*timeout-err*') {
                throw 'PAIRED_EXECUTION_TIMEOUT_OUTPUT_NOT_DURABLE'
            }
        } elseif ($thrown -or $run.ExitCode -ne $case.exit -or $record.exit -ne $case.exit -or
            $record.status -cne $(if ($case.exit -eq 0) { 'passed' } else { 'failed' }) -or
            [IO.File]::ReadAllText("$prefix.stdout.txt") -cne $stdout -or
            [IO.File]::ReadAllText("$prefix.stderr.txt") -cne $stderr) {
            throw "PAIRED_EXECUTION_CONTROL_EXIT_MISMATCH: $($case.id)"
        }
        $rows.Add([ordered]@{ id = $case.id; passed = $true; executionResult = $recordPath; timeoutMilliseconds = $case.timeout })
    }
} catch { $failure = $_.Exception.Message }
finally {
    $after = [ordered]@{}
    foreach ($path in $paths) { $after[$path] = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash }
    $stable = @($paths | Where-Object { $before[$_] -cne $after[$_] }).Count -eq 0
    $result = [ordered]@{ schemaVersion = 1; status = if (-not $failure -and $stable -and $rows.Count -eq $expectedControls) { 'passed' } else { 'failed' }
        completed = $rows.Count; total = $expectedControls; inputsStable = $stable; inputHashesStart = $before; inputHashesEnd = $after
        cases = @($rows.ToArray()); failure = $failure
        limitations = @('stdout/stderr logs are persisted after child termination, not streamed live.',
            'CPU telemetry remains console output; this test does not prove durable CPU diagnostics.',
            'Only the extracted production wrapper and tiny PowerShell children run; no compiler acceptance is rerun.',
            'Changed wrapper/helper pins invalidate current-source reuse of earlier native fixture records.')
    }
    $result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $output 'result.json') -Encoding utf8
}
if ($result.status -cne 'passed') { throw "PAIRED_EXECUTION_CONTROLS_FAILED: $failure" }
Write-Host "Paired wrapper execution records PASS $($result.completed)/$($result.total); result=$(Join-Path $output 'result.json')"

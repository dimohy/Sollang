from pathlib import Path
import json, hashlib, sys
r=Path.cwd();sys.path.insert(0,str(r/'scripts'))
from verification_execution import VerificationExecution
from completed_artifact_plan import initialize_output
b=r/'artifacts/scratch/resume-20261006-owner-continuation22';out=b/'llvmshared20789-controls2'
checker=b/'llvmshared20787-checker/CommonLlvm.dll'
items=[('managed',b/'scratch20776-managed1/environment-loop-owners/probe.exe.ll',0,'passed'),('previous-slg',b/'scratch20779-source1/environment-loop-owners/emitted.ll',1,'failed')]
paths=[Path(__file__).resolve(),*checker.parent.glob('CommonLlvm.*'),r/'examples/regression/expected/environment-loop-fixed-scratch.common.llvm.regex-counts.txt',*[p for _,p,_,_ in items],*[r/'tests/Sollang.ExampleTests'/n for n in ['LlvmAssertions.cs','CommonLlvmVerification.cs','AtomicResultFile.cs']]]
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
pins={str(p):H(p) for p in paths if p.is_file()};stable=lambda:all(Path(p).is_file() and H(p)==h for p,h in pins.items())
initialize_output(r,out,reusable_directories=[b/f'v{n}/compiler-build01' for n in [18915,20050,20656]]);out.mkdir()
record=dict(schemaVersion=1,status='running',completed=0,total=2,inputHashes=pins,cases=[],claimsGoalComplete=False)
x=VerificationExecution(r,out,record,stable,H);error=None
try:
    for name,llvm,exit,status in items:
        destination=out/(name+'-observation.json')
        done=x.run(['dotnet',str(checker),str(r),str(llvm),'environment-loop-fixed-scratch','windows-x64',str(destination)],out/name,timeout=180)
        result=json.loads(destination.read_text(encoding='utf-8-sig'))
        assert done.returncode==exit and result['status']==status and result['inputsStable'],name
        assert str(r/'examples/regression/expected/environment-loop-fixed-scratch.common.llvm.regex-counts.txt') in result['inputHashes']
        record['cases'].append(dict(id=name,expectedExit=exit,actualExit=done.returncode,observationStatus=result['status'],passed=True));record['completed']+=1;x.save()
    record['status']='passed'
except BaseException as caught:error=caught
finally:x.finalize(error,cleanup=False)
print(json.dumps({k:record.get(k) for k in ['status','completed','total','failure','inputsStable','processesStopped']}))
sys.exit(0 if record['status']=='passed' else 1)

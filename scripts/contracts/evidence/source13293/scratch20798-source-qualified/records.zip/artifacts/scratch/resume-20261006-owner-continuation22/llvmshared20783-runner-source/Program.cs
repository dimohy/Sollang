using System.Text.Json;
if (args[0] != "--selectors") return CommonLlvmVerification.Run(args[0], args[1], args[2], args[3], args[4]);
var repo=args[1]; var good=args[2]; var bad=args[3]; var result=args[4];
var folder=Path.Combine(Path.GetDirectoryName(result)!, "profiles"); Directory.CreateDirectory(folder);
var shared=Path.Combine(folder,"probe.common.llvm.regex-counts.txt");
File.Copy(Path.Combine(repo,"examples/regression/expected/environment-loop-fixed-scratch.common.llvm.regex-counts.txt"),shared);
var cases=new List<object>();
void Check(string id, string input, bool managed, bool expected) {
    var paths=LlvmAssertions.SelectPaths(folder,"probe","windows-x64",managed);
    var actual=LlvmAssertions.Verify(input,paths.Contains,paths.NotContains,paths.RegexCounts,out var error);
    if(actual!=expected) throw new InvalidOperationException(id+": "+error);
    cases.Add(new {id,passed=true});
}
Check("managed-selector-good",good,true,true); Check("slg-selector-good",good,false,true);
Check("managed-selector-rejects-old-slg",bad,true,false); Check("slg-selector-rejects-old-slg",bad,false,false);
File.WriteAllText(Path.Combine(folder,"probe.slg.llvm.regex-counts.txt"),"1\ttarget triple\n");
Check("producer-profile-cannot-bypass-shared",bad,false,false);
File.WriteAllText(shared,"");
Check("empty-shared-managed-rejected",good,true,false); Check("empty-shared-slg-rejected",good,false,false);
File.Delete(shared); Check("no-shared-preserves-legacy",bad,false,true);
AtomicResultFile.Write(result,JsonSerializer.Serialize(new {status="passed",completed=cases.Count,total=8,cases,scope="assertion selector controls, not compiler executions"}));
Console.WriteLine("SHARED_SELECTOR_CONTROLS8"); return 0;

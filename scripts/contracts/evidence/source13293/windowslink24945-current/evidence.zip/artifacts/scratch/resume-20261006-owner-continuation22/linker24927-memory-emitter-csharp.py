from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'linker24927-memory-emitter-csharp';C=B/'linker24924-managed/compiler/Sollang.Compiler.exe';P=R/'scripts/probes/windows-linker';manifest=P/'memory-runtime.sources.txt';sources=[R/p for p in manifest.read_text().splitlines() if p];contract=P/'job-limits.json';cases=json.loads(contract.read_text())['cases'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();L=R/'.tools/llvm-22.1.8'
pins={str(p.resolve()):sha(p) for p in [Path(__file__),manifest,*sources,contract,C,*managed_runtime_inputs(C),*sorted((R/'stdlib').rglob('*.slg'))]}
initialize_output(R,O,reusable_directories=[B/'nativeabi24815-native',B/'v20050/compiler-build01',B/'linker24892-native']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=len(cases),cases=[],inputHashes=pins,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  exe=O/'probe.exe';r=ex.run([str(C),'build',*map(str,sources),'-o',str(exe),'--target','windows-x64','--keep-temps','-O1','--jobs','4','--llvm',str(L)],O/'build',timeout=180);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  r=ex.run([str(exe)],O/'emit',timeout=30);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  assert 'define dso_local ptr @memset(' in r.stdout and 'define dso_local ptr @memcpy(' in r.stdout and 'define dso_local ptr @memmove(' in r.stdout
  result['completed']=result['total']=1;result['runtimeTextSha256']=sha(O/'emit.stdout')
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))




from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'linker24929-memory-components';emitted=B/'linker24928-memory-emitter-native/emit.stdout';managed=B/'linker24927-memory-emitter-csharp/emit.stdout';bootstrap=B/'linker24920-slg-native/probe.exe';controller=R/'scripts/probes/windows-linker/memory-runtime-controller.py';L=R/'.tools/llvm-22.1.8';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();assert emitted.read_bytes()==managed.read_bytes()
initialize_output(R,O,reusable_directories=[B/'linker24916-native',B/'v20050/compiler-build01',B/'linker24892-native']);O.mkdir();module=O/'memory.ll';text='target triple = "x86_64-pc-windows-msvc"\n'+emitted.read_text(encoding='utf-8-sig')+'\n'
for name,parameters,args in [('set','ptr %destination, i32 %value, i64 %count','ptr %destination, i32 %value, i64 %count'),('copy','ptr %destination, ptr %source, i64 %count','ptr %destination, ptr %source, i64 %count'),('move','ptr %destination, ptr %source, i64 %count','ptr %destination, ptr %source, i64 %count')]:
 target={'set':'memset','copy':'memcpy','move':'memmove'}[name];text+=f'define dllexport ptr @exercise_{name}({parameters}) {{\nentry:\n  %result = call ptr @{target}({args})\n  ret ptr %result\n}}\n'
text+='attributes #0 = { nounwind }\n';module.write_text(text,encoding='utf-8');pins={str(p.resolve()):sha(p) for p in [Path(__file__),emitted,managed,bootstrap,controller,module,R/'src/Sollang.Compiler/Shared/Policies/NativeRuntimePolicy.cs']}
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=3,cases=[],inputHashes=pins,emitterBytesEqual=True,scope='Actual exact shared memory definitions linked without default CRT; bounded isolated DLL calls, three unchanged optimization modes.',claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for optimization in ['-O0','-O1','-O2']:
   folder=O/optimization[1:];folder.mkdir();work=folder/'work';work.mkdir();product=folder/'memory.dll';r=ex.run([str(bootstrap),str(L),str(module),str(product),str(work),optimization,'4','true','inherit'],folder/'link',timeout=60);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
   r=ex.run([sys.executable,str(controller),str(product)],folder/'run',timeout=10);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr;detail=json.loads(r.stdout);assert detail['passed'] and detail['completed']==detail['total']==29
   result['cases'].append(dict(id=optimization,passed=True,memoryOracles=detail));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

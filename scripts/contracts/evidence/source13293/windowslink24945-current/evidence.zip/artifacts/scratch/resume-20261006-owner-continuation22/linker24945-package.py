from pathlib import Path
import json,hashlib,zipfile,subprocess,copy,datetime,collections
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/windowslink24945-current';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));write=lambda p,j:Path(p).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();digest=lambda b:hashlib.sha256(b).hexdigest().upper();rel=lambda p:Path(p).relative_to(R).as_posix();now=datetime.datetime.now(datetime.timezone.utc).isoformat()
records={'csharpLinker':'linker24940-csharp','nativeLinker':'linker24939-slg-native','cli':'linker24937-cli','processCsharp':'linker24925-process-csharp','processNative':'linker24936-process-native','inputCsharp':'linker24941-readint-csharp','inputNative':'linker24938-readint-native','jobsCsharp':'linker24923-jobs-csharp','jobsNative':'linker24922-jobs-native','policyControls':'linker24932-policy-controls','memoryCsharp':'linker24927-memory-emitter-csharp','memoryNative':'linker24928-memory-emitter-native','memoryComponents':'linker24929-memory-components','processComponents':'linker24933-process-component','semantic':'linker24930-semantic','stdlib':'linker24931-stdlib','producer':'linker24935-native','ownerCsharp':'linker24847-owned-current','ownerNative':'linker24850-owned-native','ownerCsharpControls':'linker24848-owned-controls','ownerNativeControls':'linker24851-owned-native-controls'}
observations={}
for key,name in records.items():
 j=read(B/name/'result.json');assert j['status']=='passed' and j['inputsStable'] and j['processesStopped'],name;observations[key]=j
assert observations['cli']['completed']==observations['cli']['total']==6
assert observations['nativeLinker']['completed']==observations['csharpLinker']['completed']==8
assert observations['policyControls']['policyChecks']['completed']==observations['policyControls']['policyChecks']['total']==57
assert observations['inputNative']['inputCases']['completed']==observations['inputCsharp']['inputCases']['completed']==8
E.mkdir(exist_ok=False);(E/'.gitattributes').write_text('* -text whitespace=cr-at-eol\n',encoding='utf-8');entries={}
for key,name in records.items():
 write(E/(key+'.json'),observations[key])
 for p in (B/name).rglob('*'):
  if p.is_file() and p.suffix in {'.json','.txt','.stdout','.stderr','.def','.cs','.csproj','.py'}:entries[rel(p)]=p.read_bytes()
beforeNames=['linker24843-owned-baseline','linker24869-readint-csharp','linker24866-cli','linker24893-cli','linker24903-slg-native','linker24919-process-native']
for name in beforeNames:
 j=read(B/name/'result.json');assert j['processesStopped'];write(E/(name+'-before.json'),j)
 for p in (B/name).rglob('*'):
  if p.is_file() and p.suffix in {'.json','.txt','.stdout','.stderr','.ll','.slg'}:entries[rel(p)]=p.read_bytes()
sourcePaths=['src/Sollang.Compiler/Semantics/SemanticCompiler.cs','src/Sollang.Compiler/Cli/SelfHostPolicyCompiler.cs','src/Sollang.Compiler/Shared/SelfHostPolicyAttribute.cs','src/Sollang.Compiler/Shared/Policies/WindowsLinkPolicy.cs','src/Sollang.Compiler/Shared/Policies/NativeRuntimePolicy.cs','src/Sollang.Compiler/Tooling/WindowsLinker.cs','src/Sollang.Compiler/CodeGen/LlvmEmitter.cs','src/Sollang.Compiler/CodeGen/LlvmEmitter.RuntimeHelpers.cs','src/Sollang.Compiler/CodeGen/WindowsLlvmRuntimePlatform.cs','selfhost/windows_linker.slg','selfhost/windows_imports.slg','selfhost/runtime/windows_poll.slg','selfhost/generated/windows_link_policy.slg','selfhost/toolchain.slg','selfhost/llvm/runtime.slg','selfhost/llvm/text.slg','selfhost/llvm/text/context_prepare.slg','selfhost/llvm/text/runtime_preamble.slg','selfhost/llvm/emitter/process_runtime.slg','tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.slg','tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.sources.txt','tests/Sollang.ExampleTests/SelfHostPolicyTests.cs','docs/SPEC.md','docs/AI_SLG_BEST_PRACTICES.md']
for name in sourcePaths:
 p=R/name;entries['after-source/'+name]=p.read_bytes()
 previous=subprocess.run(['git','show','HEAD:'+name],capture_output=True)
 if previous.returncode==0:entries['before-source/'+name]=previous.stdout
for p in [*R.joinpath('scripts/probes/windows-linker').rglob('*'),*B.glob('linker248*.py'),*B.glob('linker249*.py'),*B.glob('linker248*.json'),*B.glob('linker249*.json'),Path(__file__)]:
 if p.is_file():entries[rel(p)]=p.read_bytes()
previousReview=R/'scripts/contracts/evidence/source13293/nativeabi24824-current/source-review-reconciliation.json';review=read(previousReview);changed=[]
for name,row in review['sources'].items():
 current=sha(R/name)
 if current!=row['currentSha256']:
  assert name in sourcePaths,name;changed.append(name);row.update(previousSha256=row['currentSha256'],currentSha256=current,reviewMethod='authored-delta-compared-to-CSharp-production-and-focused-Native-runtime',physicalReviewState='current-complete',previousReview=rel(previousReview),evidence=rel(E/'qualification.json'))
 else:row.update(reviewMethod='exact-byte-reuse',previousReview=rel(previousReview))
review.update(observedAtUtc=now,authoredDeltaFiles=changed,additionalAuthoredDeltas=[p for p in sourcePaths if p not in review['sources']],claimsWholePhaseComplete=False);write(E/'source-review-reconciliation.json',review)
archive=E/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(entries)
 for name,data in entries.items():assert z.read(name)==data
write(E/'archive-manifest.json',dict(sha256=sha(archive),readbackVerified=True,entries={name:dict(bytes=len(data),sha256=digest(data)) for name,data in sorted(entries.items())}))
q=dict(schemaVersion=1,status='windows-host-focused-linker-and-runtime-qualified-parent-and-platform-gates-pending',observedAtUtc=now,mainPair=dict(completed=16,total=16,percentage=100.0,evidence=['csharpLinker.json','nativeLinker.json']),actualCliPair=dict(completed=6,total=6,percentage=100.0,evidence='cli.json'),publicStackPair=dict(completed=2,total=2,evidence='cli.json',nonAdditiveToCli6=True),jobLimitPair=dict(completed=34,total=34,evidence=['jobsCsharp.json','jobsNative.json']),legacyInputPair=dict(completed=16,total=16,evidence=['inputCsharp.json','inputNative.json']),processPair=dict(completed=2,total=2,evidence=['processCsharp.json','processNative.json']),ownershipPair=dict(completed=10,total=10,evidence=['ownerCsharp.json','ownerNative.json','ownerCsharpControls.json','ownerNativeControls.json']),sharedPolicyControls=dict(completed=57,total=57,evidence='policyControls.json'),memoryComponentOracles=dict(completed=87,total=87,optimizationLevels=['O0','O1','O2'],evidence='memoryComponents.json',notWholeCompilerProof=True),sourceReview=rel(E/'source-review-reconciliation.json'),managedCompiler=rel(B/'linker24924-managed/compiler/Sollang.Compiler.exe'),nativeCompiler=rel(B/'linker24935-native/compiler.exe'),nativeCompilerSha256=observations['producer']['compilerSha256'],limitations=['Whole original14/source7/runtime2708/Stage2/Stage3 and platform/performance gates remain unresolved.','Linux-host provider selection, AppContext overrides and multiple CPU groups remain unverified.','Original1999 diagnostic budgets remain exhausted; no original1999 run was started in this unit.','Outer function-tail ownership diagnostic delivery differs between compiler layers; both reject the mixed-owner control, and C385 remains open.','Thirty-nine preexisting shaping-evidence omissions remain; no full ledger validation claim.','Historical failed and canceled outputs are retained; recognized successful generated files are cleaned through ArtifactLifecycle only.','Progress-report automatic validation remains unverified.'],archive=dict(path='evidence.zip',sha256=sha(archive),entries=len(entries),readbackVerified=True),claimsWholeWindowsLinkerEquivalent=False,claimsGoalComplete=False);write(E/'qualification.json',q)
print(json.dumps(dict(status='packaged',archiveEntries=len(entries),mainPair='16/16',cli='6/6',sourceReview=len(review['sources']),authoredReviewDeltas=changed)))

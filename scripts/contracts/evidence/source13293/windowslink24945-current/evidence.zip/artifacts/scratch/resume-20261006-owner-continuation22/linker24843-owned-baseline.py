from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'linker24843-owned-baseline';C=B/'linker24830-managed/compiler/Sollang.Compiler.exe';P=R/'scripts/probes/windows-linker/owned-task-branch.slg';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
pins={str(p.resolve()):sha(p) for p in [Path(__file__),P,C,*managed_runtime_inputs(C),*sorted((R/'stdlib').rglob('*.slg'))]}
initialize_output(R,O,reusable_directories=[B/'nativeabi24815-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,inputHashes=pins,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  r=ex.run([str(C),'build',str(P),'-o',str(O/'probe.exe'),'--target','windows-x64','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')],O/'build',timeout=30)
  assert r.returncode==1 and "owned binding 'task' must be consumed on every control-flow branch" in r.stderr,(r.stdout,r.stderr)
  result.update(status='passed',completed=1,observedCompilerFailure=r.stderr)
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))


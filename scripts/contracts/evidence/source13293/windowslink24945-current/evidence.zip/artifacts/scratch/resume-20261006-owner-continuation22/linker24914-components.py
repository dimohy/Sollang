from pathlib import Path
import sys,json,hashlib,re,ctypes,struct
from _ctypes import FreeLibrary
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'linker24914-components';bootstrap=B/'linker24890-slg-native/probe.exe';emitted=B/'linker24911-process-emitter-native/emit.stdout';managed=B/'linker24910-process-emitter-csharp/emit.stdout';base=B/'linker24903-slg-native/.l0.ll';dllBase=B/'linker24893-cli/native-shared-o1/.l0.ll';interface=dllBase.with_name('.l0.ll.slglib.json');L=R/'.tools/llvm-22.1.8';contract=R/'scripts/probes/windows-linker/contract.json';specification=R/'scripts/probes/windows-linker/expected-import-definitions.json';plan=json.loads(contract.read_text());specs=json.loads(specification.read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert emitted.read_bytes()==managed.read_bytes(),'PRODUCTION_RUNTIME_EMITTER_MISMATCH'
text=emitted.read_text(encoding='utf-8-sig');globalLine=text.splitlines()[0];assert globalLine=='@_fltused = global i32 0'
pattern=re.compile(r'^[ \t]*define\b[^\n]*@([^ (]+)[^\n]*\{\n.*?^[ \t]*}',re.M|re.S)
candidates={m.group(1):m.group() for m in pattern.finditer(text)};original=base.read_text(encoding='utf-8-sig');functions={m.group(1):m.group() for m in pattern.finditer(original)};assert candidates and set(candidates)<=set(functions)
normalize=lambda s:re.sub(r'\s+',' ',s).strip();changed=[]
for name,value in candidates.items():
 assert normalize(value.split('{',1)[0])==normalize(functions[name].split('{',1)[0]),name
 if normalize(value)!=normalize(functions[name]):changed.append(name)
assert changed==['sollang_process_spawn_windows'],changed
composed=pattern.sub(lambda m:candidates.get(m.group(1),m.group()),original)
assert not re.search(r'call[^\n]*@_get_osfhandle\(',composed)
floatSource=dllBase.read_text(encoding='utf-8-sig');assert '@_fltused' not in floatSource
floatSource=re.sub(r'(^target triple[^\n]*\n)',lambda m:m.group()+globalLine+'\n',floatSource,count=1,flags=re.M)
initialize_output(R,O,reusable_directories=[B/'nativeabi24815-native',B/'v20050/compiler-build01',B/'linker24892-native']);O.mkdir();module=O/'process-component.ll';module.write_text(composed,encoding='utf-8');floatModule=O/'float-component.ll';floatModule.write_text(floatSource,encoding='utf-8');helper=O/'component-helper.exe';work=O/'bootstrap-work';work.mkdir();prepared=[]
for case in plan['cases']:
 folder=O/case['id'];folder.mkdir();source=B/'linker24831-csharp'/case['id']/'input.ll';prepared.append((case,folder,source,folder/('product.dll' if case.get('shared') else 'product.exe')))
pins={str(p.resolve()):sha(p) for p in [Path(__file__),bootstrap,emitted,managed,base,dllBase,interface,module,floatModule,contract,specification,R/'selfhost/llvm/emitter/process_runtime.slg',R/'selfhost/llvm/runtime.slg',R/'src/Sollang.Compiler/Shared/Policies/NativeRuntimePolicy.cs',*[p[2] for p in prepared]]}
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=9,cases=[],inputHashes=pins,claimsGoalComplete=False,scope='Focused reused LLVM component test from exact production template output; not a compiler build, Stage or CLI parity pass.',compatibility=dict(sourceFunctions=len(candidates),sameSignatures=True,changedFunctions=changed,addedFloatDefinition=globalLine,emitterBytesEqual=True,unchangedOtherFunctionBodies=True));ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  r=ex.run([str(bootstrap),str(L),str(module),str(helper),str(work),'-O1','4','false','inherit'],O/'bootstrap-link',timeout=60);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  for case,folder,source,product in prepared:
   work=folder/'work';work.mkdir();r=ex.run([str(helper),str(L),str(source),str(product),str(work),case['optimization'],case['workers'],'true' if case.get('shared') else 'false',case.get('nativeJobs','inherit')],folder/'link',timeout=180)
   row=dict(id=case['id'],passed=True,linkExit=r.returncode,stdout=r.stdout,stderr=r.stderr)
   if case.get('invalid'):assert r.returncode==1 and case['expectedError'] in r.stderr and 'expected top-level entity' in r.stderr and not product.exists(),r.stdout+r.stderr
   else:
    assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
    assert len(list(work.glob('*.obj')))==case['objects'];definitions={p.name:p.read_bytes() for p in work.glob('*.def')};required=set(specs) if case.get('optionalImports') else {'kernel32.def','shell32.def','ucrtbase.def'};assert set(definitions)==required
    assert all(data==specs[name].encode('utf-8') for name,data in definitions.items())
    if case.get('shared'):
     library=ctypes.WinDLL(str(product))
     try:library.answer.restype=ctypes.c_longlong;assert library.answer()==42
     finally:FreeLibrary(library._handle)
    else:
     r=ex.run([str(product)],folder/'run',timeout=10);assert r.returncode==0 and not r.stderr and r.stdout=='42\n',r.stdout+r.stderr
    data=product.read_bytes();pe=struct.unpack_from('<I',data,60)[0];reserve,commit=struct.unpack_from('<QQ',data,pe+24+72);assert (reserve,commit)==(8388608,65536)
   result['cases'].append(row);result['completed']+=1;ex.save()
  work=O/'float-work';work.mkdir();product=O/'float.dll';r=ex.run([str(helper),str(L),str(floatModule),str(product),str(work),'-O1','4','true','inherit'],O/'float-link',timeout=60);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  api=json.loads(interface.read_text(encoding='utf-8-sig'));exports={e['name']:e for e in api['exports']};assert set(exports)=={'add','multiply','hypotSquared'}
  library=ctypes.WinDLL(str(product))
  try:
   for name,kind,values,expected in [('add',ctypes.c_int32,[20,22],42),('multiply',ctypes.c_int64,[6,7],42),('hypotSquared',ctypes.c_double,[3.0,4.0],25.0)]:
    fn=getattr(library,exports[name]['symbol']);fn.restype=kind;fn.argtypes=[kind,kind];assert fn(*values)==expected
  finally:FreeLibrary(library._handle)
  result['cases'].append(dict(id='native-float-production-global',passed=True,results=[42,42,25]));result['completed']+=1;result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped','compatibility']}))

from pathlib import Path
R=Path.cwd();p=R/'selfhost/toolchain.slg';s=p.read_text(encoding='utf-8-sig');blocks=[]
start=s.index('struct WindowsImportDefinition');end=s.index('public executablePath',start);blocks.append(s[start:end]);s=s[:start]+s[end:]
start=s.index('# The caller claims the definition/library stage names.');end=s.index('# An explicit CLI option owns precedence.',start);blocks.append(s[start:end]);s=s[:start]+s[end:]
start=s.index('# Match the reference Windows linker');blocks.append(s[start:]);s=s[:start]
s=s.replace('import sollang.compiler.windows_link_policy as windows_policy\n','');p.write_text(s,encoding='utf-8')
(R/'selfhost/windows_imports.slg').write_text('namespace sollang.compiler.windows_linker\n\nimport sys.process as process\nimport sys.file as file\nimport sys.path as paths\nimport sys.runtime as runtime\nimport sollang.compiler.windows_link_policy as windows_policy\n\n'+'\n'.join(blocks),encoding='utf-8')
driver=R/'tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.slg';s=driver.read_text(encoding='utf-8-sig');needle='import sollang.compiler.toolchain as toolchain';assert needle in s;s=s.replace(needle,needle+'\nimport sollang.compiler.windows_linker as windowsLinker');s=s.replace('toolchain.createImportLibrary','windowsLinker.createImportLibrary').replace('toolchain.usesComInterop','windowsLinker.usesComInterop');driver.write_text(s,encoding='utf-8')
manifest=driver.with_suffix('.sources.txt');s=manifest.read_text(encoding='utf-8-sig');needle='selfhost/toolchain.slg\n';assert needle in s;s=s.replace(needle,needle+'selfhost/windows_linker.slg\nselfhost/windows_imports.slg\nselfhost/runtime/windows_poll.slg\n');manifest.write_text(s,encoding='utf-8')
probe=R/'scripts/probes/windows-linker/imports.slg';s=probe.read_text(encoding='utf-8-sig').replace('sollang.compiler.toolchain','sollang.compiler.windows_linker');probe.write_text(s,encoding='utf-8')
manifest=probe.with_suffix('.sources.txt');s=manifest.read_text(encoding='utf-8-sig').replace('selfhost/toolchain.slg\n','selfhost/windows_linker.slg\nselfhost/windows_imports.slg\nselfhost/runtime/windows_poll.slg\n');manifest.write_text(s,encoding='utf-8')
print('Windows import ownership moved; generic toolchain retains wasm/Linux and LLVM discovery.')

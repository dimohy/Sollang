from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'linker24899-policy-runtime-csharp';C=B/'linker24895-managed/compiler/Sollang.Compiler.exe';contract=B/'linker24898-policy-controls/runtime-policy-contract.json';case=json.loads(contract.read_text(encoding='utf-8-sig'))['cases'][0];P=Path(case['source']);sources=[P,*map(Path,case['additionalSources'])];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
pins={str(p.resolve()):sha(p) for p in [Path(__file__),contract,*sources,C,*managed_runtime_inputs(C),*sorted((R/'stdlib').rglob('*.slg'))]}
initialize_output(R,O,reusable_directories=[B/'nativeabi24815-native',B/'v20050/compiler-build01',B/'linker24892-native']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,inputHashes=pins,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  r=ex.run([str(C),'build',*map(str,sources),'-o',str(O/'probe.exe'),'--target','windows-x64','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')],O/'build',timeout=60)
  assert r.returncode==0 and not r.stderr,(r.stdout,r.stderr)
  r=ex.run([str(O/'probe.exe')],O/'run',timeout=10)
  assert r.returncode==0 and not r.stderr and r.stdout.rstrip('\n')==case['stdout'].replace('\r\n','\n').rstrip('\n'),(r.stdout,r.stderr)
  result.update(status='passed',completed=1,observedStdout=r.stdout)
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))



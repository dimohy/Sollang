from pathlib import Path
import sys,json,hashlib,time,re,textwrap,ctypes,struct
from xml.sax.saxutils import escape
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=B/'nativeabi24815-native/compiler.exe';O=B/'linker24890-slg-native';L=R/'.tools/llvm-22.1.8';contract=R/'scripts/probes/windows-linker/contract.json';plan=json.loads(contract.read_text());harness=R/'scripts/probes/windows-linker/reference-harness.cs';linker=R/'src/Sollang.Compiler/Tooling/WindowsLinker.cs';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert len(plan['cases'])==8 and plan['pairedTotal']==16
assert all((L/'bin'/name).is_file() for name in plan['requiredTools']), 'WINDOWS_LINK_TOOLS_MISSING'
initialize_output(R,O,reusable_directories=[B/'nativeabi24815-native',B/'v20050/compiler-build01',B/'linker24865-native']);O.mkdir()
manifest=R/'scripts/probes/windows-linker/link.sources.txt';sources=[R/p for p in manifest.read_text().splitlines() if p];specification=R/'scripts/probes/windows-linker/expected-import-definitions.json';specs=json.loads(specification.read_text());prepared=[]
for case in plan['cases']:
 folder=O/case['id'];folder.mkdir();source=B/'linker24831-csharp'/case['id']/'input.ll';prepared.append((case,folder,source,folder/('product.dll' if case.get('shared') else 'product.exe')))
paths=[Path(__file__),manifest,*sources,contract,specification,C,*[L/'bin'/name for name in plan['requiredTools']],*[p[2] for p in prepared],*sorted((R/'stdlib').rglob('*.slg'))];pins={str(p.resolve()):sha(p) for p in paths}
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=8,cases=[],inputHashes=pins,scope=plan['scope'],claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  probe=O/'probe.exe';r=ex.run([str(C),'build',*map(str,sources),'-o',str(probe),'--target','windows-x64','--keep-temps','-O1','--jobs','4','--llvm',str(L)],O/'probe-build',timeout=180);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  for case,folder,source,product in prepared:
   start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));work=folder/'work'
   work.mkdir()
   args=[str(probe),str(L),str(source),str(product),str(work),case['optimization'],case['workers'],'true' if case.get('shared') else 'false',case.get('nativeJobs','inherit')]
   r=ex.run(args,folder/'link',timeout=budget());row=dict(id=case['id'],passed=False,linkExit=r.returncode,stdout=r.stdout,stderr=r.stderr)
   if case.get('invalid'):
    assert r.returncode==1 and case['expectedError'] in r.stderr and 'expected top-level entity' in r.stderr and not product.exists(),r.stdout+r.stderr
   else:
    assert r.returncode==0 and not r.stderr,r.stdout+r.stderr;detail=dict(processors=int(r.stdout.splitlines()[-1].split('=')[1]),objects=[str(p) for p in sorted(work.glob('*.obj'))],definitions={p.name:p.read_text(encoding='utf-8-sig') for p in sorted(work.glob('*.def'))});assert detail['processors']>=2,'LINKER_PARTITION_FIXTURE_REQUIRES_TWO_PROCESSORS'
    assert len(detail['objects'])==case['objects'],detail
    required=set(specs) if case.get('optionalImports') else {'kernel32.def','shell32.def','ucrtbase.def'};assert set(detail['definitions'])==required,detail
    for name,text in detail['definitions'].items():assert text==specs[name] and (work/name).read_bytes()==specs[name].encode('utf-8'),name
    row['details']=detail;row['artifactSha256']=sha(product)
    if case.get('shared'):
     from _ctypes import FreeLibrary
     library=ctypes.WinDLL(str(product))
     try:library.answer.restype=ctypes.c_longlong;assert library.answer()==42
     finally:FreeLibrary(library._handle)
     row['libraryAnswer']=42
    else:
     run=ex.run([str(product)],folder/'run',timeout=budget());assert run.returncode==0 and not run.stderr and run.stdout=='42\n',run.stdout+run.stderr;row['runtimeStdout']=run.stdout
    data=product.read_bytes();pe=struct.unpack_from('<I',data,60)[0];optional=pe+24;assert data[pe:pe+4]==b'PE\x00\x00' and struct.unpack_from('<H',data,optional)[0]==0x20b
    reserve,commit=struct.unpack_from('<QQ',data,optional+72);assert reserve==plan['publicStackReserve'] and commit==plan['publicStackCommit'];row['stack']=dict(reserve=reserve,commit=commit)
   row['passed']=True;result['cases'].append(row);result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))




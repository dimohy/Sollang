from pathlib import Path
import sys,json,hashlib,ctypes,struct
from _ctypes import FreeLibrary
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'linker24896-csharp-cli';C=B/'linker24895-managed/compiler/Sollang.Compiler.exe';N=B/'linker24892-native/compiler.exe';P=R/'scripts/probes/windows-linker/public-stack.slg';D=R/'tests/native-interop/sollang_fixture.slg';L=R/'.tools/llvm-22.1.8';contract=R/'scripts/probes/windows-linker/contract.json';plan=json.loads(contract.read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
pins={str(p.resolve()):sha(p) for p in [Path(__file__),P,D,contract,C,N,*managed_runtime_inputs(C),*sorted((R/'stdlib').rglob('*.slg'))]}
initialize_output(R,O,reusable_directories=[B/'nativeabi24815-native',B/'v20050/compiler-build01',B/'linker24892-native']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=3,cases=[],inputHashes=pins,publicStackPair=dict(completed=0,total=2),claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for compiler,role in [(C,'csharp')]:
   for mode in ['stack-o1','stack-o0','shared-o1']:
    folder=O/(role+'-'+mode);folder.mkdir();shared=mode=='shared-o1';output=folder/('product.dll' if shared else 'product.exe');source=D if shared else P
    args=[str(compiler),'build',str(source),'-o',str(output),'--target','windows-x64','--jobs','4','--llvm',str(L),'-O0' if mode=='stack-o0' else '-O1','--keep-temps']
    if shared:args.append('--library')
    r=ex.run(args,folder/'build',timeout=180);assert r.returncode==0 and not r.stderr,(role,mode,r.stdout,r.stderr)
    data=output.read_bytes();pe=struct.unpack_from('<I',data,60)[0];optional=pe+24;assert data[pe:pe+4]==b'PE\x00\x00' and struct.unpack_from('<H',data,optional)[0]==0x20b
    reserve,commit=struct.unpack_from('<QQ',data,optional+72);assert reserve==plan['publicStackReserve'] and commit==plan['publicStackCommit'],(role,mode,reserve,commit)
    row=dict(id=role+'-'+mode,passed=True,stack=dict(reserve=reserve,commit=commit),artifactSha256=sha(output),compilerStdout=r.stdout)
    if shared:
     assert struct.unpack_from('<I',data,optional+16)[0]==0
     manifest=folder/'product.windows-x64.slglib.json';api=json.loads(manifest.read_text(encoding='utf-8-sig'));exports={e['name']:e for e in api['exports']};assert set(exports)=={'add','multiply','hypotSquared'} and api['target']=='windows-x64',api
     library=ctypes.WinDLL(str(output))
     try:
      for name,kind,values,expected in [('add',ctypes.c_int32,[20,22],42),('multiply',ctypes.c_int64,[6,7],42),('hypotSquared',ctypes.c_double,[3.0,4.0],25.0)]:
       fn=getattr(library,exports[name]['symbol']);fn.restype=kind;fn.argtypes=[kind,kind];assert fn(*values)==expected
     finally:FreeLibrary(library._handle)
     row['libraryResults']=[42,42,25];row['interface']=api
    else:
     r=ex.run([str(output)],folder/'run',timeout=10);assert r.returncode==0 and not r.stderr and r.stdout=='42\n',(r.stdout,r.stderr);row['runtimeStdout']=r.stdout
     if mode=='stack-o1':result['publicStackPair']['completed']+=1
    result['cases'].append(row);result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped','publicStackPair']}))

from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'linker24949-lifecycle-guard';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();paths=[Path(__file__),R/'scripts/completed_artifact_plan.py',R/'scripts/test_completed_artifacts.py',R/'scripts/ArtifactLifecycle.ps1',R/'scripts/Invoke-CompletedArtifactCleanup.ps1',R/'scripts/contracts/artifact-lifecycle.json'];pins={str(p.resolve()):sha(p) for p in paths};initialize_output(R,O,reusable_directories=[B/'linker24916-native',B/'v20050/compiler-build01',B/'linker24935-native']);O.mkdir()
with VerificationContractLease(list(map(Path,pins))):
 result=dict(schemaVersion=1,status='running',completed=0,total=4,cases=[],inputHashes=pins,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  r=ex.run([sys.executable,'-X','utf8','-m','unittest','discover','-s','scripts','-p','test_completed_artifacts.py','-k','declared','-v'],O/'tests',timeout=60);assert r.returncode==0 and 'Ran 4 tests' in r.stderr and '\nOK\n' in r.stderr,r.stdout+r.stderr
  result.update(status='passed',completed=4,cases=[dict(id=name,passed=True) for name in ['maximum-reusable-limit','missing-reusable-product','preserve-pinned-LLVM-input-and-remove-generated-LLVM','reject-crafted-input-deletion-plan']])
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

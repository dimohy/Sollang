; sollang workers = 4
; sollang.codegen.unit 0:
; sollang.codegen.key 1931366173152882045:3119186839603867641
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"
declare ptr @GetProcessHeap()
declare ptr @HeapAlloc(ptr, i32, i64)
declare i32 @HeapFree(ptr, i32, ptr)
define internal ptr @sollang_alloc(i64 %bytes) {
entry:
  %heap = call ptr @GetProcessHeap()
  %value = call ptr @HeapAlloc(ptr %heap, i32 0, i64 %bytes)
  ret ptr %value
}
define internal void @sollang_free(ptr %value) {
entry:
  %is_null = icmp eq ptr %value, null
  br i1 %is_null, label %done, label %release
release:
  %heap = call ptr @GetProcessHeap()
  %ignored = call i32 @HeapFree(ptr %heap, i32 0, ptr %value)
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1 immarg)
declare ptr @GetStdHandle(i32)
declare i32 @GetConsoleMode(ptr, ptr)
declare i32 @WriteConsoleW(ptr, ptr, i32, ptr, ptr)
declare i32 @WriteFile(ptr, ptr, i32, ptr, ptr)
declare i32 @MultiByteToWideChar(i32, i32, ptr, i32, ptr, i32)
define internal i32 @sollang_write_stream_chunk(ptr %handle, ptr %data, i32 %len, ptr %written, i1 %is_console) {
entry:
  %empty = icmp eq i32 %len, 0
  br i1 %empty, label %success_empty, label %classify

success_empty:
  store i32 0, ptr %written, align 4
  ret i32 1

classify:
  br i1 %is_console, label %console_prepare, label %redirected

redirected:
  br label %redirected_write

redirected_write:
  %redirected_offset = phi i32 [ 0, %redirected ], [ %redirected_next, %redirected_advance ]
  %redirected_remaining = sub i32 %len, %redirected_offset
  %redirected_offset64 = zext i32 %redirected_offset to i64
  %redirected_data = getelementptr i8, ptr %data, i64 %redirected_offset64
  store i32 0, ptr %written, align 4
  %redirected_ok = call i32 @WriteFile(ptr %handle, ptr %redirected_data, i32 %redirected_remaining, ptr %written, ptr null)
  %redirected_count = load i32, ptr %written, align 4
  %redirected_succeeded = icmp ne i32 %redirected_ok, 0
  %redirected_progress = icmp ugt i32 %redirected_count, 0
  %redirected_bounded = icmp ule i32 %redirected_count, %redirected_remaining
  %redirected_valid0 = and i1 %redirected_succeeded, %redirected_progress
  %redirected_valid = and i1 %redirected_valid0, %redirected_bounded
  br i1 %redirected_valid, label %redirected_advance, label %write_failed

redirected_advance:
  %redirected_next = add i32 %redirected_offset, %redirected_count
  %redirected_complete = icmp eq i32 %redirected_next, %len
  br i1 %redirected_complete, label %write_succeeded, label %redirected_write

console_prepare:
  %wide_chars = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %len, ptr null, i32 0)
  %valid_utf8 = icmp sgt i32 %wide_chars, 0
  br i1 %valid_utf8, label %allocate, label %conversion_failed

allocate:
  %wide_bytes32 = shl i32 %wide_chars, 1
  %wide_bytes = zext i32 %wide_bytes32 to i64
  %heap = call ptr @GetProcessHeap()
  %wide = call ptr @HeapAlloc(ptr %heap, i32 0, i64 %wide_bytes)
  %wide_written = alloca i32, align 4
  %allocated = icmp ne ptr %wide, null
  br i1 %allocated, label %convert, label %conversion_failed

convert:
  %converted = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %len, ptr %wide, i32 %wide_chars)
  %converted_all = icmp eq i32 %converted, %wide_chars
  br i1 %converted_all, label %console_write, label %conversion_free

console_write:
  %console_offset = phi i32 [ 0, %convert ], [ %console_next, %console_advance ]
  %console_remaining = sub i32 %wide_chars, %console_offset
  %console_offset64 = zext i32 %console_offset to i64
  %console_data = getelementptr i16, ptr %wide, i64 %console_offset64
  store i32 0, ptr %wide_written, align 4
  %console_ok = call i32 @WriteConsoleW(ptr %handle, ptr %console_data, i32 %console_remaining, ptr %wide_written, ptr null)
  %console_count = load i32, ptr %wide_written, align 4
  %console_succeeded = icmp ne i32 %console_ok, 0
  %console_progress = icmp ugt i32 %console_count, 0
  %console_bounded = icmp ule i32 %console_count, %console_remaining
  %console_valid0 = and i1 %console_succeeded, %console_progress
  %console_valid = and i1 %console_valid0, %console_bounded
  br i1 %console_valid, label %console_advance, label %console_write_failed

console_advance:
  %console_next = add i32 %console_offset, %console_count
  %console_complete = icmp eq i32 %console_next, %wide_chars
  br i1 %console_complete, label %console_write_succeeded, label %console_write

console_write_succeeded:
  %freed = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %write_succeeded

console_write_failed:
  %freed_after_write_failure = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %write_failed

write_succeeded:
  store i32 %len, ptr %written, align 4
  ret i32 1

write_failed:
  store i32 0, ptr %written, align 4
  ret i32 0

conversion_free:
  %freed_after_failure = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %conversion_failed

conversion_failed:
  store i32 0, ptr %written, align 4
  ret i32 0
}

define internal i32 @sollang_write_stream(ptr %handle, ptr %data, i64 %len64, ptr %written, i1 %is_console) {
entry:
  %empty = icmp eq i64 %len64, 0
  br i1 %empty, label %success_empty, label %prepare

success_empty:
  store i32 0, ptr %written, align 4
  ret i32 1

prepare:
  %offset = phi i64 [ 0, %entry ], [ %next, %advance ]
  %remaining = sub i64 %len64, %offset
  %current = getelementptr i8, ptr %data, i64 %offset
  %more = icmp ugt i64 %remaining, 1048576
  %proposed = select i1 %more, i64 1048576, i64 %remaining
  %split_console = and i1 %more, %is_console
  br i1 %split_console, label %trim_boundary, label %write

trim_boundary:
  %boundary = phi i64 [ 1048576, %prepare ], [ %previous, %trim_next ]
  %boundary_ptr = getelementptr i8, ptr %current, i64 %boundary
  %boundary_byte = load i8, ptr %boundary_ptr, align 1
  %prefix = and i8 %boundary_byte, -64
  %continuation = icmp eq i8 %prefix, -128
  br i1 %continuation, label %trim_next, label %write

trim_next:
  %can_trim = icmp ugt i64 %boundary, 1048573
  %previous = sub i64 %boundary, 1
  br i1 %can_trim, label %trim_boundary, label %failure

write:
  %chunk64 = phi i64 [ %proposed, %prepare ], [ %boundary, %trim_boundary ]
  %chunk32 = trunc i64 %chunk64 to i32
  %ok = call i32 @sollang_write_stream_chunk(ptr %handle, ptr %current, i32 %chunk32, ptr %written, i1 %is_console)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %advance, label %failure

advance:
  %next = add i64 %offset, %chunk64
  %complete = icmp eq i64 %next, %len64
  br i1 %complete, label %success, label %prepare

success:
  ret i32 1

failure:
  store i32 0, ptr %written, align 4
  ret i32 0
}

define internal i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %len) {
entry:
  %written = alloca i32, align 4
  %mode = alloca i32, align 4
  %empty = icmp eq i64 %len, 0
  br i1 %empty, label %success, label %classify
classify:
  %console_status = call i32 @GetConsoleMode(ptr %handle, ptr %mode)
  %is_console = icmp ne i32 %console_status, 0
  %ok = call i32 @sollang_write_stream(ptr %handle, ptr %data, i64 %len, ptr %written, i1 %is_console)
  ret i32 %ok
success:
  ret i32 1
}
define internal i32 @sollang_runtime_write_stdout_bytes(ptr %handle, ptr %data, i32 %len) {
entry:
  %length = zext i32 %len to i64
  %ok = call i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %length)
  ret i32 %ok
}
@sollang_runtime_newline = private constant [1 x i8] c"\0A"
@sollang_runtime_stdout_buffer = private global [1048576 x i8] zeroinitializer
@sollang_runtime_stdout_count = private global i64 0
define internal void @sollang_runtime_flush_stdout() {
entry:
  %count = load i64, ptr @sollang_runtime_stdout_count, align 8
  %has_data = icmp ugt i64 %count, 0
  br i1 %has_data, label %write, label %done
write:
  %handle = call ptr @GetStdHandle(i32 -11)
  %count32 = trunc i64 %count to i32
  %ok = call i32 @sollang_runtime_write_stdout_bytes(ptr %handle, ptr @sollang_runtime_stdout_buffer, i32 %count32)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %clear, label %failure
clear:
  store i64 0, ptr @sollang_runtime_stdout_count, align 8
  br label %done
failure:
  call void @llvm.trap()
  unreachable
done:
  ret void
}
define internal void @sollang_runtime_append_stdout(ptr %data, i64 %len) {
entry:
  %count = load i64, ptr @sollang_runtime_stdout_count, align 8
  %total = add i64 %count, %len
  %available = sub i64 1048576, %count
  %fits = icmp ule i64 %len, %available
  br i1 %fits, label %append, label %flush
flush:
  call void @sollang_runtime_flush_stdout()
  %large = icmp ugt i64 %len, 1048576
  br i1 %large, label %direct, label %append_empty
direct:
  %handle = call ptr @GetStdHandle(i32 -11)
  %ok = call i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %len)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %direct_done, label %direct_failure
direct_done:
  ret void
direct_failure:
  call void @llvm.trap()
  unreachable
append_empty:
  call void @llvm.memcpy.p0.p0.i64(ptr @sollang_runtime_stdout_buffer, ptr %data, i64 %len, i1 false)
  store i64 %len, ptr @sollang_runtime_stdout_count, align 8
  ret void
append:
  %slot = getelementptr i8, ptr @sollang_runtime_stdout_buffer, i64 %count
  call void @llvm.memcpy.p0.p0.i64(ptr %slot, ptr %data, i64 %len, i1 false)
  store i64 %total, ptr @sollang_runtime_stdout_count, align 8
  ret void
}
define internal void @sollang_runtime_print(ptr %data, i64 %len, i1 %newline) {
entry:
  call void @sollang_runtime_append_stdout(ptr %data, i64 %len)
  br i1 %newline, label %write_newline, label %done
write_newline:
  call void @sollang_runtime_append_stdout(ptr @sollang_runtime_newline, i64 1)
  br label %done
done:
  ret void
}
@sollang_runtime_error_newline = private constant [2 x i8] c"\0D\0A"
define internal void @sollang_runtime_eprint(ptr %data, i64 %len, i1 %newline) {
entry:
  %handle = call ptr @GetStdHandle(i32 -12)
  %ok = call i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %len)
  br i1 %newline, label %write_newline, label %done
write_newline:
  %newline_ok = call i32 @sollang_runtime_write_stdout_bytes(ptr %handle, ptr @sollang_runtime_error_newline, i32 2)
  br label %done
done:
  ret void
}
define internal void @sollang_runtime_eprintln(ptr %data, i64 %len) {
entry:
  call void @sollang_runtime_eprint(ptr %data, i64 %len, i1 true)
  ret void
}
define internal i64 @sollang_format_u64(ptr %dest, i64 %value) {
entry:
  br label %count
count:
  %count_n = phi i64 [ %value, %entry ], [ %count_q, %count_more ]
  %length = phi i64 [ 1, %entry ], [ %next_length, %count_more ]
  %count_q = udiv i64 %count_n, 10
  %count_done = icmp eq i64 %count_q, 0
  br i1 %count_done, label %write_entry, label %count_more
count_more:
  %next_length = add i64 %length, 1
  br label %count
write_entry:
  %last_index = sub i64 %length, 1
  br label %write
write:
  %write_n = phi i64 [ %value, %write_entry ], [ %write_q, %write ]
  %index = phi i64 [ %last_index, %write_entry ], [ %previous_index, %write ]
  %digit = urem i64 %write_n, 10
  %write_q = udiv i64 %write_n, 10
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  %slot = getelementptr i8, ptr %dest, i64 %index
  store i8 %ascii, ptr %slot, align 1
  %previous_index = sub i64 %index, 1
  %write_done = icmp eq i64 %write_q, 0
  br i1 %write_done, label %return, label %write
return:
  ret i64 %length
}
define internal i64 @sollang_format_i64(ptr %dest, i64 %value) {
entry:
  %negative = icmp slt i64 %value, 0
  br i1 %negative, label %negative_value, label %positive_value
negative_value:
  store i8 45, ptr %dest, align 1
  %digits_dest = getelementptr i8, ptr %dest, i64 1
  %magnitude = sub i64 0, %value
  %negative_digits = call i64 @sollang_format_u64(ptr %digits_dest, i64 %magnitude)
  %negative_length = add i64 %negative_digits, 1
  ret i64 %negative_length
positive_value:
  %positive_length = call i64 @sollang_format_u64(ptr %dest, i64 %value)
  ret i64 %positive_length
}
define internal void @sollang_runtime_print_i32(i32 %value, i1 %newline) {
entry:
  %buffer = alloca [12 x i8], align 1
  %end = getelementptr [12 x i8], ptr %buffer, i64 0, i64 12
  %wide = sext i32 %value to i64
  %negative = icmp slt i64 %wide, 0
  %negated = sub i64 0, %wide
  %magnitude = select i1 %negative, i64 %negated, i64 %wide
  br label %digits
digits:
  %current = phi i64 [ %magnitude, %entry ], [ %quotient, %digits ]
  %cursor = phi ptr [ %end, %entry ], [ %digit_slot, %digits ]
  %digit = urem i64 %current, 10
  %quotient = udiv i64 %current, 10
  %digit_slot = getelementptr i8, ptr %cursor, i64 -1
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  store i8 %ascii, ptr %digit_slot, align 1
  %more = icmp ne i64 %quotient, 0
  br i1 %more, label %digits, label %digits_done
digits_done:
  br i1 %negative, label %write_sign, label %emit
write_sign:
  %sign_slot = getelementptr i8, ptr %digit_slot, i64 -1
  store i8 45, ptr %sign_slot, align 1
  br label %emit
emit:
  %start = phi ptr [ %digit_slot, %digits_done ], [ %sign_slot, %write_sign ]
  %end_address = ptrtoint ptr %end to i64
  %start_address = ptrtoint ptr %start to i64
  %length = sub i64 %end_address, %start_address
  call void @sollang_runtime_print(ptr %start, i64 %length, i1 %newline)
  ret void
}
define internal void @sollang_runtime_print_i64(i64 %value, i1 %signed, i1 %newline) {
entry:
  %buffer = alloca [21 x i8], align 1
  %end = getelementptr [21 x i8], ptr %buffer, i64 0, i64 21
  %negative_value = icmp slt i64 %value, 0
  %negative = and i1 %signed, %negative_value
  %negated = sub i64 0, %value
  %magnitude = select i1 %negative, i64 %negated, i64 %value
  br label %digits
digits:
  %current = phi i64 [ %magnitude, %entry ], [ %quotient, %digits ]
  %cursor = phi ptr [ %end, %entry ], [ %digit_slot, %digits ]
  %digit = urem i64 %current, 10
  %quotient = udiv i64 %current, 10
  %digit_slot = getelementptr i8, ptr %cursor, i64 -1
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  store i8 %ascii, ptr %digit_slot, align 1
  %more = icmp ne i64 %quotient, 0
  br i1 %more, label %digits, label %digits_done
digits_done:
  br i1 %negative, label %write_sign, label %emit
write_sign:
  %sign_slot = getelementptr i8, ptr %digit_slot, i64 -1
  store i8 45, ptr %sign_slot, align 1
  br label %emit
emit:
  %start = phi ptr [ %digit_slot, %digits_done ], [ %sign_slot, %write_sign ]
  %end_address = ptrtoint ptr %end to i64
  %start_address = ptrtoint ptr %start to i64
  %length = sub i64 %end_address, %start_address
  call void @sollang_runtime_print(ptr %start, i64 %length, i1 %newline)
  ret void
}
@sollang_runtime_bool_true = private constant [4 x i8] c"true"
@sollang_runtime_bool_false = private constant [5 x i8] c"false"
define internal void @sollang_runtime_print_i1(i1 %value, i1 %newline) {
entry:
  %data = select i1 %value, ptr @sollang_runtime_bool_true, ptr @sollang_runtime_bool_false
  %length = select i1 %value, i64 4, i64 5
  call void @sollang_runtime_print(ptr %data, i64 %length, i1 %newline)
  ret void
}
define internal void @sollang_runtime_eprint_i32(i32 %value, i1 %newline) {
entry:
  %buffer = alloca [12 x i8], align 1
  %end = getelementptr [12 x i8], ptr %buffer, i64 0, i64 12
  %wide = sext i32 %value to i64
  %negative = icmp slt i64 %wide, 0
  %negated = sub i64 0, %wide
  %magnitude = select i1 %negative, i64 %negated, i64 %wide
  br label %digits
digits:
  %current = phi i64 [ %magnitude, %entry ], [ %quotient, %digits ]
  %cursor = phi ptr [ %end, %entry ], [ %digit_slot, %digits ]
  %digit = urem i64 %current, 10
  %quotient = udiv i64 %current, 10
  %digit_slot = getelementptr i8, ptr %cursor, i64 -1
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  store i8 %ascii, ptr %digit_slot, align 1
  %more = icmp ne i64 %quotient, 0
  br i1 %more, label %digits, label %digits_done
digits_done:
  br i1 %negative, label %write_sign, label %emit
write_sign:
  %sign_slot = getelementptr i8, ptr %digit_slot, i64 -1
  store i8 45, ptr %sign_slot, align 1
  br label %emit
emit:
  %start = phi ptr [ %digit_slot, %digits_done ], [ %sign_slot, %write_sign ]
  %end_address = ptrtoint ptr %end to i64
  %start_address = ptrtoint ptr %start to i64
  %length = sub i64 %end_address, %start_address
  call void @sollang_runtime_eprint(ptr %start, i64 %length, i1 %newline)
  ret void
}
define internal void @sollang_runtime_eprint_i64(i64 %value, i1 %signed, i1 %newline) {
entry:
  %buffer = alloca [21 x i8], align 1
  %end = getelementptr [21 x i8], ptr %buffer, i64 0, i64 21
  %negative_value = icmp slt i64 %value, 0
  %negative = and i1 %signed, %negative_value
  %negated = sub i64 0, %value
  %magnitude = select i1 %negative, i64 %negated, i64 %value
  br label %digits
digits:
  %current = phi i64 [ %magnitude, %entry ], [ %quotient, %digits ]
  %cursor = phi ptr [ %end, %entry ], [ %digit_slot, %digits ]
  %digit = urem i64 %current, 10
  %quotient = udiv i64 %current, 10
  %digit_slot = getelementptr i8, ptr %cursor, i64 -1
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  store i8 %ascii, ptr %digit_slot, align 1
  %more = icmp ne i64 %quotient, 0
  br i1 %more, label %digits, label %digits_done
digits_done:
  br i1 %negative, label %write_sign, label %emit
write_sign:
  %sign_slot = getelementptr i8, ptr %digit_slot, i64 -1
  store i8 45, ptr %sign_slot, align 1
  br label %emit
emit:
  %start = phi ptr [ %digit_slot, %digits_done ], [ %sign_slot, %write_sign ]
  %end_address = ptrtoint ptr %end to i64
  %start_address = ptrtoint ptr %start to i64
  %length = sub i64 %end_address, %start_address
  call void @sollang_runtime_eprint(ptr %start, i64 %length, i1 %newline)
  ret void
}
define internal void @sollang_runtime_eprint_i1(i1 %value, i1 %newline) {
entry:
  %data = select i1 %value, ptr @sollang_runtime_bool_true, ptr @sollang_runtime_bool_false
  %length = select i1 %value, i64 4, i64 5
  call void @sollang_runtime_eprint(ptr %data, i64 %length, i1 %newline)
  ret void
}
declare dllimport i32 @GetLastError()
declare dllimport ptr @CreateFileA(ptr, i32, i32, ptr, i32, i32, ptr)
declare dllimport ptr @CreateFileW(ptr, i32, i32, ptr, i32, i32, ptr)
declare dllimport i32 @WaitForSingleObject(ptr, i32)
declare dllimport i32 @CloseHandle(ptr)
declare dllimport ptr @GetCommandLineW()
declare dllimport ptr @CommandLineToArgvW(ptr, ptr)
declare dllimport ptr @LocalFree(ptr)
declare dllimport i32 @WideCharToMultiByte(i32, i32, ptr, i32, ptr, i32, ptr, ptr)
declare dllimport ptr @GetCurrentProcess()
declare dllimport i32 @DuplicateHandle(ptr, ptr, ptr, ptr, i32, i32, i32)
declare dllimport i32 @CreateProcessW(ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, ptr, ptr)
declare dllimport ptr @GetEnvironmentStringsW()
declare dllimport i32 @FreeEnvironmentStringsW(ptr)
declare dllimport i32 @CompareStringOrdinal(ptr, i32, ptr, i32, i32)
declare dllimport i32 @GetProcessId(ptr)
declare dllimport i32 @GetExitCodeProcess(ptr, ptr)
declare dllimport i32 @TerminateProcess(ptr, i32)
%sollang.process_result = type { i32, i32 }
%sollang.process_poll_result = type { i32, i32 }
%sollang.process_spawn_result = type { i64, i64, i32 }
%sollang.process_capture_result = type { i32, ptr, i64, i64, i1, ptr, i64, i64, i1, i32 }
%sollang.process_environment_result = type { ptr, i64, i64, i1 }
@sollang_process_error_spawn = private constant [5 x i8] c"spawn"
@sollang_process_error_wait = private constant [4 x i8] c"wait"
@sollang_process_error_signal = private constant [6 x i8] c"signal"
@sollang_process_error_capture = private constant [7 x i8] c"capture"
@sollang_bool_true_bytes = private constant [4 x i8] c"true"
@sollang_bool_false_bytes = private constant [5 x i8] c"false"
%sollang.source_text = type { ptr, i64, ptr, i64 }
%sollang.text = type { ptr, i64 }
%sollang.stream = type { ptr, ptr, ptr }
%sollang.event_stream = type { ptr, ptr, ptr }
%sollang.enum.t460 = type { i32, [0 x i64] }
%sollang.enum.t461 = type { i32, [0 x i64] }
%sollang.enum.t462 = type { i32, [0 x i64] }
%sollang.enum.t463 = type { i32, [0 x i64] }
%sollang.enum.t464 = type { i32, [0 x i64] }
%sollang.enum.t465 = type { i32, [0 x i64] }
%sollang.enum.t466 = type { i32, [0 x i64] }
%sollang.enum.t467 = type { i32, [0 x i64] }
%sollang.enum.t468 = type { i32, [0 x i64] }
%sollang.enum.t469 = type { i32, [0 x i64] }
%sollang.enum.t470 = type { i32, [0 x i64] }
%sollang.enum.t471 = type { i32, [0 x i64] }
%sollang.enum.t472 = type { i32, [0 x i64] }
%sollang.enum.t473 = type { i32, [1 x i64] }
%sollang.enum.t474 = type { i32, [1 x i64] }
%sollang.enum.t475 = type { i32, [0 x i64] }
%sollang.enum.t476 = type { i32, [0 x i64] }
%sollang.enum.t477 = type { i32, [5 x i64] }
%sollang.enum.t478 = type { i32, [4 x i64] }
%sollang.enum.t479 = type { i32, [0 x i64] }
%sollang.enum.t480 = type { i32, [1 x i64] }
%sollang.enum.t481 = type { i32, [0 x i64] }
%sollang.enum.t482 = type { i32, [1 x i64] }
%sollang.enum.t483 = type { i32, [0 x i64] }
%sollang.enum.t484 = type { i32, [1 x i64] }
%sollang.enum.t485 = type { i32, [0 x i64] }
%sollang.enum.t486 = type { i32, [1 x i64] }
%sollang.enum.t487 = type { i32, [1 x i64] }
%sollang.enum.t488 = type { i32, [0 x i64] }
%sollang.enum.t489 = type { i32, [66 x i64] }
%sollang.enum.t490 = type { i32, [1 x i64] }
%sollang.enum.t491 = type { i32, [1 x i64] }
%sollang.enum.t492 = type { i32, [0 x i64] }
%sollang.enum.t493 = type { i32, [4 x i64] }
%sollang.enum.t494 = type { i32, [1 x i64] }
%sollang.enum.t495 = type { i32, [1 x i64] }
%sollang.enum.t496 = type { i32, [0 x i64] }
%sollang.enum.t497 = type { i32, [0 x i64] }
%sollang.enum.t498 = type { i32, [0 x i64] }
%sollang.enum.t499 = type { i32, [0 x i64] }
%sollang.enum.t500 = type { i32, [0 x i64] }
%sollang.enum.t501 = type { i32, [1 x i64] }
%sollang.enum.t502 = type { i32, [0 x i64] }
%sollang.enum.t503 = type { i32, [4 x i64] }
%sollang.enum.t504 = type { i32, [1 x i64] }
%sollang.enum.t505 = type { i32, [0 x i64] }
%sollang.enum.t506 = type { i32, [1 x i64] }
%sollang.enum.t507 = type { i32, [1 x i64] }
%sollang.enum.t508 = type { i32, [0 x i64] }
%sollang.enum.t509 = type { i32, [0 x i64] }
%sollang.enum.t510 = type { i32, [0 x i64] }
%sollang.enum.t511 = type { i32, [1 x i64] }
%sollang.enum.t512 = type { i32, [0 x i64] }
%sollang.enum.t513 = type { i32, [0 x i64] }
%sollang.enum.t514 = type { i32, [0 x i64] }
%sollang.enum.t515 = type { i32, [0 x i64] }
%sollang.enum.t516 = type { i32, [0 x i64] }
%sollang.enum.t517 = type { i32, [0 x i64] }
%sollang.enum.t518 = type { i32, [0 x i64] }
%sollang.enum.t519 = type { i32, [0 x i64] }
%sollang.enum.t520 = type { i32, [0 x i64] }
%sollang.enum.t521 = type { i32, [3 x i64] }
%sollang.enum.t522 = type { i32, [0 x i64] }
%sollang.enum.t523 = type { i32, [0 x i64] }
%sollang.enum.t524 = type { i32, [0 x i64] }
%sollang.enum.t525 = type { i32, [0 x i64] }
%sollang.enum.t526 = type { i32, [0 x i64] }
%sollang.enum.t527 = type { i32, [0 x i64] }
%sollang.enum.t528 = type { i32, [0 x i64] }
%sollang.enum.t529 = type { i32, [0 x i64] }
%sollang.enum.t530 = type { i32, [0 x i64] }
%sollang.enum.t531 = type { i32, [0 x i64] }
%sollang.enum.t532 = type { i32, [3 x i64] }
%sollang.enum.t533 = type { i32, [0 x i64] }
%sollang.enum.t534 = type { i32, [2 x i64] }
%sollang.enum.t535 = type { i32, [0 x i64] }
%sollang.enum.t536 = type { i32, [2 x i64] }
%sollang.enum.t537 = type { i32, [4 x i64] }
%sollang.enum.t538 = type { i32, [0 x i64] }
%sollang.enum.t539 = type { i32, [0 x i64] }
%sollang.enum.t540 = type { i32, [0 x i64] }
%sollang.enum.t541 = type { i32, [1 x i64] }
%sollang.enum.t542 = type { i32, [0 x i64] }
%sollang.enum.t543 = type { i32, [0 x i64] }
%sollang.enum.t544 = type { i32, [2 x i64] }
%sollang.enum.t545 = type { i32, [7 x i64] }
%sollang.enum.t546 = type { i32, [0 x i64] }
%sollang.enum.t547 = type { i32, [2 x i64] }
%sollang.enum.t548 = type { i32, [0 x i64] }
%sollang.enum.t549 = type { i32, [0 x i64] }
%sollang.enum.t550 = type { i32, [0 x i64] }
%sollang.enum.t551 = type { i32, [0 x i64] }
%sollang.enum.t552 = type { i32, [2 x i64] }
%sollang.enum.t553 = type { i32, [8 x i64] }
%sollang.enum.t554 = type { i32, [0 x i64] }
%sollang.enum.t555 = type { i32, [0 x i64] }
%sollang.enum.t556 = type { i32, [7 x i64] }
%sollang.enum.t557 = type { i32, [0 x i64] }
%sollang.enum.t558 = type { i32, [0 x i64] }
%sollang.enum.t559 = type { i32, [0 x i64] }
%sollang.enum.t560 = type { i32, [0 x i64] }
%sollang.enum.t561 = type { i32, [0 x i64] }
%sollang.enum.t562 = type { i32, [0 x i64] }
%sollang.enum.t563 = type { i32, [0 x i64] }
%sollang.enum.t564 = type { i32, [1 x i64] }
%sollang.enum.t565 = type { i32, [0 x i64] }
%sollang.enum.t566 = type { i32, [0 x i64] }
%sollang.enum.t567 = type { i32, [16 x i64] }
%sollang.enum.t568 = type { i32, [16 x i64] }
%sollang.enum.t569 = type { i32, [0 x i64] }
%sollang.enum.t570 = type { i32, [0 x i64] }
%sollang.enum.t571 = type { i32, [0 x i64] }
%sollang.enum.t572 = type { i32, [0 x i64] }
%sollang.enum.t573 = type { i32, [0 x i64] }
%sollang.enum.t574 = type { i32, [0 x i64] }
%sollang.enum.t575 = type { i32, [0 x i64] }
%sollang.enum.t576 = type { i32, [0 x i64] }
%sollang.enum.t577 = type { i32, [0 x i64] }
%sollang.enum.t578 = type { i32, [0 x i64] }
%sollang.enum.t579 = type { i32, [0 x i64] }
%sollang.enum.t580 = type { i32, [0 x i64] }
%sollang.enum.t581 = type { i32, [0 x i64] }
%sollang.enum.t582 = type { i32, [0 x i64] }
%sollang.enum.t583 = type { i32, [0 x i64] }
%sollang.enum.t584 = type { i32, [3 x i64] }
%sollang.enum.t585 = type { i32, [1 x i64] }
%sollang.enum.t586 = type { i32, [12 x i64] }
%sollang.enum.t587 = type { i32, [0 x i64] }
%sollang.enum.t588 = type { i32, [0 x i64] }
%sollang.enum.t589 = type { i32, [0 x i64] }
%sollang.enum.t590 = type { i32, [0 x i64] }
%sollang.enum.t591 = type { i32, [0 x i64] }
%sollang.enum.t592 = type { i32, [4 x i64] }
%sollang.enum.t593 = type { i32, [3 x i64] }
%sollang.enum.t594 = type { i32, [0 x i64] }
%sollang.enum.t595 = type { i32, [2 x i64] }
%sollang.enum.t596 = type { i32, [0 x i64] }
%sollang.enum.t597 = type { i32, [0 x i64] }
%sollang.enum.t598 = type { i32, [0 x i64] }
%sollang.enum.t599 = type { i32, [0 x i64] }
%sollang.enum.t600 = type { i32, [2 x i64] }
%sollang.enum.t601 = type { i32, [2 x i64] }
%sollang.enum.t602 = type { i32, [1 x i64] }
%sollang.enum.t647 = type { i32, [1 x i64] }
%sollang.enum.t654 = type { i32, [1 x i64] }
%sollang.enum.t657 = type { i32, [1 x i64] }
%sollang.enum.t670 = type { i32, [3 x i64] }
%sollang.enum.t671 = type { i32, [44 x i64] }
%sollang.enum.t672 = type { i32, [2 x i64] }
%sollang.enum.t673 = type { i32, [13 x i64] }
%sollang.enum.t674 = type { i32, [2 x i64] }
%sollang.enum.t677 = type { i32, [1 x i64] }
%sollang.enum.t678 = type { i32, [7 x i64] }
%sollang.enum.t679 = type { i32, [1 x i64] }
%sollang.enum.t682 = type { i32, [3 x i64] }
%sollang.enum.t685 = type { i32, [1 x i64] }
%sollang.enum.t686 = type { i32, [3 x i64] }
%sollang.enum.t687 = type { i32, [4 x i64] }
%sollang.enum.t688 = type { i32, [105 x i64] }
%sollang.enum.t689 = type { i32, [2 x i64] }
%sollang.enum.t690 = type { i32, [9 x i64] }
%sollang.enum.t691 = type { i32, [26 x i64] }
%sollang.enum.t692 = type { i32, [81 x i64] }
%sollang.enum.t693 = type { i32, [2 x i64] }
%sollang.enum.t696 = type { i32, [3 x i64] }
%sollang.enum.t698 = type { i32, [26 x i64] }
%sollang.enum.t699 = type { i32, [4 x i64] }
%sollang.enum.t700 = type { i32, [2 x i64] }
%sollang.enum.t701 = type { i32, [2 x i64] }
%sollang.enum.t702 = type { i32, [2 x i64] }
%sollang.enum.t703 = type { i32, [50 x i64] }
%sollang.enum.t704 = type { i32, [2 x i64] }
%sollang.enum.t705 = type { i32, [3 x i64] }
%sollang.enum.t706 = type { i32, [2 x i64] }
%sollang.enum.t707 = type { i32, [2 x i64] }
%sollang.enum.t709 = type { i32, [2 x i64] }
%sollang.enum.t710 = type { i32, [2 x i64] }
%sollang.enum.t715 = type { i32, [9 x i64] }
%sollang.enum.t716 = type { i32, [24 x i64] }
%sollang.enum.t717 = type { i32, [2 x i64] }
%sollang.enum.t718 = type { i32, [12 x i64] }
%sollang.enum.t719 = type { i32, [11 x i64] }
%sollang.enum.t720 = type { i32, [2 x i64] }
%sollang.enum.t721 = type { i32, [32 x i64] }
%sollang.enum.t722 = type { i32, [34 x i64] }
%sollang.enum.t723 = type { i32, [2 x i64] }
%sollang.enum.t724 = type { i32, [9 x i64] }
%sollang.enum.t725 = type { i32, [31 x i64] }
%sollang.enum.t726 = type { i32, [2 x i64] }
%sollang.enum.t727 = type { i32, [15 x i64] }
%sollang.enum.t728 = type { i32, [34 x i64] }
%sollang.enum.t729 = type { i32, [2 x i64] }
%sollang.enum.t730 = type { i32, [2 x i64] }
%sollang.enum.t731 = type { i32, [6 x i64] }
%sollang.enum.t732 = type { i32, [2 x i64] }
%sollang.enum.t733 = type { i32, [2 x i64] }
%sollang.enum.t734 = type { i32, [2 x i64] }
%sollang.enum.t736 = type { i32, [14 x i64] }
%sollang.enum.t737 = type { i32, [9 x i64] }
%sollang.enum.t738 = type { i32, [5 x i64] }
%sollang.enum.t739 = type { i32, [5 x i64] }
%sollang.enum.t740 = type { i32, [4 x i64] }
%sollang.enum.t741 = type { i32, [2 x i64] }
%sollang.enum.t743 = type { i32, [2 x i64] }
%sollang.enum.t744 = type { i32, [2 x i64] }
%sollang.enum.t745 = type { i32, [81 x i64] }
%sollang.enum.t746 = type { i32, [2 x i64] }
%sollang.enum.t747 = type { i32, [3 x i64] }
%sollang.enum.t748 = type { i32, [3 x i64] }
%sollang.enum.t749 = type { i32, [5 x i64] }
%sollang.enum.t750 = type { i32, [2 x i64] }
%sollang.enum.t751 = type { i32, [14 x i64] }
%sollang.enum.t752 = type { i32, [2 x i64] }
%sollang.enum.t753 = type { i32, [32 x i64] }
%sollang.enum.t754 = type { i32, [4 x i64] }
%sollang.enum.t755 = type { i32, [2 x i64] }
%sollang.enum.t757 = type { i32, [5 x i64] }
%sollang.enum.t758 = type { i32, [2 x i64] }
%sollang.enum.t759 = type { i32, [2 x i64] }
%sollang.enum.t760 = type { i32, [5 x i64] }
%sollang.enum.t761 = type { i32, [2 x i64] }
%sollang.enum.t762 = type { i32, [2 x i64] }
%sollang.enum.t763 = type { i32, [32 x i64] }
%sollang.enum.t764 = type { i32, [2 x i64] }
%sollang.enum.t765 = type { i32, [4 x i64] }
%sollang.enum.t768 = type { i32, [2 x i64] }
%sollang.enum.t769 = type { i32, [2 x i64] }
%sollang.enum.t770 = type { i32, [4 x i64] }
%sollang.enum.t771 = type { i32, [2 x i64] }
%sollang.enum.t772 = type { i32, [2 x i64] }
%sollang.enum.t773 = type { i32, [2 x i64] }
%sollang.enum.t774 = type { i32, [2 x i64] }
%sollang.enum.t775 = type { i32, [2 x i64] }
%sollang.enum.t776 = type { i32, [2 x i64] }
%sollang.enum.t777 = type { i32, [3 x i64] }
%sollang.enum.t778 = type { i32, [2 x i64] }
%sollang.enum.t780 = type { i32, [3 x i64] }
%sollang.enum.t781 = type { i32, [4 x i64] }
%sollang.enum.t782 = type { i32, [9 x i64] }
%sollang.enum.t783 = type { i32, [2 x i64] }
%sollang.enum.t784 = type { i32, [32 x i64] }
%sollang.enum.t785 = type { i32, [3 x i64] }
%sollang.enum.t787 = type { i32, [5 x i64] }
%sollang.enum.t788 = type { i32, [2 x i64] }
%sollang.enum.t789 = type { i32, [2 x i64] }
%sollang.enum.t790 = type { i32, [4 x i64] }
%sollang.enum.t791 = type { i32, [4 x i64] }
%sollang.enum.t792 = type { i32, [72 x i64] }
%sollang.enum.t793 = type { i32, [2 x i64] }
%sollang.enum.t794 = type { i32, [2 x i64] }
%sollang.enum.t795 = type { i32, [2 x i64] }
%sollang.enum.t796 = type { i32, [13 x i64] }
%sollang.enum.t797 = type { i32, [26 x i64] }
%sollang.enum.t798 = type { i32, [5 x i64] }
%sollang.enum.t799 = type { i32, [2 x i64] }
%sollang.enum.t802 = type { i32, [2 x i64] }
%sollang.enum.t803 = type { i32, [72 x i64] }
%sollang.enum.t804 = type { i32, [3 x i64] }
%sollang.enum.t805 = type { i32, [3 x i64] }
%sollang.enum.t806 = type { i32, [13 x i64] }
%sollang.enum.t807 = type { i32, [70 x i64] }
%sollang.enum.t808 = type { i32, [2 x i64] }
%sollang.enum.t809 = type { i32, [40 x i64] }
%sollang.enum.t813 = type { i32, [3 x i64] }
%sollang.enum.t814 = type { i32, [10 x i64] }
%sollang.enum.t815 = type { i32, [11 x i64] }
%sollang.enum.t816 = type { i32, [2 x i64] }
%sollang.enum.t817 = type { i32, [1 x i64] }
%sollang.enum.t818 = type { i32, [5 x i64] }
%sollang.enum.t819 = type { i32, [3 x i64] }
%sollang.enum.t820 = type { i32, [3 x i64] }
%sollang.enum.t821 = type { i32, [10 x i64] }
%sollang.enum.t822 = type { i32, [33 x i64] }
%sollang.enum.t823 = type { i32, [35 x i64] }
%sollang.enum.t824 = type { i32, [1 x i64] }
%sollang.enum.t831 = type { i32, [8 x i64] }
%sollang.enum.t832 = type { i32, [1 x i64] }
%sollang.enum.t833 = type { i32, [2 x i64] }
%sollang.enum.t834 = type { i32, [2 x i64] }
%sollang.enum.t835 = type { i32, [2 x i64] }
%sollang.enum.t839 = type { i32, [3 x i64] }
%sollang.enum.t842 = type { i32, [2 x i64] }
%sollang.enum.t843 = type { i32, [2 x i64] }
%sollang.enum.t844 = type { i32, [2 x i64] }
%sollang.enum.t845 = type { i32, [5 x i64] }
%sollang.enum.t846 = type { i32, [11 x i64] }
%sollang.enum.t847 = type { i32, [9 x i64] }
%sollang.enum.t849 = type { i32, [3 x i64] }
%sollang.enum.t850 = type { i32, [2 x i64] }
%sollang.enum.t851 = type { i32, [2 x i64] }
%sollang.enum.t852 = type { i32, [2 x i64] }
%sollang.enum.t853 = type { i32, [2 x i64] }
%sollang.enum.t854 = type { i32, [2 x i64] }
%sollang.enum.t855 = type { i32, [2 x i64] }
%sollang.enum.t856 = type { i32, [2 x i64] }
%sollang.enum.t857 = type { i32, [2 x i64] }
%sollang.enum.t858 = type { i32, [3 x i64] }
%sollang.enum.t859 = type { i32, [4 x i64] }
%sollang.enum.t860 = type { i32, [2 x i64] }
%sollang.enum.t861 = type { i32, [3 x i64] }
%sollang.enum.t866 = type { i32, [1 x i64] }
%sollang.enum.t867 = type { i32, [4 x i64] }
%sollang.enum.t868 = type { i32, [4 x i64] }
%sollang.enum.t869 = type { i32, [2 x i64] }
%sollang.enum.t870 = type { i32, [8 x i64] }
%sollang.enum.t871 = type { i32, [2 x i64] }
%sollang.enum.t872 = type { i32, [4 x i64] }
%sollang.enum.t873 = type { i32, [2 x i64] }
%sollang.enum.t874 = type { i32, [2 x i64] }
%sollang.enum.t876 = type { i32, [3 x i64] }
%sollang.enum.t877 = type { i32, [5 x i64] }
%sollang.enum.t878 = type { i32, [10 x i64] }
%sollang.enum.t879 = type { i32, [10 x i64] }
%sollang.enum.t880 = type { i32, [11 x i64] }
%sollang.enum.t881 = type { i32, [11 x i64] }
%sollang.enum.t884 = type { i32, [7 x i64] }
%sollang.enum.t885 = type { i32, [8 x i64] }
%sollang.enum.t886 = type { i32, [7 x i64] }
%sollang.enum.t887 = type { i32, [8 x i64] }
%sollang.enum.t888 = type { i32, [2 x i64] }
%sollang.enum.t889 = type { i32, [7 x i64] }
%sollang.enum.t890 = type { i32, [7 x i64] }
%sollang.enum.t891 = type { i32, [3 x i64] }
%sollang.enum.t893 = type { i32, [2 x i64] }
%sollang.enum.t894 = type { i32, [3 x i64] }
%sollang.enum.t895 = type { i32, [2 x i64] }
%sollang.enum.t896 = type { i32, [2 x i64] }
%sollang.enum.t898 = type { i32, [2 x i64] }
%sollang.enum.t899 = type { i32, [4 x i64] }
%sollang.enum.t901 = type { i32, [3 x i64] }
%sollang.enum.t902 = type { i32, [3 x i64] }
%sollang.enum.t903 = type { i32, [13 x i64] }
%sollang.enum.t904 = type { i32, [12 x i64] }
%sollang.enum.t905 = type { i32, [4 x i64] }
%sollang.enum.t906 = type { i32, [2 x i64] }
%sollang.enum.t907 = type { i32, [2 x i64] }
%sollang.enum.t909 = type { i32, [2 x i64] }
%sollang.enum.t910 = type { i32, [5 x i64] }
%sollang.enum.t911 = type { i32, [3 x i64] }
%sollang.enum.t912 = type { i32, [15 x i64] }
%sollang.enum.t913 = type { i32, [3 x i64] }
%sollang.enum.t914 = type { i32, [2 x i64] }
%sollang.enum.t915 = type { i32, [3 x i64] }
%sollang.enum.t920 = type { i32, [2 x i64] }
%sollang.enum.t921 = type { i32, [3 x i64] }
%sollang.enum.t922 = type { i32, [3 x i64] }
%sollang.enum.t923 = type { i32, [15 x i64] }
%sollang.enum.t924 = type { i32, [25 x i64] }
%sollang.enum.t925 = type { i32, [7 x i64] }
%sollang.enum.t926 = type { i32, [5 x i64] }
%sollang.enum.t927 = type { i32, [9 x i64] }
%sollang.enum.t928 = type { i32, [31 x i64] }
%sollang.enum.t929 = type { i32, [3 x i64] }
%sollang.enum.t930 = type { i32, [8 x i64] }
%sollang.enum.t931 = type { i32, [2 x i64] }
%sollang.enum.t932 = type { i32, [12 x i64] }
%sollang.enum.t933 = type { i32, [6 x i64] }
%sollang.enum.t934 = type { i32, [2 x i64] }
%sollang.enum.t935 = type { i32, [9 x i64] }
%sollang.enum.t936 = type { i32, [6 x i64] }
%sollang.enum.t937 = type { i32, [3 x i64] }
%sollang.enum.t938 = type { i32, [26 x i64] }
%sollang.enum.t939 = type { i32, [4 x i64] }
%sollang.enum.t940 = type { i32, [5 x i64] }
%sollang.enum.t941 = type { i32, [8 x i64] }
%sollang.enum.t942 = type { i32, [40 x i64] }
%sollang.enum.t943 = type { i32, [9 x i64] }
%sollang.enum.t944 = type { i32, [3 x i64] }
%sollang.enum.t955 = type { i32, [2 x i64] }
%sollang.enum.t956 = type { i32, [2 x i64] }
%sollang.enum.t957 = type { i32, [9 x i64] }
%sollang.enum.t958 = type { i32, [21 x i64] }
%sollang.enum.t959 = type { i32, [4 x i64] }
%sollang.enum.t960 = type { i32, [9 x i64] }
%sollang.enum.t961 = type { i32, [2 x i64] }
%sollang.enum.t962 = type { i32, [5 x i64] }
%sollang.enum.t963 = type { i32, [2 x i64] }
%sollang.enum.t964 = type { i32, [14 x i64] }
%sollang.enum.t966 = type { i32, [11 x i64] }
%sollang.enum.t967 = type { i32, [16 x i64] }
%sollang.enum.t968 = type { i32, [7 x i64] }
%sollang.enum.t971 = type { i32, [7 x i64] }
%sollang.enum.t972 = type { i32, [4 x i64] }
%sollang.enum.t973 = type { i32, [6 x i64] }
%sollang.enum.t974 = type { i32, [7 x i64] }
%sollang.enum.t975 = type { i32, [6 x i64] }
%sollang.enum.t976 = type { i32, [5 x i64] }
%sollang.enum.t977 = type { i32, [2 x i64] }
%sollang.enum.t978 = type { i32, [4 x i64] }
%sollang.enum.t979 = type { i32, [10 x i64] }
%sollang.enum.t980 = type { i32, [131 x i64] }
%sollang.enum.t981 = type { i32, [2 x i64] }
%sollang.enum.t982 = type { i32, [16 x i64] }
%sollang.enum.t983 = type { i32, [7 x i64] }
%sollang.enum.t984 = type { i32, [10 x i64] }
%sollang.enum.t986 = type { i32, [5 x i64] }
%sollang.enum.t988 = type { i32, [2 x i64] }
%sollang.enum.t989 = type { i32, [17 x i64] }
%sollang.enum.t990 = type { i32, [2 x i64] }
%sollang.enum.t991 = type { i32, [2 x i64] }
%sollang.enum.t992 = type { i32, [3 x i64] }
%sollang.enum.t994 = type { i32, [10 x i64] }
%sollang.enum.t995 = type { i32, [5 x i64] }
%sollang.enum.t996 = type { i32, [3 x i64] }
%sollang.enum.t997 = type { i32, [8 x i64] }
%sollang.enum.t999 = type { i32, [2 x i64] }
%sollang.enum.t1000 = type { i32, [4 x i64] }
%sollang.enum.t1002 = type { i32, [2 x i64] }
%sollang.enum.t1003 = type { i32, [9 x i64] }
%sollang.enum.t1004 = type { i32, [3 x i64] }
%sollang.enum.t1005 = type { i32, [7 x i64] }
%sollang.enum.t1006 = type { i32, [11 x i64] }
%sollang.enum.t1007 = type { i32, [7 x i64] }
%sollang.enum.t1011 = type { i32, [6 x i64] }
%sollang.enum.t1013 = type { i32, [11 x i64] }
%sollang.enum.t1014 = type { i32, [18 x i64] }
%sollang.enum.t1016 = type { i32, [149 x i64] }
%sollang.enum.t1017 = type { i32, [3 x i64] }
%sollang.enum.t1018 = type { i32, [2 x i64] }
%sollang.enum.t1019 = type { i32, [2 x i64] }
%sollang.enum.t1020 = type { i32, [2 x i64] }
%sollang.enum.t1022 = type { i32, [12 x i64] }
%sollang.enum.t1023 = type { i32, [9 x i64] }
%sollang.enum.t1024 = type { i32, [5 x i64] }
%sollang.enum.t1025 = type { i32, [5 x i64] }
%sollang.enum.t1026 = type { i32, [6 x i64] }
%sollang.enum.t1027 = type { i32, [6 x i64] }
%sollang.enum.t1028 = type { i32, [2 x i64] }
%sollang.enum.t1030 = type { i32, [14 x i64] }
%sollang.enum.t1033 = type { i32, [6 x i64] }
%sollang.enum.t1034 = type { i32, [6 x i64] }
%sollang.enum.t1036 = type { i32, [4 x i64] }
%sollang.enum.t1037 = type { i32, [5 x i64] }
%sollang.enum.t1038 = type { i32, [4 x i64] }
%sollang.enum.t1039 = type { i32, [21 x i64] }
%sollang.enum.t1040 = type { i32, [4 x i64] }
%sollang.enum.t1041 = type { i32, [5 x i64] }
%sollang.enum.t1042 = type { i32, [2 x i64] }
%sollang.enum.t1044 = type { i32, [3 x i64] }
%sollang.enum.t1045 = type { i32, [4 x i64] }
%sollang.enum.t1046 = type { i32, [2 x i64] }
%sollang.enum.t1047 = type { i32, [6 x i64] }
%sollang.enum.t1048 = type { i32, [5 x i64] }
%sollang.enum.t1049 = type { i32, [5 x i64] }
%sollang.enum.t1052 = type { i32, [16 x i64] }
%sollang.enum.t1053 = type { i32, [7 x i64] }
%sollang.enum.t1054 = type { i32, [6 x i64] }
%sollang.enum.t1055 = type { i32, [4 x i64] }
%sollang.enum.t1056 = type { i32, [5 x i64] }
%sollang.enum.t1057 = type { i32, [2 x i64] }
%sollang.enum.t1058 = type { i32, [2 x i64] }
%sollang.enum.t1060 = type { i32, [4 x i64] }
%sollang.enum.t1062 = type { i32, [9 x i64] }
%sollang.enum.t1063 = type { i32, [4 x i64] }
%sollang.enum.t1067 = type { i32, [1 x i64] }
%sollang.enum.t1068 = type { i32, [2 x i64] }
%sollang.enum.t1069 = type { i32, [3 x i64] }
%sollang.enum.t1070 = type { i32, [17 x i64] }
%sollang.enum.t1072 = type { i32, [2 x i64] }
%sollang.enum.t1073 = type { i32, [3 x i64] }
%sollang.enum.t1074 = type { i32, [12 x i64] }
%sollang.enum.t1075 = type { i32, [3 x i64] }
%sollang.enum.t1076 = type { i32, [4 x i64] }
%sollang.enum.t1090 = type { i32, [12 x i64] }
%sollang.enum.t1091 = type { i32, [4 x i64] }
%sollang.enum.t1092 = type { i32, [3 x i64] }
%sollang.enum.t1093 = type { i32, [3 x i64] }
%sollang.enum.t1094 = type { i32, [4 x i64] }
%sollang.enum.t1095 = type { i32, [2 x i64] }
%sollang.enum.t1097 = type { i32, [3 x i64] }
%sollang.enum.t1098 = type { i32, [6 x i64] }
%sollang.enum.t1099 = type { i32, [3 x i64] }
%sollang.enum.t1102 = type { i32, [2 x i64] }
%sollang.enum.t1103 = type { i32, [2 x i64] }
%sollang.enum.t1104 = type { i32, [2 x i64] }
%sollang.enum.t1105 = type { i32, [2 x i64] }
%sollang.enum.t1106 = type { i32, [2 x i64] }
%sollang.enum.t1107 = type { i32, [12 x i64] }
%sollang.enum.t1108 = type { i32, [6 x i64] }
%sollang.enum.t1109 = type { i32, [3 x i64] }
%sollang.enum.t1110 = type { i32, [2 x i64] }
%sollang.enum.t1111 = type { i32, [8 x i64] }
%sollang.enum.t1113 = type { i32, [2 x i64] }
%sollang.enum.t1114 = type { i32, [4 x i64] }
%sollang.enum.t1117 = type { i32, [3 x i64] }
%sollang.enum.t1118 = type { i32, [4 x i64] }
%sollang.enum.t1119 = type { i32, [4 x i64] }
%sollang.enum.t1120 = type { i32, [7 x i64] }
%sollang.enum.t1121 = type { i32, [4 x i64] }
%sollang.enum.t1123 = type { i32, [9 x i64] }
%sollang.enum.t1124 = type { i32, [2 x i64] }
%sollang.enum.t1125 = type { i32, [4 x i64] }
%sollang.enum.t1126 = type { i32, [1 x i64] }
%sollang.enum.t1127 = type { i32, [1 x i64] }
%sollang.enum.t1128 = type { i32, [2 x i64] }
%sollang.enum.t1129 = type { i32, [2 x i64] }
%sollang.enum.t1130 = type { i32, [2 x i64] }
%sollang.enum.t1131 = type { i32, [6 x i64] }
%sollang.enum.t1132 = type { i32, [1 x i64] }
%sollang.enum.t1133 = type { i32, [1 x i64] }
%sollang.enum.t1134 = type { i32, [1 x i64] }
%sollang.enum.t1135 = type { i32, [1 x i64] }
%sollang.enum.t1136 = type { i32, [11 x i64] }
%sollang.enum.t1137 = type { i32, [29 x i64] }
%sollang.enum.t1138 = type { i32, [12 x i64] }
%sollang.enum.t1139 = type { i32, [2 x i64] }
%sollang.enum.t1140 = type { i32, [2 x i64] }
%sollang.enum.t1142 = type { i32, [3 x i64] }
%sollang.enum.t1143 = type { i32, [2 x i64] }
%sollang.enum.t1144 = type { i32, [3 x i64] }
%sollang.enum.t1145 = type { i32, [2 x i64] }
%sollang.enum.t1146 = type { i32, [1 x i64] }
%sollang.enum.t1147 = type { i32, [1 x i64] }
%sollang.enum.t1154 = type { i32, [2 x i64] }
%sollang.enum.t1155 = type { i32, [2 x i64] }
%sollang.enum.t1156 = type { i32, [2 x i64] }
%sollang.enum.t1157 = type { i32, [0 x i64] }
%sollang.enum.t1158 = type { i32, [0 x i64] }
%sollang.enum.t1159 = type { i32, [2 x i64] }
%sollang.enum.t1160 = type { i32, [2 x i64] }
%sollang.enum.t1161 = type { i32, [2 x i64] }
%sollang.enum.t1162 = type { i32, [7 x i64] }
%sollang.enum.t1163 = type { i32, [4 x i64] }
%sollang.enum.t1164 = type { i32, [2 x i64] }
%sollang.enum.t1167 = type { i32, [2 x i64] }
%sollang.enum.t1169 = type { i32, [3 x i64] }
%sollang.enum.t1180 = type { i32, [0 x i64] }
%sollang.enum.t1181 = type { i32, [3 x i64] }
%sollang.enum.t1182 = type { i32, [6 x i64] }
%sollang.enum.t1183 = type { i32, [2 x i64] }
%sollang.enum.t1184 = type { i32, [3 x i64] }
%sollang.enum.t1185 = type { i32, [8 x i64] }
%sollang.enum.t1186 = type { i32, [2 x i64] }
%sollang.enum.t1187 = type { i32, [1 x i64] }
%sollang.enum.t1188 = type { i32, [2 x i64] }
%sollang.enum.t1189 = type { i32, [3 x i64] }
%sollang.enum.t1190 = type { i32, [2 x i64] }
%sollang.enum.t1192 = type { i32, [2 x i64] }
%sollang.enum.t1193 = type { i32, [4 x i64] }
%sollang.enum.t1194 = type { i32, [3 x i64] }
%sollang.enum.t1195 = type { i32, [18 x i64] }
%sollang.enum.t1196 = type { i32, [3 x i64] }
%sollang.enum.t1197 = type { i32, [16 x i64] }
%sollang.enum.t1198 = type { i32, [2 x i64] }
%sollang.enum.t1199 = type { i32, [2 x i64] }
%sollang.enum.t1200 = type { i32, [2 x i64] }
%sollang.enum.t1202 = type { i32, [1 x i64] }
%sollang.enum.t1203 = type { i32, [2 x i64] }
%sollang.enum.t1204 = type { i32, [2 x i64] }
%sollang.enum.t1205 = type { i32, [5 x i64] }
%sollang.enum.t1206 = type { i32, [2 x i64] }
%sollang.enum.t1209 = type { i32, [9 x i64] }
%sollang.enum.t1210 = type { i32, [7 x i64] }
%sollang.enum.t1211 = type { i32, [3 x i64] }
%sollang.enum.t1212 = type { i32, [2 x i64] }
%sollang.struct.x0D7374642E616C676F726974686D010301084F72646572696E6700 = type { %sollang.enum.t460 }
%sollang.struct.x0D7374642E616C676F726974686D0103010A416C676F726974686D7300 = type {  }
%sollang.struct.x0D7374642E616C676F726974686D0103010C536561726368526573756C7400 = type { i32, i1 }
%sollang.struct.x0D7374642E616C676F726974686D0103010A457175616C52616E676500 = type { i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A6970010301054572726F7200 = type { %sollang.enum.t466, i64 }
%sollang.struct.x0F7374642E617263686976652E7A6970010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A697001030105436F64656300 = type { %sollang.struct.x0F7374642E617263686976652E7A6970010301064C696D69747300 }
%sollang.struct.x0F7374642E617263686976652E7A69700103010D4465666C6174654C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A6970010301074465636F64657200 = type { %sollang.struct.x0F7374642E617263686976652E7A6970010301064C696D69747300, %sollang.enum.t464, i32, %sollang.array.i32, %sollang.array.i32, i32, i32, i32, %sollang.array.i32, i32, i32, i32, i32, %sollang.array.i32, i1, %sollang.struct.x0F7374642E617263686976652E7A69700103010D4465666C6174654C696D69747300, i32, %sollang.struct.x0E7374642E686173682E63726333320103010648617368657200, %sollang.array.i32, %sollang.array.i32, i32, i32, i32, %sollang.array.i32, i32, i32, %sollang.array.i32, i32, i1, %sollang.struct.x0F7374642E617263686976652E7A6970010301054572726F7200 }
%sollang.struct.x0F7374642E617263686976652E7A69700103010C5772697465724C696D69747300 = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A69700103010657726974657200 = type { %sollang.struct.x0F7374642E617263686976652E7A69700103010C5772697465724C696D69747300, %sollang.enum.t465, i32, i32, i32, i32, i32, i32, %sollang.struct.x0E7374642E686173682E63726333320103010648617368657200, %sollang.array.i32 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030110446961676E6F737469634C696D69747300 = type { i32 }
%sollang.struct.x157374642E6173796E632E646961676E6F73746963730103011153757370656E73696F6E4C6F6361746F7200 = type { %sollang.text, %sollang.text, i32, i64, i32, i32 }
%sollang.struct.x157374642E6173796E632E646961676E6F73746963730103010C5461736B536E617073686F7400 = type { i64, %sollang.enum.t677, %sollang.enum.t467, %sollang.enum.t468, %sollang.enum.t677, i64, %sollang.enum.t678 }
%sollang.struct.x157374642E6173796E632E646961676E6F73746963730103010E536E617073686F74526573756C7400 = type { i64, i64, i64, i1 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030111446961676E6F7374696353756D6D61727900 = type { i64, i64, i64 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030111446961676E6F7374696353657373696F6E00 = type { i64 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030116446961676E6F73746963436C6F73654661696C75726500 = type { %sollang.struct.x157374642E6173796E632E646961676E6F737469637301030111446961676E6F7374696353657373696F6E00, %sollang.enum.t471 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301054572726F7200 = type { %sollang.enum.t498, i64 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C6901030105436F64656300 = type { %sollang.struct.x137374642E636F6D70726573732E62726F746C69010301064C696D69747300 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C6901030107456E636F64657200 = type { i32, i32, i32, i32, i32, i32, i1 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301074465636F64657200 = type { i32, i32, i32, i32, i32, i32, %sollang.enum.t497, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010657696E646F7700, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010652656164657200, i32, i1, i32, i32, i32, %sollang.array.i32, i1, %sollang.struct.x137374642E636F6D70726573732E62726F746C69010301054572726F7200 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C690103010942697457726974657200 = type { i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C690103010942697452656164657200 = type { i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C690103010C53747265616D437572736F7200 = type { i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301074269745265616400 = type { i1, i64 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301054572726F7200 = type { %sollang.enum.t475, i64 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301084578656375746F7200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273656400, i32, i32, i32, i32 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301074465636F64656400 = type { %sollang.array.i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E640103010652656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273656400, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301085265736F6C76657200, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32, i32, %sollang.enum.t472, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.t472 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E640103010853747265616D656400 = type { %sollang.array.i32 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301054572726F7200 = type { %sollang.enum.t488, i64 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301064C696D69747300 = type { i32, i32, i32, i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010650617273657200, %sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010650617273657200, i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D5072656C75646552656164657200 = type { %sollang.enum.t476, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.t499, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301075072656C75646500 = type { i32, i32, i32, i32, i32, %sollang.enum.t499, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F68656164657201030111426C6F636B53747265616D52656164657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, %sollang.enum.t479, i32, i32, i32, i32, %sollang.enum.t478, %sollang.enum.t478 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010C48656164657252656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F68656164657201030111426C6F636B53747265616D52656164657200, %sollang.enum.t481, i32, %sollang.array.i32, i32, i32, %sollang.array.i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D4865616465725072656C75646500 = type { %sollang.array.i32, i32, i32, i32, %sollang.array.i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D436F6E7465787452656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D4865616465725072656C75646500, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010652656164657200, %sollang.enum.t483, %sollang.array.i32, %sollang.array.i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010E436F6E746578745072656C75646500 = type { %sollang.array.i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010A5472656552656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010E436F6E746578745072656C75646500, %sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010652656164657200, %sollang.enum.t485, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010B426C6F636B53747265616D00 = type { i32, i32, %sollang.enum.t478, %sollang.enum.t478 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010B426C6F636B53776974636800 = type { i32, i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273656400 = type { %sollang.array.i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F68656164657201030111506172736564426C6F636B53747265616D00 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010B426C6F636B53747265616D00, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D010301054572726F7200 = type { %sollang.enum.t498, i64 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010C48656164657250726566697800 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010C48656164657252656164657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010D436F6E7465787450726566697800 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D436F6E7465787452656164657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010A5472656550726566697800 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010A5472656552656164657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010652656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D010301064C696D69747300, i32, %sollang.array.i32, %sollang.enum.t489 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D6170010301054572726F7200 = type { %sollang.enum.t496, i64 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D6170010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010650617273657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010650617273656400 = type { %sollang.array.i32, i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010652656164657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, i32, %sollang.enum.t492, i32, i32, i32, %sollang.array.i32, %sollang.enum.t493 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010853747265616D656400 = type { %sollang.array.i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D6170010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301054572726F7200 = type { %sollang.enum.t505, i64 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301064C696D69747300 = type { i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200 = type { %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074275696C64657200, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273656400 = type { %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301055461626C6500, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301154669786564436F64654C656E67746852656164657200 = type { %sollang.enum.t500, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 = type { %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074275696C64657200, i32, i32, i32, %sollang.enum.t502, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301154669786564436F64654C656E67746852656164657200, %sollang.array.i32, i32, i32, i32, %sollang.enum.t503, i32, i32, i32, i32, i32, i32, %sollang.enum.t503 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301054572726F7200 = type { %sollang.enum.t508, i64 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301064C696D69747300 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074275696C64657200 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301055461626C6500 = type { %sollang.array.i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074465636F64656400 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010650726F62656400 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010C57696E646F774C696D69747300 = type { i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010657696E646F7700 = type { i64, i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301065065656B656400 = type { i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301054572726F7200 = type { %sollang.enum.t510, i64 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301064C696D69747300 = type { i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301085265736F6C76657200 = type { i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E6172790103010A44657363726970746F7200 = type { i32, %sollang.enum.t509, i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F7570010301054572726F7200 = type { %sollang.enum.t512, i64 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F7570010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010650617273657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010650617273656400 = type { %sollang.array.i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010652656164657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.array.i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010853747265616D656400 = type { %sollang.array.i32 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301054572726F7200 = type { %sollang.enum.t514, i64 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301064C696D69747300 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030105436F64656300 = type { %sollang.struct.x117374642E636F6D70726573732E677A6970010301064C696D69747300 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010D4465636F6465724C696D69747300 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030107456E636F64657200 = type { i32, i32, i32, i32, i1, i1, %sollang.struct.x117374642E636F6D70726573732E677A69700103010942697457726974657200 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301074465636F64657200 = type { %sollang.struct.x117374642E636F6D70726573732E677A697001030105436F64656300, i32, i32, i32, i32, i32, i32, %sollang.enum.t513, i32, i32, i32, i32, i32, i32, i32, i1, i32, i32, i32, i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, i32, i32, i32, i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, i32, i1, %sollang.struct.x117374642E636F6D70726573732E677A6970010301054572726F7200, i1, i1 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301115261774465666C6174654465636F64657200 = type { %sollang.struct.x117374642E636F6D70726573732E677A6970010301074465636F64657200 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A456E636F6465506C616E00 = type { i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A4465636F6465506C616E00 = type { i32, i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030109426974437572736F7200 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010942697457726974657200 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010B4465666C617465436F646500 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A4C656E677468436F646500 = type { i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C44697374616E6365436F646500 = type { i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301054D6174636800 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00 = type { %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010B487566666D616E5061697200 = type { %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C496E666C617465537461746500 = type { %sollang.struct.x117374642E636F6D70726573732E677A697001030109426974437572736F7200, i32, %sollang.array.i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C4D656D6265724465636F646500 = type { i32, %sollang.array.i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C496E666C617465436F756E7400 = type { i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C53747265616D437572736F7200 = type { i32 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301074269745265616400 = type { i1, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A55496E7433325265616400 = type { i1, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A53796D626F6C5265616400 = type { i1, i32 }
%sollang.struct.x117374642E636F6D70726573732E7A737464010301054572726F7200 = type { %sollang.enum.t516, i64 }
%sollang.struct.x117374642E636F6D70726573732E7A7374640103010F436F6D70726573736564426C6F636B00 = type { %sollang.array.i32, %sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500, i1, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E7A737464010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E7A7374640103010C4672616D654F7074696F6E7300 = type { i1 }
%sollang.struct.x117374642E636F6D70726573732E7A73746401030105436F64656300 = type { %sollang.struct.x117374642E636F6D70726573732E7A737464010301064C696D69747300, %sollang.struct.x117374642E636F6D70726573732E7A7374640103010C4672616D654F7074696F6E7300 }
%sollang.struct.x117374642E636F6D70726573732E7A73746401030107456E636F64657200 = type { i32, i32, i32, i32, i1, i1, %sollang.struct.x117374642E686173682E78786861736836340103010648617368657200 }
%sollang.struct.x117374642E636F6D70726573732E7A737464010301074465636F64657200 = type { i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.t515, i64, i32, i32, i32, i32, i32, i1, i64, i1, %sollang.struct.x117374642E686173682E78786861736836340103010648617368657200, i32, i32, i32, i32, i1, %sollang.array.i32, %sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500, i1, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32, %sollang.array.i32, i1, %sollang.struct.x117374642E636F6D70726573732E7A737464010301054572726F7200 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500 = type { %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E6673650103010B4465736372697074696F6E00 = type { %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i32 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E6673650103010B466F72776172644269747300 = type { i32 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E6673650103010B526576657273654269747300 = type { i32, i32, i32 }
%sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500 = type { %sollang.array.i32, i32 }
%sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E0103010B4465736372697074696F6E00 = type { %sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E636501030106437572736F7200 = type { i32, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E636501030108507265706172656400 = type { %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E63650103010D526563656E744F66667365747300 = type { i32, i32, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E6365010301074465636F64656400 = type { %sollang.array.i32, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32 }
%sollang.struct.x117374642E63727970746F2E616573313238010301034B657900 = type { %sollang.array.i32 }
%sollang.struct.x117374642E63727970746F2E6165733132380103010A426C6F636B56616C756500 = type { %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E6165733132385F67636D010301065365616C656400 = type { %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E6165733132385F67636D010301034B657900 = type { %sollang.struct.x117374642E63727970746F2E616573313238010301034B657900, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E6165733132385F67636D0103010A426C6F636B56616C756500 = type { %sollang.int_slice }
%sollang.struct.x127374642E63727970746F2E65643235353139010301054572726F7200 = type { %sollang.enum.t522 }
%sollang.struct.x127374642E63727970746F2E6564323535313901030105506F696E7400 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x167374642E63727970746F2E686D61635F7368613235360103010648617368657200 = type { %sollang.struct.x117374642E63727970746F2E7368613235360103010648617368657200, %sollang.struct.x117374642E63727970746F2E7368613235360103010648617368657200 }
%sollang.struct.x117374642E63727970746F2E72616E646F6D0103010C53656375726552616E646F6D00 = type { i8 }
%sollang.struct.x117374642E63727970746F2E7368613235360103010648617368657200 = type { %sollang.int_slice, %sollang.int_slice, i32, i64 }
%sollang.struct.x157374642E63727970746F2E746C7331335F6B6579730103011048616E647368616B655365637265747300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E746C7331335F6B6579730103010C4561726C795365637265747300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E746C7331335F6B657973010301124170706C69636174696F6E5365637265747300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x137374642E656E636F64696E672E626173653634010301054572726F7200 = type { %sollang.enum.t524, i64 }
%sollang.struct.x137374642E656E636F64696E672E6261736536340103010A456E636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x137374642E656E636F64696E672E6261736536340103010A4465636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x137374642E656E636F64696E672E62617365363401030105436F64656300 = type { %sollang.enum.t525, %sollang.enum.t526 }
%sollang.struct.x137374642E656E636F64696E672E62617365363401030107456E636F64657200 = type { %sollang.struct.x137374642E656E636F64696E672E62617365363401030105436F64656300, i32, i32, i64, i8, i8, i32 }
%sollang.struct.x137374642E656E636F64696E672E626173653634010301074465636F64657200 = type { %sollang.struct.x137374642E656E636F64696E672E62617365363401030105436F64656300, i32, i32, i64, i32, i32, i32, i32, i64, i64, i64, i64, i32, i1 }
%sollang.struct.x137374642E656E636F64696E672E6261736536340103010F4465636F64655772697465506C616E00 = type { i32, i32, i64, i32, i32, i32, i32, i64, i64, i64, i64, i32, i1 }
%sollang.struct.x137374642E656E636F64696E672E62696E617279010301054572726F7200 = type { %sollang.enum.t528, i64 }
%sollang.struct.x137374642E656E636F64696E672E62696E6172790103010652656164657200 = type { %sollang.enum.t527, i64 }
%sollang.struct.x137374642E656E636F64696E672E62696E6172790103010657726974657200 = type { %sollang.enum.t527, i32, i32 }
%sollang.struct.x107374642E656E636F64696E672E686578010301054572726F7200 = type { %sollang.enum.t529, i64 }
%sollang.struct.x107374642E656E636F64696E672E6865780103010A456E636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x107374642E656E636F64696E672E6865780103010A4465636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x107374642E656E636F64696E672E68657801030105436F64656300 = type { i1 }
%sollang.struct.x107374642E656E636F64696E672E68657801030107456E636F64657200 = type { %sollang.struct.x107374642E656E636F64696E672E68657801030105436F64656300, i32, i32, i64 }
%sollang.struct.x107374642E656E636F64696E672E686578010301074465636F64657200 = type { i32, i32, i64, i32, i64 }
%sollang.struct.x0E7374642E686173682E63726333320103010648617368657200 = type { %sollang.enum.t530, i32 }
%sollang.struct.x117374642E686173682E7878686173683634010301045365656400 = type { i64 }
%sollang.struct.x117374642E686173682E78786861736836340103010648617368657200 = type { i64, i64, i64, i64, i64, i64, i64, %sollang.int_slice, i32 }
%sollang.struct.x067374642E696F010301054572726F7200 = type { %sollang.enum.t531, i64 }
%sollang.struct.x067374642E696F0103010B436F70794F7574636F6D6500 = type { i32, %sollang.enum.t533 }
%sollang.struct.x067374642E696F0103010E5472616E73666572506F6C69637900 = type { i32, i32 }
%sollang.struct.x067374642E696F0103010C5265706C617942756666657200 = type { %sollang.array.i32, i32, %sollang.array.i32, i32, i32 }
%sollang.struct.x067374642E696F0103010C4D656D6F727952656164657200 = type { %sollang.array.i32, i32, i32 }
%sollang.struct.x067374642E696F0103010C4D656D6F727957726974657200 = type { %sollang.array.i32, i32 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C43616E63656C6C6174696F6E00 = type { i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010B526561645375636365737300 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727952656164657200, %sollang.array.i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010B526561644661696C75726500 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727952656164657200, %sollang.array.i32, %sollang.enum.t534 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C57726974655375636365737300 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727957726974657200, %sollang.array.i32, i32 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C57726974654661696C75726500 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727957726974657200, %sollang.array.i32, %sollang.enum.t534 }
%sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500 = type { %sollang.array.i32, i32, i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C4F666665725375636365737300 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C4F666665724661696C75726500 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, %sollang.enum.t534 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C447261696E5375636365737300 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C447261696E4661696C75726500 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, %sollang.enum.t534 }
%sollang.struct.x0B7374642E696F2E66696C650103010A4279746552656164657200 = type { %sollang.struct.x087379732E66696C650103010446696C6500, i64 }
%sollang.struct.x0B7374642E696F2E66696C650103010A4279746557726974657200 = type { %sollang.struct.x087379732E66696C650103010A46696C6557726974657200, i64 }
%sollang.struct.x0B7374642E696F2E66696C65010301104173796E63526561645375636365737300 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746552656164657200, %sollang.array.i32, i32, i1 }
%sollang.struct.x0B7374642E696F2E66696C65010301104173796E63526561644661696C75726500 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746552656164657200, %sollang.array.i32, %sollang.enum.t595 }
%sollang.struct.x0B7374642E696F2E66696C65010301114173796E6357726974655375636365737300 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746557726974657200, %sollang.array.i32, i32 }
%sollang.struct.x0B7374642E696F2E66696C65010301114173796E6357726974654661696C75726500 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746557726974657200, %sollang.array.i32, %sollang.enum.t595 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, i64 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010D4372656174654661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010B526561645375636365737300 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, i64, i1 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010B526561644661696C75726500 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010C57726974655375636365737300 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, i64 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010C57726974654661696C75726500 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x077374642E6C6F67010301054669656C6400 = type { %sollang.text, %sollang.text }
%sollang.struct.x077374642E6C6F67010301054572726F7200 = type { %sollang.text }
%sollang.struct.x077374642E6C6F67010301065265636F726400 = type { %sollang.enum.t535, %sollang.text }
%sollang.struct.x077374642E6C6F67010301064C6F6767657200 = type { %sollang.enum.t535 }
%sollang.struct.x077374642E6E65740103010B497076344164647265737300 = type { i8, i8, i8, i8 }
%sollang.struct.x077374642E6E65740103010C49707634456E64706F696E7400 = type { %sollang.struct.x077374642E6E65740103010B497076344164647265737300, i16 }
%sollang.struct.x077374642E6E65740103010B497076364164647265737300 = type { i16, i16, i16, i16, i16, i16, i16, i16 }
%sollang.struct.x077374642E6E65740103010C49707636456E64706F696E7400 = type { %sollang.struct.x077374642E6E65740103010B497076364164647265737300, i16, i32, i32 }
%sollang.struct.x077374642E6E65740103010A50617273654572726F7200 = type { %sollang.enum.t554, i64 }
%sollang.struct.x0B7374642E6E65742E646E73010301054572726F7200 = type { %sollang.enum.t539, i32 }
%sollang.struct.x0B7374642E6E65742E646E73010301085265736F6C76657200 = type { %sollang.enum.t538, i64, i64 }
%sollang.struct.x0C7374642E6E65742E68747470010301054572726F7200 = type { %sollang.enum.t546, i64 }
%sollang.struct.x0C7374642E6E65742E68747470010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x0C7374642E6E65742E68747470010301045370616E00 = type { i64, i64 }
%sollang.struct.x0C7374642E6E65742E68747470010301054669656C6400 = type { %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00 }
%sollang.struct.x0C7374642E6E65742E687474700103010650617273657200 = type { %sollang.struct.x0C7374642E6E65742E68747470010301064C696D69747300 }
%sollang.struct.x0C7374642E6E65742E687474700103010B526571756573744865616400 = type { %sollang.source_text, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.enum.t540, %sollang.array.i32, i64 }
%sollang.struct.x0C7374642E6E65742E687474700103010C526573706F6E73654865616400 = type { %sollang.source_text, %sollang.enum.t540, i32, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.array.i32, i64 }
%sollang.struct.x0C7374642E6E65742E687474700103010C5061727365644669656C647300 = type { %sollang.array.i32, i64 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900 = type { %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300 }
%sollang.struct.x117374642E6E65742E687474702E626F647901030113526573706F6E7365426F6479436F6E7465787400 = type { %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, %sollang.text }
%sollang.struct.x117374642E6E65742E687474702E626F647901030108426F6479506C616E00 = type { %sollang.enum.t541, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010C426F647950726F677265737300 = type { i64, i64, i1 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010B426F64794465636F64657200 = type { %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300, %sollang.enum.t542, %sollang.enum.t543, i64, i64, i64, i64, %sollang.array.i32, i1, i64, i32 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010D4865616465724672616D696E6700 = type { i1, i64, i1, i1 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E740103010D436C69656E744F7074696F6E7300 = type { %sollang.enum.t537, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E7401030106436C69656E7400 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E740103010845786368616E676500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32, %sollang.enum.t549, %sollang.enum.t548 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E7401030108526573706F6E736500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32, %sollang.enum.t549, %sollang.enum.t548, %sollang.array.i32, %sollang.struct.x0C7374642E6E65742E687474700103010C526573706F6E73654865616400, i64 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E740103010C526573706F6E7365426F647900 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32, %sollang.array.i32, i64, %sollang.array.i32, i64, %sollang.struct.x117374642E6E65742E687474702E626F64790103010B426F64794465636F64657200, i1, i1, i1 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010D526571756573744C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010D52657175657374506F6C69637900 = type { %sollang.struct.x147374642E6E65742E687474702E726571756573740103010D526571756573744C696D69747300 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010D5265717565737457726974657200 = type { %sollang.struct.x147374642E6E65742E687474702E726571756573740103010D526571756573744C696D69747300, %sollang.array.i32, %sollang.text, i32, i32, i1, i1, i1, i64, %sollang.enum.t548, %sollang.enum.t549 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010B526571756573744865616400 = type { %sollang.array.i32, i64, %sollang.enum.t548, %sollang.enum.t549 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E73654C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E7365506F6C69637900 = type { %sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E73654C696D69747300 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E736557726974657200 = type { %sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E73654C696D69747300, %sollang.array.i32, i32, i32, i1, i1, i1, i64, %sollang.enum.t551 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010C526573706F6E73654865616400 = type { %sollang.array.i32, i64, %sollang.enum.t551, %sollang.enum.t550 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010D5365727665724F7074696F6E7300 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4C697374656E4F7074696F6E7300, %sollang.struct.x0C7374642E6E65742E68747470010301064C696D69747300 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010653657276657200 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010B5463704C697374656E657200, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010A436F6E6E656374696F6E00 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32, %sollang.array.i32, i64 }
%sollang.struct.x137374642E6E65742E687474702E736572766572010301075265717565737400 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32, %sollang.array.i32, %sollang.struct.x0C7374642E6E65742E687474700103010B526571756573744865616400, i64, %sollang.array.i32, i64, i1 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010B52657175657374426F647900 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32, %sollang.array.i32, %sollang.struct.x0C7374642E6E65742E687474700103010B526571756573744865616400, i64, %sollang.array.i32, i64, %sollang.struct.x117374642E6E65742E687474702E626F64790103010B426F64794465636F64657200 }
%sollang.struct.x0C7374642E6E65742E7175696301030109517569634572726F7200 = type { %sollang.enum.t555, i64 }
%sollang.struct.x0C7374642E6E65742E71756963010301084964656E7469747900 = type { %sollang.int_slice }
%sollang.struct.x0C7374642E6E65742E7175696301030108456E64706F696E7400 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030109556470536F636B657400, %sollang.enum.t537, i1, %sollang.array.i32, %sollang.array.i32, i64 }
%sollang.struct.x0C7374642E6E65742E71756963010301125265636569766557696E646F7753697A657300 = type { i64, i64, i64, i64 }
%sollang.struct.x0C7374642E6E65742E7175696301030111436F6E6E656374696F6E4F7074696F6E7300 = type { i64, i64, i32, i32, i32, i64, %sollang.struct.x0C7374642E6E65742E71756963010301125265636569766557696E646F7753697A657300 }
%sollang.struct.x0C7374642E6E65742E71756963010301084C697374656E657200 = type { %sollang.struct.x0C7374642E6E65742E71756963010301084964656E7469747900, %sollang.enum.t537, %sollang.struct.x0C7374642E6E65742E7175696301030111436F6E6E656374696F6E4F7074696F6E7300, i1 }
%sollang.struct.x0C7374642E6E65742E717569630103010A436F6E6E656374696F6E00 = type { %sollang.array.i32, %sollang.enum.t537, %sollang.enum.t537, i1, i32, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301084B6579537461746500, %sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301084B6579537461746500, i64, i64, i1, %sollang.int_slice, %sollang.array.i32, %sollang.int_slice, %sollang.array.i32, i1, i1, %sollang.array.i32, %sollang.struct.x177374642E6E65742E717569632E7265617373656D626C7901030105517565756500, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i64, i32, i64, i1, i1, %sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F76657279010301074A6F75726E616C00, %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F7665727901030108527474537461746500, %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F766572790103010F436F6E67657374696F6E537461746500, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E436F6E6E656374696F6E466C6F7700, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E53747265616D526567697374727900, i64, i64, i64, i64, i64, i64, i8, i64, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103010D53656E64446972656374696F6E00 = type { %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010853656E64466C6F7700, i1, i1, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103011052656365697665446972656374696F6E00 = type { %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010B52656365697665466C6F7700, i1, i1, i64, i1, i64 }
%sollang.struct.x0C7374642E6E65742E7175696301030108426953747265616D00 = type { i64, %sollang.struct.x0C7374642E6E65742E717569630103010D53656E64446972656374696F6E00, %sollang.struct.x0C7374642E6E65742E717569630103011052656365697665446972656374696F6E00 }
%sollang.struct.x0C7374642E6E65742E717569630103010A53656E6453747265616D00 = type { i64, %sollang.struct.x0C7374642E6E65742E717569630103010D53656E64446972656374696F6E00 }
%sollang.struct.x0C7374642E6E65742E717569630103010D5265636569766553747265616D00 = type { i64, %sollang.struct.x0C7374642E6E65742E717569630103011052656365697665446972656374696F6E00 }
%sollang.struct.x0C7374642E6E65742E7175696301030105526F75746500 = type { i64, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103010B5061636B6574526F75746500 = type { i64, i8 }
%sollang.struct.x0C7374642E6E65742E717569630103010D506565725472616E73706F727400 = type { i64, i64, i64, i64, i64, i64, i64, i8, i64, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103011048616E647368616B654D65737361676500 = type { %sollang.array.i32, i64 }
%sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301084B6579537461746500 = type { i1, i32, %sollang.int_slice, %sollang.struct.x197374642E6E65742E717569632E747261666669635F6B657973010301044B65797300 }
%sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301064F70656E656400 = type { i64, i1, %sollang.enum.t556 }
%sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E650103010A4F70656E65644D616E7900 = type { i64, i1, %sollang.array.i32 }
%sollang.struct.x1D7374642E6E65742E717569632E636F6E6E656374696F6E5F737461746501030105537461746500 = type { i1, i1, i1, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E436F6E6E656374696F6E466C6F7700, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010C53747265616D4C696D69747300 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D010301084279746543656C6C00 = type { i64, i8 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D0103010D5265636569766542756666657200 = type { %sollang.array.i32, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D0103010A53656E6442756666657200 = type { %sollang.array.i32, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D010301045265616400 = type { %sollang.array.i32, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D010301054368756E6B00 = type { i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6572726F72010301054572726F7200 = type { %sollang.enum.t555, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010643727970746F00 = type { i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010653747265616D00 = type { i64, i64, i1, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010B526573657453747265616D00 = type { i64, i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010B53746F7053656E64696E6700 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D6501030108446174616772616D00 = type { %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010D4D617853747265616D4461746100 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010A4D617853747265616D7300 = type { i1, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103011153747265616D44617461426C6F636B656400 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010E53747265616D73426C6F636B656400 = type { i1, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010F436F6E6E656374696F6E436C6F736500 = type { i1, i64, i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010F4E6577436F6E6E656374696F6E496400 = type { i64, i64, %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010841636B52616E676500 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010341636B00 = type { i64, i64, i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D65010301074465636F64656400 = type { %sollang.enum.t556, i64 }
%sollang.struct.x1D7374642E6E65742E717569632E68616E647368616B655F656E67696E65010301064F70656E656400 = type { i32, i64, i64, %sollang.array.i32, i64 }
%sollang.struct.x1B7374642E6E65742E717569632E696E697469616C5F656E67696E65010301154163636570746564436C69656E74496E697469616C00 = type { i32, %sollang.array.i32, %sollang.array.i32, i64, %sollang.array.i32 }
%sollang.struct.x1B7374642E6E65742E717569632E696E697469616C5F656E67696E65010301134F70656E6564536572766572496E697469616C00 = type { %sollang.array.i32, i64, %sollang.array.i32 }
%sollang.struct.x117374642E6E65742E717569632E6B6579730103010B496E697469616C4B65797300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F7665727901030108527474537461746500 = type { i1, i64, i64, i64, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F766572790103010F436F6E67657374696F6E537461746500 = type { i64, i64, i64, i64, i1 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400 = type { %sollang.int_slice }
%sollang.struct.x107374642E6E65742E717569632E703270010301084964656E7469747900 = type { %sollang.struct.x0C7374642E6E65742E71756963010301084964656E7469747900, %sollang.int_slice, %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010A506565725265636F726400 = type { %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400, %sollang.int_slice, %sollang.struct.x077374642E6E65740103010C49707634456E64706F696E7400, i64, %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x107374642E6E65742E717569632E7032700103010753657373696F6E00 = type { %sollang.struct.x0C7374642E6E65742E717569630103010A436F6E6E656374696F6E00, %sollang.struct.x0C7374642E6E65742E7175696301030108426953747265616D00, %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010E50726F746F636F6C53747265616D00 = type { %sollang.array.i32 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010D41757468656E7469636174656400 = type { %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400, %sollang.struct.x0C7374642E6E65742E7175696301030108426953747265616D00 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010D4F70656E6564496E697469616C00 = type { i32, i64, %sollang.array.i32, i64 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010D496E697469616C48656164657200 = type { i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i64, i64 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010F4F70656E656448616E647368616B6500 = type { i32, i64, %sollang.array.i32, i64 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010F48616E647368616B6548656164657200 = type { i32, %sollang.array.i32, %sollang.array.i32, i64, i64 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010C4F70656E65644F6E6552747400 = type { i1, i64, %sollang.array.i32 }
%sollang.struct.x137374642E6E65742E717569632E7061636B6574010301134F70656E656450726F7465637465644C6F6E6700 = type { i8, i64, %sollang.array.i32 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010950726F746563746F7200 = type { %sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E0103011150726570617265645061636B65744B657900, %sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301094865616465724B657900 }
%sollang.struct.x1A7374642E6E65742E717569632E7061636B65745F6E756D626572010301095472756E636174656400 = type { i32, i64 }
%sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F766572790103010A53656E745061636B657400 = type { i64, i64, i64, i1, i1 }
%sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F766572790103010655706461746500 = type { %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F7665727901030108527474537461746500, %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F766572790103010F436F6E67657374696F6E537461746500, i64, i64, i64, i64 }
%sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F76657279010301074A6F75726E616C00 = type { %sollang.array.i32 }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301094D61736B56616C756500 = type { %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E0103010A4E6F6E636556616C756500 = type { %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301095061636B65744B657900 = type { %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301094865616465724B657900 = type { %sollang.struct.x117374642E63727970746F2E616573313238010301034B657900 }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E0103011150726570617265645061636B65744B657900 = type { %sollang.struct.x157374642E63727970746F2E6165733132385F67636D010301034B657900, %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E7265617373656D626C79010301094163636F756E74656400 = type { %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010B52656365697665466C6F7700, i64 }
%sollang.struct.x177374642E6E65742E717569632E7265617373656D626C7901030105517565756500 = type { %sollang.array.i32, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E53747265616D4964656E7469747900 = type { i64, i64, %sollang.enum.t557, %sollang.enum.t558 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010B52656365697665466C6F7700 = type { i64, i64, i64, i1, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010853656E64466C6F7700 = type { i64, i64, i1, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E436F6E6E656374696F6E466C6F7700 = type { i64, i64, i64, i64, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010C53747265616D4C696D69747300 = type { i64, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E53747265616D526567697374727900 = type { i1, i64, i64, i1, i1, i64, i64, i64, i64, i64, i64, i32, %sollang.array.i32, i32, i32, i32, i32, %sollang.array.i32, i32, i32, i32 }
%sollang.struct.x157374642E6E65742E717569632E746C735F617574680103010B436572746966696361746500 = type { %sollang.array.i32 }
%sollang.struct.x157374642E6E65742E717569632E746C735F6175746801030111436572746966696361746556657269667900 = type { i16, %sollang.array.i32 }
%sollang.struct.x1D7374642E6E65742E717569632E746C735F636C69656E745F737461746501030105537461746500 = type { %sollang.enum.t559, %sollang.struct.x1B7374642E6E65742E717569632E746C735F7472616E7363726970740103010A5472616E73637269707400, %sollang.int_slice }
%sollang.struct.x1A7374642E6E65742E717569632E746C735F68616E647368616B65010301074465636F64656400 = type { i8, %sollang.array.i32, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E746C735F68616E647368616B65010301104465636F646564457874656E73696F6E00 = type { i16, %sollang.array.i32, i64 }
%sollang.struct.x167374642E6E65742E717569632E746C735F68656C6C6F0103010B436C69656E7448656C6C6F00 = type { %sollang.int_slice, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.int_slice, %sollang.array.i32 }
%sollang.struct.x167374642E6E65742E717569632E746C735F68656C6C6F0103010B53657276657248656C6C6F00 = type { %sollang.int_slice, %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x167374642E6E65742E717569632E746C735F68656C6C6F01030113456E63727970746564457874656E73696F6E7300 = type { %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x1D7374642E6E65742E717569632E746C735F7365727665725F737461746501030105537461746500 = type { %sollang.enum.t560, %sollang.struct.x1B7374642E6E65742E717569632E746C735F7472616E7363726970740103010A5472616E73637269707400 }
%sollang.struct.x1B7374642E6E65742E717569632E746C735F7472616E7363726970740103010A5472616E73637269707400 = type { %sollang.array.i32 }
%sollang.struct.x197374642E6E65742E717569632E747261666669635F6B657973010301044B65797300 = type { %sollang.struct.x137374642E6E65742E717569632E7061636B65740103010950726F746563746F7200 }
%sollang.struct.x217374642E6E65742E717569632E7472616E73706F72745F706172616D6574657273010301074465636F64656400 = type { i64, %sollang.array.i32, i64 }
%sollang.struct.x217374642E6E65742E717569632E7472616E73706F72745F706172616D65746572730103010B53747265616D436F756E7400 = type { i64 }
%sollang.struct.x137374642E6E65742E717569632E766172696E74010301074465636F64656400 = type { i64, i64 }
%sollang.struct.x207374642E6E65742E717569632E76657273696F6E5F6E65676F74696174696F6E0103010B496E666F726D6174696F6E00 = type { i32, %sollang.array.i32 }
%sollang.struct.x1B7374642E6E65742E717569632E76657273696F6E5F7061636B6574010301065061636B657400 = type { %sollang.array.i32, %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x197374642E6E65742E717569632E783530395F6564323535313901030107456C656D656E7400 = type { i8, i64, i64, i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D4C697374656E4F7074696F6E7300 = type { %sollang.enum.t537, i32, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030113446174616772616D42696E644F7074696F6E7300 = type { %sollang.enum.t537, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010B5463704C697374656E657200 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030109556470536F636B657400 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010A53656E6442756666657200 = type { ptr, i64, i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D5265636569766542756666657200 = type { %sollang.array.i32 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030108496E74657265737400 = type { i64, %sollang.enum.t564, %sollang.enum.t563 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010A52656164794576656E7400 = type { i64, i1, i1, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030118436F6D706C6574696F6E52656163746F724F7074696F6E7300 = type { i64, i64, i64 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400 = type { i64, %sollang.enum.t565, %sollang.array.i32, i64, i64, %sollang.enum.t566, %sollang.enum.t1067, %sollang.enum.t1068, %sollang.enum.t677 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030119536F636B6574526567697374726174696F6E4661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D52656D6F76656453747265616D00 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030115436F6D706C6574696F6E576169744661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030110536F636B6574436F6D706C6574696F6E00 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103011B436F6D706C6574696F6E5375626D697373696F6E4661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030115536C6F745472616E736974696F6E4661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010752656163746F7200 = type { i64, %sollang.array.i32 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030108446174616772616D00 = type { %sollang.enum.t537, %sollang.array.i32, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010F446174616772616D5265636569707400 = type { %sollang.enum.t537, i64, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 = type { %sollang.enum.t569, i32 }
%sollang.struct.x087374642E70617468010301054572726F7200 = type { %sollang.enum.t571, i64 }
%sollang.struct.x087374642E70617468010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x087374642E7061746801030109436F6D706F6E656E7400 = type { %sollang.enum.t570, i64, i64 }
%sollang.struct.x087374642E706174680103010648656164657200 = type { %sollang.enum.t570, i64, i1 }
%sollang.struct.x087374642E706174680103010A436F6D706F6E656E747300 = type { %sollang.source_text, i64, i64, i32, i1, %sollang.struct.x087374642E70617468010301064C696D69747300, %sollang.struct.x087374642E706174680103010648656164657200 }
%sollang.struct.x0C7374642E746578742E637376010301054572726F7200 = type { %sollang.enum.t573, i64, i32 }
%sollang.struct.x0C7374642E746578742E637376010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0C7374642E746578742E6373760103010C5772697465724C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0C7374642E746578742E63737601030106466F726D617400 = type { %sollang.enum.t572, i32 }
%sollang.struct.x0C7374642E746578742E637376010301054669656C6400 = type { i32, i32, i32, i1 }
%sollang.struct.x0C7374642E746578742E6373760103010652656164657200 = type { %sollang.source_text, i64, i64, i32, i32, i1, %sollang.struct.x0C7374642E746578742E63737601030106466F726D617400, %sollang.struct.x0C7374642E746578742E637376010301064C696D69747300 }
%sollang.struct.x0C7374642E746578742E6373760103010657726974657200 = type { %sollang.struct.x0C7374642E746578742E6373760103010C5772697465724C696D69747300, i32, i32, i32, i32 }
%sollang.struct.x0C7374642E746578742E6373760103010C5363616E6E65644669656C6400 = type { i64, i64, i64, i32, i1, i1 }
%sollang.struct.x0D7374642E746578742E676C6F62010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x0D7374642E746578742E676C6F62010301054572726F7200 = type { %sollang.enum.t574, i64, i64 }
%sollang.struct.x0D7374642E746578742E676C6F62010301075061747465726E00 = type { %sollang.source_text, i64, i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E010301054572726F7200 = type { %sollang.enum.t577, i64 }
%sollang.struct.x0D7374642E746578742E6A736F6E010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E01030105546F6B656E00 = type { %sollang.enum.t575, i64, i64, i64, i64, i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E010301064D656D62657200 = type { %sollang.array.i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010556616C756500 = type { %sollang.enum.t576, i64, i64, i1, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E01030108446F63756D656E7400 = type { %sollang.array.i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010652656164657200 = type { %sollang.source_text, i64, i64, i8, i32, %sollang.struct.x0D7374642E746578742E6A736F6E010301064C696D69747300, %sollang.array.i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010657726974657200 = type { %sollang.array.i32, i32, i32, i32, i8, %sollang.array.i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010A537472696E675363616E00 = type { i64, i64, i32 }
%sollang.struct.x0E7374642E746578742E7265676578010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0E7374642E746578742E7265676578010301054572726F7200 = type { %sollang.enum.t578, i64, i64, i64 }
%sollang.struct.x0E7374642E746578742E7265676578010301054D6174636800 = type { i64, i64 }
%sollang.struct.x0E7374642E746578742E7265676578010301075061747465726E00 = type { %sollang.source_text, i64, i64, i32, i32, i1, i1, i32, i32 }
%sollang.struct.x0E7374642E746578742E72656765780103010441746F6D00 = type { %sollang.enum.t579, i64, i64, i64, i1, %sollang.enum.t580, i64 }
%sollang.struct.x0E7374642E746578742E726567657801030109436C617373556E697400 = type { i8, i64 }
%sollang.struct.x0E7374642E746578742E726567657801030104576F726B00 = type { i32 }
%sollang.struct.x087374642E74696D65010301084475726174696F6E00 = type { i64 }
%sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400 = type { i64, i64 }
%sollang.struct.x087374642E74696D650103010A557463496E7374616E7400 = type { i64 }
%sollang.struct.x087374642E74696D650103010C43616C656E6461724461746500 = type { i64, i64, i64 }
%sollang.struct.x087374642E74696D650103010E4D6F6E6F746F6E6963436C6F636B00 = type { i8 }
%sollang.struct.x087374642E74696D650103010957616C6C436C6F636B00 = type { i8 }
%sollang.struct.x087374642E74696D650103010B4D616E75616C436C6F636B00 = type { i64, i64 }
%sollang.struct.x087374642E74696D650103010F4D616E75616C57616C6C436C6F636B00 = type { i64 }
%sollang.struct.x087374642E74696D6501030108446561646C696E6500 = type { %sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400 }
%sollang.struct.x087374642E74696D650103010A4669786564436C6F636B00 = type { %sollang.struct.x087374642E74696D650103010A557463496E7374616E7400 }
%sollang.struct.x087374642E74696D650103010B4F6666736574436C6F636B00 = type { i64 }
%sollang.struct.x087374642E74696D6501030111436C6F636B4361706162696C697469657300 = type { %sollang.struct.x087374642E74696D65010301084475726174696F6E00, %sollang.enum.t581, %sollang.struct.x087374642E74696D65010301084475726174696F6E00 }
%sollang.struct.x087374642E74696D650103010554696D657200 = type { %sollang.array.i32, %sollang.struct.x087374642E74696D65010301084475726174696F6E00, i64, %sollang.enum.t582 }
%sollang.struct.x087374642E74696D650103010954696D65725469636B00 = type { %sollang.struct.x087374642E74696D650103010554696D657200, %sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400, %sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400, i64 }
%sollang.struct.x087374642E74696D65010301054572726F7200 = type { %sollang.enum.t583 }
%sollang.struct.x077374642E757269010301054572726F7200 = type { %sollang.enum.t587, i64 }
%sollang.struct.x077374642E757269010301045370616E00 = type { i64, i64, i1 }
%sollang.struct.x077374642E75726901030109417574686F7269747900 = type { %sollang.struct.x077374642E757269010301045370616E00, %sollang.enum.t584, %sollang.enum.t585, %sollang.struct.x077374642E757269010301045370616E00 }
%sollang.struct.x077374642E757269010301095265666572656E636500 = type { %sollang.source_text, %sollang.struct.x077374642E757269010301045370616E00, %sollang.enum.t586, %sollang.struct.x077374642E757269010301045370616E00, %sollang.struct.x077374642E757269010301045370616E00, %sollang.struct.x077374642E757269010301045370616E00 }
%sollang.struct.x077374642E757269010301134E6F726D616C697A6174696F6E506F6C69637900 = type { i1, i1, i1, i1, i1 }
%sollang.struct.x0F7374642E7572692E70657263656E74010301054572726F7200 = type { %sollang.enum.t588, i64 }
%sollang.struct.x0F7374642E7572692E70657263656E7401030104506C616E00 = type { i32, i32 }
%sollang.struct.x0F7374642E7572692E70657263656E7401030105436F64656300 = type { %sollang.enum.t589 }
%sollang.struct.x087374642E75756964010301054572726F7200 = type { %sollang.enum.t591, i64 }
%sollang.struct.x087374642E75756964010301045575696400 = type { %sollang.int_slice }
%sollang.struct.x087374642E7575696401030105436F64656300 = type { i8 }
%sollang.struct.x087374642E757569640103010947656E657261746F7200 = type { %sollang.struct.x087374642E74696D650103010957616C6C436C6F636B00, %sollang.struct.x117374642E63727970746F2E72616E646F6D0103010C53656375726552616E646F6D00 }
%sollang.struct.x0D7379732E6469726563746F72790103010352617700 = type { %sollang.array.i32, i64 }
%sollang.struct.x0D7379732E6469726563746F727901030105456E74727900 = type { %sollang.struct.x087379732E70617468010301045061746800, %sollang.enum.t594 }
%sollang.struct.x087379732E66696C650103010446696C6500 = type { i64 }
%sollang.struct.x087379732E66696C650103010A46696C6557726974657200 = type { i64 }
%sollang.struct.x087379732E66696C650103011441746F6D69635265706C6163655265717565737400 = type { %sollang.text, %sollang.text }
%sollang.struct.x087379732E66696C650103010A536F757263655465787400 = type {  }
%sollang.struct.x087379732E66696C650103010D5265616441745375636365737300 = type { %sollang.struct.x087379732E66696C650103010446696C6500, %sollang.array.i32, i64, i1 }
%sollang.struct.x087379732E66696C650103010D5265616441744661696C75726500 = type { %sollang.struct.x087379732E66696C650103010446696C6500, %sollang.array.i32, %sollang.enum.t595 }
%sollang.struct.x087379732E66696C650103010E577269746541745375636365737300 = type { %sollang.struct.x087379732E66696C650103010A46696C6557726974657200, %sollang.array.i32, i64 }
%sollang.struct.x087379732E66696C650103010E577269746541744661696C75726500 = type { %sollang.struct.x087379732E66696C650103010A46696C6557726974657200, %sollang.array.i32, %sollang.enum.t595 }
%sollang.struct.x0F7379732E696E7075742E6D6F757365010301054576656E7400 = type { i32, i32, i32, i32, %sollang.enum.t596 }
%sollang.struct.x0F7379732E696E7075742E6D6F757365010301054572726F7200 = type { %sollang.enum.t598, i32 }
%sollang.struct.x0F7379732E696E7075742E6D6F75736501030106536F7572636500 = type { i32, %sollang.enum.t597 }
%sollang.struct.x087379732E70617468010301045061746800 = type { %sollang.array.i32, %sollang.enum.t599 }
%sollang.struct.x087379732E7061746801030107526177496E666F00 = type { %sollang.array.i32, i8, i64, i64 }
%sollang.struct.x087379732E7061746801030104496E666F00 = type { %sollang.struct.x087379732E70617468010301045061746800, %sollang.enum.t594, i64, i64 }
%sollang.struct.x0B7379732E70726F6365737301030111456E7669726F6E6D656E744368616E676500 = type { %sollang.text, %sollang.text, i1 }
%sollang.struct.x0B7379732E70726F636573730103010D436170747572654C696D69747300 = type { i64, i64 }
%sollang.struct.x0B7379732E70726F636573730103010E43617074757265644F757470757400 = type { %sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300, %sollang.array.i32, %sollang.array.i32, i1, i1 }
%sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 = type { %sollang.array.i32, %sollang.text, i1, %sollang.array.i32, i1, %sollang.enum.t600, %sollang.enum.t601, %sollang.enum.t601 }
%sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 = type { i32 }
%sollang.struct.x0B7379732E70726F636573730103010C5369676E616C53746174757300 = type { i32 }
%sollang.struct.x0B7379732E70726F636573730103010950726F63657373496400 = type { i64 }
%sollang.struct.x0B7379732E70726F63657373010301054368696C6400 = type { i64, %sollang.struct.x0B7379732E70726F636573730103010950726F63657373496400, i32, i32 }
%sollang.struct.x0B7379732E70726F63657373010301094368696C64506F6C6C00 = type { i32, i32 }
%sollang.struct.x067374642E696F0105010652656164657200 = type {  }
%sollang.struct.x067374642E696F0105010657726974657200 = type {  }
@_fltused = global i32 0
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture)
%sollang.dyn = type { ptr, ptr }
%sollang.mutable_container = type { ptr, ptr, ptr }
%sollang.int_slice = type { ptr, i64 }
%sollang.array.i32 = type { ptr, i64, i64 }
define internal void @sollang_drop_t451(%sollang.struct.x0B7379732E70726F6365737301030111456E7669726F6E6D656E744368616E676500 %value) {
entry:
  ret void
}
define internal void @sollang_drop_t454(%sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %value) {
entry:
  %field0 = extractvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %value, 0
  call void @sollang_drop_t1165(%sollang.array.i32 %field0)
  %field3 = extractvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %value, 3
  call void @sollang_drop_t1166(%sollang.array.i32 %field3)
  ret void
}
define internal void @sollang_drop_t455(%sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 %value) {
entry:
  ret void
}
define internal void @sollang_drop_t1165(%sollang.array.i32 %value) {
entry:
  %data = extractvalue %sollang.array.i32 %value, 0
  %length = extractvalue %sollang.array.i32 %value, 1
  call void @sollang_free(ptr %data)
  ret void
}
define internal void @sollang_drop_t1166(%sollang.array.i32 %value) {
entry:
  %data = extractvalue %sollang.array.i32 %value, 0
  %length = extractvalue %sollang.array.i32 %value, 1
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %continue ]
  %in_range = icmp ult i64 %index, %length
  br i1 %in_range, label %item, label %done
item:
  %slot = getelementptr %sollang.struct.x0B7379732E70726F6365737301030111456E7669726F6E6D656E744368616E676500, ptr %data, i64 %index
  %element = load %sollang.struct.x0B7379732E70726F6365737301030111456E7669726F6E6D656E744368616E676500, ptr %slot, align 8
  call void @sollang_drop_t451(%sollang.struct.x0B7379732E70726F6365737301030111456E7669726F6E6D656E744368616E676500 %element)
  br label %continue
continue:
  %next = add i64 %index, 1
  br label %loop
done:
  call void @sollang_free(ptr %data)
  ret void
}
define internal void @sollang_drop_t1167(%sollang.enum.t1167 %value) {
entry:
  %slot = alloca %sollang.enum.t1167, align 8
  store %sollang.enum.t1167 %value, ptr %slot, align 8
  %tag = extractvalue %sollang.enum.t1167 %value, 0
  %payload = getelementptr inbounds %sollang.enum.t1167, ptr %slot, i32 0, i32 1
  %is0 = icmp eq i32 %tag, 0
  br i1 %is0, label %tag0, label %tag1
tag0:
  %first = load %sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300, ptr %payload, align 4
  call void @sollang_drop_t455(%sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 %first)
  br label %done
tag1:
  br label %done
done:
  ret void
}
declare void @llvm.trap()
declare dllimport void @ExitProcess(i32)
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011764657269766545787465726E616C42696E6465724B65794E01067075626C6963011764657269766545787465726E616C42696E6465724B6579010370736B18013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [10 x i8] c"ext binder"
@sollang_str_x157374642E63727970746F2E746C7331335F6B65797301070119646572697665526573756D7074696F6E42696E6465724B65795001067075626C69630119646572697665526573756D7074696F6E42696E6465724B6579010370736B18013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [10 x i8] c"res binder"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701136465726976654561726C7946726F6D486173687201067075626C696301136465726976654561726C7946726F6D48617368010370736B18013A07015B010555496E743808015D0E012C0119636C69656E7448656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E010C4561726C7953656372657473_00 = private unnamed_addr constant [11 x i8] c"c e traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701136465726976654561726C7946726F6D486173687201067075626C696301136465726976654561726C7946726F6D48617368010370736B18013A07015B010555496E743808015D0E012C0119636C69656E7448656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E010C4561726C7953656372657473_01 = private unnamed_addr constant [12 x i8] c"e exp master"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_00 = private unnamed_addr constant [7 x i8] c"derived"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_01 = private unnamed_addr constant [12 x i8] c"c hs traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_02 = private unnamed_addr constant [12 x i8] c"s hs traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_03 = private unnamed_addr constant [7 x i8] c"derived"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701196465726976654170706C69636174696F6E46726F6D48617368880101067075626C696301196465726976654170706C69636174696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C73657276657246696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E01124170706C69636174696F6E53656372657473_00 = private unnamed_addr constant [12 x i8] c"c ap traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701196465726976654170706C69636174696F6E46726F6D48617368880101067075626C696301196465726976654170706C69636174696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C73657276657246696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E01124170706C69636174696F6E53656372657473_01 = private unnamed_addr constant [12 x i8] c"s ap traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701196465726976654170706C69636174696F6E46726F6D48617368880101067075626C696301196465726976654170706C69636174696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C73657276657246696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E01124170706C69636174696F6E53656372657473_02 = private unnamed_addr constant [10 x i8] c"exp master"
@sollang_str_x157374642E63727970746F2E746C7331335F6B65797301070118646572697665526573756D7074696F6E46726F6D48617368870101067075626C69630118646572697665526573756D7074696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C636C69656E7446696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [10 x i8] c"res master"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011A66696E69736865645665726966794461746146726F6D486173687801067075626C6963011A66696E69736865645665726966794461746146726F6D486173680107626173654B657918013A07015B010555496E743808015D0E012C010E7472616E7363726970744861736818013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [8 x i8] c"finished"
@sollang_str_x157374642E63727970746F2E746C7331335F6B65797301070113757064617465547261666669635365637265744D01067075626C6963011375706461746554726166666963536563726574010673656372657418013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [11 x i8] c"traffic upd"
@sollang_str_x0C7374642E6E65742E687474700107010C706172736556657273696F6E8401010C706172736556657273696F6E0106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C0105737461727418013A010855496E7453697A650E012C0103656E6418013A010855496E7453697A6516022D3E0106526573756C741E013C010756657273696F6E0E012C01054572726F721F013E_00 = private unnamed_addr constant [8 x i8] c"HTTP/1.0"
@sollang_str_x0C7374642E6E65742E687474700107010C706172736556657273696F6E8401010C706172736556657273696F6E0106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C0105737461727418013A010855496E7453697A650E012C0103656E6418013A010855496E7453697A6516022D3E0106526573756C741E013C010756657273696F6E0E012C01054572726F721F013E_01 = private unnamed_addr constant [8 x i8] c"HTTP/1.1"
@sollang_str_x117374642E6E65742E687474702E626F64790107011570617273655472616E73666572456E636F64696E678301011570617273655472616E73666572456E636F64696E670106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C010576616C756518013A0104687474700D012E01045370616E16022D3E0106526573756C741E013C0104426F6F6C0E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [7 x i8] c"chunked"
@sollang_str_x117374642E6E65742E687474702E626F64790107010D6865616465724672616D696E67B101010D6865616465724672616D696E670106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C01066669656C647318013A010372656607015B0104687474700D012E01054669656C640F013B0C017E08015D0E012C01066C696D69747318013A010A426F64794C696D69747316022D3E0106526573756C741E013C010D4865616465724672616D696E670E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x117374642E6E65742E687474702E626F64790107010D6865616465724672616D696E67B101010D6865616465724672616D696E670106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C01066669656C647318013A010372656607015B0104687474700D012E01054669656C640F013B0C017E08015D0E012C01066C696D69747318013A010A426F64794C696D69747316022D3E0106526573756C741E013C010D4865616465724672616D696E670E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F76616C6964617465547261696C65725A010F76616C6964617465547261696C657201076465636F64657218013A0103726566010B426F64794465636F64657216022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F76616C6964617465547261696C65725A010F76616C6964617465547261696C657201076465636F64657218013A0103726566010B426F64794465636F64657216022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F73656C6563745265706C79426F64798901010F73656C6563745265706C79426F64790107636F6E7465787418013A0113526573706F6E7365426F6479436F6E746578740E012C01046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0108426F6479506C616E0E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F73656C6563745265706C79426F64798901010F73656C6563745265706C79426F64790107636F6E7465787418013A0113526573706F6E7365426F6479436F6E746578740E012C01046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0108426F6479506C616E0E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x137374642E6E65742E687474702E636C69656E7401070119726573706F6E7365416C6C6F777350657273697374656E6365620119726573706F6E7365416C6C6F777350657273697374656E636501046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_00 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x137374642E6E65742E687474702E636C69656E7401070119726573706F6E7365416C6C6F777350657273697374656E6365620119726573706F6E7365416C6C6F777350657273697374656E636501046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"close"
@sollang_str_x137374642E6E65742E687474702E636C69656E7401070119726573706F6E7365416C6C6F777350657273697374656E6365620119726573706F6E7365416C6C6F777350657273697374656E636501046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_02 = private unnamed_addr constant [10 x i8] c"keep-alive"
@sollang_str_x137374642E6E65742E687474702E636C69656E7402060108526573706F6E7365100104696D706C0108526573706F6E73651F01086F70656E426F64794B01067075626C696301086F70656E426F647918013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365426F64790E012C01054572726F721F013E_00 = private unnamed_addr constant [3 x i8] c"GET"
@sollang_str_x137374642E6E65742E687474702E636C69656E7402060108526573706F6E7365100104696D706C0108526573706F6E73651F01086F70656E426F64794B01067075626C696301086F70656E426F647918013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365426F64790E012C01054572726F721F013E_01 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x137374642E6E65742E687474702E636C69656E7402060108526573706F6E7365100104696D706C0108526573706F6E73651F01086F70656E426F64794B01067075626C696301086F70656E426F647918013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365426F64790E012C01054572726F721F013E_02 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E7265717565737401070119636C617373696679526573706F6E736553656D616E74696373430119636C617373696679526573706F6E736553656D616E7469637301066D6574686F6418013A01045465787416022D3E0111526573706F6E736553656D616E74696373_00 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x147374642E6E65742E687474702E7265717565737401070119636C617373696679526573706F6E736553656D616E74696373430119636C617373696679526573706F6E736553656D616E7469637301066D6574686F6418013A01045465787416022D3E0111526573706F6E736553656D616E74696373_01 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_00 = private unnamed_addr constant [4 x i8] c"Host"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_01 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_02 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_03 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_04 = private unnamed_addr constant [7 x i8] c"Trailer"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_00 = private unnamed_addr constant [8 x i8] c"HTTP/1.0"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_01 = private unnamed_addr constant [8 x i8] c"HTTP/1.1"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_00 = private unnamed_addr constant [2 x i8] c": "
@sollang_str_x147374642E6E65742E687474702E726571756573740107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x147374642E6E65742E687474702E7265717565737401070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_00 = private unnamed_addr constant [16 x i8] c"Content-Length: "
@sollang_str_x147374642E6E65742E687474702E7265717565737401070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_03 = private unnamed_addr constant [7 x i8] c"OPTIONS"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374506F6C696379150104696D706C010D52657175657374506F6C6963791F010772657175657374F50101067075626C696301077265717565737418013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C0109617574686F7269747918013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010D526571756573745772697465720E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"Host"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [5 x i8] c"close"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_03 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_04 = private unnamed_addr constant [10 x i8] c"keep-alive"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_05 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_00 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_01 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_02 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_03 = private unnamed_addr constant [7 x i8] c"Trailer"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_00 = private unnamed_addr constant [8 x i8] c"HTTP/1.0"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_01 = private unnamed_addr constant [8 x i8] c"HTTP/1.1"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_00 = private unnamed_addr constant [2 x i8] c": "
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E736501070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_00 = private unnamed_addr constant [16 x i8] c"Content-Length: "
@sollang_str_x157374642E6E65742E687474702E726573706F6E736501070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365506F6C696379160104696D706C010E526573706F6E7365506F6C6963791F0108726573706F6E7365EA0101067075626C69630108726573706F6E736518013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C010673746174757318013A0103496E740E012C0106726561736F6E18013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010E526573706F6E73655772697465720E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365506F6C696379160104696D706C010E526573706F6E7365506F6C6963791F0108726573706F6E7365EA0101067075626C69630108726573706F6E736518013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C010673746174757318013A0103496E740E012C0106726561736F6E18013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010E526573706F6E73655772697465720E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365506F6C696379160104696D706C010E526573706F6E7365506F6C6963791F0108726573706F6E7365EA0101067075626C69630108726573706F6E736518013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C010673746174757318013A0103496E740E012C0106726561736F6E18013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010E526573706F6E73655772697465720E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"close"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_03 = private unnamed_addr constant [10 x i8] c"keep-alive"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_04 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_00 = private unnamed_addr constant [9 x i8] c"client in"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_01 = private unnamed_addr constant [9 x i8] c"server in"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_02 = private unnamed_addr constant [10 x i8] c"quicv2 key"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_03 = private unnamed_addr constant [8 x i8] c"quic key"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_04 = private unnamed_addr constant [9 x i8] c"quicv2 iv"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_05 = private unnamed_addr constant [7 x i8] c"quic iv"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_06 = private unnamed_addr constant [9 x i8] c"quicv2 hp"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_07 = private unnamed_addr constant [7 x i8] c"quic hp"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_00 = private unnamed_addr constant [10 x i8] c"quicv2 key"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_01 = private unnamed_addr constant [8 x i8] c"quic key"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_02 = private unnamed_addr constant [9 x i8] c"quicv2 iv"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_03 = private unnamed_addr constant [7 x i8] c"quic iv"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_04 = private unnamed_addr constant [9 x i8] c"quicv2 hp"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_05 = private unnamed_addr constant [7 x i8] c"quic hp"
@sollang_str_x0D7374642E746578742E6A736F6E020601065265616465720E0104696D706C01065265616465721F0107626F6F6C65616E5001067075626C69630107626F6F6C65616E18013A010473656C660E012C0105746F6B656E18013A0105546F6B656E16022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E020601065265616465720E0104696D706C01065265616465721F0107626F6F6C65616E5001067075626C69630107626F6F6C65616E18013A010473656C660E012C0105746F6B656E18013A0105546F6B656E16022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x0D7374642E746578742E6A736F6E020601065265616465720E0104696D706C01065265616465721F01096E756C6C56616C75655201067075626C696301096E756C6C56616C756518013A010473656C660E012C0105746F6B656E18013A0105546F6B656E16022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E010701097363616E56616C75655801097363616E56616C7565010672656164657218013A01036D757401065265616465720E012C0105646570746818013A0103496E7416022D3E0106526573756C741E013C0105546F6B656E0E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E010701097363616E56616C75655801097363616E56616C7565010672656164657218013A01036D757401065265616465720E012C0105646570746818013A0103496E7416022D3E0106526573756C741E013C0105546F6B656E0E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x0D7374642E746578742E6A736F6E010701097363616E56616C75655801097363616E56616C7565010672656164657218013A01036D757401065265616465720E012C0105646570746818013A0103496E7416022D3E0106526573756C741E013C0105546F6B656E0E012C01054572726F721F013E_02 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E0107011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E748501011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E74010576616C756518013A0103726566010556616C75650E012C01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C0108646F63756D656E7418013A01037265660108446F63756D656E7416022D3E0104556E6974_00 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E0107011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E748501011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E74010576616C756518013A0103726566010556616C75650E012C01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C0108646F63756D656E7418013A01037265660108446F63756D656E7416022D3E0104556E6974_01 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E0107011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E748501011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E74010576616C756518013A0103726566010556616C75650E012C01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C0108646F63756D656E7418013A01037265660108446F63756D656E7416022D3E0104556E6974_02 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F0105696E7436345301067075626C69630105696E74363418013A01036D7574010473656C660E012C010576616C756518013A0105496E74363416022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [6 x i8] c"$value"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F010675696E7436345501067075626C6963010675696E74363418013A01036D7574010473656C660E012C010576616C756518013A010655496E74363416022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [6 x i8] c"$value"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F01096E756C6C56616C75654301067075626C696301096E756C6C56616C756518013A01036D7574010473656C6616022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F0107626F6F6C65616E5401067075626C69630107626F6F6C65616E18013A01036D7574010473656C660E012C010576616C756518013A0104426F6F6C16022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F0107626F6F6C65616E5401067075626C69630107626F6F6C65616E18013A01036D7574010473656C660E012C010576616C756518013A0104426F6F6C16022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F0115617574686F7269747955736572496E666F546578743201067075626C69630115617574686F7269747955736572496E666F5465787418013A010473656C6616022D3E010454657874_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F010E726567697374657265644E616D652B01067075626C6963010E726567697374657265644E616D6518013A010473656C6616022D3E010454657874_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F010E726567697374657265644E616D652B01067075626C6963010E726567697374657265644E616D6518013A010473656C6616022D3E010454657874_01 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F010E726567697374657265644E616D652B01067075626C6963010E726567697374657265644E616D6518013A010473656C6616022D3E010454657874_02 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_00 = private unnamed_addr constant [1 x i8] c"0"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_01 = private unnamed_addr constant [1 x i8] c"1"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_02 = private unnamed_addr constant [1 x i8] c"2"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_03 = private unnamed_addr constant [1 x i8] c"3"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_04 = private unnamed_addr constant [1 x i8] c"4"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_05 = private unnamed_addr constant [1 x i8] c"5"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_06 = private unnamed_addr constant [1 x i8] c"6"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_07 = private unnamed_addr constant [1 x i8] c"7"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_08 = private unnamed_addr constant [1 x i8] c"8"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_09 = private unnamed_addr constant [1 x i8] c"9"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0A = private unnamed_addr constant [1 x i8] c"a"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0B = private unnamed_addr constant [1 x i8] c"b"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0C = private unnamed_addr constant [1 x i8] c"c"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0D = private unnamed_addr constant [1 x i8] c"d"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0E = private unnamed_addr constant [1 x i8] c"e"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0F = private unnamed_addr constant [1 x i8] c"f"
@sollang_str_x087374642E7575696402060104557569640C0104696D706C0104557569641F0104746578743C01067075626C696301047465787418013A010473656C660E012C010773746F7261676518013A01036D757401054172656E6116022D3E010454657874_00 = private unnamed_addr constant [1296 x i8] c"$((Int(self.bytes[0]) / 16) -> hexDigit)$((Int(self.bytes[0]) % 16) -> hexDigit)$((Int(self.bytes[1]) / 16) -> hexDigit)$((Int(self.bytes[1]) % 16) -> hexDigit)$((Int(self.bytes[2]) / 16) -> hexDigit)$((Int(self.bytes[2]) % 16) -> hexDigit)$((Int(self.bytes[3]) / 16) -> hexDigit)$((Int(self.bytes[3]) % 16) -> hexDigit)-$((Int(self.bytes[4]) / 16) -> hexDigit)$((Int(self.bytes[4]) % 16) -> hexDigit)$((Int(self.bytes[5]) / 16) -> hexDigit)$((Int(self.bytes[5]) % 16) -> hexDigit)-$((Int(self.bytes[6]) / 16) -> hexDigit)$((Int(self.bytes[6]) % 16) -> hexDigit)$((Int(self.bytes[7]) / 16) -> hexDigit)$((Int(self.bytes[7]) % 16) -> hexDigit)-$((Int(self.bytes[8]) / 16) -> hexDigit)$((Int(self.bytes[8]) % 16) -> hexDigit)$((Int(self.bytes[9]) / 16) -> hexDigit)$((Int(self.bytes[9]) % 16) -> hexDigit)-$((Int(self.bytes[10]) / 16) -> hexDigit)$((Int(self.bytes[10]) % 16) -> hexDigit)$((Int(self.bytes[11]) / 16) -> hexDigit)$((Int(self.bytes[11]) % 16) -> hexDigit)$((Int(self.bytes[12]) / 16) -> hexDigit)$((Int(self.bytes[12]) % 16) -> hexDigit)$((Int(self.bytes[13]) / 16) -> hexDigit)$((Int(self.bytes[13]) % 16) -> hexDigit)$((Int(self.bytes[14]) / 16) -> hexDigit)$((Int(self.bytes[14]) % 16) -> hexDigit)$((Int(self.bytes[15]) / 16) -> hexDigit)$((Int(self.bytes[15]) % 16) -> hexDigit)"
@sollang_str_x0D7379732E6469726563746F727901070104726561644701067075626C696301047265616401096469726563746F727918013A0104706174680D012E01045061746816022D3E010A52656164526573756C74010475736573010446696C65_00 = private unnamed_addr constant [2 x i8] c"io"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F010571756572794501067075626C69630105717565727918013A010473656C6616022D3E0106526573756C741E013C0104496E666F0E012C0104546578741F013E010475736573010446696C65_00 = private unnamed_addr constant [2 x i8] c"io"
@sollang_str_x087379732E706174680107010966726F6D42797465736B01067075626C6963010966726F6D4279746573010576616C756518013A01046D6F766507015B010555496E74380F013B0C017E08015D0E012C01057374796C6518013A01055374796C6516022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [23 x i8] c"path is not valid UTF-8"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01046A6F696E5101067075626C696301046A6F696E18013A01046D6F7665010473656C660E012C01056368696C6418013A01045465787416022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [19 x i8] c"absolute child path"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01086A6F696E506174685401067075626C696301086A6F696E5061746818013A010473656C660E012C01056368696C6418013A010372656601045061746816022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [18 x i8] c"path styles differ"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01086A6F696E506174685401067075626C696301086A6F696E5061746818013A010473656C660E012C01056368696C6418013A010372656601045061746816022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_01 = private unnamed_addr constant [29 x i8] c"cannot join an absolute child"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F0111636F6E7461696E734C65786963616C6C796101067075626C69630111636F6E7461696E734C65786963616C6C7918013A010473656C660E012C010963616E64696461746518013A010372656601045061746816022D3E0106526573756C741E013C0104426F6F6C0E012C0104546578741F013E_00 = private unnamed_addr constant [18 x i8] c"path styles differ"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [17 x i8] c"path contains NUL"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_01 = private unnamed_addr constant [20 x i8] c"invalid drive prefix"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_02 = private unnamed_addr constant [26 x i8] c"unsupported path namespace"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_03 = private unnamed_addr constant [26 x i8] c"unsupported path namespace"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_04 = private unnamed_addr constant [16 x i8] c"invalid UNC path"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_05 = private unnamed_addr constant [17 x i8] c"path escapes root"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_06 = private unnamed_addr constant [19 x i8] c"incomplete UNC path"
@sollang_str_x0B7379732E70726F6365737301070107636F6D6D616E643001067075626C69630107636F6D6D616E64010770726F6772616D18013A01045465787416022D3E0107436F6D6D616E64_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x0B7379732E70726F6365737302060107436F6D6D616E640F0104696D706C0107436F6D6D616E641F011172656D6F7665456E7669726F6E6D656E744501067075626C6963011172656D6F7665456E7669726F6E6D656E7418013A01036D7574010473656C660E012C01046E616D6518013A01045465787416022D3E0104556E6974_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F0112747279576169745465726D696E6174696F6E7501067075626C69630112747279576169745465726D696E6174696F6E18013A01036D7574010473656C6616022D3E0106526573756C741E013C01064F7074696F6E1E013C01115465726D696E6174696F6E5374617475731F013E0E012C0104546578741F013E010475736573010750726F63657373_00 = private unnamed_addr constant [4 x i8] c"wait"
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F0112747279576169745465726D696E6174696F6E7501067075626C69630112747279576169745465726D696E6174696F6E18013A01036D7574010473656C6616022D3E0106526573756C741E013C01064F7074696F6E1E013C01115465726D696E6174696F6E5374617475731F013E0E012C0104546578741F013E010475736573010750726F63657373_01 = private unnamed_addr constant [4 x i8] c"wait"
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F0107747279576169746301067075626C696301077472795761697418013A01036D7574010473656C6616022D3E0106526573756C741E013C01064F7074696F6E1E013C010A457869745374617475731F013E0E012C0104546578741F013E010475736573010750726F63657373_00 = private unnamed_addr constant [6 x i8] c"signal"
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F01046B696C6C4C01067075626C696301046B696C6C18013A01036D7574010473656C6616022D3E0106526573756C741E013C0104556E69740E012C0104546578741F013E010475736573010750726F63657373_00 = private unnamed_addr constant [4 x i8] c"kill"
@sollang_str_x0001070108657869745465787422010865786974546578740104636F646518013A0103496E7416022D3E010454657874_00 = private unnamed_addr constant [6 x i8] c"exit 0"
@sollang_str_x0001070108657869745465787422010865786974546578740104636F646518013A0103496E7416022D3E010454657874_01 = private unnamed_addr constant [12 x i8] c"exit nonzero"
@sollang_str_x000107010864657363726962654E010864657363726962650106726573756C7418013A0106526573756C741E013C010770726F636573730D012E010A457869745374617475730E012C0104546578741F013E16022D3E010454657874_00 = private unnamed_addr constant [12 x i8] c"exit nonzero"
@sollang_str_entry_00 = private unnamed_addr constant [13 x i8] c"child $spaced"
@sollang_str_entry_01 = private unnamed_addr constant [14 x i8] c"child $unicode"
@sollang_str_entry_02 = private unnamed_addr constant [7 x i8] c"--child"
@sollang_str_entry_03 = private unnamed_addr constant [11 x i8] c"space value"
@sollang_str_entry_04 = private unnamed_addr constant [6 x i8] c"\ED\95\9C\EA\B8\80"
@sollang_str_entry_05 = private unnamed_addr constant [33 x i8] c"argv $(command! -> argumentCount)"
@sollang_str_entry_06 = private unnamed_addr constant [37 x i8] c"sollang-definitely-missing-executable"
@sollang_argument_count_value = internal global i64 0
@sollang_argument_records = internal global ptr null
define internal i32 @sollang_init_arguments() {
entry:
  %argc_slot = alloca i32, align 4
  %command = call ptr @GetCommandLineW()
  %wide_argv = call ptr @CommandLineToArgvW(ptr %command, ptr %argc_slot)
  %argv_ok = icmp ne ptr %wide_argv, null
  br i1 %argv_ok, label %allocate, label %fail

allocate:
  %argc32 = load i32, ptr %argc_slot, align 4
  %argc = zext i32 %argc32 to i64
  %record_bytes = mul i64 %argc, 16
  %records = call ptr @sollang_alloc(i64 %record_bytes)
  %records_ok = icmp ne ptr %records, null
  br i1 %records_ok, label %loop, label %free_wide_fail

loop:
  %i = phi i64 [ 0, %allocate ], [ %next, %stored ]
  %done = icmp eq i64 %i, %argc
  br i1 %done, label %success, label %convert_size

convert_size:
  %wide_slot = getelementptr ptr, ptr %wide_argv, i64 %i
  %wide = load ptr, ptr %wide_slot, align 8
  %bytes32 = call i32 @WideCharToMultiByte(i32 65001, i32 128, ptr %wide, i32 -1, ptr null, i32 0, ptr null, ptr null)
  %bytes_valid = icmp sgt i32 %bytes32, 0
  br i1 %bytes_valid, label %convert_alloc, label %cleanup_partial

convert_alloc:
  %bytes = zext i32 %bytes32 to i64
  %utf8 = call ptr @sollang_alloc(i64 %bytes)
  %utf8_ok = icmp ne ptr %utf8, null
  br i1 %utf8_ok, label %convert, label %cleanup_partial

convert:
  %written = call i32 @WideCharToMultiByte(i32 65001, i32 128, ptr %wide, i32 -1, ptr %utf8, i32 %bytes32, ptr null, ptr null)
  %converted = icmp eq i32 %written, %bytes32
  br i1 %converted, label %stored, label %free_current

free_current:
  call void @sollang_free(ptr %utf8)
  br label %cleanup_partial

stored:
  %record = getelementptr %sollang.text, ptr %records, i64 %i
  %ptr_slot = getelementptr inbounds %sollang.text, ptr %record, i32 0, i32 0
  store ptr %utf8, ptr %ptr_slot, align 8
  %len_slot = getelementptr inbounds %sollang.text, ptr %record, i32 0, i32 1
  %length = sub i64 %bytes, 1
  store i64 %length, ptr %len_slot, align 8
  %next = add i64 %i, 1
  br label %loop

cleanup_partial:
  %j = phi i64 [ %i, %convert_size ], [ %i, %convert_alloc ], [ %i, %free_current ], [ %prev, %cleanup_free ]
  %cleanup_done = icmp eq i64 %j, 0
  br i1 %cleanup_done, label %free_records_fail, label %cleanup_free

cleanup_free:
  %prev = sub i64 %j, 1
  %old_record = getelementptr %sollang.text, ptr %records, i64 %prev
  %old_ptr_slot = getelementptr inbounds %sollang.text, ptr %old_record, i32 0, i32 0
  %old_ptr = load ptr, ptr %old_ptr_slot, align 8
  call void @sollang_free(ptr %old_ptr)
  br label %cleanup_partial

free_records_fail:
  call void @sollang_free(ptr %records)
  br label %free_wide_fail

success:
  store i64 %argc, ptr @sollang_argument_count_value, align 8
  store ptr %records, ptr @sollang_argument_records, align 8
  %ignored_wide = call ptr @LocalFree(ptr %wide_argv)
  ret i32 1

free_wide_fail:
  %ignored_fail = call ptr @LocalFree(ptr %wide_argv)
  br label %fail

fail:
  ret i32 0
}

define internal i64 @sollang_argument_count() {
entry:
  %count = load i64, ptr @sollang_argument_count_value, align 8
  ret i64 %count
}

define internal %sollang.text @sollang_argument(i64 %index) {
entry:
  %records = load ptr, ptr @sollang_argument_records, align 8
  %record = getelementptr %sollang.text, ptr %records, i64 %index
  %value = load %sollang.text, ptr %record, align 8
  ret %sollang.text %value
}

define internal void @sollang_dispose_arguments() {
entry:
  %count = load i64, ptr @sollang_argument_count_value, align 8
  %records = load ptr, ptr @sollang_argument_records, align 8
  br label %loop

loop:
  %i = phi i64 [ 0, %entry ], [ %next, %free_item ]
  %done = icmp eq i64 %i, %count
  br i1 %done, label %finish, label %free_item

free_item:
  %record = getelementptr %sollang.text, ptr %records, i64 %i
  %ptr_slot = getelementptr inbounds %sollang.text, ptr %record, i32 0, i32 0
  %ptr = load ptr, ptr %ptr_slot, align 8
  call void @sollang_free(ptr %ptr)
  %next = add i64 %i, 1
  br label %loop

finish:
  call void @sollang_free(ptr %records)
  ret void
}
; sollang.codegen.unit 1:
; sollang.codegen.key 7809847782465536322:16735588292263053512
define %sollang.text @sollang_x000107010864657363726962654E010864657363726962650106726573756C7418013A0106526573756C741E013C010770726F636573730D012E010A457869745374617475730E012C0104546578741F013E16022D3E010454657874(%sollang.enum.t1167 %arg) {
entry:
  %v5_subject_slot = alloca %sollang.enum.t1167, align 8
  %v5_result = alloca %sollang.text, align 8
  %if13_result = alloca %sollang.text, align 8
  %v5_tag = extractvalue %sollang.enum.t1167 %arg, 0
  store %sollang.enum.t1167 %arg, ptr %v5_subject_slot, align 8
  %v5_is_arm0 = icmp eq i32 %v5_tag, 0
  br i1 %v5_is_arm0, label %match118123_arm0, label %match118123_next0
match118123_arm0:
  %v5_arm0_payload = getelementptr inbounds %sollang.enum.t1167, ptr %v5_subject_slot, i32 0, i32 1
  %v8 = load %sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300, ptr %v5_arm0_payload, align 4
  %v12 = freeze %sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 %v8
  %v11 = call i1 @sollang_x0B7379732E70726F636573730206010A45786974537461747573120104696D706C010A457869745374617475731F01097375636365656465642601067075626C6963010973756363656564656418013A010473656C6616022D3E0104426F6F6C(%sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 %v12)
  br i1 %v11, label %if13_then, label %if13_else
if13_then:
  %v16 = freeze %sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 %v8
  %v24 = call i32 @sollang_x0B7379732E70726F636573730206010A45786974537461747573120104696D706C010A457869745374617475731F010865786974436F64652401067075626C6963010865786974436F646518013A010473656C6616022D3E0103496E74(%sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 %v16)
  %v15 = call %sollang.text @sollang_x0001070108657869745465787422010865786974546578740104636F646518013A0103496E7416022D3E010454657874(i32 %v24)
  store %sollang.text %v15, ptr %if13_result, align 8
  br label %if13_merge
if13_else:
  %v18_ptr = insertvalue %sollang.text poison, ptr @sollang_str_x000107010864657363726962654E010864657363726962650106726573756C7418013A0106526573756C741E013C010770726F636573730D012E010A457869745374617475730E012C0104546578741F013E16022D3E010454657874_00, 0
  %v18 = insertvalue %sollang.text %v18_ptr, i64 12, 1
  store %sollang.text %v18, ptr %if13_result, align 8
  br label %if13_merge
if13_merge:
  %v13 = load %sollang.text, ptr %if13_result, align 8
  store %sollang.text %v13, ptr %v5_result, align 8
  br label %match118123_merge
match118123_next0:
  %v5_is_arm1 = icmp eq i32 %v5_tag, 1
  br i1 %v5_is_arm1, label %match118123_arm1, label %match118123_next1
match118123_arm1:
  %v5_arm1_payload = getelementptr inbounds %sollang.enum.t1167, ptr %v5_subject_slot, i32 0, i32 1
  %v21 = load %sollang.text, ptr %v5_arm1_payload, align 8
  %v23 = freeze %sollang.text %v21
  store %sollang.text %v21, ptr %v5_result, align 8
  br label %match118123_merge
match118123_next1:
  call void @llvm.trap()
  unreachable
match118123_merge:
  %v5 = load %sollang.text, ptr %v5_result, align 8
  ret %sollang.text %v5
}
define %sollang.text @sollang_x0001070108657869745465787422010865786974546578740104636F646518013A0103496E7416022D3E010454657874(i32 %arg) {
entry:
  %if5_result = alloca %sollang.text, align 8
  %while6_v7 = icmp sle i32 %arg, 0
  br i1 %while6_v7, label %while6_body, label %while6_exit
while6_body:
  %v10_ptr = insertvalue %sollang.text poison, ptr @sollang_str_x0001070108657869745465787422010865786974546578740104636F646518013A0103496E7416022D3E010454657874_00, 0
  %v10 = insertvalue %sollang.text %v10_ptr, i64 6, 1
  store %sollang.text %v10, ptr %if5_result, align 8
  br label %when5_end
while6_exit:
  %v12_ptr = insertvalue %sollang.text poison, ptr @sollang_str_x0001070108657869745465787422010865786974546578740104636F646518013A0103496E7416022D3E010454657874_01, 0
  %v12 = insertvalue %sollang.text %v12_ptr, i64 12, 1
  store %sollang.text %v12, ptr %if5_result, align 8
  br label %when5_end
when5_end:
  %v5 = load %sollang.text, ptr %if5_result, align 8
  ret %sollang.text %v5
}
; sollang.codegen.unit 1:sys.process
; sollang.codegen.key 9991274762956626912:6501433182353577892
define %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 @sollang_x0B7379732E70726F6365737301070107636F6D6D616E643001067075626C69630107636F6D6D616E64010770726F6772616D18013A01045465787416022D3E0107436F6D6D616E64(%sollang.text %arg) {
entry:
  %v6_ptr = insertvalue %sollang.text poison, ptr @sollang_str_x0B7379732E70726F6365737301070107636F6D6D616E643001067075626C69630107636F6D6D616E64010770726F6772616D18013A01045465787416022D3E0107436F6D6D616E64_00, 0
  %v6 = insertvalue %sollang.text %v6_ptr, i64 0, 1
  %heap_v8 = inttoptr i64 0 to ptr
  %v8_data = getelementptr i8, ptr %heap_v8, i64 0
  %v8_0 = insertvalue %sollang.array.i32 poison, ptr %v8_data, 0
  %v8_1 = insertvalue %sollang.array.i32 %v8_0, i64 0, 1
  %v8 = insertvalue %sollang.array.i32 %v8_1, i64 0, 2
  %v10_enum_slot = alloca %sollang.enum.t600, align 8
  store %sollang.enum.t600 zeroinitializer, ptr %v10_enum_slot, align 8
  %v10_enum_tag = getelementptr inbounds %sollang.enum.t600, ptr %v10_enum_slot, i32 0, i32 0
  store i32 0, ptr %v10_enum_tag, align 4
  %v10 = load %sollang.enum.t600, ptr %v10_enum_slot, align 8
  %v11_enum_slot = alloca %sollang.enum.t601, align 8
  store %sollang.enum.t601 zeroinitializer, ptr %v11_enum_slot, align 8
  %v11_enum_tag = getelementptr inbounds %sollang.enum.t601, ptr %v11_enum_slot, i32 0, i32 0
  store i32 0, ptr %v11_enum_tag, align 4
  %v11 = load %sollang.enum.t601, ptr %v11_enum_slot, align 8
  %v12_enum_slot = alloca %sollang.enum.t601, align 8
  store %sollang.enum.t601 zeroinitializer, ptr %v12_enum_slot, align 8
  %v12_enum_tag = getelementptr inbounds %sollang.enum.t601, ptr %v12_enum_slot, i32 0, i32 0
  store i32 0, ptr %v12_enum_tag, align 4
  %v12 = load %sollang.enum.t601, ptr %v12_enum_slot, align 8
  %heap_v4 = call ptr @sollang_alloc(i64 16)
  %v4_data = getelementptr i8, ptr %heap_v4, i64 0
  %v4_allocation_ok = icmp ne ptr %v4_data, null
  br i1 %v4_allocation_ok, label %v4_allocation_ready, label %v4_allocation_failed
v4_allocation_failed:
  %v4_allocation_diagnostic = alloca [49 x i8], align 1
  store [49 x i8] c"\73\79\73\2E\70\72\6F\63\65\73\73\2E\73\79\73\2E\70\72\6F\63\65\73\73\2E\63\6F\6D\6D\61\6E\64\3A\61\6C\6C\6F\63\61\74\69\6F\6E\5F\66\61\69\6C\65\64", ptr %v4_allocation_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v4_allocation_diagnostic, i64 49, i1 false)
  call void @llvm.trap()
  unreachable
v4_allocation_ready:
  %v4_ptr0 = getelementptr %sollang.text, ptr %v4_data, i64 0
  store %sollang.text %arg, ptr %v4_ptr0, align 8
  %v4_0 = insertvalue %sollang.array.i32 poison, ptr %v4_data, 0
  %v4_1 = insertvalue %sollang.array.i32 %v4_0, i64 1, 1
  %v4 = insertvalue %sollang.array.i32 %v4_1, i64 1, 2
  %v3_f0 = insertvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 poison, %sollang.array.i32 %v4, 0
  %v3_f1 = insertvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %v3_f0, %sollang.text { ptr @sollang_str_x0B7379732E70726F6365737301070107636F6D6D616E643001067075626C69630107636F6D6D616E64010770726F6772616D18013A01045465787416022D3E0107436F6D6D616E64_00, i64 0 }, 1
  %v3_f2 = insertvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %v3_f1, i1 0, 2
  %v3_f3 = insertvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %v3_f2, %sollang.array.i32 %v8, 3
  %v3_f4 = insertvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %v3_f3, i1 1, 4
  %v3_f5 = insertvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %v3_f4, %sollang.enum.t600 %v10, 5
  %v3_f6 = insertvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %v3_f5, %sollang.enum.t601 %v11, 6
  %v3 = insertvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %v3_f6, %sollang.enum.t601 %v12, 7
  ret %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %v3
}
define void @sollang_x0B7379732E70726F6365737302060107436F6D6D616E640F0104696D706C0107436F6D6D616E641F01036172673801067075626C6963010361726718013A01036D7574010473656C660E012C010576616C756518013A01045465787416022D3E0104556E6974(ptr %arg_mut_struct, %sollang.text %arg1) {
entry:
  %arg = load %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400, ptr %arg_mut_struct, align 8
  %v6 = load %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400, ptr %arg_mut_struct, align 8
  %v7 = freeze %sollang.text %arg1
  %v5 = extractvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %v6, 0
  %push4_data = extractvalue %sollang.array.i32 %v5, 0
  %push4_length = extractvalue %sollang.array.i32 %v5, 1
  %push4_capacity = extractvalue %sollang.array.i32 %v5, 2
  %push4_full = icmp eq i64 %push4_length, %push4_capacity
  %push4_empty = icmp eq i64 %push4_capacity, 0
  %push4_doubled = mul i64 %push4_capacity, 2
  %push4_grown_capacity = select i1 %push4_empty, i64 4, i64 %push4_doubled
  %push4_append_capacity = select i1 %push4_full, i64 %push4_grown_capacity, i64 %push4_capacity
  %push4_append_bytes = mul i64 %push4_append_capacity, 16
  br i1 %push4_full, label %push4_grow, label %push4_keep
push4_keep:
  br label %push4_ready
push4_grow:
  %push4_grown_data = call ptr @sollang_alloc(i64 %push4_append_bytes)
  %push4_allocated = icmp ne ptr %push4_grown_data, null
  br i1 %push4_allocated, label %push4_copy, label %push4_allocation_failed
push4_allocation_failed:
  call void @llvm.trap()
  unreachable
push4_copy:
  %push4_copy_bytes = mul i64 %push4_length, 16
  call void @llvm.memcpy.p0.p0.i64(ptr %push4_grown_data, ptr %push4_data, i64 %push4_copy_bytes, i1 false)
  call void @sollang_free(ptr %push4_data)
  br label %push4_ready
push4_ready:
  %push4_append_data = phi ptr [ %push4_data, %push4_keep ], [ %push4_grown_data, %push4_copy ]
  %push4_slot = getelementptr %sollang.text, ptr %push4_append_data, i64 %push4_length
  store %sollang.text %arg1, ptr %push4_slot, align 8
  %push4_new_length = add i64 %push4_length, 1
  %push4_array0 = insertvalue %sollang.array.i32 poison, ptr %push4_append_data, 0
  %push4_array1 = insertvalue %sollang.array.i32 %push4_array0, i64 %push4_new_length, 1
  %push4_array2 = insertvalue %sollang.array.i32 %push4_array1, i64 %push4_append_capacity, 2
  %callref4_arg0_place0 = getelementptr inbounds %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400, ptr %arg_mut_struct, i32 0, i32 0
  store %sollang.array.i32 %push4_array2, ptr %callref4_arg0_place0, align 8
  ret void
}
define void @sollang_x0B7379732E70726F6365737302060107436F6D6D616E640F0104696D706C0107436F6D6D616E641F0104617267734B01067075626C696301046172677318013A01036D7574010473656C660E012C010676616C75657318013A01036D757407015B0104546578740F013B0C017E08015D16022D3E0104556E6974(ptr %arg_mut_struct, %sollang.mutable_container %arg1_borrow) {
entry:
  %arg = load %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400, ptr %arg_mut_struct, align 8
  %arg1_mut_ptr_addr = extractvalue %sollang.mutable_container %arg1_borrow, 0
  %arg1_mut_len_addr = extractvalue %sollang.mutable_container %arg1_borrow, 1
  %arg1_mut_capacity_addr = extractvalue %sollang.mutable_container %arg1_borrow, 2
  %arg1_mut_ptr = load ptr, ptr %arg1_mut_ptr_addr, align 8
  %arg1_mut_len = load i64, ptr %arg1_mut_len_addr, align 8
  %arg1_mut_capacity = load i64, ptr %arg1_mut_capacity_addr, align 8
  %arg1_value0 = insertvalue %sollang.array.i32 poison, ptr %arg1_mut_ptr, 0
  %arg1_value1 = insertvalue %sollang.array.i32 %arg1_value0, i64 %arg1_mut_len, 1
  %arg1 = insertvalue %sollang.array.i32 %arg1_value1, i64 %arg1_mut_capacity, 2
  %slot4 = alloca i32, align 4
  %v8_current_ptr = load ptr, ptr %arg1_mut_ptr_addr, align 8
  %v8_current_len = load i64, ptr %arg1_mut_len_addr, align 8
  %v8_current_capacity = load i64, ptr %arg1_mut_capacity_addr, align 8
  %v8_current0 = insertvalue %sollang.array.i32 poison, ptr %v8_current_ptr, 0
  %v8_current1 = insertvalue %sollang.array.i32 %v8_current0, i64 %v8_current_len, 1
  %v8 = insertvalue %sollang.array.i32 %v8_current1, i64 %v8_current_capacity, 2
  %v7_raw = load i64, ptr %arg1_mut_len_addr, align 8
  %v7 = trunc i64 %v7_raw to i32
  store i32 %v7, ptr %slot4, align 4
  br label %while13_header
while13_header:
  %while13_v11 = load i32, ptr %slot4, align 4
  %while13_v10 = icmp sgt i32 %while13_v11, 0
  br i1 %while13_v10, label %while13_body, label %while13_exit
while13_body:
  %v16_current_ptr = load ptr, ptr %arg1_mut_ptr_addr, align 8
  %v16_current_len = load i64, ptr %arg1_mut_len_addr, align 8
  %v16_current_capacity = load i64, ptr %arg1_mut_capacity_addr, align 8
  %v16_current0 = insertvalue %sollang.array.i32 poison, ptr %v16_current_ptr, 0
  %v16_current1 = insertvalue %sollang.array.i32 %v16_current0, i64 %v16_current_len, 1
  %v16 = insertvalue %sollang.array.i32 %v16_current1, i64 %v16_current_capacity, 2
  %take15_data = load ptr, ptr %arg1_mut_ptr_addr, align 8
  %take15_length = load i64, ptr %arg1_mut_len_addr, align 8
  %take15_capacity = load i64, ptr %arg1_mut_capacity_addr, align 8
  %take15_in_bounds = icmp ult i64 0, %take15_length
  br i1 %take15_in_bounds, label %take15_ready, label %take15_missing
take15_missing:
  call void @llvm.trap()
  unreachable
take15_ready:
  %take15_selected = add i64 0, 0
  %take15_value_ptr = getelementptr %sollang.text, ptr %take15_data, i64 %take15_selected
  %v15 = load %sollang.text, ptr %take15_value_ptr, align 8
  %take15_new_length = sub i64 %take15_length, 1
  br label %take15_shift
take15_shift:
  %take15_shift_index = phi i64 [ %take15_selected, %take15_ready ], [ %take15_shift_next, %take15_shift_body ]
  %take15_shift_active = icmp ult i64 %take15_shift_index, %take15_new_length
  br i1 %take15_shift_active, label %take15_shift_body, label %take15_done
take15_shift_body:
  %take15_shift_next = add i64 %take15_shift_index, 1
  %take15_source_ptr = getelementptr %sollang.text, ptr %take15_data, i64 %take15_shift_next
  %take15_moved = load %sollang.text, ptr %take15_source_ptr, align 8
  %take15_target_ptr = getelementptr %sollang.text, ptr %take15_data, i64 %take15_shift_index
  store %sollang.text %take15_moved, ptr %take15_target_ptr, align 8
  br label %take15_shift
take15_done:
  %take15_array0 = insertvalue %sollang.array.i32 poison, ptr %take15_data, 0
  %take15_array1 = insertvalue %sollang.array.i32 %take15_array0, i64 %take15_new_length, 1
  %take15_array2 = insertvalue %sollang.array.i32 %take15_array1, i64 %take15_capacity, 2
  store ptr %take15_data, ptr %arg1_mut_ptr_addr, align 8
  store i64 %take15_new_length, ptr %arg1_mut_len_addr, align 8
  store i64 %take15_capacity, ptr %arg1_mut_capacity_addr, align 8
  %v20 = load %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400, ptr %arg_mut_struct, align 8
  %v21 = freeze %sollang.text %v15
  %v19 = extractvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %v20, 0
  %push18_data = extractvalue %sollang.array.i32 %v19, 0
  %push18_length = extractvalue %sollang.array.i32 %v19, 1
  %push18_capacity = extractvalue %sollang.array.i32 %v19, 2
  %push18_full = icmp eq i64 %push18_length, %push18_capacity
  %push18_empty = icmp eq i64 %push18_capacity, 0
  %push18_doubled = mul i64 %push18_capacity, 2
  %push18_grown_capacity = select i1 %push18_empty, i64 4, i64 %push18_doubled
  %push18_append_capacity = select i1 %push18_full, i64 %push18_grown_capacity, i64 %push18_capacity
  %push18_append_bytes = mul i64 %push18_append_capacity, 16
  br i1 %push18_full, label %push18_grow, label %push18_keep
push18_keep:
  br label %push18_ready
push18_grow:
  %push18_grown_data = call ptr @sollang_alloc(i64 %push18_append_bytes)
  %push18_allocated = icmp ne ptr %push18_grown_data, null
  br i1 %push18_allocated, label %push18_copy, label %push18_allocation_failed
push18_allocation_failed:
  call void @llvm.trap()
  unreachable
push18_copy:
  %push18_copy_bytes = mul i64 %push18_length, 16
  call void @llvm.memcpy.p0.p0.i64(ptr %push18_grown_data, ptr %push18_data, i64 %push18_copy_bytes, i1 false)
  call void @sollang_free(ptr %push18_data)
  br label %push18_ready
push18_ready:
  %push18_append_data = phi ptr [ %push18_data, %push18_keep ], [ %push18_grown_data, %push18_copy ]
  %push18_slot = getelementptr %sollang.text, ptr %push18_append_data, i64 %push18_length
  store %sollang.text %v21, ptr %push18_slot, align 8
  %push18_new_length = add i64 %push18_length, 1
  %push18_array0 = insertvalue %sollang.array.i32 poison, ptr %push18_append_data, 0
  %push18_array1 = insertvalue %sollang.array.i32 %push18_array0, i64 %push18_new_length, 1
  %push18_array2 = insertvalue %sollang.array.i32 %push18_array1, i64 %push18_append_capacity, 2
  %callref18_arg0_place0 = getelementptr inbounds %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400, ptr %arg_mut_struct, i32 0, i32 0
  store %sollang.array.i32 %push18_array2, ptr %callref18_arg0_place0, align 8
  %v23 = load i32, ptr %slot4, align 4
  %v22 = sub i32 %v23, 1
  store i32 %v22, ptr %slot4, align 4
  br label %while13_header
while13_exit:
  ret void
}
define %sollang.enum.t1167 @sollang_x0B7379732E70726F6365737302060107436F6D6D616E640F0104696D706C0107436F6D6D616E641F01067374617475735501067075626C6963010673746174757318013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010A457869745374617475730E012C0104546578741F013E010475736573010750726F63657373(%sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %arg) {
entry:
  %v6_subject_slot = alloca %sollang.enum.t888, align 8
  %v6_result = alloca %sollang.enum.t1167, align 8
  %v4_process_argv = extractvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %arg, 0
  %v4_process_records = extractvalue %sollang.array.i32 %v4_process_argv, 0
  %v4_process_count = extractvalue %sollang.array.i32 %v4_process_argv, 1
  %v4_process_working_directory = extractvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %arg, 1
  %v4_process_working_directory_ptr = extractvalue %sollang.text %v4_process_working_directory, 0
  %v4_process_working_directory_len = extractvalue %sollang.text %v4_process_working_directory, 1
  %v4_process_has_working_directory = extractvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %arg, 2
  %v4_process_environment_changes = extractvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %arg, 3
  %v4_process_environment_change_records = extractvalue %sollang.array.i32 %v4_process_environment_changes, 0
  %v4_process_environment_change_count = extractvalue %sollang.array.i32 %v4_process_environment_changes, 1
  %v4_process_inherits_environment = extractvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %arg, 4
  %v4_process_stdin = extractvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %arg, 5
  %v4_process_stdin_mode = extractvalue %sollang.enum.t600 %v4_process_stdin, 0
  %v4_process_stdin_slot = alloca %sollang.enum.t600, align 8
  store %sollang.enum.t600 %v4_process_stdin, ptr %v4_process_stdin_slot, align 8
  %v4_process_stdin_path_address = getelementptr inbounds %sollang.enum.t600, ptr %v4_process_stdin_slot, i32 0, i32 1
  %v4_process_stdin_path = load %sollang.text, ptr %v4_process_stdin_path_address, align 8
  %v4_process_stdin_path_ptr = extractvalue %sollang.text %v4_process_stdin_path, 0
  %v4_process_stdin_path_len = extractvalue %sollang.text %v4_process_stdin_path, 1
  %v4_process_stdout = extractvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %arg, 6
  %v4_process_stdout_mode = extractvalue %sollang.enum.t601 %v4_process_stdout, 0
  %v4_process_stdout_slot = alloca %sollang.enum.t601, align 8
  store %sollang.enum.t601 %v4_process_stdout, ptr %v4_process_stdout_slot, align 8
  %v4_process_stdout_path_address = getelementptr inbounds %sollang.enum.t601, ptr %v4_process_stdout_slot, i32 0, i32 1
  %v4_process_stdout_path = load %sollang.text, ptr %v4_process_stdout_path_address, align 8
  %v4_process_stdout_path_ptr = extractvalue %sollang.text %v4_process_stdout_path, 0
  %v4_process_stdout_path_len = extractvalue %sollang.text %v4_process_stdout_path, 1
  %v4_process_stderr = extractvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %arg, 7
  %v4_process_stderr_mode = extractvalue %sollang.enum.t601 %v4_process_stderr, 0
  %v4_process_stderr_slot = alloca %sollang.enum.t601, align 8
  store %sollang.enum.t601 %v4_process_stderr, ptr %v4_process_stderr_slot, align 8
  %v4_process_stderr_path_address = getelementptr inbounds %sollang.enum.t601, ptr %v4_process_stderr_slot, i32 0, i32 1
  %v4_process_stderr_path = load %sollang.text, ptr %v4_process_stderr_path_address, align 8
  %v4_process_stderr_path_ptr = extractvalue %sollang.text %v4_process_stderr_path, 0
  %v4_process_stderr_path_len = extractvalue %sollang.text %v4_process_stderr_path, 1
  %v4_process_raw = call %sollang.process_result @sollang_run_process_configured(ptr %v4_process_records, i64 %v4_process_count, ptr %v4_process_working_directory_ptr, i64 %v4_process_working_directory_len, i1 %v4_process_has_working_directory, ptr %v4_process_environment_change_records, i64 %v4_process_environment_change_count, i1 %v4_process_inherits_environment, i32 %v4_process_stdin_mode, ptr %v4_process_stdin_path_ptr, i64 %v4_process_stdin_path_len, i32 %v4_process_stdout_mode, ptr %v4_process_stdout_path_ptr, i64 %v4_process_stdout_path_len, i32 %v4_process_stderr_mode, ptr %v4_process_stderr_path_ptr, i64 %v4_process_stderr_path_len)
  %v4_process_value = extractvalue %sollang.process_result %v4_process_raw, 0
  %v4_process_error = extractvalue %sollang.process_result %v4_process_raw, 1
  %v4_process_ok = icmp eq i32 %v4_process_error, 0
  %v4_process_result_slot = alloca %sollang.enum.t888, align 8
  store %sollang.enum.t888 zeroinitializer, ptr %v4_process_result_slot, align 8
  br i1 %v4_process_ok, label %process117027_ok, label %process117027_error
process117027_ok:
  %v4_process_ok_tag = getelementptr inbounds %sollang.enum.t888, ptr %v4_process_result_slot, i32 0, i32 0
  store i32 0, ptr %v4_process_ok_tag, align 4
  %v4_process_ok_payload = getelementptr inbounds %sollang.enum.t888, ptr %v4_process_result_slot, i32 0, i32 1
  store i32 %v4_process_value, ptr %v4_process_ok_payload, align 4
  br label %process117027_merge
process117027_error:
  %v4_process_error_tag = getelementptr inbounds %sollang.enum.t888, ptr %v4_process_result_slot, i32 0, i32 0
  store i32 1, ptr %v4_process_error_tag, align 4
  %v4_process_is_wait = icmp eq i32 %v4_process_error, 2
  %v4_process_is_signal = icmp eq i32 %v4_process_error, 3
  %v4_process_is_capture = icmp eq i32 %v4_process_error, 4
  %v4_process_wait_ptr = select i1 %v4_process_is_wait, ptr @sollang_process_error_wait, ptr @sollang_process_error_spawn
  %v4_process_wait_len = select i1 %v4_process_is_wait, i64 4, i64 5
  %v4_process_signal_ptr = select i1 %v4_process_is_signal, ptr @sollang_process_error_signal, ptr %v4_process_wait_ptr
  %v4_process_signal_len = select i1 %v4_process_is_signal, i64 6, i64 %v4_process_wait_len
  %v4_process_error_ptr = select i1 %v4_process_is_capture, ptr @sollang_process_error_capture, ptr %v4_process_signal_ptr
  %v4_process_error_len = select i1 %v4_process_is_capture, i64 7, i64 %v4_process_signal_len
  %v4_process_error_text0 = insertvalue %sollang.text poison, ptr %v4_process_error_ptr, 0
  %v4_process_error_text = insertvalue %sollang.text %v4_process_error_text0, i64 %v4_process_error_len, 1
  %v4_process_error_payload = getelementptr inbounds %sollang.enum.t888, ptr %v4_process_result_slot, i32 0, i32 1
  store %sollang.text %v4_process_error_text, ptr %v4_process_error_payload, align 8
  br label %process117027_merge
process117027_merge:
  %v4 = load %sollang.enum.t888, ptr %v4_process_result_slot, align 8
  %v6_tag = extractvalue %sollang.enum.t888 %v4, 0
  store %sollang.enum.t888 %v4, ptr %v6_subject_slot, align 8
  %v6_is_arm0 = icmp eq i32 %v6_tag, 0
  br i1 %v6_is_arm0, label %match117029_arm0, label %match117029_next0
match117029_arm0:
  %v6_arm0_payload = getelementptr inbounds %sollang.enum.t888, ptr %v6_subject_slot, i32 0, i32 1
  %v9 = load i32, ptr %v6_arm0_payload, align 4
  %v13 = freeze i32 %v9
  %v12 = insertvalue %sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 poison, i32 %v13, 0
  %v11_enum_slot = alloca %sollang.enum.t1167, align 8
  store %sollang.enum.t1167 zeroinitializer, ptr %v11_enum_slot, align 8
  %v11_enum_tag = getelementptr inbounds %sollang.enum.t1167, ptr %v11_enum_slot, i32 0, i32 0
  store i32 0, ptr %v11_enum_tag, align 4
  %v11_enum_payload = getelementptr inbounds %sollang.enum.t1167, ptr %v11_enum_slot, i32 0, i32 1
  store %sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 %v12, ptr %v11_enum_payload, align 4
  %v11 = load %sollang.enum.t1167, ptr %v11_enum_slot, align 8
  store %sollang.enum.t1167 %v11, ptr %v6_result, align 8
  br label %match117029_merge
match117029_next0:
  %v6_is_arm1 = icmp eq i32 %v6_tag, 1
  br i1 %v6_is_arm1, label %match117029_arm1, label %match117029_next1
match117029_arm1:
  %v6_arm1_payload = getelementptr inbounds %sollang.enum.t888, ptr %v6_subject_slot, i32 0, i32 1
  %v16 = load %sollang.text, ptr %v6_arm1_payload, align 8
  %v19 = freeze %sollang.text %v16
  %v18_enum_slot = alloca %sollang.enum.t1167, align 8
  store %sollang.enum.t1167 zeroinitializer, ptr %v18_enum_slot, align 8
  %v18_enum_tag = getelementptr inbounds %sollang.enum.t1167, ptr %v18_enum_slot, i32 0, i32 0
  store i32 1, ptr %v18_enum_tag, align 4
  %v18_enum_payload = getelementptr inbounds %sollang.enum.t1167, ptr %v18_enum_slot, i32 0, i32 1
  store %sollang.text %v16, ptr %v18_enum_payload, align 8
  %v18 = load %sollang.enum.t1167, ptr %v18_enum_slot, align 8
  store %sollang.enum.t1167 %v18, ptr %v6_result, align 8
  br label %match117029_merge
match117029_next1:
  call void @llvm.trap()
  unreachable
match117029_merge:
  %v6 = load %sollang.enum.t1167, ptr %v6_result, align 8
  ret %sollang.enum.t1167 %v6
}
define i64 @sollang_x0B7379732E70726F6365737302060107436F6D6D616E640F0104696D706C0107436F6D6D616E641F010D617267756D656E74436F756E742E01067075626C6963010D617267756D656E74436F756E7418013A010473656C6616022D3E010855496E7453697A65(%sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %arg) {
entry:
  %v5 = extractvalue %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %arg, 0
  %v4_raw = extractvalue %sollang.array.i32 %v5, 1
  %v4 = trunc i64 %v4_raw to i32
  %v3_conversion_lower_valid = icmp sge i32 %v4, 0
  br i1 %v3_conversion_lower_valid, label %v3_conversion_lower_ok, label %v3_conversion_lower_fail
v3_conversion_lower_fail:
  %v3_conversion_lower_diagnostic = alloca [70 x i8], align 1
  store [70 x i8] c"\73\79\73\2E\70\72\6F\63\65\73\73\2E\73\79\73\2E\70\72\6F\63\65\73\73\2E\43\6F\6D\6D\61\6E\64\2E\61\72\67\75\6D\65\6E\74\43\6F\75\6E\74\3A\6E\75\6D\65\72\69\63\5F\63\6F\6E\76\65\72\73\69\6F\6E\5F\6C\6F\77\65\72", ptr %v3_conversion_lower_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v3_conversion_lower_diagnostic, i64 70, i1 false)
  call void @llvm.trap()
  unreachable
v3_conversion_lower_ok:
  %v3 = sext i32 %v4 to i64
  ret i64 %v3
}
define i32 @sollang_x0B7379732E70726F636573730206010A45786974537461747573120104696D706C010A457869745374617475731F010865786974436F64652401067075626C6963010865786974436F646518013A010473656C6616022D3E0103496E74(%sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 %arg) {
entry:
  %v3 = extractvalue %sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 %arg, 0
  ret i32 %v3
}
define i1 @sollang_x0B7379732E70726F636573730206010A45786974537461747573120104696D706C010A457869745374617475731F01097375636365656465642601067075626C6963010973756363656564656418013A010473656C6616022D3E0104426F6F6C(%sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 %arg) {
entry:
  %v4 = extractvalue %sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 %arg, 0
  %v3 = icmp eq i32 %v4, 0
  ret i1 %v3
}
; sollang.codegen.unit 2:
; sollang.codegen.key 10997868353068918418:10282058026031920408
define i32 @sollang_start() {
entry:
  %stack_slot0 = alloca [24 x i8], align 8
  %calltext118186_arg0_root0_buffer = alloca [21 x i8], align 1
  %arguments_ok = call i32 @sollang_init_arguments()
  %arguments_valid = icmp ne i32 %arguments_ok, 0
  %slot5 = alloca %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400, align 8
  %slot6 = getelementptr i8, ptr %stack_slot0, i64 0
  %v10 = call i64 @sollang_argument_count()
  %v12 = freeze i64 %v10
  %v11 = call i64 @sollang_argument_count()
  %v15 = freeze i64 %v11
  %v14 = icmp ugt i64 %v15, 1
  br i1 %v14, label %if17_then, label %if17_else
if17_then:
  %v20 = freeze i64 %v10
  %v19 = call %sollang.text @sollang_argument(i64 2)
  %v23 = freeze i64 %v10
  %v22 = call %sollang.text @sollang_argument(i64 3)
  %v26_ptr = insertvalue %sollang.text poison, ptr @sollang_str_entry_00, 0
  %v26 = insertvalue %sollang.text %v26_ptr, i64 13, 1
  %v25_expression_literal0 = getelementptr i8, ptr @sollang_str_entry_00, i64 0
  call void @sollang_runtime_print(ptr %v25_expression_literal0, i64 6, i1 false)
  %v25_expression0_text_ptr = extractvalue %sollang.text %v19, 0
  %v25_expression0_text_len = extractvalue %sollang.text %v19, 1
  call void @sollang_runtime_print(ptr %v25_expression0_text_ptr, i64 %v25_expression0_text_len, i1 false)
  %v25_expression_suffix = getelementptr i8, ptr @sollang_str_entry_00, i64 13
  call void @sollang_runtime_print(ptr %v25_expression_suffix, i64 0, i1 true)
  %v28_ptr = insertvalue %sollang.text poison, ptr @sollang_str_entry_01, 0
  %v28 = insertvalue %sollang.text %v28_ptr, i64 14, 1
  %v27_expression_literal0 = getelementptr i8, ptr @sollang_str_entry_01, i64 0
  call void @sollang_runtime_print(ptr %v27_expression_literal0, i64 6, i1 false)
  %v27_expression1_text_ptr = extractvalue %sollang.text %v22, 0
  %v27_expression1_text_len = extractvalue %sollang.text %v22, 1
  call void @sollang_runtime_print(ptr %v27_expression1_text_ptr, i64 %v27_expression1_text_len, i1 false)
  %v27_expression_suffix = getelementptr i8, ptr @sollang_str_entry_01, i64 14
  call void @sollang_runtime_print(ptr %v27_expression_suffix, i64 0, i1 true)
  br label %if17_merge
if17_else:
  %v32 = freeze i64 %v10
  %v31 = call %sollang.text @sollang_argument(i64 0)
  %v30 = call %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 @sollang_x0B7379732E70726F6365737301070107636F6D6D616E643001067075626C69630107636F6D6D616E64010770726F6772616D18013A01045465787416022D3E0107436F6D6D616E64(%sollang.text %v31)
  store %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %v30, ptr %slot5, align 8
  %v35_ptr = insertvalue %sollang.text poison, ptr @sollang_str_entry_02, 0
  %v35 = insertvalue %sollang.text %v35_ptr, i64 7, 1
  %v36_ptr = insertvalue %sollang.text poison, ptr @sollang_str_entry_03, 0
  %v36 = insertvalue %sollang.text %v36_ptr, i64 11, 1
  %heap_v34 = call ptr @sollang_alloc(i64 32)
  %v34_data = getelementptr i8, ptr %heap_v34, i64 0
  %v34_allocation_ok = icmp ne ptr %v34_data, null
  br i1 %v34_allocation_ok, label %v34_allocation_ready, label %v34_allocation_failed
v34_allocation_failed:
  %v34_allocation_diagnostic = alloca [22 x i8], align 1
  store [22 x i8] c"\6D\61\69\6E\3A\61\6C\6C\6F\63\61\74\69\6F\6E\5F\66\61\69\6C\65\64", ptr %v34_allocation_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v34_allocation_diagnostic, i64 22, i1 false)
  call void @llvm.trap()
  unreachable
v34_allocation_ready:
  %v34_ptr0 = getelementptr %sollang.text, ptr %v34_data, i64 0
  store %sollang.text %v35, ptr %v34_ptr0, align 8
  %v34_ptr1 = getelementptr %sollang.text, ptr %v34_data, i64 1
  store %sollang.text %v36, ptr %v34_ptr1, align 8
  %v34_0 = insertvalue %sollang.array.i32 poison, ptr %v34_data, 0
  %v34_1 = insertvalue %sollang.array.i32 %v34_0, i64 2, 1
  %v34 = insertvalue %sollang.array.i32 %v34_1, i64 2, 2
  call void @llvm.lifetime.start.p0(i64 24, ptr %stack_slot0)
  store %sollang.array.i32 %v34, ptr %slot6, align 8
  %v38 = load %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400, ptr %slot5, align 8
  %v39 = load %sollang.array.i32, ptr %slot6, align 8
  %callmut118180_arg0 = getelementptr i8, ptr %slot5, i64 0
  %callmut118180_arg1_ptr = getelementptr inbounds %sollang.array.i32, ptr %slot6, i32 0, i32 0
  %callmut118180_arg1_len = getelementptr inbounds %sollang.array.i32, ptr %slot6, i32 0, i32 1
  %callmut118180_arg1_capacity = getelementptr inbounds %sollang.array.i32, ptr %slot6, i32 0, i32 2
  %callmut118180_arg1_0 = insertvalue %sollang.mutable_container poison, ptr %callmut118180_arg1_ptr, 0
  %callmut118180_arg1_1 = insertvalue %sollang.mutable_container %callmut118180_arg1_0, ptr %callmut118180_arg1_len, 1
  %callmut118180_arg1 = insertvalue %sollang.mutable_container %callmut118180_arg1_1, ptr %callmut118180_arg1_capacity, 2
  call void @sollang_x0B7379732E70726F6365737302060107436F6D6D616E640F0104696D706C0107436F6D6D616E641F0104617267734B01067075626C696301046172677318013A01036D7574010473656C660E012C010676616C75657318013A01036D757407015B0104546578740F013B0C017E08015D16022D3E0104556E6974(ptr %callmut118180_arg0, %sollang.mutable_container %callmut118180_arg1)
  %v41 = load %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400, ptr %slot5, align 8
  %v42_ptr = insertvalue %sollang.text poison, ptr @sollang_str_entry_04, 0
  %v42 = insertvalue %sollang.text %v42_ptr, i64 6, 1
  %callmut118183_arg0 = getelementptr i8, ptr %slot5, i64 0
  call void @sollang_x0B7379732E70726F6365737302060107436F6D6D616E640F0104696D706C0107436F6D6D616E641F01036172673801067075626C6963010361726718013A01036D7574010473656C660E012C010576616C756518013A01045465787416022D3E0104556E6974(ptr %callmut118183_arg0, %sollang.text { ptr @sollang_str_entry_04, i64 6 })
  %v44_ptr = insertvalue %sollang.text poison, ptr @sollang_str_entry_05, 0
  %v44 = insertvalue %sollang.text %v44_ptr, i64 33, 1
  %v43_expression_literal0 = getelementptr i8, ptr @sollang_str_entry_05, i64 0
  call void @sollang_runtime_print(ptr %v43_expression_literal0, i64 5, i1 false)
  %v43_expression3_mutable = load %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400, ptr %slot5, align 8
  %v43_expression2 = call i64 @sollang_x0B7379732E70726F6365737302060107436F6D6D616E640F0104696D706C0107436F6D6D616E641F010D617267756D656E74436F756E742E01067075626C6963010D617267756D656E74436F756E7418013A010473656C6616022D3E010855496E7453697A65(%sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %v43_expression3_mutable)
  call void @sollang_runtime_print_i64(i64 %v43_expression2, i1 false, i1 false)
  %v43_expression_suffix = getelementptr i8, ptr @sollang_str_entry_05, i64 33
  call void @sollang_runtime_print(ptr %v43_expression_suffix, i64 0, i1 true)
  %v46 = load %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400, ptr %slot5, align 8
  %v55 = call %sollang.enum.t1167 @sollang_x0B7379732E70726F6365737302060107436F6D6D616E640F0104696D706C0107436F6D6D616E641F01067374617475735501067075626C6963010673746174757318013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010A457869745374617475730E012C0104546578741F013E010475736573010750726F63657373(%sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %v46)
  %v45 = call %sollang.text @sollang_x000107010864657363726962654E010864657363726962650106726573756C7418013A0106526573756C741E013C010770726F636573730D012E010A457869745374617475730E012C0104546578741F013E16022D3E010454657874(%sollang.enum.t1167 %v55)
  call void @sollang_drop_t1167(%sollang.enum.t1167 %v55)
  %v48 = freeze %sollang.text %v45
  %v47_runtime_ptr = extractvalue %sollang.text %v48, 0
  %v47_runtime_len = extractvalue %sollang.text %v48, 1
  call void @sollang_runtime_print(ptr %v47_runtime_ptr, i64 %v47_runtime_len, i1 true)
  %v50_ptr = insertvalue %sollang.text poison, ptr @sollang_str_entry_06, 0
  %v50 = insertvalue %sollang.text %v50_ptr, i64 37, 1
  %v49 = call %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 @sollang_x0B7379732E70726F6365737301070107636F6D6D616E643001067075626C69630107636F6D6D616E64010770726F6772616D18013A01045465787416022D3E0107436F6D6D616E64(%sollang.text { ptr @sollang_str_entry_06, i64 37 })
  %v52 = freeze %sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %v49
  %v56 = call %sollang.enum.t1167 @sollang_x0B7379732E70726F6365737302060107436F6D6D616E640F0104696D706C0107436F6D6D616E641F01067374617475735501067075626C6963010673746174757318013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010A457869745374617475730E012C0104546578741F013E010475736573010750726F63657373(%sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 %v52)
  %v51 = call %sollang.text @sollang_x000107010864657363726962654E010864657363726962650106726573756C7418013A0106526573756C741E013C010770726F636573730D012E010A457869745374617475730E012C0104546578741F013E16022D3E010454657874(%sollang.enum.t1167 %v56)
  call void @sollang_drop_t1167(%sollang.enum.t1167 %v56)
  %v54 = freeze %sollang.text %v51
  %v53_runtime_ptr = extractvalue %sollang.text %v54, 0
  %v53_runtime_len = extractvalue %sollang.text %v54, 1
  call void @sollang_runtime_print(ptr %v53_runtime_ptr, i64 %v53_runtime_len, i1 true)
  %cleanup1181602_b118149_current = load %sollang.array.i32, ptr %slot6, align 8
  call void @sollang_drop_t1165(%sollang.array.i32 %cleanup1181602_b118149_current)
  call void @llvm.lifetime.end.p0(i64 24, ptr %stack_slot0)
  br label %if17_merge
if17_merge:
  call void @sollang_dispose_arguments()
  call void @sollang_runtime_flush_stdout()
  %exit_code = select i1 %arguments_valid, i32 0, i32 1
  ret i32 %exit_code
}
define internal ptr @sollang_process_copy_text(ptr %data, i64 %length) {
entry:
  %capacity = add i64 %length, 1
  %copy = call ptr @sollang_alloc(i64 %capacity)
  %allocated = icmp ne ptr %copy, null
  br i1 %allocated, label %loop, label %fail
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %body ]
  %done = icmp eq i64 %index, %length
  br i1 %done, label %terminate, label %body
body:
  %source = getelementptr i8, ptr %data, i64 %index
  %byte = load i8, ptr %source, align 1
  %destination = getelementptr i8, ptr %copy, i64 %index
  store i8 %byte, ptr %destination, align 1
  %next = add i64 %index, 1
  br label %loop
terminate:
  %null_slot = getelementptr i8, ptr %copy, i64 %length
  store i8 0, ptr %null_slot, align 1
  ret ptr %copy
fail:
  ret ptr null
}
define internal void @sollang_process_dispose_argv(ptr %argv, i64 %count) {
entry:
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %body ]
  %done = icmp eq i64 %index, %count
  br i1 %done, label %finish, label %body
body:
  %slot = getelementptr ptr, ptr %argv, i64 %index
  %value = load ptr, ptr %slot, align 8
  call void @sollang_free(ptr %value)
  %next = add i64 %index, 1
  br label %loop
finish:
  call void @sollang_free(ptr %argv)
  ret void
}
define internal ptr @sollang_process_build_argv(ptr %records, i64 %count) {
entry:
  %slots = add i64 %count, 1
  %bytes = mul i64 %slots, 8
  %argv = call ptr @sollang_alloc(i64 %bytes)
  %allocated = icmp ne ptr %argv, null
  br i1 %allocated, label %loop, label %fail
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %stored ]
  %done = icmp eq i64 %index, %count
  br i1 %done, label %terminate, label %copy
copy:
  %record = getelementptr %sollang.text, ptr %records, i64 %index
  %data_slot = getelementptr inbounds %sollang.text, ptr %record, i32 0, i32 0
  %data = load ptr, ptr %data_slot, align 8
  %length_slot = getelementptr inbounds %sollang.text, ptr %record, i32 0, i32 1
  %length = load i64, ptr %length_slot, align 8
  %value = call ptr @sollang_process_copy_text(ptr %data, i64 %length)
  %copied = icmp ne ptr %value, null
  br i1 %copied, label %stored, label %cleanup
stored:
  %slot = getelementptr ptr, ptr %argv, i64 %index
  store ptr %value, ptr %slot, align 8
  %next = add i64 %index, 1
  br label %loop
cleanup:
  call void @sollang_process_dispose_argv(ptr %argv, i64 %index)
  ret ptr null
terminate:
  %null_slot = getelementptr ptr, ptr %argv, i64 %count
  store ptr null, ptr %null_slot, align 8
  ret ptr %argv
fail:
  ret ptr null
}
define internal i1 @sollang_process_windows_arg_needs_quotes(ptr %source, i32 %chars) {
entry:
  %empty = icmp eq i32 %chars, 0
  br i1 %empty, label %quoted, label %scan
scan:
  %index = phi i32 [ 0, %entry ], [ %next, %advance ]
  %character_ptr = getelementptr i16, ptr %source, i32 %index
  %character = load i16, ptr %character_ptr, align 2
  %quote = icmp eq i16 %character, 34
  %space = icmp eq i16 %character, 32
  %ascii_offset = sub i16 %character, 9
  %ascii_space = icmp ule i16 %ascii_offset, 4
  %next_line = icmp eq i16 %character, 133
  %no_break = icmp eq i16 %character, 160
  %ogham = icmp eq i16 %character, 5760
  %unicode_offset = sub i16 %character, 8192
  %unicode_space = icmp ule i16 %unicode_offset, 10
  %separator_offset = sub i16 %character, 8232
  %separator = icmp ule i16 %separator_offset, 1
  %narrow_no_break = icmp eq i16 %character, 8239
  %medium_space = icmp eq i16 %character, 8287
  %ideographic_space = icmp eq i16 %character, 12288
  %needs0 = or i1 %quote, %space
  %needs1 = or i1 %needs0, %ascii_space
  %needs2 = or i1 %needs1, %next_line
  %needs3 = or i1 %needs2, %no_break
  %needs4 = or i1 %needs3, %ogham
  %needs5 = or i1 %needs4, %unicode_space
  %needs6 = or i1 %needs5, %separator
  %needs7 = or i1 %needs6, %narrow_no_break
  %needs8 = or i1 %needs7, %medium_space
  %needs = or i1 %needs8, %ideographic_space
  br i1 %needs, label %quoted, label %advance
advance:
  %next = add i32 %index, 1
  %done = icmp eq i32 %next, %chars
  br i1 %done, label %plain, label %scan
quoted:
  ret i1 true
plain:
  ret i1 false
}

define internal ptr @sollang_process_quote_windows_arg(ptr %source, i32 %chars) {
entry:
  %chars64 = zext i32 %chars to i64
  %double = mul i64 %chars64, 2
  %capacity = add i64 %double, 3
  %bytes = mul i64 %capacity, 2
  %output = call ptr @sollang_alloc(i64 %bytes)
  %allocated = icmp ne ptr %output, null
  br i1 %allocated, label %initialize, label %fail
initialize:
  %needs_quotes = call i1 @sollang_process_windows_arg_needs_quotes(ptr %source, i32 %chars)
  br i1 %needs_quotes, label %quote_initialize, label %plain_copy
plain_copy:
  %plain_bytes = mul i64 %chars64, 2
  call void @llvm.memcpy.p0.p0.i64(ptr %output, ptr %source, i64 %plain_bytes, i1 false)
  %plain_null = getelementptr i16, ptr %output, i64 %chars64
  store i16 0, ptr %plain_null, align 2
  ret ptr %output
quote_initialize:
  store i16 34, ptr %output, align 2
  %index_slot = alloca i32, align 4
  %output_slot = alloca i64, align 8
  %slashes_slot = alloca i64, align 8
  store i32 0, ptr %index_slot, align 4
  store i64 1, ptr %output_slot, align 8
  store i64 0, ptr %slashes_slot, align 8
  br label %loop
loop:
  %index = load i32, ptr %index_slot, align 4
  %done = icmp eq i32 %index, %chars
  br i1 %done, label %finish_prepare, label %read
read:
  %character_ptr = getelementptr i16, ptr %source, i32 %index
  %character = load i16, ptr %character_ptr, align 2
  %is_slash = icmp eq i16 %character, 92
  br i1 %is_slash, label %remember_slash, label %flush_prepare
remember_slash:
  %slashes = load i64, ptr %slashes_slot, align 8
  %more_slashes = add i64 %slashes, 1
  store i64 %more_slashes, ptr %slashes_slot, align 8
  %slash_next = add i32 %index, 1
  store i32 %slash_next, ptr %index_slot, align 4
  br label %loop
flush_prepare:
  %pending = load i64, ptr %slashes_slot, align 8
  %is_quote = icmp eq i16 %character, 34
  %doubled = mul i64 %pending, 2
  %escaped = add i64 %doubled, 1
  %flush_count = select i1 %is_quote, i64 %escaped, i64 %pending
  br label %flush_loop
flush_loop:
  %flush_index = phi i64 [ 0, %flush_prepare ], [ %flush_next, %flush_body ]
  %flush_done = icmp eq i64 %flush_index, %flush_count
  br i1 %flush_done, label %write_character, label %flush_body
flush_body:
  %flush_output = load i64, ptr %output_slot, align 8
  %flush_ptr = getelementptr i16, ptr %output, i64 %flush_output
  store i16 92, ptr %flush_ptr, align 2
  %flush_output_next = add i64 %flush_output, 1
  store i64 %flush_output_next, ptr %output_slot, align 8
  %flush_next = add i64 %flush_index, 1
  br label %flush_loop
write_character:
  %output_index = load i64, ptr %output_slot, align 8
  %output_ptr = getelementptr i16, ptr %output, i64 %output_index
  store i16 %character, ptr %output_ptr, align 2
  %output_next = add i64 %output_index, 1
  store i64 %output_next, ptr %output_slot, align 8
  store i64 0, ptr %slashes_slot, align 8
  %index_next = add i32 %index, 1
  store i32 %index_next, ptr %index_slot, align 4
  br label %loop
finish_prepare:
  %trailing = load i64, ptr %slashes_slot, align 8
  %finish_count = mul i64 %trailing, 2
  br label %finish_loop
finish_loop:
  %finish_index = phi i64 [ 0, %finish_prepare ], [ %finish_next, %finish_body ]
  %finish_done = icmp eq i64 %finish_index, %finish_count
  br i1 %finish_done, label %close_quote, label %finish_body
finish_body:
  %finish_output = load i64, ptr %output_slot, align 8
  %finish_ptr = getelementptr i16, ptr %output, i64 %finish_output
  store i16 92, ptr %finish_ptr, align 2
  %finish_output_next = add i64 %finish_output, 1
  store i64 %finish_output_next, ptr %output_slot, align 8
  %finish_next = add i64 %finish_index, 1
  br label %finish_loop
close_quote:
  %close_index = load i64, ptr %output_slot, align 8
  %quote_ptr = getelementptr i16, ptr %output, i64 %close_index
  store i16 34, ptr %quote_ptr, align 2
  %null_index = add i64 %close_index, 1
  %null_ptr = getelementptr i16, ptr %output, i64 %null_index
  store i16 0, ptr %null_ptr, align 2
  ret ptr %output
fail:
  ret ptr null
}
define internal ptr @sollang_process_build_windows_argv(ptr %records, i64 %count, ptr %program_slot) {
entry:
  store ptr null, ptr %program_slot, align 8
  %slots = add i64 %count, 1
  %argv_bytes = mul i64 %slots, 8
  %argv = call ptr @sollang_alloc(i64 %argv_bytes)
  %allocated = icmp ne ptr %argv, null
  br i1 %allocated, label %loop, label %fail
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %store ]
  %done = icmp eq i64 %index, %count
  br i1 %done, label %terminate, label %measure
measure:
  %record = getelementptr %sollang.text, ptr %records, i64 %index
  %data_slot = getelementptr inbounds %sollang.text, ptr %record, i32 0, i32 0
  %data = load ptr, ptr %data_slot, align 8
  %length_slot = getelementptr inbounds %sollang.text, ptr %record, i32 0, i32 1
  %length64 = load i64, ptr %length_slot, align 8
  %length_fits = icmp ule i64 %length64, 2147483647
  br i1 %length_fits, label %convert_size, label %cleanup
convert_size:
  %length = trunc i64 %length64 to i32
  %chars = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %length, ptr null, i32 0)
  %chars_valid = icmp sgt i32 %chars, 0
  %empty = icmp eq i32 %length, 0
  %valid = or i1 %chars_valid, %empty
  br i1 %valid, label %allocate_wide, label %cleanup
allocate_wide:
  %chars_with_null = add i32 %chars, 1
  %chars_with_null64 = zext i32 %chars_with_null to i64
  %wide_bytes = mul i64 %chars_with_null64, 2
  %wide = call ptr @sollang_alloc(i64 %wide_bytes)
  %wide_ok = icmp ne ptr %wide, null
  br i1 %wide_ok, label %convert, label %cleanup
convert:
  %written = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %length, ptr %wide, i32 %chars)
  %converted = icmp eq i32 %written, %chars
  br i1 %converted, label %terminate_wide, label %free_wide_error
terminate_wide:
  %wide_end = getelementptr i16, ptr %wide, i32 %chars
  store i16 0, ptr %wide_end, align 2
  %quoted = call ptr @sollang_process_quote_windows_arg(ptr %wide, i32 %chars)
  %quoted_ok = icmp ne ptr %quoted, null
  br i1 %quoted_ok, label %preserve_program, label %free_wide_error
preserve_program:
  %is_program = icmp eq i64 %index, 0
  br i1 %is_program, label %store_program, label %free_unquoted
store_program:
  store ptr %wide, ptr %program_slot, align 8
  br label %store
free_unquoted:
  call void @sollang_free(ptr %wide)
  br label %store
store:
  %slot = getelementptr ptr, ptr %argv, i64 %index
  store ptr %quoted, ptr %slot, align 8
  %next = add i64 %index, 1
  br label %loop
free_wide_error:
  call void @sollang_free(ptr %wide)
  br label %cleanup
cleanup:
  %failed_program = load ptr, ptr %program_slot, align 8
  call void @sollang_free(ptr %failed_program)
  store ptr null, ptr %program_slot, align 8
  call void @sollang_process_dispose_argv(ptr %argv, i64 %index)
  ret ptr null
terminate:
  %null_slot = getelementptr ptr, ptr %argv, i64 %count
  store ptr null, ptr %null_slot, align 8
  ret ptr %argv
fail:
  ret ptr null
}
define internal ptr @sollang_process_windows_text(ptr %data, i64 %length64) {
entry:
  %length_fits = icmp ule i64 %length64, 2147483647
  br i1 %length_fits, label %measure, label %fail
measure:
  %length = trunc i64 %length64 to i32
  %chars = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %length, ptr null, i32 0)
  %chars_valid = icmp sgt i32 %chars, 0
  %empty = icmp eq i32 %length, 0
  %valid = or i1 %chars_valid, %empty
  br i1 %valid, label %allocate, label %fail
allocate:
  %with_null = add i32 %chars, 1
  %with_null64 = zext i32 %with_null to i64
  %bytes = mul i64 %with_null64, 2
  %wide = call ptr @sollang_alloc(i64 %bytes)
  %allocated = icmp ne ptr %wide, null
  br i1 %allocated, label %convert, label %fail
convert:
  %written = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %length, ptr %wide, i32 %chars)
  %converted = icmp eq i32 %written, %chars
  br i1 %converted, label %terminate, label %free_fail
terminate:
  %end = getelementptr i16, ptr %wide, i32 %chars
  store i16 0, ptr %end, align 2
  ret ptr %wide
free_fail:
  call void @sollang_free(ptr %wide)
  br label %fail
fail:
  ret ptr null
}
define internal ptr @sollang_process_windows_path(ptr %data, i64 %length) {
entry:
  %present = icmp ugt i64 %length, 0
  br i1 %present, label %check, label %fail
check:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %done = icmp eq i64 %index, %length
  br i1 %done, label %convert, label %inspect
inspect:
  %byte_ptr = getelementptr i8, ptr %data, i64 %index
  %byte = load i8, ptr %byte_ptr, align 1
  %nul = icmp eq i8 %byte, 0
  br i1 %nul, label %fail, label %advance
advance:
  %next = add i64 %index, 1
  br label %check
convert:
  %wide = call ptr @sollang_process_windows_text(ptr %data, i64 %length)
  ret ptr %wide
fail:
  ret ptr null
}
define internal ptr @sollang_process_join_windows_args(ptr %argv, i64 %count) {
entry:
  %index_slot = alloca i64, align 8
  %offset_slot = alloca i64, align 8
  store i64 0, ptr %index_slot, align 8
  store i64 0, ptr %offset_slot, align 8
  br label %measure_outer
measure_outer:
  %index = load i64, ptr %index_slot, align 8
  %outer_done = icmp eq i64 %index, %count
  br i1 %outer_done, label %allocate, label %measure_inner
measure_inner:
  %character_index = phi i64 [ 0, %measure_outer ], [ %character_next, %measure_more ]
  %argument_slot = getelementptr ptr, ptr %argv, i64 %index
  %argument = load ptr, ptr %argument_slot, align 8
  %character_ptr = getelementptr i16, ptr %argument, i64 %character_index
  %character = load i16, ptr %character_ptr, align 2
  %argument_done = icmp eq i16 %character, 0
  br i1 %argument_done, label %measure_argument_done, label %measure_more
measure_more:
  %character_next = add i64 %character_index, 1
  br label %measure_inner
measure_argument_done:
  %offset = load i64, ptr %offset_slot, align 8
  %needs_space = icmp ne i64 %index, 0
  %space = zext i1 %needs_space to i64
  %with_argument = add i64 %offset, %character_index
  %next_offset = add i64 %with_argument, %space
  store i64 %next_offset, ptr %offset_slot, align 8
  %next_index = add i64 %index, 1
  store i64 %next_index, ptr %index_slot, align 8
  br label %measure_outer
allocate:
  %total = load i64, ptr %offset_slot, align 8
  %with_null = add i64 %total, 1
  %bytes = mul i64 %with_null, 2
  %command = call ptr @sollang_alloc(i64 %bytes)
  %allocated = icmp ne ptr %command, null
  br i1 %allocated, label %copy_setup, label %fail
copy_setup:
  store i64 0, ptr %index_slot, align 8
  store i64 0, ptr %offset_slot, align 8
  br label %copy_outer
copy_outer:
  %copy_index = load i64, ptr %index_slot, align 8
  %copy_done = icmp eq i64 %copy_index, %count
  br i1 %copy_done, label %terminate, label %copy_space
copy_space:
  %copy_offset = load i64, ptr %offset_slot, align 8
  %copy_needs_space = icmp ne i64 %copy_index, 0
  br i1 %copy_needs_space, label %store_space, label %copy_inner
store_space:
  %space_ptr = getelementptr i16, ptr %command, i64 %copy_offset
  store i16 32, ptr %space_ptr, align 2
  %after_space = add i64 %copy_offset, 1
  store i64 %after_space, ptr %offset_slot, align 8
  br label %copy_inner
copy_inner:
  %copy_character_index = phi i64 [ 0, %copy_space ], [ 0, %store_space ], [ %copy_character_next, %copy_more ]
  %copy_argument_slot = getelementptr ptr, ptr %argv, i64 %copy_index
  %copy_argument = load ptr, ptr %copy_argument_slot, align 8
  %copy_character_ptr = getelementptr i16, ptr %copy_argument, i64 %copy_character_index
  %copy_character = load i16, ptr %copy_character_ptr, align 2
  %copy_argument_done = icmp eq i16 %copy_character, 0
  br i1 %copy_argument_done, label %copy_argument_finish, label %copy_more
copy_more:
  %current_offset = load i64, ptr %offset_slot, align 8
  %destination = getelementptr i16, ptr %command, i64 %current_offset
  store i16 %copy_character, ptr %destination, align 2
  %destination_next = add i64 %current_offset, 1
  store i64 %destination_next, ptr %offset_slot, align 8
  %copy_character_next = add i64 %copy_character_index, 1
  br label %copy_inner
copy_argument_finish:
  %copy_index_next = add i64 %copy_index, 1
  store i64 %copy_index_next, ptr %index_slot, align 8
  br label %copy_outer
terminate:
  %final_offset = load i64, ptr %offset_slot, align 8
  %null_ptr = getelementptr i16, ptr %command, i64 %final_offset
  store i16 0, ptr %null_ptr, align 2
  ret ptr %command
fail:
  ret ptr null
}
define internal i64 @sollang_windows_wide_length(ptr %text) {
entry:
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %more ]
  %at = getelementptr i16, ptr %text, i64 %index
  %character = load i16, ptr %at, align 2
  %done = icmp eq i16 %character, 0
  br i1 %done, label %result, label %more
more:
  %next = add i64 %index, 1
  br label %loop
result:
  ret i64 %index
}

define internal i64 @sollang_windows_environment_name_length(ptr %entry) {
entry_block:
  %first = load i16, ptr %entry, align 2
  %hidden = icmp eq i16 %first, 61
  %start = select i1 %hidden, i64 1, i64 0
  br label %loop
loop:
  %index = phi i64 [ %start, %entry_block ], [ %next, %more ]
  %at = getelementptr i16, ptr %entry, i64 %index
  %character = load i16, ptr %at, align 2
  %separator = icmp eq i16 %character, 61
  %end = icmp eq i16 %character, 0
  %done = or i1 %separator, %end
  br i1 %done, label %result, label %more
more:
  %next = add i64 %index, 1
  br label %loop
result:
  ret i64 %index
}

define internal i1 @sollang_windows_environment_text_valid(ptr %data, i64 %length, i1 %name) {
entry:
  br label %loop
loop:
  %index = phi i64 [ 0, %entry ], [ %next, %more ]
  %done = icmp eq i64 %index, %length
  br i1 %done, label %valid, label %inspect
inspect:
  %at = getelementptr i8, ptr %data, i64 %index
  %byte = load i8, ptr %at, align 1
  %nul = icmp eq i8 %byte, 0
  %equal = icmp eq i8 %byte, 61
  %name_equal = and i1 %name, %equal
  %invalid = or i1 %nul, %name_equal
  br i1 %invalid, label %failure, label %more
more:
  %next = add i64 %index, 1
  br label %loop
valid:
  ret i1 true
failure:
  ret i1 false
}

define internal i64 @sollang_windows_latest_environment_change(ptr %entries, ptr %name_lengths, i64 %count, ptr %name, i64 %name_length) {
entry:
  %name_fits = icmp ule i64 %name_length, 2147483647
  br i1 %name_fits, label %loop, label %missing
loop:
  %remaining = phi i64 [ %count, %entry ], [ %index, %different ]
  %done = icmp eq i64 %remaining, 0
  br i1 %done, label %missing, label %inspect
inspect:
  %index = sub i64 %remaining, 1
  %entry_slot = getelementptr ptr, ptr %entries, i64 %index
  %candidate = load ptr, ptr %entry_slot, align 8
  %length_slot = getelementptr i64, ptr %name_lengths, i64 %index
  %candidate_length64 = load i64, ptr %length_slot, align 8
  %candidate_fits = icmp ule i64 %candidate_length64, 2147483647
  br i1 %candidate_fits, label %compare, label %different
compare:
  %candidate_length = trunc i64 %candidate_length64 to i32
  %target_length = trunc i64 %name_length to i32
  %order = call i32 @CompareStringOrdinal(ptr %candidate, i32 %candidate_length, ptr %name, i32 %target_length, i32 1)
  %matches = icmp eq i32 %order, 2
  br i1 %matches, label %found, label %different
different:
  br label %loop
found:
  ret i64 %index
missing:
  ret i64 -1
}

define internal void @sollang_windows_dispose_environment_build(ptr %entries, ptr %name_lengths, ptr %list, i64 %count, ptr %parent) {
entry:
  %has_entries = icmp ne ptr %entries, null
  br i1 %has_entries, label %entry_loop, label %free_arrays
entry_loop:
  %index = phi i64 [ 0, %entry ], [ %next, %entry_more ]
  %entries_done = icmp eq i64 %index, %count
  br i1 %entries_done, label %free_arrays, label %entry_more
entry_more:
  %slot = getelementptr ptr, ptr %entries, i64 %index
  %value = load ptr, ptr %slot, align 8
  call void @sollang_free(ptr %value)
  %next = add i64 %index, 1
  br label %entry_loop
free_arrays:
  call void @sollang_free(ptr %entries)
  call void @sollang_free(ptr %name_lengths)
  call void @sollang_free(ptr %list)
  %has_parent = icmp ne ptr %parent, null
  br i1 %has_parent, label %free_parent, label %cleanup_done
free_parent:
  %parent_freed = call i32 @FreeEnvironmentStringsW(ptr %parent)
  br label %cleanup_done
cleanup_done:
  ret void
}

define internal %sollang.process_environment_result @sollang_windows_build_environment(ptr %changes, i64 %change_count, i1 %inherits) {
entry:
  %has_changes = icmp ne i64 %change_count, 0
  %cleared = xor i1 %inherits, true
  %custom = or i1 %has_changes, %cleared
  br i1 %custom, label %allocate_entries, label %fast
fast:
  %fast0 = insertvalue %sollang.process_environment_result poison, ptr null, 0
  %fast1 = insertvalue %sollang.process_environment_result %fast0, i64 0, 1
  %fast2 = insertvalue %sollang.process_environment_result %fast1, i64 -1, 2
  %fast3 = insertvalue %sollang.process_environment_result %fast2, i1 true, 3
  ret %sollang.process_environment_result %fast3
allocate_entries:
  %entry_slots0 = select i1 %has_changes, i64 %change_count, i64 1
  %entry_bytes = mul i64 %entry_slots0, 8
  %entries = call ptr @sollang_alloc(i64 %entry_bytes)
  %entries_ok = icmp ne ptr %entries, null
  br i1 %entries_ok, label %allocate_lengths, label %failure
allocate_lengths:
  %name_lengths = call ptr @sollang_alloc(i64 %entry_bytes)
  %lengths_ok = icmp ne ptr %name_lengths, null
  br i1 %lengths_ok, label %initialize_entries, label %free_entries_failure
initialize_entries:
  %init_index = phi i64 [ 0, %allocate_lengths ], [ %init_next, %init_more ]
  %init_done = icmp eq i64 %init_index, %change_count
  br i1 %init_done, label %convert_changes, label %init_more
init_more:
  %init_slot = getelementptr ptr, ptr %entries, i64 %init_index
  store ptr null, ptr %init_slot, align 8
  %init_next = add i64 %init_index, 1
  br label %initialize_entries
convert_changes:
  %change_index = phi i64 [ 0, %initialize_entries ], [ %change_next_removed, %store_removed ], [ %change_next_set, %store_set ]
  %changes_done = icmp eq i64 %change_index, %change_count
  br i1 %changes_done, label %parent_select, label %load_change
load_change:
  %change = getelementptr { %sollang.text, %sollang.text, i1 }, ptr %changes, i64 %change_index
  %name_slot = getelementptr inbounds { %sollang.text, %sollang.text, i1 }, ptr %change, i32 0, i32 0
  %name = load %sollang.text, ptr %name_slot, align 8
  %name_data = extractvalue %sollang.text %name, 0
  %name_length = extractvalue %sollang.text %name, 1
  %name_nonempty = icmp ne i64 %name_length, 0
  %name_valid0 = call i1 @sollang_windows_environment_text_valid(ptr %name_data, i64 %name_length, i1 true)
  %name_valid = and i1 %name_nonempty, %name_valid0
  %value_slot = getelementptr inbounds { %sollang.text, %sollang.text, i1 }, ptr %change, i32 0, i32 1
  %value = load %sollang.text, ptr %value_slot, align 8
  %value_data = extractvalue %sollang.text %value, 0
  %value_length = extractvalue %sollang.text %value, 1
  %value_valid = call i1 @sollang_windows_environment_text_valid(ptr %value_data, i64 %value_length, i1 false)
  %text_valid = and i1 %name_valid, %value_valid
  br i1 %text_valid, label %convert_name, label %build_failure
convert_name:
  %wide_name = call ptr @sollang_process_windows_text(ptr %name_data, i64 %name_length)
  %wide_name_ok = icmp ne ptr %wide_name, null
  br i1 %wide_name_ok, label %measure_name, label %build_failure
measure_name:
  %wide_name_length = call i64 @sollang_windows_wide_length(ptr %wide_name)
  %name_length_store = getelementptr i64, ptr %name_lengths, i64 %change_index
  store i64 %wide_name_length, ptr %name_length_store, align 8
  %removed_slot = getelementptr inbounds { %sollang.text, %sollang.text, i1 }, ptr %change, i32 0, i32 2
  %removed = load i1, ptr %removed_slot, align 1
  br i1 %removed, label %store_removed, label %convert_value
store_removed:
  %removed_entry_slot = getelementptr ptr, ptr %entries, i64 %change_index
  store ptr %wide_name, ptr %removed_entry_slot, align 8
  %change_next_removed = add i64 %change_index, 1
  br label %convert_changes
convert_value:
  %wide_value = call ptr @sollang_process_windows_text(ptr %value_data, i64 %value_length)
  %wide_value_ok = icmp ne ptr %wide_value, null
  br i1 %wide_value_ok, label %allocate_entry, label %free_name_failure
allocate_entry:
  %wide_value_length = call i64 @sollang_windows_wide_length(ptr %wide_value)
  %entry_without_end = add i64 %wide_name_length, %wide_value_length
  %entry_chars = add i64 %entry_without_end, 2
  %wide_entry_bytes = mul i64 %entry_chars, 2
  %wide_entry = call ptr @sollang_alloc(i64 %wide_entry_bytes)
  %wide_entry_ok = icmp ne ptr %wide_entry, null
  br i1 %wide_entry_ok, label %copy_entry, label %free_name_value_failure
copy_entry:
  %wide_name_bytes = mul i64 %wide_name_length, 2
  call void @llvm.memcpy.p0.p0.i64(ptr %wide_entry, ptr %wide_name, i64 %wide_name_bytes, i1 false)
  %separator = getelementptr i16, ptr %wide_entry, i64 %wide_name_length
  store i16 61, ptr %separator, align 2
  %value_offset = add i64 %wide_name_length, 1
  %value_destination = getelementptr i16, ptr %wide_entry, i64 %value_offset
  %wide_value_bytes = mul i64 %wide_value_length, 2
  call void @llvm.memcpy.p0.p0.i64(ptr %value_destination, ptr %wide_value, i64 %wide_value_bytes, i1 false)
  %entry_end_offset = add i64 %value_offset, %wide_value_length
  %entry_end = getelementptr i16, ptr %wide_entry, i64 %entry_end_offset
  store i16 0, ptr %entry_end, align 2
  call void @sollang_free(ptr %wide_name)
  call void @sollang_free(ptr %wide_value)
  br label %store_set
store_set:
  %set_entry_slot = getelementptr ptr, ptr %entries, i64 %change_index
  store ptr %wide_entry, ptr %set_entry_slot, align 8
  %change_next_set = add i64 %change_index, 1
  br label %convert_changes
free_name_failure:
  call void @sollang_free(ptr %wide_name)
  br label %build_failure
free_name_value_failure:
  call void @sollang_free(ptr %wide_name)
  call void @sollang_free(ptr %wide_value)
  br label %build_failure
parent_select:
  br i1 %inherits, label %load_parent, label %allocate_list
load_parent:
  %parent = call ptr @GetEnvironmentStringsW()
  %parent_ok = icmp ne ptr %parent, null
  br i1 %parent_ok, label %count_parent, label %build_failure
count_parent:
  %parent_count = phi i64 [ 0, %load_parent ], [ %parent_count_next, %parent_more ]
  %parent_cursor = phi ptr [ %parent, %load_parent ], [ %parent_next, %parent_more ]
  %parent_first = load i16, ptr %parent_cursor, align 2
  %parent_done = icmp eq i16 %parent_first, 0
  br i1 %parent_done, label %allocate_list, label %parent_more
parent_more:
  %parent_length = call i64 @sollang_windows_wide_length(ptr %parent_cursor)
  %parent_stride = add i64 %parent_length, 1
  %parent_next = getelementptr i16, ptr %parent_cursor, i64 %parent_stride
  %parent_count_next = add i64 %parent_count, 1
  br label %count_parent
allocate_list:
  %selected_parent = phi ptr [ null, %parent_select ], [ %parent, %count_parent ]
  %selected_parent_count = phi i64 [ 0, %parent_select ], [ %parent_count, %count_parent ]
  %maximum_count = add i64 %selected_parent_count, %change_count
  %list_slots = add i64 %maximum_count, 1
  %list_bytes = mul i64 %list_slots, 8
  %list = call ptr @sollang_alloc(i64 %list_bytes)
  %list_ok = icmp ne ptr %list, null
  br i1 %list_ok, label %copy_parent, label %build_failure_with_parent
copy_parent:
  %copy_parent_index = phi i64 [ 0, %allocate_list ], [ %copy_parent_next, %copy_parent_continue ]
  %copy_parent_cursor = phi ptr [ %selected_parent, %allocate_list ], [ %copy_parent_cursor_next, %copy_parent_continue ]
  %kept_count = phi i64 [ 0, %allocate_list ], [ %kept_next, %copy_parent_continue ]
  %copy_parent_done = icmp eq i64 %copy_parent_index, %selected_parent_count
  br i1 %copy_parent_done, label %append_changes, label %copy_parent_inspect
copy_parent_inspect:
  %parent_entry_length = call i64 @sollang_windows_wide_length(ptr %copy_parent_cursor)
  %parent_name_length = call i64 @sollang_windows_environment_name_length(ptr %copy_parent_cursor)
  %parent_change = call i64 @sollang_windows_latest_environment_change(ptr %entries, ptr %name_lengths, i64 %change_count, ptr %copy_parent_cursor, i64 %parent_name_length)
  %parent_overridden = icmp sge i64 %parent_change, 0
  br i1 %parent_overridden, label %copy_parent_skip, label %copy_parent_keep
copy_parent_keep:
  %parent_destination = getelementptr ptr, ptr %list, i64 %kept_count
  store ptr %copy_parent_cursor, ptr %parent_destination, align 8
  %kept_after_copy = add i64 %kept_count, 1
  br label %copy_parent_continue
copy_parent_skip:
  br label %copy_parent_continue
copy_parent_continue:
  %kept_next = phi i64 [ %kept_after_copy, %copy_parent_keep ], [ %kept_count, %copy_parent_skip ]
  %copy_parent_stride = add i64 %parent_entry_length, 1
  %copy_parent_cursor_next = getelementptr i16, ptr %copy_parent_cursor, i64 %copy_parent_stride
  %copy_parent_next = add i64 %copy_parent_index, 1
  br label %copy_parent
append_changes:
  %append_index = phi i64 [ 0, %copy_parent ], [ %append_next, %append_continue ]
  %output_count = phi i64 [ %kept_count, %copy_parent ], [ %output_next, %append_continue ]
  %append_done = icmp eq i64 %append_index, %change_count
  br i1 %append_done, label %sort_outer, label %append_inspect
append_inspect:
  %append_entry_slot = getelementptr ptr, ptr %entries, i64 %append_index
  %append_entry = load ptr, ptr %append_entry_slot, align 8
  %append_name_length_slot = getelementptr i64, ptr %name_lengths, i64 %append_index
  %append_name_length = load i64, ptr %append_name_length_slot, align 8
  %latest = call i64 @sollang_windows_latest_environment_change(ptr %entries, ptr %name_lengths, i64 %change_count, ptr %append_entry, i64 %append_name_length)
  %is_latest = icmp eq i64 %latest, %append_index
  br i1 %is_latest, label %append_latest, label %append_skip
append_latest:
  %append_change = getelementptr { %sollang.text, %sollang.text, i1 }, ptr %changes, i64 %append_index
  %append_removed_slot = getelementptr inbounds { %sollang.text, %sollang.text, i1 }, ptr %append_change, i32 0, i32 2
  %append_removed = load i1, ptr %append_removed_slot, align 1
  br i1 %append_removed, label %append_skip, label %append_keep
append_keep:
  %append_destination = getelementptr ptr, ptr %list, i64 %output_count
  store ptr %append_entry, ptr %append_destination, align 8
  %output_after_append = add i64 %output_count, 1
  br label %append_continue
append_skip:
  br label %append_continue
append_continue:
  %output_next = phi i64 [ %output_after_append, %append_keep ], [ %output_count, %append_skip ]
  %append_next = add i64 %append_index, 1
  br label %append_changes
sort_outer:
  %sort_index = phi i64 [ 1, %append_changes ], [ %sort_next, %sort_store ]
  %sort_done = icmp uge i64 %sort_index, %output_count
  br i1 %sort_done, label %measure_block, label %sort_load
sort_load:
  %sort_key_slot = getelementptr ptr, ptr %list, i64 %sort_index
  %sort_key = load ptr, ptr %sort_key_slot, align 8
  br label %sort_inner
sort_inner:
  %sort_position = phi i64 [ %sort_index, %sort_load ], [ %sort_previous, %sort_shift ]
  %at_start = icmp eq i64 %sort_position, 0
  br i1 %at_start, label %sort_store, label %sort_compare
sort_compare:
  %sort_previous = sub i64 %sort_position, 1
  %sort_previous_slot = getelementptr ptr, ptr %list, i64 %sort_previous
  %sort_previous_value = load ptr, ptr %sort_previous_slot, align 8
  %sort_order = call i32 @CompareStringOrdinal(ptr %sort_key, i32 -1, ptr %sort_previous_value, i32 -1, i32 1)
  %sort_before = icmp eq i32 %sort_order, 1
  br i1 %sort_before, label %sort_shift, label %sort_store
sort_shift:
  %sort_shift_destination = getelementptr ptr, ptr %list, i64 %sort_position
  store ptr %sort_previous_value, ptr %sort_shift_destination, align 8
  br label %sort_inner
sort_store:
  %sort_destination = getelementptr ptr, ptr %list, i64 %sort_position
  store ptr %sort_key, ptr %sort_destination, align 8
  %sort_next = add i64 %sort_index, 1
  br label %sort_outer
measure_block:
  %measure_index = phi i64 [ 0, %sort_outer ], [ %measure_next, %measure_more ]
  %measure_chars = phi i64 [ 0, %sort_outer ], [ %measure_total, %measure_more ]
  %measure_done = icmp eq i64 %measure_index, %output_count
  br i1 %measure_done, label %allocate_block, label %measure_more
measure_more:
  %measure_slot = getelementptr ptr, ptr %list, i64 %measure_index
  %measure_entry = load ptr, ptr %measure_slot, align 8
  %measure_length = call i64 @sollang_windows_wide_length(ptr %measure_entry)
  %measure_with_null = add i64 %measure_length, 1
  %measure_total = add i64 %measure_chars, %measure_with_null
  %measure_next = add i64 %measure_index, 1
  br label %measure_block
allocate_block:
  %empty_block = icmp eq i64 %output_count, 0
  %nonempty_chars = add i64 %measure_chars, 1
  %block_chars = select i1 %empty_block, i64 2, i64 %nonempty_chars
  %block_bytes = mul i64 %block_chars, 2
  %block = call ptr @sollang_alloc(i64 %block_bytes)
  %block_ok = icmp ne ptr %block, null
  br i1 %block_ok, label %copy_block, label %build_failure_with_list
copy_block:
  %block_index = phi i64 [ 0, %allocate_block ], [ %block_next, %block_more ]
  %block_offset = phi i64 [ 0, %allocate_block ], [ %block_offset_next, %block_more ]
  %block_done = icmp eq i64 %block_index, %output_count
  br i1 %block_done, label %terminate_block, label %block_more
block_more:
  %block_entry_slot = getelementptr ptr, ptr %list, i64 %block_index
  %block_entry = load ptr, ptr %block_entry_slot, align 8
  %block_entry_length = call i64 @sollang_windows_wide_length(ptr %block_entry)
  %block_copy_chars = add i64 %block_entry_length, 1
  %block_copy_bytes = mul i64 %block_copy_chars, 2
  %block_destination = getelementptr i16, ptr %block, i64 %block_offset
  call void @llvm.memcpy.p0.p0.i64(ptr %block_destination, ptr %block_entry, i64 %block_copy_bytes, i1 false)
  %block_offset_next = add i64 %block_offset, %block_copy_chars
  %block_next = add i64 %block_index, 1
  br label %copy_block
terminate_block:
  %final_null = getelementptr i16, ptr %block, i64 %block_offset
  store i16 0, ptr %final_null, align 2
  %empty_second = getelementptr i16, ptr %block, i64 1
  br i1 %empty_block, label %terminate_empty, label %finish
terminate_empty:
  store i16 0, ptr %empty_second, align 2
  br label %finish
finish:
  call void @sollang_windows_dispose_environment_build(ptr %entries, ptr %name_lengths, ptr %list, i64 %change_count, ptr %selected_parent)
  %ok0 = insertvalue %sollang.process_environment_result poison, ptr %block, 0
  %ok1 = insertvalue %sollang.process_environment_result %ok0, i64 0, 1
  %ok2 = insertvalue %sollang.process_environment_result %ok1, i64 -1, 2
  %ok3 = insertvalue %sollang.process_environment_result %ok2, i1 true, 3
  ret %sollang.process_environment_result %ok3
build_failure_with_list:
  call void @sollang_windows_dispose_environment_build(ptr %entries, ptr %name_lengths, ptr %list, i64 %change_count, ptr %selected_parent)
  br label %failure
build_failure_with_parent:
  call void @sollang_windows_dispose_environment_build(ptr %entries, ptr %name_lengths, ptr null, i64 %change_count, ptr %selected_parent)
  br label %failure
build_failure:
  call void @sollang_windows_dispose_environment_build(ptr %entries, ptr %name_lengths, ptr null, i64 %change_count, ptr null)
  br label %failure
free_entries_failure:
  call void @sollang_free(ptr %entries)
  br label %failure
failure:
  ret %sollang.process_environment_result zeroinitializer
}


define internal ptr @sollang_process_inherit_windows_handle(ptr %source) {
entry:
  %process = call ptr @GetCurrentProcess()
  %target_slot = alloca ptr, align 8
  %duplicated = call i32 @DuplicateHandle(ptr %process, ptr %source, ptr %process, ptr %target_slot, i32 0, i32 1, i32 2)
  %ok = icmp ne i32 %duplicated, 0
  br i1 %ok, label %success, label %fail
success:
  %target = load ptr, ptr %target_slot, align 8
  ret ptr %target
fail:
  ret ptr null
}
define internal i1 @sollang_process_windows_explicit_application(ptr %program) {
entry:
  br label %scan
scan:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %character_ptr = getelementptr i16, ptr %program, i64 %index
  %character = load i16, ptr %character_ptr, align 2
  %slash = icmp eq i16 %character, 47
  %backslash = icmp eq i16 %character, 92
  %colon = icmp eq i16 %character, 58
  %quote = icmp eq i16 %character, 34
  %separator = or i1 %slash, %backslash
  %qualified = or i1 %colon, %quote
  %explicit = or i1 %separator, %qualified
  br i1 %explicit, label %explicit_application, label %check_end
check_end:
  %end = icmp eq i16 %character, 0
  br i1 %end, label %search_application, label %advance
advance:
  %next = add i64 %index, 1
  br label %scan
explicit_application:
  ret i1 true
search_application:
  ret i1 false
}

define internal i64 @sollang_process_spawn_windows(ptr %program, ptr %argv, i64 %count, ptr %working_directory, ptr %environment, ptr %stdin_override, ptr %stdout_override, ptr %stderr_override) {
entry:
  %command = call ptr @sollang_process_join_windows_args(ptr %argv, i64 %count)
  %command_ok = icmp ne ptr %command, null
  br i1 %command_ok, label %handles, label %fail
handles:
  %has_stdin_override = icmp ne ptr %stdin_override, null
  %stdin_default = call ptr @GetStdHandle(i32 -10)
  %stdin_source = select i1 %has_stdin_override, ptr %stdin_override, ptr %stdin_default
  %has_stdout_override = icmp ne ptr %stdout_override, null
  %stdout_default = call ptr @GetStdHandle(i32 -11)
  %stdout_source = select i1 %has_stdout_override, ptr %stdout_override, ptr %stdout_default
  %has_stderr_override = icmp ne ptr %stderr_override, null
  %stderr_default = call ptr @GetStdHandle(i32 -12)
  %stderr_source = select i1 %has_stderr_override, ptr %stderr_override, ptr %stderr_default
  %stdin_handle = call ptr @sollang_process_inherit_windows_handle(ptr %stdin_source)
  %stdout_handle = call ptr @sollang_process_inherit_windows_handle(ptr %stdout_source)
  %stderr_handle = call ptr @sollang_process_inherit_windows_handle(ptr %stderr_source)
  %stdin_ok = icmp ne ptr %stdin_handle, null
  %stdout_ok = icmp ne ptr %stdout_handle, null
  %stderr_ok = icmp ne ptr %stderr_handle, null
  %io_ok0 = and i1 %stdin_ok, %stdout_ok
  %io_ok = and i1 %io_ok0, %stderr_ok
  br i1 %io_ok, label %create, label %close_handles_fail
create:
  %startup = alloca [104 x i8], align 8
  %process_info = alloca [24 x i8], align 8
  call void @llvm.memset.p0.i64(ptr %startup, i8 0, i64 104, i1 false)
  call void @llvm.memset.p0.i64(ptr %process_info, i8 0, i64 24, i1 false)
  store i32 104, ptr %startup, align 4
  %flags_ptr = getelementptr i8, ptr %startup, i64 60
  store i32 256, ptr %flags_ptr, align 4
  %stdin_ptr = getelementptr i8, ptr %startup, i64 80
  store ptr %stdin_handle, ptr %stdin_ptr, align 8
  %stdout_ptr = getelementptr i8, ptr %startup, i64 88
  store ptr %stdout_handle, ptr %stdout_ptr, align 8
  %stderr_ptr = getelementptr i8, ptr %startup, i64 96
  store ptr %stderr_handle, ptr %stderr_ptr, align 8
  %has_environment = icmp ne ptr %environment, null
  %creation_flags = select i1 %has_environment, i32 1024, i32 0
  %explicit_application = call i1 @sollang_process_windows_explicit_application(ptr %program)
  %application = select i1 %explicit_application, ptr %program, ptr null
  %created = call i32 @CreateProcessW(ptr %application, ptr %command, ptr null, ptr null, i32 1, i32 %creation_flags, ptr %environment, ptr %working_directory, ptr %startup, ptr %process_info)
  %created_ok = icmp ne i32 %created, 0
  br i1 %created_ok, label %spawned, label %close_handles_fail
spawned:
  %process_handle = load ptr, ptr %process_info, align 8
  %thread_ptr = getelementptr i8, ptr %process_info, i64 8
  %thread_handle = load ptr, ptr %thread_ptr, align 8
  %closed_thread = call i32 @CloseHandle(ptr %thread_handle)
  %closed_stdin = call i32 @CloseHandle(ptr %stdin_handle)
  %closed_stdout = call i32 @CloseHandle(ptr %stdout_handle)
  %closed_stderr = call i32 @CloseHandle(ptr %stderr_handle)
  call void @sollang_free(ptr %command)
  %token = ptrtoint ptr %process_handle to i64
  ret i64 %token
close_handles_fail:
  br i1 %stdin_ok, label %close_stdin, label %close_stdout
close_stdin:
  %closed_stdin_fail = call i32 @CloseHandle(ptr %stdin_handle)
  br label %close_stdout
close_stdout:
  br i1 %stdout_ok, label %close_stdout_present, label %close_stderr
close_stdout_present:
  %closed_stdout_fail = call i32 @CloseHandle(ptr %stdout_handle)
  br label %close_stderr
close_stderr:
  br i1 %stderr_ok, label %close_stderr_present, label %free_fail
close_stderr_present:
  %closed_stderr_fail = call i32 @CloseHandle(ptr %stderr_handle)
  br label %free_fail
free_fail:
  call void @sollang_free(ptr %command)
  br label %fail
fail:
  ret i64 -1
}
define internal %sollang.process_spawn_result @sollang_spawn_process_with_stdio(ptr %records, i64 %count, ptr %working_directory_data, i64 %working_directory_length, i1 %has_working_directory, ptr %environment_changes, i64 %environment_change_count, i1 %inherits_environment, ptr %stdin_override, ptr %stdout_override, ptr %stderr_override) {
entry:
  %has_program = icmp ugt i64 %count, 0
  br i1 %has_program, label %build, label %error
build:
  %program_slot = alloca ptr, align 8
  %argv = call ptr @sollang_process_build_windows_argv(ptr %records, i64 %count, ptr %program_slot)
  %built = icmp ne ptr %argv, null
  br i1 %built, label %spawn, label %error
spawn:
  %program = load ptr, ptr %program_slot, align 8
  br i1 %has_working_directory, label %working_directory_convert, label %spawn_ready
working_directory_convert:
  %working_directory_wide = call ptr @sollang_process_windows_text(ptr %working_directory_data, i64 %working_directory_length)
  %working_directory_ok = icmp ne ptr %working_directory_wide, null
  br i1 %working_directory_ok, label %working_directory_ready, label %build_error
working_directory_ready:
  br label %spawn_ready
spawn_ready:
  %working_directory = phi ptr [ null, %spawn ], [ %working_directory_wide, %working_directory_ready ]
  %environment_result = call %sollang.process_environment_result @sollang_windows_build_environment(ptr %environment_changes, i64 %environment_change_count, i1 %inherits_environment)
  %environment = extractvalue %sollang.process_environment_result %environment_result, 0
  %environment_ok = extractvalue %sollang.process_environment_result %environment_result, 3
  br i1 %environment_ok, label %environment_ready, label %environment_error
environment_ready:
  %raw = call i64 @sollang_process_spawn_windows(ptr %program, ptr %argv, i64 %count, ptr %working_directory, ptr %environment, ptr %stdin_override, ptr %stdout_override, ptr %stderr_override)
  call void @sollang_free(ptr %environment)
  call void @sollang_free(ptr %working_directory)
  call void @sollang_free(ptr %program)
  call void @sollang_process_dispose_argv(ptr %argv, i64 %count)
  %spawned = icmp ne i64 %raw, -1
  br i1 %spawned, label %read_process_id, label %error
environment_error:
  call void @sollang_free(ptr %working_directory)
  call void @sollang_free(ptr %program)
  call void @sollang_process_dispose_argv(ptr %argv, i64 %count)
  br label %error
build_error:
  call void @sollang_free(ptr %program)
  call void @sollang_process_dispose_argv(ptr %argv, i64 %count)
  br label %error
read_process_id:
  %handle = inttoptr i64 %raw to ptr
  %process_id32 = call i32 @GetProcessId(ptr %handle)
  %process_id_ok = icmp ne i32 %process_id32, 0
  br i1 %process_id_ok, label %success, label %process_id_error
process_id_error:
  %terminated_id_error = call i32 @TerminateProcess(ptr %handle, i32 1)
  %reaped_id_error = call i32 @WaitForSingleObject(ptr %handle, i32 -1)
  %closed_id_error = call i32 @CloseHandle(ptr %handle)
  br label %error
success:
  %process_id = zext i32 %process_id32 to i64
  %ok0 = insertvalue %sollang.process_spawn_result poison, i64 %raw, 0
  %ok1 = insertvalue %sollang.process_spawn_result %ok0, i64 %process_id, 1
  %ok2 = insertvalue %sollang.process_spawn_result %ok1, i32 0, 2
  ret %sollang.process_spawn_result %ok2
error:
  %error0 = insertvalue %sollang.process_spawn_result poison, i64 0, 0
  %error1 = insertvalue %sollang.process_spawn_result %error0, i64 0, 1
  %error2 = insertvalue %sollang.process_spawn_result %error1, i32 1, 2
  ret %sollang.process_spawn_result %error2
}
define internal %sollang.process_spawn_result @sollang_spawn_process_with_stdout(ptr %records, i64 %count, ptr %working_directory_data, i64 %working_directory_length, i1 %has_working_directory, ptr %environment_changes, i64 %environment_change_count, i1 %inherits_environment, ptr %stdout_override) {
entry:
  %result = call %sollang.process_spawn_result @sollang_spawn_process_with_stdio(ptr %records, i64 %count, ptr %working_directory_data, i64 %working_directory_length, i1 %has_working_directory, ptr %environment_changes, i64 %environment_change_count, i1 %inherits_environment, ptr null, ptr %stdout_override, ptr null)
  ret %sollang.process_spawn_result %result
}
@sollang_process_null_windows = private unnamed_addr constant [4 x i8] c"NUL\00"
define internal ptr @sollang_process_open_windows_stdio(i32 %mode, ptr %path, i64 %path_length, i1 %input) {
entry:
  %inherits = icmp eq i32 %mode, 0
  br i1 %inherits, label %inherit, label %select_file
select_file:
  %is_file = icmp eq i32 %mode, 1
  br i1 %is_file, label %copy_path, label %select_null
select_null:
  %is_null = icmp eq i32 %mode, 2
  br i1 %is_null, label %open_null, label %failure
copy_path:
  %path_copy = call ptr @sollang_process_windows_path(ptr %path, i64 %path_length)
  %path_ok = icmp ne ptr %path_copy, null
  br i1 %path_ok, label %open, label %failure
open:
  %access = select i1 %input, i32 -2147483648, i32 1073741824
  %creation = select i1 %input, i32 3, i32 2
  %handle = call ptr @CreateFileW(ptr %path_copy, i32 %access, i32 1, ptr null, i32 %creation, i32 128, ptr null)
  call void @sollang_free(ptr %path_copy)
  ret ptr %handle
open_null:
  %null_access = select i1 %input, i32 -2147483648, i32 1073741824
  %null_creation = select i1 %input, i32 3, i32 2
  %null_handle = call ptr @CreateFileA(ptr @sollang_process_null_windows, i32 %null_access, i32 3, ptr null, i32 %null_creation, i32 128, ptr null)
  ret ptr %null_handle
inherit:
  ret ptr null
failure:
  ret ptr inttoptr (i64 -1 to ptr)
}
define internal void @sollang_process_close_windows_stdio(ptr %handle) {
entry:
  %value = ptrtoint ptr %handle to i64
  %present = icmp ne i64 %value, 0
  %valid = icmp ne i64 %value, -1
  %should_close = and i1 %present, %valid
  br i1 %should_close, label %close, label %done
close:
  %closed = call i32 @CloseHandle(ptr %handle)
  br label %done
done:
  ret void
}
define internal %sollang.process_spawn_result @sollang_spawn_process_configured(ptr %records, i64 %count, ptr %working_directory_data, i64 %working_directory_length, i1 %has_working_directory, ptr %environment_changes, i64 %environment_change_count, i1 %inherits_environment, i32 %stdin_mode, ptr %stdin_path, i64 %stdin_path_length, i32 %stdout_mode, ptr %stdout_path, i64 %stdout_path_length, i32 %stderr_mode, ptr %stderr_path, i64 %stderr_path_length) {
entry:
  %stdin_inherits = icmp eq i32 %stdin_mode, 0
  %stdout_inherits = icmp eq i32 %stdout_mode, 0
  %stderr_inherits = icmp eq i32 %stderr_mode, 0
  %output_inherits = and i1 %stdout_inherits, %stderr_inherits
  %all_inherit = and i1 %stdin_inherits, %output_inherits
  br i1 %all_inherit, label %inherit, label %open
inherit:
  %inherited = call %sollang.process_spawn_result @sollang_spawn_process(ptr %records, i64 %count, ptr %working_directory_data, i64 %working_directory_length, i1 %has_working_directory, ptr %environment_changes, i64 %environment_change_count, i1 %inherits_environment)
  ret %sollang.process_spawn_result %inherited
open:
  %stdin_handle = call ptr @sollang_process_open_windows_stdio(i32 %stdin_mode, ptr %stdin_path, i64 %stdin_path_length, i1 true)
  %stdout_handle = call ptr @sollang_process_open_windows_stdio(i32 %stdout_mode, ptr %stdout_path, i64 %stdout_path_length, i1 false)
  %stderr_handle = call ptr @sollang_process_open_windows_stdio(i32 %stderr_mode, ptr %stderr_path, i64 %stderr_path_length, i1 false)
  %stdin_value = ptrtoint ptr %stdin_handle to i64
  %stdout_value = ptrtoint ptr %stdout_handle to i64
  %stderr_value = ptrtoint ptr %stderr_handle to i64
  %stdin_ok = icmp ne i64 %stdin_value, -1
  %stdout_ok = icmp ne i64 %stdout_value, -1
  %stderr_ok = icmp ne i64 %stderr_value, -1
  %stdio_ok0 = and i1 %stdin_ok, %stdout_ok
  %stdio_ok = and i1 %stdio_ok0, %stderr_ok
  br i1 %stdio_ok, label %spawn, label %open_failure
spawn:
  %spawned = call %sollang.process_spawn_result @sollang_spawn_process_with_stdio(ptr %records, i64 %count, ptr %working_directory_data, i64 %working_directory_length, i1 %has_working_directory, ptr %environment_changes, i64 %environment_change_count, i1 %inherits_environment, ptr %stdin_handle, ptr %stdout_handle, ptr %stderr_handle)
  call void @sollang_process_close_windows_stdio(ptr %stdin_handle)
  call void @sollang_process_close_windows_stdio(ptr %stdout_handle)
  call void @sollang_process_close_windows_stdio(ptr %stderr_handle)
  ret %sollang.process_spawn_result %spawned
open_failure:
  call void @sollang_process_close_windows_stdio(ptr %stdin_handle)
  call void @sollang_process_close_windows_stdio(ptr %stdout_handle)
  call void @sollang_process_close_windows_stdio(ptr %stderr_handle)
  ret %sollang.process_spawn_result { i64 0, i64 0, i32 1 }
}
define internal %sollang.process_spawn_result @sollang_spawn_process(ptr %records, i64 %count, ptr %working_directory_data, i64 %working_directory_length, i1 %has_working_directory, ptr %environment_changes, i64 %environment_change_count, i1 %inherits_environment) {
entry:
  %result = call %sollang.process_spawn_result @sollang_spawn_process_with_stdio(ptr %records, i64 %count, ptr %working_directory_data, i64 %working_directory_length, i1 %has_working_directory, ptr %environment_changes, i64 %environment_change_count, i1 %inherits_environment, ptr null, ptr null, ptr null)
  ret %sollang.process_spawn_result %result
}
define internal %sollang.process_result @sollang_wait_process(i64 %token) {
entry:
  %valid = icmp ne i64 %token, 0
  br i1 %valid, label %wait, label %error
wait:
  %handle = inttoptr i64 %token to ptr
  %waited = call i32 @WaitForSingleObject(ptr %handle, i32 -1)
  %wait_ok = icmp eq i32 %waited, 0
  br i1 %wait_ok, label %read_exit, label %terminate_error
read_exit:
  %exit_slot = alloca i32, align 4
  %read = call i32 @GetExitCodeProcess(ptr %handle, ptr %exit_slot)
  %read_ok = icmp ne i32 %read, 0
  br i1 %read_ok, label %success, label %terminate_error
success:
  %exit_code = load i32, ptr %exit_slot, align 4
  %closed = call i32 @CloseHandle(ptr %handle)
  %ok0 = insertvalue %sollang.process_result poison, i32 %exit_code, 0
  %ok1 = insertvalue %sollang.process_result %ok0, i32 0, 1
  ret %sollang.process_result %ok1
terminate_error:
  %terminated = call i32 @TerminateProcess(ptr %handle, i32 1)
  %reaped = call i32 @WaitForSingleObject(ptr %handle, i32 -1)
  %closed_error = call i32 @CloseHandle(ptr %handle)
  br label %error
error:
  %error0 = insertvalue %sollang.process_result poison, i32 0, 0
  %error1 = insertvalue %sollang.process_result %error0, i32 2, 1
  ret %sollang.process_result %error1
}
define internal %sollang.process_poll_result @sollang_poll_process(i64 %token) {
entry:
  %valid = icmp ne i64 %token, 0
  br i1 %valid, label %poll, label %poll_error
poll:
  %handle = inttoptr i64 %token to ptr
  %waited = call i32 @WaitForSingleObject(ptr %handle, i32 0)
  %exited = icmp eq i32 %waited, 0
  %running = icmp eq i32 %waited, 258
  br i1 %exited, label %read_exit, label %classify_pending
classify_pending:
  br i1 %running, label %poll_running, label %poll_error
read_exit:
  %exit_slot = alloca i32, align 4
  %read = call i32 @GetExitCodeProcess(ptr %handle, ptr %exit_slot)
  %read_ok = icmp ne i32 %read, 0
  br i1 %read_ok, label %close_exit, label %poll_error
close_exit:
  %exit_code = load i32, ptr %exit_slot, align 4
  %closed = call i32 @CloseHandle(ptr %handle)
  %close_ok = icmp ne i32 %closed, 0
  br i1 %close_ok, label %poll_exited, label %poll_error
poll_exited:
  %exited0 = insertvalue %sollang.process_poll_result poison, i32 %exit_code, 0
  %exited1 = insertvalue %sollang.process_poll_result %exited0, i32 1, 1
  ret %sollang.process_poll_result %exited1
poll_running:
  ret %sollang.process_poll_result { i32 0, i32 0 }
poll_error:
  ret %sollang.process_poll_result { i32 0, i32 2 }
}
define internal i1 @sollang_kill_process(i64 %token) {
entry:
  %valid = icmp ne i64 %token, 0
  br i1 %valid, label %terminate, label %failure
terminate:
  %handle = inttoptr i64 %token to ptr
  %terminated = call i32 @TerminateProcess(ptr %handle, i32 1)
  %succeeded = icmp ne i32 %terminated, 0
  ret i1 %succeeded
failure:
  ret i1 false
}
define internal void @sollang_drop_process_child(i64 %token) {
entry:
  %valid = icmp ne i64 %token, 0
  br i1 %valid, label %dispose, label %done
dispose:
  %handle = inttoptr i64 %token to ptr
  %terminated = call i32 @TerminateProcess(ptr %handle, i32 1)
  %reaped = call i32 @WaitForSingleObject(ptr %handle, i32 -1)
  %closed = call i32 @CloseHandle(ptr %handle)
  br label %done
done:
  ret void
}
define internal %sollang.process_result @sollang_run_process(ptr %records, i64 %count, ptr %working_directory, i64 %working_directory_length, i1 %has_working_directory, ptr %environment_changes, i64 %environment_change_count, i1 %inherits_environment) {
entry:
  %spawned = call %sollang.process_spawn_result @sollang_spawn_process(ptr %records, i64 %count, ptr %working_directory, i64 %working_directory_length, i1 %has_working_directory, ptr %environment_changes, i64 %environment_change_count, i1 %inherits_environment)
  %token = extractvalue %sollang.process_spawn_result %spawned, 0
  %error = extractvalue %sollang.process_spawn_result %spawned, 2
  %ok = icmp eq i32 %error, 0
  br i1 %ok, label %wait, label %spawn_error
wait:
  %result = call %sollang.process_result @sollang_wait_process(i64 %token)
  ret %sollang.process_result %result
spawn_error:
  %error0 = insertvalue %sollang.process_result poison, i32 0, 0
  %error1 = insertvalue %sollang.process_result %error0, i32 1, 1
  ret %sollang.process_result %error1
}
define internal %sollang.process_result @sollang_run_process_configured(ptr %records, i64 %count, ptr %working_directory, i64 %working_directory_length, i1 %has_working_directory, ptr %environment_changes, i64 %environment_change_count, i1 %inherits_environment, i32 %stdin_mode, ptr %stdin_path, i64 %stdin_path_length, i32 %stdout_mode, ptr %stdout_path, i64 %stdout_path_length, i32 %stderr_mode, ptr %stderr_path, i64 %stderr_path_length) {
entry:
  %spawned = call %sollang.process_spawn_result @sollang_spawn_process_configured(ptr %records, i64 %count, ptr %working_directory, i64 %working_directory_length, i1 %has_working_directory, ptr %environment_changes, i64 %environment_change_count, i1 %inherits_environment, i32 %stdin_mode, ptr %stdin_path, i64 %stdin_path_length, i32 %stdout_mode, ptr %stdout_path, i64 %stdout_path_length, i32 %stderr_mode, ptr %stderr_path, i64 %stderr_path_length)
  %token = extractvalue %sollang.process_spawn_result %spawned, 0
  %error = extractvalue %sollang.process_spawn_result %spawned, 2
  %ok = icmp eq i32 %error, 0
  br i1 %ok, label %wait, label %spawn_error
wait:
  %result = call %sollang.process_result @sollang_wait_process(i64 %token)
  ret %sollang.process_result %result
spawn_error:
  ret %sollang.process_result { i32 0, i32 1 }
}
define internal %sollang.process_result @sollang_run_process_to_file(ptr %records, i64 %count, ptr %working_directory, i64 %working_directory_length, i1 %has_working_directory, ptr %environment_changes, i64 %environment_change_count, i1 %inherits_environment, ptr %path, i64 %path_length) {
entry:
  %path_copy = call ptr @sollang_process_windows_path(ptr %path, i64 %path_length)
  %path_ok = icmp ne ptr %path_copy, null
  br i1 %path_ok, label %open, label %error
open:
  %output = call ptr @CreateFileW(ptr %path_copy, i32 1073741824, i32 1, ptr null, i32 2, i32 128, ptr null)
  call void @sollang_free(ptr %path_copy)
  %output_handle_value = ptrtoint ptr %output to i64
  %opened = icmp ne i64 %output_handle_value, -1
  br i1 %opened, label %run, label %error
run:
  %spawned = call %sollang.process_spawn_result @sollang_spawn_process_with_stdout(ptr %records, i64 %count, ptr %working_directory, i64 %working_directory_length, i1 %has_working_directory, ptr %environment_changes, i64 %environment_change_count, i1 %inherits_environment, ptr %output)
  %closed_output = call i32 @CloseHandle(ptr %output)
  %token = extractvalue %sollang.process_spawn_result %spawned, 0
  %spawn_error = extractvalue %sollang.process_spawn_result %spawned, 2
  %spawn_ok = icmp eq i32 %spawn_error, 0
  br i1 %spawn_ok, label %wait, label %error
wait:
  %result = call %sollang.process_result @sollang_wait_process(i64 %token)
  ret %sollang.process_result %result
error:
  %error0 = insertvalue %sollang.process_result poison, i32 0, 0
  %error1 = insertvalue %sollang.process_result %error0, i32 1, 1
  ret %sollang.process_result %error1
}
%sollang.legacy_int_result = type { i64, i32 }
@sollang_legacy_int_writer_buffer = internal global [8192 x i64] zeroinitializer
@sollang_legacy_int_writer_buffer_count = internal global i64 0
define internal i32 @sollang_legacy_int_copy_text_to_c_path(ptr %data, i64 %len, ptr %out) {
entry:
  %too_long = icmp ugt i64 %len, 259
  br i1 %too_long, label %fail, label %copy

copy:
  %i = phi i64 [ 0, %entry ], [ %next, %copy_body ]
  %done = icmp eq i64 %i, %len
  br i1 %done, label %nul, label %copy_body

copy_body:
  %src = getelementptr i8, ptr %data, i64 %i
  %ch = load i8, ptr %src, align 1
  %dst = getelementptr i8, ptr %out, i64 %i
  store i8 %ch, ptr %dst, align 1
  %next = add i64 %i, 1
  br label %copy

nul:
  %nul_ptr = getelementptr i8, ptr %out, i64 %len
  store i8 0, ptr %nul_ptr, align 1
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_open_write_i64_file(ptr %path, i64 %len) {
entry:
  store i64 0, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %ok = call i32 @sollang_legacy_int_platform_open_write_file(ptr %path, i64 %len)
  ret i32 %ok
}

define internal i32 @sollang_legacy_int_flush_i64_file() {
entry:
  %count = load i64, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %success, label %flush

flush:
  %bytes = mul i64 %count, 8
  %ok = call i32 @sollang_legacy_int_platform_write_file_bytes(ptr @sollang_legacy_int_writer_buffer, i64 %bytes)
  %is_ok = icmp ne i32 %ok, 0
  br i1 %is_ok, label %reset, label %fail

reset:
  store i64 0, ptr @sollang_legacy_int_writer_buffer_count, align 8
  br label %success

success:
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_write_i64_file(i64 %value) {
entry:
  %count = load i64, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %slot = getelementptr inbounds [8192 x i64], ptr @sollang_legacy_int_writer_buffer, i64 0, i64 %count
  store i64 %value, ptr %slot, align 8
  %next = add i64 %count, 1
  store i64 %next, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %full = icmp eq i64 %next, 8192
  br i1 %full, label %flush, label %success

flush:
  %ok = call i32 @sollang_legacy_int_flush_i64_file()
  ret i32 %ok

success:
  ret i32 1
}

define internal i32 @sollang_legacy_int_close_write_i64_file() {
entry:
  %flush_ok = call i32 @sollang_legacy_int_flush_i64_file()
  %flush_is_ok = icmp ne i32 %flush_ok, 0
  br i1 %flush_is_ok, label %close, label %fail

close:
  %close_ok = call i32 @sollang_legacy_int_platform_close_write_file()
  ret i32 %close_ok

fail:
  ret i32 0
}

define internal %sollang.legacy_int_result @sollang_legacy_int_closest_i64_file(i64 %target) {
entry:
  %count_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_i64_file_count()
  %count = extractvalue %sollang.legacy_int_result %count_result, 0
  %count_ok = extractvalue %sollang.legacy_int_result %count_result, 1
  %count_is_ok = icmp ne i32 %count_ok, 0
  %has_values = icmp sgt i64 %count, 0
  %can_search = and i1 %count_is_ok, %has_values
  br i1 %can_search, label %search, label %fail

search:
  br label %loop

loop:
  %low = phi i64 [ 0, %search ], [ %next_low, %step ]
  %high = phi i64 [ %count, %search ], [ %next_high, %step ]
  %active = icmp slt i64 %low, %high
  br i1 %active, label %probe, label %choose

probe:
  %span = sub i64 %high, %low
  %half = sdiv i64 %span, 2
  %mid = add i64 %low, %half
  %mid_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %mid)
  %mid_value = extractvalue %sollang.legacy_int_result %mid_result, 0
  %mid_ok = extractvalue %sollang.legacy_int_result %mid_result, 1
  %mid_is_ok = icmp ne i32 %mid_ok, 0
  br i1 %mid_is_ok, label %compare_mid, label %fail

compare_mid:
  %less = icmp slt i64 %mid_value, %target
  br i1 %less, label %move_low, label %move_high

move_low:
  %low_plus = add i64 %mid, 1
  br label %step

move_high:
  br label %step

step:
  %next_low = phi i64 [ %low_plus, %move_low ], [ %low, %move_high ]
  %next_high = phi i64 [ %high, %move_low ], [ %mid, %move_high ]
  br label %loop

choose:
  %at_start = icmp eq i64 %low, 0
  br i1 %at_start, label %read_low, label %check_end

check_end:
  %at_end = icmp eq i64 %low, %count
  br i1 %at_end, label %read_prev_only, label %read_pair

read_low:
  %first_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 0)
  ret %sollang.legacy_int_result %first_result

read_prev_only:
  %last_index = sub i64 %count, 1
  %last_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %last_index)
  ret %sollang.legacy_int_result %last_result

read_pair:
  %prev_index = sub i64 %low, 1
  %prev_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %prev_index)
  %next_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %low)
  %prev_ok = extractvalue %sollang.legacy_int_result %prev_result, 1
  %next_ok = extractvalue %sollang.legacy_int_result %next_result, 1
  %prev_is_ok = icmp ne i32 %prev_ok, 0
  %next_is_ok = icmp ne i32 %next_ok, 0
  %both_ok = and i1 %prev_is_ok, %next_is_ok
  br i1 %both_ok, label %compare_pair, label %fail

compare_pair:
  %prev_value = extractvalue %sollang.legacy_int_result %prev_result, 0
  %next_value = extractvalue %sollang.legacy_int_result %next_result, 0
  %prev_diff = sub i64 %target, %prev_value
  %next_diff = sub i64 %next_value, %target
  %prefer_prev = icmp sle i64 %prev_diff, %next_diff
  br i1 %prefer_prev, label %return_prev, label %return_next

return_prev:
  ret %sollang.legacy_int_result %prev_result

return_next:
  ret %sollang.legacy_int_result %next_result

fail:
  %fail0 = insertvalue %sollang.legacy_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.legacy_int_result %fail0, i32 0, 1
  ret %sollang.legacy_int_result %fail1
}
define internal void @sollang_legacy_int_require(i32 %status) {
entry:
  %ok = icmp ne i32 %status, 0
  br i1 %ok, label %done, label %failure
failure:
  call void @ExitProcess(i32 1)
unreachable
done:
  ret void
}
define void @sollang_x0B7379732E72756E74696D650107010D6F70656E496E745772697465723E01067075626C6963010D6F70656E496E7457726974657201047061746818013A01045465787416022D3E0104556E697420013D0109696E7472696E736963(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  %ok = call i32 @sollang_legacy_int_open_write_i64_file(ptr %data, i64 %length)
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define void @sollang_x0B7379732E72756E74696D65010701087772697465496E743901067075626C696301087772697465496E74010576616C756518013A0103496E7416022D3E0104556E697420013D0109696E7472696E736963(i32 %arg) {
entry:
  %wide = sext i32 %arg to i64
  %ok = call i32 @sollang_legacy_int_write_i64_file(i64 %wide)
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define void @sollang_x0B7379732E72756E74696D650107010E636C6F7365496E745772697465723301067075626C6963010E636C6F7365496E7457726974657218013A16022D3E0104556E697420013D0109696E7472696E736963() {
entry:
  %ok = call i32 @sollang_legacy_int_close_write_i64_file()
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define void @sollang_x0B7379732E72756E74696D650107010D6F70656E496E745265616465723E01067075626C6963010D6F70656E496E7452656164657201047061746818013A01045465787416022D3E0104556E697420013D0109696E7472696E736963(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  %ok = call i32 @sollang_legacy_int_platform_open_read_file(ptr %data, i64 %length)
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define void @sollang_x0B7379732E72756E74696D650107010E636C6F7365496E745265616465723301067075626C6963010E636C6F7365496E7452656164657218013A16022D3E0104556E697420013D0109696E7472696E736963() {
entry:
  %ok = call i32 @sollang_legacy_int_platform_close_read_file()
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define i32 @sollang_x0B7379732E72756E74696D650107010A636C6F73657374496E743B01067075626C6963010A636C6F73657374496E74010674617267657418013A0103496E7416022D3E0103496E7420013D0109696E7472696E736963(i32 %arg) {
entry:
  %wide = sext i32 %arg to i64
  %result = call %sollang.legacy_int_result @sollang_legacy_int_closest_i64_file(i64 %wide)
  %status = extractvalue %sollang.legacy_int_result %result, 1
  call void @sollang_legacy_int_require(i32 %status)
  %value = extractvalue %sollang.legacy_int_result %result, 0
  %narrow = trunc i64 %value to i32
  ret i32 %narrow
}
declare dllimport i32 @ReadFile(ptr, ptr, i32, ptr, ptr)
declare dllimport i32 @SetFilePointerEx(ptr, i64, ptr, i32)
@sollang_legacy_int_file_writer = internal global ptr null
@sollang_legacy_int_file_reader = internal global ptr null

define internal i32 @sollang_legacy_int_platform_open_write_file(ptr %path, i64 %len) {
entry:
  %buf = alloca [260 x i8], align 1
  %buf_ptr = getelementptr inbounds [260 x i8], ptr %buf, i64 0, i64 0
  %copy_ok = call i32 @sollang_legacy_int_copy_text_to_c_path(ptr %path, i64 %len, ptr %buf_ptr)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileA(ptr %buf_ptr, i32 1073741824, i32 0, ptr null, i32 2, i32 128, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  store ptr %handle, ptr @sollang_legacy_int_file_writer, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_platform_write_file_bytes(ptr %data, i64 %len64) {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_writer, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %write, label %fail

write:
  %written = alloca i32, align 4
  %len = trunc i64 %len64 to i32
  %ok = call i32 @WriteFile(ptr %handle, ptr %data, i32 %len, ptr %written, ptr null)
  %written32 = load i32, ptr %written, align 4
  %written64 = zext i32 %written32 to i64
  %write_ok = icmp ne i32 %ok, 0
  %full = icmp eq i64 %written64, %len64
  %all_ok = and i1 %write_ok, %full
  %result = zext i1 %all_ok to i32
  ret i32 %result

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_platform_close_write_file() {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_writer, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %close, label %fail

close:
  %ok = call i32 @CloseHandle(ptr %handle)
  %close_ok = icmp ne i32 %ok, 0
  br i1 %close_ok, label %success, label %fail

success:
  store ptr null, ptr @sollang_legacy_int_file_writer, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_platform_open_read_file(ptr %path, i64 %len) {
entry:
  %buf = alloca [260 x i8], align 1
  %buf_ptr = getelementptr inbounds [260 x i8], ptr %buf, i64 0, i64 0
  %copy_ok = call i32 @sollang_legacy_int_copy_text_to_c_path(ptr %path, i64 %len, ptr %buf_ptr)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileA(ptr %buf_ptr, i32 -2147483648, i32 1, ptr null, i32 3, i32 128, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  store ptr %handle, ptr @sollang_legacy_int_file_reader, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal %sollang.legacy_int_result @sollang_legacy_int_platform_i64_file_count() {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %size, label %fail

size:
  %size_ptr = alloca i64, align 8
  %ok = call i32 @GetFileSizeEx(ptr %handle, ptr %size_ptr)
  %size_ok = icmp ne i32 %ok, 0
  br i1 %size_ok, label %check, label %fail

check:
  %bytes = load i64, ptr %size_ptr, align 8
  %rem = urem i64 %bytes, 8
  %aligned = icmp eq i64 %rem, 0
  br i1 %aligned, label %success, label %fail

success:
  %count = udiv i64 %bytes, 8
  %ok0 = insertvalue %sollang.legacy_int_result poison, i64 %count, 0
  %ok1 = insertvalue %sollang.legacy_int_result %ok0, i32 1, 1
  ret %sollang.legacy_int_result %ok1

fail:
  %fail0 = insertvalue %sollang.legacy_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.legacy_int_result %fail0, i32 0, 1
  ret %sollang.legacy_int_result %fail1
}

define internal %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %index) {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %seek, label %fail

seek:
  %offset = mul i64 %index, 8
  %seek_ok = call i32 @SetFilePointerEx(ptr %handle, i64 %offset, ptr null, i32 0)
  %seek_is_ok = icmp ne i32 %seek_ok, 0
  br i1 %seek_is_ok, label %read, label %fail

read:
  %value_ptr = alloca i64, align 8
  %read_bytes = alloca i32, align 4
  %ok = call i32 @ReadFile(ptr %handle, ptr %value_ptr, i32 8, ptr %read_bytes, ptr null)
  %read_ok = icmp ne i32 %ok, 0
  %read_count = load i32, ptr %read_bytes, align 4
  %read_full = icmp eq i32 %read_count, 8
  %all_ok = and i1 %read_ok, %read_full
  br i1 %all_ok, label %success, label %fail

success:
  %value = load i64, ptr %value_ptr, align 8
  %ok0 = insertvalue %sollang.legacy_int_result poison, i64 %value, 0
  %ok1 = insertvalue %sollang.legacy_int_result %ok0, i32 1, 1
  ret %sollang.legacy_int_result %ok1

fail:
  %fail0 = insertvalue %sollang.legacy_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.legacy_int_result %fail0, i32 0, 1
  ret %sollang.legacy_int_result %fail1
}

define internal i32 @sollang_legacy_int_platform_close_read_file() {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %close, label %fail

close:
  %ok = call i32 @CloseHandle(ptr %handle)
  %close_ok = icmp ne i32 %ok, 0
  br i1 %close_ok, label %success, label %fail

success:
  store ptr null, ptr @sollang_legacy_int_file_reader, align 8
  ret i32 1

fail:
  ret i32 0
}
declare dllimport i32 @GetFileSizeEx(ptr, ptr)
declare dllimport ptr @CreateFileMappingA(ptr, ptr, i32, i32, i32, ptr)
declare dllimport ptr @MapViewOfFile(ptr, i32, i32, i32, i64)
declare dllimport i32 @UnmapViewOfFile(ptr)
declare dllimport i64 @GetTickCount64()
declare dllimport void @GetSystemTimePreciseAsFileTime(ptr)
@sollang_stage2_random_state = internal global i64 88172645463325252
%sollang.read_int_result = type { i64, i32 }
define internal %sollang.read_int_result @sollang_read_i64(ptr %stdin, ptr %read) #0 {
entry:
  %buf = alloca [64 x i8], align 1
  %ok = call i32 @sollang_read_stdin(ptr %stdin, ptr %buf, i64 64, ptr %read)
  %read_ok = icmp ne i32 %ok, 0
  br i1 %read_ok, label %prepare, label %fail

prepare:
  %read32 = load i32, ptr %read, align 4
  %len = zext i32 %read32 to i64
  br label %skip

skip:
  %skip_idx = phi i64 [ 0, %prepare ], [ %skip_next, %skip_ws ]
  %skip_has = icmp ult i64 %skip_idx, %len
  br i1 %skip_has, label %skip_char, label %fail

skip_char:
  %skip_ptr = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 %skip_idx
  %skip_ch = load i8, ptr %skip_ptr, align 1
  %skip_sp = icmp eq i8 %skip_ch, 32
  %skip_tab = icmp eq i8 %skip_ch, 9
  %skip_cr = icmp eq i8 %skip_ch, 13
  %skip_lf = icmp eq i8 %skip_ch, 10
  %skip_sp_tab = or i1 %skip_sp, %skip_tab
  %skip_cr_lf = or i1 %skip_cr, %skip_lf
  %skip_is_ws = or i1 %skip_sp_tab, %skip_cr_lf
  br i1 %skip_is_ws, label %skip_ws, label %digit_entry

skip_ws:
  %skip_next = add i64 %skip_idx, 1
  br label %skip

digit_entry:
  %first_ge = icmp uge i8 %skip_ch, 48
  %first_le = icmp ule i8 %skip_ch, 57
  %first_digit = and i1 %first_ge, %first_le
  br i1 %first_digit, label %digits, label %fail

digits:
  %digit_idx = phi i64 [ %skip_idx, %digit_entry ], [ %digit_next, %digit_continue ]
  %value = phi i64 [ 0, %digit_entry ], [ %value_next, %digit_continue ]
  %digit_has = icmp ult i64 %digit_idx, %len
  br i1 %digit_has, label %digit_char, label %success

digit_char:
  %digit_ptr = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 %digit_idx
  %digit_ch = load i8, ptr %digit_ptr, align 1
  %digit_ge = icmp uge i8 %digit_ch, 48
  %digit_le = icmp ule i8 %digit_ch, 57
  %is_digit = and i1 %digit_ge, %digit_le
  br i1 %is_digit, label %digit_continue, label %trail_entry

digit_continue:
  %digit64 = zext i8 %digit_ch to i64
  %digit_value = sub i64 %digit64, 48
  %value_x10 = mul i64 %value, 10
  %value_next = add i64 %value_x10, %digit_value
  %digit_next = add i64 %digit_idx, 1
  br label %digits

trail_entry:
  br label %trail

trail:
  %trail_idx = phi i64 [ %digit_idx, %trail_entry ], [ %trail_next, %trail_ws ]
  %trail_has = icmp ult i64 %trail_idx, %len
  br i1 %trail_has, label %trail_char, label %success

trail_char:
  %trail_ptr = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 %trail_idx
  %trail_ch = load i8, ptr %trail_ptr, align 1
  %trail_sp = icmp eq i8 %trail_ch, 32
  %trail_tab = icmp eq i8 %trail_ch, 9
  %trail_cr = icmp eq i8 %trail_ch, 13
  %trail_lf = icmp eq i8 %trail_ch, 10
  %trail_sp_tab = or i1 %trail_sp, %trail_tab
  %trail_cr_lf = or i1 %trail_cr, %trail_lf
  %trail_is_ws = or i1 %trail_sp_tab, %trail_cr_lf
  br i1 %trail_is_ws, label %trail_ws, label %fail

trail_ws:
  %trail_next = add i64 %trail_idx, 1
  br label %trail

success:
  %success_value = phi i64 [ %value, %digits ], [ %value, %trail ]
  %success0 = insertvalue %sollang.read_int_result poison, i64 %success_value, 0
  %success1 = insertvalue %sollang.read_int_result %success0, i32 1, 1
  ret %sollang.read_int_result %success1

fail:
  %fail0 = insertvalue %sollang.read_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.read_int_result %fail0, i32 0, 1
  ret %sollang.read_int_result %fail1
}
define internal i32 @sollang_read_stdin(ptr %stdin, ptr %data, i64 %len64, ptr %read) #0 {
entry:
  %exceeds_dword = icmp ugt i64 %len64, 4294967295
  %bounded_len = select i1 %exceeds_dword, i64 4294967295, i64 %len64
  %len = trunc i64 %bounded_len to i32
  %ok = call i32 @ReadFile(ptr %stdin, ptr %data, i32 %len, ptr %read, ptr null)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %success, label %inspect_error

inspect_error:
  %error = call i32 @GetLastError()
  %broken_pipe = icmp eq i32 %error, 109
  br i1 %broken_pipe, label %eof, label %failure

eof:
  store i32 0, ptr %read, align 4
  ret i32 1

success:
  ret i32 1

failure:
  ret i32 0
}
define void @sollang_x0B7379732E72756E74696D65010701057072696E743701067075626C696301057072696E74010576616C756518013A01045465787416022D3E0104556E697420013D0109696E7472696E736963(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_print(ptr %data, i64 %length, i1 false)
  ret void
}
define void @sollang_x0B7379732E72756E74696D65010701077072696E746C6E3901067075626C696301077072696E746C6E010576616C756518013A01045465787416022D3E0104556E697420013D0109696E7472696E736963(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_print(ptr %data, i64 %length, i1 true)
  ret void
}
define i32 @sollang_x0B7379732E72756E74696D650107010772656164496E743901067075626C6963010772656164496E74010670726F6D707418013A01045465787416022D3E0103496E7420013D0109696E7472696E736963(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_print(ptr %data, i64 %length, i1 false)
  %stdin = call ptr @GetStdHandle(i32 -10)
  %read = alloca i32, align 4
  %result = call %sollang.read_int_result @sollang_read_i64(ptr %stdin, ptr %read)
  %ok = extractvalue %sollang.read_int_result %result, 1
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %success, label %failure
success:
  %value = extractvalue %sollang.read_int_result %result, 0
  %narrowed = trunc i64 %value to i32
  ret i32 %narrowed
failure:
  call void @sollang_runtime_flush_stdout()
  call void @ExitProcess(i32 1)
  unreachable
}
define void @sollang_x0B7379732E72756E74696D650107010A7365656452616E646F6D3B01067075626C6963010A7365656452616E646F6D010576616C756518013A0103496E7416022D3E0104556E697420013D0109696E7472696E736963(i32 %arg) {
entry:
  %seed = sext i32 %arg to i64
  store i64 %seed, ptr @sollang_stage2_random_state, align 8
  ret void
}
define i32 @sollang_x0B7379732E72756E74696D650107010B72616E646F6D42656C6F774201067075626C6963010B72616E646F6D42656C6F77010C6D61784578636C757369766518013A0103496E7416022D3E0103496E7420013D0109696E7472696E736963(i32 %arg) {
entry:
  %valid = icmp sgt i32 %arg, 0
  br i1 %valid, label %next, label %failure
next:
  %state = load i64, ptr @sollang_stage2_random_state, align 8
  %product = mul i64 %state, 6364136223846793005
  %updated = add i64 %product, 1442695040888963407
  store i64 %updated, ptr @sollang_stage2_random_state, align 8
  %bound = zext i32 %arg to i64
  %value = urem i64 %updated, %bound
  %result = trunc i64 %value to i32
  ret i32 %result
failure:
  ret i32 0
}

define i64 @sollang_x0B7379732E72756E74696D65010701096E6F774D696C6C69732E01067075626C696301096E6F774D696C6C697318013A16022D3E01044C6F6E6720013D0109696E7472696E736963() {
entry:
  %value = call i64 @GetTickCount64()
  ret i64 %value
}
define i64 @sollang_x0B7379732E72756E74696D650107010C7574634E6F774D696C6C69733101067075626C6963010C7574634E6F774D696C6C697318013A16022D3E01044C6F6E6720013D0109696E7472696E736963() {
entry:
  %filetime = alloca [2 x i32], align 4
  call void @GetSystemTimePreciseAsFileTime(ptr %filetime)
  %low_ptr = getelementptr inbounds [2 x i32], ptr %filetime, i64 0, i64 0
  %high_ptr = getelementptr inbounds [2 x i32], ptr %filetime, i64 0, i64 1
  %low32 = load i32, ptr %low_ptr, align 4
  %high32 = load i32, ptr %high_ptr, align 4
  %low = zext i32 %low32 to i64
  %high = zext i32 %high32 to i64
  %shifted = shl i64 %high, 32
  %ticks = or i64 %shifted, %low
  %unix_ticks = sub i64 %ticks, 116444736000000000
  %millis = udiv i64 %unix_ticks, 10000
  ret i64 %millis
}
define i8 @sollang_x0B7379732E72756E74696D65010701166D6F6E6F746F6E696353757370656E64506F6C6963793C01067075626C696301166D6F6E6F746F6E696353757370656E64506F6C69637918013A16022D3E010555496E743820013D0109696E7472696E736963() { ret i8 0 }
define void @sollang_x0B7379732E72756E74696D6501070106657072696E743801067075626C69630106657072696E74010576616C756518013A01045465787416022D3E0104556E697420013D0109696E7472696E736963(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_eprint(ptr %data, i64 %length, i1 false)
  ret void
}
define void @sollang_x0B7379732E72756E74696D6501070108657072696E746C6E3A01067075626C69630108657072696E746C6E010576616C756518013A01045465787416022D3E0104556E697420013D0109696E7472696E736963(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_eprintln(ptr %data, i64 %length)
  ret void
}
define void @sollang_x0B7379732E72756E74696D6501070113666C7573685374616E646172644F75747075744701067075626C69630113666C7573685374616E646172644F757470757418013A16022D3E0104556E69740104757365730107436F6E736F6C6520013D0109696E7472696E736963() {
entry:
  call void @sollang_runtime_flush_stdout()
  ret void
}
; sollang.codegen.end

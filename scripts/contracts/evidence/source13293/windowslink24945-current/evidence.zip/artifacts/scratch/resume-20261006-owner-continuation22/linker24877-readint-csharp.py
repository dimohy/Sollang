from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'linker24877-readint-csharp';C=B/'linker24876-managed/compiler/Sollang.Compiler.exe';P=R/'scripts/probes/windows-linker/read-int.slg';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
contract=P.with_name('read-int.json');controller=P.with_name('read-int-controller.py')
pins={str(p.resolve()):sha(p) for p in [Path(__file__),P,contract,controller,C,*managed_runtime_inputs(C),*sorted((R/'stdlib').rglob('*.slg'))]}
initialize_output(R,O,reusable_directories=[B/'nativeabi24815-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,inputHashes=pins,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  r=ex.run([str(C),'build',str(P),'-o',str(O/'probe.exe'),'--target','windows-x64','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')],O/'build',timeout=60)
  assert r.returncode==0 and not r.stderr,(r.stdout,r.stderr)
  r=ex.run([sys.executable,str(controller),str(O/'probe.exe'),str(contract)],O/'run',timeout=60)
  assert r.returncode==0 and not r.stderr,(r.stdout,r.stderr);detail=json.loads(r.stdout);assert detail['completed']==detail['total']==8;result['inputCases']=detail
  result.update(status='passed',completed=1,observedStdout=r.stdout)
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))






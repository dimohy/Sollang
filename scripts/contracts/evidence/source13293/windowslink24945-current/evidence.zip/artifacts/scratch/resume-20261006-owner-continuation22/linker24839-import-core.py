from pathlib import Path
p=Path('selfhost/windows_imports.slg');s=p.read_text(encoding='utf-8-sig');start=s.index('# Caller claims a private work directory');end=s.index('# Match the reference Windows linker',start)
replacement='''definitionBytes definition: WindowsImportDefinition -> [UInt8; ~] {
    [UInt8; ~] => bytes!
    definition.library => dll
    Arena(0) => headerStorage!
    "LIBRARY $dll\\nEXPORTS\\n" -> materialize(headerStorage!) => header
    bytes! -> appendText(header)
    UIntSize(0) => index!
    index! < (definition.exports -> len) -> while {
        definition.exports -> byte(index!) => value
        value == ',' -> if { UInt8(10) } else { value } => rendered
        bytes! -> push(rendered)
        index! + 1 => index!
    }
    bytes!
}

createImportCore tool: Text, definitionPath: Text, libraryPath: Text, specification: Text, storage: mut Arena -> Result<Unit, Failure> uses File, Process {
    [UInt8; ~] => bytes!
    bytes! -> appendText(specification)
    definitionPath -> file.openWrite -> when {
        Err(error) {
            "cannot open import definition '$definitionPath': $error" -> materialize(storage) => message
            Result<Unit, Failure>.Err(Failure { message: message, unexpected: true }) -> return
        }
        Ok(writer) {
            writer -> writeRangeAt(bytes!, 0, UIntSize(bytes! -> len), 0) -> when {
                Err(error) {
                    "cannot write import definition '$definitionPath': $error" -> materialize(storage) => message
                    Result<Unit, Failure>.Err(Failure { message: message, unexpected: true }) -> return
                }
                Ok(count) {
                    count != UIntSize(bytes! -> len) -> if {
                        Result<Unit, Failure>.Err(Failure { message: "incomplete import definition write", unexpected: true }) -> return
                    }
                }
            }
            writer -> file.sync -> unless {
                Result<Unit, Failure>.Err(Failure { message: "cannot sync import definition", unexpected: true }) -> return
            }
        }
    }
    Arena(0) => definitionStorage!
    "/def:$definitionPath" -> materialize(definitionStorage!) => definitionArgument
    Arena(0) => libraryStorage!
    "/out:$libraryPath" -> materialize(libraryStorage!) => libraryArgument
    [tool, "/nologo", "/machine:x64", definitionArgument, libraryArgument; ~] -> runTool(libraryPath, storage)
}

createImports tool: Text, llvmPath: Text, workDirectory: Text, libraries: mut [paths.Path; ~], storage: mut Arena -> Result<Unit, Failure> uses File, Process {
    windowsImportDefinitions() -> each definition {
        (definition.marker -> len) == 0 -> if { true } else {
            llvmPath -> containsPrefixMarker(definition.marker) -> when {
                Ok(required) { required }
                Err(error) {
                    "cannot inspect native LLVM imports: $error" -> materialize(storage) => message
                    Result<Unit, Failure>.Err(Failure { message: message, unexpected: true }) -> return
                }
            }
        } => required
        required -> if {
            Arena(0) => definitionStorage!
            Arena(0) => libraryStorage!
            definition.name => name
            "$workDirectory/$name.def" -> materialize(definitionStorage!) => definitionPath
            "$workDirectory/$name.lib" -> materialize(libraryStorage!) => libraryPath
            definition -> definitionBytes => bytes
            bytes -> file.borrowBytes => source
            source -> slice(0, source -> len) => specification
            tool -> createImportCore(definitionPath, libraryPath, specification, storage) -> when {
                Ok {}
                Err(failure) { Result<Unit, Failure>.Err(failure) -> return }
            }
            libraryPath -> paths.fromText(paths.nativeStyle()) => path
            libraries -> push(path)
        }
    }
    Result<Unit, Failure>.Ok
}

# Compatibility edges for the focused import probe and pre-integration CLI.
# The full linker consumes the typed core and owns error presentation itself.
public createWindowsImportLibraries tool: Text, llvmPath: Text, workDirectory: Text, libraries: mut [paths.Path; ~] -> Int uses Console, File, Process {
    Arena(0) => storage!
    tool -> createImports(llvmPath, workDirectory, libraries, storage!) -> when {
        Ok { 0 }
        Err(failure) { failure -> reportFailure
            1 }
    }
}

public createImportLibrary tool: Text, definitionPath: Text, libraryPath: Text, specification: Text -> Int uses Console, File, Process {
    Arena(0) => storage!
    tool -> createImportCore(definitionPath, libraryPath, specification, storage!) -> when {
        Ok { 0 }
        Err(failure) { failure -> reportFailure
            1 }
    }
}

'''
s=s[:start]+replacement+s[end:];p.write_text(s,encoding='utf-8');print('Import creation shares one typed write/tool-execution path.')

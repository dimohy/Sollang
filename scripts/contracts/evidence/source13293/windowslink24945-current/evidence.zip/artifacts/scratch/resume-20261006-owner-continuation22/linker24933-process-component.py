from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'linker24933-process-component';base=B/'linker24919-process-native/.l0.ll';memory=B/'linker24928-memory-emitter-native/emit.stdout';bootstrap=B/'linker24920-slg-native/probe.exe';expected=R/'examples/regression/expected/87-structured-child-process.stdout.txt';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
text=base.read_text(encoding='utf-8-sig');assert all(('define dso_local ptr @'+name+'(') not in text for name in ['memset','memcpy','memmove']);text+='\n'+memory.read_text(encoding='utf-8-sig')
initialize_output(R,O,reusable_directories=[B/'linker24916-native',B/'v20050/compiler-build01',B/'linker24892-native']);O.mkdir();module=O/'process-component.ll';module.write_text(text,encoding='utf-8');work=O/'work';work.mkdir();product=O/'process.exe';pins={str(p.resolve()):sha(p) for p in [Path(__file__),base,memory,bootstrap,expected,module]}
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,cases=[],inputHashes=pins,scope='Focused source-emitted memory primitive component composition; original87 output unchanged; not a full CLI pass.',claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  r=ex.run([str(bootstrap),str(R/'.tools/llvm-22.1.8'),str(module),str(product),str(work),'-O1','4','false','inherit'],O/'link',timeout=60);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  r=ex.run([str(product)],O/'run',timeout=10);assert r.returncode==0 and not r.stderr and r.stdout==expected.read_text(encoding='utf-8-sig'),r.stdout+r.stderr
  result.update(status='passed',completed=1,cases=[dict(id='original87-exact-memory-component',passed=True,stdout=r.stdout)])
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

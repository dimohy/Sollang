from pathlib import Path
import sys,json,hashlib
from xml.sax.saxutils import escape
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'linker24833-jobs-csharp';C=B/'linker24830-managed/compiler/Sollang.Compiler.exe';P=R/'scripts/probes/windows-linker';source=P/'job-limits.cs';contract=P/'job-limits.json';cases=json.loads(contract.read_text())['cases'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();L=R/'.tools/llvm-22.1.8'
initialize_output(R,O,reusable_directories=[B/'nativeabi24815-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir();project=O/'jobs.csproj';project.write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net11.0</TargetFramework><EnableDefaultCompileItems>false</EnableDefaultCompileItems><RestoreSources></RestoreSources></PropertyGroup><ItemGroup><Compile Include="'+escape(str(source))+'" /></ItemGroup></Project>')
pins={str(p.resolve()):sha(p) for p in [Path(__file__),source,contract,project,C,*managed_runtime_inputs(C),R/'src/Sollang.Compiler/Tooling/WindowsLinker.cs',R/'src/Sollang.Compiler/Shared/Policies/WindowsLinkPolicy.cs']}
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=len(cases),cases=[],inputHashes=pins,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  cache=str(O/'.sollang-cache/obj')+'/';r=ex.run(['dotnet','build',str(project),'-c','Release','-o',str(O/'bin'),'--nologo','-v','minimal','/nodeReuse:false','/p:UseSharedCompilation=false','/p:BaseIntermediateOutputPath='+cache,'/p:MSBuildProjectExtensionsPath='+cache,'/warnaserror'],O/'build',timeout=180);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  r=ex.run(['dotnet',str(O/'bin/jobs.dll'),str(C.with_suffix('.dll')),str(L),str(contract)],O/'run',timeout=30);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr;actual=[json.loads(line) for line in r.stdout.splitlines()];assert len(actual)==len(cases)
  for a,c in zip(actual,cases):assert a=={k:v for k,v in c.items() if k in ['id','workers','error']},(a,c)
  result.update(status='passed',completed=len(cases),cases=actual)
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))


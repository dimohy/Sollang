from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'linker24848-owned-controls';C=B/'linker24846-managed/compiler/Sollang.Compiler.exe';P=R/'scripts/probes/windows-linker/owned-task-branch.slg';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
positive=['301-owned-array-push-move','708-owned-branch-merge-move'];negative=['1550-mixed-owned-continuing-branches','1551-partially-terminating-owned-branch'];fixtures=[R/'examples/regression'/f'{n}.slg' for n in positive]+[R/'examples/regression/diagnostics'/f'{n}.slg' for n in negative];expectations=[R/'examples/regression/expected'/f'{n}.stdout.txt' for n in positive]+[R/'examples/regression/diagnostics'/f'{n}.stderr.contains.txt' for n in negative]
pins={str(p.resolve()):sha(p) for p in [Path(__file__),P,*fixtures,*expectations,C,*managed_runtime_inputs(C),*sorted((R/'stdlib').rglob('*.slg'))]}
initialize_output(R,O,reusable_directories=[B/'nativeabi24815-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=4,inputHashes=pins,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  result['cases']=[]
  for source,expected in zip(fixtures,expectations):
   output=O/(source.stem+'.exe');r=ex.run([str(C),'build',str(source),'-o',str(output),'--target','windows-x64','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')],O/(source.stem+'.build'),timeout=60)
   text=expected.read_text(encoding='utf-8-sig').replace('\r\n','\n')
   if source.stem in positive:
    assert r.returncode==0 and not r.stderr,(r.stdout,r.stderr)
    r=ex.run([str(output)],O/(source.stem+'.run'),timeout=10)
    assert r.returncode==0 and not r.stderr and r.stdout==text,(r.stdout,r.stderr,text)
   else:
    assert r.returncode==1 and all(line in r.stderr for line in text.splitlines() if line.strip()),(r.stdout,r.stderr,text)
   result['cases'].append(dict(id=source.stem,passed=True));result['completed']+=1;ex.save()
  result['status']='passed' 
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))



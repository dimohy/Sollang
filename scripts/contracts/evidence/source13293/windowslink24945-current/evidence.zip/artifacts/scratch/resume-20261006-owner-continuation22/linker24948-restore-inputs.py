from pathlib import Path
import ast,json,hashlib,re,zipfile
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/windowslink24945-current';read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest().upper();plan=read(R/'scripts/probes/windows-linker/contract.json')
base=next(ast.literal_eval(n.value) for n in ast.parse((B/'linker24831-csharp.py').read_text(encoding='utf-8-sig')).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='base' for t in n.targets));values={}
for case in plan['cases']:
 value=base
 if case.get('optionalImports'):value+='declare dllimport i32 @CoInitializeEx(ptr, i32)\ndeclare dllimport i32 @WSAStartup(i16, ptr)\ndeclare dllimport i32 @BCryptGenRandom(ptr, ptr, i32, i32)\n'
 if case.get('shared'):value='target triple = "x86_64-pc-windows-msvc"\ndefine dllexport i64 @answer() { ret i64 42 }\n'
 if case.get('invalid'):value='not LLVM input\n'
 if case.get('large'):value+=';'+'partition fixture padding '*((1048576-len(value.encode()))//26+2)+'\n'
 values[case['id']]=value
reconstructed={}
for name in read(B/'linker24947-cleanup-selection.json'):
 out=B/name;j=read(out/'result.json')
 for name,h in j.get('inputHashes',{}).items():
  p=Path(name)
  if p.suffix=='.ll' and p.is_relative_to(out) and not p.exists():reconstructed[p]=h
processPattern=re.compile(r'^[ \t]*define\b[^\n]*@([^ (]+)[^\n]*\{\n.*?^[ \t]*}',re.M|re.S)
processText=(B/'linker24911-process-emitter-native/emit.stdout').read_text(encoding='utf-8-sig');functions={m.group(1):m.group() for m in processPattern.finditer(processText)};firstLine=processText.splitlines()[0]
restored=[]
for p,h in reconstructed.items():
 if p.name=='input.ll' and p.parent.name in values:value=values[p.parent.name]
 elif p.parent.name=='linker24914-components' and p.name=='process-component.ll':value=processPattern.sub(lambda m:functions.get(m.group(1),m.group()),(B/'linker24903-slg-native/.l0.ll').read_text(encoding='utf-8-sig'))
 elif p.parent.name=='linker24914-components' and p.name=='float-component.ll':value=re.sub(r'(^target triple[^\n]*\n)',lambda m:m.group()+firstLine+'\n',(B/'linker24893-cli/native-shared-o1/.l0.ll').read_text(encoding='utf-8-sig'),count=1,flags=re.M)
 elif p.parent.name=='linker24933-process-component':value=(B/'linker24919-process-native/.l0.ll').read_text(encoding='utf-8-sig')+'\n'+(B/'linker24928-memory-emitter-native/emit.stdout').read_text(encoding='utf-8-sig')
 elif p.parent.name=='linker24929-memory-components':
  value='target triple = "x86_64-pc-windows-msvc"\n'+(B/'linker24928-memory-emitter-native/emit.stdout').read_text(encoding='utf-8-sig')+'\n'
  for name,parameters,args in [('set','ptr %destination, i32 %value, i64 %count','ptr %destination, i32 %value, i64 %count'),('copy','ptr %destination, ptr %source, i64 %count','ptr %destination, ptr %source, i64 %count'),('move','ptr %destination, ptr %source, i64 %count','ptr %destination, ptr %source, i64 %count')]:
   target={'set':'memset','copy':'memcpy','move':'memmove'}[name];value+=f'define dllexport ptr @exercise_{name}({parameters}) {{\nentry:\n  %result = call ptr @{target}({args})\n  ret ptr %result\n}}\n'
  value+='attributes #0 = { nounwind }\n'
 else:raise AssertionError(str(p))
 variants=[value.encode(),value.replace('\r\n','\n').replace('\n','\r\n').encode()];data=next(v for v in variants if sha(v)==h);p.write_bytes(data);assert sha(p.read_bytes())==h;restored.append(dict(path=p.relative_to(R).as_posix(),sha256=h,bytes=len(data),exactHashReadback=True))
archive=E/'frozen-inputs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for row in restored:z.writestr(row['path'],(R/row['path']).read_bytes())
with zipfile.ZipFile(archive) as z:
 for row in restored:assert sha(z.read(row['path']))==row['sha256']
(E/'frozen-input-restoration.json').write_text(json.dumps(dict(schemaVersion=1,reason='Canonical cleanup classified pinned LLVM input fixtures as intermediates. Restore only source fixtures from their frozen generators/inputs and require the original recorded byte hashes; protect initial input hashes in the common planner and executor.',restored=restored,archiveSha256=sha(archive.read_bytes()),archiveReadbackVerified=True,claimsGeneratedBinariesRestored=False),indent=2)+'\n',encoding='utf-8');print('Exactly restored and archived pinned LLVM inputs:',len(restored))

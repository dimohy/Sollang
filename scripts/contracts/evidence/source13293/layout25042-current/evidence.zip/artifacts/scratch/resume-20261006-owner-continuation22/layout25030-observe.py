from pathlib import Path
import sys, json, hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22'
C=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve();S=B/'layout25030-capacity.slg'
sha=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
paths=[Path(__file__),S,C,*sorted((R/'stdlib').rglob('*.slg')),*[R/'scripts'/x for x in ['verification_execution.py','verification_contract_lease.py','verification_fingerprints.py','completed_artifact_plan.py','ArtifactLifecycle.ps1']]]
if C.with_suffix('.dll').exists(): paths+=managed_runtime_inputs(C)
pins={str(p.resolve()):sha(p) for p in paths}
initialize_output(R,O,reusable_directories=[B/'return25002-native',B/'product24976-native',B/'v20050/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',purpose='observe bounded dictionary overflow diagnostic; no qualification claim',inputHashes=pins,claimsGoalComplete=False)
 ex=VerificationExecution(R,O,result,lambda: all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  done=ex.run([str(C),'build',str(S),'-o',str(O/'probe.exe'),'--target','windows-x64','-O1','--jobs','4','--keep-temps','--llvm',str(R/'.tools/llvm-22.1.8')],O/'capacity.build',timeout=60)
  result.update(status='observed',exitCode=done.returncode,stdout=done.stdout,stderr=done.stderr,productPublished=(O/'probe.exe').exists())
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','exitCode','stdout','stderr','productPublished','inputsStable','processesStopped']}))

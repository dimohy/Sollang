from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22'
from completed_artifact_plan import cleanup_output,assert_output_shutdown
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
reuse=[B/'layout25036-native',B/'return25002-native',B/'v20050/compiler-build01']
consumers=['product24977-native-after','review24982-priority','review24988-native','review24999-ir']
audit=[]
for name in consumers:
 p=B/name/'result.json';d=read(p);assert d['processesStopped'] is True;assert_output_shutdown(R,p.parent)
 audit.append(dict(path=str(p),sha256=sha(p),status=d['status'],processesStopped=True,claimsFailedConsumerPassed=False))
old=read(B/'product24976-native/result.json');assert not old.get('pendingConsumerProtection')
result=dict(schemaVersion=1,status='running',nativeReusableDirectories=list(map(str,reuse)),managedReusableDirectories=list(map(str,[B/'layout25031-managed',B/'review24984-managed',B/'ownership24970-managed'])),retiredNativeConsumers=audit,retirementContract='Old producer has no pendingConsumerProtection; use ordinary verified-complete cleanup, preserving failed consumer output. Consumer-closure registration requires a pending producer and does not apply.',cleanup=[],earlierSchemaLimitedOutputs=['layout25032-csharp','layout25038-array-csharp'],earlierSchemaLimitedDisposition='Preserve immutable records and outputs: domain status occupies the completion status field, so canonical lifecycle does not verify these old records. Fresh records are independently regenerated with layoutStatus.')
for name in ['layout25045-csharp','layout25047-arithmetic-csharp','layout25049-native','layout25048-arithmetic-native','layout25046-array-csharp','layout25050-array-native','layout25037-arithmetic-csharp','layout25039-native','layout25040-arithmetic-native','layout25041-array-native','product24976-native','linker24924-managed']:
 p=B/name;assert p.resolve().is_relative_to(B.resolve());plan=cleanup_output(R,p,reusable_directories=reuse);done=read(Path(str(plan)+'.execution.json'));assert done['status']=='completed';result['cleanup'].append(dict(output=name,execution=str(plan)+'.execution.json',reclaimedBytes=done['reclaimedBytes']))
for name in ['layout25036-native','layout25031-managed']:
 plan=cleanup_output(R,B/name,reusable_directories=reuse,temporary_only=True);done=read(Path(str(plan)+'.execution.json'));assert done['status']=='completed';result['cleanup'].append(dict(output=name,temporaryOnly=True,execution=str(plan)+'.execution.json',reclaimedBytes=done['reclaimedBytes']))
for directory in reuse:assert (directory/'compiler.exe').is_file()
for name in ['layout25031-managed','review24984-managed','ownership24970-managed']:assert (B/name/'compiler/Sollang.Compiler.exe').is_file()
assert not (B/'product24976-native/compiler.exe').exists() and not (B/'linker24924-managed/compiler/Sollang.Compiler.exe').exists()
result.update(status='completed',reclaimedBytes=sum(x['reclaimedBytes'] for x in result['cleanup']),claimsGoalComplete=False)
(B/'layout25044-cleanup.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(status=result['status'],reclaimedBytes=result['reclaimedBytes'])))

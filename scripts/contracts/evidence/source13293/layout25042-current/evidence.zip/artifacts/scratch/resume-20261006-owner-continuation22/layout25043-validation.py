from pathlib import Path
import sys,json,hashlib,importlib.util
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/(sys.argv[1] if len(sys.argv)>1 else 'layout25043-validation')
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output,cleanup_output
spec=importlib.util.spec_from_file_location('audit',R/'scripts/audit-structural-source-connections.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a);detail=a.DETAIL.read('scripts/contracts/structural-parity-detail.json')
paths=[Path(__file__),R/'scripts/contracts/structural-parity-detail.json',R/'scripts/test-structural-phase-closure.py',R/'scripts/audit-structural-source-connections.py',R/'scripts/verify-structural-parity-detail.py',R/'scripts/probes/layout-boundary/test_status_contract.py',R/'scripts/probes/layout-boundary/verify-source.py',R/'scripts/verification_execution.py',R/'scripts/completed_artifact_plan.py']
for row in detail['phaseProgress']:
 for side,ext in [('managed','.cs'),('selfhost','.slg')]:paths += [R/p for p in a.phase_source_files(R,row['phase'],row['decisionInventory'],side,ext)]
 for d in row['decisionInventory']['decisions']:paths += [R/p for p in d.get('supportingSources',[])]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();pins={str(p.resolve()):sha(p) for p in paths};reuse=[B/'return25002-native',B/'product24976-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=4,inputHashes=pins,cases=[],claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for label,args,fragment in [('closure-controls',[R/'scripts/test-structural-phase-closure.py'],'Ran 112 tests'),('layout-controls',[R/'scripts/probes/layout-boundary/test_status_contract.py'],'Ran 2 tests'),('source-connections',[R/'scripts/audit-structural-source-connections.py'],'"claimsPhaseComplete": false'),('phase-closure',[R/'scripts/verify-structural-parity-detail.py','--phase-closure-only'],'0/7')]:
   done=ex.run([sys.executable,'-B',*map(str,args)],O/label,timeout=60);assert done.returncode==0 and fragment in done.stdout+done.stderr,(done.stdout,done.stderr)
   if label=='source-connections':
    audit=json.loads(done.stdout);assert sum(v['named'] for p in audit['phases'] for v in p['coverage'].values())==458;result['sourceConnections']=audit
   result['cases'].append(dict(id=label,passed=True));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reuse)
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

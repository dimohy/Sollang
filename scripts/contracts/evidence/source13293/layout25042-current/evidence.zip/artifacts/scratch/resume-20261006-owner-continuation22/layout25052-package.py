from pathlib import Path
import sys,json,hashlib,datetime,zipfile,subprocess
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/layout25042-current'
from completed_artifact_plan import completed
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
write=lambda p,d:Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
units={'managed':'layout25045-csharp','arithmeticManaged':'layout25047-arithmetic-csharp','native':'layout25049-native','arithmeticNative':'layout25048-arithmetic-native','arrayManaged':'layout25046-array-csharp','arrayNative':'layout25050-array-native','validation':'layout25051-validation'}
records={key:read(B/name/'result.json') for key,name in units.items()}
for key,record in records.items():
 assert completed(record) and record['processesStopped'],key
 assert all(sha(p)==h for p,h in record['inputHashes'].items()),key
 for stream in ['stdout','stderr']:
  assert len({p[stream+'Path'] for p in record['processes']})==len(record['processes'])
  for process in record['processes']:assert sha(process[stream+'Path'])==process[stream+'Sha256']
 write(E/(key+'.json'),record)
for left,right in zip(records['arithmeticManaged']['cases'],records['arithmeticNative']['cases']):assert left==right
assert sum(records[key]['completed'] for key in ['managed','arithmeticManaged','native','arithmeticNative'])==36
schema=[]
for old,new in [('layout25032-csharp','managed'),('layout25038-array-csharp','arrayManaged')]:
 previous=read(B/old/'result.json');assert not completed(previous)
 normalized=[{**{k:v for k,v in case.items() if k!='status'},'layoutStatus':case['status']} if 'capacity' in case else case for case in previous['cases']]
 assert normalized==records[new]['cases']
 schema.append(dict(earlierRecord=str((B/old/'result.json').relative_to(R)),earlierLifecycleAccepted=False,currentLifecycleAccepted=True,oracleResultsUnchanged=True,earlierOutputProtected=True))
cleanup=read(B/'layout25044-cleanup.json');assert cleanup['status']=='completed'
write(E/'artifact-lifecycle.json',dict(cleanup=cleanup,executionStatusSchema=schema,limitation='Two earlier immutable records retain the old domain-status field and their outputs stay protected. All freshly regenerated verification outputs were cleaned successfully.'))
audit=records['validation']['sourceConnections'];named=sum(v['named'] for p in audit['phases'] for v in p['coverage'].values());total=sum(v['actual'] for p in audit['phases'] for v in p['coverage'].values());assert (named,total)==(458,712)
write(E/'source-connections.json',audit)
comparison=read(B/'layout25033-source-comparison.json');comparison['currentManagedVerification']='artifacts/scratch/resume-20261006-owner-continuation22/layout25045-csharp/result.json';comparison['inputSourceHashes']={p:sha(R/p) for p in ['src/Sollang.Compiler/Semantics/BoundProgram.cs','selfhost/llvm/emitter/layout_arithmetic.slg','selfhost/llvm/type_layouts.slg','selfhost/llvm/text/invariants.slg','selfhost/llvm/text/invariant_diagnostics.slg','selfhost/llvm/text/foundation.slg']};write(E/'source-comparison.json',comparison)
write(E/'proof-snapshot.json',dict(observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),focused=dict(completed=36,total=36,metadata=16,pairedArithmetic=16,pairedCli=4),arrayControls=dict(completed=11,total=11),integrationChecks=dict(completed=4,total=4),closureControls=dict(completed=112,total=112),layoutControls=dict(completed=2,total=2),sourceComparison='source-comparison.json',claimsGoalComplete=False))
entries={}
def add(p):
 p=Path(p);entries[p.relative_to(R).as_posix()]=p.read_bytes()
sources=['src/Sollang.Compiler/Semantics/BoundProgram.cs','selfhost/llvm/emitter/layout_arithmetic.slg','selfhost/llvm/type_layouts.slg','selfhost/llvm/text/invariants.slg','selfhost/llvm/text/invariant_diagnostics.slg','selfhost/llvm/text/foundation.slg','docs/SPEC.md','scripts/probes/layout-boundary/Program.cs','scripts/probes/layout-boundary/verify-managed.py','scripts/probes/layout-boundary/verify-source.py','scripts/probes/layout-boundary/verify-native.py','scripts/probes/layout-boundary/dictionary-normal.slg','scripts/probes/layout-boundary/dictionary-overflow.slg','scripts/probes/layout-boundary/dictionary-arithmetic.slg','scripts/verification_execution.py','scripts/completed_artifact_plan.py']
for name in sources:add(R/name)
for name in sources:
 original=subprocess.run(['git','show','HEAD:'+name],capture_output=True)
 if original.returncode==0:entries['before-source/'+name]=original.stdout
for name in ['layout25030-observe.py','layout25030-capacity.slg','layout25033-source-comparison.json','layout25042-record.py','layout25042-detail-before.json','layout25042-goal-before.json','layout25043-validation.py','layout25044-cleanup.py','layout25044-cleanup.json','layout25052-package.py']:add(B/name)
for name in [*units.values(),'layout25030-csharp','layout25031-managed','layout25034-semantic','layout25035-stdlib','layout25036-native','layout25032-csharp','layout25038-array-csharp','layout25037-arithmetic-csharp','layout25039-native','layout25040-arithmetic-native','layout25041-array-native']:
 for p in (B/name).rglob('*'):
  if p.is_file() and not any(part in p.parts for part in ['.sollang-cache','compiler','bin','obj','dotnet-artifacts']) and not any(part.endswith('.slg-tmp') for part in p.parts) and p.suffix.lower() not in ['.exe','.dll','.pdb','.ll','.bc','.obj','.lib','.pyc']:add(p)
archive=E/'evidence.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(entries.items()):z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
 for name,raw in entries.items():assert z.read(name)==raw
write(E/'archive-manifest.json',dict(sha256=sha(archive),readbackVerified=True,entries={name:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest().upper()) for name,raw in sorted(entries.items())}))
write(E/'qualification.json',dict(schemaVersion=1,status='current-windows-bounded-dictionary-focused-qualified-final-gates-pending',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),owner='C2026-10-31-762',focused=dict(completed=36,total=36,percentage=100.0,metadata=16,pairedArithmetic=16,pairedCli=4),arrayControls=dict(completed=11,total=11),semantic=dict(completed=4,total=4),stdlib=dict(completed=1,total=1),integrationChecks=dict(completed=4,total=4),closureControls=112,layoutControls=2,associated=dict(completed=458,total=712,percentage=64.33,remaining=254),addedSourceAssociations=1,currentIndependentCommandLogs=sum(len(d['processes']) for d in records.values()),sourceComparison='source-comparison.json',lifecycle='artifact-lifecycle.json',currentFailedCases=0,historicalSchemaLimitedOutputs=2,fullSourcePhases=dict(completed=0,total=7),original1999Runs=0,nativeCompilerProducerBuilds=1,managedCompilerProducerBuilds=1,currentFocusedProgramBuilds=8,earlierFocusedProgramBuilds=8,baselineNegativeCompile=1,platformScope='windows-x64 only',archive=dict(path='evidence.zip',sha256=sha(archive),entries=len(entries),readbackVerified=True),claimsWholePhaseComplete=False,claimsGoalComplete=False))
goalPath=R/'scripts/contracts/active-goal-progress.json';goal=read(goalPath);goal['currentBoundedDictionaryLayoutUnit']['csharpFirst']='artifacts/scratch/resume-20261006-owner-continuation22/layout25045-csharp/result.json';goal['currentBoundedDictionaryLayoutUnit']['historicalCsharpFirstBeforeSlg']='artifacts/scratch/resume-20261006-owner-continuation22/layout25032-csharp/result.json';write(goalPath,goal)
print(json.dumps(dict(status='qualified',focused='36/36',arrayControls='11/11',archiveEntries=len(entries),archiveBytes=archive.stat().st_size,associated='458/712',goalComplete=False)))

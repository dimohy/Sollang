from pathlib import Path
import json, hashlib, datetime, subprocess, zipfile
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/layout25042-current'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
write=lambda p,d:Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
units={'managed':'layout25032-csharp','arithmeticManaged':'layout25037-arithmetic-csharp','native':'layout25039-native','arithmeticNative':'layout25040-arithmetic-native','arrayManaged':'layout25038-array-csharp','arrayNative':'layout25041-array-native'}
records={key:read(B/name/'result.json') for key,name in units.items()}
for key,record in records.items():
 assert record['status']=='passed' and record['completed']==record['total'] and record['inputsStable'] and record['processesStopped'],key
 assert all(sha(p)==h for p,h in record['inputHashes'].items()),key
 for stream in ['stdout','stderr']:
  assert len({p[stream+'Path'] for p in record['processes']})==len(record['processes'])
  for process in record['processes']:assert sha(process[stream+'Path'])==process[stream+'Sha256']
for left,right in zip(records['arithmeticManaged']['cases'],records['arithmeticNative']['cases']):assert left==right
assert sum(records[key]['completed'] for key in ['managed','arithmeticManaged','native','arithmeticNative'])==36
E.mkdir();write(E/'source-comparison.json',read(B/'layout25033-source-comparison.json'))
for key,record in records.items():write(E/(key+'.json'),record)
write(E/'proof-snapshot.json',dict(observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),focused=dict(completed=36,total=36,metadata=16,pairedArithmetic=16,pairedCli=4),arrayControls=dict(completed=11,total=11),sourceComparison='source-comparison.json',claimsGoalComplete=False))
detailPath=R/'scripts/contracts/structural-parity-detail.json';before=read(detailPath);write(B/'layout25042-detail-before.json',before)
row=next(r for r in before['phaseProgress'] if r['phase']=='llvm-generation');decision=next(d for d in row['decisionInventory']['decisions'] if d['id']=='llvm-generation.checked-bounded-storage-layout')
assert 'selfhost/llvm/type_layouts.slg' not in decision['selfhostSources']
decision['selfhostSources'].append('selfhost/llvm/type_layouts.slg')
decision.setdefault('supportingSources',[]).append('src/Sollang.Compiler/Semantics/BoundProgram.cs')
decision['branches']='Bounded array and dictionary checked Int32 operation order; dictionary minimum-bucket cast, power-of-two growth, entry payload and aligned storage size; explicit overflow4 rejection before LLVM. Existing nominal-cycle diagnostics remain distinct.'
decision['logic']='CSharp type creation and restored registration share one bounded-dictionary geometry helper. SLG scalar arithmetic returns Result, the canonical type wrapper publishes known layout only on Ok and propagates overflow4 otherwise; existing foundation consumers reuse that wrapper. The IR diagnostic guard handles both bounded kinds and selects the matching exact diagnostic.'
decision['diagnostics']='Current dictionary focused36: CSharp metadata16, actual paired CLI4 and production arithmetic pair16. Existing array controls11, semantic4 and full stdlib1 pass. Historical full layoutsFor Native API timeout remains unverified; no whole phase or final gate credit.'
decision['currentQualification']='scripts/contracts/evidence/source13293/layout25042-current/qualification.json'
decision['focusedQualification']=decision['currentQualification']
decision['dictionarySourceComparison']='scripts/contracts/evidence/source13293/layout25042-current/source-comparison.json'
row['latestFocusedUnit']='Checked bounded-dictionary geometry and exact overflow diagnostic: focused36 and array controls11 qualified; whole-phase proof pending.'
write(detailPath,before)
ledgerPath=R/'scripts/contracts/compiler-defects.json';ledger=read(ledgerPath);defect=next(d for d in ledger['defects'] if d['id']=='C2026-10-31-762');assert defect['state']=='candidate-fixed'
defect['owner']='CSharp and SLG bounded aggregate checked layout arithmetic'
defect['rootCause']='Bounded aggregate geometry must preserve checked Int32 intermediate arithmetic before publishing a layout. SLG bounded arrays and dictionaries previously used unchecked arithmetic; CSharp bounded dictionaries checked geometry but leaked OverflowException as an unexpected compiler failure and duplicated creation/restore calculations.'
defect['dictionaryQualification']=decision['currentQualification'];defect['dictionarySourceComparison']=decision['dictionarySourceComparison']
defect['remaining']='Dictionary focused36 and array controls11 qualify current Windows source. Historical full layoutsFor Native API timeout remains unverified; whole source/runtime/Stage/platform gates remain.'
write(ledgerPath,ledger)
goalPath=R/'scripts/contracts/active-goal-progress.json';goal=read(goalPath);write(B/'layout25042-goal-before.json',goal)
goal['currentFocusedGate']='layout25042-focused36'
goal['currentBoundedDictionaryLayoutUnit']=dict(defectId=defect['id'],status='current-focused-qualified-final-pending',qualification=decision['currentQualification'],completed=36,total=36,arrayControls=dict(completed=11,total=11),csharpFirst='artifacts/scratch/resume-20261006-owner-continuation22/layout25032-csharp/result.json',nextVerification='Remaining source decisions before whole source/runtime and Stage gates.')
goal['currentSourceAssociationIntake']=dict(status='measured-source-connections-not-phase-proof',completed=458,total=712,percentage=64.33,remaining=254,qualification=decision['currentQualification'])
write(goalPath,goal)
print(json.dumps(dict(focused='36/36',arrayControls='11/11',associated='458/712',goalComplete=False)))

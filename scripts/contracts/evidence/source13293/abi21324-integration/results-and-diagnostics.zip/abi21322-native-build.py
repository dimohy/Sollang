from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();parentPath=B/'abi21320-source-emitter/result.json';parent=json.loads(parentPath.read_text());assert parent['status']=='passed' and parent['completed']==parent['total']==9 and parent['inputsStable'] and parent['processesStopped'];llvm=B/'abi21320-source-emitter/positive/math.ll';paths=[Path(__file__),parentPath,llvm,ROOT/'.tools/llvm-22.1.8/bin/llvm-as.exe',*[Path(p) for p in parent['inputHashes']]]
for p,h in parent['inputHashes'].items():assert sha(p)==h,p
hashes={str(p):sha(p) for p in paths};OUT=B/'abi21322-emission';initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(paths):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='verified-llvm-emission-subset',mode='managed',semanticPreflight=dict(status='passed-current-source',proof=str(B/'abi21319-semantic/result.json'),codegenInvoked=False),parentProof=str(parentPath),claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(Path(p).is_file() and sha(p)==h for p,h in hashes.items()),sha);error=None
 try:
  p=run.run([str(ROOT/'.tools/llvm-22.1.8/bin/llvm-as.exe'),str(llvm),'-o',str(OUT/'positive.bc')],OUT/'assemble',timeout=180);link=next(p for p in parent['processes'] if str(llvm) in p['command'] and '-shared' in p['command']);execute=next(p for p in parent['processes'] if '-c' in p['command'] and str(llvm.parent/'math.dll') in p['command']);assert p.returncode==link['exit']==execute['exit']==0;result['cases'].append(dict(id='library-fixed-int32',passed=True,status='passed',emittedLlvmSha256=sha(llvm),assemblyExit=p.returncode,nativeLinkExit=link['exit'],nativeRunExit=execute['exit'],parentConsumer=execute['command']));result['completed']=1;result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
proofs=[B/'abi21319-semantic/result.json',OUT/'result.json',B/'abi21321-stdlib/result.json'];plan=json.loads((B/'native21262-plan.json').read_text());command=plan['command']
for old,new in [('v21262','v21323'),('store21256-semantic','abi21319-semantic'),('store21262-emission2','abi21322-emission'),('store21258-stdlib','abi21321-stdlib')]:command=[x.replace(old,new) for x in command]
buildPaths=[Path(__file__),ROOT/'scripts/build-focused-selfhost-compiler.ps1',ROOT/'scripts/focused-selfhost-input-contract.ps1',ROOT/'scripts/verification_execution.py',ROOT/'scripts/verification_contract_lease.py']
for proof in proofs:
 r=json.loads(proof.read_text());assert r['status']=='passed' and r['inputsStable'] and r['processesStopped'];buildPaths.append(proof)
 for p,h in r['inputHashes'].items():assert sha(p)==h,p;buildPaths.append(Path(p))
buildPaths=list(dict.fromkeys(buildPaths));buildHashes={str(p):sha(p) for p in buildPaths};plan.update(command=command,inputHashes=buildHashes,purpose='One grouped current Native candidate for C764 computed TypeId ABI diagnostics and C768 callback AST metadata; exact CSharp baselines3, SLG source emitter9, semantic4, emitted-library execution/assembly1 and full stdlib source1 verified first. No oracle or timeout relaxation.');planPath=B/'native21323-plan.json';planPath.write_text(json.dumps(plan,indent=2)+'\n');buildPaths.append(planPath);buildHashes[str(planPath)]=sha(planPath);OUT=B/'native21323-supervision';OUT.mkdir(exist_ok=False)
with VerificationContractLease(buildPaths):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,cases=[],inputHashes=buildHashes,maximumTotalSeconds=180,claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(Path(p).is_file() and sha(p)==h for p,h in buildHashes.items()),sha);error=None
 try:
  p=run.run(command,OUT/'build',timeout=180);result['cases'].append(dict(id='canonical-native-build',passed=p.returncode==0,exit=p.returncode));result['completed']=int(p.returncode==0);result['status']='observed-not-qualified' if p.returncode==0 else 'failed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps(dict(status=result['status'],completed=result['completed'],processesStopped=result['processesStopped'])))

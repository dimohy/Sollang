from pathlib import Path
import sys,json,hashlib,time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_source_proof import current_build_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'abi21325-native';NATIVE=B/'v21323/compiler-build01/compiler.exe';parentPath=B/'abi21320-source-emitter/result.json';parent=json.loads(parentPath.read_text());assert parent['status']=='passed' and parent['completed']==parent['total']==9 and parent['inputsStable'] and parent['processesStopped'];birth=json.loads((NATIVE.parent/'result.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();assert sha(NATIVE)==birth['compilerSha256'];base=ROOT/'scripts/probes/codegen-identity';rows=[]
for row in parent['cases']:
 if row['id'] in ['build','positive-library-link-and-call']:continue
 source=(B/'library21111-csharp-declarations'/(row['id']+'.slg')) if row['id'] in ['readonly','struct','fixed-array'] else base/('library-'+row['id']+'.slg');rows.append((row['id'],source,row['expected']))
positive=base/'library-export.slg';metadata=B/'library21049-int32-baseline2/managed/math.windows-x64.slglib.json';inputs=[Path(__file__),NATIVE,NATIVE.parent/'result.json',parentPath,metadata,positive,*[r[1] for r in rows],*current_build_inputs(ROOT,birth)];inputs=list(dict.fromkeys(inputs));hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=8,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Fresh current Native actual ABI diagnostic3 and rejection-priority4 plus positive shared library link/interface/call1',claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  for label,source,expected in rows:
   d=OUT/label;d.mkdir();done=run.run([str(NATIVE),'build',str(source),'-o',str(d/'math.dll'),'--library','--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0'],d/'build',timeout=180);passed=done.returncode==1 and not done.stdout and done.stderr==expected;result['cases'].append(dict(id=label,passed=passed,buildExit=done.returncode,expectedBuildExit=1,expectedDiagnostic=expected,actualDiagnostic=done.stderr,stdout=done.stdout));result['completed']+=int(passed);run.save();assert passed,(label,done.stdout[-1000:],done.stderr)
  d=OUT/'positive';d.mkdir();start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));dll=d/'math.dll';done=run.run([str(NATIVE),'build',str(positive),'-o',str(dll),'--library','--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0'],d/'build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout[-2000:]+done.stderr;interface=d/'math.windows-x64.slglib.json';assert json.loads(interface.read_text())==json.loads(metadata.read_text());code="import ctypes,json,sys;from pathlib import Path;p=Path(sys.argv[1]);j=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'));lib=ctypes.CDLL(str(p));f=getattr(lib,j['exports'][0]['symbol']);f.argtypes=[ctypes.c_int32];f.restype=ctypes.c_int32;print(f(7))";done=run.run([sys.executable,'-c',code,str(dll),str(interface)],d/'call',timeout=budget());assert done.returncode==0 and done.stdout=='8\n' and not done.stderr,done.stdout+done.stderr;result['cases'].append(dict(id='positive',passed=True,buildExit=0,runExit=done.returncode,stdout=done.stdout,interfaceMatchesCSharp=True));result['completed']+=1;result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','cases','inputsStable','processesStopped']},indent=2))

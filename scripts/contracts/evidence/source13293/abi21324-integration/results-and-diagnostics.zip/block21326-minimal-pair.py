from pathlib import Path
import sys,json,hashlib,time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_source_proof import current_build_inputs
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'block21326-minimal-pair';MANAGED=B/'managed21139/compiler/Sollang.Compiler.exe';NATIVE=B/'v21323/compiler-build01/compiler.exe';MANIFEST=ROOT/'scripts/probes/codegen-identity/type-registration-intrinsic-block-ast.sources.txt';sources=[ROOT/s for s in MANIFEST.read_text(encoding='utf-8-sig').splitlines() if s];old=B/'block21315-formatted-pair';proof=old/'result.json';r=json.loads(proof.read_text());assert r['status']=='passed' and r['completed']==r['total']==8 and r['inputsStable'] and r['processesStopped'];labels=['ordinary','intrinsic','simple-intrinsic','native'];fixtures={label:ROOT/'scripts/probes/codegen-identity/intrinsic-block-metadata'/(label+'.slg') for label in labels};expected={label:(old/(label+'-slg.stdout')).read_text(encoding='utf-8') for label in labels};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();inputs=[Path(__file__),MANAGED,*managed_runtime_inputs(MANAGED),NATIVE,NATIVE.parent/'result.json',MANIFEST,*sources,proof,*fixtures.values(),*[old/(label+'-slg.stdout') for label in labels],*current_build_inputs(ROOT,json.loads((NATIVE.parent/'result.json').read_text()))];inputs=list(dict.fromkeys(inputs));hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=10,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='C768 minimal current AST/symbol closure compiled by CSharp then current Native, exact metadata four fixtures each; CSharp actual parser oracle remains block21315 eight-case result',claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  for mode,compiler in [('managed',MANAGED),('native',NATIVE)]:
   d=OUT/mode;d.mkdir();done=run.run([str(compiler),'build',*map(str,sources),'-o',str(d/'observer.exe'),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0','--keep-temps'],d/'build',timeout=180);assert done.returncode==0 and not done.stderr,done.stdout[-2000:]+done.stderr;result['cases'].append(dict(id=mode+'-build',passed=True,buildExit=done.returncode));result['completed']+=1;run.save()
   for label in labels:
    done=run.run([str(d/'observer.exe'),str(fixtures[label])],d/label,timeout=180);passed=done.returncode==0 and not done.stderr and done.stdout==expected[label];result['cases'].append(dict(id=mode+'-'+label,passed=passed,runExit=done.returncode,stdout=done.stdout,expected=expected[label]));result['completed']+=int(passed);run.save();assert passed,(label,done.stdout,done.stderr)
  result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','cases','inputsStable','processesStopped']},indent=2))

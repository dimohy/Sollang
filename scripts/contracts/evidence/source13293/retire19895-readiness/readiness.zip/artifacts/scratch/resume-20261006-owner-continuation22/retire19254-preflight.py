import json
from pathlib import Path
import sys
import argparse

root=Path.cwd()
base=root/'artifacts/scratch/resume-20261006-owner-continuation22'
sys.path.insert(0,str(root/'scripts'))
from completed_artifact_plan import consumer_closure_record

parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,default=base/'retire19254-selected.json');args=parser.parse_args()
plan=json.loads(args.plan.read_text(encoding='utf-8-sig'))
paths=[Path(x['path']) for x in plan['consumerCandidates']]
def trace(frame,event,arg):
    if event=='exception' and frame.f_code.co_name=='consumer_closure_record':
        print(json.dumps(dict(blockedConsumer=str(frame.f_locals.get('path')),failure=str(arg[1]))),flush=True)
    return trace
sys.settrace(trace)
try:
    record=consumer_closure_record(root,Path(plan['product']),paths,Path(plan['replacement']),legacy_terminal=True)
    print(json.dumps(dict(status='retirement-preflight-passed-no-cleanup',consumers=len(record['consumers']))))
finally:
    sys.settrace(None)


from pathlib import Path
from datetime import datetime, timezone
import argparse, copy, hashlib, json, sys
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(r/'scripts'))
from completed_artifact_plan import assert_output_shutdown, terminal_consumer_process
parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--output-plan',type=Path,required=True);parser.add_argument('--views',type=Path,required=True);parser.add_argument('--consumer',action='append',required=True);parser.add_argument('--allow-passed-phase-observation',action='store_true');args=parser.parse_args()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
plan=read(args.plan);product=Path(plan['product']).resolve();binary=product/'compiler.exe';assert product.is_relative_to(b.resolve()) and sha(binary)==read(product/'result.json')['compilerSha256']
summary=[]
for name in args.consumer:
 rawPath=(b/name/'result.json').resolve();assert rawPath.is_relative_to(b.resolve());raw=read(rawPath)
 assert raw['status'] in ('passed','failed','observed-not-qualified') and raw['inputsStable'] and raw['processesStopped']
 if raw['status']=='observed-not-qualified':assert raw['claimsTestPassed'] is False
 assert_output_shutdown(r,rawPath.parent)
 pins={str(p):sha(p) for p in [binary,product/'result.json',rawPath,r/'scripts/completed_artifact_plan.py',Path(__file__).resolve()]};processes=[];validation=[]
 if raw['status']=='passed':
  assert args.allow_passed_phase_observation
  canonical=Path(raw['canonicalPhaseRecord']);proof=read(canonical);compiler=proof['compilerBinaries']['selfhost']
  assert proof['status']=='passed' and set(proof['compilerBinaries'])=={'selfhost'} and (r/compiler['path']).resolve()==binary and compiler['sha256'].upper()==sha(binary)
  assert all(row['status']=='passed' for row in raw['cases'])
  pins[str(canonical)]=sha(canonical)
  for item in raw['processes']:
   command=item['command'];assert command[command.index('-PhaseCompilerSide')+1]=='selfhost'
 for index,item in enumerate(raw['processes']):
  assert terminal_consumer_process(r,rawPath.parent,item) and item['shutdownConfirmed'] and item['shutdownScope']=='owned-windows-job'
  assert item['startedAtUtc'] and item['finishedAtUtc'] and type(item['exit']) is int
  if not any(Path(arg).resolve()==binary for arg in item['command'] if str(arg).lower().endswith('compiler.exe')):continue
  for key in ('stdoutPath','stderrPath'):
   if key in item:p=Path(item[key]);assert p.is_file();pins[str(p)]=sha(p)
  value=copy.deepcopy(item);value['capturedStatus']=value.get('status');value['status']='terminal';processes.append(value);validation.append(dict(original=str(rawPath),processIndex=index,originalProcessSha256=hashlib.sha256(json.dumps(item,sort_keys=True).encode()).hexdigest().upper(),canonicalTerminalCheckPassed=True))
 assert processes,name
 out=(args.views/name).resolve();assert out.is_relative_to(b.resolve());out.mkdir(parents=True,exist_ok=False)
 view=dict(schemaVersion=1,status='passed',scope='Authenticated stopped compiler-consumption observation only; no test or current-source acceptance.',observedAtUtc=datetime.now(timezone.utc).isoformat(),inputsStable=True,processesStopped=True,inputHashes=pins,processes=processes,originalResult=str(rawPath),originalStatus=raw['status'],originalCompleted=raw.get('completed'),originalTotal=raw.get('total'),claimsTestPassed=False,claimsAcceptancePassed=False,claimsGoalComplete=False,originalTestCompletionAdded=0,representation='Existing uncounted terminal-observation protocol. Original failed/nonqualified records preserved; process completion authenticated.',processValidation=validation)
 (out/'result.json').write_text(json.dumps(view,indent=2)+'\n',encoding='utf-8');assert sha(rawPath)==pins[str(rawPath)]
 matches=[x for x in plan['consumerCandidates'] if Path(x['path']).resolve()==rawPath];assert len(matches)==1;matches[0]['originalPath']=matches[0]['path'];matches[0]['path']=str(out/'result.json');summary.append(dict(name=name,terminalProcesses=len(processes)))
assert not args.output_plan.exists();plan['status']='read-only-preflight-with-authenticated-terminal-views';args.output_plan.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(views=summary,originalTestCompletionAdded=0,retirementExecuted=False)))

from pathlib import Path
import json,hashlib,subprocess,zipfile,datetime
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/return25007-current'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
write=lambda p,d:Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
records=dict(csharpPriority='review24985-csharp',csharpOwnership='review24986-csharp-controls',csharpReturnControls='review24989-csharp-controls',nativePriority='return25003-native',nativeOwnership='return25005-native',nativeReturnControls='return25004-native',semantic='return25000-semantic',stdlib='return25001-stdlib',producer='return25002-native')
data={k:read(B/n/'result.json') for k,n in records.items()}
for d in data.values():assert d['status']=='passed' and d['completed']==d['total'] and d['inputsStable'] and d['processesStopped']
pairs=[]
for kind in ['Priority','Ownership','ReturnControls']:
 c,n=data['csharp'+kind],data['native'+kind];assert len(c['cases'])==len(n['cases'])
 for left,right in zip(c['cases'],n['cases']):
  assert left.get('id',left.get('source'))==right.get('id',right.get('source'))
  assert left['passed'] and right['passed']
  if 'observedStdout' in left:assert left['observedStdout']==right['observedStdout']
  if 'returncode' in left:assert left['returncode']==right['returncode']
  shared=[p for p in c['inputHashes'] if p in n['inputHashes'] and p.endswith(('.slg','.txt'))]
  assert shared
  for p in shared:assert c['inputHashes'][p]==n['inputHashes'][p]==sha(p)
  pairs.append(dict(id=left.get('id',left.get('source')),group=kind,passed=True,observedStdout=left.get('observedStdout')))
assert len(pairs)==15
for record in [data['producer'],read(B/'review24984-managed/result.json')]:
 for path,expected in record['inputHashes'].items():
  if path.endswith(('.slg','.cs')):assert sha(path)==expected,(path,'current producer source changed')
sources=['src/Sollang.Compiler/Semantics/SemanticCompiler.cs','selfhost/ir/typed/resolved_context_finalize.slg','selfhost/ir/typed/value_aliases.slg']
for p in sources:
 prod=data['producer'] if p.endswith('.slg') else read(B/'review24984-managed/result.json')
 assert prod['inputHashes'][str((R/p).resolve())]==sha(R/p)
E.mkdir()
for k,d in data.items():write(E/(k+'.json'),d)
write(E/'source-comparison.json',read(B/'return25000-source-comparison.json'))
write(E/'source-connection-audit.json',read(B/'review24981-source-coverage.json'))
write(E/'paired-cases.json',dict(completed=30,total=30,percentage=100.0,programPairs=15,cases=pairs))
entries={}
def add(p,label=None):
 p=Path(p);entries[label or p.relative_to(R).as_posix()]=p.read_bytes()
for p in [Path(__file__),*[B/n for n in ['review24985-priority.py','review24986-controls.py','review24989-controls.py','review24994-priority.py','review24995-controls.py','review24996-ownership.py','return25003-priority.py','return25004-controls.py','return25005-ownership.py','return25000-source-comparison.json','review24999-capture.py','review24981-source-coverage.json']],*[R/p for p in sources],R/'docs/SPEC.md',*R.joinpath('examples/regression/diagnostics').glob('285[01]-*')]:add(p)
for p in sources:entries['before-source/'+p]=subprocess.run(['git','show','HEAD:'+p],capture_output=True,check=True).stdout
for name in [*records.values(),'review24982-priority','review24988-native','review24990-semantic','review24994-native','review24999-ir','review24992-native']:
 directory=B/name
 for p in directory.rglob('*'):
  if p.is_file() and not any(x in p.parts for x in ['.sollang-cache','.w0','compiler','obj','bin']) and not any(x.endswith('.slg-tmp') for x in p.parts) and p.suffix.lower() not in ['.exe','.dll','.pdb','.ll','.bc','.obj','.lib','.pyc']:add(p)
archive=E/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,raw in sorted(entries.items()):z.writestr(n,raw)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(entries)
 for n,raw in entries.items():assert z.read(n)==raw
write(E/'archive-manifest.json',dict(sha256=sha(archive),readbackVerified=True,entries={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest().upper()) for n,raw in sorted(entries.items())}))
q=dict(schemaVersion=1,status='focused-qualified-full-source-and-final-gates-pending',owner='C2026-09-12-385',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Return compatibility precedes Unit-tail ownership diagnostics; source-final linked control owns the actual function result independently of its declared result type.',paired=dict(completed=30,total=30,percentage=100.0,programPairs=15,evidence='paired-cases.json'),semantic=dict(completed=4,total=4),stdlib=dict(completed=1,total=1,sources=144,activeBodies=2071,totalBodies=2101,inactiveBodies=30,diagnostics=0),sourceComparison='source-comparison.json',currentNativeCompiler=str((B/'return25002-native/compiler.exe').relative_to(R).as_posix()),currentManagedCompiler=str((B/'review24984-managed/compiler/Sollang.Compiler.exe').relative_to(R).as_posix()),baselineFailure=dict(result='review24988-native/result.json',completed=1,total=2,nonAdditive=True),firstCandidateFailure=dict(result='review24994-native/result.json',completed=1,total=2,nonAdditive=True,discriminator='review24999-ir/result.json',protected=True),formatFailure=dict(result='review24990-semantic/result.json',invalidSources=1,resolvedBy='Canonical targeted formatter; fresh semantic4 passed, no bypass.'),remainingSourceConnectionAudit='source-connection-audit.json',original1999Runs=0,wholeProfileRuns=0,nativeProducerBuilds=2,archive=dict(path='evidence.zip',sha256=sha(archive),entries=len(entries),readbackVerified=True),claimsWholePhaseComplete=False,claimsGoalComplete=False)
write(E/'qualification.json',q);print(json.dumps(dict(status=q['status'],paired=q['paired'],archiveEntries=len(entries))))

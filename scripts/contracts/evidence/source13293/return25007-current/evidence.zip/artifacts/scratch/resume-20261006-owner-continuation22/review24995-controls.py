from pathlib import Path
import argparse,hashlib,json,sys
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output,cleanup_output
p=argparse.ArgumentParser();p.add_argument('--compiler',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();C=a.compiler.resolve();O=a.output.resolve();B=R/'artifacts/scratch/resume-20261006-owner-continuation22'
fixtures=[(R/f'examples/regression/{n}.slg',R/f'examples/regression/expected/{n}.stdout.txt') for n in ['947-terminating-when-value-arm','957-final-nested-when-all-paths-return','1309-selfhost-terminating-if-branch-result']]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
paths=[Path(__file__),C,*[p for row in fixtures for p in row],*sorted((R/'stdlib').rglob('*.slg'))]
if C.with_suffix('.dll').exists():paths+=managed_runtime_inputs(C)
pins={str(p.resolve()):sha(p) for p in paths};reusable=[B/'review24992-native',B/'product24976-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reusable);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=len(fixtures),inputHashes=pins,cases=[],claimsGoalComplete=False,claimsWholeCompilerSpeedImprovement=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for source,expected in fixtures:
   product=O/(source.stem+'.exe');r=ex.run([str(C),'build',str(source),'-o',str(product),'--target','windows-x64','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')],O/(source.stem+'.build'),timeout=60)
   assert r.returncode==0 and not r.stderr,(r.stdout,r.stderr)
   done=ex.run([str(product)],O/(source.stem+'.run'),timeout=10);text=expected.read_text(encoding='utf-8-sig').replace('\r\n','\n');assert done.returncode==0 and not done.stderr and done.stdout==text,(done.stdout,done.stderr,text)
   result['cases'].append(dict(id=source.stem,source=str(source),passed=True,observedStdout=done.stdout));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reusable)
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

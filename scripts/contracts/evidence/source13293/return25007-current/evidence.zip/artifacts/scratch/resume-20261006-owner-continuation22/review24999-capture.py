from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output,cleanup_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'review24999-ir';P=R/'examples/regression/diagnostics/2851-owned-when-tail-return-type-priority.slg';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
compilers=[('before',B/'product24976-native/compiler.exe'),('candidate',B/'review24992-native/compiler.exe')]
paths=[Path(__file__),P,*sorted((R/'stdlib').rglob('*.slg'))]
for _,c in compilers:
 paths.append(c)
 if c.with_suffix('.dll').exists():paths+=managed_runtime_inputs(c)
pins={str(p.resolve()):sha(p) for p in paths};reusable=[B/'review24992-native',B/'product24976-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reusable);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',scope='Diagnostic captures only; no parity or repair acceptance',completed=0,total=2,inputHashes=pins,cases=[],claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for name,c in compilers:
   r=ex.run([str(c),'typed-ir-nodes',str(P)],O/name,timeout=30)
   assert r.returncode==0 and not r.stderr,(name,r.stdout,r.stderr)
   result['cases'].append(dict(id=name,passed=True,captureOnly=True,typedIr=r.stdout));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reusable)
print(json.dumps(dict(status=result['status'],completed=result['completed'],total=result['total'])))

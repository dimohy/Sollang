from pathlib import Path
import argparse,sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output,cleanup_output
p=argparse.ArgumentParser();p.add_argument('--compiler',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=a.compiler.resolve();O=a.output.resolve();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
fixtures=[R/f'examples/regression/diagnostics/{n}.slg' for n in ['2850-owned-unit-tail-return-type-priority','2851-owned-when-tail-return-type-priority']];expected=[p.with_suffix('.stderr.contains.txt') for p in fixtures];paths=[Path(__file__),C,*fixtures,*expected,*sorted((R/'stdlib').rglob('*.slg'))]
if C.with_suffix('.dll').exists():paths+=managed_runtime_inputs(C)
pins={str(p.resolve()):sha(p) for p in paths};reusable=[B/'return25002-native',B/'product24976-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reusable);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=2,inputHashes=pins,cases=[],claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for source,expectation in zip(fixtures,expected):
   product=O/(source.stem+'.exe');r=ex.run([str(C),'build',str(source),'-o',str(product),'--target','windows-x64','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')],O/source.stem,timeout=60)
   assert r.returncode==1 and not product.exists(),(r.stdout,r.stderr)
   assert all(line in r.stderr for line in expectation.read_text(encoding='utf-8-sig').splitlines() if line),(r.stdout,r.stderr)
   assert 'must be consumed on every control-flow branch' not in r.stderr,r.stderr
   result['cases'].append(dict(id=source.stem,passed=True,diagnostic=r.stderr));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reusable)
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

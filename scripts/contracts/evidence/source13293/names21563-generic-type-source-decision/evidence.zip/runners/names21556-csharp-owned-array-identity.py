from pathlib import Path
import json, hashlib, sys, re, struct, time
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B = ROOT / 'artifacts/scratch/resume-20261006-owner-continuation22'
OUT = B / 'names21556-csharp-owned-array-identity'
CPP = B / 'managed21553/compiler/Sollang.Compiler.exe'
producerPath = B / 'managed21553/result.json'
producer = json.loads(producerPath.read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert producer['status'] == 'passed' and producer['completed'] == producer['total'] == 1 and producer['inputsStable'] and producer['processesStopped']
assert sha(CPP) == producer['generatedOutputHashes'][str(CPP)]
assert all(sha(Path(p)) == h for p,h in producer['inputHashes'].items())
initialize_output(ROOT, OUT, reusable_directories=[B / x / 'compiler-build01' for x in ['v18915', 'v20050', 'v21323']])
OUT.mkdir(exist_ok=False)
fixtures = OUT / 'variants'
fixtures.mkdir()
texts = {'main.slg': 'import cache.alpha as alpha\nimport cache.beta as beta\nmain {\n    alpha.make() -> beta.apply => item\n    item -> len -> println\n}\n', 'beta.slg': 'namespace cache.beta\nimport cache.alpha as alpha\npublic apply<T> value: T -> T uses Console {\n    alpha.make() => temporary\n    temporary -> len -> println\n    "beta" -> println\n    value\n}\n', 'before.slg': 'namespace cache.alpha\npublic struct Payload { public value: Text }\npublic make: -> [Payload; 1] => [Payload; { value: "owned" }]\n', 'after.slg': 'namespace cache.alpha\nstruct Padding { value: Int32 }\npublic struct Payload { public value: Text }\npublic make: -> [Payload; 1] => [Payload; { value: "owned" }]\n'}
for name, text in texts.items():
    (fixtures / name).write_text(text, encoding='utf-8')
project = OUT / 'project'
project.mkdir()
(project / 'main.slg').write_bytes((fixtures / 'main.slg').read_bytes())
(project / 'beta.slg').write_bytes((fixtures / 'beta.slg').read_bytes())
inputs = [Path(__file__), CPP, *managed_runtime_inputs(CPP), producerPath, *fixtures.iterdir(), *map(Path, producer['inputHashes'])]
inputs = list(dict.fromkeys(inputs))
hashes = {str(p): sha(p) for p in inputs}

def namespace_from_name(name):
    data = bytes.fromhex(name[1:]); words = []; value = shift = 0
    for byte in data:
        value |= (byte & 127) << shift
        if byte & 128: shift += 7
        else: words.append(value); value = shift = 0
    assert shift == 0 and words and 0 <= words[0] < len(words)
    return bytes(words[1:1 + words[0]]).decode('utf-8')

def betaFragment(cache):
    words = struct.unpack('<' + 'Q' * (cache.stat().st_size // 8), cache.read_bytes())
    index = 8
    for _ in range(words[5]):
        h = words[index:index + 8]
        name = bytes(words[index + 8:index + 8 + h[4]]).decode()
        start = index + 8 + h[4]
        if h[0] == 1 and name == 'cache.beta':
            return b''.join((v.to_bytes(8, 'little') for v in words[start:start + h[6]]))[:h[5]]
        index = start + h[6]
    raise AssertionError('beta unit missing')
with VerificationContractLease(inputs):
    result = dict(schemaVersion=1, status='running', completed=0, total=4, cases=[], inputHashes=hashes, maximumCaseSeconds=180, scope='Separate generic nominal type identity under unrelated private type insertion and source ordering: unchanged beta prints a literal then returns its input+3. CSharp first; same source order and actual outputs; cached and fresh CSharp beta fragments, CSharp-only qualification before SLG implementation. Mutable staged sources only change between stopped cases; immutable variants pinned.', claimsGoalComplete=False)
    run = VerificationExecution(ROOT, OUT, result, lambda: all((p.is_file() and sha(p) == hashes[str(p)] for p in inputs)), sha)
    error = None
    cppFragments = []
    slgFragments = []
    try:
        for label, variant, expected, outputName in [('cold', 'before.slg', '1\nbeta\n1\n', 'program'), ('changed', 'after.slg', '1\nbeta\n1\n', 'program'), ('fresh-changed', 'after.slg', '1\nbeta\n1\n', 'fresh')]:
            (project / 'alpha.slg').write_bytes((fixtures / variant).read_bytes())
            live = {str(p): sha(p) for p in project.glob('*.slg')}
            d = OUT / ('csharp-' + label)
            d.mkdir()
            start = time.monotonic()
            budget = lambda: max(1, 180 - (time.monotonic() - start))
            exe = project / (outputName + '.exe')
            done = run.run([str(CPP), 'build', *[str(project / n) for n in (['main.slg', 'alpha.slg', 'beta.slg'] if label in ('cold', 'before') else ['main.slg', 'beta.slg', 'alpha.slg'])], '-o', str(exe), '--target', 'windows-x64', '--llvm', str(ROOT / '.tools/llvm-22.1.8'), '--jobs', '1', '-O0'], d / 'build', timeout=budget())
            assert done.returncode == 0 and (not done.stderr), done.stdout + done.stderr
            cache = next((project / '.sollang-cache').glob(outputName + '.*.cgu'))
            fragment = betaFragment(cache)
            (d / 'beta.ll').write_bytes(fragment)
            cppFragments.append(fragment)
            trace = re.search('\\[codegen-cache\\] ([^;]+); reused (\\d+)/(\\d+) units;', done.stdout)
            assert trace
            done = run.run([str(exe)], d / 'run', timeout=budget())
            assert done.returncode == 0 and done.stdout == expected and (not done.stderr), done.stdout + done.stderr
            assert all((sha(Path(p)) == h for p, h in live.items()))
            result['cases'].append(dict(id='csharp-' + label, passed=True, buildExit=0, runExit=0, stdout=done.stdout, reused=int(trace.group(2)), units=int(trace.group(3)), betaFragmentSha256=sha(d / 'beta.ll'), sourceHashes=live))
            result['completed'] += 1
            run.save()
        assert cppFragments[0] == cppFragments[1] == cppFragments[2], 'CSharp fresh/cached beta changed'
        result['cases'].append(dict(id='complete-nominal-type-and-specialization-identity',passed=True,rawModuleBytesEqual=True))
        result['completed'] += 1
        result['status'] = 'passed'
    except BaseException as e:
        error = e
    finally:
        run.finalize(error, cleanup=False)
    if error:
        raise error
print(json.dumps({k: result[k] for k in ['status', 'completed', 'total', 'cases', 'inputsStable', 'processesStopped']}, indent=2))

from pathlib import Path
import sys, json, hashlib, struct, time
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'names21559-csharp-original51-contract';src=ROOT/'examples/regression/51-fixed-array-value-generics.slg';expected=ROOT/'examples/regression/expected/51-fixed-array-value-generics.stdout.txt';contains=expected.with_name('51-fixed-array-value-generics.llvm.contains.txt');compilers=[B/'managed21139/compiler/Sollang.Compiler.exe',B/'managed21553/compiler/Sollang.Compiler.exe'];receipt=B/'managed21553/result.json';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();producer=json.loads(receipt.read_text());assert producer['status']=='passed' and producer['inputsStable'] and producer['processesStopped'];assert all(sha(Path(p))==h for p,h in producer['inputHashes'].items())
inputs=list(dict.fromkeys([src,expected,contains,receipt,*map(Path,producer['inputHashes']),*sorted((ROOT/'stdlib').rglob('*.slg')),*[p for c in compilers for p in [c,*managed_runtime_inputs(c)]] ]));hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir()
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=2,cases=[],inputHashes=hashes,scope='Unchanged original51 runtime and LLVM contains assertions: baseline versus proposed CSharp naming; no oracle updates',maximumCaseSeconds=180,claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  for label,compiler in zip(['baseline','proposed'],compilers):
   d=OUT/label;d.mkdir();exe=d/'program.exe';start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));done=run.run([str(compiler),'build',str(src),'-o',str(exe),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0'],d/'build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout+done.stderr
   done=run.run([str(exe)],d/'run',timeout=budget());assert done.returncode==0 and not done.stderr and done.stdout==expected.read_text(encoding='utf-8-sig'),done.stdout+done.stderr
   cache=next((d/'.sollang-cache').glob('program.*.cgu'));w=struct.unpack('<'+'Q'*(cache.stat().st_size//8),cache.read_bytes());i=8;fragments=[]
   for _ in range(w[5]):
    h=w[i:i+8];s=i+8+h[4];fragments.append(b''.join(v.to_bytes(8,'little') for v in w[s:s+h[6]])[:h[5]].decode('utf-8'));i=s+h[6]
   llvm=''.join(fragments);(d/'original51-cached-units.ll').write_text(llvm,encoding='utf-8');needles=[s for s in contains.read_text(encoding='utf-8-sig').splitlines() if s.strip()];missing=[s for s in needles if s not in llvm];result['cases'].append(dict(id=label,runtimePassed=True,llvmContainsPassed=not missing,required=len(needles),missing=missing));run.save();assert not missing,f'{label}: unchanged original51 LLVM oracle mismatch: {len(missing)}/{len(needles)}';result['completed']+=1;run.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result.get(k) for k in ['status','completed','total','failure','inputsStable','processesStopped']}))

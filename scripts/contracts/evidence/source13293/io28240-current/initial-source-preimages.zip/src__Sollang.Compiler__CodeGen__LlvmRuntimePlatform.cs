using System.Text;
using Sollang.Compiler.Shared;
using Sollang.Compiler.Diagnostics;

namespace Sollang.Compiler.CodeGen;

internal abstract class LlvmRuntimePlatform
{
    public abstract string TargetTriple { get; }

    public abstract string EntryPointName { get; }

    public virtual string EntryPointParameters => "";

    public virtual int PointerBitWidth => 64;

    public virtual void EmitGlobals(StringBuilder globals)
    {
    }

    public abstract void EmitExternalDeclarations(StringBuilder functions);

    public abstract void EmitIoPrimitives(StringBuilder functions);

    public abstract void EmitFilePrimitives(StringBuilder functions);

    public abstract void EmitDirectoryPrimitives(StringBuilder functions);

    public abstract void EmitMappedFilePrimitives(StringBuilder functions);

    public abstract void EmitTimePrimitives(StringBuilder functions);

    public abstract void EmitProcessPrimitives(StringBuilder functions);

    public virtual void EmitSocketPrimitives(StringBuilder functions) =>
        throw new SollangException("network sockets are unavailable on the current target");

    public virtual void EmitSecureRandomPrimitives(StringBuilder functions) =>
        throw new SollangException("cryptographic random bytes are unavailable on the current target");

    public virtual void EmitEnvironmentPrimitives(StringBuilder functions)
    {
    }

    public abstract void EmitEntryHandles(StringBuilder functions);

    public virtual void EmitExitHandles(StringBuilder functions)
    {
    }

    public virtual void EmitProcessEntry(StringBuilder functions)
    {
    }

    public virtual bool SupportsHeapAllocation => true;

    public virtual bool SupportsMemoryMapping => true;

    public virtual bool SupportsProcessArguments => true;

    public virtual bool SupportsEnvironment => true;

    public virtual bool SupportsChildProcesses => true;

    public virtual bool SupportsDirectoryTraversal => true;

    public virtual bool SupportsNetwork => true;

    public virtual bool SupportsSecureRandom => true;

    public virtual bool SupportsAsync => false;

    public virtual bool SupportsComputePool => false;

    public virtual bool SupportsEventStreams => true;

    public virtual bool SupportsConcurrentStreamJoins => false;

    public bool UsesAsyncFile { get; set; }
    public bool UsesProcessRuntime { get; set; }
    public bool UsesProcessCapture { get; set; }
    public bool UsesProcessExit { get; set; }
    public bool UsesComputePool { get; set; }
    public bool UsesDirectoryTraversal { get; set; }
    public bool UsesNetwork { get; set; }
    public bool UsesSocketCompletion { get; set; }
    public bool UsesSecureRandom { get; set; }
    public bool UsesMouseEvents { get; set; }
    public bool UsesConcurrentStreamJoins { get; set; }
    public bool UsesStandardError { get; set; }

    public virtual void EmitComputePrimitives(StringBuilder functions)
    {
    }

    public virtual void EmitEventPrimitives(StringBuilder functions)
    {
    }

    public void EmitConcurrentStreamJoinPrimitives(StringBuilder functions)
    {
        EmitConcurrentStreamJoinPlatformPrimitives(functions);
        EmitConcurrentStreamJoinCommonPrimitives(functions);
    }

    protected virtual void EmitConcurrentStreamJoinPlatformPrimitives(StringBuilder functions) =>
        throw new SollangException("bounded concurrent stream joins are unavailable on the current target");

    private static void EmitConcurrentStreamJoinCommonPrimitives(StringBuilder functions)
    {
        functions.AppendLine(NativeRuntimePolicy.StreamJoinWorkerFunctions());
        functions.AppendLine();
        functions.AppendLine(NativeRuntimePolicy.StreamJoinLifecycleFunctions());
        functions.AppendLine();
    }

    protected static void EmitDirectoryNodePrimitives(StringBuilder functions)
    {
        functions.AppendLine("""
            define internal i32 @sollang_directory_compare_nodes(ptr %left, ptr %right) #0 {
            entry:
              %left_len_slot = getelementptr %sollang.directory_node, ptr %left, i32 0, i32 1
              %left_len = load i64, ptr %left_len_slot, align 8
              %right_len_slot = getelementptr %sollang.directory_node, ptr %right, i32 0, i32 1
              %right_len = load i64, ptr %right_len_slot, align 8
              %left_name = getelementptr i8, ptr %left, i64 24
              %right_name = getelementptr i8, ptr %right, i64 24
              %left_shorter = icmp ult i64 %left_len, %right_len
              %minimum = select i1 %left_shorter, i64 %left_len, i64 %right_len
              br label %compare

            compare:
              %index = phi i64 [ 0, %entry ], [ %next, %equal_byte ]
              %within = icmp ult i64 %index, %minimum
              br i1 %within, label %compare_byte, label %compare_length

            compare_byte:
              %left_ptr = getelementptr i8, ptr %left_name, i64 %index
              %right_ptr = getelementptr i8, ptr %right_name, i64 %index
              %left_byte = load i8, ptr %left_ptr, align 1
              %right_byte = load i8, ptr %right_ptr, align 1
              %same = icmp eq i8 %left_byte, %right_byte
              br i1 %same, label %equal_byte, label %different_byte

            equal_byte:
              %next = add i64 %index, 1
              br label %compare

            different_byte:
              %less = icmp ult i8 %left_byte, %right_byte
              %byte_result = select i1 %less, i32 -1, i32 1
              ret i32 %byte_result

            compare_length:
              %same_length = icmp eq i64 %left_len, %right_len
              br i1 %same_length, label %equal, label %different_length

            different_length:
              %length_result = select i1 %left_shorter, i32 -1, i32 1
              ret i32 %length_result

            equal:
              ret i32 0
            }

            define internal ptr @sollang_directory_insert_sorted(ptr %head, ptr %node) #0 {
            entry:
              %empty = icmp eq ptr %head, null
              br i1 %empty, label %only, label %compare_head

            only:
              %only_next = getelementptr %sollang.directory_node, ptr %node, i32 0, i32 0
              store ptr null, ptr %only_next, align 8
              ret ptr %node

            compare_head:
              %head_order = call i32 @sollang_directory_compare_nodes(ptr %node, ptr %head)
              %before_head = icmp slt i32 %head_order, 0
              br i1 %before_head, label %prepend, label %scan_start

            prepend:
              %prepend_next = getelementptr %sollang.directory_node, ptr %node, i32 0, i32 0
              store ptr %head, ptr %prepend_next, align 8
              ret ptr %node

            scan_start:
              %head_next_slot = getelementptr %sollang.directory_node, ptr %head, i32 0, i32 0
              %head_next = load ptr, ptr %head_next_slot, align 8
              br label %scan

            scan:
              %previous = phi ptr [ %head, %scan_start ], [ %current, %advance ]
              %current = phi ptr [ %head_next, %scan_start ], [ %next, %advance ]
              %at_end = icmp eq ptr %current, null
              br i1 %at_end, label %append, label %compare_current

            compare_current:
              %order = call i32 @sollang_directory_compare_nodes(ptr %node, ptr %current)
              %before = icmp slt i32 %order, 0
              br i1 %before, label %insert, label %advance

            advance:
              %current_next_slot = getelementptr %sollang.directory_node, ptr %current, i32 0, i32 0
              %next = load ptr, ptr %current_next_slot, align 8
              br label %scan

            insert:
              %node_next = getelementptr %sollang.directory_node, ptr %node, i32 0, i32 0
              store ptr %current, ptr %node_next, align 8
              %previous_next = getelementptr %sollang.directory_node, ptr %previous, i32 0, i32 0
              store ptr %node, ptr %previous_next, align 8
              ret ptr %head

            append:
              %append_node_next = getelementptr %sollang.directory_node, ptr %node, i32 0, i32 0
              store ptr null, ptr %append_node_next, align 8
              %append_previous_next = getelementptr %sollang.directory_node, ptr %previous, i32 0, i32 0
              store ptr %node, ptr %append_previous_next, align 8
              ret ptr %head
            }

            define internal void @sollang_directory_free_nodes(ptr %head) #0 {
            entry:
              br label %loop

            loop:
              %node = phi ptr [ %head, %entry ], [ %next, %body ]
              %done = icmp eq ptr %node, null
              br i1 %done, label %finish, label %body

            body:
              %next_slot = getelementptr %sollang.directory_node, ptr %node, i32 0, i32 0
              %next = load ptr, ptr %next_slot, align 8
              call void @sollang_free(ptr %node)
              br label %loop

            finish:
              ret void
            }

            define internal ptr @sollang_directory_serialize(ptr %head, i64 %total) #0 {
            entry:
              %empty = icmp eq i64 %total, 0
              br i1 %empty, label %empty_result, label %allocate

            empty_result:
              ret ptr null

            allocate:
              %output = call ptr @sollang_alloc(i64 %total)
              %allocated = icmp ne ptr %output, null
              br i1 %allocated, label %loop, label %allocation_failed

            allocation_failed:
              call void @sollang_directory_free_nodes(ptr %head)
              ret ptr null

            loop:
              %node = phi ptr [ %head, %allocate ], [ %next_node, %body ]
              %offset = phi i64 [ 0, %allocate ], [ %next_offset, %body ]
              %done = icmp eq ptr %node, null
              br i1 %done, label %finish, label %body

            body:
              %next_slot = getelementptr %sollang.directory_node, ptr %node, i32 0, i32 0
              %next_node = load ptr, ptr %next_slot, align 8
              %length_slot = getelementptr %sollang.directory_node, ptr %node, i32 0, i32 1
              %length = load i64, ptr %length_slot, align 8
              %kind_slot = getelementptr %sollang.directory_node, ptr %node, i32 0, i32 2
              %kind = load i8, ptr %kind_slot, align 1
              %record = getelementptr i8, ptr %output, i64 %offset
              store i8 %kind, ptr %record, align 1
              %length32 = trunc i64 %length to i32
              %length0 = trunc i32 %length32 to i8
              %length_shift1 = lshr i32 %length32, 8
              %length1 = trunc i32 %length_shift1 to i8
              %length_shift2 = lshr i32 %length32, 16
              %length2 = trunc i32 %length_shift2 to i8
              %length_shift3 = lshr i32 %length32, 24
              %length3 = trunc i32 %length_shift3 to i8
              %length_ptr0 = getelementptr i8, ptr %record, i64 1
              %length_ptr1 = getelementptr i8, ptr %record, i64 2
              %length_ptr2 = getelementptr i8, ptr %record, i64 3
              %length_ptr3 = getelementptr i8, ptr %record, i64 4
              store i8 %length0, ptr %length_ptr0, align 1
              store i8 %length1, ptr %length_ptr1, align 1
              store i8 %length2, ptr %length_ptr2, align 1
              store i8 %length3, ptr %length_ptr3, align 1
              %destination = getelementptr i8, ptr %record, i64 5
              %source = getelementptr i8, ptr %node, i64 24
              call void @llvm.memcpy.p0.p0.i64(ptr %destination, ptr %source, i64 %length, i1 false)
              %record_size = add i64 %length, 5
              %next_offset = add i64 %offset, %record_size
              call void @sollang_free(ptr %node)
              br label %loop

            finish:
              ret ptr %output
            }

            """);
    }

    public void EmitMemoryOutputSinkPrimitives(StringBuilder functions)
    {
        functions.AppendLine(NativeRuntimePolicy.MemoryOutputSinkFunctions());
    }

    public virtual void EmitAsyncPrimitives(StringBuilder functions)
    {
        if (UsesAsyncFile)
        {
            functions.AppendLine(NativeRuntimePolicy.AsyncFilePushRequestFunction());
            functions.AppendLine();
            functions.AppendLine(NativeRuntimePolicy.IoPushCompletionFunction());
            functions.AppendLine();
            functions.AppendLine(NativeRuntimePolicy.AsyncFileWorkerFunction());
            functions.AppendLine();
            functions.AppendLine(NativeRuntimePolicy.IoDrainCompletionsFunction());
            functions.AppendLine();
            functions.AppendLine(NativeRuntimePolicy.AsyncFileSubmitFunction());
            functions.AppendLine();
            functions.AppendLine(NativeRuntimePolicy.IoWaitIdleFunction());
            functions.AppendLine();
            functions.AppendLine(NativeRuntimePolicy.IoShutdownFunction());
            functions.AppendLine();
            functions.AppendLine(NativeRuntimePolicy.AsyncFileShutdownFunction());
            functions.AppendLine();
            functions.AppendLine(NativeRuntimePolicy.AsyncFileTaskWorkerFunction());
            functions.AppendLine();
            functions.AppendLine(NativeRuntimePolicy.AsyncFileTaskCancelFunction());
            functions.AppendLine();
            functions.AppendLine(NativeRuntimePolicy.AsyncFileOpenTaskStartFunction());
            functions.AppendLine();
            functions.AppendLine(NativeRuntimePolicy.AsyncFileBufferTaskStartFunction());
            functions.AppendLine();
        }
        else
        {
            functions.AppendLine("""
            define internal i1 @sollang_io_drain_completions() #0 {
            entry:
              ret i1 false
            }

            define internal void @sollang_platform_io_wait_completion(i64 %requested) #0 {
            entry:
              ret void
            }

            define internal void @sollang_file_wait_idle() #0 {
            entry:
              ret void
            }

            define internal void @sollang_async_shutdown() #0 {
            entry:
              ret void
            }

            """);
        }

        functions.AppendLine("""

            define internal void @sollang_task_enqueue_ready(ptr %control) #0 {
            entry:
              %status_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 4
              store i32 0, ptr %status_slot, align 4
              %next_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 3
              store ptr null, ptr %next_slot, align 8
              %tail = load ptr, ptr @sollang_task_ready_tail, align 8
              %empty = icmp eq ptr %tail, null
              br i1 %empty, label %first, label %append

            first:
              store ptr %control, ptr @sollang_task_ready_head, align 8
              br label %queued

            append:
              %tail_next_slot = getelementptr %sollang.task_control, ptr %tail, i32 0, i32 3
              store ptr %control, ptr %tail_next_slot, align 8
              br label %queued

            queued:
              store ptr %control, ptr @sollang_task_ready_tail, align 8
              ret void
            }

            define internal void @sollang_task_park_on(ptr %parent, ptr %child) #0 {
            entry:
              %child_status_slot = getelementptr %sollang.task_control, ptr %child, i32 0, i32 4
              %child_status = load i32, ptr %child_status_slot, align 4
              %completed = icmp eq i32 %child_status, 2
              br i1 %completed, label %done, label %park

            park:
              %child_waiter_slot = getelementptr %sollang.task_control, ptr %child, i32 0, i32 9
              %existing_waiter = load ptr, ptr %child_waiter_slot, align 8
              %available = icmp eq ptr %existing_waiter, null
              br i1 %available, label %attach, label %invalid

            attach:
              store ptr %parent, ptr %child_waiter_slot, align 8
              %parent_child_slot = getelementptr %sollang.task_control, ptr %parent, i32 0, i32 10
              store ptr %child, ptr %parent_child_slot, align 8
              %parent_status_slot = getelementptr %sollang.task_control, ptr %parent, i32 0, i32 4
              store i32 5, ptr %parent_status_slot, align 4
              br label %done

            invalid:
              call void @llvm.trap()
              unreachable

            done:
              ret void
            }

            define internal void @sollang_task_wake_waiter(ptr %child) #0 {
            entry:
              %waiter_slot = getelementptr %sollang.task_control, ptr %child, i32 0, i32 9
              %waiter = load ptr, ptr %waiter_slot, align 8
              %has_waiter = icmp ne ptr %waiter, null
              br i1 %has_waiter, label %wake, label %done

            wake:
              store ptr null, ptr %waiter_slot, align 8
              %waiter_child_slot = getelementptr %sollang.task_control, ptr %waiter, i32 0, i32 10
              store ptr null, ptr %waiter_child_slot, align 8
              call void @sollang_task_enqueue_ready(ptr %waiter)
              br label %done

            done:
              ret void
            }

            define internal void @sollang_timer_park(ptr %control, i64 %deadline) #0 {
            entry:
              %status_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 4
              store i32 4, ptr %status_slot, align 4
              %deadline_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 8
              store i64 %deadline, ptr %deadline_slot, align 8
              %head = load ptr, ptr @sollang_task_timer_head, align 8
              br label %scan

            scan:
              %previous = phi ptr [ null, %entry ], [ %current, %advance ]
              %current = phi ptr [ %head, %entry ], [ %next, %advance ]
              %has_current = icmp ne ptr %current, null
              br i1 %has_current, label %compare, label %insert

            compare:
              %current_deadline_slot = getelementptr %sollang.task_control, ptr %current, i32 0, i32 8
              %current_deadline = load i64, ptr %current_deadline_slot, align 8
              %before_current = icmp slt i64 %deadline, %current_deadline
              br i1 %before_current, label %insert, label %advance

            advance:
              %current_next_slot = getelementptr %sollang.task_control, ptr %current, i32 0, i32 7
              %next = load ptr, ptr %current_next_slot, align 8
              br label %scan

            insert:
              %control_next_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 7
              store ptr %current, ptr %control_next_slot, align 8
              %at_head = icmp eq ptr %previous, null
              br i1 %at_head, label %insert_head, label %insert_after

            insert_head:
              store ptr %control, ptr @sollang_task_timer_head, align 8
              ret void

            insert_after:
              %previous_next_slot = getelementptr %sollang.task_control, ptr %previous, i32 0, i32 7
              store ptr %control, ptr %previous_next_slot, align 8
              ret void
            }

            define internal void @sollang_timer_wake_due() #0 {
            entry:
              br label %scan

            scan:
              %head = load ptr, ptr @sollang_task_timer_head, align 8
              %has_head = icmp ne ptr %head, null
              br i1 %has_head, label %check, label %done

            check:
              %deadline_slot = getelementptr %sollang.task_control, ptr %head, i32 0, i32 8
              %deadline = load i64, ptr %deadline_slot, align 8
              %now = call i64 @sollang_now_millis()
              %due = icmp sge i64 %now, %deadline
              br i1 %due, label %wake, label %done

            wake:
              %timer_next_slot = getelementptr %sollang.task_control, ptr %head, i32 0, i32 7
              %timer_next = load ptr, ptr %timer_next_slot, align 8
              store ptr %timer_next, ptr @sollang_task_timer_head, align 8
              store ptr null, ptr %timer_next_slot, align 8
              call void @sollang_task_enqueue_ready(ptr %head)
              br label %scan

            done:
              ret void
            }

            define internal i1 @sollang_timer_wait_next() #0 {
            entry:
              %file_progress = call i1 @sollang_io_drain_completions()
              call void @sollang_timer_wake_due()
              %ready = load ptr, ptr @sollang_task_ready_head, align 8
              %has_ready = icmp ne ptr %ready, null
              br i1 %has_ready, label %progress, label %inspect_timer

            inspect_timer:
              %timer = load ptr, ptr @sollang_task_timer_head, align 8
              %has_timer = icmp ne ptr %timer, null
              %file_outstanding = load atomic i64, ptr @sollang_io_outstanding acquire, align 8
              %has_file = icmp ne i64 %file_outstanding, 0
              br i1 %has_timer, label %timer_timeout, label %inspect_file

            inspect_file:
              br i1 %has_file, label %wait_file_only, label %stalled

            timer_timeout:
              %deadline_slot = getelementptr %sollang.task_control, ptr %timer, i32 0, i32 8
              %deadline = load i64, ptr %deadline_slot, align 8
              %now = call i64 @sollang_now_millis()
              %remaining_raw = sub i64 %deadline, %now
              %positive = icmp sgt i64 %remaining_raw, 0
              %remaining = select i1 %positive, i64 %remaining_raw, i64 0
              br i1 %has_file, label %wait_file_or_timer, label %wait_timer_only

            wait_file_or_timer:
              call void @sollang_platform_io_wait_completion(i64 %remaining)
              %file_timer_progress = call i1 @sollang_io_drain_completions()
              call void @sollang_timer_wake_due()
              br label %progress

            wait_file_only:
              call void @sollang_platform_io_wait_completion(i64 -1)
              %file_only_progress = call i1 @sollang_io_drain_completions()
              br label %progress

            wait_timer_only:
              call void @sollang_wait_millis(i64 %remaining)
              call void @sollang_timer_wake_due()
              br label %progress

            progress:
              ret i1 true

            stalled:
              ret i1 false
            }

            define internal i1 @sollang_sleep_worker(ptr %control) #0 {
            entry:
              %deadline_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 8
              %deadline = load i64, ptr %deadline_slot, align 8
              %now = call i64 @sollang_now_millis()
              %ready = icmp sge i64 %now, %deadline
              br i1 %ready, label %complete, label %pending

            complete:
              ret i1 true

            pending:
              call void @sollang_timer_park(ptr %control, i64 %deadline)
              ret i1 false
            }

            define internal void @sollang_sleep_cancel(ptr %control) #0 {
            entry:
              %context_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 0
              %context = load ptr, ptr %context_slot, align 8
              call void @sollang_free(ptr %context)
              ret void
            }

            define internal ptr @sollang_task_start(ptr %worker, ptr %destroy, ptr %cancel, ptr %context) #0 {
            entry:
              %control = call ptr @sollang_alloc(i64 168)
              %allocated = icmp ne ptr %control, null
              br i1 %allocated, label %initialize, label %fail

            initialize:
              %context_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 0
              store ptr %context, ptr %context_slot, align 8
              %resume_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 1
              store ptr %worker, ptr %resume_slot, align 8
              %destroy_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 2
              store ptr %destroy, ptr %destroy_slot, align 8
              %next_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 3
              store ptr null, ptr %next_slot, align 8
              %status_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 4
              store i32 0, ptr %status_slot, align 4
              %state_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 5
              store i32 0, ptr %state_slot, align 4
              %cancel_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 6
              store ptr %cancel, ptr %cancel_slot, align 8
              %timer_next_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 7
              store ptr null, ptr %timer_next_slot, align 8
              %deadline_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 8
              store i64 0, ptr %deadline_slot, align 8
              %waiter_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 9
              store ptr null, ptr %waiter_slot, align 8
              %waiting_child_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 10
              store ptr null, ptr %waiting_child_slot, align 8
              %file_size_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 11
              store i32 0, ptr %file_size_slot, align 4
              %file_phase_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 12
              store i32 0, ptr %file_phase_slot, align 4
              %file_data_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 13
              store i64 0, ptr %file_data_slot, align 8
              %file_count_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 14
              store i64 0, ptr %file_count_slot, align 8
              %file_ok_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 15
              store i32 0, ptr %file_ok_slot, align 4
              %file_next_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 16
              store ptr null, ptr %file_next_slot, align 8
              %file_handle_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 17
              store i64 -1, ptr %file_handle_slot, align 8
              %file_offset_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 18
              store i64 0, ptr %file_offset_slot, align 8
              %file_explicit_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 19
              store i32 0, ptr %file_explicit_slot, align 4
              %file_operation_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 20
              store i32 0, ptr %file_operation_slot, align 4
              %result_address_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 21
              store ptr null, ptr %result_address_slot, align 8
              %result_completion_slot = getelementptr %sollang.task_control, ptr %control, i32 0, i32 22
              store ptr null, ptr %result_completion_slot, align 8
              %tail = load ptr, ptr @sollang_task_ready_tail, align 8
              %empty = icmp eq ptr %tail, null
              br i1 %empty, label %first, label %append

            first:
              store ptr %control, ptr @sollang_task_ready_head, align 8
              br label %queued

            append:
              %tail_next_slot = getelementptr %sollang.task_control, ptr %tail, i32 0, i32 3
              store ptr %control, ptr %tail_next_slot, align 8
              br label %queued

            queued:
              store ptr %control, ptr @sollang_task_ready_tail, align 8
              ret ptr %control

            fail:
              ret ptr null
            }

            define internal i1 @sollang_task_join(ptr %handle) #0 {
            entry:
              br label %poll

            poll:
              %target_status_slot = getelementptr %sollang.task_control, ptr %handle, i32 0, i32 4
              %target_status = load i32, ptr %target_status_slot, align 4
              %completed = icmp eq i32 %target_status, 2
              br i1 %completed, label %success, label %dequeue

            dequeue:
              %ready = load ptr, ptr @sollang_task_ready_head, align 8
              %has_ready = icmp ne ptr %ready, null
              br i1 %has_ready, label %run, label %wait

            wait:
              %timer_progress = call i1 @sollang_timer_wait_next()
              br i1 %timer_progress, label %poll, label %fail

            run:
              %next_slot = getelementptr %sollang.task_control, ptr %ready, i32 0, i32 3
              %next = load ptr, ptr %next_slot, align 8
              store ptr %next, ptr @sollang_task_ready_head, align 8
              %became_empty = icmp eq ptr %next, null
              br i1 %became_empty, label %clear_tail, label %invoke

            clear_tail:
              store ptr null, ptr @sollang_task_ready_tail, align 8
              br label %invoke

            invoke:
              %ready_status_slot = getelementptr %sollang.task_control, ptr %ready, i32 0, i32 4
              store i32 1, ptr %ready_status_slot, align 4
              %resume_slot = getelementptr %sollang.task_control, ptr %ready, i32 0, i32 1
              %worker = load ptr, ptr %resume_slot, align 8
              %worker_complete = call i1 %worker(ptr %ready)
              br i1 %worker_complete, label %complete, label %requeue

            complete:
              store i32 2, ptr %ready_status_slot, align 4
              call void @sollang_task_wake_waiter(ptr %ready)
              br label %poll

            requeue:
              %pending_status = load i32, ptr %ready_status_slot, align 4
              %waiting = icmp uge i32 %pending_status, 4
              br i1 %waiting, label %poll, label %requeue_ready

            requeue_ready:
              store i32 0, ptr %ready_status_slot, align 4
              store ptr null, ptr %next_slot, align 8
              %tail = load ptr, ptr @sollang_task_ready_tail, align 8
              %queue_empty = icmp eq ptr %tail, null
              br i1 %queue_empty, label %requeue_first, label %requeue_append

            requeue_first:
              store ptr %ready, ptr @sollang_task_ready_head, align 8
              br label %requeued

            requeue_append:
              %tail_next_slot = getelementptr %sollang.task_control, ptr %tail, i32 0, i32 3
              store ptr %ready, ptr %tail_next_slot, align 8
              br label %requeued

            requeued:
              store ptr %ready, ptr @sollang_task_ready_tail, align 8
              br label %poll

            success:
              ret i1 true

            fail:
              ret i1 false
            }

            define internal i1 @sollang_task_release(ptr %handle) #0 {
            entry:
              %status_slot = getelementptr %sollang.task_control, ptr %handle, i32 0, i32 4
              %status = load i32, ptr %status_slot, align 4
              %completed = icmp eq i32 %status, 2
              br i1 %completed, label %destroy, label %fail

            destroy:
              %destroy_slot = getelementptr %sollang.task_control, ptr %handle, i32 0, i32 2
              %destroy_fn = load ptr, ptr %destroy_slot, align 8
              %context_slot = getelementptr %sollang.task_control, ptr %handle, i32 0, i32 0
              %context = load ptr, ptr %context_slot, align 8
              call void %destroy_fn(ptr %context)
              call void @sollang_free(ptr %handle)
              ret i1 true

            fail:
              ret i1 false
            }

            define internal i1 @sollang_task_cancel(ptr %handle) #0 {
            entry:
              %status_slot = getelementptr %sollang.task_control, ptr %handle, i32 0, i32 4
              %status = load i32, ptr %status_slot, align 4
              %completed = icmp eq i32 %status, 2
              br i1 %completed, label %destroy, label %check_queued

            check_queued:
              %queued = icmp eq i32 %status, 0
              br i1 %queued, label %find, label %check_waiting

            check_waiting:
              %waiting_timer = icmp eq i32 %status, 4
              br i1 %waiting_timer, label %timer_find, label %check_child_waiting

            check_child_waiting:
              %waiting_child = icmp eq i32 %status, 5
              br i1 %waiting_child, label %detach_child, label %check_file_waiting

            check_file_waiting:
              %waiting_file = icmp eq i32 %status, 6
              br i1 %waiting_file, label %cancel_file, label %check_socket_completion_waiting

            check_socket_completion_waiting:
              %waiting_socket_completion = icmp eq i32 %status, 7
              br i1 %waiting_socket_completion, label %cancel_socket_completion, label %fail

            cancel_file:
              %file_phase_slot = getelementptr %sollang.task_control, ptr %handle, i32 0, i32 12
              store atomic i32 3, ptr %file_phase_slot release, align 4
              store i32 3, ptr %status_slot, align 4
              ret i1 true

            cancel_socket_completion:
              %socket_phase_slot = getelementptr %sollang.task_control, ptr %handle, i32 0, i32 12
              store atomic i32 3, ptr %socket_phase_slot release, align 4
              store i32 3, ptr %status_slot, align 4
              %socket_cancel_phase_slot = getelementptr %sollang.task_control, ptr %handle, i32 0, i32 19
              store atomic i32 1, ptr %socket_cancel_phase_slot release, align 4
              %socket_cancel_slot = getelementptr %sollang.task_control, ptr %handle, i32 0, i32 6
              %socket_cancel_fn = load ptr, ptr %socket_cancel_slot, align 8
              call void %socket_cancel_fn(ptr %handle)
              ret i1 true

            detach_child:
              %waiting_child_slot = getelementptr %sollang.task_control, ptr %handle, i32 0, i32 10
              %child = load ptr, ptr %waiting_child_slot, align 8
              %has_child = icmp ne ptr %child, null
              br i1 %has_child, label %clear_child_waiter, label %fail

            clear_child_waiter:
              %child_waiter_slot = getelementptr %sollang.task_control, ptr %child, i32 0, i32 9
              store ptr null, ptr %child_waiter_slot, align 8
              store ptr null, ptr %waiting_child_slot, align 8
              store i32 3, ptr %status_slot, align 4
              br label %destroy

            find:
              %head = load ptr, ptr @sollang_task_ready_head, align 8
              br label %scan

            scan:
              %previous = phi ptr [ null, %find ], [ %current, %advance ]
              %current = phi ptr [ %head, %find ], [ %next, %advance ]
              %has_current = icmp ne ptr %current, null
              br i1 %has_current, label %compare, label %fail

            compare:
              %found = icmp eq ptr %current, %handle
              br i1 %found, label %unlink, label %advance

            advance:
              %current_next_slot = getelementptr %sollang.task_control, ptr %current, i32 0, i32 3
              %next = load ptr, ptr %current_next_slot, align 8
              br label %scan

            unlink:
              %handle_next_slot = getelementptr %sollang.task_control, ptr %handle, i32 0, i32 3
              %handle_next = load ptr, ptr %handle_next_slot, align 8
              %is_head = icmp eq ptr %previous, null
              br i1 %is_head, label %unlink_head, label %unlink_after

            unlink_head:
              store ptr %handle_next, ptr @sollang_task_ready_head, align 8
              br label %repair_tail

            unlink_after:
              %previous_next_slot = getelementptr %sollang.task_control, ptr %previous, i32 0, i32 3
              store ptr %handle_next, ptr %previous_next_slot, align 8
              br label %repair_tail

            repair_tail:
              %tail = load ptr, ptr @sollang_task_ready_tail, align 8
              %is_tail = icmp eq ptr %tail, %handle
              br i1 %is_tail, label %replace_tail, label %mark_cancelled

            replace_tail:
              store ptr %previous, ptr @sollang_task_ready_tail, align 8
              br label %mark_cancelled

            mark_cancelled:
              store i32 3, ptr %status_slot, align 4
              br label %destroy

            timer_find:
              %timer_head = load ptr, ptr @sollang_task_timer_head, align 8
              br label %timer_scan

            timer_scan:
              %timer_previous = phi ptr [ null, %timer_find ], [ %timer_current, %timer_advance ]
              %timer_current = phi ptr [ %timer_head, %timer_find ], [ %timer_next, %timer_advance ]
              %timer_has_current = icmp ne ptr %timer_current, null
              br i1 %timer_has_current, label %timer_compare, label %fail

            timer_compare:
              %timer_found = icmp eq ptr %timer_current, %handle
              br i1 %timer_found, label %timer_unlink, label %timer_advance

            timer_advance:
              %timer_current_next_slot = getelementptr %sollang.task_control, ptr %timer_current, i32 0, i32 7
              %timer_next = load ptr, ptr %timer_current_next_slot, align 8
              br label %timer_scan

            timer_unlink:
              %handle_timer_next_slot = getelementptr %sollang.task_control, ptr %handle, i32 0, i32 7
              %handle_timer_next = load ptr, ptr %handle_timer_next_slot, align 8
              %timer_is_head = icmp eq ptr %timer_previous, null
              br i1 %timer_is_head, label %timer_unlink_head, label %timer_unlink_after

            timer_unlink_head:
              store ptr %handle_timer_next, ptr @sollang_task_timer_head, align 8
              br label %timer_mark_cancelled

            timer_unlink_after:
              %timer_previous_next_slot = getelementptr %sollang.task_control, ptr %timer_previous, i32 0, i32 7
              store ptr %handle_timer_next, ptr %timer_previous_next_slot, align 8
              br label %timer_mark_cancelled

            timer_mark_cancelled:
              store ptr null, ptr %handle_timer_next_slot, align 8
              store i32 3, ptr %status_slot, align 4
              br label %destroy

            destroy:
              %cancel_slot = getelementptr %sollang.task_control, ptr %handle, i32 0, i32 6
              %cancel_fn = load ptr, ptr %cancel_slot, align 8
              call void %cancel_fn(ptr %handle)
              call void @sollang_free(ptr %handle)
              ret i1 true

            fail:
              ret i1 false
            }

            """);
    }

    public virtual void EmitExitCleanup(StringBuilder functions)
    {
    }

    public virtual void EmitEnvironmentCleanup(StringBuilder functions)
    {
    }

    public abstract void EmitMemoryDeclarations(StringBuilder functions);

    public abstract void EmitMemoryPrimitives(StringBuilder functions);

    public static LlvmRuntimePlatform Create(CompilationTarget target)
    {
        return target switch
        {
            CompilationTarget.WindowsX64 => new WindowsLlvmRuntimePlatform(),
            CompilationTarget.LinuxX64 => new LinuxLlvmRuntimePlatform(),
            CompilationTarget.Wasm32Browser => new WasmBrowserLlvmRuntimePlatform(),
            _ => throw new SollangException($"unsupported target '{target}'")
        };
    }
}

define i32 @sollang_m146_s0(i32 %arg) {
entry:
  %v118115 = add i32 %arg, 3
  ret i32 %v118115
}
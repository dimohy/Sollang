define internal i32 @sollang_fn_cache_beta_apply(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, i32 %it) #0 {
entry:
  %add0 = add i32 %it, 3
  ret i32 %add0
}


using System.Reflection;
using System.Collections;
using System.Runtime.ExceptionServices;
using System.Text.Json;

// Temporary adapter to the existing production frontend. Remove when the
// managed compiler exposes a canonical semantic-only check command.
internal static class SemanticPreflight
{
    private static object? Invoke(MethodInfo method, object? owner, object?[] args)
    {
        try { return method.Invoke(owner, args); }
        catch (TargetInvocationException error) when (error.InnerException is { } inner)
        {
            ExceptionDispatchInfo.Capture(inner).Throw();
            throw;
        }
    }

    public static int Main(string[] args)
    {
        try
        {
            if (args.Length < 2) throw new ArgumentException("compiler DLL and source paths required");
            var assembly = Assembly.LoadFrom(Path.GetFullPath(args[0]));
            var app = assembly.GetType("Sollang.Compiler.Cli.CompilerApp", true)!;
            var target = Enum.Parse(assembly.GetType("Sollang.Compiler.CompilationTarget", true)!, "WindowsX64");
            var loaded = Invoke(app.GetMethod("LoadProgram", BindingFlags.Static | BindingFlags.NonPublic)!,
                null, [args[1..].Select(Path.GetFullPath).ToArray(), null, target])!;
            var program = loaded.GetType().GetProperty("Program")!.GetValue(loaded)!;
            var functions=((IEnumerable)program.GetType().GetProperty("Functions")!.GetValue(program)!).Cast<object>().Where(x=>(string)x.GetType().GetProperty("ModuleName")!.GetValue(x)! == "probe").Select(x=>{
                var type=x.GetType();object? Read(string name)=>type.GetProperty(name)!.GetValue(x);
                var full=(string)Read("Name")!;return new {name=full[(full.LastIndexOf('.')+1)..],blockInput=Read("BlockInputType"),blockResult=Read("BlockResultType")};
            }).ToArray();
            Console.WriteLine(JsonSerializer.Serialize(functions));
            return 0;
        }
        catch (Exception error)
        {
            while (error is TargetInvocationException { InnerException: { } inner }) error = inner;
            Console.Error.WriteLine("sollang: " + error.Message);
            Console.WriteLine(JsonSerializer.Serialize(new { status = "failed", codegenInvoked = false }));
            return 1;
        }
    }
}

from pathlib import Path
import json
B=Path(__file__).resolve().parent;OUT=B/'typeid21306-declaration-oracles';OUT.mkdir(exist_ok=True)
builtin=[0,1,2,4,5,2,6,6,7,8,9,10,11,12,13,15,14,16,17,18,18,19,19,3,31,43]
def split_top(text,delimiter=','):
 depth=0;parts=[];last=0
 for i,ch in enumerate(text):
  if ch in '<[({':depth+=1
  elif ch in '>])}':depth-=1
  elif ch==delimiter and depth==0:parts.append(text[last:i].strip());last=i+1
 parts.append(text[last:].strip());return parts
for label in ['readonly','struct','fixed-array']:
 observed=B/'typeid21280-definition-observer'/(label+'.stdout');rows=[x.split('\t') for x in observed.read_text(encoding='utf-8').splitlines()];types={int(x[1]):list(map(int,x[2:])) for x in rows if x[0]=='T'};declarations={(int(x[2]),int(x[3])):x[4] for x in rows if x[0]=='N'};table=json.loads((B/'typeid21302-function-trace'/(label+'.stdout')).read_text(encoding='utf-8'))['afterDeclarations'];names=table['names'];shapes={}
 def put(key,value):
  if key in shapes:assert shapes[key]==value,(label,key,shapes[key],value)
  shapes[key]=value
 put(('Slice',2),names['[Int]']);put(('Dynamic',2),names['[Int; ~]'])
 for x in table['refs']:put(('Reference',x['element']),x['id'])
 for x in table['shapes']['_slices']:put(('Slice',x['value']['ElementType']),x['id'])
 for x in table['shapes']['_dynamicArrays']:put(('Dynamic',x['value']['ElementType']),x['id'])
 for x in table['shapes']['_staticArrays']:put(('Fixed',x['value']['ElementType'],x['value']['FixedLength']),x['id'])
 generic_names={'generic parameter':512,'secondary generic parameter':513,'tertiary generic parameter':514}
 def parse_name(name):
  if name in names:return names[name]
  if name in generic_names:return generic_names[name]
  raise KeyError(name)
 for name,value in names.items():
  if name.startswith('Option<') and name.endswith('>'):
   try:put(('Option',parse_name(name[7:-1].strip())),value)
   except KeyError:pass
  elif name.startswith('Result<') and name.endswith('>'):
   try:put(('Result',*(parse_name(x) for x in split_top(name[7:-1]))),value)
   except KeyError:pass
  elif name.startswith('Stream<') and name.endswith('>'):
   try:put(('Stream',parse_name(name[7:-1].strip())),value)
   except KeyError:pass
  elif name.startswith('EventStream<') and name.endswith('>'):
   try:put(('EventStream',parse_name(name[12:-1].strip())),value)
   except KeyError:pass
  elif name.startswith('(') and name.endswith(')'):
   fields=[]
   try:
    for part in split_top(name[1:-1]):
     pair=split_top(part,':');fields.append((pair[0] if len(pair)==2 else '',parse_name(pair[-1])))
    put(('Product',*fields),value)
   except KeyError:pass
 generics=[list(map(int,x.split('\t')[1:])) for x in (B/'typeid21304-function-observer'/(label+'.stdout')).read_text(encoding='utf-8').splitlines() if x.startswith('G\t')];known={};unmatched={};visiting=set()
 def resolve(i):
  if i in known:return known[i]
  if i in unmatched:return None
  assert i not in visiting,(label,i);visiting.add(i)
  kind,origin,module,symbol,first,second,length=types[i];value=None;key=None
  if kind==1:
   if origin==1:value=builtin[symbol]
   elif origin in [0,2] and (module,symbol) in declarations:value=names[declarations[module,symbol]]
   elif origin==3:
    g=next(x for x in generics if x[0]==module and x[1]==symbol);value=512+sum(x[0]==g[0] and x[2]==g[2] and x[3]<g[3] for x in generics)
  elif kind in [2,3,4,8,7]:
   child=resolve(first)
   if kind in [2,3,8]:key=({2:'Slice',3:'Dynamic',8:'Reference'}[kind],child)
   elif kind==4:key=('Fixed',child,length)
   elif origin==4 and symbol in [0,3,4]:key=({0:'Option',3:'Stream',4:'EventStream'}[symbol],child)
   elif origin==4 and symbol==1:key=('Result',child,resolve(second))
   if key is not None and None not in key:value=shapes.get(key)
  elif kind==10:
   fields=[];field=first
   while field>=0:
    f=types[field];assert f[0]==11 and f[6]==-1,'Labeled product needs exact observed label bytes, never a hash';fields.append(('',resolve(f[4])));field=f[5]
   key=('Product',*fields)
   if all(x[1] is not None for x in fields):value=shapes.get(key)
  visiting.remove(i)
  if value is None:unmatched[i]=key
  else:known[i]=value
  return value
 for i in types:
  if types[i][0]!=11:resolve(i)
 result=dict(schemaVersion=1,scope='CSharp after-declaration shape lookup: each returned SLG mapping must match this independently observed identity; a lookup alone does not certify traversal or unsupported source kinds',known={str(i):value for i,value in known.items()},unmatched={str(i):value for i,value in unmatched.items()},expectedNext=table['next'],expectedReadonlyReference=json.loads((B/'typeid21302-function-trace'/(label+'.stdout')).read_text(encoding='utf-8'))['prefixInputType'] if label!='struct' else None,fieldsHaveExactUnlabeledEvidence=True)
 (OUT/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(label,len(known),'shape lookup candidates',table['next'])

import pathlib,json,hashlib,sys
ROOT=pathlib.Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OLD=B/'typeid21280-definition-observer';OUT=B/sys.argv[1];record=json.loads((OLD/'result.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest().upper();base=ROOT/'scripts/probes/codegen-identity';probe=base/'type-registration-declarations-contract.slg';modules=[base/x for x in ['reference-type-ids-prototype.slg','reference-synthetic-type-ids-prototype.slg','reference-prepared-type-ids-prototype.slg']]
inputs=[pathlib.Path(p) for p in record['inputHashes']]
comparison=ROOT/'scripts/contracts/evidence/source13293/block21311-source/source-comparison.json'
change=json.loads(comparison.read_text(encoding='utf-8'))['sourceChanges'][0]
assert change['path']=='selfhost/syntax/ast.slg'
for p in inputs:
 expected=record['inputHashes'][str(p)]
 if p==ROOT/change['path']:
  assert expected==change['beforeSha256'];expected=change['afterSha256']
 assert sha(p)==expected,str(p)
inputs.append(comparison)
proof=B/'block21310-csharp/result.json';baseline=json.loads(proof.read_text(encoding='utf-8'));assert baseline['status']=='passed' and baseline['completed']==baseline['total']==5 and baseline['inputsStable'] and baseline['processesStopped'];inputs.append(proof)
inputs+=[B/'typeid21306-declaration-oracles.py',pathlib.Path(__file__),probe,*modules,OLD/'result.json',*sorted((B/'typeid21306-declaration-oracles').iterdir())];hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21262']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=4,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Current SemanticSnapshot function-declaration TypeId registration against preserved independently checked CSharp metadata, not production ABI diagnostic qualification',claimsGoalComplete=False)
 run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  for i,p in enumerate(record['processes']):
   label='build' if i==0 else ['readonly','struct','fixed-array'][i-1];cmd=[s.replace(str(OLD),str(OUT)).replace(str(base/'type-registration-definition-observer.slg'),str(probe)) for s in p['command']]
   if i==0:cmd[cmd.index('-o'):cmd.index('-o')]=list(map(str,modules))
   done=run.run(cmd,OUT/label,timeout=180);assert done.returncode==0 and not done.stderr,done.stdout[-1500:]+done.stderr
   if i:
    oracle=json.loads((B/'typeid21306-declaration-oracles'/(label+'.json')).read_text(encoding='utf-8'));rows=[line.split('\t') for line in done.stdout.splitlines()];nextId=int(rows[-1][1]);actual={i:int(v) for i,v in rows[:-1]};mismatches=[dict(type=i,actual=v,expected=oracle['known'].get(i)) for i,v in actual.items() if oracle['known'].get(i)!=v];passed=not mismatches and nextId==oracle['expectedNext'];detail=dict(matchesExpected=passed,registeredTypeCount=len(actual),nextTypeId=nextId,expectedNext=oracle['expectedNext'],mismatches=mismatches[:12]);result['cases'].append(dict(id=label,passed=passed,**detail));run.save();assert passed,'OUTPUT_MISMATCH '+label+': '+json.dumps(detail);result['cases'].pop()
   else:detail={}
   result['cases'].append(dict(id=label,passed=True,**detail));result['completed']+=1;run.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','cases','inputsStable','processesStopped']},indent=2))

from pathlib import Path
import json,shutil,subprocess,sys
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(r/'scripts'))
from completed_artifact_plan import prepare_output
roots=[b/'v18915/compiler-build01',b/'v19080/compiler-build01',b/'v19418/compiler-build01']
for name in ('diagnostic19786-fact-observation','diagnostic19770-managed-positive'):
 output=(b/name).resolve();assert output.is_relative_to(b.resolve())
 result=json.loads((output/'result.json').read_text(encoding='utf-8-sig'))
 assert result['status']=='passed' and result['inputsStable'] and result['processesStopped']
 plan=prepare_output(r,output,reusable_directories=roots)
 command=[shutil.which('pwsh'),'-NoProfile','-File',str(r/'scripts/Invoke-CompletedArtifactCleanup.ps1'),'-Plan',str(plan)]
 for stage,extra in [('plan',[]),('execute',['-Execute'])]:
  observed=subprocess.run(command+extra,capture_output=True)
  (b/('diagnostic19791-'+name+'-'+stage+'.stdout')).write_bytes(observed.stdout)
  (b/('diagnostic19791-'+name+'-'+stage+'.stderr')).write_bytes(observed.stderr)
  assert observed.returncode==0,(name,stage,observed.stderr.decode('utf-8-sig',errors='replace'))
 print(name+': existing lifecycle plan validated and executed')

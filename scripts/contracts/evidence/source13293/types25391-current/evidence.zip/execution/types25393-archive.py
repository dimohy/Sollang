from pathlib import Path
import json,hashlib,subprocess,zipfile,sys
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/types25391-current'
sha=lambda x:hashlib.sha256(x).hexdigest().upper()
files={}
skip={'.exe','.dll','.ll','.bc','.pdb','.obj','.lib','.a','.cache','.pyc','.zip'}
for p in B.glob('types253*'):
 for f in ([p] if p.is_file() else p.rglob('*')):
  if not f.is_file() or f.suffix.lower() in skip or '.sollang-cache' in f.parts or f.name.endswith('-before.json'):continue
  files['execution/'+f.relative_to(B).as_posix()]=f.read_bytes()
owned=['selfhost/semantic/type_registration.slg','scripts/probes/codegen-unit-stream/registry_universe.slg','docs/AI_SLG_BEST_PRACTICES.md','docs/SPEC.md']
for name in owned:
 files['qualified-source/'+name]=(R/name).read_bytes()
 files['before-source/'+name]=subprocess.run(['git','show','HEAD:'+name],check=True,capture_output=True).stdout
for f in sorted((R/'scripts/contracts/evidence/C2026-11-03-798').rglob('*')):
 if f.is_file():files['defect-evidence/'+f.name]=f.read_bytes()
with zipfile.ZipFile(E/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(files.items()):z.writestr(n,b)
entries=[dict(path=n,bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())]
with zipfile.ZipFile(E/'evidence.zip') as z:
 assert z.testzip() is None
 for row in entries:assert sha(z.read(row['path']))==row['sha256']
manifest=dict(schemaVersion=1,archiveSha256=sha((E/'evidence.zip').read_bytes()),entries=entries,entriesVerified=len(entries),excludes='Generated binaries, LLVM intermediates, private caches and foreign metadata snapshots',claimsGoalComplete=False)
(E/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(entries=len(entries),uncompressedBytes=sum(x['bytes'] for x in entries),archiveBytes=(E/'evidence.zip').stat().st_size)))

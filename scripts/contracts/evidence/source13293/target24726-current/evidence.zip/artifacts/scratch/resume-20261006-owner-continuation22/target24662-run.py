from pathlib import Path
import sys,json,hashlib,time
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve()
fixture=R/'examples/regression/23-webassembly-browser.slg';expected=R/'examples/regression/expected/23-webassembly-browser.stdout.txt';runner=R/'scripts/verify-browser-program.mjs'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
llvm=R/'.tools/llvm-22.1.8';assert all((llvm/'bin'/n).is_file() for n in ['clang.exe','wasm-ld.exe'])
paths=[Path(__file__),C,*(managed_runtime_inputs(C) if C.name!='compiler.exe' else []),fixture,expected,runner,*sorted((R/'src/Sollang.Compiler').rglob('*.cs')),*sorted((R/'selfhost').rglob('*.slg')),*sorted((R/'stdlib').rglob('*.slg'))]
pins={str(p.resolve()):sha(p) for p in paths};initialize_output(R,O,reusable_directories=[B/'map24655-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=2,cases=[],inputHashes=pins,maximumCaseSeconds=180,scope='Actual CSharp/Native CLI target build23 plus WebAssembly instantiation or Linux WSL executable run; frozen original stdout oracle',claimsGoalComplete=False)
 ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for target in ['wasm32-browser','linux-x64']:
   started=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-started));exe=O/('program.wasm' if target=='wasm32-browser' else 'program-linux')
   command=[str(C),'build' if target=='wasm32-browser' else 'run',str(fixture),'-o',str(exe),'--target',target,'--keep-temps','-O1','--jobs','4','--llvm',str(llvm)]
   if C.name=='compiler.exe':command+=['--stdlib',str(R/'stdlib')]
   done=ex.run(command,O/(target+'-build'),timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout+done.stderr
   if target=='wasm32-browser':
    done=ex.run(['node',str(runner),str(exe),str(expected)],O/(target+'-run'),timeout=budget());assert done.returncode==0 and not done.stderr and done.stdout.startswith('PASS browser program:'),done.stdout+done.stderr
   else:
    assert done.stdout.replace('\r\n','\n').rstrip('\n')==expected.read_text(encoding='utf-8').replace('\r\n','\n').rstrip('\n'),done.stdout+done.stderr
   result['cases'].append(dict(id=target,passed=True,execution='actual-WebAssembly-instantiation-Node' if target=='wasm32-browser' else 'actual-Linux-executable-WSL',artifactSha256=sha(exe),elapsedSeconds=time.monotonic()-started));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

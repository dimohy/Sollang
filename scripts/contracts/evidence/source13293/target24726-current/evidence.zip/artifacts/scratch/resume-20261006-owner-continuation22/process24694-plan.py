from pathlib import Path
import json
R=Path.cwd(); B=R/'artifacts/scratch/resume-20261006-owner-continuation22'
p=B/'process24686-source-comparison/decision.json'
d=json.loads(p.read_text())
d.update(sourceEmitterBudget=dict(maximumBuilds=1,timeoutSeconds=180,output=str((B/'process24695-native').relative_to(R))),requiredNativePreflights=[str((B/'process24693-stdlib/result.json').relative_to(R))],reasonForDistinctBuild='Previous target24672 build passed; reproduced executable-search defect in both compiled runtimes, CSharp repair verified6/6 before SLG port. New runtime sources require a distinct producer, not an unchanged replay or budget reset.',slgAttributeNote='SLG runtime omits CSharp emitter-specific #0 attribute as existing neighboring helpers do; instruction bodies and application decisions match.')
p.write_text(json.dumps(d,indent=2)+'\n')
p=R/'scripts/contracts/active-goal-progress.json'; d=json.loads(p.read_text(encoding='utf-8-sig'))
u=d['currentTargetLinkingUnit'];u.update(completed=5,status='native-wasm-and-windows-passed-linux-search-name-root-repair',nativeWindowsControl=str((B/'target24681-windows-control/result.json').relative_to(R)),processSearchComparison=str((B/'process24686-source-comparison/decision.json').relative_to(R)))
for row in d.get('focusedGates',[]):
 if row.get('name')=='target24668-linking-pair6':row.update(completed=5,percentage=83.33)
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Distinct runtime repair build frozen; focused target evidence updated5/6.')

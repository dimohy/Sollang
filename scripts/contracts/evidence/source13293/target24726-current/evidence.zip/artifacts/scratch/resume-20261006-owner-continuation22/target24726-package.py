from pathlib import Path
import json,hashlib,zipfile,datetime,shutil
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/target24726-current';E.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda data:hashlib.sha256(data).hexdigest().upper();rel=lambda p:str(p.relative_to(R)).replace('\\','/')
def write(name,obj):(E/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
passed=['process24687-managed','process24688-csharp-after','process24692-semantic','process24693-stdlib','process24695-native','process24699-csharp-argv','process24700-native-after','process24701-native-argv','process24705-managed','process24707-csharp-argv','process24708-csharp-search','process24713-semantic','process24714-stdlib','process24716-native','process24720-native-search','process24721-native-argv','target24717-csharp','target24724-csharp-windows','target24719-native-pair']
failed=['process24679-csharp-before','process24680-native-before','process24682-csharp-before','process24683-native-before','process24684-csharp-before','process24685-native-before','process24690-semantic','process24691-stdlib','process24703-wsl-csharp-before','process24706-wsl-csharp-after','process24710-wsl-csharp-collect','process24711-wsl-csharp-collect','target24662-csharp','target24663-csharp','target24669-semantic','target24670-semantic','target24671-linker-semantic','target24673-linker-semantic','target24678-native-pair','target24697-native-pair']
records={n:read(B/n/'result.json') for n in passed+failed}
for n in passed:
 j=records[n];assert j['status']=='passed' and j['completed']==j['total'] and j['inputsStable'] and j['processesStopped'],n
for n in ['process24720-native-search','process24721-native-argv','target24717-csharp','target24724-csharp-windows','target24719-native-pair','process24716-native']:
 assert all(sha(Path(p).read_bytes())==h for p,h in records[n]['inputHashes'].items()),n
protected=read(B/'block24016-protected-inputs.json');assert all(sha((R/p).read_bytes())==h for p,h in protected.items())
entries={}
def add(p,key=None):
 if not p.is_file():return
 key=key or rel(p);data=p.read_bytes();assert key not in entries or entries[key]==data,key;entries[key]=data
for n,j in records.items():
 shutil.copyfile(B/n/'result.json',E/(n+'.json'))
 for p in (B/n).rglob('*'):
  if p.is_file() and p.suffix.lower() in {'.json','.txt','.log','.stdout','.stderr','.py','.slg'} and not {'.sollang-cache','obj','bin','dotnet-artifacts'}.intersection(p.parts):add(p)
for name in ['target24668-source-comparison','process24686-source-comparison','process24704-source-comparison','target24723-linux-run']:
 for p in (B/name).rglob('*'):
  if p.is_file():add(p)
for pattern in ['process246*.py','process247*.py','target246*.py','target247*.py']:
 for p in B.glob(pattern):add(p)
for folder in ['scripts/probes/process-search-name','scripts/probes/target-linking']:
 for p in (R/folder).rglob('*'):add(p)
for j in records.values():
 for name,h in j.get('inputHashes',{}).items():
  p=Path(name)
  if p.is_file() and p.is_relative_to(R) and 'artifacts' not in p.relative_to(R).parts and p.suffix.lower() in {'.slg','.cs','.py','.ps1','.json','.csproj','.props','.targets','.grammar','.lexer','.txt'} and sha(p.read_bytes())==h:add(p)
add(Path(__file__))
prev=R/'scripts/contracts/evidence/source13293/llvm24661-current-review/source-review.json';old=read(prev);sources={};changed=[]
notes={
 'src/Sollang.Compiler/CodeGen/WindowsLlvmRuntimePlatform.cs':'CSharp-first executable-search and minimal Windows argv encoding repairs, raw path ownership preserved. Focused18 controls and current Linux CLI products verified before corresponding SLG source changes.',
 'selfhost/llvm/source_root.slg':'Common source mapping and cached product dispatch now accepts target2; original mapping ownership and diagnostics retained.',
 'selfhost/llvm/text/context_prepare.slg':'WebAssembly runtime prefix, function module stream and owned-file suffix follow existing cache boundary ownership, matching Windows/Linux ordering.',
 'selfhost/llvm/text/entrypoints.slg':'Target descriptor product replaces Windows boolean; checked frontend, registry, codegen request and source/cache publication are shared. Existing target rejection decisions collected and emitted once; wasm async runtime diagnostics remain before emission.',
 'selfhost/llvm/text/library_exports.slg':'Product stores TargetDescriptor; shared-library plan fields and export decisions unchanged.',
 'tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.slg':'Target-specific linker selection after common preparation; wasm cache CLI dispatch; object stage ownership; host-only run guard. Existing Windows direct-clang partitioning remains a separately tracked gap.',
 'selfhost/llvm/emitter/process_runtime.slg':'Exact UTF16 explicit application-path scan and minimal quoting admission copied after CSharp proof; owned plain-copy branch retains allocation/free and raw argv0 lifetime, existing complex argument encoder unchanged.'}
for name,row in old['sources'].items():
 digest=sha((R/name).read_bytes())
 if digest==row['currentSha256']:sources[name]=dict(currentSha256=digest,reviewMethod='exact-byte-reuse',previousReview=rel(prev),physicalReviewState='current-complete')
 else:
  assert name in notes,name
  pre=B/'process24686-source-comparison/csharp-before.cs' if name.endswith('/WindowsLlvmRuntimePlatform.cs') else (B/'process24686-source-comparison/slg-before.slg' if name.endswith('/process_runtime.slg') else B/'target24668-source-comparison/before'/name)
  assert sha(pre.read_bytes())==row['currentSha256'],name
  sources[name]=dict(currentSha256=digest,previousSha256=row['currentSha256'],reviewMethod='direct-complete-authored-delta-read',previousReview=rel(prev),inspection=notes[name],physicalReviewState='current-complete',claimsWholePhaseComplete=False);changed.append(name)
assert len(sources)==156 and len(changed)==7,(len(sources),changed)
write('source-review-reconciliation.json',dict(schemaVersion=1,status='current-physical-review-focused-deltas-qualified-phase-pending',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),completed=156,total=156,sources=sources,authoredDeltas=changed,additionalReviewedSource=dict(path='selfhost/toolchain.slg',inspection='Complete added linker helpers and WSL absolute-path conversion read against CSharp WasmBrowserLinker and WslLinuxLinker. Stage order, export flags, object compilation, shared flag and chmod decisions ported.',sha256=sha((R/'selfhost/toolchain.slg').read_bytes())),claimsWholePhaseComplete=False,claimsGoalComplete=False))
archive=E/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(entries)
 for name in z.namelist():assert sha(z.read(name))==sha(entries[name]),name
write('archive-manifest.json',dict(archiveSha256=sha(archive.read_bytes()),entries={name:dict(sha256=sha(data),bytes=len(data)) for name,data in sorted(entries.items())},readbackVerified=True))
write('protected-inputs.json',dict(completed=8,total=8,hashes=protected))
write('qualification.json',dict(schemaVersion=1,status='focused-qualified-final-pending',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),managedFirst=True,pairedTargets=dict(completed=6,total=6,managedRecords=['target24717-csharp.json','target24724-csharp-windows.json'],nativeRecord='target24719-native-pair.json',nativeWasmWarmReuse=records['target24719-native-pair']['wasmWarmCodegenReuse'],linuxOwnedRuntimeReceipt=rel(B/'target24723-linux-run/result.json')),processSearchAndLiteralArguments=dict(completed=36,total=36,managedRecords=['process24707-csharp-argv.json','process24708-csharp-search.json'],nativeRecords=['process24720-native-search.json','process24721-native-argv.json']),sourceComparisons=[rel(B/'target24668-source-comparison/source-comparison.json'),rel(B/'process24686-source-comparison/decision.json'),rel(B/'process24704-source-comparison/decision.json')],nativeProducer='process24716-native.json',prerequisites=dict(semantic='passed4/4',stdlib='passed1/1'),archive=dict(path='evidence.zip',sha256=sha(archive.read_bytes()),entries=len(entries),readbackVerified=True),protectedInputsUnchanged=dict(completed=8,total=8),claimsGoalComplete=False,claimsWholePhaseComplete=False,claimsWindowsLinkerPartitionParity=False,claimsStandaloneWslShutdownFixed=False,nonAdditive='Target6 and process36 are separate scoped contracts; seed/build/preflight and repeated cold/warm observations do not increase either denominator.',remaining=['Original1999 Native whole180/O1/jobs4 timeout unchanged; no replay or profiling budget reset.','Windows linker partitioning and workspace resolve remain separate source decisions; full source7/runtime2708/Stage2/Stage3/stdlib-runtime22/platform acceptance pending.','Short standalone WSL calls returned0 after minimal quoting but retained live helper processes under strict Windows job supervision; those records remain failed. Actual complete CSharp and Native Linux compiler builds drained owned Windows jobs; actual ELF executions drained owned Linux groups.','Progress evaluator remains unverified; preexisting39 defect-ledger shapingEvidence gaps are unchanged.','Superseded provisional probes did not all retain original helper source bytes; raw failed logs and result hashes retained.','Extensionless historical target24666 ELF is outside current GENERATED extension matcher and is preserved pending common lifecycle ownership repair. Current Linux outputs use explicit .exe-owned ELF paths.']))
print(json.dumps(dict(evidence=rel(E),pairedTargets=6,processCases=36,archiveEntries=len(entries),archiveBytes=archive.stat().st_size,physicalReview=156,authoredDeltas=len(changed))))

from pathlib import Path
import json,datetime
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'process24704-source-comparison'
proofs=[B/'process24707-csharp-argv/result.json',B/'process24708-csharp-search/result.json']
for p in proofs:
 j=json.loads(p.read_text());assert j['status']=='passed' and j['completed']==j['total'] and j['inputsStable'] and j['processesStopped']
p=O/'decision.json';j=json.loads(p.read_text());j.update(status='compared-before-slg-edit',csharpFirst=[str(p.relative_to(R)) for p in proofs],csharpCompleted=18,csharpTotal=18,slgDecision='Port identical Unicode quote-admission scan and owned plain-copy branch; retain existing quoted encoding and program-path ownership. CSharp helper has emitter-specific #0 attribute; SLG omits it consistently.',wslObservation='Minimal quoting changes actual WSL true result127 to0, but Windows owned-job descendant check still fails; both raw WSL records remain failed. No WSL support or shutdown qualification claimed.',wslFailedObservation=str((B/'process24706-wsl-csharp-after/result.json').relative_to(R)),observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat());p.write_text(json.dumps(j,indent=2)+'\n')
S=R/'selfhost/llvm/emitter/process_runtime.slg';s=S.read_text();helper=(O/'helper.ll').read_text().replace(' #0 {',' {');anchor='    define internal ptr @sollang_process_quote_windows_arg('
assert s.count(anchor)==1
s=s.replace(anchor,''.join('    '+line+'\n' if line else '\n' for line in helper.splitlines())+anchor,1)
old='''    initialize:
      store i16 34, ptr %output, align 2'''
new='''    initialize:
      %needs_quotes = call i1 @sollang_process_windows_arg_needs_quotes(ptr %source, i32 %chars)
      br i1 %needs_quotes, label %quote_initialize, label %plain_copy
    plain_copy:
      %plain_bytes = mul i64 %chars64, 2
      call void @llvm.memcpy.p0.p0.i64(ptr %output, ptr %source, i64 %plain_bytes, i1 false)
      %plain_null = getelementptr i16, ptr %output, i64 %chars64
      store i16 0, ptr %plain_null, align 2
      ret ptr %output
    quote_initialize:
      store i16 34, ptr %output, align 2'''
assert s.count(old)==1
S.write_text(s.replace(old,new,1),encoding='utf-8')
print('CSharp18/18 proof verified; identical quote decisions ported. WSL shutdown remains unresolved.')

from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'target24667-native-before';C=B/'map24655-native/compiler.exe';fixture=R/'examples/regression/23-webassembly-browser.slg'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
files=[Path(__file__),C,fixture,R/'tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.slg'];pins={str(p.resolve()):sha(p) for p in files};initialize_output(R,O,reusable_directories=[C.parent,B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=2,cases=[],inputHashes=pins,claimsGoalComplete=False,scope='Reproduce actual Native build target rejection; oracle remains build success, rejection is failure not supported credit');ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for target in ['wasm32-browser','linux-x64']:
   r=ex.run([str(C),'build',str(fixture),'-o',str(O/target),'--target',target,'--stdlib',str(R/'stdlib'),'--llvm',str(R/'.tools/llvm-22.1.8'),'-O1','--jobs','4'],O/target,timeout=180)
   result['cases'].append(dict(id=target,passed=r.returncode==0,expectedExit=0,actualExit=r.returncode,stdout=r.stdout,stderr=r.stderr));ex.save()
  raise AssertionError('NATIVE_CLI_TARGET_LINKING_REJECTED')
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error

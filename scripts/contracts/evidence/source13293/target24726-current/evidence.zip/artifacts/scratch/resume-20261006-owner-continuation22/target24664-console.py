from pathlib import Path
import sys,subprocess,time,json,ctypes
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import _WindowsJob,VerificationExecution
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';exe=B/'target24662-csharp/program-linux'
wsl='/mnt/'+str(exe)[0].lower()+str(exe)[2:].replace('\\','/')
rows=[]
for mode,flags in [('existing-suspended',4),('no-window-suspended',4|subprocess.CREATE_NO_WINDOW)]:
 job=_WindowsJob();row=dict(mode=mode,flags=flags);p=subprocess.Popen([r'C:\Windows\System32\wsl.exe','-d','Ubuntu','--exec',wsl],stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=flags)
 try:
  job.start(p);stdout,stderr=p.communicate(timeout=30);row.update(pid=p.pid,exit=p.returncode,stdout=stdout.decode(),stderr=stderr.decode())
  row['naturalShutdown']=VerificationExecution.confirm_natural_shutdown(None,p,row,job)
  row['remainingWindowsProcesses']=[]
  for pid in job.shutdown_observation()[1]:
   k=ctypes.WinDLL('kernel32',use_last_error=True);k.OpenProcess.restype=ctypes.c_void_p;k.QueryFullProcessImageNameW.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_ulong)];k.CloseHandle.argtypes=[ctypes.c_void_p];h=k.OpenProcess(0x1000,False,pid);buf=ctypes.create_unicode_buffer(32768);n=ctypes.c_ulong(len(buf));ok=k.QueryFullProcessImageNameW(h,0,buf,ctypes.byref(n)) if h else False
   row['remainingWindowsProcesses'].append(dict(pid=pid,path=buf.value if ok else 'unavailable'))
   if h:k.CloseHandle(h)
  if not row['naturalShutdown']:job.terminate()
  row['processesStopped']=job.stopped()
 finally:job.close()
 rows.append(row)
p=B/'target24664-console-observation.json';p.write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(json.dumps(rows))

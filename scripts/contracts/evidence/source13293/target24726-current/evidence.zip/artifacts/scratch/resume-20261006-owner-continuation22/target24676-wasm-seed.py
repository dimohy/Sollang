from pathlib import Path
import sys,json,hashlib,time
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'target24676-wasm-seed';C=B/'generic24558-managed/compiler/Sollang.Compiler.exe'
inputs=[R/'scripts/probes/target-linking/driver.slg',R/'selfhost/toolchain.slg'];llvm=B/'target24662-csharp/program.wasm.ll';runner=R/'scripts/verify-browser-program.mjs';expected=R/'examples/regression/expected/23-webassembly-browser.stdout.txt';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
paths=[Path(__file__),*inputs,C,*managed_runtime_inputs(C),llvm,runner,expected,*sorted((R/'stdlib').rglob('*.slg'))];pins={str(p.resolve()):sha(p) for p in paths};initialize_output(R,O,reusable_directories=[B/'map24655-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,cases=[],inputHashes=pins,scope='Managed seed compiles actual new SLG target-linking helper and links/runs frozen original23 WebAssembly; supporting only, not Native CLI proof',claimsGoalComplete=False)
 ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None;start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start))
 try:
  exe=O/'linker.exe'
  r=ex.run([str(C),'build',*[str(p) for p in inputs],'-o',str(exe),'--target','windows-x64','--keep-temps','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')],O/'build',timeout=budget());assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  r=ex.run([str(exe),'wasm',str(R/'.tools/llvm-22.1.8'),str(llvm),str(O/'program.o'),str(O/'program.wasm')],O/'link',timeout=budget());assert r.returncode==0 and not r.stdout and not r.stderr,r.stdout+r.stderr
  r=ex.run(['node',str(runner),str(O/'program.wasm'),str(expected)],O/'run',timeout=budget());assert r.returncode==0 and not r.stderr and r.stdout.startswith('PASS browser program:'),r.stdout+r.stderr
  result.update(status='passed',completed=1,cases=[dict(id='original23-wasm-target-linker',passed=True,stdout=r.stdout,wasmSha256=sha(O/'program.wasm'))])
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

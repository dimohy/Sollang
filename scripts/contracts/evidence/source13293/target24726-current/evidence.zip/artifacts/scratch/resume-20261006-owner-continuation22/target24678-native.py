from pathlib import Path
import sys,json,hashlib,time,re
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'target24678-native-pair';C=B/'target24672-native/compiler.exe'
fixture=R/'examples/regression/23-webassembly-browser.slg';control=R/'examples/regression/1432-dyn-trait-reachable-implementations.slg';runner=R/'scripts/verify-browser-program.mjs';expected=R/'examples/regression/expected/23-webassembly-browser.stdout.txt';producer=B/'target24672-native/result.json';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
j=json.loads(producer.read_text(encoding='utf-8'));assert j['status']=='passed' and j['completed']==j['total']==1 and j['inputsStable'] and j['processesStopped'] and sha(C)==j['compilerSha256'];assert all(sha(p)==h for p,h in j['inputHashes'].items())
paths=[Path(__file__),producer,C,fixture,control,runner,expected,B/'target24668-source-comparison/frozen-contract.json',*sorted((R/'selfhost').rglob('*.slg')),*sorted((R/'stdlib').rglob('*.slg'))];pins={str(p.resolve()):sha(p) for p in paths};initialize_output(R,O,reusable_directories=[C.parent,B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=3,cases=[],inputHashes=pins,maximumCaseSeconds=180,scope='Current Native CLI wasm cold/warm actual execution, Linux build pending Linux-owned runtime receipt, retained Windows original1432 actual runtime; supporting runs are not additive',claimsGoalComplete=False)
 ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 def command(source,output,target):return [str(C),'build',str(source),'-o',str(output),'--target',target,'--keep-temps','--stdlib',str(R/'stdlib'),'-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')]
 try:
  start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));wasm=O/'program.wasm'
  for epoch in ['cold','warm']:
   r=ex.run(command(fixture,wasm,'wasm32-browser'),O/('wasm-'+epoch+'-build'),timeout=budget());assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
   if epoch=='warm':
    reused=re.search(r'\[codegen-cache\] reused (\d+)/(\d+) units;',r.stdout);assert reused and int(reused[2])>0 and int(reused[1])==int(reused[2]),r.stdout
    result['wasmWarmCodegenReuse']=dict(reused=int(reused[1]),total=int(reused[2]))
   r=ex.run(['node',str(runner),str(wasm),str(expected)],O/('wasm-'+epoch+'-run'),timeout=budget());assert r.returncode==0 and not r.stderr and r.stdout.startswith('PASS browser program:'),r.stdout+r.stderr
  result['cases'].append(dict(id='wasm32-browser23',passed=True,epochs=['cold','warm'],artifactSha256=sha(wasm)));result['completed']+=1;ex.save()
  start=time.monotonic();linux=O/'program-linux.exe'
  r=ex.run(command(fixture,linux,'linux-x64'),O/'linux-build',timeout=budget());assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  assert linux.read_bytes()[:4]==b'\x7fELF';result['linuxBuild']=dict(status='passed-runtime-pending',artifact=str(linux),sha256=sha(linux));ex.save()
  start=time.monotonic();windows=O/'control.exe'
  r=ex.run(command(control,windows,'windows-x64'),O/'windows-build',timeout=budget());assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  r=ex.run([str(windows)],O/'windows-run',timeout=budget());assert r.returncode==0 and not r.stderr and r.stdout.strip()=='7',r.stdout+r.stderr
  result['cases'].append(dict(id='windows-original1432',passed=True,stdout='7'));result['completed']+=1;result['status']='awaiting-linux-runtime'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result.get(k) for k in ['status','completed','total','wasmWarmCodegenReuse','linuxBuild','inputsStable','processesStopped']}))

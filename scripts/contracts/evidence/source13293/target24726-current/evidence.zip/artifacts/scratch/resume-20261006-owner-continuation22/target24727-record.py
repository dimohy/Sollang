from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess,copy
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/target24726-current';read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda d:hashlib.sha256(d).hexdigest().upper();rel=lambda p:str(p.relative_to(R)).replace('\\','/')
def write(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
manifest=read(E/'archive-manifest.json');archive=E/'evidence.zip'
with zipfile.ZipFile(archive) as z:
 entries={name:z.read(name) for name in z.namelist()}
 assert set(entries)==set(manifest['entries'])
 for name,data in entries.items():assert sha(data)==manifest['entries'][name]['sha256']
for directory in ['target24665-linux-run','target24666-csharp','target24667-native-before','target24672-native','target24674-linker-semantic','target24675-semantic','target24676-wasm-seed','target24677-stdlib']:
 for p in (B/directory).rglob('*'):
  if p.is_file() and p.suffix.lower() in {'.json','.txt','.log','.stdout','.stderr','.py','.slg'} and not {'.sollang-cache','obj','bin','dotnet-artifacts'}.intersection(p.parts):entries[rel(p)]=p.read_bytes()
for p in [B/'target24664-console-observation.json',Path(__file__)]:entries[rel(p)]=p.read_bytes()
closures=[]
for name in ['map24655-native','target24672-native','process24695-native','process24720-native-search','process24721-native-argv','target24717-csharp','target24724-csharp-windows','target24719-native-pair','process24716-native']:
 folder=B/name;j=read(folder/'artifact-cleanup-plan.json.execution.json');assert j['status']=='completed'
 dest=E/'lifecycle'/name;dest.mkdir(parents=True,exist_ok=True)
 for p in folder.glob('artifact-cleanup-plan.json*'):shutil.copyfile(p,dest/p.name)
 closures.append(dict(output=rel(folder),reclaimedBytes=j['reclaimedBytes'],execution=rel(dest/'artifact-cleanup-plan.json.execution.json')))
current=[B/'process24716-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01'];assert all((p/'compiler.exe').is_file() for p in current)
assert all(not (B/p/'compiler.exe').exists() for p in ['map24655-native','target24672-native','process24695-native'])
write(E/'artifact-lifecycle.json',dict(status='completed-for-listed-outputs',outputs=closures,reclaimedBytes=sum(x['reclaimedBytes'] for x in closures),reusableCompilerDirectories=[rel(p) for p in current],reusableCompilerCount=3,failedOutputsPreserved=True,limitation='Historical extensionless target24666 ELF remains preserved pending canonical output-ownership repair; not counted as cleaned. Managed producer24705 retained for pending focused consumers.'))
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(entries)
 for name in z.namelist():assert sha(z.read(name))==sha(entries[name])
write(E/'archive-manifest.json',dict(archiveSha256=sha(archive.read_bytes()),entries={name:dict(sha256=sha(data),bytes=len(data)) for name,data in sorted(entries.items())},readbackVerified=True))
q=read(E/'qualification.json');q['archive'].update(sha256=sha(archive.read_bytes()),entries=len(entries));q['artifactLifecycle']=rel(E/'artifact-lifecycle.json')
comparisons=[]
for source,name in [(B/'target24668-source-comparison/source-comparison.json','target-source-comparison.json'),(B/'process24686-source-comparison/decision.json','process-search-source-comparison.json'),(B/'process24704-source-comparison/decision.json','process-argv-source-comparison.json')]:shutil.copyfile(source,E/name);comparisons.append(rel(E/name))
q['sourceComparisons']=comparisons;write(E/'qualification.json',q)
qualified=rel(E/'qualification.json');gate=dict(name='target24668-linking-pair6',status='passed',completed=6,total=6,percentage=100.00,scope='Actual CSharp3/Native3 wasm23, Linux23 and retained Windows1432. Process36 and build/preflight/cold-warm supporting contracts are not added to target6.',evidence=qualified)
target=dict(status='focused-qualified-final-pending',completed=6,total=6,percentage=100.00,qualification=qualified,csharpRecords=[rel(E/'target24717-csharp.json'),rel(E/'target24724-csharp-windows.json')],nativeRecord=rel(E/'target24719-native-pair.json'),sourceComparison=comparisons[0],claimsGoalComplete=False,claimsWholePhaseComplete=False,claimsWindowsPartitionParity=False)
process=dict(status='focused-qualified-final-pending',completed=36,total=36,percentage=100.00,qualification=qualified,evidenceSelector='processSearchAndLiteralArguments',sourceComparisons=comparisons[1:],claimsWholeProcessRuntimeComplete=False,claimsStandaloneWslShutdownFixed=False,claimsGoalComplete=False)
def updateProgress(j):
 j.update(currentFocusedGate=gate['name'],currentTargetLinkingUnit=copy.deepcopy(target),currentProcessSearchAndArgvUnit=copy.deepcopy(process))
 j['focusedGates']=[x for x in j['focusedGates'] if x['name']!=gate['name']]+[copy.deepcopy(gate)]
def updateDetail(j):
 for phase in j['phaseProgress']:
  if phase['phase']!='llvm-generation':continue
  inventory=phase['decisionInventory'];inventory['previousCompleteFileReviewBeforeTarget24726']=inventory['currentCompleteFileReview'];inventory['currentCompleteFileReview']=rel(E/'source-review-reconciliation.json');inventory['currentAuthoredDeltaReview']=rel(E/'source-review-reconciliation.json')
  for d in inventory['decisions']:
   if d['id']=='llvm-generation.process-quoted-argv-and-child-lifetime':d['processSearchAndArgvFocusedUnit']=copy.deepcopy(process)
   if d['id']=='llvm-generation.target-descriptor-and-capability-configuration':d['targetLinkingFocusedUnit']=copy.deepcopy(target)
for name,update in [('scripts/contracts/active-goal-progress.json',updateProgress),('scripts/contracts/structural-parity-detail.json',updateDetail)]:
 path=R/name;work=read(path);base=json.loads(subprocess.check_output(['git','show','HEAD:'+name]).decode('utf-8'));update(work);update(base);write(path,work)
 data=(json.dumps(base,ensure_ascii=False,indent=2)+'\n').encode('utf-8');oid=subprocess.check_output(['git','hash-object','-w','--stdin'],input=data).decode().strip();subprocess.run(['git','update-index','--cacheinfo','100644',oid,name],check=True)
protected=read(B/'block24016-protected-inputs.json');assert all(sha((R/p).read_bytes())==h for p,h in protected.items())
print(json.dumps(dict(targets='6/6',processCases='36/36',archiveEntries=len(entries),reclaimedBytes=sum(x['reclaimedBytes'] for x in closures),selectiveMetadataStaged=True,protectedInputs='8/8')))

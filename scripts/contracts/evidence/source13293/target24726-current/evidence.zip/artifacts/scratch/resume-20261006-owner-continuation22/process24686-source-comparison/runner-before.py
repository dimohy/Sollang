from pathlib import Path
import sys,json,hashlib,time,shutil
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve();fixture=R/'scripts/probes/process-search-name/driver.slg'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();pins={str(p.resolve()):sha(p) for p in [Path(__file__),C,*(managed_runtime_inputs(C) if C.name!='compiler.exe' else []),fixture,*sorted((R/'src/Sollang.Compiler').rglob('*.cs')),*sorted((R/'selfhost').rglob('*.slg')),*sorted((R/'stdlib').rglob('*.slg'))]}
initialize_output(R,O,reusable_directories=[B/'target24672-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=6,cases=[],inputHashes=pins,scope='Actual sys.process.Command executable search name vs explicit path vs missing name; SPEC program path or search name contract',claimsGoalComplete=False)
 ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None;start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start))
 try:
  exe=O/'probe.exe';args=[str(C),'build',str(fixture),'-o',str(exe),'--target','windows-x64','--keep-temps','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')]
  if C.name=='compiler.exe':args+=['--stdlib',str(R/'stdlib')]
  r=ex.run(args,O/'build',timeout=budget());assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  shutil.copyfile(r'C:\Windows\System32\hostname.exe',O/'program space.exe')
  for name,program,expected in [('search-name','hostname.exe','exit=0'),('explicit-path',r'C:\Windows\System32\hostname.exe','exit=0'),('missing-search-name','sollang-absent-process24679.exe','error=spawn'),('explicit-space',str(O/'program space.exe'),'exit=0'),('search-space','program space.exe','exit=0'),('relative-space',str((O/'program space.exe').relative_to(R)),'exit=0')]:
   r=ex.run([str(exe),program],O/name,timeout=budget());ok=r.returncode==0 and not r.stderr and r.stdout.strip()==expected
   result['cases'].append(dict(id=name,passed=ok,expected=expected,actual=r.stdout.strip(),stderr=r.stderr));result['completed']+=int(ok);ex.save()
  assert result['completed']==result['total'],'PROCESS_SEARCH_NAME_CONTRACT_MISMATCH'
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

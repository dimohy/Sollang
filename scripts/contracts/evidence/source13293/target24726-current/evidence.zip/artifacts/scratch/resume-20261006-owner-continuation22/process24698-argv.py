from pathlib import Path
import sys,json,hashlib,time,shutil
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve();fixture=R/'scripts/probes/process-search-name/literal-argv.slg'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
pins={str(p.resolve()):sha(p) for p in [Path(__file__),C,*(managed_runtime_inputs(C) if C.name!='compiler.exe' else []),fixture,*sorted((R/'selfhost').rglob('*.slg')),*sorted((R/'stdlib').rglob('*.slg'))]}
initialize_output(R,O,reusable_directories=[B/'process24716-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=12,cases=[],inputHashes=pins,scope='C671 literal argv preservation: explicit spaced path and spaced search name, six payloads each',claimsGoalComplete=False)
 ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None;start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start))
 try:
  exe=O/'probe.exe';args=[str(C),'build',str(fixture),'-o',str(exe),'--target','windows-x64','--keep-temps','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')]
  if C.name=='compiler.exe':args+=['--stdlib',str(R/'stdlib')]
  r=ex.run(args,O/'build',timeout=budget());assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  child=O/'program space.exe';shutil.copyfile(exe,child);result['childSha256']=sha(child)
  for mode,program in [('explicit',str(child)),('search',child.name)]:
   for name,payload in [('plain','payload'),('space','two words'),('empty',''),('quote','a"b'),('trailing-slash','a\\'),('slash-quote','a\\"b')]:
    r=ex.run([str(exe),program,payload],O/(mode+'-'+name),timeout=budget());expected='3\n'+payload+'\nstatus=0';actual=r.stdout.replace('\r\n','\n').rstrip('\n');ok=r.returncode==0 and not r.stderr and actual==expected
    result['cases'].append(dict(id=mode+'-'+name,passed=ok,expected=expected,actual=actual,stderr=r.stderr));result['completed']+=int(ok);ex.save()
  assert result['completed']==result['total'],'PROCESS_LITERAL_ARGV_MISMATCH'
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

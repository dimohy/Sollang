from pathlib import Path
import sys,json,hashlib,time
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'target24681-windows-control';C=B/'target24672-native/compiler.exe';source=R/'examples/regression/1432-dyn-trait-reachable-implementations.slg';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
files=[Path(__file__),C,source,*sorted((R/'selfhost').rglob('*.slg')),*sorted((R/'stdlib').rglob('*.slg'))];pins={str(p.resolve()):sha(p) for p in files};initialize_output(R,O,reusable_directories=[C.parent,B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,cases=[],inputHashes=pins,scope='Current target-linking Native retained original1432 Windows control; independent completion after Linux spawn failure',claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None;start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start))
 try:
  exe=O/'control.exe';r=ex.run([str(C),'build',str(source),'-o',str(exe),'--target','windows-x64','--stdlib',str(R/'stdlib'),'--keep-temps','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')],O/'build',timeout=budget());assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  r=ex.run([str(exe)],O/'run',timeout=budget());assert r.returncode==0 and not r.stderr and r.stdout.strip()=='7',r.stdout+r.stderr
  result.update(status='passed',completed=1,cases=[dict(id='original1432-windows',passed=True,stdout='7')])
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

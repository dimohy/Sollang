from pathlib import Path
import json, hashlib, datetime
R=Path.cwd(); B=R/'artifacts/scratch/resume-20261006-owner-continuation22'
C=R/'src/Sollang.Compiler/CodeGen/WindowsLlvmRuntimePlatform.cs'; S=R/'selfhost/llvm/emitter/process_runtime.slg'
proof=json.loads((B/'process24688-csharp-after/result.json').read_text(encoding='utf-8-sig'))
assert proof['status']=='passed' and proof['completed']==proof['total']==6 and proof['inputsStable'] and proof['processesStopped']
cs=C.read_text(encoding='utf-8-sig'); slg=S.read_text(encoding='utf-8-sig')
start=cs.index('            define internal i1 @sollang_process_windows_explicit_application(')
end=cs.index('            define internal i64 @sollang_spawn_windows(', start)
helper='\n'.join(line[8:] if line.startswith('        ') else line for line in cs[start:end].splitlines())+'\n'
anchor='    define internal i64 @sollang_process_spawn_windows('
assert slg.count(anchor)==1 and '@sollang_process_windows_explicit_application' not in slg
record=dict(status='compared-before-slg-edit',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),csharpFirst=str(B/'process24688-csharp-after/result.json'),completed=6,total=6,
 csharpDecision='UTF16 scan identifies explicit application paths by slash, backslash or colon; quotes retain invalid raw-name rejection. Explicit names retain raw application pointer; plain search names use null application with existing quoted command line. Existing ownership, quoting and stdio decisions unchanged.',
 slgDecision='Copy exact helper and CreateProcess application-selection branches, preserving existing SLG handle acquisition and ownership.',
 beforeHashes={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in [C,S]},claimsGoalComplete=False)
(B/'process24686-source-comparison/decision.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
slg=slg.replace(anchor,helper+anchor,1)
old='      %created = call i32 @CreateProcessW(ptr %program, ptr %command,'
new='      %explicit_application = call i1 @sollang_process_windows_explicit_application(ptr %program)\n      %application = select i1 %explicit_application, ptr %program, ptr null\n      %created = call i32 @CreateProcessW(ptr %application, ptr %command,'
assert slg.count(old)==1
S.write_text(slg.replace(old,new,1),encoding='utf-8')
print('CSharp proof checked; source decisions recorded before SLG edit; exact helper ported.')

define internal i1 @sollang_process_windows_arg_needs_quotes(ptr %source, i32 %chars) #0 {
entry:
  %empty = icmp eq i32 %chars, 0
  br i1 %empty, label %quoted, label %scan
scan:
  %index = phi i32 [ 0, %entry ], [ %next, %advance ]
  %character_ptr = getelementptr i16, ptr %source, i32 %index
  %character = load i16, ptr %character_ptr, align 2
  %quote = icmp eq i16 %character, 34
  %space = icmp eq i16 %character, 32
  %ascii_offset = sub i16 %character, 9
  %ascii_space = icmp ule i16 %ascii_offset, 4
  %next_line = icmp eq i16 %character, 133
  %no_break = icmp eq i16 %character, 160
  %ogham = icmp eq i16 %character, 5760
  %unicode_offset = sub i16 %character, 8192
  %unicode_space = icmp ule i16 %unicode_offset, 10
  %separator_offset = sub i16 %character, 8232
  %separator = icmp ule i16 %separator_offset, 1
  %narrow_no_break = icmp eq i16 %character, 8239
  %medium_space = icmp eq i16 %character, 8287
  %ideographic_space = icmp eq i16 %character, 12288
  %needs0 = or i1 %quote, %space
  %needs1 = or i1 %needs0, %ascii_space
  %needs2 = or i1 %needs1, %next_line
  %needs3 = or i1 %needs2, %no_break
  %needs4 = or i1 %needs3, %ogham
  %needs5 = or i1 %needs4, %unicode_space
  %needs6 = or i1 %needs5, %separator
  %needs7 = or i1 %needs6, %narrow_no_break
  %needs8 = or i1 %needs7, %medium_space
  %needs = or i1 %needs8, %ideographic_space
  br i1 %needs, label %quoted, label %advance
advance:
  %next = add i32 %index, 1
  %done = icmp eq i32 %next, %chars
  br i1 %done, label %plain, label %scan
quoted:
  ret i1 true
plain:
  ret i1 false
}


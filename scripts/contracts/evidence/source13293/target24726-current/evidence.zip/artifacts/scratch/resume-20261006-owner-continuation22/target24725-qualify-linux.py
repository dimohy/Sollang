from pathlib import Path
import json,hashlib,datetime,sys
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_contract_lease import VerificationContractLease
from verification_json_records import write_json_atomic
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'target24719-native-pair';P=B/'target24723-linux-run';read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
j=read(O/'result.json');receipt=read(P/'result.json');before=O/'awaiting-linux-runtime.json'
assert not before.exists() and j['status']=='awaiting-linux-runtime' and j['completed']==2 and j['total']==3 and j['inputsStable'] and j['processesStopped']
assert all(sha(p)==h for p,h in j['inputHashes'].items())
assert receipt['status']=='observed-not-qualified' and receipt['inputsStable'] and receipt['processesStopped'] and receipt['programExit']==0
for p,h in receipt['inputHashes'].items():
 assert p.startswith('/mnt/w/MyWorks/Sollang/');assert sha(R/p.removeprefix('/mnt/w/MyWorks/Sollang/'))==h
expected=(R/'examples/regression/expected/23-webassembly-browser.stdout.txt').read_text(encoding='utf-8-sig').replace('\r\n','\n').rstrip('\n')
assert not (P/'command.stderr').read_text() and (P/'command.stdout').read_text().replace('\r\n','\n').rstrip('\n')==expected
linuxBuild=next(p for p in j['processes'] if 'linux-x64' in p['command'])
elapsed=(datetime.datetime.fromisoformat(receipt['processes'][0]['finishedAtUtc'])-datetime.datetime.fromisoformat(linuxBuild['startedAtUtc'])).total_seconds();assert elapsed<180
with VerificationContractLease([Path(p) for p in j['inputHashes']]+[P/'result.json',P/'command.stdout',P/'command.stderr']):
 before.write_bytes((O/'result.json').read_bytes())
 j['inputHashes'].update({str(p.resolve()):sha(p) for p in [Path(__file__),P/'result.json',P/'command.stdout',P/'command.stderr']})
 j.update(status='passed',completed=3,linuxExecutionReceipt=str(P/'result.json'),linuxCaseElapsedSeconds=elapsed,linuxExecutionScope='Actual ELF payload and descendants supervised in owned Linux process group. Windows compiler build and descendants separately passed owned Windows job. WSL transport helpers are outside the Linux payload process-group claim.')
 j['cases'].append(dict(id='linux-x64-original23',passed=True,stdout=expected,artifactSha256=sha(O/'program-linux.exe'),executionReceipt=str(P/'result.json')))
 j['linuxBuild']['status']='passed-build-and-runtime'
 assert all(sha(p)==h for p,h in j['inputHashes'].items())
 write_json_atomic(O/'result.json',j)
print(json.dumps(dict(status=j['status'],completed=j['completed'],total=j['total'],linuxCaseElapsedSeconds=elapsed)))

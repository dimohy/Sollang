from pathlib import Path
import json,hashlib,datetime
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'process24704-source-comparison'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
records=[B/'process24707-csharp-argv/result.json',B/'process24708-csharp-search/result.json'];rows=[read(p) for p in records]
assert all(j['status']=='passed' and j['completed']==j['total'] and j['inputsStable'] and j['processesStopped'] for j in rows)
proof=dict(status='passed',completed=sum(j['completed'] for j in rows),total=sum(j['total'] for j in rows),inputsStable=True,processesStopped=True,composition=[str(p.relative_to(R)) for p in records],claimsNewExecution=False,scope='CSharp minimal quoting and search-name actual focused consumers. WSL exit0 observation remains unqualified because Windows descendants survived.',claimsGoalComplete=False)
(O/'csharp-first18.json').write_text(json.dumps(proof,indent=2)+'\n')
j=read(O/'decision.json');j['csharpFirstControls']=j['csharpFirst'];j.update(csharpFirst=str((O/'csharp-first18.json').relative_to(R)),sourceEmitterBudget=dict(maximumBuilds=1,timeoutSeconds=180,output=str((B/'process24716-native').relative_to(R))),requiredNativePreflights=[str((B/'process24714-stdlib/result.json').relative_to(R))],reasonForDistinctBuild='Native24695 passed executable-name fix and literal controls. New reproduced WSL127 raw-option defect led to CSharp minimal quoting repair, proved18/18 before SLG port; independent source epoch needs one producer. No WSL shutdown fix or unchanged target replay budget is claimed.')
(O/'native-build-plan.json').write_text(json.dumps(j,indent=2)+'\n')
print('CSharp proof18 frozen; one distinct minimal-quoting producer budget; WSL shutdown excluded from completion.')

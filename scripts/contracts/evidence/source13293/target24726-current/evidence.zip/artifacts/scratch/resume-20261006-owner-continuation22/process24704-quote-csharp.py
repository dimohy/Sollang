from pathlib import Path
import json,hashlib,datetime,shutil
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'process24704-source-comparison';O.mkdir()
C=R/'src/Sollang.Compiler/CodeGen/WindowsLlvmRuntimePlatform.cs';S=R/'selfhost/llvm/emitter/process_runtime.slg'
for p,name in [(C,'csharp-before.cs'),(S,'slg-before.slg')]:shutil.copyfile(p,O/name)
helper='''define internal i1 @sollang_process_windows_arg_needs_quotes(ptr %source, i32 %chars) #0 {
entry:
  %empty = icmp eq i32 %chars, 0
  br i1 %empty, label %quoted, label %scan
scan:
  %index = phi i32 [ 0, %entry ], [ %next, %advance ]
  %character_ptr = getelementptr i16, ptr %source, i32 %index
  %character = load i16, ptr %character_ptr, align 2
  %quote = icmp eq i16 %character, 34
  %space = icmp eq i16 %character, 32
  %ascii_offset = sub i16 %character, 9
  %ascii_space = icmp ule i16 %ascii_offset, 4
  %next_line = icmp eq i16 %character, 133
  %no_break = icmp eq i16 %character, 160
  %ogham = icmp eq i16 %character, 5760
  %unicode_offset = sub i16 %character, 8192
  %unicode_space = icmp ule i16 %unicode_offset, 10
  %separator_offset = sub i16 %character, 8232
  %separator = icmp ule i16 %separator_offset, 1
  %narrow_no_break = icmp eq i16 %character, 8239
  %medium_space = icmp eq i16 %character, 8287
  %ideographic_space = icmp eq i16 %character, 12288
  %needs0 = or i1 %quote, %space
  %needs1 = or i1 %needs0, %ascii_space
  %needs2 = or i1 %needs1, %next_line
  %needs3 = or i1 %needs2, %no_break
  %needs4 = or i1 %needs3, %ogham
  %needs5 = or i1 %needs4, %unicode_space
  %needs6 = or i1 %needs5, %separator
  %needs7 = or i1 %needs6, %narrow_no_break
  %needs8 = or i1 %needs7, %medium_space
  %needs = or i1 %needs8, %ideographic_space
  br i1 %needs, label %quoted, label %advance
advance:
  %next = add i32 %index, 1
  %done = icmp eq i32 %next, %chars
  br i1 %done, label %plain, label %scan
quoted:
  ret i1 true
plain:
  ret i1 false
}

'''
(O/'helper.ll').write_text(helper)
s=C.read_text(encoding='utf-8-sig');anchor='            define internal ptr @sollang_quote_windows_arg('
assert s.count(anchor)==1
s=s.replace(anchor,''.join('            '+line+'\n' if line else '\n' for line in helper.splitlines())+anchor,1)
old='''            init:
              store i16 34, ptr %out, align 2'''
new='''            init:
              %needs_quotes = call i1 @sollang_process_windows_arg_needs_quotes(ptr %src, i32 %chars)
              br i1 %needs_quotes, label %quote_init, label %plain_copy
            plain_copy:
              %plain_bytes = mul i64 %chars64, 2
              call void @llvm.memcpy.p0.p0.i64(ptr %out, ptr %src, i64 %plain_bytes, i1 false)
              %plain_null = getelementptr i16, ptr %out, i64 %chars64
              store i16 0, ptr %plain_null, align 2
              ret ptr %out
            quote_init:
              store i16 34, ptr %out, align 2'''
assert s.count(old)==1
C.write_text(s.replace(old,new,1),encoding='utf-8')
record=dict(status='csharp-repair-awaiting-proof',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),root='Compiled CSharp runtime and Native runtime quote every argv entry. WSL interprets quoted --exec as command text; CSharp Tooling uses .NET minimal argument quoting.',primaryReference='https://source.dot.net/System.Private.CoreLib/src/runtime/src/libraries/System.Private.CoreLib/src/System/PasteArguments.cs.html',reproduction=str(B/'process24703-wsl-csharp-before/result.json'),decision='Copy simple nonempty argv entries without added quotes; preserve existing quote/backslash escaping for empty, whitespace or quote-containing entries. Unicode whitespace list matches Char.IsWhiteSpace BMP values. Preserve independent raw program pointer and owned per-argument allocations.',claimsGoalComplete=False)
(O/'decision.json').write_text(json.dumps(record,indent=2)+'\n')
print('CSharp minimal quoting repair applied; SLG remains unchanged pending focused proof.')

; sollang cpu contract cpu1-d-r1-a3fe-f0
target triple = "x86_64-pc-windows-msvc"

%sollang.text = type { ptr, i64 }
%sollang.source_text = type { ptr, i64, ptr, i64 }
%sollang.int_slice = type { ptr, i64 }
%sollang.mutable_container = type { ptr, ptr, ptr }
%sollang.dynamic_int_array = type { ptr, i64, i64 }
%sollang.int_dictionary = type { ptr, i64, i64 }
%sollang.read_int_result = type { i64, i32 }
%sollang.file_int_result = type { i64, i32 }
%sollang.file_count_result = type { i64, i32 }
%sollang.file_handle_result = type { i64, i32 }
%sollang.socket_result = type { i64, i32, i32 }
%sollang.mapped_bytes = type { ptr, i64, ptr, i64, i1 }
%sollang.environment_result = type { ptr, i64, i1, i1 }
%sollang.process_result = type { i32, i32 }
%sollang.process_poll_result = type { i32, i32 }
%sollang.process_spawn_result = type { i64, i64, i32 }
%sollang.process_capture_result = type { i32, ptr, i64, i64, i1, ptr, i64, i64, i1, i32 }
%sollang.process_environment_result = type { ptr, i64, i64, i1 }
%sollang.task = type { ptr, ptr }
%sollang.stream = type { ptr, ptr, ptr }
%sollang.event_stream = type { ptr, ptr, ptr }
%sollang.dyn = type { ptr, ptr }
%sollang.task_control = type { ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, i64, ptr, ptr, i32, i32, i64, i64, i32, ptr, i64, i64, i32, i32, ptr, ptr }%sollang.struct.27 = type { i64 }
%sollang.struct.29 = type { i64 }
%sollang.struct.30 = type { i64 }
%sollang.struct.31 = type { i64 }
%sollang.struct.32 = type { %sollang.dynamic_int_array, %sollang.text, i1, %sollang.dynamic_int_array, i1, %sollang.enum.1585, %sollang.enum.1586, %sollang.enum.1586 }
%sollang.struct.33 = type { %sollang.text, %sollang.text }
%sollang.struct.34 = type { %sollang.dynamic_int_array, %sollang.enum.35 }
%sollang.struct.43 = type { i32, i32 }
%sollang.struct.44 = type { i32, i32, i32, i32, %sollang.enum.45 }
%sollang.struct.1024 = type { %sollang.enum.1451 }
%sollang.struct.1025 = type {  }
%sollang.struct.1026 = type { i32, i1 }
%sollang.struct.1027 = type { i32, i32 }
%sollang.struct.1028 = type { %sollang.enum.1457, i64 }
%sollang.struct.1029 = type { i32, i32, i32, i32, i32 }
%sollang.struct.1030 = type { %sollang.struct.1029 }
%sollang.struct.1031 = type { i32, i32, i32 }
%sollang.struct.1032 = type { %sollang.struct.1029, %sollang.enum.1455, i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32, i32, i32, %sollang.dynamic_int_array, i32, i32, i32, i32, %sollang.dynamic_int_array, i1, %sollang.struct.1031, i32, %sollang.struct.1184, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32, i32, i32, %sollang.dynamic_int_array, i32, i32, %sollang.dynamic_int_array, i32, i1, %sollang.struct.1028 }
%sollang.struct.1033 = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%sollang.struct.1034 = type { %sollang.struct.1033, %sollang.enum.1456, i32, i32, i32, i32, i32, i32, %sollang.struct.1184, %sollang.dynamic_int_array }
%sollang.struct.1035 = type { i32 }
%sollang.struct.1036 = type { %sollang.text, %sollang.text, i32, i64, i32, i32 }
%sollang.struct.1037 = type { i64, %sollang.enum.2157, %sollang.enum.1458, %sollang.enum.1459, %sollang.enum.2157, i64, %sollang.enum.2158 }
%sollang.struct.1038 = type { i64, i64, i64, i1 }
%sollang.struct.1039 = type { i64, i64, i64 }
%sollang.struct.1040 = type { i64 }
%sollang.struct.1041 = type { %sollang.struct.1040, %sollang.enum.1462 }
%sollang.struct.1042 = type { %sollang.enum.1489, i64 }
%sollang.struct.1043 = type { i32, i32, i32, i32, i32 }
%sollang.struct.1044 = type { %sollang.struct.1043 }
%sollang.struct.1045 = type { i32, i32, i32, i32, i32, i32, i1 }
%sollang.struct.1046 = type { i32, i32, i32, i32, i32, i32, %sollang.enum.1488, %sollang.struct.1102, %sollang.struct.1060, %sollang.struct.1079, i32, i1, i32, i32, i32, %sollang.dynamic_int_array, i1, %sollang.struct.1042 }
%sollang.struct.1047 = type { i32, i32 }
%sollang.struct.1048 = type { i32, i32 }
%sollang.struct.1049 = type { i32, i32 }
%sollang.struct.1050 = type { i1, i64 }
%sollang.struct.1051 = type { %sollang.enum.1466, i64 }
%sollang.struct.1052 = type { i32, i32, i32 }
%sollang.struct.1053 = type { %sollang.struct.1071, i32, i32, i32, i32 }
%sollang.struct.1054 = type { %sollang.dynamic_int_array, %sollang.struct.1098 }
%sollang.struct.1055 = type { %sollang.struct.1071, %sollang.struct.1106, i32, i32, i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32, i32, %sollang.enum.1463, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.1463 }
%sollang.struct.1056 = type { %sollang.dynamic_int_array }
%sollang.struct.1057 = type { i32, %sollang.struct.1098 }
%sollang.struct.1058 = type { %sollang.enum.1479, i64 }
%sollang.struct.1059 = type { i32, i32, i32, i32, i32, i32 }
%sollang.struct.1060 = type { %sollang.struct.1089, %sollang.struct.1082, %sollang.struct.1110, i32, i32, i32 }
%sollang.struct.1061 = type { %sollang.enum.1467, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.1490, i32, i32 }
%sollang.struct.1062 = type { i32, i32, i32, i32, i32, %sollang.enum.1490, i32, i32 }
%sollang.struct.1063 = type { %sollang.struct.1089, i32, i32, %sollang.enum.1470, i32, i32, i32, i32, %sollang.enum.1469, %sollang.enum.1469 }
%sollang.struct.1064 = type { %sollang.struct.1060, %sollang.struct.1063, %sollang.enum.1472, i32, %sollang.dynamic_int_array, i32, i32, %sollang.dynamic_int_array }
%sollang.struct.1065 = type { %sollang.dynamic_int_array, i32, i32, i32, %sollang.dynamic_int_array, i32 }
%sollang.struct.1066 = type { %sollang.struct.1065, %sollang.struct.1084, %sollang.enum.1474, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32, i32 }
%sollang.struct.1067 = type { %sollang.dynamic_int_array, i32, i32, i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32, i32 }
%sollang.struct.1068 = type { %sollang.struct.1067, %sollang.struct.1112, %sollang.enum.1476, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array }
%sollang.struct.1069 = type { i32, i32, %sollang.enum.1469, %sollang.enum.1469 }
%sollang.struct.1070 = type { i32, i32, %sollang.struct.1098 }
%sollang.struct.1071 = type { %sollang.dynamic_int_array, i32, i32, i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.struct.1098 }
%sollang.struct.1072 = type { i32, %sollang.struct.1098 }
%sollang.struct.1073 = type { %sollang.struct.1069, %sollang.struct.1098 }
%sollang.struct.1074 = type { %sollang.enum.1489, i64 }
%sollang.struct.1075 = type { i32, i32, i32 }
%sollang.struct.1076 = type { %sollang.struct.1064, %sollang.struct.1092 }
%sollang.struct.1077 = type { %sollang.struct.1066, %sollang.struct.1092 }
%sollang.struct.1078 = type { %sollang.struct.1068, %sollang.struct.1092 }
%sollang.struct.1079 = type { %sollang.struct.1060, %sollang.struct.1075, i32, %sollang.dynamic_int_array, %sollang.enum.1480 }
%sollang.struct.1080 = type { %sollang.enum.1487, i64 }
%sollang.struct.1081 = type { i32, i32, i32 }
%sollang.struct.1082 = type { %sollang.struct.1089, i32, i32 }
%sollang.struct.1083 = type { %sollang.dynamic_int_array, i32, %sollang.struct.1098 }
%sollang.struct.1084 = type { %sollang.struct.1089, i32, i32, i32, %sollang.enum.1483, i32, i32, i32, %sollang.dynamic_int_array, %sollang.enum.1484 }
%sollang.struct.1085 = type { %sollang.dynamic_int_array, i32 }
%sollang.struct.1086 = type { i32, %sollang.struct.1098 }
%sollang.struct.1087 = type { %sollang.enum.1496, i64 }
%sollang.struct.1088 = type { i32, i32 }
%sollang.struct.1089 = type { %sollang.struct.1096, i32 }
%sollang.struct.1090 = type { %sollang.struct.1097, %sollang.struct.1098 }
%sollang.struct.1091 = type { %sollang.enum.1491, i32 }
%sollang.struct.1092 = type { %sollang.struct.1096, i32, i32, i32, %sollang.enum.1493, i32, i32, i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.struct.1091, %sollang.dynamic_int_array, i32, i32, i32, %sollang.enum.1494, i32, i32, i32, i32, i32, i32, %sollang.enum.1494 }
%sollang.struct.1093 = type { i32, %sollang.struct.1098 }
%sollang.struct.1094 = type { %sollang.enum.1499, i64 }
%sollang.struct.1095 = type { i32, i32 }
%sollang.struct.1096 = type { i32, i32 }
%sollang.struct.1097 = type { %sollang.dynamic_int_array, i32 }
%sollang.struct.1098 = type { i32, i32 }
%sollang.struct.1099 = type { i32, %sollang.struct.1098 }
%sollang.struct.1100 = type { i32, i32 }
%sollang.struct.1101 = type { i32 }
%sollang.struct.1102 = type { i64, i32, i32 }
%sollang.struct.1103 = type { i32, i32 }
%sollang.struct.1104 = type { %sollang.enum.1501, i64 }
%sollang.struct.1105 = type { i32 }
%sollang.struct.1106 = type { i32 }
%sollang.struct.1107 = type { i32, %sollang.enum.1500, i32 }
%sollang.struct.1108 = type { %sollang.enum.1503, i64 }
%sollang.struct.1109 = type { i32, i32, i32, i32 }
%sollang.struct.1110 = type { %sollang.struct.1089, i32, i32, i32 }
%sollang.struct.1111 = type { %sollang.dynamic_int_array, %sollang.struct.1098 }
%sollang.struct.1112 = type { %sollang.struct.1089, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.dynamic_int_array }
%sollang.struct.1113 = type { %sollang.dynamic_int_array }
%sollang.struct.1114 = type { %sollang.enum.1505, i64 }
%sollang.struct.1115 = type { i32, i32 }
%sollang.struct.1116 = type { %sollang.struct.1115 }
%sollang.struct.1117 = type { i32, i32 }
%sollang.struct.1118 = type { i32, i32, i32, i32, i1, i1, %sollang.struct.1124 }
%sollang.struct.1119 = type { %sollang.struct.1116, i32, i32, i32, i32, i32, i32, %sollang.enum.1504, i32, i32, i32, i32, i32, i32, i32, i1, i32, i32, i32, i32, i32, i32, i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.struct.1129, %sollang.struct.1129, %sollang.struct.1129, i32, i32, i32, i32, i32, i32, i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32, i1, %sollang.struct.1114, i1, i1 }
%sollang.struct.1120 = type { %sollang.struct.1119 }
%sollang.struct.1121 = type { i32, i32, i32 }
%sollang.struct.1122 = type { i32, i32, i32, i32 }
%sollang.struct.1123 = type { i32, i32 }
%sollang.struct.1124 = type { i32, i32 }
%sollang.struct.1125 = type { i32, i32 }
%sollang.struct.1126 = type { i32, i32, i32 }
%sollang.struct.1127 = type { i32, i32, i32 }
%sollang.struct.1128 = type { i32, i32 }
%sollang.struct.1129 = type { %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32 }
%sollang.struct.1130 = type { %sollang.struct.1129, %sollang.struct.1129 }
%sollang.struct.1131 = type { %sollang.struct.1123, i32, %sollang.dynamic_int_array }
%sollang.struct.1132 = type { i32, %sollang.dynamic_int_array }
%sollang.struct.1133 = type { i32 }
%sollang.struct.1134 = type { i32 }
%sollang.struct.1135 = type { i1, i32 }
%sollang.struct.1136 = type { i1, i32 }
%sollang.struct.1137 = type { i1, i32 }
%sollang.struct.1138 = type { %sollang.enum.1507, i64 }
%sollang.struct.1139 = type { %sollang.dynamic_int_array, %sollang.struct.1149, i1, %sollang.struct.1145, %sollang.struct.1145, %sollang.struct.1145, i1, i1, i1, i32, i32, i32 }
%sollang.struct.1140 = type { i32, i32, i32, i32, i32 }
%sollang.struct.1141 = type { i1 }
%sollang.struct.1142 = type { %sollang.struct.1140, %sollang.struct.1141 }
%sollang.struct.1143 = type { i32, i32, i32, i32, i1, i1, %sollang.struct.1186 }
%sollang.struct.1144 = type { i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.1506, i64, i32, i32, i32, i32, i32, i1, i64, i1, %sollang.struct.1186, i32, i32, i32, i32, i1, %sollang.dynamic_int_array, %sollang.struct.1149, i1, %sollang.struct.1145, %sollang.struct.1145, %sollang.struct.1145, i1, i1, i1, i32, i32, i32, %sollang.dynamic_int_array, i1, %sollang.struct.1138 }
%sollang.struct.1145 = type { %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32 }
%sollang.struct.1146 = type { %sollang.struct.1145, i32 }
%sollang.struct.1147 = type { i32 }
%sollang.struct.1148 = type { i32, i32, i32 }
%sollang.struct.1149 = type { %sollang.dynamic_int_array, i32 }
%sollang.struct.1150 = type { %sollang.struct.1149, i32 }
%sollang.struct.1151 = type { i32, i32 }
%sollang.struct.1152 = type { %sollang.struct.1145, %sollang.struct.1145, %sollang.struct.1145, i1, i1, i1, i32, i32, i32, i32 }
%sollang.struct.1153 = type { i32, i32, i32 }
%sollang.struct.1154 = type { %sollang.dynamic_int_array, %sollang.struct.1145, %sollang.struct.1145, %sollang.struct.1145, i1, i1, i1, i32, i32, i32 }
%sollang.struct.1155 = type { %sollang.dynamic_int_array }
%sollang.struct.1156 = type { %sollang.int_slice }
%sollang.struct.1157 = type { %sollang.dynamic_int_array, %sollang.int_slice }
%sollang.struct.1158 = type { %sollang.struct.1155, %sollang.int_slice }
%sollang.struct.1159 = type { %sollang.int_slice }
%sollang.struct.1160 = type { %sollang.enum.1513 }
%sollang.struct.1161 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.1162 = type { %sollang.struct.1164, %sollang.struct.1164 }
%sollang.struct.1163 = type { i8 }
%sollang.struct.1164 = type { %sollang.int_slice, %sollang.int_slice, i32, i64 }
%sollang.struct.1165 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.1166 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.1167 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.1168 = type { %sollang.enum.1515, i64 }
%sollang.struct.1169 = type { i32, i32 }
%sollang.struct.1170 = type { i32, i32 }
%sollang.struct.1171 = type { %sollang.enum.1516, %sollang.enum.1517 }
%sollang.struct.1172 = type { %sollang.struct.1171, i32, i32, i64, i8, i8, i32 }
%sollang.struct.1173 = type { %sollang.struct.1171, i32, i32, i64, i32, i32, i32, i32, i64, i64, i64, i64, i32, i1 }
%sollang.struct.1174 = type { i32, i32, i64, i32, i32, i32, i32, i64, i64, i64, i64, i32, i1 }
%sollang.struct.1175 = type { %sollang.enum.1519, i64 }
%sollang.struct.1176 = type { %sollang.enum.1518, i64 }
%sollang.struct.1177 = type { %sollang.enum.1518, i32, i32 }
%sollang.struct.1178 = type { %sollang.enum.1520, i64 }
%sollang.struct.1179 = type { i32, i32 }
%sollang.struct.1180 = type { i32, i32 }
%sollang.struct.1181 = type { i1 }
%sollang.struct.1182 = type { %sollang.struct.1181, i32, i32, i64 }
%sollang.struct.1183 = type { i32, i32, i64, i32, i64 }
%sollang.struct.1184 = type { %sollang.enum.1521, i32 }
%sollang.struct.1185 = type { i64 }
%sollang.struct.1186 = type { i64, i64, i64, i64, i64, i64, i64, %sollang.int_slice, i32 }
%sollang.struct.1187 = type { %sollang.enum.1522, i64 }
%sollang.struct.1188 = type { i32, %sollang.enum.1524 }
%sollang.struct.1189 = type { i32, i32 }
%sollang.struct.1190 = type { %sollang.dynamic_int_array, i32, %sollang.dynamic_int_array, i32, i32 }
%sollang.struct.1191 = type { %sollang.dynamic_int_array, i32, i32 }
%sollang.struct.1192 = type { %sollang.dynamic_int_array, i32 }
%sollang.struct.1193 = type { i1 }
%sollang.struct.1194 = type { %sollang.struct.1191, %sollang.dynamic_int_array, i32, i1 }
%sollang.struct.1195 = type { %sollang.struct.1191, %sollang.dynamic_int_array, %sollang.enum.1525 }
%sollang.struct.1196 = type { %sollang.struct.1192, %sollang.dynamic_int_array, i32 }
%sollang.struct.1197 = type { %sollang.struct.1192, %sollang.dynamic_int_array, %sollang.enum.1525 }
%sollang.struct.1198 = type { %sollang.dynamic_int_array, i32, i32, i32, i1 }
%sollang.struct.1199 = type { %sollang.struct.1198, %sollang.dynamic_int_array, i32, i1 }
%sollang.struct.1200 = type { %sollang.struct.1198, %sollang.dynamic_int_array, %sollang.enum.1525 }
%sollang.struct.1201 = type { %sollang.struct.1198, %sollang.dynamic_int_array, i32, i1 }
%sollang.struct.1202 = type { %sollang.struct.1198, %sollang.dynamic_int_array, %sollang.enum.1525 }
%sollang.struct.1203 = type { %sollang.struct.29, i64 }
%sollang.struct.1204 = type { %sollang.struct.30, i64 }
%sollang.struct.1205 = type { %sollang.struct.1203, %sollang.dynamic_int_array, i32, i1 }
%sollang.struct.1206 = type { %sollang.struct.1203, %sollang.dynamic_int_array, %sollang.enum.1583 }
%sollang.struct.1207 = type { %sollang.struct.1204, %sollang.dynamic_int_array, i32 }
%sollang.struct.1208 = type { %sollang.struct.1204, %sollang.dynamic_int_array, %sollang.enum.1583 }
%sollang.struct.1209 = type { %sollang.struct.1362, i64 }
%sollang.struct.1210 = type { %sollang.struct.1355, %sollang.struct.1373 }
%sollang.struct.1211 = type { %sollang.struct.1209, %sollang.dynamic_int_array, i64, i1 }
%sollang.struct.1212 = type { %sollang.struct.1209, %sollang.dynamic_int_array, %sollang.struct.1373 }
%sollang.struct.1213 = type { %sollang.struct.1209, %sollang.dynamic_int_array, i64 }
%sollang.struct.1214 = type { %sollang.struct.1209, %sollang.dynamic_int_array, %sollang.struct.1373 }
%sollang.struct.1215 = type { %sollang.text, %sollang.text }
%sollang.struct.1216 = type { %sollang.text }
%sollang.struct.1217 = type { %sollang.enum.1526, %sollang.text }
%sollang.struct.1218 = type { %sollang.enum.1526 }
%sollang.struct.1219 = type { i8, i8, i8, i8 }
%sollang.struct.1220 = type { %sollang.struct.1219, i16 }
%sollang.struct.1221 = type { i16, i16, i16, i16, i16, i16, i16, i16 }
%sollang.struct.1222 = type { %sollang.struct.1221, i16, i32, i32 }
%sollang.struct.1223 = type { %sollang.enum.1545, i64 }
%sollang.struct.1224 = type { %sollang.enum.1530, i32 }
%sollang.struct.1225 = type { %sollang.enum.1529, i64, i64 }
%sollang.struct.1226 = type { %sollang.enum.1537, i64 }
%sollang.struct.1227 = type { i32, i32, i32, i32, i32 }
%sollang.struct.1228 = type { i64, i64 }
%sollang.struct.1229 = type { %sollang.struct.1228, %sollang.struct.1228 }
%sollang.struct.1230 = type { %sollang.struct.1227 }
%sollang.struct.1231 = type { %sollang.source_text, %sollang.struct.1228, %sollang.struct.1228, %sollang.enum.1531, %sollang.dynamic_int_array, i64 }
%sollang.struct.1232 = type { %sollang.source_text, %sollang.enum.1531, i32, %sollang.struct.1228, %sollang.dynamic_int_array, i64 }
%sollang.struct.1233 = type { %sollang.dynamic_int_array, i64 }
%sollang.struct.1234 = type { i32, i32, i32, i32, i32 }
%sollang.struct.1235 = type { %sollang.struct.1234 }
%sollang.struct.1236 = type { %sollang.struct.1235, %sollang.text }
%sollang.struct.1237 = type { %sollang.enum.1532, %sollang.struct.1234 }
%sollang.struct.1238 = type { i64, i64, i1 }
%sollang.struct.1239 = type { %sollang.struct.1234, %sollang.enum.1533, %sollang.enum.1534, i64, i64, i64, i64, %sollang.dynamic_int_array, i1, i64, i32 }
%sollang.struct.1240 = type { i1, i64, i1, i1 }
%sollang.struct.1241 = type { %sollang.enum.1528, %sollang.struct.1230, %sollang.struct.1235, i32, i32 }
%sollang.struct.1242 = type { %sollang.struct.1355, %sollang.struct.1230, %sollang.struct.1235, i32, i32 }
%sollang.struct.1243 = type { %sollang.struct.1355, %sollang.struct.1230, %sollang.struct.1235, i32, i32, %sollang.enum.1540, %sollang.enum.1539 }
%sollang.struct.1244 = type { %sollang.struct.1355, %sollang.struct.1230, %sollang.struct.1235, i32, i32, %sollang.enum.1540, %sollang.enum.1539, %sollang.dynamic_int_array, %sollang.struct.1232, i64 }
%sollang.struct.1245 = type { %sollang.struct.1355, %sollang.struct.1230, %sollang.struct.1235, i32, i32, %sollang.dynamic_int_array, i64, %sollang.dynamic_int_array, i64, %sollang.struct.1239, i1, i1, i1 }
%sollang.struct.1246 = type { i32, i32, i32, i32 }
%sollang.struct.1247 = type { %sollang.struct.1246 }
%sollang.struct.1248 = type { %sollang.struct.1246, %sollang.dynamic_int_array, %sollang.text, i32, i32, i1, i1, i1, i64, %sollang.enum.1539, %sollang.enum.1540 }
%sollang.struct.1249 = type { %sollang.dynamic_int_array, i64, %sollang.enum.1539, %sollang.enum.1540 }
%sollang.struct.1250 = type { i32, i32, i32, i32 }
%sollang.struct.1251 = type { %sollang.struct.1250 }
%sollang.struct.1252 = type { %sollang.struct.1250, %sollang.dynamic_int_array, i32, i32, i1, i1, i1, i64, %sollang.enum.1542 }
%sollang.struct.1253 = type { %sollang.dynamic_int_array, i64, %sollang.enum.1542, %sollang.enum.1541 }
%sollang.struct.1254 = type { %sollang.struct.1352, %sollang.struct.1227 }
%sollang.struct.1255 = type { %sollang.struct.1354, %sollang.struct.1230, i32 }
%sollang.struct.1256 = type { %sollang.struct.1355, %sollang.struct.1230, i32, %sollang.dynamic_int_array, i64 }
%sollang.struct.1257 = type { %sollang.struct.1355, %sollang.struct.1230, i32, %sollang.dynamic_int_array, %sollang.struct.1231, i64, %sollang.dynamic_int_array, i64, i1 }
%sollang.struct.1258 = type { %sollang.struct.1355, %sollang.struct.1230, i32, %sollang.dynamic_int_array, %sollang.struct.1231, i64, %sollang.dynamic_int_array, i64, %sollang.struct.1239 }
%sollang.struct.1259 = type { %sollang.enum.1546, i64 }
%sollang.struct.1260 = type { %sollang.int_slice }
%sollang.struct.1261 = type { %sollang.struct.1356, %sollang.enum.1528, i1, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i64 }
%sollang.struct.1262 = type { i64, i64, i64, i64 }
%sollang.struct.1263 = type { i64, i64, i32, i32, i32, i64, %sollang.struct.1262 }
%sollang.struct.1264 = type { %sollang.struct.1260, %sollang.enum.1528, %sollang.struct.1263, i1 }
%sollang.struct.1265 = type { %sollang.dynamic_int_array, %sollang.enum.1528, %sollang.enum.1528, i1, i32, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.struct.1275, %sollang.struct.1275, i64, i64, i1, %sollang.int_slice, %sollang.dynamic_int_array, %sollang.int_slice, %sollang.dynamic_int_array, i1, i1, %sollang.dynamic_int_array, %sollang.struct.1328, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i64, i32, i64, i1, i1, %sollang.struct.1321, %sollang.struct.1303, %sollang.struct.1304, %sollang.struct.1332, %sollang.struct.1334, i64, i64, i64, i64, i64, i64, i8, i64, i64 }
%sollang.struct.1266 = type { %sollang.struct.1331, i1, i1, i64 }
%sollang.struct.1267 = type { %sollang.struct.1330, i1, i1, i64, i1, i64 }
%sollang.struct.1268 = type { i64, %sollang.struct.1266, %sollang.struct.1267 }
%sollang.struct.1269 = type { i64, %sollang.struct.1266 }
%sollang.struct.1270 = type { i64, %sollang.struct.1267 }
%sollang.struct.1271 = type { i64, i64 }
%sollang.struct.1272 = type { i64, i8 }
%sollang.struct.1273 = type { i64, i64, i64, i64, i64, i64, i64, i8, i64, i64 }
%sollang.struct.1274 = type { %sollang.dynamic_int_array, i64 }
%sollang.struct.1275 = type { i1, i32, %sollang.int_slice, %sollang.struct.1345 }
%sollang.struct.1276 = type { i64, i1, %sollang.enum.1547 }
%sollang.struct.1277 = type { i64, i1, %sollang.dynamic_int_array }
%sollang.struct.1278 = type { i1, i1, i1, %sollang.struct.1332, %sollang.struct.1333 }
%sollang.struct.1279 = type { i64, i8 }
%sollang.struct.1280 = type { %sollang.dynamic_int_array, i64 }
%sollang.struct.1281 = type { %sollang.dynamic_int_array, i64 }
%sollang.struct.1282 = type { %sollang.dynamic_int_array, i64 }
%sollang.struct.1283 = type { i64, %sollang.dynamic_int_array }
%sollang.struct.1284 = type { %sollang.enum.1546, i64 }
%sollang.struct.1285 = type { i64, %sollang.dynamic_int_array }
%sollang.struct.1286 = type { i64, i64, i1, %sollang.dynamic_int_array }
%sollang.struct.1287 = type { i64, i64, i64 }
%sollang.struct.1288 = type { i64, i64 }
%sollang.struct.1289 = type { %sollang.dynamic_int_array }
%sollang.struct.1290 = type { i64, i64 }
%sollang.struct.1291 = type { i1, i64 }
%sollang.struct.1292 = type { i64, i64 }
%sollang.struct.1293 = type { i1, i64 }
%sollang.struct.1294 = type { i1, i64, i64, %sollang.dynamic_int_array }
%sollang.struct.1295 = type { i64, i64, %sollang.dynamic_int_array, %sollang.int_slice }
%sollang.struct.1296 = type { i64, i64 }
%sollang.struct.1297 = type { i64, i64, i64, %sollang.dynamic_int_array }
%sollang.struct.1298 = type { %sollang.enum.1547, i64 }
%sollang.struct.1299 = type { i32, i64, i64, %sollang.dynamic_int_array, i64 }
%sollang.struct.1300 = type { i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i64, %sollang.dynamic_int_array }
%sollang.struct.1301 = type { %sollang.dynamic_int_array, i64, %sollang.dynamic_int_array }
%sollang.struct.1302 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.1303 = type { i1, i64, i64, i64, i64 }
%sollang.struct.1304 = type { i64, i64, i64, i64, i1 }
%sollang.struct.1305 = type { %sollang.int_slice }
%sollang.struct.1306 = type { %sollang.struct.1260, %sollang.int_slice, %sollang.struct.1305 }
%sollang.struct.1307 = type { %sollang.struct.1305, %sollang.int_slice, %sollang.struct.1220, i64, %sollang.dynamic_int_array, %sollang.int_slice }
%sollang.struct.1308 = type { %sollang.struct.1265, %sollang.struct.1268, %sollang.struct.1305 }
%sollang.struct.1309 = type { %sollang.dynamic_int_array }
%sollang.struct.1310 = type { %sollang.struct.1305, %sollang.struct.1268 }
%sollang.struct.1311 = type { i32, i64, %sollang.dynamic_int_array, i64 }
%sollang.struct.1312 = type { i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i64, i64 }
%sollang.struct.1313 = type { i32, i64, %sollang.dynamic_int_array, i64 }
%sollang.struct.1314 = type { i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i64, i64 }
%sollang.struct.1315 = type { i1, i64, %sollang.dynamic_int_array }
%sollang.struct.1316 = type { i8, i64, %sollang.dynamic_int_array }
%sollang.struct.1317 = type { %sollang.struct.1326, %sollang.struct.1325 }
%sollang.struct.1318 = type { i32, i64 }
%sollang.struct.1319 = type { i64, i64, i64, i1, i1 }
%sollang.struct.1320 = type { %sollang.struct.1303, %sollang.struct.1304, i64, i64, i64, i64 }
%sollang.struct.1321 = type { %sollang.dynamic_int_array }
%sollang.struct.1322 = type { %sollang.int_slice }
%sollang.struct.1323 = type { %sollang.int_slice }
%sollang.struct.1324 = type { %sollang.int_slice, %sollang.int_slice }
%sollang.struct.1325 = type { %sollang.struct.1155 }
%sollang.struct.1326 = type { %sollang.struct.1158, %sollang.int_slice }
%sollang.struct.1327 = type { %sollang.struct.1330, i64 }
%sollang.struct.1328 = type { %sollang.dynamic_int_array, i64 }
%sollang.struct.1329 = type { i64, i64, %sollang.enum.1548, %sollang.enum.1549 }
%sollang.struct.1330 = type { i64, i64, i64, i1, i64 }
%sollang.struct.1331 = type { i64, i64, i1, i64 }
%sollang.struct.1332 = type { i64, i64, i64, i64, i64 }
%sollang.struct.1333 = type { i64, i64 }
%sollang.struct.1334 = type { i1, i64, i64, i1, i1, i64, i64, i64, i64, i64, i64, i32, %sollang.dynamic_int_array, i32, i32, i32, i32, %sollang.dynamic_int_array, i32, i32, i32 }
%sollang.struct.1335 = type { %sollang.dynamic_int_array }
%sollang.struct.1336 = type { i16, %sollang.dynamic_int_array }
%sollang.struct.1337 = type { %sollang.enum.1550, %sollang.struct.1344, %sollang.int_slice }
%sollang.struct.1338 = type { i8, %sollang.dynamic_int_array, i64 }
%sollang.struct.1339 = type { i16, %sollang.dynamic_int_array, i64 }
%sollang.struct.1340 = type { %sollang.int_slice, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.int_slice, %sollang.dynamic_int_array }
%sollang.struct.1341 = type { %sollang.int_slice, %sollang.dynamic_int_array, %sollang.int_slice }
%sollang.struct.1342 = type { %sollang.dynamic_int_array, %sollang.dynamic_int_array }
%sollang.struct.1343 = type { %sollang.enum.1551, %sollang.struct.1344 }
%sollang.struct.1344 = type { %sollang.dynamic_int_array }
%sollang.struct.1345 = type { %sollang.struct.1317 }
%sollang.struct.1346 = type { i64, %sollang.dynamic_int_array, i64 }
%sollang.struct.1347 = type { i64 }
%sollang.struct.1348 = type { i64, i64 }
%sollang.struct.1349 = type { i32, %sollang.dynamic_int_array }
%sollang.struct.1350 = type { %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array }
%sollang.struct.1351 = type { i8, i64, i64, i64 }
%sollang.struct.1352 = type { %sollang.enum.1528, i32, i1 }
%sollang.struct.1353 = type { %sollang.enum.1528, i1 }
%sollang.struct.1354 = type { i64 }
%sollang.struct.1355 = type { i64 }
%sollang.struct.1356 = type { i64 }
%sollang.struct.1357 = type { ptr, i64, i64 }
%sollang.struct.1358 = type { %sollang.dynamic_int_array }
%sollang.struct.1359 = type { i64, %sollang.enum.1555, %sollang.enum.1554 }
%sollang.struct.1360 = type { i64, i1, i1, i1 }
%sollang.struct.1361 = type { i64, i64, i64 }
%sollang.struct.1362 = type { i64 }
%sollang.struct.1363 = type { i64, %sollang.enum.1556, %sollang.dynamic_int_array, i64, i64, %sollang.enum.1557, %sollang.enum.2182, %sollang.enum.2183, %sollang.enum.2157 }
%sollang.struct.1364 = type { %sollang.struct.1362, %sollang.struct.1355, %sollang.struct.1373 }
%sollang.struct.1365 = type { %sollang.struct.1362, %sollang.struct.1355 }
%sollang.struct.1366 = type { %sollang.struct.1362, %sollang.struct.1373 }
%sollang.struct.1367 = type { %sollang.struct.1362, %sollang.struct.1363 }
%sollang.struct.1368 = type { %sollang.struct.1362, %sollang.struct.1363, %sollang.struct.1373 }
%sollang.struct.1369 = type { %sollang.struct.1363, %sollang.struct.1373 }
%sollang.struct.1370 = type { i64, %sollang.dynamic_int_array }
%sollang.struct.1371 = type { %sollang.enum.1528, %sollang.dynamic_int_array, i1 }
%sollang.struct.1372 = type { %sollang.enum.1528, i64, i1 }
%sollang.struct.1373 = type { %sollang.enum.1560, i32 }
%sollang.struct.1374 = type { %sollang.enum.1562, i64 }
%sollang.struct.1375 = type { i32, i32, i32 }
%sollang.struct.1376 = type { %sollang.enum.1561, i64, i64 }
%sollang.struct.1377 = type { %sollang.enum.1561, i64, i1 }
%sollang.struct.1378 = type { %sollang.source_text, i64, i64, i32, i1, %sollang.struct.1375, %sollang.struct.1377 }
%sollang.struct.1379 = type { %sollang.enum.1564, i64, i32 }
%sollang.struct.1380 = type { i32, i32, i32, i32 }
%sollang.struct.1381 = type { i32, i32, i32, i32 }
%sollang.struct.1382 = type { %sollang.enum.1563, i32 }
%sollang.struct.1383 = type { i32, i32, i32, i1 }
%sollang.struct.1384 = type { %sollang.source_text, i64, i64, i32, i32, i1, %sollang.struct.1382, %sollang.struct.1380 }
%sollang.struct.1385 = type { %sollang.struct.1381, i32, i32, i32, i32 }
%sollang.struct.1386 = type { i64, i64, i64, i32, i1, i1 }
%sollang.struct.1387 = type { i32, i32, i32 }
%sollang.struct.1388 = type { %sollang.enum.1565, i64, i64 }
%sollang.struct.1389 = type { %sollang.source_text, i64, i32, i32 }
%sollang.struct.1390 = type { %sollang.enum.1568, i64 }
%sollang.struct.1391 = type { i32, i32, i32, i32 }
%sollang.struct.1392 = type { %sollang.enum.1566, i64, i64, i64, i64, i32, i32 }
%sollang.struct.1393 = type { %sollang.dynamic_int_array, i32 }
%sollang.struct.1394 = type { %sollang.enum.1567, i64, i64, i1, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array }
%sollang.struct.1395 = type { %sollang.dynamic_int_array, i32 }
%sollang.struct.1396 = type { %sollang.source_text, i64, i64, i8, i32, %sollang.struct.1391, %sollang.dynamic_int_array }
%sollang.struct.1397 = type { %sollang.dynamic_int_array, i32, i32, i32, i8, %sollang.dynamic_int_array }
%sollang.struct.1398 = type { i64, i64, i32 }
%sollang.struct.1399 = type { i32, i32, i32, i32 }
%sollang.struct.1400 = type { %sollang.enum.1569, i64, i64, i64 }
%sollang.struct.1401 = type { i64, i64 }
%sollang.struct.1402 = type { %sollang.source_text, i64, i64, i32, i32, i1, i1, i32, i32 }
%sollang.struct.1403 = type { %sollang.enum.1570, i64, i64, i64, i1, %sollang.enum.1571, i64 }
%sollang.struct.1404 = type { i8, i64 }
%sollang.struct.1405 = type { i32 }
%sollang.struct.1406 = type { i64, i64 }
%sollang.struct.1407 = type { i64 }
%sollang.struct.1408 = type { i64, i64, i64 }
%sollang.struct.1409 = type { i8 }
%sollang.struct.1410 = type { i8 }
%sollang.struct.1411 = type { i64, i64 }
%sollang.struct.1412 = type { i64 }
%sollang.struct.1413 = type { %sollang.struct.1406 }
%sollang.struct.1414 = type { %sollang.struct.1407 }
%sollang.struct.1415 = type { i64 }
%sollang.struct.1416 = type { %sollang.struct.27, %sollang.enum.1572, %sollang.struct.27 }
%sollang.struct.1417 = type { %sollang.dynamic_int_array, %sollang.struct.27, i64, %sollang.enum.1573 }
%sollang.struct.1418 = type { %sollang.struct.1417, %sollang.struct.1406, %sollang.struct.1406, i64 }
%sollang.struct.1419 = type { %sollang.enum.1574 }
%sollang.struct.1420 = type { %sollang.enum.1578, i64 }
%sollang.struct.1421 = type { i64, i64, i1 }
%sollang.struct.1422 = type { %sollang.struct.1421, %sollang.enum.1575, %sollang.enum.1576, %sollang.struct.1421 }
%sollang.struct.1423 = type { %sollang.source_text, %sollang.struct.1421, %sollang.enum.1577, %sollang.struct.1421, %sollang.struct.1421, %sollang.struct.1421 }
%sollang.struct.1424 = type { i1, i1, i1, i1, i1 }
%sollang.struct.1425 = type { %sollang.enum.1579, i64 }
%sollang.struct.1426 = type { i32, i32 }
%sollang.struct.1427 = type { %sollang.enum.1580 }
%sollang.struct.1428 = type { %sollang.enum.1582, i64 }
%sollang.struct.1429 = type { %sollang.int_slice }
%sollang.struct.1430 = type { i8 }
%sollang.struct.1431 = type { %sollang.struct.1410, %sollang.struct.1163 }
%sollang.struct.1432 = type { %sollang.struct.29, %sollang.dynamic_int_array, i64, i1 }
%sollang.struct.1433 = type { %sollang.struct.29, %sollang.dynamic_int_array, %sollang.enum.1583 }
%sollang.struct.1434 = type { %sollang.struct.30, %sollang.dynamic_int_array, i64 }
%sollang.struct.1435 = type { %sollang.struct.30, %sollang.dynamic_int_array, %sollang.enum.1583 }
%sollang.struct.1436 = type { %sollang.enum.1584, i32 }
%sollang.struct.1437 = type { i32, %sollang.enum.46 }
%sollang.struct.1438 = type { %sollang.dynamic_int_array, i8, i64, i64 }
%sollang.struct.1439 = type { %sollang.struct.34, %sollang.enum.38, i64, i64 }
%sollang.struct.1440 = type { %sollang.text, %sollang.text, i1 }
%sollang.struct.1441 = type { i64, i64 }
%sollang.struct.1442 = type { %sollang.struct.1443, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i1, i1 }
%sollang.struct.1443 = type { i32 }
%sollang.struct.1444 = type { i32 }
%sollang.struct.1445 = type { i64 }
%sollang.struct.1446 = type { i64, %sollang.struct.1445, i32, i32 }
%sollang.struct.1447 = type { i32, i32 }
%sollang.struct.1448 = type { i64 }
%sollang.struct.1449 = type { i64 }
%sollang.struct.1450 = type { i64 }
%sollang.enum.35 = type { i32, [0 x i64] }
%sollang.enum.38 = type { i32, [0 x i64] }
%sollang.enum.45 = type { i32, [0 x i64] }
%sollang.enum.46 = type { i32, [0 x i64] }
%sollang.enum.1451 = type { i32, [0 x i64] }
%sollang.enum.1452 = type { i32, [0 x i64] }
%sollang.enum.1453 = type { i32, [0 x i64] }
%sollang.enum.1454 = type { i32, [0 x i64] }
%sollang.enum.1455 = type { i32, [0 x i64] }
%sollang.enum.1456 = type { i32, [0 x i64] }
%sollang.enum.1457 = type { i32, [0 x i64] }
%sollang.enum.1458 = type { i32, [0 x i64] }
%sollang.enum.1459 = type { i32, [0 x i64] }
%sollang.enum.1460 = type { i32, [0 x i64] }
%sollang.enum.1461 = type { i32, [0 x i64] }
%sollang.enum.1462 = type { i32, [0 x i64] }
%sollang.enum.1463 = type { i32, [0 x i64] }
%sollang.enum.1464 = type { i32, [1 x i64] }
%sollang.enum.1465 = type { i32, [1 x i64] }
%sollang.enum.1466 = type { i32, [0 x i64] }
%sollang.enum.1467 = type { i32, [0 x i64] }
%sollang.enum.1468 = type { i32, [5 x i64] }
%sollang.enum.1469 = type { i32, [4 x i64] }
%sollang.enum.1470 = type { i32, [0 x i64] }
%sollang.enum.1471 = type { i32, [1 x i64] }
%sollang.enum.1472 = type { i32, [0 x i64] }
%sollang.enum.1473 = type { i32, [1 x i64] }
%sollang.enum.1474 = type { i32, [0 x i64] }
%sollang.enum.1475 = type { i32, [1 x i64] }
%sollang.enum.1476 = type { i32, [0 x i64] }
%sollang.enum.1477 = type { i32, [1 x i64] }
%sollang.enum.1478 = type { i32, [1 x i64] }
%sollang.enum.1479 = type { i32, [0 x i64] }
%sollang.enum.1480 = type { i32, [66 x i64] }
%sollang.enum.1481 = type { i32, [1 x i64] }
%sollang.enum.1482 = type { i32, [1 x i64] }
%sollang.enum.1483 = type { i32, [0 x i64] }
%sollang.enum.1484 = type { i32, [4 x i64] }
%sollang.enum.1485 = type { i32, [1 x i64] }
%sollang.enum.1486 = type { i32, [1 x i64] }
%sollang.enum.1487 = type { i32, [0 x i64] }
%sollang.enum.1488 = type { i32, [0 x i64] }
%sollang.enum.1489 = type { i32, [0 x i64] }
%sollang.enum.1490 = type { i32, [0 x i64] }
%sollang.enum.1491 = type { i32, [0 x i64] }
%sollang.enum.1492 = type { i32, [1 x i64] }
%sollang.enum.1493 = type { i32, [0 x i64] }
%sollang.enum.1494 = type { i32, [4 x i64] }
%sollang.enum.1495 = type { i32, [1 x i64] }
%sollang.enum.1496 = type { i32, [0 x i64] }
%sollang.enum.1497 = type { i32, [1 x i64] }
%sollang.enum.1498 = type { i32, [1 x i64] }
%sollang.enum.1499 = type { i32, [0 x i64] }
%sollang.enum.1500 = type { i32, [0 x i64] }
%sollang.enum.1501 = type { i32, [0 x i64] }
%sollang.enum.1502 = type { i32, [1 x i64] }
%sollang.enum.1503 = type { i32, [0 x i64] }
%sollang.enum.1504 = type { i32, [0 x i64] }
%sollang.enum.1505 = type { i32, [0 x i64] }
%sollang.enum.1506 = type { i32, [0 x i64] }
%sollang.enum.1507 = type { i32, [0 x i64] }
%sollang.enum.1508 = type { i32, [0 x i64] }
%sollang.enum.1509 = type { i32, [0 x i64] }
%sollang.enum.1510 = type { i32, [0 x i64] }
%sollang.enum.1511 = type { i32, [0 x i64] }
%sollang.enum.1512 = type { i32, [3 x i64] }
%sollang.enum.1513 = type { i32, [0 x i64] }
%sollang.enum.1514 = type { i32, [0 x i64] }
%sollang.enum.1515 = type { i32, [0 x i64] }
%sollang.enum.1516 = type { i32, [0 x i64] }
%sollang.enum.1517 = type { i32, [0 x i64] }
%sollang.enum.1518 = type { i32, [0 x i64] }
%sollang.enum.1519 = type { i32, [0 x i64] }
%sollang.enum.1520 = type { i32, [0 x i64] }
%sollang.enum.1521 = type { i32, [0 x i64] }
%sollang.enum.1522 = type { i32, [0 x i64] }
%sollang.enum.1523 = type { i32, [3 x i64] }
%sollang.enum.1524 = type { i32, [0 x i64] }
%sollang.enum.1525 = type { i32, [2 x i64] }
%sollang.enum.1526 = type { i32, [0 x i64] }
%sollang.enum.1527 = type { i32, [2 x i64] }
%sollang.enum.1528 = type { i32, [4 x i64] }
%sollang.enum.1529 = type { i32, [0 x i64] }
%sollang.enum.1530 = type { i32, [0 x i64] }
%sollang.enum.1531 = type { i32, [0 x i64] }
%sollang.enum.1532 = type { i32, [1 x i64] }
%sollang.enum.1533 = type { i32, [0 x i64] }
%sollang.enum.1534 = type { i32, [0 x i64] }
%sollang.enum.1535 = type { i32, [2 x i64] }
%sollang.enum.1536 = type { i32, [7 x i64] }
%sollang.enum.1537 = type { i32, [0 x i64] }
%sollang.enum.1538 = type { i32, [2 x i64] }
%sollang.enum.1539 = type { i32, [0 x i64] }
%sollang.enum.1540 = type { i32, [0 x i64] }
%sollang.enum.1541 = type { i32, [0 x i64] }
%sollang.enum.1542 = type { i32, [0 x i64] }
%sollang.enum.1543 = type { i32, [2 x i64] }
%sollang.enum.1544 = type { i32, [8 x i64] }
%sollang.enum.1545 = type { i32, [0 x i64] }
%sollang.enum.1546 = type { i32, [0 x i64] }
%sollang.enum.1547 = type { i32, [7 x i64] }
%sollang.enum.1548 = type { i32, [0 x i64] }
%sollang.enum.1549 = type { i32, [0 x i64] }
%sollang.enum.1550 = type { i32, [0 x i64] }
%sollang.enum.1551 = type { i32, [0 x i64] }
%sollang.enum.1552 = type { i32, [0 x i64] }
%sollang.enum.1553 = type { i32, [0 x i64] }
%sollang.enum.1554 = type { i32, [0 x i64] }
%sollang.enum.1555 = type { i32, [1 x i64] }
%sollang.enum.1556 = type { i32, [0 x i64] }
%sollang.enum.1557 = type { i32, [0 x i64] }
%sollang.enum.1558 = type { i32, [16 x i64] }
%sollang.enum.1559 = type { i32, [16 x i64] }
%sollang.enum.1560 = type { i32, [0 x i64] }
%sollang.enum.1561 = type { i32, [0 x i64] }
%sollang.enum.1562 = type { i32, [0 x i64] }
%sollang.enum.1563 = type { i32, [0 x i64] }
%sollang.enum.1564 = type { i32, [0 x i64] }
%sollang.enum.1565 = type { i32, [0 x i64] }
%sollang.enum.1566 = type { i32, [0 x i64] }
%sollang.enum.1567 = type { i32, [0 x i64] }
%sollang.enum.1568 = type { i32, [0 x i64] }
%sollang.enum.1569 = type { i32, [0 x i64] }
%sollang.enum.1570 = type { i32, [0 x i64] }
%sollang.enum.1571 = type { i32, [0 x i64] }
%sollang.enum.1572 = type { i32, [0 x i64] }
%sollang.enum.1573 = type { i32, [0 x i64] }
%sollang.enum.1574 = type { i32, [0 x i64] }
%sollang.enum.1575 = type { i32, [3 x i64] }
%sollang.enum.1576 = type { i32, [1 x i64] }
%sollang.enum.1577 = type { i32, [12 x i64] }
%sollang.enum.1578 = type { i32, [0 x i64] }
%sollang.enum.1579 = type { i32, [0 x i64] }
%sollang.enum.1580 = type { i32, [0 x i64] }
%sollang.enum.1581 = type { i32, [0 x i64] }
%sollang.enum.1582 = type { i32, [0 x i64] }
%sollang.enum.1583 = type { i32, [2 x i64] }
%sollang.enum.1584 = type { i32, [0 x i64] }
%sollang.enum.1585 = type { i32, [2 x i64] }
%sollang.enum.1586 = type { i32, [2 x i64] }
%sollang.enum.1587 = type { i32, [1 x i64] }
%sollang.enum.2157 = type { i32, [1 x i64] }
%sollang.enum.2158 = type { i32, [7 x i64] }
%sollang.enum.2182 = type { i32, [1 x i64] }
%sollang.enum.2183 = type { i32, [2 x i64] }
%sollang.enum.2192 = type { i32, [2 x i64] }
%sollang.enum.2195 = type { i32, [1 x i64] }
%sollang.enum.2196 = type { i32, [1 x i64] }
%sollang.enum.2197 = type { i32, [3 x i64] }
%sollang.enum.2198 = type { i32, [44 x i64] }
%sollang.enum.2199 = type { i32, [2 x i64] }
%sollang.enum.2200 = type { i32, [13 x i64] }
%sollang.enum.2201 = type { i32, [2 x i64] }
%sollang.enum.2203 = type { i32, [1 x i64] }
%sollang.enum.2206 = type { i32, [3 x i64] }
%sollang.enum.2207 = type { i32, [3 x i64] }
%sollang.enum.2208 = type { i32, [4 x i64] }
%sollang.enum.2209 = type { i32, [105 x i64] }
%sollang.enum.2210 = type { i32, [2 x i64] }
%sollang.enum.2211 = type { i32, [3 x i64] }
%sollang.enum.2212 = type { i32, [9 x i64] }
%sollang.enum.2213 = type { i32, [26 x i64] }
%sollang.enum.2214 = type { i32, [81 x i64] }
%sollang.enum.2215 = type { i32, [2 x i64] }
%sollang.enum.2218 = type { i32, [26 x i64] }
%sollang.enum.2219 = type { i32, [4 x i64] }
%sollang.enum.2220 = type { i32, [2 x i64] }
%sollang.enum.2221 = type { i32, [2 x i64] }
%sollang.enum.2222 = type { i32, [2 x i64] }
%sollang.enum.2223 = type { i32, [50 x i64] }
%sollang.enum.2224 = type { i32, [2 x i64] }
%sollang.enum.2225 = type { i32, [3 x i64] }
%sollang.enum.2226 = type { i32, [2 x i64] }
%sollang.enum.2227 = type { i32, [2 x i64] }
%sollang.enum.2229 = type { i32, [2 x i64] }
%sollang.enum.2230 = type { i32, [2 x i64] }
%sollang.enum.2232 = type { i32, [9 x i64] }
%sollang.enum.2233 = type { i32, [24 x i64] }
%sollang.enum.2234 = type { i32, [2 x i64] }
%sollang.enum.2235 = type { i32, [12 x i64] }
%sollang.enum.2236 = type { i32, [11 x i64] }
%sollang.enum.2237 = type { i32, [2 x i64] }
%sollang.enum.2238 = type { i32, [32 x i64] }
%sollang.enum.2239 = type { i32, [34 x i64] }
%sollang.enum.2240 = type { i32, [2 x i64] }
%sollang.enum.2241 = type { i32, [9 x i64] }
%sollang.enum.2242 = type { i32, [31 x i64] }
%sollang.enum.2243 = type { i32, [2 x i64] }
%sollang.enum.2244 = type { i32, [15 x i64] }
%sollang.enum.2245 = type { i32, [34 x i64] }
%sollang.enum.2246 = type { i32, [2 x i64] }
%sollang.enum.2247 = type { i32, [2 x i64] }
%sollang.enum.2248 = type { i32, [6 x i64] }
%sollang.enum.2249 = type { i32, [2 x i64] }
%sollang.enum.2250 = type { i32, [2 x i64] }
%sollang.enum.2251 = type { i32, [2 x i64] }
%sollang.enum.2253 = type { i32, [14 x i64] }
%sollang.enum.2254 = type { i32, [9 x i64] }
%sollang.enum.2255 = type { i32, [5 x i64] }
%sollang.enum.2256 = type { i32, [5 x i64] }
%sollang.enum.2257 = type { i32, [4 x i64] }
%sollang.enum.2258 = type { i32, [2 x i64] }
%sollang.enum.2260 = type { i32, [2 x i64] }
%sollang.enum.2261 = type { i32, [2 x i64] }
%sollang.enum.2262 = type { i32, [81 x i64] }
%sollang.enum.2263 = type { i32, [3 x i64] }
%sollang.enum.2264 = type { i32, [2 x i64] }
%sollang.enum.2265 = type { i32, [3 x i64] }
%sollang.enum.2266 = type { i32, [5 x i64] }
%sollang.enum.2267 = type { i32, [2 x i64] }
%sollang.enum.2268 = type { i32, [14 x i64] }
%sollang.enum.2269 = type { i32, [2 x i64] }
%sollang.enum.2270 = type { i32, [32 x i64] }
%sollang.enum.2271 = type { i32, [4 x i64] }
%sollang.enum.2272 = type { i32, [2 x i64] }
%sollang.enum.2274 = type { i32, [5 x i64] }
%sollang.enum.2275 = type { i32, [2 x i64] }
%sollang.enum.2276 = type { i32, [2 x i64] }
%sollang.enum.2277 = type { i32, [5 x i64] }
%sollang.enum.2278 = type { i32, [2 x i64] }
%sollang.enum.2279 = type { i32, [2 x i64] }
%sollang.enum.2280 = type { i32, [32 x i64] }
%sollang.enum.2281 = type { i32, [2 x i64] }
%sollang.enum.2282 = type { i32, [4 x i64] }
%sollang.enum.2284 = type { i32, [2 x i64] }
%sollang.enum.2285 = type { i32, [2 x i64] }
%sollang.enum.2286 = type { i32, [4 x i64] }
%sollang.enum.2287 = type { i32, [2 x i64] }
%sollang.enum.2288 = type { i32, [2 x i64] }
%sollang.enum.2289 = type { i32, [2 x i64] }
%sollang.enum.2290 = type { i32, [2 x i64] }
%sollang.enum.2291 = type { i32, [2 x i64] }
%sollang.enum.2292 = type { i32, [2 x i64] }
%sollang.enum.2293 = type { i32, [3 x i64] }
%sollang.enum.2294 = type { i32, [2 x i64] }
%sollang.enum.2296 = type { i32, [3 x i64] }
%sollang.enum.2297 = type { i32, [4 x i64] }
%sollang.enum.2298 = type { i32, [9 x i64] }
%sollang.enum.2299 = type { i32, [2 x i64] }
%sollang.enum.2300 = type { i32, [32 x i64] }
%sollang.enum.2301 = type { i32, [3 x i64] }
%sollang.enum.2303 = type { i32, [5 x i64] }
%sollang.enum.2304 = type { i32, [2 x i64] }
%sollang.enum.2305 = type { i32, [2 x i64] }
%sollang.enum.2306 = type { i32, [4 x i64] }
%sollang.enum.2307 = type { i32, [4 x i64] }
%sollang.enum.2308 = type { i32, [72 x i64] }
%sollang.enum.2309 = type { i32, [2 x i64] }
%sollang.enum.2310 = type { i32, [2 x i64] }
%sollang.enum.2311 = type { i32, [3 x i64] }
%sollang.enum.2312 = type { i32, [2 x i64] }
%sollang.enum.2313 = type { i32, [13 x i64] }
%sollang.enum.2314 = type { i32, [26 x i64] }
%sollang.enum.2315 = type { i32, [5 x i64] }
%sollang.enum.2316 = type { i32, [2 x i64] }
%sollang.enum.2319 = type { i32, [2 x i64] }
%sollang.enum.2320 = type { i32, [72 x i64] }
%sollang.enum.2321 = type { i32, [3 x i64] }
%sollang.enum.2322 = type { i32, [13 x i64] }
%sollang.enum.2323 = type { i32, [70 x i64] }
%sollang.enum.2324 = type { i32, [2 x i64] }
%sollang.enum.2325 = type { i32, [3 x i64] }
%sollang.enum.2326 = type { i32, [40 x i64] }
%sollang.enum.2330 = type { i32, [10 x i64] }
%sollang.enum.2331 = type { i32, [11 x i64] }
%sollang.enum.2332 = type { i32, [2 x i64] }
%sollang.enum.2333 = type { i32, [1 x i64] }
%sollang.enum.2334 = type { i32, [5 x i64] }
%sollang.enum.2335 = type { i32, [3 x i64] }
%sollang.enum.2336 = type { i32, [3 x i64] }
%sollang.enum.2337 = type { i32, [10 x i64] }
%sollang.enum.2338 = type { i32, [33 x i64] }
%sollang.enum.2339 = type { i32, [35 x i64] }
%sollang.enum.2340 = type { i32, [1 x i64] }
%sollang.enum.2342 = type { i32, [8 x i64] }
%sollang.enum.2343 = type { i32, [2 x i64] }
%sollang.enum.2344 = type { i32, [2 x i64] }
%sollang.enum.2345 = type { i32, [1 x i64] }
%sollang.enum.2346 = type { i32, [2 x i64] }
%sollang.enum.2349 = type { i32, [3 x i64] }
%sollang.enum.2351 = type { i32, [2 x i64] }
%sollang.enum.2352 = type { i32, [2 x i64] }
%sollang.enum.2353 = type { i32, [2 x i64] }
%sollang.enum.2354 = type { i32, [5 x i64] }
%sollang.enum.2355 = type { i32, [11 x i64] }
%sollang.enum.2356 = type { i32, [9 x i64] }
%sollang.enum.2358 = type { i32, [3 x i64] }
%sollang.enum.2359 = type { i32, [2 x i64] }
%sollang.enum.2360 = type { i32, [2 x i64] }
%sollang.enum.2361 = type { i32, [2 x i64] }
%sollang.enum.2362 = type { i32, [2 x i64] }
%sollang.enum.2363 = type { i32, [2 x i64] }
%sollang.enum.2364 = type { i32, [2 x i64] }
%sollang.enum.2365 = type { i32, [2 x i64] }
%sollang.enum.2366 = type { i32, [2 x i64] }
%sollang.enum.2367 = type { i32, [3 x i64] }
%sollang.enum.2368 = type { i32, [3 x i64] }
%sollang.enum.2369 = type { i32, [4 x i64] }
%sollang.enum.2370 = type { i32, [2 x i64] }
%sollang.enum.2371 = type { i32, [4 x i64] }
%sollang.enum.2372 = type { i32, [4 x i64] }
%sollang.enum.2373 = type { i32, [2 x i64] }
%sollang.enum.2374 = type { i32, [8 x i64] }
%sollang.enum.2375 = type { i32, [2 x i64] }
%sollang.enum.2376 = type { i32, [4 x i64] }
%sollang.enum.2377 = type { i32, [3 x i64] }
%sollang.enum.2378 = type { i32, [2 x i64] }
%sollang.enum.2379 = type { i32, [2 x i64] }
%sollang.enum.2380 = type { i32, [5 x i64] }
%sollang.enum.2381 = type { i32, [10 x i64] }
%sollang.enum.2382 = type { i32, [10 x i64] }
%sollang.enum.2383 = type { i32, [11 x i64] }
%sollang.enum.2384 = type { i32, [11 x i64] }
%sollang.enum.2385 = type { i32, [7 x i64] }
%sollang.enum.2386 = type { i32, [8 x i64] }
%sollang.enum.2387 = type { i32, [7 x i64] }
%sollang.enum.2388 = type { i32, [8 x i64] }
%sollang.enum.2389 = type { i32, [2 x i64] }
%sollang.enum.2390 = type { i32, [7 x i64] }
%sollang.enum.2391 = type { i32, [7 x i64] }
%sollang.enum.2392 = type { i32, [3 x i64] }
%sollang.enum.2393 = type { i32, [3 x i64] }
%sollang.enum.2394 = type { i32, [2 x i64] }
%sollang.enum.2395 = type { i32, [2 x i64] }
%sollang.enum.2397 = type { i32, [2 x i64] }
%sollang.enum.2398 = type { i32, [4 x i64] }
%sollang.enum.2399 = type { i32, [3 x i64] }
%sollang.enum.2400 = type { i32, [3 x i64] }
%sollang.enum.2401 = type { i32, [13 x i64] }
%sollang.enum.2402 = type { i32, [12 x i64] }
%sollang.enum.2403 = type { i32, [4 x i64] }
%sollang.enum.2404 = type { i32, [2 x i64] }
%sollang.enum.2405 = type { i32, [2 x i64] }
%sollang.enum.2407 = type { i32, [2 x i64] }
%sollang.enum.2408 = type { i32, [5 x i64] }
%sollang.enum.2409 = type { i32, [3 x i64] }
%sollang.enum.2410 = type { i32, [15 x i64] }
%sollang.enum.2411 = type { i32, [3 x i64] }
%sollang.enum.2412 = type { i32, [2 x i64] }
%sollang.enum.2413 = type { i32, [3 x i64] }
%sollang.enum.2418 = type { i32, [2 x i64] }
%sollang.enum.2419 = type { i32, [3 x i64] }
%sollang.enum.2420 = type { i32, [3 x i64] }
%sollang.enum.2421 = type { i32, [15 x i64] }
%sollang.enum.2422 = type { i32, [25 x i64] }
%sollang.enum.2423 = type { i32, [7 x i64] }
%sollang.enum.2424 = type { i32, [5 x i64] }
%sollang.enum.2425 = type { i32, [9 x i64] }
%sollang.enum.2426 = type { i32, [31 x i64] }
%sollang.enum.2427 = type { i32, [3 x i64] }
%sollang.enum.2428 = type { i32, [8 x i64] }
%sollang.enum.2429 = type { i32, [2 x i64] }
%sollang.enum.2430 = type { i32, [12 x i64] }
%sollang.enum.2431 = type { i32, [6 x i64] }
%sollang.enum.2432 = type { i32, [2 x i64] }
%sollang.enum.2433 = type { i32, [9 x i64] }
%sollang.enum.2434 = type { i32, [6 x i64] }
%sollang.enum.2435 = type { i32, [3 x i64] }
%sollang.enum.2436 = type { i32, [26 x i64] }
%sollang.enum.2437 = type { i32, [4 x i64] }
%sollang.enum.2438 = type { i32, [5 x i64] }
%sollang.enum.2439 = type { i32, [8 x i64] }
%sollang.enum.2440 = type { i32, [40 x i64] }
%sollang.enum.2441 = type { i32, [9 x i64] }
%sollang.enum.2442 = type { i32, [3 x i64] }
%sollang.enum.2446 = type { i32, [2 x i64] }
%sollang.enum.2447 = type { i32, [2 x i64] }
%sollang.enum.2448 = type { i32, [9 x i64] }
%sollang.enum.2449 = type { i32, [21 x i64] }
%sollang.enum.2450 = type { i32, [2 x i64] }
%sollang.enum.2451 = type { i32, [2 x i64] }
%sollang.enum.2452 = type { i32, [4 x i64] }
%sollang.enum.2453 = type { i32, [3 x i64] }
%sollang.enum.2454 = type { i32, [9 x i64] }
%sollang.enum.2455 = type { i32, [2 x i64] }
%sollang.enum.2456 = type { i32, [5 x i64] }
%sollang.enum.2457 = type { i32, [2 x i64] }
%sollang.enum.2458 = type { i32, [14 x i64] }
%sollang.enum.2460 = type { i32, [11 x i64] }
%sollang.enum.2461 = type { i32, [16 x i64] }
%sollang.enum.2462 = type { i32, [7 x i64] }
%sollang.enum.2465 = type { i32, [7 x i64] }
%sollang.enum.2466 = type { i32, [4 x i64] }
%sollang.enum.2467 = type { i32, [6 x i64] }
%sollang.enum.2468 = type { i32, [7 x i64] }
%sollang.enum.2469 = type { i32, [6 x i64] }
%sollang.enum.2470 = type { i32, [5 x i64] }
%sollang.enum.2471 = type { i32, [2 x i64] }
%sollang.enum.2472 = type { i32, [4 x i64] }
%sollang.enum.2473 = type { i32, [10 x i64] }
%sollang.enum.2474 = type { i32, [131 x i64] }
%sollang.enum.2475 = type { i32, [2 x i64] }
%sollang.enum.2476 = type { i32, [16 x i64] }
%sollang.enum.2477 = type { i32, [7 x i64] }
%sollang.enum.2478 = type { i32, [10 x i64] }
%sollang.enum.2479 = type { i32, [5 x i64] }
%sollang.enum.2481 = type { i32, [2 x i64] }
%sollang.enum.2482 = type { i32, [17 x i64] }
%sollang.enum.2484 = type { i32, [10 x i64] }
%sollang.enum.2485 = type { i32, [5 x i64] }
%sollang.enum.2486 = type { i32, [3 x i64] }
%sollang.enum.2487 = type { i32, [8 x i64] }
%sollang.enum.2488 = type { i32, [2 x i64] }
%sollang.enum.2489 = type { i32, [4 x i64] }
%sollang.enum.2490 = type { i32, [2 x i64] }
%sollang.enum.2491 = type { i32, [9 x i64] }
%sollang.enum.2492 = type { i32, [3 x i64] }
%sollang.enum.2493 = type { i32, [7 x i64] }
%sollang.enum.2494 = type { i32, [11 x i64] }
%sollang.enum.2495 = type { i32, [7 x i64] }
%sollang.enum.2499 = type { i32, [6 x i64] }
%sollang.enum.2501 = type { i32, [11 x i64] }
%sollang.enum.2502 = type { i32, [2 x i64] }
%sollang.enum.2503 = type { i32, [18 x i64] }
%sollang.enum.2504 = type { i32, [149 x i64] }
%sollang.enum.2506 = type { i32, [3 x i64] }
%sollang.enum.2507 = type { i32, [2 x i64] }
%sollang.enum.2508 = type { i32, [2 x i64] }
%sollang.enum.2510 = type { i32, [12 x i64] }
%sollang.enum.2511 = type { i32, [9 x i64] }
%sollang.enum.2512 = type { i32, [5 x i64] }
%sollang.enum.2513 = type { i32, [5 x i64] }
%sollang.enum.2514 = type { i32, [6 x i64] }
%sollang.enum.2515 = type { i32, [6 x i64] }
%sollang.enum.2516 = type { i32, [2 x i64] }
%sollang.enum.2517 = type { i32, [14 x i64] }
%sollang.enum.2518 = type { i32, [6 x i64] }
%sollang.enum.2519 = type { i32, [6 x i64] }
%sollang.enum.2520 = type { i32, [4 x i64] }
%sollang.enum.2521 = type { i32, [5 x i64] }
%sollang.enum.2522 = type { i32, [4 x i64] }
%sollang.enum.2523 = type { i32, [21 x i64] }
%sollang.enum.2524 = type { i32, [4 x i64] }
%sollang.enum.2525 = type { i32, [5 x i64] }
%sollang.enum.2526 = type { i32, [2 x i64] }
%sollang.enum.2528 = type { i32, [3 x i64] }
%sollang.enum.2529 = type { i32, [4 x i64] }
%sollang.enum.2530 = type { i32, [2 x i64] }
%sollang.enum.2531 = type { i32, [6 x i64] }
%sollang.enum.2532 = type { i32, [5 x i64] }
%sollang.enum.2533 = type { i32, [5 x i64] }
%sollang.enum.2536 = type { i32, [16 x i64] }
%sollang.enum.2537 = type { i32, [7 x i64] }
%sollang.enum.2538 = type { i32, [6 x i64] }
%sollang.enum.2539 = type { i32, [4 x i64] }
%sollang.enum.2540 = type { i32, [5 x i64] }
%sollang.enum.2541 = type { i32, [2 x i64] }
%sollang.enum.2542 = type { i32, [2 x i64] }
%sollang.enum.2543 = type { i32, [4 x i64] }
%sollang.enum.2545 = type { i32, [9 x i64] }
%sollang.enum.2546 = type { i32, [4 x i64] }
%sollang.enum.2547 = type { i32, [3 x i64] }
%sollang.enum.2548 = type { i32, [17 x i64] }
%sollang.enum.2549 = type { i32, [2 x i64] }
%sollang.enum.2550 = type { i32, [3 x i64] }
%sollang.enum.2551 = type { i32, [12 x i64] }
%sollang.enum.2552 = type { i32, [3 x i64] }
%sollang.enum.2553 = type { i32, [4 x i64] }
%sollang.enum.2554 = type { i32, [12 x i64] }
%sollang.enum.2555 = type { i32, [4 x i64] }
%sollang.enum.2556 = type { i32, [3 x i64] }
%sollang.enum.2557 = type { i32, [3 x i64] }
%sollang.enum.2558 = type { i32, [4 x i64] }
%sollang.enum.2559 = type { i32, [2 x i64] }
%sollang.enum.2560 = type { i32, [3 x i64] }
%sollang.enum.2562 = type { i32, [6 x i64] }
%sollang.enum.2563 = type { i32, [3 x i64] }
%sollang.enum.2564 = type { i32, [2 x i64] }
%sollang.enum.2565 = type { i32, [2 x i64] }
%sollang.enum.2566 = type { i32, [2 x i64] }
%sollang.enum.2567 = type { i32, [3 x i64] }
%sollang.enum.2568 = type { i32, [2 x i64] }
%sollang.enum.2569 = type { i32, [2 x i64] }
%sollang.enum.2570 = type { i32, [12 x i64] }
%sollang.enum.2571 = type { i32, [6 x i64] }
%sollang.enum.2572 = type { i32, [3 x i64] }
%sollang.enum.2573 = type { i32, [2 x i64] }
%sollang.enum.2574 = type { i32, [8 x i64] }
%sollang.enum.2576 = type { i32, [2 x i64] }
%sollang.enum.2577 = type { i32, [4 x i64] }
%sollang.enum.2580 = type { i32, [4 x i64] }
%sollang.enum.2581 = type { i32, [4 x i64] }
%sollang.enum.2582 = type { i32, [7 x i64] }
%sollang.enum.2583 = type { i32, [4 x i64] }
%sollang.enum.2585 = type { i32, [9 x i64] }
%sollang.enum.2586 = type { i32, [2 x i64] }
%sollang.enum.2587 = type { i32, [4 x i64] }
%sollang.enum.2588 = type { i32, [1 x i64] }
%sollang.enum.2589 = type { i32, [1 x i64] }
%sollang.enum.2590 = type { i32, [2 x i64] }
%sollang.enum.2591 = type { i32, [2 x i64] }
%sollang.enum.2592 = type { i32, [2 x i64] }
%sollang.enum.2593 = type { i32, [6 x i64] }
%sollang.enum.2594 = type { i32, [1 x i64] }
%sollang.enum.2595 = type { i32, [1 x i64] }
%sollang.enum.2596 = type { i32, [1 x i64] }
%sollang.enum.2597 = type { i32, [1 x i64] }
%sollang.enum.2598 = type { i32, [11 x i64] }
%sollang.enum.2599 = type { i32, [29 x i64] }
%sollang.enum.2600 = type { i32, [12 x i64] }
%sollang.enum.2601 = type { i32, [2 x i64] }
%sollang.enum.2602 = type { i32, [3 x i64] }
%sollang.enum.2603 = type { i32, [2 x i64] }
%sollang.enum.2605 = type { i32, [2 x i64] }
%sollang.enum.2606 = type { i32, [3 x i64] }
%sollang.enum.2607 = type { i32, [2 x i64] }
%sollang.enum.2608 = type { i32, [1 x i64] }
%sollang.enum.2609 = type { i32, [1 x i64] }
%sollang.enum.2612 = type { i32, [2 x i64] }
%sollang.enum.2613 = type { i32, [2 x i64] }
%sollang.enum.2614 = type { i32, [2 x i64] }
%sollang.enum.2617 = type { i32, [2 x i64] }
%sollang.enum.2618 = type { i32, [7 x i64] }
%sollang.enum.2619 = type { i32, [4 x i64] }
%sollang.enum.2620 = type { i32, [2 x i64] }
%sollang.enum.2621 = type { i32, [2 x i64] }
%sollang.enum.2623 = type { i32, [3 x i64] }
%sollang.enum.2626 = type { i32, [6 x i64] }
%sollang.enum.2627 = type { i32, [2 x i64] }
%sollang.enum.2628 = type { i32, [3 x i64] }
%sollang.enum.2629 = type { i32, [8 x i64] }
%sollang.enum.2630 = type { i32, [2 x i64] }
%sollang.enum.2631 = type { i32, [3 x i64] }
%sollang.enum.2632 = type { i32, [1 x i64] }
%sollang.enum.2633 = type { i32, [2 x i64] }
%sollang.enum.2634 = type { i32, [2 x i64] }
%sollang.enum.2636 = type { i32, [2 x i64] }
%sollang.enum.2637 = type { i32, [4 x i64] }
%sollang.enum.2638 = type { i32, [3 x i64] }
%sollang.enum.2639 = type { i32, [18 x i64] }
%sollang.enum.2640 = type { i32, [3 x i64] }
%sollang.enum.2641 = type { i32, [16 x i64] }
%sollang.enum.2642 = type { i32, [2 x i64] }
%sollang.enum.2643 = type { i32, [2 x i64] }
%sollang.enum.2644 = type { i32, [2 x i64] }
%sollang.enum.2645 = type { i32, [2 x i64] }
%sollang.enum.2647 = type { i32, [1 x i64] }
%sollang.enum.2648 = type { i32, [2 x i64] }
%sollang.enum.2649 = type { i32, [5 x i64] }
%sollang.enum.2650 = type { i32, [2 x i64] }
%sollang.enum.2651 = type { i32, [3 x i64] }
%sollang.enum.2654 = type { i32, [2 x i64] }
%sollang.enum.2655 = type { i32, [9 x i64] }
%sollang.enum.2656 = type { i32, [7 x i64] }
%sollang.enum.2657 = type { i32, [1 x i64] }
%sollang.enum.2659 = type { i32, [1 x i64] }
%sollang.enum.2660 = type { i32, [1 x i64] }
%sollang.enum.2662 = type { i32, [1 x i64] }

@sollang_file_writer = internal global ptr null
@sollang_file_reader = internal global ptr null
@sollang_argument_count_value = internal global i64 0
@sollang_argument_records = internal global ptr null
@sollang_environment_allocations = internal global ptr null
@sollang_environment_empty = internal constant [1 x i8] zeroinitializer, align 1
@sollang_stdout_buffer = internal global [1048576 x i8] zeroinitializer, align 16
@sollang_stdout_buffer_count = internal global i64 0
@sollang_stdout_line_buffered = internal global i1 false
@_fltused = global i32 0
@sollang_random_state = internal global i64 88172645463393265
@sollang_writer_buffer = internal global [8192 x i64] zeroinitializer, align 8
@sollang_writer_buffer_count = internal global i64 0
@.slg.native.library.name.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F66697874757265 = private unnamed_addr constant [38 x i8] c"artifacts/com-interop/com_fixture.dll\00", align 1
@sollang_native_library_x6172746966616374732F636F6D2D696E7465726F702F636F6D5F66697874757265 = internal global ptr null, align 8
@.slg.native.symbol.name.x70726F62652E7265666572656E636573 = private unnamed_addr constant [28 x i8] c"com_fixture_live_references\00", align 1
@sollang_native_function_x70726F62652E7265666572656E636573 = internal global ptr null, align 8
@.slg.com.iid.class_factory = private unnamed_addr constant [16 x i8] c"\01\00\00\00\00\00\00\00\C0\00\00\00\00\00\00F", align 4
@.slg.com.clsid.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F666978747572650038413930453241352D374132442D344532412D393841302D364235433241313243353031 = private unnamed_addr constant [16 x i8] c"\A5\E2\90\8A-z*N\98\A0k\5C*\12\C5\01", align 4
@.slg.com.iid.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F666978747572650038413930453241352D374132442D344532412D393841302D3642354332413132433530310042323134413936442D353843462D343331312D413239422D364446383530383031433734 = private unnamed_addr constant [16 x i8] c"m\A9\14\B2\CFX\11C\A2\9Bm\F8P\80\1Ct", align 4
@.slg.com.iid.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F666978747572650038413930453241352D374132442D344532412D393841302D3642354332413132433530310034433130413437422D373235442D343144332D423541362D373044363744334245423131 = private unnamed_addr constant [16 x i8] c"{\A4\10L]r\D3A\B5\A6p\D6};\EB\11", align 4
@.slg.com.iid.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F666978747572650038413930453241352D374132442D344532412D393841302D3642354332413132433530310034433645453034462D424143412D344445372D393145452D454135364343393744313041 = private unnamed_addr constant [16 x i8] c"O\E0nL\CA\BA\E7M\91\EE\EAV\CC\97\D1\0A", align 4
@.slg.com.dll_get_class_object_name = private unnamed_addr constant [18 x i8] c"DllGetClassObject\00", align 1
@.slg.com.server.name.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F66697874757265 = private unnamed_addr constant [38 x i8] c"artifacts/com-interop/com_fixture.dll\00", align 1
@.slg.com.server.handle.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F66697874757265 = internal global ptr null, align 8
@.slg.com.server.get_class_object.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F66697874757265 = internal global ptr null, align 8
@.slg.com.factory.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F666978747572650038413930453241352D374132442D344532412D393841302D364235433241313243353031 = internal global ptr null, align 8

declare dllimport ptr @GetStdHandle(i32)
declare dllimport i32 @GetConsoleMode(ptr, ptr)
declare dllimport i32 @WriteConsoleW(ptr, ptr, i32, ptr, ptr)
declare dllimport i32 @WriteFile(ptr, ptr, i32, ptr, ptr)
declare dllimport i32 @ReadFile(ptr, ptr, i32, ptr, ptr)
declare dllimport i32 @GetOverlappedResult(ptr, ptr, ptr, i32)
declare dllimport ptr @CreateFileA(ptr, i32, i32, ptr, i32, i32, ptr)
declare dllimport ptr @CreateFileW(ptr, i32, i32, ptr, i32, i32, ptr)
declare dllimport i32 @CloseHandle(ptr)
declare dllimport ptr @GetCurrentProcess()
declare dllimport i32 @DuplicateHandle(ptr, ptr, ptr, ptr, i32, i32, i32)
declare dllimport i32 @SetFilePointerEx(ptr, i64, ptr, i32)
declare dllimport i32 @GetFileSizeEx(ptr, ptr)
declare dllimport i32 @SetEndOfFile(ptr)
declare dllimport ptr @CreateFileMappingA(ptr, ptr, i32, i32, i32, ptr)
declare dllimport ptr @MapViewOfFile(ptr, i32, i32, i32, i64)
declare dllimport i32 @UnmapViewOfFile(ptr)
declare dllimport i32 @FlushViewOfFile(ptr, i64)
declare dllimport i32 @FlushFileBuffers(ptr)
declare dllimport i32 @MoveFileExA(ptr, ptr, i32)
declare dllimport i32 @MoveFileExW(ptr, ptr, i32)
declare dllimport i32 @DeleteFileA(ptr)
declare dllimport i32 @DeleteFileW(ptr)
declare dllimport ptr @GetProcessHeap()
declare dllimport ptr @HeapAlloc(ptr, i32, i64)
declare dllimport i32 @HeapFree(ptr, i32, ptr)
declare dllimport i64 @GetTickCount64()
declare dllimport void @GetSystemTimePreciseAsFileTime(ptr)
declare dllimport void @Sleep(i32)
declare dllimport ptr @GetCommandLineW()
declare dllimport ptr @CommandLineToArgvW(ptr, ptr)
declare dllimport i32 @WideCharToMultiByte(i32, i32, ptr, i32, ptr, i32, ptr, ptr)
declare dllimport ptr @LocalFree(ptr)
declare dllimport i32 @MultiByteToWideChar(i32, i32, ptr, i32, ptr, i32)
declare dllimport i32 @GetEnvironmentVariableW(ptr, ptr, i32)
declare dllimport i32 @GetLastError()
declare dllimport void @SetLastError(i32)
define internal i32 @sollang_windows_utf8_path(ptr %data, i64 %length, ptr %wide, i32 %capacity) #0 {
entry:
  %positive = icmp ugt i64 %length, 0
  %fits_i32 = icmp ule i64 %length, 2147483647
  %length_valid = and i1 %positive, %fits_i32
  br i1 %length_valid, label %check, label %failure
check:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %done = icmp eq i64 %index, %length
  br i1 %done, label %convert, label %inspect
inspect:
  %byte_ptr = getelementptr i8, ptr %data, i64 %index
  %byte = load i8, ptr %byte_ptr, align 1
  %nul = icmp eq i8 %byte, 0
  br i1 %nul, label %failure, label %advance
advance:
  %next = add i64 %index, 1
  br label %check
convert:
  %length32 = trunc i64 %length to i32
  %room = sub i32 %capacity, 1
  %converted = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %length32, ptr %wide, i32 %room)
  %converted_ok = icmp sgt i32 %converted, 0
  br i1 %converted_ok, label %terminate, label %failure
terminate:
  %zero = getelementptr i16, ptr %wide, i32 %converted
  store i16 0, ptr %zero, align 2
  ret i32 1
failure:
  ret i32 0
}
declare dllimport ptr @LoadLibraryA(ptr)
declare dllimport ptr @GetProcAddress(ptr, ptr)
declare dllimport i32 @FreeLibrary(ptr)
declare dllimport i32 @CoInitializeEx(ptr, i32)
declare dllimport void @CoUninitialize()
declare dllimport i32 @CoCreateInstance(ptr, ptr, i32, ptr, ptr)

declare void @llvm.trap()
declare i64 @llvm.ctpop.i64(i64)
declare i16 @llvm.cttz.i16(i16, i1 immarg)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg)
declare void @llvm.memcpy.p0.p0.i64(ptr nocapture writeonly, ptr nocapture readonly, i64, i1 immarg)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture)

define internal void @sollang_drop_1448(%sollang.struct.1448 %value) #0 {
entry:
  %drop_com_handle_value0 = extractvalue %sollang.struct.1448 %value, 0
  %drop_com_handle1 = inttoptr i64 %drop_com_handle_value0 to ptr
  %com_release_vtable2 = load ptr, ptr %drop_com_handle1, align 8
  %com_release_slot3 = getelementptr ptr, ptr %com_release_vtable2, i64 2
  %com_release_target4 = load ptr, ptr %com_release_slot3, align 8
  %com_reference_count5 = call i32 %com_release_target4(ptr %drop_com_handle1)
  ret void
}

define internal void @sollang_drop_1449(%sollang.struct.1449 %value) #0 {
entry:
  %drop_com_handle_value6 = extractvalue %sollang.struct.1449 %value, 0
  %drop_com_handle7 = inttoptr i64 %drop_com_handle_value6 to ptr
  %com_release_vtable8 = load ptr, ptr %drop_com_handle7, align 8
  %com_release_slot9 = getelementptr ptr, ptr %com_release_vtable8, i64 2
  %com_release_target10 = load ptr, ptr %com_release_slot9, align 8
  %com_reference_count11 = call i32 %com_release_target10(ptr %drop_com_handle7)
  ret void
}

define internal void @sollang_drop_1450(%sollang.struct.1450 %value) #0 {
entry:
  %drop_com_handle_value12 = extractvalue %sollang.struct.1450 %value, 0
  %drop_com_handle13 = inttoptr i64 %drop_com_handle_value12 to ptr
  %com_release_vtable14 = load ptr, ptr %drop_com_handle13, align 8
  %com_release_slot15 = getelementptr ptr, ptr %com_release_vtable14, i64 2
  %com_release_target16 = load ptr, ptr %com_release_slot15, align 8
  %com_reference_count17 = call i32 %com_release_target16(ptr %drop_com_handle13)
  ret void
}

define internal void @sollang_drop_2657(%sollang.enum.2657 %value) #0 {
entry:
  %drop_enum_tag18 = extractvalue %sollang.enum.2657 %value, 0
  switch i32 %drop_enum_tag18, label %bb_drop_enum_end0 [ i32 0, label %bb_drop_enum_variant1 ]
bb_drop_enum_variant1:
  %drop_enum_slot19 = alloca %sollang.enum.2657, align 8
  store %sollang.enum.2657 %value, ptr %drop_enum_slot19, align 8
  %drop_enum_payload_addr20 = getelementptr inbounds %sollang.enum.2657, ptr %drop_enum_slot19, i32 0, i32 1
  %drop_enum_payload21 = load %sollang.struct.1448, ptr %drop_enum_payload_addr20, align 8
  call void @sollang_drop_1448(%sollang.struct.1448 %drop_enum_payload21)
  br label %bb_drop_enum_end0
bb_drop_enum_end0:
  ret void
}

define internal void @sollang_drop_2660(%sollang.enum.2660 %value) #0 {
entry:
  %drop_enum_tag22 = extractvalue %sollang.enum.2660 %value, 0
  switch i32 %drop_enum_tag22, label %bb_drop_enum_end2 [ i32 0, label %bb_drop_enum_variant3 ]
bb_drop_enum_variant3:
  %drop_enum_slot23 = alloca %sollang.enum.2660, align 8
  store %sollang.enum.2660 %value, ptr %drop_enum_slot23, align 8
  %drop_enum_payload_addr24 = getelementptr inbounds %sollang.enum.2660, ptr %drop_enum_slot23, i32 0, i32 1
  %drop_enum_payload25 = load %sollang.struct.1449, ptr %drop_enum_payload_addr24, align 8
  call void @sollang_drop_1449(%sollang.struct.1449 %drop_enum_payload25)
  br label %bb_drop_enum_end2
bb_drop_enum_end2:
  ret void
}

define internal void @sollang_drop_2662(%sollang.enum.2662 %value) #0 {
entry:
  %drop_enum_tag26 = extractvalue %sollang.enum.2662 %value, 0
  switch i32 %drop_enum_tag26, label %bb_drop_enum_end4 [ i32 0, label %bb_drop_enum_variant5 ]
bb_drop_enum_variant5:
  %drop_enum_slot27 = alloca %sollang.enum.2662, align 8
  store %sollang.enum.2662 %value, ptr %drop_enum_slot27, align 8
  %drop_enum_payload_addr28 = getelementptr inbounds %sollang.enum.2662, ptr %drop_enum_slot27, i32 0, i32 1
  %drop_enum_payload29 = load %sollang.struct.1450, ptr %drop_enum_payload_addr28, align 8
  call void @sollang_drop_1450(%sollang.struct.1450 %drop_enum_payload29)
  br label %bb_drop_enum_end4
bb_drop_enum_end4:
  ret void
}

@.slg.str.suffix.0 = private unnamed_addr constant [33 x i8] c"main:bb_native_library_load_fail1", align 1
@.slg.str.suffix.1 = private unnamed_addr constant [32 x i8] c"main:bb_native_symbol_load_fail3", align 1
@.slg.str.suffix.2 = private unnamed_addr constant [28 x i8] c"main:bb_com_initialize_fail5", align 1
@.slg.str.suffix.3 = private unnamed_addr constant [29 x i8] c"main:bb_com_server_load_fail7", align 1
@.slg.str.suffix.4 = private unnamed_addr constant [38 x i8] c"main:bb_com_dll_get_class_object_fail9", align 1
@.slg.str.suffix.5 = private unnamed_addr constant [26 x i8] c"main:bb_com_factory_fail11", align 1
@.slg.str.suffix.6 = private unnamed_addr constant [13 x i8] c"COM result = ", align 1
@.slg.str.suffix.7 = private unnamed_addr constant [1 x i8] c"\0A", align 1
@.slg.str.suffix.8 = private unnamed_addr constant [20 x i8] c"COM method failed = ", align 1
@.slg.str.suffix.9 = private unnamed_addr constant [1 x i8] c"\0A", align 1
@.slg.str.suffix.10 = private unnamed_addr constant [19 x i8] c"COM query result = ", align 1
@.slg.str.suffix.11 = private unnamed_addr constant [1 x i8] c"\0A", align 1
@.slg.str.suffix.12 = private unnamed_addr constant [28 x i8] c"COM queried method failed = ", align 1
@.slg.str.suffix.13 = private unnamed_addr constant [1 x i8] c"\0A", align 1
@.slg.str.suffix.14 = private unnamed_addr constant [19 x i8] c"COM query failed = ", align 1
@.slg.str.suffix.15 = private unnamed_addr constant [1 x i8] c"\0A", align 1
@.slg.str.suffix.16 = private unnamed_addr constant [24 x i8] c"Unexpected COM interface", align 1
@.slg.str.suffix.17 = private unnamed_addr constant [1 x i8] c"\0A", align 1
@.slg.str.suffix.18 = private unnamed_addr constant [20 x i8] c"COM query failure = ", align 1
@.slg.str.suffix.19 = private unnamed_addr constant [1 x i8] c"\0A", align 1
@.slg.str.suffix.20 = private unnamed_addr constant [19 x i8] c"COM clone result = ", align 1
@.slg.str.suffix.21 = private unnamed_addr constant [1 x i8] c"\0A", align 1
@.slg.str.suffix.22 = private unnamed_addr constant [26 x i8] c"COM clone method failed = ", align 1
@.slg.str.suffix.23 = private unnamed_addr constant [1 x i8] c"\0A", align 1
@.slg.str.suffix.24 = private unnamed_addr constant [24 x i8] c"COM activation failed = ", align 1
@.slg.str.suffix.25 = private unnamed_addr constant [1 x i8] c"\0A", align 1
@.slg.str.suffix.26 = private unnamed_addr constant [29 x i8] c"COM references after scope = ", align 1
@.slg.str.suffix.27 = private unnamed_addr constant [1 x i8] c"\0A", align 1
define dso_local void @__chkstk() naked nounwind {
entry:
  call void asm sideeffect inteldialect "push rcx\0Apush rax\0Alea rcx, [rsp + 24]\0Acmp rax, 4096\0Ajb .Lsollang_chkstk_tail\0A.Lsollang_chkstk_loop:\0Asub rcx, 4096\0Atest byte ptr [rcx], 0\0Asub rax, 4096\0Acmp rax, 4096\0Ajae .Lsollang_chkstk_loop\0A.Lsollang_chkstk_tail:\0Asub rcx, rax\0Atest byte ptr [rcx], 0\0Apop rax\0Apop rcx\0Aret", "~{memory},~{flags}"()
  unreachable
}

define internal i32 @sollang_write_stream_chunk(ptr %handle, ptr %data, i32 %len, ptr %written, i1 %is_console) #0 {
entry:
  %empty = icmp eq i32 %len, 0
  br i1 %empty, label %success_empty, label %classify

success_empty:
  store i32 0, ptr %written, align 4
  ret i32 1

classify:
  br i1 %is_console, label %console_prepare, label %redirected

redirected:
  br label %redirected_write

redirected_write:
  %redirected_offset = phi i32 [ 0, %redirected ], [ %redirected_next, %redirected_advance ]
  %redirected_remaining = sub i32 %len, %redirected_offset
  %redirected_offset64 = zext i32 %redirected_offset to i64
  %redirected_data = getelementptr i8, ptr %data, i64 %redirected_offset64
  store i32 0, ptr %written, align 4
  %redirected_ok = call i32 @WriteFile(ptr %handle, ptr %redirected_data, i32 %redirected_remaining, ptr %written, ptr null)
  %redirected_count = load i32, ptr %written, align 4
  %redirected_succeeded = icmp ne i32 %redirected_ok, 0
  %redirected_progress = icmp ugt i32 %redirected_count, 0
  %redirected_bounded = icmp ule i32 %redirected_count, %redirected_remaining
  %redirected_valid0 = and i1 %redirected_succeeded, %redirected_progress
  %redirected_valid = and i1 %redirected_valid0, %redirected_bounded
  br i1 %redirected_valid, label %redirected_advance, label %write_failed

redirected_advance:
  %redirected_next = add i32 %redirected_offset, %redirected_count
  %redirected_complete = icmp eq i32 %redirected_next, %len
  br i1 %redirected_complete, label %write_succeeded, label %redirected_write

console_prepare:
  %wide_chars = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %len, ptr null, i32 0)
  %valid_utf8 = icmp sgt i32 %wide_chars, 0
  br i1 %valid_utf8, label %allocate, label %conversion_failed

allocate:
  %wide_bytes32 = shl i32 %wide_chars, 1
  %wide_bytes = zext i32 %wide_bytes32 to i64
  %heap = call ptr @GetProcessHeap()
  %wide = call ptr @HeapAlloc(ptr %heap, i32 0, i64 %wide_bytes)
  %wide_written = alloca i32, align 4
  %allocated = icmp ne ptr %wide, null
  br i1 %allocated, label %convert, label %conversion_failed

convert:
  %converted = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %len, ptr %wide, i32 %wide_chars)
  %converted_all = icmp eq i32 %converted, %wide_chars
  br i1 %converted_all, label %console_write, label %conversion_free

console_write:
  %console_offset = phi i32 [ 0, %convert ], [ %console_next, %console_advance ]
  %console_remaining = sub i32 %wide_chars, %console_offset
  %console_offset64 = zext i32 %console_offset to i64
  %console_data = getelementptr i16, ptr %wide, i64 %console_offset64
  store i32 0, ptr %wide_written, align 4
  %console_ok = call i32 @WriteConsoleW(ptr %handle, ptr %console_data, i32 %console_remaining, ptr %wide_written, ptr null)
  %console_count = load i32, ptr %wide_written, align 4
  %console_succeeded = icmp ne i32 %console_ok, 0
  %console_progress = icmp ugt i32 %console_count, 0
  %console_bounded = icmp ule i32 %console_count, %console_remaining
  %console_valid0 = and i1 %console_succeeded, %console_progress
  %console_valid = and i1 %console_valid0, %console_bounded
  br i1 %console_valid, label %console_advance, label %console_write_failed

console_advance:
  %console_next = add i32 %console_offset, %console_count
  %console_complete = icmp eq i32 %console_next, %wide_chars
  br i1 %console_complete, label %console_write_succeeded, label %console_write

console_write_succeeded:
  %freed = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %write_succeeded

console_write_failed:
  %freed_after_write_failure = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %write_failed

write_succeeded:
  store i32 %len, ptr %written, align 4
  ret i32 1

write_failed:
  store i32 0, ptr %written, align 4
  ret i32 0

conversion_free:
  %freed_after_failure = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %conversion_failed

conversion_failed:
  store i32 0, ptr %written, align 4
  ret i32 0
}

define internal i32 @sollang_write_stream(ptr %handle, ptr %data, i64 %len64, ptr %written, i1 %is_console) #0 {
entry:
  %empty = icmp eq i64 %len64, 0
  br i1 %empty, label %success_empty, label %prepare

success_empty:
  store i32 0, ptr %written, align 4
  ret i32 1

prepare:
  %offset = phi i64 [ 0, %entry ], [ %next, %advance ]
  %remaining = sub i64 %len64, %offset
  %current = getelementptr i8, ptr %data, i64 %offset
  %more = icmp ugt i64 %remaining, 1048576
  %proposed = select i1 %more, i64 1048576, i64 %remaining
  %split_console = and i1 %more, %is_console
  br i1 %split_console, label %trim_boundary, label %write

trim_boundary:
  %boundary = phi i64 [ 1048576, %prepare ], [ %previous, %trim_next ]
  %boundary_ptr = getelementptr i8, ptr %current, i64 %boundary
  %boundary_byte = load i8, ptr %boundary_ptr, align 1
  %prefix = and i8 %boundary_byte, -64
  %continuation = icmp eq i8 %prefix, -128
  br i1 %continuation, label %trim_next, label %write

trim_next:
  %can_trim = icmp ugt i64 %boundary, 1048573
  %previous = sub i64 %boundary, 1
  br i1 %can_trim, label %trim_boundary, label %failure

write:
  %chunk64 = phi i64 [ %proposed, %prepare ], [ %boundary, %trim_boundary ]
  %chunk32 = trunc i64 %chunk64 to i32
  %ok = call i32 @sollang_write_stream_chunk(ptr %handle, ptr %current, i32 %chunk32, ptr %written, i1 %is_console)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %advance, label %failure

advance:
  %next = add i64 %offset, %chunk64
  %complete = icmp eq i64 %next, %len64
  br i1 %complete, label %success, label %prepare

success:
  ret i32 1

failure:
  store i32 0, ptr %written, align 4
  ret i32 0
}

define internal i32 @sollang_write_stdout_bytes(ptr %stdout, ptr %data, i32 %len, ptr %written) #0 {
entry:
  %is_console = load i1, ptr @sollang_stdout_line_buffered, align 1
  %ok = call i32 @sollang_write_stream_chunk(ptr %stdout, ptr %data, i32 %len, ptr %written, i1 %is_console)
  ret i32 %ok
}

define internal i32 @sollang_flush_stdout(ptr %stdout, ptr %written) #0 {
entry:
  %count64 = load i64, ptr @sollang_stdout_buffer_count, align 8
  %has_data = icmp ne i64 %count64, 0
  br i1 %has_data, label %write, label %empty

write:
  %count = trunc i64 %count64 to i32
  %buffer = getelementptr inbounds [1048576 x i8], ptr @sollang_stdout_buffer, i64 0, i64 0
  %ok = call i32 @sollang_write_stdout_bytes(ptr %stdout, ptr %buffer, i32 %count, ptr %written)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %clear, label %failure

clear:
  store i64 0, ptr @sollang_stdout_buffer_count, align 8
  ret i32 %ok

failure:
  call void @llvm.trap()
  unreachable

empty:
  store i32 0, ptr %written, align 4
  ret i32 1
}

define internal i32 @sollang_write(ptr %stdout, ptr %data, i64 %len64, ptr %written) #0 {
entry:
  br label %write_prepare

write_prepare:
  %oversized = icmp ugt i64 %len64, 1048576
  br i1 %oversized, label %write_direct_prepare, label %buffer_prepare

write_direct_prepare:
  %flushed_direct = call i32 @sollang_flush_stdout(ptr %stdout, ptr %written)
  %direct_console = load i1, ptr @sollang_stdout_line_buffered, align 1
  %direct_ok = call i32 @sollang_write_stream(ptr %stdout, ptr %data, i64 %len64, ptr %written, i1 %direct_console)
  %direct_succeeded = icmp ne i32 %direct_ok, 0
  br i1 %direct_succeeded, label %write_direct_done, label %write_direct_failure

write_direct_done:
  ret i32 1

write_direct_failure:
  call void @llvm.trap()
  unreachable

buffer_prepare:
  %count = load i64, ptr @sollang_stdout_buffer_count, align 8
  %combined = add i64 %count, %len64
  %needs_flush = icmp ugt i64 %combined, 1048576
  br i1 %needs_flush, label %flush, label %append

flush:
  %flushed = call i32 @sollang_flush_stdout(ptr %stdout, ptr %written)
  br label %append

append:
  %offset = phi i64 [ %count, %buffer_prepare ], [ 0, %flush ]
  %destination = getelementptr inbounds [1048576 x i8], ptr @sollang_stdout_buffer, i64 0, i64 %offset
  %copied = call ptr @memcpy(ptr %destination, ptr %data, i64 %len64)
  %next_count = add i64 %offset, %len64
  store i64 %next_count, ptr @sollang_stdout_buffer_count, align 8
  %written32 = trunc i64 %len64 to i32
  store i32 %written32, ptr %written, align 4
  %single_byte = icmp eq i64 %len64, 1
  br i1 %single_byte, label %inspect_newline, label %done

inspect_newline:
  %byte = load i8, ptr %data, align 1
  %newline = icmp eq i8 %byte, 10
  %line_buffered = load i1, ptr @sollang_stdout_line_buffered, align 1
  %flush_newline = and i1 %newline, %line_buffered
  br i1 %flush_newline, label %flush_line, label %done

flush_line:
  %line_ok = call i32 @sollang_flush_stdout(ptr %stdout, ptr %written)
  ret i32 %line_ok

done:
  ret i32 1
}

define internal i32 @sollang_read_stdin(ptr %stdin, ptr %data, i64 %len64, ptr %read) #0 {
entry:
  %exceeds_dword = icmp ugt i64 %len64, 4294967295
  %bounded_len = select i1 %exceeds_dword, i64 4294967295, i64 %len64
  %len = trunc i64 %bounded_len to i32
  %ok = call i32 @ReadFile(ptr %stdin, ptr %data, i32 %len, ptr %read, ptr null)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %success, label %inspect_error

inspect_error:
  %error = call i32 @GetLastError()
  %broken_pipe = icmp eq i32 %error, 109
  br i1 %broken_pipe, label %eof, label %failure

eof:
  store i32 0, ptr %read, align 4
  ret i32 1

success:
  ret i32 1

failure:
  ret i32 0
}

define internal i32 @sollang_platform_create_exclusive_file(ptr %path, i64 %len) #0 {
entry:
  %buf = alloca [260 x i16], align 2
  %buf_ptr = getelementptr inbounds [260 x i16], ptr %buf, i64 0, i64 0
  %fits = icmp ule i64 %len, 259
  br i1 %fits, label %convert, label %fail
convert:
  %copy_ok = call i32 @sollang_windows_utf8_path(ptr %path, i64 %len, ptr %buf_ptr, i32 260)
  %copied = icmp ne i32 %copy_ok, 0
  br i1 %copied, label %create, label %fail

create:
  %handle = call ptr @CreateFileW(ptr %buf_ptr, i32 1073741824, i32 0, ptr null, i32 1, i32 128, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %create_failed, label %close

close:
  %closed = call i32 @CloseHandle(ptr %handle)
  %close_ok = icmp ne i32 %closed, 0
  %status = select i1 %close_ok, i32 1, i32 -1
  ret i32 %status

create_failed:
  %error = call i32 @GetLastError()
  %file_exists = icmp eq i32 %error, 80
  %already_exists = icmp eq i32 %error, 183
  %exists = or i1 %file_exists, %already_exists
  %status_failed = select i1 %exists, i32 0, i32 -1
  ret i32 %status_failed

fail:
  ret i32 -1
}

define internal i32 @sollang_platform_remove_file(ptr %path, i64 %len) #0 {
entry:
  %buf = alloca [260 x i16], align 2
  %buf_ptr = getelementptr inbounds [260 x i16], ptr %buf, i64 0, i64 0
  %fits = icmp ule i64 %len, 259
  br i1 %fits, label %convert, label %fail
convert:
  %copy_ok = call i32 @sollang_windows_utf8_path(ptr %path, i64 %len, ptr %buf_ptr, i32 260)
  %copied = icmp ne i32 %copy_ok, 0
  br i1 %copied, label %remove, label %fail

remove:
  %removed = call i32 @DeleteFileW(ptr %buf_ptr)
  %success = icmp ne i32 %removed, 0
  br i1 %success, label %removed_file, label %remove_failed

removed_file:
  ret i32 1

remove_failed:
  %error = call i32 @GetLastError()
  %file_missing = icmp eq i32 %error, 2
  %path_missing = icmp eq i32 %error, 3
  %missing = or i1 %file_missing, %path_missing
  %status = select i1 %missing, i32 0, i32 -1
  ret i32 %status

fail:
  ret i32 -1
}

define internal i32 @sollang_platform_atomic_replace_file(ptr %temporary, i64 %temporary_len, ptr %destination, i64 %destination_len) #0 {
entry:
  %temporary_buf = alloca [260 x i16], align 2
  %temporary_ptr = getelementptr inbounds [260 x i16], ptr %temporary_buf, i64 0, i64 0
  %temporary_fits = icmp ule i64 %temporary_len, 259
  br i1 %temporary_fits, label %convert_temporary, label %fail
convert_temporary:
  %temporary_ok = call i32 @sollang_windows_utf8_path(ptr %temporary, i64 %temporary_len, ptr %temporary_ptr, i32 260)
  %temporary_valid = icmp ne i32 %temporary_ok, 0
  br i1 %temporary_valid, label %copy_destination, label %fail

copy_destination:
  %destination_buf = alloca [260 x i16], align 2
  %destination_ptr = getelementptr inbounds [260 x i16], ptr %destination_buf, i64 0, i64 0
  %destination_fits = icmp ule i64 %destination_len, 259
  br i1 %destination_fits, label %convert_destination, label %fail
convert_destination:
  %destination_ok = call i32 @sollang_windows_utf8_path(ptr %destination, i64 %destination_len, ptr %destination_ptr, i32 260)
  %destination_valid = icmp ne i32 %destination_ok, 0
  br i1 %destination_valid, label %replace, label %fail

replace:
  %result = call i32 @MoveFileExW(ptr %temporary_ptr, ptr %destination_ptr, i32 9)
  ret i32 %result

fail:
  ret i32 0
}

define internal %sollang.file_handle_result @sollang_platform_open_owned_read_file(ptr %path, i64 %len) #0 {
entry:
  %buf = alloca [260 x i16], align 2
  %buf_ptr = getelementptr inbounds [260 x i16], ptr %buf, i64 0, i64 0
  %fits = icmp ule i64 %len, 259
  br i1 %fits, label %convert, label %fail
convert:
  %copy_ok = call i32 @sollang_windows_utf8_path(ptr %path, i64 %len, ptr %buf_ptr, i32 260)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileW(ptr %buf_ptr, i32 -2147483648, i32 1, ptr null, i32 3, i32 1073741952, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  %ok0 = insertvalue %sollang.file_handle_result poison, i64 %handle_int, 0
  %ok1 = insertvalue %sollang.file_handle_result %ok0, i32 1, 1
  ret %sollang.file_handle_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_handle_result poison, i64 -1, 0
  %fail1 = insertvalue %sollang.file_handle_result %fail0, i32 0, 1
  ret %sollang.file_handle_result %fail1
}

define internal %sollang.file_handle_result @sollang_platform_open_owned_write_file(ptr %path, i64 %len) #0 {
entry:
  %buf = alloca [260 x i16], align 2
  %buf_ptr = getelementptr inbounds [260 x i16], ptr %buf, i64 0, i64 0
  %fits = icmp ule i64 %len, 259
  br i1 %fits, label %convert, label %fail
convert:
  %copy_ok = call i32 @sollang_windows_utf8_path(ptr %path, i64 %len, ptr %buf_ptr, i32 260)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileW(ptr %buf_ptr, i32 1073741824, i32 1, ptr null, i32 2, i32 1073741952, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  %ok0 = insertvalue %sollang.file_handle_result poison, i64 %handle_int, 0
  %ok1 = insertvalue %sollang.file_handle_result %ok0, i32 1, 1
  ret %sollang.file_handle_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_handle_result poison, i64 -1, 0
  %fail1 = insertvalue %sollang.file_handle_result %fail0, i32 0, 1
  ret %sollang.file_handle_result %fail1
}

define internal i64 @sollang_platform_duplicate_owned_file(i64 %source_value) #0 {
entry:
  %source = inttoptr i64 %source_value to ptr
  %process = call ptr @GetCurrentProcess()
  %target_slot = alloca ptr, align 8
  %ok = call i32 @DuplicateHandle(ptr %process, ptr %source, ptr %process, ptr %target_slot, i32 0, i32 0, i32 2)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %success, label %fail

success:
  %target = load ptr, ptr %target_slot, align 8
  %target_value = ptrtoint ptr %target to i64
  ret i64 %target_value

fail:
  ret i64 -1
}

define internal %sollang.file_count_result @sollang_platform_read_owned_file_at(i64 %handle_value, ptr %data, i64 %len64, i64 %offset) #0 {
entry:
  %valid_handle = icmp ne i64 %handle_value, -1
  %valid_offset = icmp ule i64 %offset, 9223372036854775807
  %fits = icmp ule i64 %len64, 4294967295
  %ready0 = and i1 %valid_handle, %valid_offset
  %ready = and i1 %ready0, %fits
  br i1 %ready, label %read, label %fail

read:
  %handle = inttoptr i64 %handle_value to ptr
  %overlapped = alloca [32 x i8], align 8
  call void @llvm.memset.p0.i64(ptr %overlapped, i8 0, i64 32, i1 false)
  %offset_low_slot = getelementptr i8, ptr %overlapped, i64 16
  %offset_low = trunc i64 %offset to i32
  store i32 %offset_low, ptr %offset_low_slot, align 4
  %offset_high_slot = getelementptr i8, ptr %overlapped, i64 20
  %offset_shifted = lshr i64 %offset, 32
  %offset_high = trunc i64 %offset_shifted to i32
  store i32 %offset_high, ptr %offset_high_slot, align 4
  %count_slot = alloca i32, align 4
  store i32 0, ptr %count_slot, align 4
  %len = trunc i64 %len64 to i32
  %started = call i32 @ReadFile(ptr %handle, ptr %data, i32 %len, ptr null, ptr %overlapped)
  %completed = call i32 @GetOverlappedResult(ptr %handle, ptr %overlapped, ptr %count_slot, i32 1)
  %ok = icmp ne i32 %completed, 0
  br i1 %ok, label %success, label %classify_failure

classify_failure:
  %error = call i32 @GetLastError()
  %eof = icmp eq i32 %error, 38
  br i1 %eof, label %success, label %fail

success:
  %count32 = load i32, ptr %count_slot, align 4
  %count = zext i32 %count32 to i64
  %ok0 = insertvalue %sollang.file_count_result poison, i64 %count, 0
  %ok1 = insertvalue %sollang.file_count_result %ok0, i32 1, 1
  ret %sollang.file_count_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_count_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.file_count_result %fail0, i32 0, 1
  ret %sollang.file_count_result %fail1
}

define internal %sollang.file_count_result @sollang_platform_write_owned_file_at(i64 %handle_value, ptr %data, i64 %len64, i64 %offset) #0 {
entry:
  %valid_handle = icmp ne i64 %handle_value, -1
  %valid_offset = icmp ule i64 %offset, 9223372036854775807
  %fits = icmp ule i64 %len64, 4294967295
  %ready0 = and i1 %valid_handle, %valid_offset
  %ready = and i1 %ready0, %fits
  br i1 %ready, label %write, label %fail

write:
  %handle = inttoptr i64 %handle_value to ptr
  %overlapped = alloca [32 x i8], align 8
  call void @llvm.memset.p0.i64(ptr %overlapped, i8 0, i64 32, i1 false)
  %offset_low_slot = getelementptr i8, ptr %overlapped, i64 16
  %offset_low = trunc i64 %offset to i32
  store i32 %offset_low, ptr %offset_low_slot, align 4
  %offset_high_slot = getelementptr i8, ptr %overlapped, i64 20
  %offset_shifted = lshr i64 %offset, 32
  %offset_high = trunc i64 %offset_shifted to i32
  store i32 %offset_high, ptr %offset_high_slot, align 4
  %count_slot = alloca i32, align 4
  store i32 0, ptr %count_slot, align 4
  %len = trunc i64 %len64 to i32
  %started = call i32 @WriteFile(ptr %handle, ptr %data, i32 %len, ptr null, ptr %overlapped)
  %completed = call i32 @GetOverlappedResult(ptr %handle, ptr %overlapped, ptr %count_slot, i32 1)
  %ok = icmp ne i32 %completed, 0
  br i1 %ok, label %success, label %fail

success:
  %count32 = load i32, ptr %count_slot, align 4
  %count = zext i32 %count32 to i64
  %ok0 = insertvalue %sollang.file_count_result poison, i64 %count, 0
  %ok1 = insertvalue %sollang.file_count_result %ok0, i32 1, 1
  ret %sollang.file_count_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_count_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.file_count_result %fail0, i32 0, 1
  ret %sollang.file_count_result %fail1
}

define internal i32 @sollang_platform_sync_owned_file(i64 %handle_value) #0 {
entry:
  %valid = icmp ne i64 %handle_value, -1
  br i1 %valid, label %sync, label %fail

sync:
  %handle = inttoptr i64 %handle_value to ptr
  %ok = call i32 @FlushFileBuffers(ptr %handle)
  ret i32 %ok

fail:
  ret i32 0
}

define internal void @sollang_platform_close_owned_file(i64 %handle_value) #0 {
entry:
  %valid = icmp ne i64 %handle_value, -1
  br i1 %valid, label %close, label %done

close:
  %handle = inttoptr i64 %handle_value to ptr
  %ignored = call i32 @CloseHandle(ptr %handle)
  br label %done

done:
  ret void
}

define internal i32 @sollang_platform_open_write_file(ptr %path, i64 %len) #0 {
entry:
  %buf = alloca [260 x i8], align 1
  %buf_ptr = getelementptr inbounds [260 x i8], ptr %buf, i64 0, i64 0
  %copy_ok = call i32 @sollang_copy_text_to_c_path(ptr %path, i64 %len, ptr %buf_ptr)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileA(ptr %buf_ptr, i32 1073741824, i32 0, ptr null, i32 2, i32 128, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  store ptr %handle, ptr @sollang_file_writer, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_platform_write_file_bytes(ptr %data, i64 %len64) #0 {
entry:
  %handle = load ptr, ptr @sollang_file_writer, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %write, label %fail

write:
  %written = alloca i32, align 4
  %len = trunc i64 %len64 to i32
  %ok = call i32 @WriteFile(ptr %handle, ptr %data, i32 %len, ptr %written, ptr null)
  %written32 = load i32, ptr %written, align 4
  %written64 = zext i32 %written32 to i64
  %write_ok = icmp ne i32 %ok, 0
  %full = icmp eq i64 %written64, %len64
  %all_ok = and i1 %write_ok, %full
  %result = zext i1 %all_ok to i32
  ret i32 %result

fail:
  ret i32 0
}

define internal i32 @sollang_platform_close_write_file() #0 {
entry:
  %handle = load ptr, ptr @sollang_file_writer, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %close, label %fail

close:
  %ok = call i32 @CloseHandle(ptr %handle)
  %close_ok = icmp ne i32 %ok, 0
  br i1 %close_ok, label %success, label %fail

success:
  store ptr null, ptr @sollang_file_writer, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_platform_open_read_file(ptr %path, i64 %len) #0 {
entry:
  %buf = alloca [260 x i8], align 1
  %buf_ptr = getelementptr inbounds [260 x i8], ptr %buf, i64 0, i64 0
  %copy_ok = call i32 @sollang_copy_text_to_c_path(ptr %path, i64 %len, ptr %buf_ptr)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileA(ptr %buf_ptr, i32 -2147483648, i32 1, ptr null, i32 3, i32 128, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  store ptr %handle, ptr @sollang_file_reader, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal %sollang.file_count_result @sollang_platform_i64_file_count() #0 {
entry:
  %handle = load ptr, ptr @sollang_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %size, label %fail

size:
  %size_ptr = alloca i64, align 8
  %ok = call i32 @GetFileSizeEx(ptr %handle, ptr %size_ptr)
  %size_ok = icmp ne i32 %ok, 0
  br i1 %size_ok, label %check, label %fail

check:
  %bytes = load i64, ptr %size_ptr, align 8
  %rem = urem i64 %bytes, 8
  %aligned = icmp eq i64 %rem, 0
  br i1 %aligned, label %success, label %fail

success:
  %count = udiv i64 %bytes, 8
  %ok0 = insertvalue %sollang.file_count_result poison, i64 %count, 0
  %ok1 = insertvalue %sollang.file_count_result %ok0, i32 1, 1
  ret %sollang.file_count_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_count_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.file_count_result %fail0, i32 0, 1
  ret %sollang.file_count_result %fail1
}

define internal %sollang.file_int_result @sollang_platform_read_i64_at(i64 %index) #0 {
entry:
  %handle = load ptr, ptr @sollang_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %seek, label %fail

seek:
  %offset = mul i64 %index, 8
  %seek_ok = call i32 @SetFilePointerEx(ptr %handle, i64 %offset, ptr null, i32 0)
  %seek_is_ok = icmp ne i32 %seek_ok, 0
  br i1 %seek_is_ok, label %read, label %fail

read:
  %value_ptr = alloca i64, align 8
  %read_bytes = alloca i32, align 4
  %ok = call i32 @ReadFile(ptr %handle, ptr %value_ptr, i32 8, ptr %read_bytes, ptr null)
  %read_ok = icmp ne i32 %ok, 0
  %read_count = load i32, ptr %read_bytes, align 4
  %read_full = icmp eq i32 %read_count, 8
  %all_ok = and i1 %read_ok, %read_full
  br i1 %all_ok, label %success, label %fail

success:
  %value = load i64, ptr %value_ptr, align 8
  %ok0 = insertvalue %sollang.file_int_result poison, i64 %value, 0
  %ok1 = insertvalue %sollang.file_int_result %ok0, i32 1, 1
  ret %sollang.file_int_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.file_int_result %fail0, i32 0, 1
  ret %sollang.file_int_result %fail1
}

define internal %sollang.file_count_result @sollang_platform_read_file_bytes(ptr %data, i64 %len64) #0 {
entry:
  %handle = load ptr, ptr @sollang_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  %fits = icmp ule i64 %len64, 4294967295
  %ready = and i1 %has_handle, %fits
  br i1 %ready, label %read, label %fail

read:
  %len = trunc i64 %len64 to i32
  %count_ptr = alloca i32, align 4
  %result = call i32 @ReadFile(ptr %handle, ptr %data, i32 %len, ptr %count_ptr, ptr null)
  %ok = icmp ne i32 %result, 0
  br i1 %ok, label %success, label %fail

success:
  %count32 = load i32, ptr %count_ptr, align 4
  %count = zext i32 %count32 to i64
  %ok0 = insertvalue %sollang.file_count_result poison, i64 %count, 0
  %ok1 = insertvalue %sollang.file_count_result %ok0, i32 1, 1
  ret %sollang.file_count_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_count_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.file_count_result %fail0, i32 0, 1
  ret %sollang.file_count_result %fail1
}

define internal i32 @sollang_platform_close_read_file() #0 {
entry:
  %handle = load ptr, ptr @sollang_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %close, label %fail

close:
  %ok = call i32 @CloseHandle(ptr %handle)
  %close_ok = icmp ne i32 %ok, 0
  br i1 %close_ok, label %success, label %fail

success:
  store ptr null, ptr @sollang_file_reader, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal %sollang.mapped_bytes @sollang_map_file(ptr %path, i64 %path_len, i64 %offset, i64 %requested_len, i64 %requested_size, i1 %writable) #0 {
entry:
  %buf = alloca [260 x i16], align 2
  %buf_ptr = getelementptr inbounds [260 x i16], ptr %buf, i64 0, i64 0
  %copy_ok = call i32 @sollang_windows_utf8_path(ptr %path, i64 %path_len, ptr %buf_ptr, i32 260)
  %path_ok = icmp ne i32 %copy_ok, 0
  br i1 %path_ok, label %open, label %fail

open:
  %access = select i1 %writable, i32 -1073741824, i32 -2147483648
  %creation = select i1 %writable, i32 4, i32 3
  %file = call ptr @CreateFileW(ptr %buf_ptr, i32 %access, i32 1, ptr null, i32 %creation, i32 128, ptr null)
  %file_int = ptrtoint ptr %file to i64
  %file_ok = icmp ne i64 %file_int, -1
  br i1 %file_ok, label %resize_check, label %fail

resize_check:
  %has_requested_size = icmp ne i64 %requested_size, 0
  %resize = and i1 %writable, %has_requested_size
  br i1 %resize, label %resize_file, label %read_size

resize_file:
  %seek_ok = call i32 @SetFilePointerEx(ptr %file, i64 %requested_size, ptr null, i32 0)
  %seek_valid = icmp ne i32 %seek_ok, 0
  br i1 %seek_valid, label %resize_end, label %close_fail

resize_end:
  %end_ok = call i32 @SetEndOfFile(ptr %file)
  %resize_valid = icmp ne i32 %end_ok, 0
  br i1 %resize_valid, label %read_size, label %close_fail

read_size:
  %size_slot = alloca i64, align 8
  %size_ok = call i32 @GetFileSizeEx(ptr %file, ptr %size_slot)
  %size_valid = icmp ne i32 %size_ok, 0
  br i1 %size_valid, label %bounds, label %close_fail

bounds:
  %file_size = load i64, ptr %size_slot, align 8
  %offset_ok = icmp ule i64 %offset, %file_size
  %remaining = sub i64 %file_size, %offset
  %whole = icmp eq i64 %requested_len, 0
  %view_len = select i1 %whole, i64 %remaining, i64 %requested_len
  %len_nonzero = icmp ne i64 %view_len, 0
  %len_ok = icmp ule i64 %view_len, %remaining
  %bounds1 = and i1 %offset_ok, %len_nonzero
  %bounds_ok = and i1 %bounds1, %len_ok
  br i1 %bounds_ok, label %mapping, label %close_fail

mapping:
  %protect = select i1 %writable, i32 4, i32 2
  %mapping_handle = call ptr @CreateFileMappingA(ptr %file, ptr null, i32 %protect, i32 0, i32 0, ptr null)
  %mapping_ok = icmp ne ptr %mapping_handle, null
  br i1 %mapping_ok, label %view, label %close_fail

view:
  %aligned = and i64 %offset, -65536
  %delta = sub i64 %offset, %aligned
  %mapped_len = add i64 %delta, %view_len
  %high64 = lshr i64 %aligned, 32
  %high = trunc i64 %high64 to i32
  %low = trunc i64 %aligned to i32
  %desired = select i1 %writable, i32 2, i32 4
  %base = call ptr @MapViewOfFile(ptr %mapping_handle, i32 %desired, i32 %high, i32 %low, i64 %mapped_len)
  %base_ok = icmp ne ptr %base, null
  br i1 %base_ok, label %success, label %mapping_close_fail

success:
  %data = getelementptr i8, ptr %base, i64 %delta
  %ignored_mapping = call i32 @CloseHandle(ptr %mapping_handle)
  %ignored_file = call i32 @CloseHandle(ptr %file)
  %r0 = insertvalue %sollang.mapped_bytes poison, ptr %data, 0
  %r1 = insertvalue %sollang.mapped_bytes %r0, i64 %view_len, 1
  %r2 = insertvalue %sollang.mapped_bytes %r1, ptr %base, 2
  %r3 = insertvalue %sollang.mapped_bytes %r2, i64 %mapped_len, 3
  %r4 = insertvalue %sollang.mapped_bytes %r3, i1 %writable, 4
  ret %sollang.mapped_bytes %r4

mapping_close_fail:
  %ignored_mapping_fail = call i32 @CloseHandle(ptr %mapping_handle)
  br label %close_fail

close_fail:
  %ignored_close = call i32 @CloseHandle(ptr %file)
  br label %fail

fail:
  %f0 = insertvalue %sollang.mapped_bytes zeroinitializer, i1 %writable, 4
  ret %sollang.mapped_bytes %f0
}

define internal i32 @sollang_mapped_flush(ptr %base, i64 %mapped_len) #0 {
entry:
  %ok = call i32 @FlushViewOfFile(ptr %base, i64 %mapped_len)
  ret i32 %ok
}

define internal void @sollang_mapped_unmap(ptr %base, i64 %mapped_len) #0 {
entry:
  %ignored = call i32 @UnmapViewOfFile(ptr %base)
  ret void
}

define internal i64 @sollang_now_millis() #0 {
entry:
  %millis = call i64 @GetTickCount64()
  ret i64 %millis
}

define internal i64 @sollang_utc_now_millis() #0 {
entry:
  %filetime = alloca [2 x i32], align 4
  call void @GetSystemTimePreciseAsFileTime(ptr %filetime)
  %low_ptr = getelementptr inbounds [2 x i32], ptr %filetime, i64 0, i64 0
  %high_ptr = getelementptr inbounds [2 x i32], ptr %filetime, i64 0, i64 1
  %low32 = load i32, ptr %low_ptr, align 4
  %high32 = load i32, ptr %high_ptr, align 4
  %low = zext i32 %low32 to i64
  %high = zext i32 %high32 to i64
  %shifted = shl i64 %high, 32
  %ticks = or i64 %shifted, %low
  %unix_ticks = sub i64 %ticks, 116444736000000000
  %millis = udiv i64 %unix_ticks, 10000
  ret i64 %millis
}

define internal void @sollang_wait_millis(i64 %requested) #0 {
entry:
  %positive = icmp sgt i64 %requested, 0
  br i1 %positive, label %clamp, label %done

clamp:
  %too_large = icmp ugt i64 %requested, 4294967294
  %bounded = select i1 %too_large, i64 4294967294, i64 %requested
  %millis = trunc i64 %bounded to i32
  call void @Sleep(i32 %millis)
  br label %done

done:
  ret void
}

define internal ptr @sollang_alloc(i64 %bytes) #0 {
entry:
  %heap = call ptr @GetProcessHeap()
  %ptr = call ptr @HeapAlloc(ptr %heap, i32 0, i64 %bytes)
  ret ptr %ptr
}

define internal void @sollang_free(ptr %ptr) #0 {
entry:
  %is_null = icmp eq ptr %ptr, null
  br i1 %is_null, label %done, label %free

free:
  %heap = call ptr @GetProcessHeap()
  %ignored = call i32 @HeapFree(ptr %heap, i32 0, ptr %ptr)
  br label %done

done:
  ret void
}

define dso_local ptr @memset(ptr %dest, i32 %value, i64 %count) #0 {
entry:
  %byte = trunc i32 %value to i8
  br label %loop

loop:
  %i = phi i64 [ 0, %entry ], [ %next, %body ]
  %active = icmp ult i64 %i, %count
  br i1 %active, label %body, label %done

body:
  %slot = getelementptr i8, ptr %dest, i64 %i
  store i8 %byte, ptr %slot, align 1
  %next = add i64 %i, 1
  br label %loop

done:
  ret ptr %dest
}

define dso_local ptr @memcpy(ptr %dest, ptr %source, i64 %count) #0 {
entry:
  br label %loop

loop:
  %i = phi i64 [ 0, %entry ], [ %next, %body ]
  %active = icmp ult i64 %i, %count
  br i1 %active, label %body, label %done

body:
  %src_slot = getelementptr i8, ptr %source, i64 %i
  %dst_slot = getelementptr i8, ptr %dest, i64 %i
  %byte = load i8, ptr %src_slot, align 1
  store i8 %byte, ptr %dst_slot, align 1
  %next = add i64 %i, 1
  br label %loop

done:
  ret ptr %dest
}

define dso_local ptr @memmove(ptr %dest, ptr %source, i64 %count) #0 {
entry:
  %same = icmp eq ptr %dest, %source
  %empty = icmp eq i64 %count, 0
  %done_early = or i1 %same, %empty
  br i1 %done_early, label %done, label %choose_direction

choose_direction:
  %forward = icmp ult ptr %dest, %source
  br i1 %forward, label %forward_loop, label %backward_loop

forward_loop:
  %forward_i = phi i64 [ 0, %choose_direction ], [ %forward_next, %forward_body ]
  %forward_active = icmp ult i64 %forward_i, %count
  br i1 %forward_active, label %forward_body, label %done

forward_body:
  %forward_src = getelementptr i8, ptr %source, i64 %forward_i
  %forward_dst = getelementptr i8, ptr %dest, i64 %forward_i
  %forward_byte = load i8, ptr %forward_src, align 1
  store i8 %forward_byte, ptr %forward_dst, align 1
  %forward_next = add i64 %forward_i, 1
  br label %forward_loop

backward_loop:
  %backward_i = phi i64 [ %count, %choose_direction ], [ %backward_next, %backward_body ]
  %backward_active = icmp ugt i64 %backward_i, 0
  br i1 %backward_active, label %backward_body, label %done

backward_body:
  %backward_next = sub i64 %backward_i, 1
  %backward_src = getelementptr i8, ptr %source, i64 %backward_next
  %backward_dst = getelementptr i8, ptr %dest, i64 %backward_next
  %backward_byte = load i8, ptr %backward_src, align 1
  store i8 %backward_byte, ptr %backward_dst, align 1
  br label %backward_loop

done:
  ret ptr %dest
}

define internal i64 @sollang_format_u64(ptr %dest, i64 %value) #0 {
entry:
  br label %count

count:
  %count_n = phi i64 [ %value, %entry ], [ %count_q, %count_more ]
  %length = phi i64 [ 1, %entry ], [ %next_length, %count_more ]
  %count_q = udiv i64 %count_n, 10
  %count_done = icmp eq i64 %count_q, 0
  br i1 %count_done, label %write_entry, label %count_more

count_more:
  %next_length = add i64 %length, 1
  br label %count

write_entry:
  %last_index = sub i64 %length, 1
  br label %write

write:
  %write_n = phi i64 [ %value, %write_entry ], [ %write_q, %write ]
  %index = phi i64 [ %last_index, %write_entry ], [ %previous_index, %write ]
  %digit = urem i64 %write_n, 10
  %write_q = udiv i64 %write_n, 10
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  %slot = getelementptr i8, ptr %dest, i64 %index
  store i8 %ascii, ptr %slot, align 1
  %previous_index = sub i64 %index, 1
  %write_done = icmp eq i64 %write_q, 0
  br i1 %write_done, label %return, label %write

return:
  ret i64 %length
}

define internal i64 @sollang_format_i64(ptr %dest, i64 %value) #0 {
entry:
  %negative = icmp slt i64 %value, 0
  br i1 %negative, label %negative_value, label %positive_value

negative_value:
  store i8 45, ptr %dest, align 1
  %digits_dest = getelementptr i8, ptr %dest, i64 1
  %magnitude = sub i64 0, %value
  %negative_digits = call i64 @sollang_format_u64(ptr %digits_dest, i64 %magnitude)
  %negative_length = add i64 %negative_digits, 1
  ret i64 %negative_length

positive_value:
  %positive_length = call i64 @sollang_format_u64(ptr %dest, i64 %value)
  ret i64 %positive_length
}

define internal i32 @sollang_write_u64(ptr %stdout, i64 %value, ptr %written) #0 {
entry:
  %buf = alloca [20 x i8], align 1
  %end = getelementptr inbounds [20 x i8], ptr %buf, i64 0, i64 20
  br label %digits

digits:
  %n = phi i64 [ %value, %entry ], [ %q, %digits ]
  %p = phi ptr [ %end, %entry ], [ %next, %digits ]
  %digit = urem i64 %n, 10
  %q = udiv i64 %n, 10
  %next = getelementptr i8, ptr %p, i64 -1
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  store i8 %ascii, ptr %next, align 1
  %done = icmp eq i64 %q, 0
  br i1 %done, label %write, label %digits

write:
  %start_int = ptrtoint ptr %next to i64
  %end_int = ptrtoint ptr %end to i64
  %len = sub i64 %end_int, %start_int
  %ok = call i32 @sollang_write(ptr %stdout, ptr %next, i64 %len, ptr %written)
  ret i32 %ok
}

define internal i32 @sollang_write_i64(ptr %stdout, i64 %value, ptr %written) #0 {
entry:
  %negative = icmp slt i64 %value, 0
  br i1 %negative, label %write_sign, label %write_digits

write_sign:
  %sign = alloca i8, align 1
  store i8 45, ptr %sign, align 1
  %sign_ok = call i32 @sollang_write(ptr %stdout, ptr %sign, i64 1, ptr %written)
  %magnitude = sub i64 0, %value
  %digits_ok_negative = call i32 @sollang_write_u64(ptr %stdout, i64 %magnitude, ptr %written)
  %negative_ok = and i32 %sign_ok, %digits_ok_negative
  ret i32 %negative_ok

write_digits:
  %digits_ok = call i32 @sollang_write_u64(ptr %stdout, i64 %value, ptr %written)
  ret i32 %digits_ok
}

define internal %sollang.read_int_result @sollang_read_i64(ptr %stdin, ptr %read) #0 {
entry:
  %buf = alloca [64 x i8], align 1
  %ok = call i32 @sollang_read_stdin(ptr %stdin, ptr %buf, i64 64, ptr %read)
  %read_ok = icmp ne i32 %ok, 0
  br i1 %read_ok, label %prepare, label %fail

prepare:
  %read32 = load i32, ptr %read, align 4
  %len = zext i32 %read32 to i64
  br label %skip

skip:
  %skip_idx = phi i64 [ 0, %prepare ], [ %skip_next, %skip_ws ]
  %skip_has = icmp ult i64 %skip_idx, %len
  br i1 %skip_has, label %skip_char, label %fail

skip_char:
  %skip_ptr = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 %skip_idx
  %skip_ch = load i8, ptr %skip_ptr, align 1
  %skip_sp = icmp eq i8 %skip_ch, 32
  %skip_tab = icmp eq i8 %skip_ch, 9
  %skip_cr = icmp eq i8 %skip_ch, 13
  %skip_lf = icmp eq i8 %skip_ch, 10
  %skip_sp_tab = or i1 %skip_sp, %skip_tab
  %skip_cr_lf = or i1 %skip_cr, %skip_lf
  %skip_is_ws = or i1 %skip_sp_tab, %skip_cr_lf
  br i1 %skip_is_ws, label %skip_ws, label %digit_entry

skip_ws:
  %skip_next = add i64 %skip_idx, 1
  br label %skip

digit_entry:
  %first_ge = icmp uge i8 %skip_ch, 48
  %first_le = icmp ule i8 %skip_ch, 57
  %first_digit = and i1 %first_ge, %first_le
  br i1 %first_digit, label %digits, label %fail

digits:
  %digit_idx = phi i64 [ %skip_idx, %digit_entry ], [ %digit_next, %digit_continue ]
  %value = phi i64 [ 0, %digit_entry ], [ %value_next, %digit_continue ]
  %digit_has = icmp ult i64 %digit_idx, %len
  br i1 %digit_has, label %digit_char, label %success

digit_char:
  %digit_ptr = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 %digit_idx
  %digit_ch = load i8, ptr %digit_ptr, align 1
  %digit_ge = icmp uge i8 %digit_ch, 48
  %digit_le = icmp ule i8 %digit_ch, 57
  %is_digit = and i1 %digit_ge, %digit_le
  br i1 %is_digit, label %digit_continue, label %trail_entry

digit_continue:
  %digit64 = zext i8 %digit_ch to i64
  %digit_value = sub i64 %digit64, 48
  %value_x10 = mul i64 %value, 10
  %value_next = add i64 %value_x10, %digit_value
  %digit_next = add i64 %digit_idx, 1
  br label %digits

trail_entry:
  br label %trail

trail:
  %trail_idx = phi i64 [ %digit_idx, %trail_entry ], [ %trail_next, %trail_ws ]
  %trail_has = icmp ult i64 %trail_idx, %len
  br i1 %trail_has, label %trail_char, label %success

trail_char:
  %trail_ptr = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 %trail_idx
  %trail_ch = load i8, ptr %trail_ptr, align 1
  %trail_sp = icmp eq i8 %trail_ch, 32
  %trail_tab = icmp eq i8 %trail_ch, 9
  %trail_cr = icmp eq i8 %trail_ch, 13
  %trail_lf = icmp eq i8 %trail_ch, 10
  %trail_sp_tab = or i1 %trail_sp, %trail_tab
  %trail_cr_lf = or i1 %trail_cr, %trail_lf
  %trail_is_ws = or i1 %trail_sp_tab, %trail_cr_lf
  br i1 %trail_is_ws, label %trail_ws, label %fail

trail_ws:
  %trail_next = add i64 %trail_idx, 1
  br label %trail

success:
  %success_value = phi i64 [ %value, %digits ], [ %value, %trail ]
  %success0 = insertvalue %sollang.read_int_result poison, i64 %success_value, 0
  %success1 = insertvalue %sollang.read_int_result %success0, i32 1, 1
  ret %sollang.read_int_result %success1

fail:
  %fail0 = insertvalue %sollang.read_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.read_int_result %fail0, i32 0, 1
  ret %sollang.read_int_result %fail1
}

define internal i32 @sollang_copy_text_to_c_path(ptr %data, i64 %len, ptr %out) #0 {
entry:
  %too_long = icmp ugt i64 %len, 259
  br i1 %too_long, label %fail, label %copy

copy:
  %i = phi i64 [ 0, %entry ], [ %next, %copy_body ]
  %done = icmp eq i64 %i, %len
  br i1 %done, label %nul, label %copy_body

copy_body:
  %src = getelementptr i8, ptr %data, i64 %i
  %ch = load i8, ptr %src, align 1
  %dst = getelementptr i8, ptr %out, i64 %i
  store i8 %ch, ptr %dst, align 1
  %next = add i64 %i, 1
  br label %copy

nul:
  %nul_ptr = getelementptr i8, ptr %out, i64 %len
  store i8 0, ptr %nul_ptr, align 1
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_file_path_has_no_nul(ptr %data, i64 %len) #0 {
entry:
  br label %check

check:
  %i = phi i64 [ 0, %entry ], [ %next, %advance ]
  %done = icmp eq i64 %i, %len
  br i1 %done, label %valid, label %read

read:
  %src = getelementptr i8, ptr %data, i64 %i
  %ch = load i8, ptr %src, align 1
  %is_nul = icmp eq i8 %ch, 0
  br i1 %is_nul, label %invalid, label %advance

advance:
  %next = add i64 %i, 1
  br label %check

valid:
  ret i32 1

invalid:
  ret i32 0
}

define internal i32 @sollang_seed_random(i64 %seed) #0 {
entry:
  store i64 %seed, ptr @sollang_random_state, align 8
  ret i32 1
}

define internal %sollang.file_int_result @sollang_random_below(i64 %max) #0 {
entry:
  %valid = icmp sgt i64 %max, 0
  br i1 %valid, label %next, label %fail

next:
  %state = load i64, ptr @sollang_random_state, align 8
  %mul = mul i64 %state, 6364136223846793005
  %new_state = add i64 %mul, 1442695040888963407
  store i64 %new_state, ptr @sollang_random_state, align 8
  %value = urem i64 %new_state, %max
  %ok0 = insertvalue %sollang.file_int_result poison, i64 %value, 0
  %ok1 = insertvalue %sollang.file_int_result %ok0, i32 1, 1
  ret %sollang.file_int_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.file_int_result %fail0, i32 0, 1
  ret %sollang.file_int_result %fail1
}

define internal i32 @sollang_open_write_i64_file(ptr %path, i64 %len) #0 {
entry:
  store i64 0, ptr @sollang_writer_buffer_count, align 8
  %ok = call i32 @sollang_platform_open_write_file(ptr %path, i64 %len)
  ret i32 %ok
}

define internal i32 @sollang_flush_i64_file() #0 {
entry:
  %count = load i64, ptr @sollang_writer_buffer_count, align 8
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %success, label %flush

flush:
  %bytes = mul i64 %count, 8
  %ok = call i32 @sollang_platform_write_file_bytes(ptr @sollang_writer_buffer, i64 %bytes)
  %is_ok = icmp ne i32 %ok, 0
  br i1 %is_ok, label %reset, label %fail

reset:
  store i64 0, ptr @sollang_writer_buffer_count, align 8
  br label %success

success:
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_write_i64_file(i64 %value) #0 {
entry:
  %count = load i64, ptr @sollang_writer_buffer_count, align 8
  %slot = getelementptr inbounds [8192 x i64], ptr @sollang_writer_buffer, i64 0, i64 %count
  store i64 %value, ptr %slot, align 8
  %next = add i64 %count, 1
  store i64 %next, ptr @sollang_writer_buffer_count, align 8
  %full = icmp eq i64 %next, 8192
  br i1 %full, label %flush, label %success

flush:
  %ok = call i32 @sollang_flush_i64_file()
  ret i32 %ok

success:
  ret i32 1
}

define internal i32 @sollang_close_write_i64_file() #0 {
entry:
  %flush_ok = call i32 @sollang_flush_i64_file()
  %flush_is_ok = icmp ne i32 %flush_ok, 0
  br i1 %flush_is_ok, label %close, label %fail

close:
  %close_ok = call i32 @sollang_platform_close_write_file()
  ret i32 %close_ok

fail:
  ret i32 0
}

define internal %sollang.file_int_result @sollang_closest_i64_file(i64 %target) #0 {
entry:
  %count_result = call %sollang.file_count_result @sollang_platform_i64_file_count()
  %count = extractvalue %sollang.file_count_result %count_result, 0
  %count_ok = extractvalue %sollang.file_count_result %count_result, 1
  %count_is_ok = icmp ne i32 %count_ok, 0
  %has_values = icmp sgt i64 %count, 0
  %can_search = and i1 %count_is_ok, %has_values
  br i1 %can_search, label %search, label %fail

search:
  br label %loop

loop:
  %low = phi i64 [ 0, %search ], [ %next_low, %step ]
  %high = phi i64 [ %count, %search ], [ %next_high, %step ]
  %active = icmp slt i64 %low, %high
  br i1 %active, label %probe, label %choose

probe:
  %span = sub i64 %high, %low
  %half = sdiv i64 %span, 2
  %mid = add i64 %low, %half
  %mid_result = call %sollang.file_int_result @sollang_platform_read_i64_at(i64 %mid)
  %mid_value = extractvalue %sollang.file_int_result %mid_result, 0
  %mid_ok = extractvalue %sollang.file_int_result %mid_result, 1
  %mid_is_ok = icmp ne i32 %mid_ok, 0
  br i1 %mid_is_ok, label %compare_mid, label %fail

compare_mid:
  %less = icmp slt i64 %mid_value, %target
  br i1 %less, label %move_low, label %move_high

move_low:
  %low_plus = add i64 %mid, 1
  br label %step

move_high:
  br label %step

step:
  %next_low = phi i64 [ %low_plus, %move_low ], [ %low, %move_high ]
  %next_high = phi i64 [ %high, %move_low ], [ %mid, %move_high ]
  br label %loop

choose:
  %at_start = icmp eq i64 %low, 0
  br i1 %at_start, label %read_low, label %check_end

check_end:
  %at_end = icmp eq i64 %low, %count
  br i1 %at_end, label %read_prev_only, label %read_pair

read_low:
  %first_result = call %sollang.file_int_result @sollang_platform_read_i64_at(i64 0)
  ret %sollang.file_int_result %first_result

read_prev_only:
  %last_index = sub i64 %count, 1
  %last_result = call %sollang.file_int_result @sollang_platform_read_i64_at(i64 %last_index)
  ret %sollang.file_int_result %last_result

read_pair:
  %prev_index = sub i64 %low, 1
  %prev_result = call %sollang.file_int_result @sollang_platform_read_i64_at(i64 %prev_index)
  %next_result = call %sollang.file_int_result @sollang_platform_read_i64_at(i64 %low)
  %prev_ok = extractvalue %sollang.file_int_result %prev_result, 1
  %next_ok = extractvalue %sollang.file_int_result %next_result, 1
  %prev_is_ok = icmp ne i32 %prev_ok, 0
  %next_is_ok = icmp ne i32 %next_ok, 0
  %both_ok = and i1 %prev_is_ok, %next_is_ok
  br i1 %both_ok, label %compare_pair, label %fail

compare_pair:
  %prev_value = extractvalue %sollang.file_int_result %prev_result, 0
  %next_value = extractvalue %sollang.file_int_result %next_result, 0
  %prev_diff = sub i64 %target, %prev_value
  %next_diff = sub i64 %next_value, %target
  %prefer_prev = icmp sle i64 %prev_diff, %next_diff
  br i1 %prefer_prev, label %return_prev, label %return_next

return_prev:
  ret %sollang.file_int_result %prev_result

return_next:
  ret %sollang.file_int_result %next_result

fail:
  %fail0 = insertvalue %sollang.file_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.file_int_result %fail0, i32 0, 1
  ret %sollang.file_int_result %fail1
}
define internal i64 @sollang_utf8_decode(ptr %data, i64 %len, i64 %index) #0 {
entry:
  %has_first = icmp ult i64 %index, %len
  br i1 %has_first, label %first, label %invalid

first:
  %p0 = getelementptr i8, ptr %data, i64 %index
  %b0raw = load i8, ptr %p0, align 1
  %b0 = zext i8 %b0raw to i32
  %ascii = icmp ult i32 %b0, 128
  br i1 %ascii, label %ascii_result, label %classify

ascii_result:
  %ascii_wide = zext i32 %b0 to i64
  %ascii_packed = or i64 %ascii_wide, 4294967296
  ret i64 %ascii_packed

classify:
  %is2lo = icmp uge i32 %b0, 194
  %is2hi = icmp ule i32 %b0, 223
  %is2 = and i1 %is2lo, %is2hi
  %is3lo = icmp uge i32 %b0, 224
  %is3hi = icmp ule i32 %b0, 239
  %is3 = and i1 %is3lo, %is3hi
  %is4lo = icmp uge i32 %b0, 240
  %is4hi = icmp ule i32 %b0, 244
  %is4 = and i1 %is4lo, %is4hi
  br i1 %is2, label %decode2, label %check3

check3:
  br i1 %is3, label %decode3, label %check4

check4:
  br i1 %is4, label %decode4, label %invalid

decode2:
  %end2 = add i64 %index, 1
  %has2 = icmp ult i64 %end2, %len
  br i1 %has2, label %load2, label %invalid

load2:
  %p1_2 = getelementptr i8, ptr %data, i64 %end2
  %b1_2raw = load i8, ptr %p1_2, align 1
  %b1_2 = zext i8 %b1_2raw to i32
  %c1_2lo = icmp uge i32 %b1_2, 128
  %c1_2hi = icmp ule i32 %b1_2, 191
  %c1_2 = and i1 %c1_2lo, %c1_2hi
  br i1 %c1_2, label %result2, label %invalid

result2:
  %h2 = and i32 %b0, 31
  %h2s = shl i32 %h2, 6
  %l2 = and i32 %b1_2, 63
  %cp2 = or i32 %h2s, %l2
  %cp2wide = zext i32 %cp2 to i64
  %packed2 = or i64 %cp2wide, 8589934592
  ret i64 %packed2

decode3:
  %end3 = add i64 %index, 2
  %has3 = icmp ult i64 %end3, %len
  br i1 %has3, label %load3, label %invalid

load3:
  %i1_3 = add i64 %index, 1
  %p1_3 = getelementptr i8, ptr %data, i64 %i1_3
  %p2_3 = getelementptr i8, ptr %data, i64 %end3
  %b1_3raw = load i8, ptr %p1_3, align 1
  %b2_3raw = load i8, ptr %p2_3, align 1
  %b1_3 = zext i8 %b1_3raw to i32
  %b2_3 = zext i8 %b2_3raw to i32
  %c1_3lo = icmp uge i32 %b1_3, 128
  %c1_3hi = icmp ule i32 %b1_3, 191
  %c1_3 = and i1 %c1_3lo, %c1_3hi
  %c2_3lo = icmp uge i32 %b2_3, 128
  %c2_3hi = icmp ule i32 %b2_3, 191
  %c2_3 = and i1 %c2_3lo, %c2_3hi
  %cont3 = and i1 %c1_3, %c2_3
  br i1 %cont3, label %value3, label %invalid

value3:
  %h3 = and i32 %b0, 15
  %h3s = shl i32 %h3, 12
  %m3 = and i32 %b1_3, 63
  %m3s = shl i32 %m3, 6
  %hm3 = or i32 %h3s, %m3s
  %l3 = and i32 %b2_3, 63
  %cp3 = or i32 %hm3, %l3
  %min3 = icmp uge i32 %cp3, 2048
  %below_surrogate = icmp ult i32 %cp3, 55296
  %above_surrogate = icmp ugt i32 %cp3, 57343
  %not_surrogate = or i1 %below_surrogate, %above_surrogate
  %valid3 = and i1 %min3, %not_surrogate
  br i1 %valid3, label %result3, label %invalid

result3:
  %cp3wide = zext i32 %cp3 to i64
  %packed3 = or i64 %cp3wide, 12884901888
  ret i64 %packed3

decode4:
  %end4 = add i64 %index, 3
  %has4 = icmp ult i64 %end4, %len
  br i1 %has4, label %load4, label %invalid

load4:
  %i1_4 = add i64 %index, 1
  %i2_4 = add i64 %index, 2
  %p1_4 = getelementptr i8, ptr %data, i64 %i1_4
  %p2_4 = getelementptr i8, ptr %data, i64 %i2_4
  %p3_4 = getelementptr i8, ptr %data, i64 %end4
  %b1_4raw = load i8, ptr %p1_4, align 1
  %b2_4raw = load i8, ptr %p2_4, align 1
  %b3_4raw = load i8, ptr %p3_4, align 1
  %b1_4 = zext i8 %b1_4raw to i32
  %b2_4 = zext i8 %b2_4raw to i32
  %b3_4 = zext i8 %b3_4raw to i32
  %c1_4lo = icmp uge i32 %b1_4, 128
  %c1_4hi = icmp ule i32 %b1_4, 191
  %c1_4 = and i1 %c1_4lo, %c1_4hi
  %c2_4lo = icmp uge i32 %b2_4, 128
  %c2_4hi = icmp ule i32 %b2_4, 191
  %c2_4 = and i1 %c2_4lo, %c2_4hi
  %c3_4lo = icmp uge i32 %b3_4, 128
  %c3_4hi = icmp ule i32 %b3_4, 191
  %c3_4 = and i1 %c3_4lo, %c3_4hi
  %cont12_4 = and i1 %c1_4, %c2_4
  %cont4 = and i1 %cont12_4, %c3_4
  br i1 %cont4, label %value4, label %invalid

value4:
  %h4 = and i32 %b0, 7
  %h4s = shl i32 %h4, 18
  %m1_4 = and i32 %b1_4, 63
  %m1_4s = shl i32 %m1_4, 12
  %m2_4 = and i32 %b2_4, 63
  %m2_4s = shl i32 %m2_4, 6
  %hm1_4 = or i32 %h4s, %m1_4s
  %hm2_4 = or i32 %hm1_4, %m2_4s
  %l4 = and i32 %b3_4, 63
  %cp4 = or i32 %hm2_4, %l4
  %min4 = icmp uge i32 %cp4, 65536
  %max4 = icmp ule i32 %cp4, 1114111
  %valid4 = and i1 %min4, %max4
  br i1 %valid4, label %result4, label %invalid

result4:
  %cp4wide = zext i32 %cp4 to i64
  %packed4 = or i64 %cp4wide, 17179869184
  ret i64 %packed4

invalid:
  ret i64 -1
}

define dso_local i32 @sollang_start() local_unnamed_addr {
entry:
  %written = alloca i32, align 4
  %read = alloca i32, align 4
  %ok_state = alloca i1, align 1
  %trap_written3 = alloca i32, align 4
  %trap_written8 = alloca i32, align 4
  %trap_written12 = alloca i32, align 4
  %trap_written16 = alloca i32, align 4
  %trap_written20 = alloca i32, align 4
  %com_factory_out21 = alloca ptr, align 8
  %trap_written29 = alloca i32, align 4
  %com_object_out30 = alloca ptr, align 8
  %enum_init_slot42 = alloca %sollang.enum.2657, align 8
  %enum_init_slot46 = alloca %sollang.enum.2657, align 8
  %enum_match_slot53 = alloca %sollang.enum.2657, align 8
  %enum_payload_owned56 = alloca i1, align 1
  %ref_arg57 = alloca %sollang.struct.1448, align 8
  %com_method_out61 = alloca i32, align 4
  %enum_init_slot68 = alloca %sollang.enum.2659, align 8
  %enum_init_slot72 = alloca %sollang.enum.2659, align 8
  %enum_match_slot79 = alloca %sollang.enum.2659, align 8
  %enum_match_slot96 = alloca %sollang.enum.2659, align 8
  %com_query_out115 = alloca ptr, align 8
  %enum_init_slot126 = alloca %sollang.enum.2660, align 8
  %enum_init_slot130 = alloca %sollang.enum.2660, align 8
  %enum_match_slot137 = alloca %sollang.enum.2660, align 8
  %enum_payload_owned140 = alloca i1, align 1
  %ref_arg141 = alloca %sollang.struct.1449, align 8
  %com_method_out145 = alloca i32, align 4
  %enum_init_slot152 = alloca %sollang.enum.2659, align 8
  %enum_init_slot156 = alloca %sollang.enum.2659, align 8
  %enum_match_slot163 = alloca %sollang.enum.2659, align 8
  %enum_match_slot180 = alloca %sollang.enum.2659, align 8
  %enum_match_slot198 = alloca %sollang.enum.2660, align 8
  %com_query_out217 = alloca ptr, align 8
  %enum_init_slot228 = alloca %sollang.enum.2662, align 8
  %enum_init_slot232 = alloca %sollang.enum.2662, align 8
  %enum_match_slot239 = alloca %sollang.enum.2662, align 8
  %enum_payload_owned242 = alloca i1, align 1
  %enum_match_slot253 = alloca %sollang.enum.2662, align 8
  %ref_arg278 = alloca %sollang.struct.1448, align 8
  %com_method_out282 = alloca i32, align 4
  %enum_init_slot289 = alloca %sollang.enum.2659, align 8
  %enum_init_slot293 = alloca %sollang.enum.2659, align 8
  %enum_match_slot300 = alloca %sollang.enum.2659, align 8
  %enum_match_slot317 = alloca %sollang.enum.2659, align 8
  %enum_match_slot335 = alloca %sollang.enum.2657, align 8
  store i1 true, ptr %ok_state, align 1
  %stdin = call ptr @GetStdHandle(i32 -10)
  %stdout = call ptr @GetStdHandle(i32 -11)
  %stdout_mode = alloca i32, align 4
  %stdout_is_console_status = call i32 @GetConsoleMode(ptr %stdout, ptr %stdout_mode)
  %stdout_is_console = icmp ne i32 %stdout_is_console_status, 0
  store i1 %stdout_is_console, ptr @sollang_stdout_line_buffered, align 1
  %native_library0 = call ptr @LoadLibraryA(ptr @.slg.native.library.name.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F66697874757265)
  %native_library_load_found1 = icmp ne ptr %native_library0, null
  br i1 %native_library_load_found1, label %bb_native_library_load_ok0, label %bb_native_library_load_fail1

bb_native_library_load_fail1:
  %trap_stderr2 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr2, ptr @.slg.str.suffix.0, i32 33, ptr %trap_written3, ptr null)
  call void @llvm.trap()
  unreachable

bb_native_library_load_ok0:
  store ptr %native_library0, ptr @sollang_native_library_x6172746966616374732F636F6D2D696E7465726F702F636F6D5F66697874757265, align 8
  %native_library_handle4 = load ptr, ptr @sollang_native_library_x6172746966616374732F636F6D2D696E7465726F702F636F6D5F66697874757265, align 8
  %native_symbol5 = call ptr @GetProcAddress(ptr %native_library_handle4, ptr @.slg.native.symbol.name.x70726F62652E7265666572656E636573)
  %native_symbol_load_found6 = icmp ne ptr %native_symbol5, null
  br i1 %native_symbol_load_found6, label %bb_native_symbol_load_ok2, label %bb_native_symbol_load_fail3

bb_native_symbol_load_fail3:
  %trap_stderr7 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr7, ptr @.slg.str.suffix.1, i32 32, ptr %trap_written8, ptr null)
  call void @llvm.trap()
  unreachable

bb_native_symbol_load_ok2:
  store ptr %native_symbol5, ptr @sollang_native_function_x70726F62652E7265666572656E636573, align 8
  %com_initialized9 = call i32 @CoInitializeEx(ptr null, i32 4)
  %com_initialized_ok10 = icmp sge i32 %com_initialized9, 0
  br i1 %com_initialized_ok10, label %bb_com_initialize_ok4, label %bb_com_initialize_fail5

bb_com_initialize_fail5:
  %trap_stderr11 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr11, ptr @.slg.str.suffix.2, i32 28, ptr %trap_written12, ptr null)
  call void @llvm.trap()
  unreachable

bb_com_initialize_ok4:
  %com_server13 = call ptr @LoadLibraryA(ptr @.slg.com.server.name.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F66697874757265)
  %com_server_load_found14 = icmp ne ptr %com_server13, null
  br i1 %com_server_load_found14, label %bb_com_server_load_ok6, label %bb_com_server_load_fail7

bb_com_server_load_fail7:
  %trap_stderr15 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr15, ptr @.slg.str.suffix.3, i32 29, ptr %trap_written16, ptr null)
  call void @llvm.trap()
  unreachable

bb_com_server_load_ok6:
  store ptr %com_server13, ptr @.slg.com.server.handle.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F66697874757265, align 8
  %com_dll_get_class_object17 = call ptr @GetProcAddress(ptr %com_server13, ptr @.slg.com.dll_get_class_object_name)
  %com_dll_get_class_object_found18 = icmp ne ptr %com_dll_get_class_object17, null
  br i1 %com_dll_get_class_object_found18, label %bb_com_dll_get_class_object_ok8, label %bb_com_dll_get_class_object_fail9

bb_com_dll_get_class_object_fail9:
  %trap_stderr19 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr19, ptr @.slg.str.suffix.4, i32 38, ptr %trap_written20, ptr null)
  call void @llvm.trap()
  unreachable

bb_com_dll_get_class_object_ok8:
  store ptr %com_dll_get_class_object17, ptr @.slg.com.server.get_class_object.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F66697874757265, align 8
  store ptr null, ptr %com_factory_out21, align 8
  %com_get_class_object22 = load ptr, ptr @.slg.com.server.get_class_object.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F66697874757265, align 8
  %com_factory_status23 = call i32 %com_get_class_object22(ptr @.slg.com.clsid.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F666978747572650038413930453241352D374132442D344532412D393841302D364235433241313243353031, ptr @.slg.com.iid.class_factory, ptr %com_factory_out21)
  %com_factory24 = load ptr, ptr %com_factory_out21, align 8
  %com_factory_status_ok25 = icmp sge i32 %com_factory_status23, 0
  %com_factory_pointer_ok26 = icmp ne ptr %com_factory24, null
  %com_factory_ready27 = and i1 %com_factory_status_ok25, %com_factory_pointer_ok26
  br i1 %com_factory_ready27, label %bb_com_factory_ok10, label %bb_com_factory_fail11

bb_com_factory_fail11:
  %trap_stderr28 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr28, ptr @.slg.str.suffix.5, i32 26, ptr %trap_written29, ptr null)
  call void @llvm.trap()
  unreachable

bb_com_factory_ok10:
  store ptr %com_factory24, ptr @.slg.com.factory.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F666978747572650038413930453241352D374132442D344532412D393841302D364235433241313243353031, align 8
  store ptr null, ptr %com_object_out30, align 8
  %com_factory32 = load ptr, ptr @.slg.com.factory.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F666978747572650038413930453241352D374132442D344532412D393841302D364235433241313243353031, align 8
  %com_create_instance_vtable33 = load ptr, ptr %com_factory32, align 8
  %com_create_instance_slot34 = getelementptr ptr, ptr %com_create_instance_vtable33, i64 3
  %com_create_instance_target35 = load ptr, ptr %com_create_instance_slot34, align 8
  %com_activation_status31 = call i32 %com_create_instance_target35(ptr %com_factory32, ptr null, ptr @.slg.com.iid.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F666978747572650038413930453241352D374132442D344532412D393841302D3642354332413132433530310034433130413437422D373235442D343144332D423541362D373044363744334245423131, ptr %com_object_out30)
  %com_object36 = load ptr, ptr %com_object_out30, align 8
  %com_activation_status_ok37 = icmp sge i32 %com_activation_status31, 0
  %com_activation_pointer_ok38 = icmp ne ptr %com_object36, null
  %com_activation_ok39 = and i1 %com_activation_status_ok37, %com_activation_pointer_ok38
  %com_handle40 = ptrtoint ptr %com_object36 to i64
  %com_interface41 = insertvalue %sollang.struct.1448 poison, i64 %com_handle40, 0
  br i1 %com_activation_ok39, label %bb_com_activation_result_ok12, label %bb_com_activation_result_error13
bb_com_activation_result_ok12:
  store %sollang.enum.2657 zeroinitializer, ptr %enum_init_slot42, align 8
  %enum_tag_addr43 = getelementptr inbounds %sollang.enum.2657, ptr %enum_init_slot42, i32 0, i32 0
  store i32 0, ptr %enum_tag_addr43, align 4
  %enum_payload_addr44 = getelementptr inbounds %sollang.enum.2657, ptr %enum_init_slot42, i32 0, i32 1
  store %sollang.struct.1448 %com_interface41, ptr %enum_payload_addr44, align 8
  %enum_value45 = load %sollang.enum.2657, ptr %enum_init_slot42, align 8
  br label %bb_com_activation_result_end14
bb_com_activation_result_error13:
  store %sollang.enum.2657 zeroinitializer, ptr %enum_init_slot46, align 8
  %enum_tag_addr47 = getelementptr inbounds %sollang.enum.2657, ptr %enum_init_slot46, i32 0, i32 0
  store i32 1, ptr %enum_tag_addr47, align 4
  %enum_payload_addr48 = getelementptr inbounds %sollang.enum.2657, ptr %enum_init_slot46, i32 0, i32 1
  store i32 %com_activation_status31, ptr %enum_payload_addr48, align 4
  %enum_value49 = load %sollang.enum.2657, ptr %enum_init_slot46, align 8
  br label %bb_com_activation_result_end14
bb_com_activation_result_end14:
  %com_activation_result50 = phi %sollang.enum.2657 [ %enum_value45, %bb_com_activation_result_ok12 ], [ %enum_value49, %bb_com_activation_result_error13 ]
  %enum_tag51 = extractvalue %sollang.enum.2657 %com_activation_result50, 0
  %enum_matches52 = icmp eq i32 %enum_tag51, 0
  br i1 %enum_matches52, label %bb_enum_when_arm16, label %bb_enum_when_next17
bb_enum_when_arm16:
  store %sollang.enum.2657 %com_activation_result50, ptr %enum_match_slot53, align 8
  %enum_payload_addr54 = getelementptr inbounds %sollang.enum.2657, ptr %enum_match_slot53, i32 0, i32 1
  %enum_payload55 = load %sollang.struct.1448, ptr %enum_payload_addr54, align 8
  store i1 true, ptr %enum_payload_owned56, align 1
  store %sollang.struct.1448 %enum_payload55, ptr %ref_arg57, align 8
  %ref_value58 = load %sollang.struct.1448, ptr %ref_arg57, align 8
  %com_handle_value59 = extractvalue %sollang.struct.1448 %ref_value58, 0
  %com_handle_pointer60 = inttoptr i64 %com_handle_value59 to ptr
  store i32 zeroinitializer, ptr %com_method_out61, align 4
  %com_method_vtable62 = load ptr, ptr %com_handle_pointer60, align 8
  %com_method_slot63 = getelementptr ptr, ptr %com_method_vtable62, i64 3
  %com_method_target64 = load ptr, ptr %com_method_slot63, align 8
  %com_method_status65 = call i32 %com_method_target64(ptr %com_handle_pointer60, i32 20, i32 22, ptr %com_method_out61)
  %com_method_ok66 = icmp sge i32 %com_method_status65, 0
  %com_method_value67 = load i32, ptr %com_method_out61, align 4
  br i1 %com_method_ok66, label %bb_com_method_result_ok18, label %bb_com_method_result_error19
bb_com_method_result_ok18:
  store %sollang.enum.2659 zeroinitializer, ptr %enum_init_slot68, align 8
  %enum_tag_addr69 = getelementptr inbounds %sollang.enum.2659, ptr %enum_init_slot68, i32 0, i32 0
  store i32 0, ptr %enum_tag_addr69, align 4
  %enum_payload_addr70 = getelementptr inbounds %sollang.enum.2659, ptr %enum_init_slot68, i32 0, i32 1
  store i32 %com_method_value67, ptr %enum_payload_addr70, align 4
  %enum_value71 = load %sollang.enum.2659, ptr %enum_init_slot68, align 8
  br label %bb_com_method_result_end20
bb_com_method_result_error19:
  store %sollang.enum.2659 zeroinitializer, ptr %enum_init_slot72, align 8
  %enum_tag_addr73 = getelementptr inbounds %sollang.enum.2659, ptr %enum_init_slot72, i32 0, i32 0
  store i32 1, ptr %enum_tag_addr73, align 4
  %enum_payload_addr74 = getelementptr inbounds %sollang.enum.2659, ptr %enum_init_slot72, i32 0, i32 1
  store i32 %com_method_status65, ptr %enum_payload_addr74, align 4
  %enum_value75 = load %sollang.enum.2659, ptr %enum_init_slot72, align 8
  br label %bb_com_method_result_end20
bb_com_method_result_end20:
  %com_method_result76 = phi %sollang.enum.2659 [ %enum_value71, %bb_com_method_result_ok18 ], [ %enum_value75, %bb_com_method_result_error19 ]
  %enum_tag77 = extractvalue %sollang.enum.2659 %com_method_result76, 0
  %enum_matches78 = icmp eq i32 %enum_tag77, 0
  br i1 %enum_matches78, label %bb_enum_when_arm22, label %bb_enum_when_next23
bb_enum_when_arm22:
  store %sollang.enum.2659 %com_method_result76, ptr %enum_match_slot79, align 8
  %enum_payload_addr80 = getelementptr inbounds %sollang.enum.2659, ptr %enum_match_slot79, i32 0, i32 1
  %enum_payload81 = load i32, ptr %enum_payload_addr80, align 4
  %write82 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.6, i64 13, ptr %written)
  %is_ok83 = icmp ne i32 %write82, 0
  %previous_ok84 = load i1, ptr %ok_state, align 1
  %ok85 = and i1 %previous_ok84, %is_ok83
  store i1 %ok85, ptr %ok_state, align 1
  %print_integer86 = sext i32 %enum_payload81 to i64
  %write87 = call i32 @sollang_write_i64(ptr %stdout, i64 %print_integer86, ptr %written)
  %is_ok88 = icmp ne i32 %write87, 0
  %previous_ok89 = load i1, ptr %ok_state, align 1
  %ok90 = and i1 %previous_ok89, %is_ok88
  store i1 %ok90, ptr %ok_state, align 1
  %write91 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.7, i64 1, ptr %written)
  %is_ok92 = icmp ne i32 %write91, 0
  %previous_ok93 = load i1, ptr %ok_state, align 1
  %ok94 = and i1 %previous_ok93, %is_ok92
  store i1 %ok94, ptr %ok_state, align 1
  br label %bb_enum_when_end21
bb_enum_when_next23:
  %enum_matches95 = icmp eq i32 %enum_tag77, 1
  br i1 %enum_matches95, label %bb_enum_when_arm24, label %bb_enum_when_next25
bb_enum_when_arm24:
  store %sollang.enum.2659 %com_method_result76, ptr %enum_match_slot96, align 8
  %enum_payload_addr97 = getelementptr inbounds %sollang.enum.2659, ptr %enum_match_slot96, i32 0, i32 1
  %enum_payload98 = load i32, ptr %enum_payload_addr97, align 4
  %write99 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.8, i64 20, ptr %written)
  %is_ok100 = icmp ne i32 %write99, 0
  %previous_ok101 = load i1, ptr %ok_state, align 1
  %ok102 = and i1 %previous_ok101, %is_ok100
  store i1 %ok102, ptr %ok_state, align 1
  %print_integer103 = sext i32 %enum_payload98 to i64
  %write104 = call i32 @sollang_write_i64(ptr %stdout, i64 %print_integer103, ptr %written)
  %is_ok105 = icmp ne i32 %write104, 0
  %previous_ok106 = load i1, ptr %ok_state, align 1
  %ok107 = and i1 %previous_ok106, %is_ok105
  store i1 %ok107, ptr %ok_state, align 1
  %write108 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.9, i64 1, ptr %written)
  %is_ok109 = icmp ne i32 %write108, 0
  %previous_ok110 = load i1, ptr %ok_state, align 1
  %ok111 = and i1 %previous_ok110, %is_ok109
  store i1 %ok111, ptr %ok_state, align 1
  br label %bb_enum_when_end21
bb_enum_when_next25:
  call void @llvm.trap()
  unreachable
bb_enum_when_end21:
  store %sollang.struct.1448 %enum_payload55, ptr %ref_arg57, align 8
  %ref_value112 = load %sollang.struct.1448, ptr %ref_arg57, align 8
  %com_handle_value113 = extractvalue %sollang.struct.1448 %ref_value112, 0
  %com_handle_pointer114 = inttoptr i64 %com_handle_value113 to ptr
  store ptr null, ptr %com_query_out115, align 8
  %com_query_interface_vtable116 = load ptr, ptr %com_handle_pointer114, align 8
  %com_query_interface_slot117 = getelementptr ptr, ptr %com_query_interface_vtable116, i64 0
  %com_query_interface_target118 = load ptr, ptr %com_query_interface_slot117, align 8
  %com_query_status119 = call i32 %com_query_interface_target118(ptr %com_handle_pointer114, ptr @.slg.com.iid.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F666978747572650038413930453241352D374132442D344532412D393841302D3642354332413132433530310042323134413936442D353843462D343331312D413239422D364446383530383031433734, ptr %com_query_out115)
  %com_query_object120 = load ptr, ptr %com_query_out115, align 8
  %com_query_status_ok121 = icmp sge i32 %com_query_status119, 0
  %com_query_pointer_ok122 = icmp ne ptr %com_query_object120, null
  %com_query_ok123 = and i1 %com_query_status_ok121, %com_query_pointer_ok122
  %com_handle124 = ptrtoint ptr %com_query_object120 to i64
  %com_interface125 = insertvalue %sollang.struct.1449 poison, i64 %com_handle124, 0
  br i1 %com_query_ok123, label %bb_com_query_result_ok26, label %bb_com_query_result_error27
bb_com_query_result_ok26:
  store %sollang.enum.2660 zeroinitializer, ptr %enum_init_slot126, align 8
  %enum_tag_addr127 = getelementptr inbounds %sollang.enum.2660, ptr %enum_init_slot126, i32 0, i32 0
  store i32 0, ptr %enum_tag_addr127, align 4
  %enum_payload_addr128 = getelementptr inbounds %sollang.enum.2660, ptr %enum_init_slot126, i32 0, i32 1
  store %sollang.struct.1449 %com_interface125, ptr %enum_payload_addr128, align 8
  %enum_value129 = load %sollang.enum.2660, ptr %enum_init_slot126, align 8
  br label %bb_com_query_result_end28
bb_com_query_result_error27:
  store %sollang.enum.2660 zeroinitializer, ptr %enum_init_slot130, align 8
  %enum_tag_addr131 = getelementptr inbounds %sollang.enum.2660, ptr %enum_init_slot130, i32 0, i32 0
  store i32 1, ptr %enum_tag_addr131, align 4
  %enum_payload_addr132 = getelementptr inbounds %sollang.enum.2660, ptr %enum_init_slot130, i32 0, i32 1
  store i32 %com_query_status119, ptr %enum_payload_addr132, align 4
  %enum_value133 = load %sollang.enum.2660, ptr %enum_init_slot130, align 8
  br label %bb_com_query_result_end28
bb_com_query_result_end28:
  %com_query_result134 = phi %sollang.enum.2660 [ %enum_value129, %bb_com_query_result_ok26 ], [ %enum_value133, %bb_com_query_result_error27 ]
  %enum_tag135 = extractvalue %sollang.enum.2660 %com_query_result134, 0
  %enum_matches136 = icmp eq i32 %enum_tag135, 0
  br i1 %enum_matches136, label %bb_enum_when_arm30, label %bb_enum_when_next31
bb_enum_when_arm30:
  store %sollang.enum.2660 %com_query_result134, ptr %enum_match_slot137, align 8
  %enum_payload_addr138 = getelementptr inbounds %sollang.enum.2660, ptr %enum_match_slot137, i32 0, i32 1
  %enum_payload139 = load %sollang.struct.1449, ptr %enum_payload_addr138, align 8
  store i1 true, ptr %enum_payload_owned140, align 1
  store %sollang.struct.1449 %enum_payload139, ptr %ref_arg141, align 8
  %ref_value142 = load %sollang.struct.1449, ptr %ref_arg141, align 8
  %com_handle_value143 = extractvalue %sollang.struct.1449 %ref_value142, 0
  %com_handle_pointer144 = inttoptr i64 %com_handle_value143 to ptr
  store i32 zeroinitializer, ptr %com_method_out145, align 4
  %com_method_vtable146 = load ptr, ptr %com_handle_pointer144, align 8
  %com_method_slot147 = getelementptr ptr, ptr %com_method_vtable146, i64 3
  %com_method_target148 = load ptr, ptr %com_method_slot147, align 8
  %com_method_status149 = call i32 %com_method_target148(ptr %com_handle_pointer144, i32 21, i32 21, ptr %com_method_out145)
  %com_method_ok150 = icmp sge i32 %com_method_status149, 0
  %com_method_value151 = load i32, ptr %com_method_out145, align 4
  br i1 %com_method_ok150, label %bb_com_method_result_ok32, label %bb_com_method_result_error33
bb_com_method_result_ok32:
  store %sollang.enum.2659 zeroinitializer, ptr %enum_init_slot152, align 8
  %enum_tag_addr153 = getelementptr inbounds %sollang.enum.2659, ptr %enum_init_slot152, i32 0, i32 0
  store i32 0, ptr %enum_tag_addr153, align 4
  %enum_payload_addr154 = getelementptr inbounds %sollang.enum.2659, ptr %enum_init_slot152, i32 0, i32 1
  store i32 %com_method_value151, ptr %enum_payload_addr154, align 4
  %enum_value155 = load %sollang.enum.2659, ptr %enum_init_slot152, align 8
  br label %bb_com_method_result_end34
bb_com_method_result_error33:
  store %sollang.enum.2659 zeroinitializer, ptr %enum_init_slot156, align 8
  %enum_tag_addr157 = getelementptr inbounds %sollang.enum.2659, ptr %enum_init_slot156, i32 0, i32 0
  store i32 1, ptr %enum_tag_addr157, align 4
  %enum_payload_addr158 = getelementptr inbounds %sollang.enum.2659, ptr %enum_init_slot156, i32 0, i32 1
  store i32 %com_method_status149, ptr %enum_payload_addr158, align 4
  %enum_value159 = load %sollang.enum.2659, ptr %enum_init_slot156, align 8
  br label %bb_com_method_result_end34
bb_com_method_result_end34:
  %com_method_result160 = phi %sollang.enum.2659 [ %enum_value155, %bb_com_method_result_ok32 ], [ %enum_value159, %bb_com_method_result_error33 ]
  %enum_tag161 = extractvalue %sollang.enum.2659 %com_method_result160, 0
  %enum_matches162 = icmp eq i32 %enum_tag161, 0
  br i1 %enum_matches162, label %bb_enum_when_arm36, label %bb_enum_when_next37
bb_enum_when_arm36:
  store %sollang.enum.2659 %com_method_result160, ptr %enum_match_slot163, align 8
  %enum_payload_addr164 = getelementptr inbounds %sollang.enum.2659, ptr %enum_match_slot163, i32 0, i32 1
  %enum_payload165 = load i32, ptr %enum_payload_addr164, align 4
  %write166 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.10, i64 19, ptr %written)
  %is_ok167 = icmp ne i32 %write166, 0
  %previous_ok168 = load i1, ptr %ok_state, align 1
  %ok169 = and i1 %previous_ok168, %is_ok167
  store i1 %ok169, ptr %ok_state, align 1
  %print_integer170 = sext i32 %enum_payload165 to i64
  %write171 = call i32 @sollang_write_i64(ptr %stdout, i64 %print_integer170, ptr %written)
  %is_ok172 = icmp ne i32 %write171, 0
  %previous_ok173 = load i1, ptr %ok_state, align 1
  %ok174 = and i1 %previous_ok173, %is_ok172
  store i1 %ok174, ptr %ok_state, align 1
  %write175 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.11, i64 1, ptr %written)
  %is_ok176 = icmp ne i32 %write175, 0
  %previous_ok177 = load i1, ptr %ok_state, align 1
  %ok178 = and i1 %previous_ok177, %is_ok176
  store i1 %ok178, ptr %ok_state, align 1
  br label %bb_enum_when_end35
bb_enum_when_next37:
  %enum_matches179 = icmp eq i32 %enum_tag161, 1
  br i1 %enum_matches179, label %bb_enum_when_arm38, label %bb_enum_when_next39
bb_enum_when_arm38:
  store %sollang.enum.2659 %com_method_result160, ptr %enum_match_slot180, align 8
  %enum_payload_addr181 = getelementptr inbounds %sollang.enum.2659, ptr %enum_match_slot180, i32 0, i32 1
  %enum_payload182 = load i32, ptr %enum_payload_addr181, align 4
  %write183 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.12, i64 28, ptr %written)
  %is_ok184 = icmp ne i32 %write183, 0
  %previous_ok185 = load i1, ptr %ok_state, align 1
  %ok186 = and i1 %previous_ok185, %is_ok184
  store i1 %ok186, ptr %ok_state, align 1
  %print_integer187 = sext i32 %enum_payload182 to i64
  %write188 = call i32 @sollang_write_i64(ptr %stdout, i64 %print_integer187, ptr %written)
  %is_ok189 = icmp ne i32 %write188, 0
  %previous_ok190 = load i1, ptr %ok_state, align 1
  %ok191 = and i1 %previous_ok190, %is_ok189
  store i1 %ok191, ptr %ok_state, align 1
  %write192 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.13, i64 1, ptr %written)
  %is_ok193 = icmp ne i32 %write192, 0
  %previous_ok194 = load i1, ptr %ok_state, align 1
  %ok195 = and i1 %previous_ok194, %is_ok193
  store i1 %ok195, ptr %ok_state, align 1
  br label %bb_enum_when_end35
bb_enum_when_next39:
  call void @llvm.trap()
  unreachable
bb_enum_when_end35:
  %enum_payload_retained196 = load i1, ptr %enum_payload_owned140, align 1
  br i1 %enum_payload_retained196, label %bb_enum_payload_drop40, label %bb_enum_payload_drop_done41

bb_enum_payload_drop40:
  call void @sollang_drop_1449(%sollang.struct.1449 %enum_payload139)
  br label %bb_enum_payload_drop_done41

bb_enum_payload_drop_done41:
  br label %bb_enum_when_end29
bb_enum_when_next31:
  %enum_matches197 = icmp eq i32 %enum_tag135, 1
  br i1 %enum_matches197, label %bb_enum_when_arm42, label %bb_enum_when_next43
bb_enum_when_arm42:
  store %sollang.enum.2660 %com_query_result134, ptr %enum_match_slot198, align 8
  %enum_payload_addr199 = getelementptr inbounds %sollang.enum.2660, ptr %enum_match_slot198, i32 0, i32 1
  %enum_payload200 = load i32, ptr %enum_payload_addr199, align 4
  %write201 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.14, i64 19, ptr %written)
  %is_ok202 = icmp ne i32 %write201, 0
  %previous_ok203 = load i1, ptr %ok_state, align 1
  %ok204 = and i1 %previous_ok203, %is_ok202
  store i1 %ok204, ptr %ok_state, align 1
  %print_integer205 = sext i32 %enum_payload200 to i64
  %write206 = call i32 @sollang_write_i64(ptr %stdout, i64 %print_integer205, ptr %written)
  %is_ok207 = icmp ne i32 %write206, 0
  %previous_ok208 = load i1, ptr %ok_state, align 1
  %ok209 = and i1 %previous_ok208, %is_ok207
  store i1 %ok209, ptr %ok_state, align 1
  %write210 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.15, i64 1, ptr %written)
  %is_ok211 = icmp ne i32 %write210, 0
  %previous_ok212 = load i1, ptr %ok_state, align 1
  %ok213 = and i1 %previous_ok212, %is_ok211
  store i1 %ok213, ptr %ok_state, align 1
  br label %bb_enum_when_end29
bb_enum_when_next43:
  call void @llvm.trap()
  unreachable
bb_enum_when_end29:
  store %sollang.struct.1448 %enum_payload55, ptr %ref_arg57, align 8
  %ref_value214 = load %sollang.struct.1448, ptr %ref_arg57, align 8
  %com_handle_value215 = extractvalue %sollang.struct.1448 %ref_value214, 0
  %com_handle_pointer216 = inttoptr i64 %com_handle_value215 to ptr
  store ptr null, ptr %com_query_out217, align 8
  %com_query_interface_vtable218 = load ptr, ptr %com_handle_pointer216, align 8
  %com_query_interface_slot219 = getelementptr ptr, ptr %com_query_interface_vtable218, i64 0
  %com_query_interface_target220 = load ptr, ptr %com_query_interface_slot219, align 8
  %com_query_status221 = call i32 %com_query_interface_target220(ptr %com_handle_pointer216, ptr @.slg.com.iid.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F666978747572650038413930453241352D374132442D344532412D393841302D3642354332413132433530310034433645453034462D424143412D344445372D393145452D454135364343393744313041, ptr %com_query_out217)
  %com_query_object222 = load ptr, ptr %com_query_out217, align 8
  %com_query_status_ok223 = icmp sge i32 %com_query_status221, 0
  %com_query_pointer_ok224 = icmp ne ptr %com_query_object222, null
  %com_query_ok225 = and i1 %com_query_status_ok223, %com_query_pointer_ok224
  %com_handle226 = ptrtoint ptr %com_query_object222 to i64
  %com_interface227 = insertvalue %sollang.struct.1450 poison, i64 %com_handle226, 0
  br i1 %com_query_ok225, label %bb_com_query_result_ok44, label %bb_com_query_result_error45
bb_com_query_result_ok44:
  store %sollang.enum.2662 zeroinitializer, ptr %enum_init_slot228, align 8
  %enum_tag_addr229 = getelementptr inbounds %sollang.enum.2662, ptr %enum_init_slot228, i32 0, i32 0
  store i32 0, ptr %enum_tag_addr229, align 4
  %enum_payload_addr230 = getelementptr inbounds %sollang.enum.2662, ptr %enum_init_slot228, i32 0, i32 1
  store %sollang.struct.1450 %com_interface227, ptr %enum_payload_addr230, align 8
  %enum_value231 = load %sollang.enum.2662, ptr %enum_init_slot228, align 8
  br label %bb_com_query_result_end46
bb_com_query_result_error45:
  store %sollang.enum.2662 zeroinitializer, ptr %enum_init_slot232, align 8
  %enum_tag_addr233 = getelementptr inbounds %sollang.enum.2662, ptr %enum_init_slot232, i32 0, i32 0
  store i32 1, ptr %enum_tag_addr233, align 4
  %enum_payload_addr234 = getelementptr inbounds %sollang.enum.2662, ptr %enum_init_slot232, i32 0, i32 1
  store i32 %com_query_status221, ptr %enum_payload_addr234, align 4
  %enum_value235 = load %sollang.enum.2662, ptr %enum_init_slot232, align 8
  br label %bb_com_query_result_end46
bb_com_query_result_end46:
  %com_query_result236 = phi %sollang.enum.2662 [ %enum_value231, %bb_com_query_result_ok44 ], [ %enum_value235, %bb_com_query_result_error45 ]
  %enum_tag237 = extractvalue %sollang.enum.2662 %com_query_result236, 0
  %enum_matches238 = icmp eq i32 %enum_tag237, 0
  br i1 %enum_matches238, label %bb_enum_when_arm48, label %bb_enum_when_next49
bb_enum_when_arm48:
  store %sollang.enum.2662 %com_query_result236, ptr %enum_match_slot239, align 8
  %enum_payload_addr240 = getelementptr inbounds %sollang.enum.2662, ptr %enum_match_slot239, i32 0, i32 1
  %enum_payload241 = load %sollang.struct.1450, ptr %enum_payload_addr240, align 8
  store i1 true, ptr %enum_payload_owned242, align 1
  %write243 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.16, i64 24, ptr %written)
  %is_ok244 = icmp ne i32 %write243, 0
  %previous_ok245 = load i1, ptr %ok_state, align 1
  %ok246 = and i1 %previous_ok245, %is_ok244
  store i1 %ok246, ptr %ok_state, align 1
  %write247 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.17, i64 1, ptr %written)
  %is_ok248 = icmp ne i32 %write247, 0
  %previous_ok249 = load i1, ptr %ok_state, align 1
  %ok250 = and i1 %previous_ok249, %is_ok248
  store i1 %ok250, ptr %ok_state, align 1
  %enum_payload_retained251 = load i1, ptr %enum_payload_owned242, align 1
  br i1 %enum_payload_retained251, label %bb_enum_payload_drop50, label %bb_enum_payload_drop_done51

bb_enum_payload_drop50:
  call void @sollang_drop_1450(%sollang.struct.1450 %enum_payload241)
  br label %bb_enum_payload_drop_done51

bb_enum_payload_drop_done51:
  br label %bb_enum_when_end47
bb_enum_when_next49:
  %enum_matches252 = icmp eq i32 %enum_tag237, 1
  br i1 %enum_matches252, label %bb_enum_when_arm52, label %bb_enum_when_next53
bb_enum_when_arm52:
  store %sollang.enum.2662 %com_query_result236, ptr %enum_match_slot253, align 8
  %enum_payload_addr254 = getelementptr inbounds %sollang.enum.2662, ptr %enum_match_slot253, i32 0, i32 1
  %enum_payload255 = load i32, ptr %enum_payload_addr254, align 4
  %write256 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.18, i64 20, ptr %written)
  %is_ok257 = icmp ne i32 %write256, 0
  %previous_ok258 = load i1, ptr %ok_state, align 1
  %ok259 = and i1 %previous_ok258, %is_ok257
  store i1 %ok259, ptr %ok_state, align 1
  %print_integer260 = sext i32 %enum_payload255 to i64
  %write261 = call i32 @sollang_write_i64(ptr %stdout, i64 %print_integer260, ptr %written)
  %is_ok262 = icmp ne i32 %write261, 0
  %previous_ok263 = load i1, ptr %ok_state, align 1
  %ok264 = and i1 %previous_ok263, %is_ok262
  store i1 %ok264, ptr %ok_state, align 1
  %write265 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.19, i64 1, ptr %written)
  %is_ok266 = icmp ne i32 %write265, 0
  %previous_ok267 = load i1, ptr %ok_state, align 1
  %ok268 = and i1 %previous_ok267, %is_ok266
  store i1 %ok268, ptr %ok_state, align 1
  br label %bb_enum_when_end47
bb_enum_when_next53:
  call void @llvm.trap()
  unreachable
bb_enum_when_end47:
  store %sollang.struct.1448 %enum_payload55, ptr %ref_arg57, align 8
  %ref_value269 = load %sollang.struct.1448, ptr %ref_arg57, align 8
  %com_handle_value270 = extractvalue %sollang.struct.1448 %ref_value269, 0
  %com_handle_pointer271 = inttoptr i64 %com_handle_value270 to ptr
  %com_add_ref_vtable272 = load ptr, ptr %com_handle_pointer271, align 8
  %com_add_ref_slot273 = getelementptr ptr, ptr %com_add_ref_vtable272, i64 1
  %com_add_ref_target274 = load ptr, ptr %com_add_ref_slot273, align 8
  %com_reference_count275 = call i32 %com_add_ref_target274(ptr %com_handle_pointer271)
  %com_handle276 = ptrtoint ptr %com_handle_pointer271 to i64
  %com_interface277 = insertvalue %sollang.struct.1448 poison, i64 %com_handle276, 0
  store %sollang.struct.1448 %com_interface277, ptr %ref_arg278, align 8
  %ref_value279 = load %sollang.struct.1448, ptr %ref_arg278, align 8
  %com_handle_value280 = extractvalue %sollang.struct.1448 %ref_value279, 0
  %com_handle_pointer281 = inttoptr i64 %com_handle_value280 to ptr
  store i32 zeroinitializer, ptr %com_method_out282, align 4
  %com_method_vtable283 = load ptr, ptr %com_handle_pointer281, align 8
  %com_method_slot284 = getelementptr ptr, ptr %com_method_vtable283, i64 3
  %com_method_target285 = load ptr, ptr %com_method_slot284, align 8
  %com_method_status286 = call i32 %com_method_target285(ptr %com_handle_pointer281, i32 19, i32 23, ptr %com_method_out282)
  %com_method_ok287 = icmp sge i32 %com_method_status286, 0
  %com_method_value288 = load i32, ptr %com_method_out282, align 4
  br i1 %com_method_ok287, label %bb_com_method_result_ok54, label %bb_com_method_result_error55
bb_com_method_result_ok54:
  store %sollang.enum.2659 zeroinitializer, ptr %enum_init_slot289, align 8
  %enum_tag_addr290 = getelementptr inbounds %sollang.enum.2659, ptr %enum_init_slot289, i32 0, i32 0
  store i32 0, ptr %enum_tag_addr290, align 4
  %enum_payload_addr291 = getelementptr inbounds %sollang.enum.2659, ptr %enum_init_slot289, i32 0, i32 1
  store i32 %com_method_value288, ptr %enum_payload_addr291, align 4
  %enum_value292 = load %sollang.enum.2659, ptr %enum_init_slot289, align 8
  br label %bb_com_method_result_end56
bb_com_method_result_error55:
  store %sollang.enum.2659 zeroinitializer, ptr %enum_init_slot293, align 8
  %enum_tag_addr294 = getelementptr inbounds %sollang.enum.2659, ptr %enum_init_slot293, i32 0, i32 0
  store i32 1, ptr %enum_tag_addr294, align 4
  %enum_payload_addr295 = getelementptr inbounds %sollang.enum.2659, ptr %enum_init_slot293, i32 0, i32 1
  store i32 %com_method_status286, ptr %enum_payload_addr295, align 4
  %enum_value296 = load %sollang.enum.2659, ptr %enum_init_slot293, align 8
  br label %bb_com_method_result_end56
bb_com_method_result_end56:
  %com_method_result297 = phi %sollang.enum.2659 [ %enum_value292, %bb_com_method_result_ok54 ], [ %enum_value296, %bb_com_method_result_error55 ]
  %enum_tag298 = extractvalue %sollang.enum.2659 %com_method_result297, 0
  %enum_matches299 = icmp eq i32 %enum_tag298, 0
  br i1 %enum_matches299, label %bb_enum_when_arm58, label %bb_enum_when_next59
bb_enum_when_arm58:
  store %sollang.enum.2659 %com_method_result297, ptr %enum_match_slot300, align 8
  %enum_payload_addr301 = getelementptr inbounds %sollang.enum.2659, ptr %enum_match_slot300, i32 0, i32 1
  %enum_payload302 = load i32, ptr %enum_payload_addr301, align 4
  %write303 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.20, i64 19, ptr %written)
  %is_ok304 = icmp ne i32 %write303, 0
  %previous_ok305 = load i1, ptr %ok_state, align 1
  %ok306 = and i1 %previous_ok305, %is_ok304
  store i1 %ok306, ptr %ok_state, align 1
  %print_integer307 = sext i32 %enum_payload302 to i64
  %write308 = call i32 @sollang_write_i64(ptr %stdout, i64 %print_integer307, ptr %written)
  %is_ok309 = icmp ne i32 %write308, 0
  %previous_ok310 = load i1, ptr %ok_state, align 1
  %ok311 = and i1 %previous_ok310, %is_ok309
  store i1 %ok311, ptr %ok_state, align 1
  %write312 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.21, i64 1, ptr %written)
  %is_ok313 = icmp ne i32 %write312, 0
  %previous_ok314 = load i1, ptr %ok_state, align 1
  %ok315 = and i1 %previous_ok314, %is_ok313
  store i1 %ok315, ptr %ok_state, align 1
  br label %bb_enum_when_end57
bb_enum_when_next59:
  %enum_matches316 = icmp eq i32 %enum_tag298, 1
  br i1 %enum_matches316, label %bb_enum_when_arm60, label %bb_enum_when_next61
bb_enum_when_arm60:
  store %sollang.enum.2659 %com_method_result297, ptr %enum_match_slot317, align 8
  %enum_payload_addr318 = getelementptr inbounds %sollang.enum.2659, ptr %enum_match_slot317, i32 0, i32 1
  %enum_payload319 = load i32, ptr %enum_payload_addr318, align 4
  %write320 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.22, i64 26, ptr %written)
  %is_ok321 = icmp ne i32 %write320, 0
  %previous_ok322 = load i1, ptr %ok_state, align 1
  %ok323 = and i1 %previous_ok322, %is_ok321
  store i1 %ok323, ptr %ok_state, align 1
  %print_integer324 = sext i32 %enum_payload319 to i64
  %write325 = call i32 @sollang_write_i64(ptr %stdout, i64 %print_integer324, ptr %written)
  %is_ok326 = icmp ne i32 %write325, 0
  %previous_ok327 = load i1, ptr %ok_state, align 1
  %ok328 = and i1 %previous_ok327, %is_ok326
  store i1 %ok328, ptr %ok_state, align 1
  %write329 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.23, i64 1, ptr %written)
  %is_ok330 = icmp ne i32 %write329, 0
  %previous_ok331 = load i1, ptr %ok_state, align 1
  %ok332 = and i1 %previous_ok331, %is_ok330
  store i1 %ok332, ptr %ok_state, align 1
  br label %bb_enum_when_end57
bb_enum_when_next61:
  call void @llvm.trap()
  unreachable
bb_enum_when_end57:
  call void @sollang_drop_1448(%sollang.struct.1448 %com_interface277)
  %enum_payload_retained333 = load i1, ptr %enum_payload_owned56, align 1
  br i1 %enum_payload_retained333, label %bb_enum_payload_drop62, label %bb_enum_payload_drop_done63

bb_enum_payload_drop62:
  call void @sollang_drop_1448(%sollang.struct.1448 %enum_payload55)
  br label %bb_enum_payload_drop_done63

bb_enum_payload_drop_done63:
  br label %bb_enum_when_end15
bb_enum_when_next17:
  %enum_matches334 = icmp eq i32 %enum_tag51, 1
  br i1 %enum_matches334, label %bb_enum_when_arm64, label %bb_enum_when_next65
bb_enum_when_arm64:
  store %sollang.enum.2657 %com_activation_result50, ptr %enum_match_slot335, align 8
  %enum_payload_addr336 = getelementptr inbounds %sollang.enum.2657, ptr %enum_match_slot335, i32 0, i32 1
  %enum_payload337 = load i32, ptr %enum_payload_addr336, align 4
  %write338 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.24, i64 24, ptr %written)
  %is_ok339 = icmp ne i32 %write338, 0
  %previous_ok340 = load i1, ptr %ok_state, align 1
  %ok341 = and i1 %previous_ok340, %is_ok339
  store i1 %ok341, ptr %ok_state, align 1
  %print_integer342 = sext i32 %enum_payload337 to i64
  %write343 = call i32 @sollang_write_i64(ptr %stdout, i64 %print_integer342, ptr %written)
  %is_ok344 = icmp ne i32 %write343, 0
  %previous_ok345 = load i1, ptr %ok_state, align 1
  %ok346 = and i1 %previous_ok345, %is_ok344
  store i1 %ok346, ptr %ok_state, align 1
  %write347 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.25, i64 1, ptr %written)
  %is_ok348 = icmp ne i32 %write347, 0
  %previous_ok349 = load i1, ptr %ok_state, align 1
  %ok350 = and i1 %previous_ok349, %is_ok348
  store i1 %ok350, ptr %ok_state, align 1
  br label %bb_enum_when_end15
bb_enum_when_next65:
  call void @llvm.trap()
  unreachable
bb_enum_when_end15:
  %native_target351 = load ptr, ptr @sollang_native_function_x70726F62652E7265666572656E636573, align 8
  %native_result352 = call i32 %native_target351()
  %write353 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.26, i64 29, ptr %written)
  %is_ok354 = icmp ne i32 %write353, 0
  %previous_ok355 = load i1, ptr %ok_state, align 1
  %ok356 = and i1 %previous_ok355, %is_ok354
  store i1 %ok356, ptr %ok_state, align 1
  %print_integer357 = sext i32 %native_result352 to i64
  %write358 = call i32 @sollang_write_i64(ptr %stdout, i64 %print_integer357, ptr %written)
  %is_ok359 = icmp ne i32 %write358, 0
  %previous_ok360 = load i1, ptr %ok_state, align 1
  %ok361 = and i1 %previous_ok360, %is_ok359
  store i1 %ok361, ptr %ok_state, align 1
  %write362 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.27, i64 1, ptr %written)
  %is_ok363 = icmp ne i32 %write362, 0
  %previous_ok364 = load i1, ptr %ok_state, align 1
  %ok365 = and i1 %previous_ok364, %is_ok363
  store i1 %ok365, ptr %ok_state, align 1
  %native_library_close366 = load ptr, ptr @sollang_native_library_x6172746966616374732F636F6D2D696E7465726F702F636F6D5F66697874757265, align 8
  %native_library_closed367 = call i32 @FreeLibrary(ptr %native_library_close366)
  %com_factory_close368 = load ptr, ptr @.slg.com.factory.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F666978747572650038413930453241352D374132442D344532412D393841302D364235433241313243353031, align 8
  %com_release_vtable369 = load ptr, ptr %com_factory_close368, align 8
  %com_release_slot370 = getelementptr ptr, ptr %com_release_vtable369, i64 2
  %com_release_target371 = load ptr, ptr %com_release_slot370, align 8
  %com_reference_count372 = call i32 %com_release_target371(ptr %com_factory_close368)
  %com_server_close373 = load ptr, ptr @.slg.com.server.handle.x6172746966616374732F636F6D2D696E7465726F702F636F6D5F66697874757265, align 8
  %com_server_closed374 = call i32 @FreeLibrary(ptr %com_server_close373)
  call void @CoUninitialize()
  %stdout_flushed = call i32 @sollang_flush_stdout(ptr %stdout, ptr %written)
  %final_ok375 = load i1, ptr %ok_state, align 1
  %exit376 = select i1 %final_ok375, i32 0, i32 1
  ret i32 %exit376
}

attributes #0 = { nounwind }

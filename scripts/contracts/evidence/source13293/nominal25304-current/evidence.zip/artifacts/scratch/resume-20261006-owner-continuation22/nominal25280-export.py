from pathlib import Path
import json,sys,hashlib
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output,cleanup_output
C=B/'nominal25274-managed/compiler/Sollang.Compiler.exe';O=B/'nominal25280-export';reuse=[B/'storage25227-native',B/'ownership25157-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir()
program=O/'Program.cs';program.write_text('return SelfHostPolicyTests.Run(args[0], args[1]);\n',encoding='utf-8');project=O/'PolicyHarness.csproj';project.write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net11.0</TargetFramework><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><EnableDefaultCompileItems>false</EnableDefaultCompileItems></PropertyGroup><ItemGroup>'+''.join('<Compile Include="'+str(p)+'" />' for p in [program,R/'tests/Sollang.ExampleTests/SelfHostPolicyTests.cs',R/'tests/Sollang.ExampleTests/AtomicResultFile.cs'])+'</ItemGroup></Project>\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();paths=[Path(__file__),project,program,*[R/'tests/Sollang.ExampleTests'/n for n in ['SelfHostPolicyTests.cs','AtomicResultFile.cs']],R/'src/Sollang.Compiler/Cli/SelfHostPolicyCompiler.cs',*[R/'src/Sollang.Compiler/Semantics'/n for n in ['BuiltinTypeDefinitions.cs','SemanticTypeDisplayNames.cs','SemanticTypeRegistrationNames.cs']],R/'src/Sollang.Compiler/Semantics/BoundProgram.cs',R/'src/Sollang.Compiler/Shared/SelfHostPolicyAttribute.cs',*sorted((R/'src/Sollang.Compiler/Shared/Policies').glob('*.cs')),*managed_runtime_inputs(C),R/'selfhost/semantic/reference_type_ids.slg',R/'selfhost/semantic/type_name_policy.slg',*sorted((R/'selfhost/semantic/generated').glob('*.slg')),*sorted((R/'selfhost/llvm/generated').glob('*.slg')),R/'selfhost/generated/windows_link_policy.slg',R/'selfhost/llvm/runtime.slg'];pins={str(p.resolve()):sha(p) for p in paths}
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=68,inputHashes=pins,cases=[],scope='Reuse production policy exporter68 controls; extend existing runtime probe to BlockValueContractPolicy and WindowsLinkPolicy. No parity-runtime or source-phase completion yet.',claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  done=ex.run(['dotnet','build',str(project),'-c','Release','-o',str(O/'runner'),'--nologo','/nodeReuse:false','/p:UseSharedCompilation=false'],O/'runner.build',timeout=60);assert done.returncode==0 and not done.stderr,done.stdout+done.stderr
  done=ex.run(['dotnet',str(O/'runner/PolicyHarness.dll'),str(C.with_suffix('.dll')),str(O/'policy-tests.json')],O/'export',timeout=60);assert done.returncode==0 and not done.stderr,done.stdout+done.stderr
  inner=json.loads((O/'policy-tests.json').read_text());assert inner['status']=='passed' and inner['completed']==inner['total']==68 and len(set(inner['cases']))==68,inner
  contract=json.loads(Path(inner['runtimeProbeContract']).read_text());case=contract['cases'][0];assert len(case['additionalSources'])==10 and 'BlockValueContractPolicy.AcceptsValue:' in case['stdout'] and 'WindowsLinkPolicy.ImportLibraries:' in case['stdout']
  result.update(status='passed',completed=68,cases=[dict(id=name,passed=True) for name in inner['cases']],runtimeProbeContract=inner['runtimeProbeContract'],runtimePolicyModules=9,expectedStdoutSha256=hashlib.sha256(case['stdout'].encode()).hexdigest().upper(),runtimeExecutionPending=True)
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reuse)
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped','runtimePolicyModules']}))

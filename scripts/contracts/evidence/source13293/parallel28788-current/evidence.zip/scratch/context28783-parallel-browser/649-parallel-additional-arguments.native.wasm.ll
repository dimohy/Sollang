; sollang workers = 1
; sollang.codegen.unit 0:
; sollang.codegen.key 1931366173152882045:12306777125250943370
target datalayout = "e-m:e-p:32:32-p10:8:8-p20:8:8-i64:64-i128:128-n32:64-S128-ni:1:10:20"
target triple = "wasm32-unknown-unknown-wasm"
declare i32 @sollang_browser_alloc(i64)
declare void @sollang_browser_panic(ptr, i32)
define ptr @sollang_alloc(i64 %bytes) {
entry:
  %value32 = call i32 @sollang_browser_alloc(i64 %bytes)
  %value = inttoptr i32 %value32 to ptr
  ret ptr %value
}
define internal void @sollang_free(ptr %value) {
entry:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1 immarg)
@sollang_runtime_newline = private constant [1 x i8] c"\0A"
declare i32 @sollang_browser_write(ptr, i32)
declare i32 @sollang_browser_read(ptr, i32)
declare i64 @sollang_browser_now_millis()
declare i64 @sollang_browser_utc_now_millis()
define internal i64 @sollang_now_millis() {
entry:
  %value = call i64 @sollang_browser_now_millis()
  ret i64 %value
}
define internal i64 @sollang_utc_now_millis() {
entry:
  %value = call i64 @sollang_browser_utc_now_millis()
  ret i64 %value
}
define internal void @sollang_runtime_flush_stdout() {
entry:
  ret void
}
define internal i32 @sollang_write(ptr %stdout, ptr %data, i64 %len64, ptr %written) {
entry:
  %too_large = icmp ugt i64 %len64, 2147483647
  br i1 %too_large, label %fail, label %write
write:
  %len = trunc i64 %len64 to i32
  %ok = call i32 @sollang_browser_write(ptr %data, i32 %len)
  %is_ok = icmp ne i32 %ok, 0
  br i1 %is_ok, label %success, label %fail
success:
  store i32 %len, ptr %written, align 4
  ret i32 1
fail:
  store i32 0, ptr %written, align 4
  ret i32 0
}
define internal void @sollang_runtime_print(ptr %stdout, ptr %written, ptr %ok_state, ptr %data, i64 %len, i1 %newline) {
entry:
  %data_status = call i32 @sollang_write(ptr %stdout, ptr %data, i64 %len, ptr %written)
  %data_ok = icmp ne i32 %data_status, 0
  br i1 %newline, label %write_newline, label %done
write_newline:
  %newline_status = call i32 @sollang_write(ptr %stdout, ptr @sollang_runtime_newline, i64 1, ptr %written)
  %newline_ok = icmp ne i32 %newline_status, 0
  %combined = and i1 %data_ok, %newline_ok
  br label %done
done:
  %ok = phi i1 [ %data_ok, %entry ], [ %combined, %write_newline ]
  %previous = load i1, ptr %ok_state, align 1
  %next = and i1 %previous, %ok
  store i1 %next, ptr %ok_state, align 1
  ret void
}
define internal i32 @sollang_runtime_read_int(ptr %stdout, ptr %written, ptr %read, ptr %ok_state, ptr %prompt, i64 %prompt_len) {
entry:
  call void @sollang_runtime_print(ptr %stdout, ptr %written, ptr %ok_state, ptr %prompt, i64 %prompt_len, i1 false)
  %buf = alloca [64 x i8], align 1
  %count = call i32 @sollang_browser_read(ptr %buf, i32 64)
  %has_input = icmp sgt i32 %count, 0
  br i1 %has_input, label %skip_header, label %empty
skip_header:
  br label %skip
skip:
  %skip_index = phi i32 [ 0, %skip_header ], [ %skip_next, %skip_space ]
  %skip_in_bounds = icmp slt i32 %skip_index, %count
  br i1 %skip_in_bounds, label %skip_check, label %empty
skip_check:
  %skip_ptr = getelementptr i8, ptr %buf, i32 %skip_index
  %skip_byte = load i8, ptr %skip_ptr, align 1
  %is_space = icmp eq i8 %skip_byte, 32
  %is_tab = icmp eq i8 %skip_byte, 9
  %is_newline = icmp eq i8 %skip_byte, 10
  %space_or_tab = or i1 %is_space, %is_tab
  %is_whitespace = or i1 %space_or_tab, %is_newline
  br i1 %is_whitespace, label %skip_space, label %sign
skip_space:
  %skip_next = add i32 %skip_index, 1
  br label %skip
sign:
  %is_minus = icmp eq i8 %skip_byte, 45
  %digit_start_delta = zext i1 %is_minus to i32
  %digit_start = add i32 %skip_index, %digit_start_delta
  br label %digits
digits:
  %digit_index = phi i32 [ %digit_start, %sign ], [ %digit_next, %accumulate ]
  %value = phi i32 [ 0, %sign ], [ %next_value, %accumulate ]
  %digit_in_bounds = icmp slt i32 %digit_index, %count
  br i1 %digit_in_bounds, label %digit_check, label %finish
digit_check:
  %digit_ptr = getelementptr i8, ptr %buf, i32 %digit_index
  %digit_byte = load i8, ptr %digit_ptr, align 1
  %at_least_zero = icmp uge i8 %digit_byte, 48
  %at_most_nine = icmp ule i8 %digit_byte, 57
  %is_digit = and i1 %at_least_zero, %at_most_nine
  br i1 %is_digit, label %accumulate, label %finish
accumulate:
  %digit_i32 = zext i8 %digit_byte to i32
  %digit = sub i32 %digit_i32, 48
  %times_ten = mul i32 %value, 10
  %next_value = add i32 %times_ten, %digit
  %digit_next = add i32 %digit_index, 1
  br label %digits
finish:
  %negative_value = sub i32 0, %value
  %result = select i1 %is_minus, i32 %negative_value, i32 %value
  ret i32 %result
empty:
  ret i32 0
}
declare i32 @sollang_browser_eprint(ptr, i32)
define internal void @sollang_runtime_eprint(ptr %data, i64 %len, i1 %newline) {
entry:
  %len32 = trunc i64 %len to i32
  %written = call i32 @sollang_browser_eprint(ptr %data, i32 %len32)
  br i1 %newline, label %write_newline, label %done
write_newline:
  %newline_written = call i32 @sollang_browser_eprint(ptr @sollang_runtime_newline, i32 1)
  br label %done
done:
  ret void
}
define internal void @sollang_runtime_eprintln(ptr %data, i64 %len) {
entry:
  call void @sollang_runtime_eprint(ptr %data, i64 %len, i1 true)
  ret void
}
define internal i64 @sollang_format_u64(ptr %dest, i64 %value) #0 {
entry:
  br label %count

count:
  %count_n = phi i64 [ %value, %entry ], [ %count_q, %count_more ]
  %length = phi i64 [ 1, %entry ], [ %next_length, %count_more ]
  %count_q = udiv i64 %count_n, 10
  %count_done = icmp eq i64 %count_q, 0
  br i1 %count_done, label %write_entry, label %count_more

count_more:
  %next_length = add i64 %length, 1
  br label %count

write_entry:
  %last_index = sub i64 %length, 1
  br label %write

write:
  %write_n = phi i64 [ %value, %write_entry ], [ %write_q, %write ]
  %index = phi i64 [ %last_index, %write_entry ], [ %previous_index, %write ]
  %digit = urem i64 %write_n, 10
  %write_q = udiv i64 %write_n, 10
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  %slot = getelementptr i8, ptr %dest, i64 %index
  store i8 %ascii, ptr %slot, align 1
  %previous_index = sub i64 %index, 1
  %write_done = icmp eq i64 %write_q, 0
  br i1 %write_done, label %return, label %write

return:
  ret i64 %length
}

define internal i64 @sollang_format_i64(ptr %dest, i64 %value) #0 {
entry:
  %negative = icmp slt i64 %value, 0
  br i1 %negative, label %negative_value, label %positive_value

negative_value:
  store i8 45, ptr %dest, align 1
  %digits_dest = getelementptr i8, ptr %dest, i64 1
  %magnitude = sub i64 0, %value
  %negative_digits = call i64 @sollang_format_u64(ptr %digits_dest, i64 %magnitude)
  %negative_length = add i64 %negative_digits, 1
  ret i64 %negative_length

positive_value:
  %positive_length = call i64 @sollang_format_u64(ptr %dest, i64 %value)
  ret i64 %positive_length
}

define internal void @sollang_runtime_print_i32(ptr %stdout, ptr %written, ptr %ok_state, i32 %value, i1 %newline) {
entry:
  %buffer = alloca [12 x i8], align 1
  %wide = sext i32 %value to i64
  %length = call i64 @sollang_format_i64(ptr %buffer, i64 %wide)
  call void @sollang_runtime_print(ptr %stdout, ptr %written, ptr %ok_state, ptr %buffer, i64 %length, i1 %newline)
  ret void
}
define internal void @sollang_runtime_print_i64(ptr %stdout, ptr %written, ptr %ok_state, i64 %value, i1 %signed, i1 %newline) {
entry:
  %buffer = alloca [21 x i8], align 1
  br i1 %signed, label %signed_value, label %unsigned_value
signed_value:
  %signed_length = call i64 @sollang_format_i64(ptr %buffer, i64 %value)
  br label %emit
unsigned_value:
  %unsigned_length = call i64 @sollang_format_u64(ptr %buffer, i64 %value)
  br label %emit
emit:
  %length = phi i64 [ %signed_length, %signed_value ], [ %unsigned_length, %unsigned_value ]
  call void @sollang_runtime_print(ptr %stdout, ptr %written, ptr %ok_state, ptr %buffer, i64 %length, i1 %newline)
  ret void
}
define internal void @sollang_runtime_eprint_i32(i32 %value, i1 %newline) {
entry:
  %buffer = alloca [12 x i8], align 1
  %wide = sext i32 %value to i64
  %length = call i64 @sollang_format_i64(ptr %buffer, i64 %wide)
  call void @sollang_runtime_eprint(ptr %buffer, i64 %length, i1 %newline)
  ret void
}
define internal void @sollang_runtime_eprint_i64(i64 %value, i1 %signed, i1 %newline) {
entry:
  %buffer = alloca [21 x i8], align 1
  br i1 %signed, label %signed_value, label %unsigned_value
signed_value:
  %signed_length = call i64 @sollang_format_i64(ptr %buffer, i64 %value)
  br label %emit
unsigned_value:
  %unsigned_length = call i64 @sollang_format_u64(ptr %buffer, i64 %value)
  br label %emit
emit:
  %length = phi i64 [ %signed_length, %signed_value ], [ %unsigned_length, %unsigned_value ]
  call void @sollang_runtime_eprint(ptr %buffer, i64 %length, i1 %newline)
  ret void
}
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1 immarg)
@sollang_bool_true_bytes = private constant [4 x i8] c"true"
@sollang_bool_false_bytes = private constant [5 x i8] c"false"
%sollang.source_text = type { ptr, i64, ptr, i64 }
%sollang.text = type { ptr, i64 }
%sollang.stream = type { ptr, ptr, ptr }
%sollang.event_stream = type { ptr, ptr, ptr }
%sollang.enum.t460 = type { i32, [0 x i64] }
%sollang.enum.t461 = type { i32, [0 x i64] }
%sollang.enum.t462 = type { i32, [0 x i64] }
%sollang.enum.t463 = type { i32, [0 x i64] }
%sollang.enum.t464 = type { i32, [0 x i64] }
%sollang.enum.t465 = type { i32, [0 x i64] }
%sollang.enum.t466 = type { i32, [0 x i64] }
%sollang.enum.t467 = type { i32, [0 x i64] }
%sollang.enum.t468 = type { i32, [0 x i64] }
%sollang.enum.t469 = type { i32, [0 x i64] }
%sollang.enum.t470 = type { i32, [0 x i64] }
%sollang.enum.t471 = type { i32, [0 x i64] }
%sollang.enum.t472 = type { i32, [0 x i64] }
%sollang.enum.t473 = type { i32, [1 x i64] }
%sollang.enum.t474 = type { i32, [1 x i64] }
%sollang.enum.t475 = type { i32, [0 x i64] }
%sollang.enum.t476 = type { i32, [0 x i64] }
%sollang.enum.t477 = type { i32, [5 x i64] }
%sollang.enum.t478 = type { i32, [4 x i64] }
%sollang.enum.t479 = type { i32, [0 x i64] }
%sollang.enum.t480 = type { i32, [1 x i64] }
%sollang.enum.t481 = type { i32, [0 x i64] }
%sollang.enum.t482 = type { i32, [1 x i64] }
%sollang.enum.t483 = type { i32, [0 x i64] }
%sollang.enum.t484 = type { i32, [1 x i64] }
%sollang.enum.t485 = type { i32, [0 x i64] }
%sollang.enum.t486 = type { i32, [1 x i64] }
%sollang.enum.t487 = type { i32, [1 x i64] }
%sollang.enum.t488 = type { i32, [0 x i64] }
%sollang.enum.t489 = type { i32, [66 x i64] }
%sollang.enum.t490 = type { i32, [1 x i64] }
%sollang.enum.t491 = type { i32, [1 x i64] }
%sollang.enum.t492 = type { i32, [0 x i64] }
%sollang.enum.t493 = type { i32, [4 x i64] }
%sollang.enum.t494 = type { i32, [1 x i64] }
%sollang.enum.t495 = type { i32, [1 x i64] }
%sollang.enum.t496 = type { i32, [0 x i64] }
%sollang.enum.t497 = type { i32, [0 x i64] }
%sollang.enum.t498 = type { i32, [0 x i64] }
%sollang.enum.t499 = type { i32, [0 x i64] }
%sollang.enum.t500 = type { i32, [0 x i64] }
%sollang.enum.t501 = type { i32, [1 x i64] }
%sollang.enum.t502 = type { i32, [0 x i64] }
%sollang.enum.t503 = type { i32, [4 x i64] }
%sollang.enum.t504 = type { i32, [1 x i64] }
%sollang.enum.t505 = type { i32, [0 x i64] }
%sollang.enum.t506 = type { i32, [1 x i64] }
%sollang.enum.t507 = type { i32, [1 x i64] }
%sollang.enum.t508 = type { i32, [0 x i64] }
%sollang.enum.t509 = type { i32, [0 x i64] }
%sollang.enum.t510 = type { i32, [0 x i64] }
%sollang.enum.t511 = type { i32, [1 x i64] }
%sollang.enum.t512 = type { i32, [0 x i64] }
%sollang.enum.t513 = type { i32, [0 x i64] }
%sollang.enum.t514 = type { i32, [0 x i64] }
%sollang.enum.t515 = type { i32, [0 x i64] }
%sollang.enum.t516 = type { i32, [0 x i64] }
%sollang.enum.t517 = type { i32, [0 x i64] }
%sollang.enum.t518 = type { i32, [0 x i64] }
%sollang.enum.t519 = type { i32, [0 x i64] }
%sollang.enum.t520 = type { i32, [0 x i64] }
%sollang.enum.t521 = type { i32, [3 x i64] }
%sollang.enum.t522 = type { i32, [0 x i64] }
%sollang.enum.t523 = type { i32, [0 x i64] }
%sollang.enum.t524 = type { i32, [0 x i64] }
%sollang.enum.t525 = type { i32, [0 x i64] }
%sollang.enum.t526 = type { i32, [0 x i64] }
%sollang.enum.t527 = type { i32, [0 x i64] }
%sollang.enum.t528 = type { i32, [0 x i64] }
%sollang.enum.t529 = type { i32, [0 x i64] }
%sollang.enum.t530 = type { i32, [0 x i64] }
%sollang.enum.t531 = type { i32, [0 x i64] }
%sollang.enum.t532 = type { i32, [3 x i64] }
%sollang.enum.t533 = type { i32, [0 x i64] }
%sollang.enum.t534 = type { i32, [2 x i64] }
%sollang.enum.t535 = type { i32, [0 x i64] }
%sollang.enum.t536 = type { i32, [2 x i64] }
%sollang.enum.t537 = type { i32, [4 x i64] }
%sollang.enum.t538 = type { i32, [0 x i64] }
%sollang.enum.t539 = type { i32, [0 x i64] }
%sollang.enum.t540 = type { i32, [0 x i64] }
%sollang.enum.t541 = type { i32, [1 x i64] }
%sollang.enum.t542 = type { i32, [0 x i64] }
%sollang.enum.t543 = type { i32, [0 x i64] }
%sollang.enum.t544 = type { i32, [2 x i64] }
%sollang.enum.t545 = type { i32, [7 x i64] }
%sollang.enum.t546 = type { i32, [0 x i64] }
%sollang.enum.t547 = type { i32, [2 x i64] }
%sollang.enum.t548 = type { i32, [0 x i64] }
%sollang.enum.t549 = type { i32, [0 x i64] }
%sollang.enum.t550 = type { i32, [0 x i64] }
%sollang.enum.t551 = type { i32, [0 x i64] }
%sollang.enum.t552 = type { i32, [2 x i64] }
%sollang.enum.t553 = type { i32, [8 x i64] }
%sollang.enum.t554 = type { i32, [0 x i64] }
%sollang.enum.t555 = type { i32, [0 x i64] }
%sollang.enum.t556 = type { i32, [7 x i64] }
%sollang.enum.t557 = type { i32, [0 x i64] }
%sollang.enum.t558 = type { i32, [0 x i64] }
%sollang.enum.t559 = type { i32, [0 x i64] }
%sollang.enum.t560 = type { i32, [0 x i64] }
%sollang.enum.t561 = type { i32, [0 x i64] }
%sollang.enum.t562 = type { i32, [0 x i64] }
%sollang.enum.t563 = type { i32, [0 x i64] }
%sollang.enum.t564 = type { i32, [1 x i64] }
%sollang.enum.t565 = type { i32, [0 x i64] }
%sollang.enum.t566 = type { i32, [0 x i64] }
%sollang.enum.t567 = type { i32, [15 x i64] }
%sollang.enum.t568 = type { i32, [15 x i64] }
%sollang.enum.t569 = type { i32, [0 x i64] }
%sollang.enum.t570 = type { i32, [0 x i64] }
%sollang.enum.t571 = type { i32, [0 x i64] }
%sollang.enum.t572 = type { i32, [0 x i64] }
%sollang.enum.t573 = type { i32, [0 x i64] }
%sollang.enum.t574 = type { i32, [0 x i64] }
%sollang.enum.t575 = type { i32, [0 x i64] }
%sollang.enum.t576 = type { i32, [0 x i64] }
%sollang.enum.t577 = type { i32, [0 x i64] }
%sollang.enum.t578 = type { i32, [0 x i64] }
%sollang.enum.t579 = type { i32, [0 x i64] }
%sollang.enum.t580 = type { i32, [0 x i64] }
%sollang.enum.t581 = type { i32, [0 x i64] }
%sollang.enum.t582 = type { i32, [0 x i64] }
%sollang.enum.t583 = type { i32, [0 x i64] }
%sollang.enum.t584 = type { i32, [2 x i64] }
%sollang.enum.t585 = type { i32, [1 x i64] }
%sollang.enum.t586 = type { i32, [9 x i64] }
%sollang.enum.t587 = type { i32, [0 x i64] }
%sollang.enum.t588 = type { i32, [0 x i64] }
%sollang.enum.t589 = type { i32, [0 x i64] }
%sollang.enum.t590 = type { i32, [0 x i64] }
%sollang.enum.t591 = type { i32, [0 x i64] }
%sollang.enum.t592 = type { i32, [4 x i64] }
%sollang.enum.t593 = type { i32, [3 x i64] }
%sollang.enum.t594 = type { i32, [0 x i64] }
%sollang.enum.t595 = type { i32, [2 x i64] }
%sollang.enum.t596 = type { i32, [0 x i64] }
%sollang.enum.t597 = type { i32, [0 x i64] }
%sollang.enum.t598 = type { i32, [0 x i64] }
%sollang.enum.t599 = type { i32, [0 x i64] }
%sollang.enum.t600 = type { i32, [2 x i64] }
%sollang.enum.t601 = type { i32, [2 x i64] }
%sollang.enum.t602 = type { i32, [1 x i64] }
%sollang.enum.t647 = type { i32, [1 x i64] }
%sollang.enum.t654 = type { i32, [1 x i64] }
%sollang.enum.t657 = type { i32, [1 x i64] }
%sollang.enum.t670 = type { i32, [3 x i64] }
%sollang.enum.t671 = type { i32, [44 x i64] }
%sollang.enum.t672 = type { i32, [2 x i64] }
%sollang.enum.t673 = type { i32, [13 x i64] }
%sollang.enum.t674 = type { i32, [2 x i64] }
%sollang.enum.t677 = type { i32, [1 x i64] }
%sollang.enum.t678 = type { i32, [6 x i64] }
%sollang.enum.t679 = type { i32, [1 x i64] }
%sollang.enum.t682 = type { i32, [2 x i64] }
%sollang.enum.t685 = type { i32, [1 x i64] }
%sollang.enum.t686 = type { i32, [3 x i64] }
%sollang.enum.t687 = type { i32, [4 x i64] }
%sollang.enum.t688 = type { i32, [105 x i64] }
%sollang.enum.t689 = type { i32, [2 x i64] }
%sollang.enum.t690 = type { i32, [9 x i64] }
%sollang.enum.t691 = type { i32, [26 x i64] }
%sollang.enum.t692 = type { i32, [81 x i64] }
%sollang.enum.t693 = type { i32, [2 x i64] }
%sollang.enum.t696 = type { i32, [3 x i64] }
%sollang.enum.t698 = type { i32, [26 x i64] }
%sollang.enum.t699 = type { i32, [4 x i64] }
%sollang.enum.t700 = type { i32, [2 x i64] }
%sollang.enum.t701 = type { i32, [2 x i64] }
%sollang.enum.t702 = type { i32, [2 x i64] }
%sollang.enum.t703 = type { i32, [50 x i64] }
%sollang.enum.t704 = type { i32, [2 x i64] }
%sollang.enum.t705 = type { i32, [3 x i64] }
%sollang.enum.t706 = type { i32, [2 x i64] }
%sollang.enum.t707 = type { i32, [2 x i64] }
%sollang.enum.t709 = type { i32, [2 x i64] }
%sollang.enum.t710 = type { i32, [2 x i64] }
%sollang.enum.t715 = type { i32, [9 x i64] }
%sollang.enum.t716 = type { i32, [24 x i64] }
%sollang.enum.t717 = type { i32, [2 x i64] }
%sollang.enum.t718 = type { i32, [12 x i64] }
%sollang.enum.t719 = type { i32, [11 x i64] }
%sollang.enum.t720 = type { i32, [2 x i64] }
%sollang.enum.t721 = type { i32, [32 x i64] }
%sollang.enum.t722 = type { i32, [34 x i64] }
%sollang.enum.t723 = type { i32, [2 x i64] }
%sollang.enum.t724 = type { i32, [9 x i64] }
%sollang.enum.t725 = type { i32, [31 x i64] }
%sollang.enum.t726 = type { i32, [2 x i64] }
%sollang.enum.t727 = type { i32, [15 x i64] }
%sollang.enum.t728 = type { i32, [34 x i64] }
%sollang.enum.t729 = type { i32, [2 x i64] }
%sollang.enum.t730 = type { i32, [2 x i64] }
%sollang.enum.t731 = type { i32, [6 x i64] }
%sollang.enum.t732 = type { i32, [2 x i64] }
%sollang.enum.t733 = type { i32, [2 x i64] }
%sollang.enum.t734 = type { i32, [2 x i64] }
%sollang.enum.t736 = type { i32, [14 x i64] }
%sollang.enum.t737 = type { i32, [9 x i64] }
%sollang.enum.t738 = type { i32, [5 x i64] }
%sollang.enum.t739 = type { i32, [5 x i64] }
%sollang.enum.t740 = type { i32, [4 x i64] }
%sollang.enum.t741 = type { i32, [2 x i64] }
%sollang.enum.t743 = type { i32, [2 x i64] }
%sollang.enum.t744 = type { i32, [2 x i64] }
%sollang.enum.t745 = type { i32, [81 x i64] }
%sollang.enum.t746 = type { i32, [2 x i64] }
%sollang.enum.t747 = type { i32, [3 x i64] }
%sollang.enum.t748 = type { i32, [3 x i64] }
%sollang.enum.t749 = type { i32, [5 x i64] }
%sollang.enum.t750 = type { i32, [2 x i64] }
%sollang.enum.t751 = type { i32, [14 x i64] }
%sollang.enum.t752 = type { i32, [2 x i64] }
%sollang.enum.t753 = type { i32, [32 x i64] }
%sollang.enum.t754 = type { i32, [4 x i64] }
%sollang.enum.t755 = type { i32, [2 x i64] }
%sollang.enum.t757 = type { i32, [5 x i64] }
%sollang.enum.t758 = type { i32, [2 x i64] }
%sollang.enum.t759 = type { i32, [2 x i64] }
%sollang.enum.t760 = type { i32, [5 x i64] }
%sollang.enum.t761 = type { i32, [2 x i64] }
%sollang.enum.t762 = type { i32, [2 x i64] }
%sollang.enum.t763 = type { i32, [32 x i64] }
%sollang.enum.t764 = type { i32, [2 x i64] }
%sollang.enum.t765 = type { i32, [4 x i64] }
%sollang.enum.t768 = type { i32, [2 x i64] }
%sollang.enum.t769 = type { i32, [2 x i64] }
%sollang.enum.t770 = type { i32, [4 x i64] }
%sollang.enum.t771 = type { i32, [2 x i64] }
%sollang.enum.t772 = type { i32, [2 x i64] }
%sollang.enum.t773 = type { i32, [2 x i64] }
%sollang.enum.t774 = type { i32, [2 x i64] }
%sollang.enum.t775 = type { i32, [2 x i64] }
%sollang.enum.t776 = type { i32, [2 x i64] }
%sollang.enum.t777 = type { i32, [3 x i64] }
%sollang.enum.t778 = type { i32, [2 x i64] }
%sollang.enum.t780 = type { i32, [3 x i64] }
%sollang.enum.t781 = type { i32, [4 x i64] }
%sollang.enum.t782 = type { i32, [9 x i64] }
%sollang.enum.t783 = type { i32, [2 x i64] }
%sollang.enum.t784 = type { i32, [32 x i64] }
%sollang.enum.t785 = type { i32, [3 x i64] }
%sollang.enum.t787 = type { i32, [5 x i64] }
%sollang.enum.t788 = type { i32, [2 x i64] }
%sollang.enum.t789 = type { i32, [2 x i64] }
%sollang.enum.t790 = type { i32, [4 x i64] }
%sollang.enum.t791 = type { i32, [4 x i64] }
%sollang.enum.t792 = type { i32, [72 x i64] }
%sollang.enum.t793 = type { i32, [2 x i64] }
%sollang.enum.t794 = type { i32, [2 x i64] }
%sollang.enum.t795 = type { i32, [2 x i64] }
%sollang.enum.t796 = type { i32, [13 x i64] }
%sollang.enum.t797 = type { i32, [26 x i64] }
%sollang.enum.t798 = type { i32, [5 x i64] }
%sollang.enum.t799 = type { i32, [2 x i64] }
%sollang.enum.t802 = type { i32, [2 x i64] }
%sollang.enum.t803 = type { i32, [72 x i64] }
%sollang.enum.t804 = type { i32, [3 x i64] }
%sollang.enum.t805 = type { i32, [3 x i64] }
%sollang.enum.t806 = type { i32, [13 x i64] }
%sollang.enum.t807 = type { i32, [70 x i64] }
%sollang.enum.t808 = type { i32, [2 x i64] }
%sollang.enum.t809 = type { i32, [40 x i64] }
%sollang.enum.t813 = type { i32, [3 x i64] }
%sollang.enum.t814 = type { i32, [10 x i64] }
%sollang.enum.t815 = type { i32, [11 x i64] }
%sollang.enum.t816 = type { i32, [2 x i64] }
%sollang.enum.t817 = type { i32, [1 x i64] }
%sollang.enum.t818 = type { i32, [5 x i64] }
%sollang.enum.t819 = type { i32, [3 x i64] }
%sollang.enum.t820 = type { i32, [3 x i64] }
%sollang.enum.t821 = type { i32, [10 x i64] }
%sollang.enum.t822 = type { i32, [33 x i64] }
%sollang.enum.t823 = type { i32, [35 x i64] }
%sollang.enum.t824 = type { i32, [1 x i64] }
%sollang.enum.t831 = type { i32, [8 x i64] }
%sollang.enum.t832 = type { i32, [1 x i64] }
%sollang.enum.t833 = type { i32, [2 x i64] }
%sollang.enum.t834 = type { i32, [2 x i64] }
%sollang.enum.t835 = type { i32, [2 x i64] }
%sollang.enum.t839 = type { i32, [3 x i64] }
%sollang.enum.t842 = type { i32, [2 x i64] }
%sollang.enum.t843 = type { i32, [2 x i64] }
%sollang.enum.t844 = type { i32, [2 x i64] }
%sollang.enum.t845 = type { i32, [5 x i64] }
%sollang.enum.t846 = type { i32, [9 x i64] }
%sollang.enum.t847 = type { i32, [7 x i64] }
%sollang.enum.t849 = type { i32, [3 x i64] }
%sollang.enum.t850 = type { i32, [2 x i64] }
%sollang.enum.t851 = type { i32, [2 x i64] }
%sollang.enum.t852 = type { i32, [2 x i64] }
%sollang.enum.t853 = type { i32, [2 x i64] }
%sollang.enum.t854 = type { i32, [2 x i64] }
%sollang.enum.t855 = type { i32, [2 x i64] }
%sollang.enum.t856 = type { i32, [2 x i64] }
%sollang.enum.t857 = type { i32, [2 x i64] }
%sollang.enum.t858 = type { i32, [2 x i64] }
%sollang.enum.t859 = type { i32, [3 x i64] }
%sollang.enum.t860 = type { i32, [2 x i64] }
%sollang.enum.t861 = type { i32, [3 x i64] }
%sollang.enum.t866 = type { i32, [1 x i64] }
%sollang.enum.t867 = type { i32, [4 x i64] }
%sollang.enum.t868 = type { i32, [4 x i64] }
%sollang.enum.t869 = type { i32, [2 x i64] }
%sollang.enum.t870 = type { i32, [8 x i64] }
%sollang.enum.t871 = type { i32, [2 x i64] }
%sollang.enum.t872 = type { i32, [4 x i64] }
%sollang.enum.t873 = type { i32, [2 x i64] }
%sollang.enum.t874 = type { i32, [2 x i64] }
%sollang.enum.t876 = type { i32, [3 x i64] }
%sollang.enum.t877 = type { i32, [5 x i64] }
%sollang.enum.t878 = type { i32, [10 x i64] }
%sollang.enum.t879 = type { i32, [10 x i64] }
%sollang.enum.t880 = type { i32, [11 x i64] }
%sollang.enum.t881 = type { i32, [11 x i64] }
%sollang.enum.t884 = type { i32, [7 x i64] }
%sollang.enum.t885 = type { i32, [8 x i64] }
%sollang.enum.t886 = type { i32, [7 x i64] }
%sollang.enum.t887 = type { i32, [8 x i64] }
%sollang.enum.t888 = type { i32, [2 x i64] }
%sollang.enum.t889 = type { i32, [7 x i64] }
%sollang.enum.t890 = type { i32, [7 x i64] }
%sollang.enum.t891 = type { i32, [3 x i64] }
%sollang.enum.t893 = type { i32, [2 x i64] }
%sollang.enum.t894 = type { i32, [3 x i64] }
%sollang.enum.t895 = type { i32, [2 x i64] }
%sollang.enum.t896 = type { i32, [2 x i64] }
%sollang.enum.t898 = type { i32, [2 x i64] }
%sollang.enum.t899 = type { i32, [4 x i64] }
%sollang.enum.t901 = type { i32, [3 x i64] }
%sollang.enum.t902 = type { i32, [3 x i64] }
%sollang.enum.t903 = type { i32, [11 x i64] }
%sollang.enum.t904 = type { i32, [11 x i64] }
%sollang.enum.t905 = type { i32, [4 x i64] }
%sollang.enum.t906 = type { i32, [2 x i64] }
%sollang.enum.t907 = type { i32, [2 x i64] }
%sollang.enum.t909 = type { i32, [2 x i64] }
%sollang.enum.t910 = type { i32, [5 x i64] }
%sollang.enum.t911 = type { i32, [3 x i64] }
%sollang.enum.t912 = type { i32, [12 x i64] }
%sollang.enum.t913 = type { i32, [2 x i64] }
%sollang.enum.t914 = type { i32, [2 x i64] }
%sollang.enum.t915 = type { i32, [2 x i64] }
%sollang.enum.t920 = type { i32, [2 x i64] }
%sollang.enum.t921 = type { i32, [3 x i64] }
%sollang.enum.t922 = type { i32, [3 x i64] }
%sollang.enum.t923 = type { i32, [12 x i64] }
%sollang.enum.t924 = type { i32, [24 x i64] }
%sollang.enum.t925 = type { i32, [7 x i64] }
%sollang.enum.t926 = type { i32, [5 x i64] }
%sollang.enum.t927 = type { i32, [9 x i64] }
%sollang.enum.t928 = type { i32, [28 x i64] }
%sollang.enum.t929 = type { i32, [3 x i64] }
%sollang.enum.t930 = type { i32, [8 x i64] }
%sollang.enum.t931 = type { i32, [2 x i64] }
%sollang.enum.t932 = type { i32, [11 x i64] }
%sollang.enum.t933 = type { i32, [6 x i64] }
%sollang.enum.t934 = type { i32, [2 x i64] }
%sollang.enum.t935 = type { i32, [8 x i64] }
%sollang.enum.t936 = type { i32, [6 x i64] }
%sollang.enum.t937 = type { i32, [3 x i64] }
%sollang.enum.t938 = type { i32, [23 x i64] }
%sollang.enum.t939 = type { i32, [4 x i64] }
%sollang.enum.t940 = type { i32, [5 x i64] }
%sollang.enum.t941 = type { i32, [8 x i64] }
%sollang.enum.t942 = type { i32, [35 x i64] }
%sollang.enum.t943 = type { i32, [9 x i64] }
%sollang.enum.t944 = type { i32, [3 x i64] }
%sollang.enum.t955 = type { i32, [2 x i64] }
%sollang.enum.t956 = type { i32, [2 x i64] }
%sollang.enum.t957 = type { i32, [9 x i64] }
%sollang.enum.t958 = type { i32, [21 x i64] }
%sollang.enum.t959 = type { i32, [4 x i64] }
%sollang.enum.t960 = type { i32, [9 x i64] }
%sollang.enum.t961 = type { i32, [2 x i64] }
%sollang.enum.t962 = type { i32, [5 x i64] }
%sollang.enum.t963 = type { i32, [2 x i64] }
%sollang.enum.t964 = type { i32, [14 x i64] }
%sollang.enum.t966 = type { i32, [11 x i64] }
%sollang.enum.t967 = type { i32, [16 x i64] }
%sollang.enum.t968 = type { i32, [7 x i64] }
%sollang.enum.t971 = type { i32, [7 x i64] }
%sollang.enum.t972 = type { i32, [4 x i64] }
%sollang.enum.t973 = type { i32, [6 x i64] }
%sollang.enum.t974 = type { i32, [7 x i64] }
%sollang.enum.t975 = type { i32, [6 x i64] }
%sollang.enum.t976 = type { i32, [5 x i64] }
%sollang.enum.t977 = type { i32, [2 x i64] }
%sollang.enum.t978 = type { i32, [4 x i64] }
%sollang.enum.t979 = type { i32, [10 x i64] }
%sollang.enum.t980 = type { i32, [131 x i64] }
%sollang.enum.t981 = type { i32, [2 x i64] }
%sollang.enum.t982 = type { i32, [16 x i64] }
%sollang.enum.t983 = type { i32, [7 x i64] }
%sollang.enum.t984 = type { i32, [10 x i64] }
%sollang.enum.t986 = type { i32, [5 x i64] }
%sollang.enum.t988 = type { i32, [2 x i64] }
%sollang.enum.t989 = type { i32, [17 x i64] }
%sollang.enum.t990 = type { i32, [2 x i64] }
%sollang.enum.t991 = type { i32, [2 x i64] }
%sollang.enum.t992 = type { i32, [3 x i64] }
%sollang.enum.t994 = type { i32, [10 x i64] }
%sollang.enum.t995 = type { i32, [5 x i64] }
%sollang.enum.t996 = type { i32, [3 x i64] }
%sollang.enum.t997 = type { i32, [8 x i64] }
%sollang.enum.t999 = type { i32, [2 x i64] }
%sollang.enum.t1000 = type { i32, [4 x i64] }
%sollang.enum.t1002 = type { i32, [2 x i64] }
%sollang.enum.t1003 = type { i32, [9 x i64] }
%sollang.enum.t1004 = type { i32, [3 x i64] }
%sollang.enum.t1005 = type { i32, [7 x i64] }
%sollang.enum.t1006 = type { i32, [11 x i64] }
%sollang.enum.t1007 = type { i32, [7 x i64] }
%sollang.enum.t1011 = type { i32, [6 x i64] }
%sollang.enum.t1013 = type { i32, [11 x i64] }
%sollang.enum.t1014 = type { i32, [18 x i64] }
%sollang.enum.t1016 = type { i32, [149 x i64] }
%sollang.enum.t1017 = type { i32, [3 x i64] }
%sollang.enum.t1018 = type { i32, [2 x i64] }
%sollang.enum.t1019 = type { i32, [2 x i64] }
%sollang.enum.t1020 = type { i32, [2 x i64] }
%sollang.enum.t1022 = type { i32, [11 x i64] }
%sollang.enum.t1023 = type { i32, [8 x i64] }
%sollang.enum.t1024 = type { i32, [5 x i64] }
%sollang.enum.t1025 = type { i32, [5 x i64] }
%sollang.enum.t1026 = type { i32, [6 x i64] }
%sollang.enum.t1027 = type { i32, [6 x i64] }
%sollang.enum.t1028 = type { i32, [2 x i64] }
%sollang.enum.t1030 = type { i32, [14 x i64] }
%sollang.enum.t1033 = type { i32, [6 x i64] }
%sollang.enum.t1034 = type { i32, [6 x i64] }
%sollang.enum.t1036 = type { i32, [4 x i64] }
%sollang.enum.t1037 = type { i32, [5 x i64] }
%sollang.enum.t1038 = type { i32, [4 x i64] }
%sollang.enum.t1039 = type { i32, [21 x i64] }
%sollang.enum.t1040 = type { i32, [4 x i64] }
%sollang.enum.t1041 = type { i32, [5 x i64] }
%sollang.enum.t1042 = type { i32, [2 x i64] }
%sollang.enum.t1044 = type { i32, [3 x i64] }
%sollang.enum.t1045 = type { i32, [4 x i64] }
%sollang.enum.t1046 = type { i32, [2 x i64] }
%sollang.enum.t1047 = type { i32, [6 x i64] }
%sollang.enum.t1048 = type { i32, [5 x i64] }
%sollang.enum.t1049 = type { i32, [5 x i64] }
%sollang.enum.t1052 = type { i32, [16 x i64] }
%sollang.enum.t1053 = type { i32, [7 x i64] }
%sollang.enum.t1054 = type { i32, [6 x i64] }
%sollang.enum.t1055 = type { i32, [4 x i64] }
%sollang.enum.t1056 = type { i32, [5 x i64] }
%sollang.enum.t1057 = type { i32, [2 x i64] }
%sollang.enum.t1058 = type { i32, [2 x i64] }
%sollang.enum.t1060 = type { i32, [4 x i64] }
%sollang.enum.t1062 = type { i32, [9 x i64] }
%sollang.enum.t1063 = type { i32, [2 x i64] }
%sollang.enum.t1067 = type { i32, [1 x i64] }
%sollang.enum.t1068 = type { i32, [2 x i64] }
%sollang.enum.t1069 = type { i32, [2 x i64] }
%sollang.enum.t1070 = type { i32, [16 x i64] }
%sollang.enum.t1072 = type { i32, [2 x i64] }
%sollang.enum.t1073 = type { i32, [2 x i64] }
%sollang.enum.t1074 = type { i32, [10 x i64] }
%sollang.enum.t1075 = type { i32, [2 x i64] }
%sollang.enum.t1076 = type { i32, [3 x i64] }
%sollang.enum.t1090 = type { i32, [11 x i64] }
%sollang.enum.t1091 = type { i32, [4 x i64] }
%sollang.enum.t1092 = type { i32, [2 x i64] }
%sollang.enum.t1093 = type { i32, [2 x i64] }
%sollang.enum.t1094 = type { i32, [3 x i64] }
%sollang.enum.t1095 = type { i32, [2 x i64] }
%sollang.enum.t1097 = type { i32, [3 x i64] }
%sollang.enum.t1098 = type { i32, [6 x i64] }
%sollang.enum.t1099 = type { i32, [2 x i64] }
%sollang.enum.t1102 = type { i32, [2 x i64] }
%sollang.enum.t1103 = type { i32, [2 x i64] }
%sollang.enum.t1104 = type { i32, [2 x i64] }
%sollang.enum.t1105 = type { i32, [2 x i64] }
%sollang.enum.t1106 = type { i32, [2 x i64] }
%sollang.enum.t1107 = type { i32, [11 x i64] }
%sollang.enum.t1108 = type { i32, [4 x i64] }
%sollang.enum.t1109 = type { i32, [2 x i64] }
%sollang.enum.t1110 = type { i32, [2 x i64] }
%sollang.enum.t1111 = type { i32, [8 x i64] }
%sollang.enum.t1113 = type { i32, [2 x i64] }
%sollang.enum.t1114 = type { i32, [4 x i64] }
%sollang.enum.t1117 = type { i32, [3 x i64] }
%sollang.enum.t1118 = type { i32, [3 x i64] }
%sollang.enum.t1119 = type { i32, [3 x i64] }
%sollang.enum.t1120 = type { i32, [5 x i64] }
%sollang.enum.t1121 = type { i32, [3 x i64] }
%sollang.enum.t1123 = type { i32, [8 x i64] }
%sollang.enum.t1124 = type { i32, [1 x i64] }
%sollang.enum.t1125 = type { i32, [3 x i64] }
%sollang.enum.t1126 = type { i32, [1 x i64] }
%sollang.enum.t1127 = type { i32, [1 x i64] }
%sollang.enum.t1128 = type { i32, [2 x i64] }
%sollang.enum.t1129 = type { i32, [2 x i64] }
%sollang.enum.t1130 = type { i32, [2 x i64] }
%sollang.enum.t1131 = type { i32, [6 x i64] }
%sollang.enum.t1132 = type { i32, [1 x i64] }
%sollang.enum.t1133 = type { i32, [1 x i64] }
%sollang.enum.t1134 = type { i32, [1 x i64] }
%sollang.enum.t1135 = type { i32, [1 x i64] }
%sollang.enum.t1136 = type { i32, [11 x i64] }
%sollang.enum.t1137 = type { i32, [21 x i64] }
%sollang.enum.t1138 = type { i32, [9 x i64] }
%sollang.enum.t1139 = type { i32, [2 x i64] }
%sollang.enum.t1140 = type { i32, [2 x i64] }
%sollang.enum.t1142 = type { i32, [3 x i64] }
%sollang.enum.t1143 = type { i32, [2 x i64] }
%sollang.enum.t1144 = type { i32, [3 x i64] }
%sollang.enum.t1145 = type { i32, [2 x i64] }
%sollang.enum.t1146 = type { i32, [1 x i64] }
%sollang.enum.t1147 = type { i32, [1 x i64] }
%sollang.enum.t1154 = type { i32, [2 x i64] }
%sollang.enum.t1155 = type { i32, [2 x i64] }
%sollang.enum.t1156 = type { i32, [2 x i64] }
%sollang.enum.t1157 = type { i32, [0 x i64] }
%sollang.enum.t1158 = type { i32, [0 x i64] }
%sollang.enum.t1159 = type { i32, [2 x i64] }
%sollang.enum.t1160 = type { i32, [2 x i64] }
%sollang.enum.t1161 = type { i32, [2 x i64] }
%sollang.enum.t1162 = type { i32, [7 x i64] }
%sollang.enum.t1163 = type { i32, [4 x i64] }
%sollang.enum.t1164 = type { i32, [2 x i64] }
%sollang.enum.t1167 = type { i32, [2 x i64] }
%sollang.enum.t1169 = type { i32, [3 x i64] }
%sollang.enum.t1180 = type { i32, [0 x i64] }
%sollang.enum.t1181 = type { i32, [3 x i64] }
%sollang.enum.t1182 = type { i32, [6 x i64] }
%sollang.enum.t1183 = type { i32, [2 x i64] }
%sollang.enum.t1184 = type { i32, [3 x i64] }
%sollang.enum.t1185 = type { i32, [8 x i64] }
%sollang.enum.t1186 = type { i32, [2 x i64] }
%sollang.enum.t1187 = type { i32, [1 x i64] }
%sollang.enum.t1188 = type { i32, [2 x i64] }
%sollang.enum.t1189 = type { i32, [3 x i64] }
%sollang.enum.t1190 = type { i32, [2 x i64] }
%sollang.enum.t1192 = type { i32, [2 x i64] }
%sollang.enum.t1193 = type { i32, [4 x i64] }
%sollang.enum.t1194 = type { i32, [3 x i64] }
%sollang.enum.t1195 = type { i32, [17 x i64] }
%sollang.enum.t1196 = type { i32, [3 x i64] }
%sollang.enum.t1197 = type { i32, [15 x i64] }
%sollang.enum.t1198 = type { i32, [2 x i64] }
%sollang.enum.t1199 = type { i32, [2 x i64] }
%sollang.enum.t1200 = type { i32, [2 x i64] }
%sollang.enum.t1202 = type { i32, [1 x i64] }
%sollang.enum.t1203 = type { i32, [2 x i64] }
%sollang.enum.t1204 = type { i32, [2 x i64] }
%sollang.enum.t1205 = type { i32, [5 x i64] }
%sollang.enum.t1206 = type { i32, [2 x i64] }
%sollang.enum.t1209 = type { i32, [9 x i64] }
%sollang.enum.t1210 = type { i32, [6 x i64] }
%sollang.enum.t1211 = type { i32, [3 x i64] }
%sollang.enum.t1212 = type { i32, [2 x i64] }
%sollang.struct.x0D7374642E616C676F726974686D010301084F72646572696E6700 = type { %sollang.enum.t460 }
%sollang.struct.x0D7374642E616C676F726974686D0103010A416C676F726974686D7300 = type {  }
%sollang.struct.x0D7374642E616C676F726974686D0103010C536561726368526573756C7400 = type { i32, i1 }
%sollang.struct.x0D7374642E616C676F726974686D0103010A457175616C52616E676500 = type { i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A6970010301054572726F7200 = type { %sollang.enum.t466, i32 }
%sollang.struct.x0F7374642E617263686976652E7A6970010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A697001030105436F64656300 = type { %sollang.struct.x0F7374642E617263686976652E7A6970010301064C696D69747300 }
%sollang.struct.x0F7374642E617263686976652E7A69700103010D4465666C6174654C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A6970010301074465636F64657200 = type { %sollang.struct.x0F7374642E617263686976652E7A6970010301064C696D69747300, %sollang.enum.t464, i32, %sollang.array.i32, %sollang.array.i32, i32, i32, i32, %sollang.array.i32, i32, i32, i32, i32, %sollang.array.i32, i1, %sollang.struct.x0F7374642E617263686976652E7A69700103010D4465666C6174654C696D69747300, i32, %sollang.struct.x0E7374642E686173682E63726333320103010648617368657200, %sollang.array.i32, %sollang.array.i32, i32, i32, i32, %sollang.array.i32, i32, i32, %sollang.array.i32, i32, i1, %sollang.struct.x0F7374642E617263686976652E7A6970010301054572726F7200 }
%sollang.struct.x0F7374642E617263686976652E7A69700103010C5772697465724C696D69747300 = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A69700103010657726974657200 = type { %sollang.struct.x0F7374642E617263686976652E7A69700103010C5772697465724C696D69747300, %sollang.enum.t465, i32, i32, i32, i32, i32, i32, %sollang.struct.x0E7374642E686173682E63726333320103010648617368657200, %sollang.array.i32 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030110446961676E6F737469634C696D69747300 = type { i32 }
%sollang.struct.x157374642E6173796E632E646961676E6F73746963730103011153757370656E73696F6E4C6F6361746F7200 = type { %sollang.text, %sollang.text, i32, i32, i32, i32 }
%sollang.struct.x157374642E6173796E632E646961676E6F73746963730103010C5461736B536E617073686F7400 = type { i64, %sollang.enum.t677, %sollang.enum.t467, %sollang.enum.t468, %sollang.enum.t677, i64, %sollang.enum.t678 }
%sollang.struct.x157374642E6173796E632E646961676E6F73746963730103010E536E617073686F74526573756C7400 = type { i64, i32, i32, i1 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030111446961676E6F7374696353756D6D61727900 = type { i64, i32, i32 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030111446961676E6F7374696353657373696F6E00 = type { i64 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030116446961676E6F73746963436C6F73654661696C75726500 = type { %sollang.struct.x157374642E6173796E632E646961676E6F737469637301030111446961676E6F7374696353657373696F6E00, %sollang.enum.t471 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301054572726F7200 = type { %sollang.enum.t498, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C6901030105436F64656300 = type { %sollang.struct.x137374642E636F6D70726573732E62726F746C69010301064C696D69747300 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C6901030107456E636F64657200 = type { i32, i32, i32, i32, i32, i32, i1 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301074465636F64657200 = type { i32, i32, i32, i32, i32, i32, %sollang.enum.t497, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010657696E646F7700, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010652656164657200, i32, i1, i32, i32, i32, %sollang.array.i32, i1, %sollang.struct.x137374642E636F6D70726573732E62726F746C69010301054572726F7200 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C690103010942697457726974657200 = type { i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C690103010942697452656164657200 = type { i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C690103010C53747265616D437572736F7200 = type { i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301074269745265616400 = type { i1, i64 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301054572726F7200 = type { %sollang.enum.t475, i32 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301084578656375746F7200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273656400, i32, i32, i32, i32 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301074465636F64656400 = type { %sollang.array.i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E640103010652656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273656400, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301085265736F6C76657200, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32, i32, %sollang.enum.t472, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.t472 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E640103010853747265616D656400 = type { %sollang.array.i32 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301054572726F7200 = type { %sollang.enum.t488, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301064C696D69747300 = type { i32, i32, i32, i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010650617273657200, %sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010650617273657200, i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D5072656C75646552656164657200 = type { %sollang.enum.t476, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.t499, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301075072656C75646500 = type { i32, i32, i32, i32, i32, %sollang.enum.t499, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F68656164657201030111426C6F636B53747265616D52656164657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, %sollang.enum.t479, i32, i32, i32, i32, %sollang.enum.t478, %sollang.enum.t478 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010C48656164657252656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F68656164657201030111426C6F636B53747265616D52656164657200, %sollang.enum.t481, i32, %sollang.array.i32, i32, i32, %sollang.array.i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D4865616465725072656C75646500 = type { %sollang.array.i32, i32, i32, i32, %sollang.array.i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D436F6E7465787452656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D4865616465725072656C75646500, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010652656164657200, %sollang.enum.t483, %sollang.array.i32, %sollang.array.i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010E436F6E746578745072656C75646500 = type { %sollang.array.i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010A5472656552656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010E436F6E746578745072656C75646500, %sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010652656164657200, %sollang.enum.t485, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010B426C6F636B53747265616D00 = type { i32, i32, %sollang.enum.t478, %sollang.enum.t478 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010B426C6F636B53776974636800 = type { i32, i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273656400 = type { %sollang.array.i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F68656164657201030111506172736564426C6F636B53747265616D00 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010B426C6F636B53747265616D00, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D010301054572726F7200 = type { %sollang.enum.t498, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010C48656164657250726566697800 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010C48656164657252656164657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010D436F6E7465787450726566697800 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D436F6E7465787452656164657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010A5472656550726566697800 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010A5472656552656164657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010652656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D010301064C696D69747300, i32, %sollang.array.i32, %sollang.enum.t489 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D6170010301054572726F7200 = type { %sollang.enum.t496, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D6170010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010650617273657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010650617273656400 = type { %sollang.array.i32, i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010652656164657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, i32, %sollang.enum.t492, i32, i32, i32, %sollang.array.i32, %sollang.enum.t493 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010853747265616D656400 = type { %sollang.array.i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D6170010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301054572726F7200 = type { %sollang.enum.t505, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301064C696D69747300 = type { i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200 = type { %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074275696C64657200, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273656400 = type { %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301055461626C6500, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301154669786564436F64654C656E67746852656164657200 = type { %sollang.enum.t500, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 = type { %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074275696C64657200, i32, i32, i32, %sollang.enum.t502, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301154669786564436F64654C656E67746852656164657200, %sollang.array.i32, i32, i32, i32, %sollang.enum.t503, i32, i32, i32, i32, i32, i32, %sollang.enum.t503 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301054572726F7200 = type { %sollang.enum.t508, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301064C696D69747300 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074275696C64657200 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301055461626C6500 = type { %sollang.array.i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074465636F64656400 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010650726F62656400 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010C57696E646F774C696D69747300 = type { i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010657696E646F7700 = type { i64, i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301065065656B656400 = type { i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301054572726F7200 = type { %sollang.enum.t510, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301064C696D69747300 = type { i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301085265736F6C76657200 = type { i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E6172790103010A44657363726970746F7200 = type { i32, %sollang.enum.t509, i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F7570010301054572726F7200 = type { %sollang.enum.t512, i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F7570010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010650617273657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010650617273656400 = type { %sollang.array.i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010652656164657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.array.i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010853747265616D656400 = type { %sollang.array.i32 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301054572726F7200 = type { %sollang.enum.t514, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301064C696D69747300 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030105436F64656300 = type { %sollang.struct.x117374642E636F6D70726573732E677A6970010301064C696D69747300 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010D4465636F6465724C696D69747300 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030107456E636F64657200 = type { i32, i32, i32, i32, i1, i1, %sollang.struct.x117374642E636F6D70726573732E677A69700103010942697457726974657200 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301074465636F64657200 = type { %sollang.struct.x117374642E636F6D70726573732E677A697001030105436F64656300, i32, i32, i32, i32, i32, i32, %sollang.enum.t513, i32, i32, i32, i32, i32, i32, i32, i1, i32, i32, i32, i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, i32, i32, i32, i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, i32, i1, %sollang.struct.x117374642E636F6D70726573732E677A6970010301054572726F7200, i1, i1 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301115261774465666C6174654465636F64657200 = type { %sollang.struct.x117374642E636F6D70726573732E677A6970010301074465636F64657200 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A456E636F6465506C616E00 = type { i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A4465636F6465506C616E00 = type { i32, i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030109426974437572736F7200 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010942697457726974657200 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010B4465666C617465436F646500 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A4C656E677468436F646500 = type { i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C44697374616E6365436F646500 = type { i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301054D6174636800 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00 = type { %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010B487566666D616E5061697200 = type { %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C496E666C617465537461746500 = type { %sollang.struct.x117374642E636F6D70726573732E677A697001030109426974437572736F7200, i32, %sollang.array.i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C4D656D6265724465636F646500 = type { i32, %sollang.array.i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C496E666C617465436F756E7400 = type { i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C53747265616D437572736F7200 = type { i32 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301074269745265616400 = type { i1, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A55496E7433325265616400 = type { i1, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A53796D626F6C5265616400 = type { i1, i32 }
%sollang.struct.x117374642E636F6D70726573732E7A737464010301054572726F7200 = type { %sollang.enum.t516, i32 }
%sollang.struct.x117374642E636F6D70726573732E7A7374640103010F436F6D70726573736564426C6F636B00 = type { %sollang.array.i32, %sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500, i1, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E7A737464010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E7A7374640103010C4672616D654F7074696F6E7300 = type { i1 }
%sollang.struct.x117374642E636F6D70726573732E7A73746401030105436F64656300 = type { %sollang.struct.x117374642E636F6D70726573732E7A737464010301064C696D69747300, %sollang.struct.x117374642E636F6D70726573732E7A7374640103010C4672616D654F7074696F6E7300 }
%sollang.struct.x117374642E636F6D70726573732E7A73746401030107456E636F64657200 = type { i32, i32, i32, i32, i1, i1, %sollang.struct.x117374642E686173682E78786861736836340103010648617368657200 }
%sollang.struct.x117374642E636F6D70726573732E7A737464010301074465636F64657200 = type { i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.t515, i64, i32, i32, i32, i32, i32, i1, i64, i1, %sollang.struct.x117374642E686173682E78786861736836340103010648617368657200, i32, i32, i32, i32, i1, %sollang.array.i32, %sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500, i1, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32, %sollang.array.i32, i1, %sollang.struct.x117374642E636F6D70726573732E7A737464010301054572726F7200 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500 = type { %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E6673650103010B4465736372697074696F6E00 = type { %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i32 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E6673650103010B466F72776172644269747300 = type { i32 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E6673650103010B526576657273654269747300 = type { i32, i32, i32 }
%sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500 = type { %sollang.array.i32, i32 }
%sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E0103010B4465736372697074696F6E00 = type { %sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E636501030106437572736F7200 = type { i32, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E636501030108507265706172656400 = type { %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E63650103010D526563656E744F66667365747300 = type { i32, i32, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E6365010301074465636F64656400 = type { %sollang.array.i32, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32 }
%sollang.struct.x117374642E63727970746F2E616573313238010301034B657900 = type { %sollang.array.i32 }
%sollang.struct.x117374642E63727970746F2E6165733132380103010A426C6F636B56616C756500 = type { %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E6165733132385F67636D010301065365616C656400 = type { %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E6165733132385F67636D010301034B657900 = type { %sollang.struct.x117374642E63727970746F2E616573313238010301034B657900, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E6165733132385F67636D0103010A426C6F636B56616C756500 = type { %sollang.int_slice }
%sollang.struct.x127374642E63727970746F2E65643235353139010301054572726F7200 = type { %sollang.enum.t522 }
%sollang.struct.x127374642E63727970746F2E6564323535313901030105506F696E7400 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x167374642E63727970746F2E686D61635F7368613235360103010648617368657200 = type { %sollang.struct.x117374642E63727970746F2E7368613235360103010648617368657200, %sollang.struct.x117374642E63727970746F2E7368613235360103010648617368657200 }
%sollang.struct.x117374642E63727970746F2E72616E646F6D0103010C53656375726552616E646F6D00 = type { i8 }
%sollang.struct.x117374642E63727970746F2E7368613235360103010648617368657200 = type { %sollang.int_slice, %sollang.int_slice, i32, i64 }
%sollang.struct.x157374642E63727970746F2E746C7331335F6B6579730103011048616E647368616B655365637265747300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E746C7331335F6B6579730103010C4561726C795365637265747300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E746C7331335F6B657973010301124170706C69636174696F6E5365637265747300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x137374642E656E636F64696E672E626173653634010301054572726F7200 = type { %sollang.enum.t524, i32 }
%sollang.struct.x137374642E656E636F64696E672E6261736536340103010A456E636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x137374642E656E636F64696E672E6261736536340103010A4465636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x137374642E656E636F64696E672E62617365363401030105436F64656300 = type { %sollang.enum.t525, %sollang.enum.t526 }
%sollang.struct.x137374642E656E636F64696E672E62617365363401030107456E636F64657200 = type { %sollang.struct.x137374642E656E636F64696E672E62617365363401030105436F64656300, i32, i32, i32, i8, i8, i32 }
%sollang.struct.x137374642E656E636F64696E672E626173653634010301074465636F64657200 = type { %sollang.struct.x137374642E656E636F64696E672E62617365363401030105436F64656300, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i1 }
%sollang.struct.x137374642E656E636F64696E672E6261736536340103010F4465636F64655772697465506C616E00 = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i1 }
%sollang.struct.x137374642E656E636F64696E672E62696E617279010301054572726F7200 = type { %sollang.enum.t528, i32 }
%sollang.struct.x137374642E656E636F64696E672E62696E6172790103010652656164657200 = type { %sollang.enum.t527, i32 }
%sollang.struct.x137374642E656E636F64696E672E62696E6172790103010657726974657200 = type { %sollang.enum.t527, i32, i32 }
%sollang.struct.x107374642E656E636F64696E672E686578010301054572726F7200 = type { %sollang.enum.t529, i32 }
%sollang.struct.x107374642E656E636F64696E672E6865780103010A456E636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x107374642E656E636F64696E672E6865780103010A4465636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x107374642E656E636F64696E672E68657801030105436F64656300 = type { i1 }
%sollang.struct.x107374642E656E636F64696E672E68657801030107456E636F64657200 = type { %sollang.struct.x107374642E656E636F64696E672E68657801030105436F64656300, i32, i32, i32 }
%sollang.struct.x107374642E656E636F64696E672E686578010301074465636F64657200 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x0E7374642E686173682E63726333320103010648617368657200 = type { %sollang.enum.t530, i32 }
%sollang.struct.x117374642E686173682E7878686173683634010301045365656400 = type { i64 }
%sollang.struct.x117374642E686173682E78786861736836340103010648617368657200 = type { i64, i64, i64, i64, i64, i64, i64, %sollang.int_slice, i32 }
%sollang.struct.x067374642E696F010301054572726F7200 = type { %sollang.enum.t531, i32 }
%sollang.struct.x067374642E696F0103010B436F70794F7574636F6D6500 = type { i32, %sollang.enum.t533 }
%sollang.struct.x067374642E696F0103010E5472616E73666572506F6C69637900 = type { i32, i32 }
%sollang.struct.x067374642E696F0103010C5265706C617942756666657200 = type { %sollang.array.i32, i32, %sollang.array.i32, i32, i32 }
%sollang.struct.x067374642E696F0103010C4D656D6F727952656164657200 = type { %sollang.array.i32, i32, i32 }
%sollang.struct.x067374642E696F0103010C4D656D6F727957726974657200 = type { %sollang.array.i32, i32 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C43616E63656C6C6174696F6E00 = type { i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010B526561645375636365737300 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727952656164657200, %sollang.array.i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010B526561644661696C75726500 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727952656164657200, %sollang.array.i32, %sollang.enum.t534 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C57726974655375636365737300 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727957726974657200, %sollang.array.i32, i32 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C57726974654661696C75726500 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727957726974657200, %sollang.array.i32, %sollang.enum.t534 }
%sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500 = type { %sollang.array.i32, i32, i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C4F666665725375636365737300 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C4F666665724661696C75726500 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, %sollang.enum.t534 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C447261696E5375636365737300 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C447261696E4661696C75726500 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, %sollang.enum.t534 }
%sollang.struct.x0B7374642E696F2E66696C650103010A4279746552656164657200 = type { %sollang.struct.x087379732E66696C650103010446696C6500, i64 }
%sollang.struct.x0B7374642E696F2E66696C650103010A4279746557726974657200 = type { %sollang.struct.x087379732E66696C650103010A46696C6557726974657200, i64 }
%sollang.struct.x0B7374642E696F2E66696C65010301104173796E63526561645375636365737300 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746552656164657200, %sollang.array.i32, i32, i1 }
%sollang.struct.x0B7374642E696F2E66696C65010301104173796E63526561644661696C75726500 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746552656164657200, %sollang.array.i32, %sollang.enum.t595 }
%sollang.struct.x0B7374642E696F2E66696C65010301114173796E6357726974655375636365737300 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746557726974657200, %sollang.array.i32, i32 }
%sollang.struct.x0B7374642E696F2E66696C65010301114173796E6357726974654661696C75726500 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746557726974657200, %sollang.array.i32, %sollang.enum.t595 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, i64 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010D4372656174654661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010B526561645375636365737300 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, i32, i1 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010B526561644661696C75726500 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010C57726974655375636365737300 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, i32 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010C57726974654661696C75726500 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x077374642E6C6F67010301054669656C6400 = type { %sollang.text, %sollang.text }
%sollang.struct.x077374642E6C6F67010301054572726F7200 = type { %sollang.text }
%sollang.struct.x077374642E6C6F67010301065265636F726400 = type { %sollang.enum.t535, %sollang.text }
%sollang.struct.x077374642E6C6F67010301064C6F6767657200 = type { %sollang.enum.t535 }
%sollang.struct.x077374642E6E65740103010B497076344164647265737300 = type { i8, i8, i8, i8 }
%sollang.struct.x077374642E6E65740103010C49707634456E64706F696E7400 = type { %sollang.struct.x077374642E6E65740103010B497076344164647265737300, i16 }
%sollang.struct.x077374642E6E65740103010B497076364164647265737300 = type { i16, i16, i16, i16, i16, i16, i16, i16 }
%sollang.struct.x077374642E6E65740103010C49707636456E64706F696E7400 = type { %sollang.struct.x077374642E6E65740103010B497076364164647265737300, i16, i32, i32 }
%sollang.struct.x077374642E6E65740103010A50617273654572726F7200 = type { %sollang.enum.t554, i32 }
%sollang.struct.x0B7374642E6E65742E646E73010301054572726F7200 = type { %sollang.enum.t539, i32 }
%sollang.struct.x0B7374642E6E65742E646E73010301085265736F6C76657200 = type { %sollang.enum.t538, i32, i32 }
%sollang.struct.x0C7374642E6E65742E68747470010301054572726F7200 = type { %sollang.enum.t546, i32 }
%sollang.struct.x0C7374642E6E65742E68747470010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x0C7374642E6E65742E68747470010301045370616E00 = type { i32, i32 }
%sollang.struct.x0C7374642E6E65742E68747470010301054669656C6400 = type { %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00 }
%sollang.struct.x0C7374642E6E65742E687474700103010650617273657200 = type { %sollang.struct.x0C7374642E6E65742E68747470010301064C696D69747300 }
%sollang.struct.x0C7374642E6E65742E687474700103010B526571756573744865616400 = type { %sollang.source_text, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.enum.t540, %sollang.array.i32, i32 }
%sollang.struct.x0C7374642E6E65742E687474700103010C526573706F6E73654865616400 = type { %sollang.source_text, %sollang.enum.t540, i32, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.array.i32, i32 }
%sollang.struct.x0C7374642E6E65742E687474700103010C5061727365644669656C647300 = type { %sollang.array.i32, i32 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900 = type { %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300 }
%sollang.struct.x117374642E6E65742E687474702E626F647901030113526573706F6E7365426F6479436F6E7465787400 = type { %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, %sollang.text }
%sollang.struct.x117374642E6E65742E687474702E626F647901030108426F6479506C616E00 = type { %sollang.enum.t541, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010C426F647950726F677265737300 = type { i32, i32, i1 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010B426F64794465636F64657200 = type { %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300, %sollang.enum.t542, %sollang.enum.t543, i32, i32, i32, i32, %sollang.array.i32, i1, i32, i32 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010D4865616465724672616D696E6700 = type { i1, i32, i1, i1 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E740103010D436C69656E744F7074696F6E7300 = type { %sollang.enum.t537, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E7401030106436C69656E7400 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E740103010845786368616E676500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32, %sollang.enum.t549, %sollang.enum.t548 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E7401030108526573706F6E736500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32, %sollang.enum.t549, %sollang.enum.t548, %sollang.array.i32, %sollang.struct.x0C7374642E6E65742E687474700103010C526573706F6E73654865616400, i32 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E740103010C526573706F6E7365426F647900 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32, %sollang.array.i32, i32, %sollang.array.i32, i32, %sollang.struct.x117374642E6E65742E687474702E626F64790103010B426F64794465636F64657200, i1, i1, i1 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010D526571756573744C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010D52657175657374506F6C69637900 = type { %sollang.struct.x147374642E6E65742E687474702E726571756573740103010D526571756573744C696D69747300 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010D5265717565737457726974657200 = type { %sollang.struct.x147374642E6E65742E687474702E726571756573740103010D526571756573744C696D69747300, %sollang.array.i32, %sollang.text, i32, i32, i1, i1, i1, i32, %sollang.enum.t548, %sollang.enum.t549 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010B526571756573744865616400 = type { %sollang.array.i32, i32, %sollang.enum.t548, %sollang.enum.t549 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E73654C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E7365506F6C69637900 = type { %sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E73654C696D69747300 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E736557726974657200 = type { %sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E73654C696D69747300, %sollang.array.i32, i32, i32, i1, i1, i1, i32, %sollang.enum.t551 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010C526573706F6E73654865616400 = type { %sollang.array.i32, i32, %sollang.enum.t551, %sollang.enum.t550 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010D5365727665724F7074696F6E7300 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4C697374656E4F7074696F6E7300, %sollang.struct.x0C7374642E6E65742E68747470010301064C696D69747300 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010653657276657200 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010B5463704C697374656E657200, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010A436F6E6E656374696F6E00 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32, %sollang.array.i32, i32 }
%sollang.struct.x137374642E6E65742E687474702E736572766572010301075265717565737400 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32, %sollang.array.i32, %sollang.struct.x0C7374642E6E65742E687474700103010B526571756573744865616400, i32, %sollang.array.i32, i32, i1 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010B52657175657374426F647900 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32, %sollang.array.i32, %sollang.struct.x0C7374642E6E65742E687474700103010B526571756573744865616400, i32, %sollang.array.i32, i32, %sollang.struct.x117374642E6E65742E687474702E626F64790103010B426F64794465636F64657200 }
%sollang.struct.x0C7374642E6E65742E7175696301030109517569634572726F7200 = type { %sollang.enum.t555, i64 }
%sollang.struct.x0C7374642E6E65742E71756963010301084964656E7469747900 = type { %sollang.int_slice }
%sollang.struct.x0C7374642E6E65742E7175696301030108456E64706F696E7400 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030109556470536F636B657400, %sollang.enum.t537, i1, %sollang.array.i32, %sollang.array.i32, i32 }
%sollang.struct.x0C7374642E6E65742E71756963010301125265636569766557696E646F7753697A657300 = type { i64, i64, i64, i64 }
%sollang.struct.x0C7374642E6E65742E7175696301030111436F6E6E656374696F6E4F7074696F6E7300 = type { i64, i64, i32, i32, i32, i64, %sollang.struct.x0C7374642E6E65742E71756963010301125265636569766557696E646F7753697A657300 }
%sollang.struct.x0C7374642E6E65742E71756963010301084C697374656E657200 = type { %sollang.struct.x0C7374642E6E65742E71756963010301084964656E7469747900, %sollang.enum.t537, %sollang.struct.x0C7374642E6E65742E7175696301030111436F6E6E656374696F6E4F7074696F6E7300, i1 }
%sollang.struct.x0C7374642E6E65742E717569630103010A436F6E6E656374696F6E00 = type { %sollang.array.i32, %sollang.enum.t537, %sollang.enum.t537, i1, i32, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301084B6579537461746500, %sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301084B6579537461746500, i64, i64, i1, %sollang.int_slice, %sollang.array.i32, %sollang.int_slice, %sollang.array.i32, i1, i1, %sollang.array.i32, %sollang.struct.x177374642E6E65742E717569632E7265617373656D626C7901030105517565756500, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i64, i32, i64, i1, i1, %sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F76657279010301074A6F75726E616C00, %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F7665727901030108527474537461746500, %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F766572790103010F436F6E67657374696F6E537461746500, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E436F6E6E656374696F6E466C6F7700, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E53747265616D526567697374727900, i64, i64, i64, i64, i64, i64, i8, i64, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103010D53656E64446972656374696F6E00 = type { %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010853656E64466C6F7700, i1, i1, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103011052656365697665446972656374696F6E00 = type { %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010B52656365697665466C6F7700, i1, i1, i64, i1, i64 }
%sollang.struct.x0C7374642E6E65742E7175696301030108426953747265616D00 = type { i64, %sollang.struct.x0C7374642E6E65742E717569630103010D53656E64446972656374696F6E00, %sollang.struct.x0C7374642E6E65742E717569630103011052656365697665446972656374696F6E00 }
%sollang.struct.x0C7374642E6E65742E717569630103010A53656E6453747265616D00 = type { i64, %sollang.struct.x0C7374642E6E65742E717569630103010D53656E64446972656374696F6E00 }
%sollang.struct.x0C7374642E6E65742E717569630103010D5265636569766553747265616D00 = type { i64, %sollang.struct.x0C7374642E6E65742E717569630103011052656365697665446972656374696F6E00 }
%sollang.struct.x0C7374642E6E65742E7175696301030105526F75746500 = type { i64, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103010B5061636B6574526F75746500 = type { i64, i8 }
%sollang.struct.x0C7374642E6E65742E717569630103010D506565725472616E73706F727400 = type { i64, i64, i64, i64, i64, i64, i64, i8, i64, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103011048616E647368616B654D65737361676500 = type { %sollang.array.i32, i32 }
%sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301084B6579537461746500 = type { i1, i32, %sollang.int_slice, %sollang.struct.x197374642E6E65742E717569632E747261666669635F6B657973010301044B65797300 }
%sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301064F70656E656400 = type { i64, i1, %sollang.enum.t556 }
%sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E650103010A4F70656E65644D616E7900 = type { i64, i1, %sollang.array.i32 }
%sollang.struct.x1D7374642E6E65742E717569632E636F6E6E656374696F6E5F737461746501030105537461746500 = type { i1, i1, i1, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E436F6E6E656374696F6E466C6F7700, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010C53747265616D4C696D69747300 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D010301084279746543656C6C00 = type { i64, i8 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D0103010D5265636569766542756666657200 = type { %sollang.array.i32, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D0103010A53656E6442756666657200 = type { %sollang.array.i32, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D010301045265616400 = type { %sollang.array.i32, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D010301054368756E6B00 = type { i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6572726F72010301054572726F7200 = type { %sollang.enum.t555, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010643727970746F00 = type { i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010653747265616D00 = type { i64, i64, i1, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010B526573657453747265616D00 = type { i64, i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010B53746F7053656E64696E6700 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D6501030108446174616772616D00 = type { %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010D4D617853747265616D4461746100 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010A4D617853747265616D7300 = type { i1, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103011153747265616D44617461426C6F636B656400 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010E53747265616D73426C6F636B656400 = type { i1, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010F436F6E6E656374696F6E436C6F736500 = type { i1, i64, i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010F4E6577436F6E6E656374696F6E496400 = type { i64, i64, %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010841636B52616E676500 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010341636B00 = type { i64, i64, i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D65010301074465636F64656400 = type { %sollang.enum.t556, i32 }
%sollang.struct.x1D7374642E6E65742E717569632E68616E647368616B655F656E67696E65010301064F70656E656400 = type { i32, i64, i64, %sollang.array.i32, i32 }
%sollang.struct.x1B7374642E6E65742E717569632E696E697469616C5F656E67696E65010301154163636570746564436C69656E74496E697469616C00 = type { i32, %sollang.array.i32, %sollang.array.i32, i64, %sollang.array.i32 }
%sollang.struct.x1B7374642E6E65742E717569632E696E697469616C5F656E67696E65010301134F70656E6564536572766572496E697469616C00 = type { %sollang.array.i32, i64, %sollang.array.i32 }
%sollang.struct.x117374642E6E65742E717569632E6B6579730103010B496E697469616C4B65797300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F7665727901030108527474537461746500 = type { i1, i64, i64, i64, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F766572790103010F436F6E67657374696F6E537461746500 = type { i64, i64, i64, i64, i1 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400 = type { %sollang.int_slice }
%sollang.struct.x107374642E6E65742E717569632E703270010301084964656E7469747900 = type { %sollang.struct.x0C7374642E6E65742E71756963010301084964656E7469747900, %sollang.int_slice, %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010A506565725265636F726400 = type { %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400, %sollang.int_slice, %sollang.struct.x077374642E6E65740103010C49707634456E64706F696E7400, i64, %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x107374642E6E65742E717569632E7032700103010753657373696F6E00 = type { %sollang.struct.x0C7374642E6E65742E717569630103010A436F6E6E656374696F6E00, %sollang.struct.x0C7374642E6E65742E7175696301030108426953747265616D00, %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010E50726F746F636F6C53747265616D00 = type { %sollang.array.i32 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010D41757468656E7469636174656400 = type { %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400, %sollang.struct.x0C7374642E6E65742E7175696301030108426953747265616D00 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010D4F70656E6564496E697469616C00 = type { i32, i64, %sollang.array.i32, i32 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010D496E697469616C48656164657200 = type { i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32, i32 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010F4F70656E656448616E647368616B6500 = type { i32, i64, %sollang.array.i32, i32 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010F48616E647368616B6548656164657200 = type { i32, %sollang.array.i32, %sollang.array.i32, i32, i32 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010C4F70656E65644F6E6552747400 = type { i1, i64, %sollang.array.i32 }
%sollang.struct.x137374642E6E65742E717569632E7061636B6574010301134F70656E656450726F7465637465644C6F6E6700 = type { i8, i64, %sollang.array.i32 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010950726F746563746F7200 = type { %sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E0103011150726570617265645061636B65744B657900, %sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301094865616465724B657900 }
%sollang.struct.x1A7374642E6E65742E717569632E7061636B65745F6E756D626572010301095472756E636174656400 = type { i32, i32 }
%sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F766572790103010A53656E745061636B657400 = type { i64, i64, i64, i1, i1 }
%sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F766572790103010655706461746500 = type { %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F7665727901030108527474537461746500, %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F766572790103010F436F6E67657374696F6E537461746500, i64, i64, i64, i64 }
%sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F76657279010301074A6F75726E616C00 = type { %sollang.array.i32 }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301094D61736B56616C756500 = type { %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E0103010A4E6F6E636556616C756500 = type { %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301095061636B65744B657900 = type { %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301094865616465724B657900 = type { %sollang.struct.x117374642E63727970746F2E616573313238010301034B657900 }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E0103011150726570617265645061636B65744B657900 = type { %sollang.struct.x157374642E63727970746F2E6165733132385F67636D010301034B657900, %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E7265617373656D626C79010301094163636F756E74656400 = type { %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010B52656365697665466C6F7700, i64 }
%sollang.struct.x177374642E6E65742E717569632E7265617373656D626C7901030105517565756500 = type { %sollang.array.i32, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E53747265616D4964656E7469747900 = type { i64, i64, %sollang.enum.t557, %sollang.enum.t558 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010B52656365697665466C6F7700 = type { i64, i64, i64, i1, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010853656E64466C6F7700 = type { i64, i64, i1, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E436F6E6E656374696F6E466C6F7700 = type { i64, i64, i64, i64, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010C53747265616D4C696D69747300 = type { i64, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E53747265616D526567697374727900 = type { i1, i64, i64, i1, i1, i64, i64, i64, i64, i64, i64, i32, %sollang.array.i32, i32, i32, i32, i32, %sollang.array.i32, i32, i32, i32 }
%sollang.struct.x157374642E6E65742E717569632E746C735F617574680103010B436572746966696361746500 = type { %sollang.array.i32 }
%sollang.struct.x157374642E6E65742E717569632E746C735F6175746801030111436572746966696361746556657269667900 = type { i16, %sollang.array.i32 }
%sollang.struct.x1D7374642E6E65742E717569632E746C735F636C69656E745F737461746501030105537461746500 = type { %sollang.enum.t559, %sollang.struct.x1B7374642E6E65742E717569632E746C735F7472616E7363726970740103010A5472616E73637269707400, %sollang.int_slice }
%sollang.struct.x1A7374642E6E65742E717569632E746C735F68616E647368616B65010301074465636F64656400 = type { i8, %sollang.array.i32, i32 }
%sollang.struct.x1A7374642E6E65742E717569632E746C735F68616E647368616B65010301104465636F646564457874656E73696F6E00 = type { i16, %sollang.array.i32, i32 }
%sollang.struct.x167374642E6E65742E717569632E746C735F68656C6C6F0103010B436C69656E7448656C6C6F00 = type { %sollang.int_slice, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.int_slice, %sollang.array.i32 }
%sollang.struct.x167374642E6E65742E717569632E746C735F68656C6C6F0103010B53657276657248656C6C6F00 = type { %sollang.int_slice, %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x167374642E6E65742E717569632E746C735F68656C6C6F01030113456E63727970746564457874656E73696F6E7300 = type { %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x1D7374642E6E65742E717569632E746C735F7365727665725F737461746501030105537461746500 = type { %sollang.enum.t560, %sollang.struct.x1B7374642E6E65742E717569632E746C735F7472616E7363726970740103010A5472616E73637269707400 }
%sollang.struct.x1B7374642E6E65742E717569632E746C735F7472616E7363726970740103010A5472616E73637269707400 = type { %sollang.array.i32 }
%sollang.struct.x197374642E6E65742E717569632E747261666669635F6B657973010301044B65797300 = type { %sollang.struct.x137374642E6E65742E717569632E7061636B65740103010950726F746563746F7200 }
%sollang.struct.x217374642E6E65742E717569632E7472616E73706F72745F706172616D6574657273010301074465636F64656400 = type { i64, %sollang.array.i32, i32 }
%sollang.struct.x217374642E6E65742E717569632E7472616E73706F72745F706172616D65746572730103010B53747265616D436F756E7400 = type { i64 }
%sollang.struct.x137374642E6E65742E717569632E766172696E74010301074465636F64656400 = type { i64, i32 }
%sollang.struct.x207374642E6E65742E717569632E76657273696F6E5F6E65676F74696174696F6E0103010B496E666F726D6174696F6E00 = type { i32, %sollang.array.i32 }
%sollang.struct.x1B7374642E6E65742E717569632E76657273696F6E5F7061636B6574010301065061636B657400 = type { %sollang.array.i32, %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x197374642E6E65742E717569632E783530395F6564323535313901030107456C656D656E7400 = type { i8, i32, i32, i32 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D4C697374656E4F7074696F6E7300 = type { %sollang.enum.t537, i32, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030113446174616772616D42696E644F7074696F6E7300 = type { %sollang.enum.t537, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010B5463704C697374656E657200 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030109556470536F636B657400 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010A53656E6442756666657200 = type { ptr, i32, i32 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D5265636569766542756666657200 = type { %sollang.array.i32 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030108496E74657265737400 = type { i64, %sollang.enum.t564, %sollang.enum.t563 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010A52656164794576656E7400 = type { i64, i1, i1, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030118436F6D706C6574696F6E52656163746F724F7074696F6E7300 = type { i32, i32, i32 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400 = type { i64, %sollang.enum.t565, %sollang.array.i32, i32, i32, %sollang.enum.t566, %sollang.enum.t1067, %sollang.enum.t1068, %sollang.enum.t677 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030119536F636B6574526567697374726174696F6E4661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D52656D6F76656453747265616D00 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030115436F6D706C6574696F6E576169744661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030110536F636B6574436F6D706C6574696F6E00 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103011B436F6D706C6574696F6E5375626D697373696F6E4661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030115536C6F745472616E736974696F6E4661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010752656163746F7200 = type { i32, %sollang.array.i32 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030108446174616772616D00 = type { %sollang.enum.t537, %sollang.array.i32, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010F446174616772616D5265636569707400 = type { %sollang.enum.t537, i32, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 = type { %sollang.enum.t569, i32 }
%sollang.struct.x087374642E70617468010301054572726F7200 = type { %sollang.enum.t571, i32 }
%sollang.struct.x087374642E70617468010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x087374642E7061746801030109436F6D706F6E656E7400 = type { %sollang.enum.t570, i32, i32 }
%sollang.struct.x087374642E706174680103010648656164657200 = type { %sollang.enum.t570, i32, i1 }
%sollang.struct.x087374642E706174680103010A436F6D706F6E656E747300 = type { %sollang.source_text, i32, i32, i32, i1, %sollang.struct.x087374642E70617468010301064C696D69747300, %sollang.struct.x087374642E706174680103010648656164657200 }
%sollang.struct.x0C7374642E746578742E637376010301054572726F7200 = type { %sollang.enum.t573, i32, i32 }
%sollang.struct.x0C7374642E746578742E637376010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0C7374642E746578742E6373760103010C5772697465724C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0C7374642E746578742E63737601030106466F726D617400 = type { %sollang.enum.t572, i32 }
%sollang.struct.x0C7374642E746578742E637376010301054669656C6400 = type { i32, i32, i32, i1 }
%sollang.struct.x0C7374642E746578742E6373760103010652656164657200 = type { %sollang.source_text, i32, i32, i32, i32, i1, %sollang.struct.x0C7374642E746578742E63737601030106466F726D617400, %sollang.struct.x0C7374642E746578742E637376010301064C696D69747300 }
%sollang.struct.x0C7374642E746578742E6373760103010657726974657200 = type { %sollang.struct.x0C7374642E746578742E6373760103010C5772697465724C696D69747300, i32, i32, i32, i32 }
%sollang.struct.x0C7374642E746578742E6373760103010C5363616E6E65644669656C6400 = type { i32, i32, i32, i32, i1, i1 }
%sollang.struct.x0D7374642E746578742E676C6F62010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x0D7374642E746578742E676C6F62010301054572726F7200 = type { %sollang.enum.t574, i32, i32 }
%sollang.struct.x0D7374642E746578742E676C6F62010301075061747465726E00 = type { %sollang.source_text, i32, i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E010301054572726F7200 = type { %sollang.enum.t577, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E01030105546F6B656E00 = type { %sollang.enum.t575, i32, i32, i32, i32, i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E010301064D656D62657200 = type { %sollang.array.i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010556616C756500 = type { %sollang.enum.t576, i32, i32, i1, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E01030108446F63756D656E7400 = type { %sollang.array.i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010652656164657200 = type { %sollang.source_text, i32, i32, i8, i32, %sollang.struct.x0D7374642E746578742E6A736F6E010301064C696D69747300, %sollang.array.i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010657726974657200 = type { %sollang.array.i32, i32, i32, i32, i8, %sollang.array.i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010A537472696E675363616E00 = type { i32, i32, i32 }
%sollang.struct.x0E7374642E746578742E7265676578010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0E7374642E746578742E7265676578010301054572726F7200 = type { %sollang.enum.t578, i32, i32, i32 }
%sollang.struct.x0E7374642E746578742E7265676578010301054D6174636800 = type { i32, i32 }
%sollang.struct.x0E7374642E746578742E7265676578010301075061747465726E00 = type { %sollang.source_text, i32, i32, i32, i32, i1, i1, i32, i32 }
%sollang.struct.x0E7374642E746578742E72656765780103010441746F6D00 = type { %sollang.enum.t579, i32, i32, i32, i1, %sollang.enum.t580, i32 }
%sollang.struct.x0E7374642E746578742E726567657801030109436C617373556E697400 = type { i8, i32 }
%sollang.struct.x0E7374642E746578742E726567657801030104576F726B00 = type { i32 }
%sollang.struct.x087374642E74696D65010301084475726174696F6E00 = type { i64 }
%sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400 = type { i64, i64 }
%sollang.struct.x087374642E74696D650103010A557463496E7374616E7400 = type { i64 }
%sollang.struct.x087374642E74696D650103010C43616C656E6461724461746500 = type { i64, i64, i64 }
%sollang.struct.x087374642E74696D650103010E4D6F6E6F746F6E6963436C6F636B00 = type { i8 }
%sollang.struct.x087374642E74696D650103010957616C6C436C6F636B00 = type { i8 }
%sollang.struct.x087374642E74696D650103010B4D616E75616C436C6F636B00 = type { i64, i64 }
%sollang.struct.x087374642E74696D650103010F4D616E75616C57616C6C436C6F636B00 = type { i64 }
%sollang.struct.x087374642E74696D6501030108446561646C696E6500 = type { %sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400 }
%sollang.struct.x087374642E74696D650103010A4669786564436C6F636B00 = type { %sollang.struct.x087374642E74696D650103010A557463496E7374616E7400 }
%sollang.struct.x087374642E74696D650103010B4F6666736574436C6F636B00 = type { i64 }
%sollang.struct.x087374642E74696D6501030111436C6F636B4361706162696C697469657300 = type { %sollang.struct.x087374642E74696D65010301084475726174696F6E00, %sollang.enum.t581, %sollang.struct.x087374642E74696D65010301084475726174696F6E00 }
%sollang.struct.x087374642E74696D650103010554696D657200 = type { %sollang.array.i32, %sollang.struct.x087374642E74696D65010301084475726174696F6E00, i64, %sollang.enum.t582 }
%sollang.struct.x087374642E74696D650103010954696D65725469636B00 = type { %sollang.struct.x087374642E74696D650103010554696D657200, %sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400, %sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400, i64 }
%sollang.struct.x087374642E74696D65010301054572726F7200 = type { %sollang.enum.t583 }
%sollang.struct.x077374642E757269010301054572726F7200 = type { %sollang.enum.t587, i32 }
%sollang.struct.x077374642E757269010301045370616E00 = type { i32, i32, i1 }
%sollang.struct.x077374642E75726901030109417574686F7269747900 = type { %sollang.struct.x077374642E757269010301045370616E00, %sollang.enum.t584, %sollang.enum.t585, %sollang.struct.x077374642E757269010301045370616E00 }
%sollang.struct.x077374642E757269010301095265666572656E636500 = type { %sollang.source_text, %sollang.struct.x077374642E757269010301045370616E00, %sollang.enum.t586, %sollang.struct.x077374642E757269010301045370616E00, %sollang.struct.x077374642E757269010301045370616E00, %sollang.struct.x077374642E757269010301045370616E00 }
%sollang.struct.x077374642E757269010301134E6F726D616C697A6174696F6E506F6C69637900 = type { i1, i1, i1, i1, i1 }
%sollang.struct.x0F7374642E7572692E70657263656E74010301054572726F7200 = type { %sollang.enum.t588, i32 }
%sollang.struct.x0F7374642E7572692E70657263656E7401030104506C616E00 = type { i32, i32 }
%sollang.struct.x0F7374642E7572692E70657263656E7401030105436F64656300 = type { %sollang.enum.t589 }
%sollang.struct.x087374642E75756964010301054572726F7200 = type { %sollang.enum.t591, i32 }
%sollang.struct.x087374642E75756964010301045575696400 = type { %sollang.int_slice }
%sollang.struct.x087374642E7575696401030105436F64656300 = type { i8 }
%sollang.struct.x087374642E757569640103010947656E657261746F7200 = type { %sollang.struct.x087374642E74696D650103010957616C6C436C6F636B00, %sollang.struct.x117374642E63727970746F2E72616E646F6D0103010C53656375726552616E646F6D00 }
%sollang.struct.x0D7379732E6469726563746F72790103010352617700 = type { %sollang.array.i32, i32 }
%sollang.struct.x0D7379732E6469726563746F727901030105456E74727900 = type { %sollang.struct.x087379732E70617468010301045061746800, %sollang.enum.t594 }
%sollang.struct.x087379732E66696C650103010446696C6500 = type { i64 }
%sollang.struct.x087379732E66696C650103010A46696C6557726974657200 = type { i64 }
%sollang.struct.x087379732E66696C650103011441746F6D69635265706C6163655265717565737400 = type { %sollang.text, %sollang.text }
%sollang.struct.x087379732E66696C650103010A536F757263655465787400 = type {  }
%sollang.struct.x087379732E66696C650103010D5265616441745375636365737300 = type { %sollang.struct.x087379732E66696C650103010446696C6500, %sollang.array.i32, i32, i1 }
%sollang.struct.x087379732E66696C650103010D5265616441744661696C75726500 = type { %sollang.struct.x087379732E66696C650103010446696C6500, %sollang.array.i32, %sollang.enum.t595 }
%sollang.struct.x087379732E66696C650103010E577269746541745375636365737300 = type { %sollang.struct.x087379732E66696C650103010A46696C6557726974657200, %sollang.array.i32, i32 }
%sollang.struct.x087379732E66696C650103010E577269746541744661696C75726500 = type { %sollang.struct.x087379732E66696C650103010A46696C6557726974657200, %sollang.array.i32, %sollang.enum.t595 }
%sollang.struct.x0F7379732E696E7075742E6D6F757365010301054576656E7400 = type { i32, i32, i32, i32, %sollang.enum.t596 }
%sollang.struct.x0F7379732E696E7075742E6D6F757365010301054572726F7200 = type { %sollang.enum.t598, i32 }
%sollang.struct.x0F7379732E696E7075742E6D6F75736501030106536F7572636500 = type { i32, %sollang.enum.t597 }
%sollang.struct.x087379732E70617468010301045061746800 = type { %sollang.array.i32, %sollang.enum.t599 }
%sollang.struct.x087379732E7061746801030107526177496E666F00 = type { %sollang.array.i32, i8, i64, i64 }
%sollang.struct.x087379732E7061746801030104496E666F00 = type { %sollang.struct.x087379732E70617468010301045061746800, %sollang.enum.t594, i64, i64 }
%sollang.struct.x0B7379732E70726F6365737301030111456E7669726F6E6D656E744368616E676500 = type { %sollang.text, %sollang.text, i1 }
%sollang.struct.x0B7379732E70726F636573730103010D436170747572654C696D69747300 = type { i32, i32 }
%sollang.struct.x0B7379732E70726F636573730103010E43617074757265644F757470757400 = type { %sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300, %sollang.array.i32, %sollang.array.i32, i1, i1 }
%sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 = type { %sollang.array.i32, %sollang.text, i1, %sollang.array.i32, i1, %sollang.enum.t600, %sollang.enum.t601, %sollang.enum.t601 }
%sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 = type { i32 }
%sollang.struct.x0B7379732E70726F636573730103010C5369676E616C53746174757300 = type { i32 }
%sollang.struct.x0B7379732E70726F636573730103010950726F63657373496400 = type { i64 }
%sollang.struct.x0B7379732E70726F63657373010301054368696C6400 = type { i64, %sollang.struct.x0B7379732E70726F636573730103010950726F63657373496400, i32, i32 }
%sollang.struct.x0B7379732E70726F63657373010301094368696C64506F6C6C00 = type { i32, i32 }
%sollang.struct.x067374642E696F0105010652656164657200 = type {  }
%sollang.struct.x067374642E696F0105010657726974657200 = type {  }
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture)
%sollang.dyn = type { ptr, ptr }
%sollang.mutable_container = type { ptr, ptr, ptr }
%sollang.int_slice = type { ptr, i64 }
%sollang.array.i32 = type { ptr, i64, i64 }
define internal void @sollang_drop_t697(%sollang.array.i32 %value) {
entry:
  %data = extractvalue %sollang.array.i32 %value, 0
  %length = extractvalue %sollang.array.i32 %value, 1
  call void @sollang_free(ptr %data)
  ret void
}
declare void @llvm.trap()
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011764657269766545787465726E616C42696E6465724B65794E01067075626C6963011764657269766545787465726E616C42696E6465724B6579010370736B18013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [10 x i8] c"ext binder"
@sollang_str_x157374642E63727970746F2E746C7331335F6B65797301070119646572697665526573756D7074696F6E42696E6465724B65795001067075626C69630119646572697665526573756D7074696F6E42696E6465724B6579010370736B18013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [10 x i8] c"res binder"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701136465726976654561726C7946726F6D486173687201067075626C696301136465726976654561726C7946726F6D48617368010370736B18013A07015B010555496E743808015D0E012C0119636C69656E7448656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E010C4561726C7953656372657473_00 = private unnamed_addr constant [11 x i8] c"c e traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701136465726976654561726C7946726F6D486173687201067075626C696301136465726976654561726C7946726F6D48617368010370736B18013A07015B010555496E743808015D0E012C0119636C69656E7448656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E010C4561726C7953656372657473_01 = private unnamed_addr constant [12 x i8] c"e exp master"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_00 = private unnamed_addr constant [7 x i8] c"derived"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_01 = private unnamed_addr constant [12 x i8] c"c hs traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_02 = private unnamed_addr constant [12 x i8] c"s hs traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_03 = private unnamed_addr constant [7 x i8] c"derived"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701196465726976654170706C69636174696F6E46726F6D48617368880101067075626C696301196465726976654170706C69636174696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C73657276657246696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E01124170706C69636174696F6E53656372657473_00 = private unnamed_addr constant [12 x i8] c"c ap traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701196465726976654170706C69636174696F6E46726F6D48617368880101067075626C696301196465726976654170706C69636174696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C73657276657246696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E01124170706C69636174696F6E53656372657473_01 = private unnamed_addr constant [12 x i8] c"s ap traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701196465726976654170706C69636174696F6E46726F6D48617368880101067075626C696301196465726976654170706C69636174696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C73657276657246696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E01124170706C69636174696F6E53656372657473_02 = private unnamed_addr constant [10 x i8] c"exp master"
@sollang_str_x157374642E63727970746F2E746C7331335F6B65797301070118646572697665526573756D7074696F6E46726F6D48617368870101067075626C69630118646572697665526573756D7074696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C636C69656E7446696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [10 x i8] c"res master"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011A66696E69736865645665726966794461746146726F6D486173687801067075626C6963011A66696E69736865645665726966794461746146726F6D486173680107626173654B657918013A07015B010555496E743808015D0E012C010E7472616E7363726970744861736818013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [8 x i8] c"finished"
@sollang_str_x157374642E63727970746F2E746C7331335F6B65797301070113757064617465547261666669635365637265744D01067075626C6963011375706461746554726166666963536563726574010673656372657418013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [11 x i8] c"traffic upd"
@sollang_str_x0C7374642E6E65742E687474700107010C706172736556657273696F6E8401010C706172736556657273696F6E0106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C0105737461727418013A010855496E7453697A650E012C0103656E6418013A010855496E7453697A6516022D3E0106526573756C741E013C010756657273696F6E0E012C01054572726F721F013E_00 = private unnamed_addr constant [8 x i8] c"HTTP/1.0"
@sollang_str_x0C7374642E6E65742E687474700107010C706172736556657273696F6E8401010C706172736556657273696F6E0106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C0105737461727418013A010855496E7453697A650E012C0103656E6418013A010855496E7453697A6516022D3E0106526573756C741E013C010756657273696F6E0E012C01054572726F721F013E_01 = private unnamed_addr constant [8 x i8] c"HTTP/1.1"
@sollang_str_x117374642E6E65742E687474702E626F64790107011570617273655472616E73666572456E636F64696E678301011570617273655472616E73666572456E636F64696E670106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C010576616C756518013A0104687474700D012E01045370616E16022D3E0106526573756C741E013C0104426F6F6C0E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [7 x i8] c"chunked"
@sollang_str_x117374642E6E65742E687474702E626F64790107010D6865616465724672616D696E67B101010D6865616465724672616D696E670106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C01066669656C647318013A010372656607015B0104687474700D012E01054669656C640F013B0C017E08015D0E012C01066C696D69747318013A010A426F64794C696D69747316022D3E0106526573756C741E013C010D4865616465724672616D696E670E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x117374642E6E65742E687474702E626F64790107010D6865616465724672616D696E67B101010D6865616465724672616D696E670106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C01066669656C647318013A010372656607015B0104687474700D012E01054669656C640F013B0C017E08015D0E012C01066C696D69747318013A010A426F64794C696D69747316022D3E0106526573756C741E013C010D4865616465724672616D696E670E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F76616C6964617465547261696C65725A010F76616C6964617465547261696C657201076465636F64657218013A0103726566010B426F64794465636F64657216022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F76616C6964617465547261696C65725A010F76616C6964617465547261696C657201076465636F64657218013A0103726566010B426F64794465636F64657216022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F73656C6563745265706C79426F64798901010F73656C6563745265706C79426F64790107636F6E7465787418013A0113526573706F6E7365426F6479436F6E746578740E012C01046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0108426F6479506C616E0E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F73656C6563745265706C79426F64798901010F73656C6563745265706C79426F64790107636F6E7465787418013A0113526573706F6E7365426F6479436F6E746578740E012C01046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0108426F6479506C616E0E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x137374642E6E65742E687474702E636C69656E7401070119726573706F6E7365416C6C6F777350657273697374656E6365620119726573706F6E7365416C6C6F777350657273697374656E636501046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_00 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x137374642E6E65742E687474702E636C69656E7401070119726573706F6E7365416C6C6F777350657273697374656E6365620119726573706F6E7365416C6C6F777350657273697374656E636501046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"close"
@sollang_str_x137374642E6E65742E687474702E636C69656E7401070119726573706F6E7365416C6C6F777350657273697374656E6365620119726573706F6E7365416C6C6F777350657273697374656E636501046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_02 = private unnamed_addr constant [10 x i8] c"keep-alive"
@sollang_str_x137374642E6E65742E687474702E636C69656E7402060108526573706F6E7365100104696D706C0108526573706F6E73651F01086F70656E426F64794B01067075626C696301086F70656E426F647918013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365426F64790E012C01054572726F721F013E_00 = private unnamed_addr constant [3 x i8] c"GET"
@sollang_str_x137374642E6E65742E687474702E636C69656E7402060108526573706F6E7365100104696D706C0108526573706F6E73651F01086F70656E426F64794B01067075626C696301086F70656E426F647918013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365426F64790E012C01054572726F721F013E_01 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x137374642E6E65742E687474702E636C69656E7402060108526573706F6E7365100104696D706C0108526573706F6E73651F01086F70656E426F64794B01067075626C696301086F70656E426F647918013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365426F64790E012C01054572726F721F013E_02 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E7265717565737401070119636C617373696679526573706F6E736553656D616E74696373430119636C617373696679526573706F6E736553656D616E7469637301066D6574686F6418013A01045465787416022D3E0111526573706F6E736553656D616E74696373_00 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x147374642E6E65742E687474702E7265717565737401070119636C617373696679526573706F6E736553656D616E74696373430119636C617373696679526573706F6E736553656D616E7469637301066D6574686F6418013A01045465787416022D3E0111526573706F6E736553656D616E74696373_01 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_00 = private unnamed_addr constant [4 x i8] c"Host"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_01 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_02 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_03 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_04 = private unnamed_addr constant [7 x i8] c"Trailer"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_00 = private unnamed_addr constant [8 x i8] c"HTTP/1.0"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_01 = private unnamed_addr constant [8 x i8] c"HTTP/1.1"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_00 = private unnamed_addr constant [2 x i8] c": "
@sollang_str_x147374642E6E65742E687474702E726571756573740107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x147374642E6E65742E687474702E7265717565737401070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_00 = private unnamed_addr constant [16 x i8] c"Content-Length: "
@sollang_str_x147374642E6E65742E687474702E7265717565737401070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_03 = private unnamed_addr constant [7 x i8] c"OPTIONS"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374506F6C696379150104696D706C010D52657175657374506F6C6963791F010772657175657374F50101067075626C696301077265717565737418013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C0109617574686F7269747918013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010D526571756573745772697465720E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"Host"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [5 x i8] c"close"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_03 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_04 = private unnamed_addr constant [10 x i8] c"keep-alive"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_05 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_00 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_01 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_02 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_03 = private unnamed_addr constant [7 x i8] c"Trailer"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_00 = private unnamed_addr constant [8 x i8] c"HTTP/1.0"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_01 = private unnamed_addr constant [8 x i8] c"HTTP/1.1"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_00 = private unnamed_addr constant [2 x i8] c": "
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E736501070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_00 = private unnamed_addr constant [16 x i8] c"Content-Length: "
@sollang_str_x157374642E6E65742E687474702E726573706F6E736501070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365506F6C696379160104696D706C010E526573706F6E7365506F6C6963791F0108726573706F6E7365EA0101067075626C69630108726573706F6E736518013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C010673746174757318013A0103496E740E012C0106726561736F6E18013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010E526573706F6E73655772697465720E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365506F6C696379160104696D706C010E526573706F6E7365506F6C6963791F0108726573706F6E7365EA0101067075626C69630108726573706F6E736518013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C010673746174757318013A0103496E740E012C0106726561736F6E18013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010E526573706F6E73655772697465720E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365506F6C696379160104696D706C010E526573706F6E7365506F6C6963791F0108726573706F6E7365EA0101067075626C69630108726573706F6E736518013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C010673746174757318013A0103496E740E012C0106726561736F6E18013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010E526573706F6E73655772697465720E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"close"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_03 = private unnamed_addr constant [10 x i8] c"keep-alive"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_04 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_00 = private unnamed_addr constant [9 x i8] c"client in"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_01 = private unnamed_addr constant [9 x i8] c"server in"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_02 = private unnamed_addr constant [10 x i8] c"quicv2 key"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_03 = private unnamed_addr constant [8 x i8] c"quic key"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_04 = private unnamed_addr constant [9 x i8] c"quicv2 iv"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_05 = private unnamed_addr constant [7 x i8] c"quic iv"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_06 = private unnamed_addr constant [9 x i8] c"quicv2 hp"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_07 = private unnamed_addr constant [7 x i8] c"quic hp"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_00 = private unnamed_addr constant [10 x i8] c"quicv2 key"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_01 = private unnamed_addr constant [8 x i8] c"quic key"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_02 = private unnamed_addr constant [9 x i8] c"quicv2 iv"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_03 = private unnamed_addr constant [7 x i8] c"quic iv"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_04 = private unnamed_addr constant [9 x i8] c"quicv2 hp"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_05 = private unnamed_addr constant [7 x i8] c"quic hp"
@sollang_str_x0D7374642E746578742E6A736F6E020601065265616465720E0104696D706C01065265616465721F0107626F6F6C65616E5001067075626C69630107626F6F6C65616E18013A010473656C660E012C0105746F6B656E18013A0105546F6B656E16022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E020601065265616465720E0104696D706C01065265616465721F0107626F6F6C65616E5001067075626C69630107626F6F6C65616E18013A010473656C660E012C0105746F6B656E18013A0105546F6B656E16022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x0D7374642E746578742E6A736F6E020601065265616465720E0104696D706C01065265616465721F01096E756C6C56616C75655201067075626C696301096E756C6C56616C756518013A010473656C660E012C0105746F6B656E18013A0105546F6B656E16022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E010701097363616E56616C75655801097363616E56616C7565010672656164657218013A01036D757401065265616465720E012C0105646570746818013A0103496E7416022D3E0106526573756C741E013C0105546F6B656E0E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E010701097363616E56616C75655801097363616E56616C7565010672656164657218013A01036D757401065265616465720E012C0105646570746818013A0103496E7416022D3E0106526573756C741E013C0105546F6B656E0E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x0D7374642E746578742E6A736F6E010701097363616E56616C75655801097363616E56616C7565010672656164657218013A01036D757401065265616465720E012C0105646570746818013A0103496E7416022D3E0106526573756C741E013C0105546F6B656E0E012C01054572726F721F013E_02 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E0107011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E748501011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E74010576616C756518013A0103726566010556616C75650E012C01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C0108646F63756D656E7418013A01037265660108446F63756D656E7416022D3E0104556E6974_00 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E0107011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E748501011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E74010576616C756518013A0103726566010556616C75650E012C01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C0108646F63756D656E7418013A01037265660108446F63756D656E7416022D3E0104556E6974_01 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E0107011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E748501011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E74010576616C756518013A0103726566010556616C75650E012C01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C0108646F63756D656E7418013A01037265660108446F63756D656E7416022D3E0104556E6974_02 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F0105696E7436345301067075626C69630105696E74363418013A01036D7574010473656C660E012C010576616C756518013A0105496E74363416022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [6 x i8] c"$value"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F010675696E7436345501067075626C6963010675696E74363418013A01036D7574010473656C660E012C010576616C756518013A010655496E74363416022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [6 x i8] c"$value"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F01096E756C6C56616C75654301067075626C696301096E756C6C56616C756518013A01036D7574010473656C6616022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F0107626F6F6C65616E5401067075626C69630107626F6F6C65616E18013A01036D7574010473656C660E012C010576616C756518013A0104426F6F6C16022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F0107626F6F6C65616E5401067075626C69630107626F6F6C65616E18013A01036D7574010473656C660E012C010576616C756518013A0104426F6F6C16022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F0115617574686F7269747955736572496E666F546578743201067075626C69630115617574686F7269747955736572496E666F5465787418013A010473656C6616022D3E010454657874_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F010E726567697374657265644E616D652B01067075626C6963010E726567697374657265644E616D6518013A010473656C6616022D3E010454657874_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F010E726567697374657265644E616D652B01067075626C6963010E726567697374657265644E616D6518013A010473656C6616022D3E010454657874_01 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F010E726567697374657265644E616D652B01067075626C6963010E726567697374657265644E616D6518013A010473656C6616022D3E010454657874_02 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_00 = private unnamed_addr constant [1 x i8] c"0"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_01 = private unnamed_addr constant [1 x i8] c"1"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_02 = private unnamed_addr constant [1 x i8] c"2"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_03 = private unnamed_addr constant [1 x i8] c"3"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_04 = private unnamed_addr constant [1 x i8] c"4"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_05 = private unnamed_addr constant [1 x i8] c"5"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_06 = private unnamed_addr constant [1 x i8] c"6"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_07 = private unnamed_addr constant [1 x i8] c"7"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_08 = private unnamed_addr constant [1 x i8] c"8"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_09 = private unnamed_addr constant [1 x i8] c"9"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0A = private unnamed_addr constant [1 x i8] c"a"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0B = private unnamed_addr constant [1 x i8] c"b"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0C = private unnamed_addr constant [1 x i8] c"c"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0D = private unnamed_addr constant [1 x i8] c"d"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0E = private unnamed_addr constant [1 x i8] c"e"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0F = private unnamed_addr constant [1 x i8] c"f"
@sollang_str_x087374642E7575696402060104557569640C0104696D706C0104557569641F0104746578743C01067075626C696301047465787418013A010473656C660E012C010773746F7261676518013A01036D757401054172656E6116022D3E010454657874_00 = private unnamed_addr constant [1296 x i8] c"$((Int(self.bytes[0]) / 16) -> hexDigit)$((Int(self.bytes[0]) % 16) -> hexDigit)$((Int(self.bytes[1]) / 16) -> hexDigit)$((Int(self.bytes[1]) % 16) -> hexDigit)$((Int(self.bytes[2]) / 16) -> hexDigit)$((Int(self.bytes[2]) % 16) -> hexDigit)$((Int(self.bytes[3]) / 16) -> hexDigit)$((Int(self.bytes[3]) % 16) -> hexDigit)-$((Int(self.bytes[4]) / 16) -> hexDigit)$((Int(self.bytes[4]) % 16) -> hexDigit)$((Int(self.bytes[5]) / 16) -> hexDigit)$((Int(self.bytes[5]) % 16) -> hexDigit)-$((Int(self.bytes[6]) / 16) -> hexDigit)$((Int(self.bytes[6]) % 16) -> hexDigit)$((Int(self.bytes[7]) / 16) -> hexDigit)$((Int(self.bytes[7]) % 16) -> hexDigit)-$((Int(self.bytes[8]) / 16) -> hexDigit)$((Int(self.bytes[8]) % 16) -> hexDigit)$((Int(self.bytes[9]) / 16) -> hexDigit)$((Int(self.bytes[9]) % 16) -> hexDigit)-$((Int(self.bytes[10]) / 16) -> hexDigit)$((Int(self.bytes[10]) % 16) -> hexDigit)$((Int(self.bytes[11]) / 16) -> hexDigit)$((Int(self.bytes[11]) % 16) -> hexDigit)$((Int(self.bytes[12]) / 16) -> hexDigit)$((Int(self.bytes[12]) % 16) -> hexDigit)$((Int(self.bytes[13]) / 16) -> hexDigit)$((Int(self.bytes[13]) % 16) -> hexDigit)$((Int(self.bytes[14]) / 16) -> hexDigit)$((Int(self.bytes[14]) % 16) -> hexDigit)$((Int(self.bytes[15]) / 16) -> hexDigit)$((Int(self.bytes[15]) % 16) -> hexDigit)"
@sollang_str_x0D7379732E6469726563746F727901070104726561644701067075626C696301047265616401096469726563746F727918013A0104706174680D012E01045061746816022D3E010A52656164526573756C74010475736573010446696C65_00 = private unnamed_addr constant [2 x i8] c"io"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F010571756572794501067075626C69630105717565727918013A010473656C6616022D3E0106526573756C741E013C0104496E666F0E012C0104546578741F013E010475736573010446696C65_00 = private unnamed_addr constant [2 x i8] c"io"
@sollang_str_x087379732E706174680107010966726F6D42797465736B01067075626C6963010966726F6D4279746573010576616C756518013A01046D6F766507015B010555496E74380F013B0C017E08015D0E012C01057374796C6518013A01055374796C6516022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [23 x i8] c"path is not valid UTF-8"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01046A6F696E5101067075626C696301046A6F696E18013A01046D6F7665010473656C660E012C01056368696C6418013A01045465787416022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [19 x i8] c"absolute child path"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01086A6F696E506174685401067075626C696301086A6F696E5061746818013A010473656C660E012C01056368696C6418013A010372656601045061746816022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [18 x i8] c"path styles differ"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01086A6F696E506174685401067075626C696301086A6F696E5061746818013A010473656C660E012C01056368696C6418013A010372656601045061746816022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_01 = private unnamed_addr constant [29 x i8] c"cannot join an absolute child"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F0111636F6E7461696E734C65786963616C6C796101067075626C69630111636F6E7461696E734C65786963616C6C7918013A010473656C660E012C010963616E64696461746518013A010372656601045061746816022D3E0106526573756C741E013C0104426F6F6C0E012C0104546578741F013E_00 = private unnamed_addr constant [18 x i8] c"path styles differ"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [17 x i8] c"path contains NUL"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_01 = private unnamed_addr constant [20 x i8] c"invalid drive prefix"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_02 = private unnamed_addr constant [26 x i8] c"unsupported path namespace"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_03 = private unnamed_addr constant [26 x i8] c"unsupported path namespace"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_04 = private unnamed_addr constant [16 x i8] c"invalid UNC path"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_05 = private unnamed_addr constant [17 x i8] c"path escapes root"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_06 = private unnamed_addr constant [19 x i8] c"incomplete UNC path"
@sollang_str_x0B7379732E70726F6365737301070107636F6D6D616E643001067075626C69630107636F6D6D616E64010770726F6772616D18013A01045465787416022D3E0107436F6D6D616E64_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x0B7379732E70726F6365737302060107436F6D6D616E640F0104696D706C0107436F6D6D616E641F011172656D6F7665456E7669726F6E6D656E744501067075626C6963011172656D6F7665456E7669726F6E6D656E7418013A01036D7574010473656C660E012C01046E616D6518013A01045465787416022D3E0104556E6974_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F0112747279576169745465726D696E6174696F6E7501067075626C69630112747279576169745465726D696E6174696F6E18013A01036D7574010473656C6616022D3E0106526573756C741E013C01064F7074696F6E1E013C01115465726D696E6174696F6E5374617475731F013E0E012C0104546578741F013E010475736573010750726F63657373_00 = private unnamed_addr constant [4 x i8] c"wait"
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F0112747279576169745465726D696E6174696F6E7501067075626C69630112747279576169745465726D696E6174696F6E18013A01036D7574010473656C6616022D3E0106526573756C741E013C01064F7074696F6E1E013C01115465726D696E6174696F6E5374617475731F013E0E012C0104546578741F013E010475736573010750726F63657373_01 = private unnamed_addr constant [4 x i8] c"wait"
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F0107747279576169746301067075626C696301077472795761697418013A01036D7574010473656C6616022D3E0106526573756C741E013C01064F7074696F6E1E013C010A457869745374617475731F013E0E012C0104546578741F013E010475736573010750726F63657373_00 = private unnamed_addr constant [6 x i8] c"signal"
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F01046B696C6C4C01067075626C696301046B696C6C18013A01036D7574010473656C6616022D3E0106526573756C741E013C0104556E69740E012C0104546578741F013E010475736573010750726F63657373_00 = private unnamed_addr constant [4 x i8] c"kill"
@sollang_str_entry_00 = private unnamed_addr constant [6 x i8] c"$value"
; sollang.codegen.unit 1:
; sollang.codegen.key 7809847782465536322:865958917732825234
define internal i32 @sollang_fn_addOffset(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, i32 %it, i32 %arg1) {
entry:
  %arg = freeze i32 %it
  %v6 = freeze i32 %arg1
  %v4 = add i32 %arg, %arg1
  ret i32 %v4
}
; sollang.codegen.unit 2:
; sollang.codegen.key 10997868353068918418:1022904237969444521
define i32 @sollang_start() {
entry:
  %stdin = inttoptr i32 0 to ptr
  %stdout = inttoptr i32 1 to ptr
  %written = alloca i32, align 4
  %read = alloca i32, align 4
  %ok_state = alloca i1, align 1
  store i32 0, ptr %written, align 4
  store i32 0, ptr %read, align 4
  store i1 true, ptr %ok_state, align 1
  %each13_index_slot = alloca i64, align 8
  %calltext118383_arg0_root0_buffer = alloca [21 x i8], align 1
  %heap_v5 = call ptr @sollang_alloc(i64 16)
  %v5_data = getelementptr i8, ptr %heap_v5, i64 0
  %v5_allocation_ok = icmp ne ptr %v5_data, null
  br i1 %v5_allocation_ok, label %v5_allocation_ready, label %v5_allocation_failed
v5_allocation_failed:
  %v5_allocation_diagnostic = alloca [22 x i8], align 1
  store [22 x i8] c"\6D\61\69\6E\3A\61\6C\6C\6F\63\61\74\69\6F\6E\5F\66\61\69\6C\65\64", ptr %v5_allocation_diagnostic, align 1
  call void @sollang_browser_panic(ptr %v5_allocation_diagnostic, i32 22)
  call void @llvm.trap()
  unreachable
v5_allocation_ready:
  %v5_ptr0 = getelementptr i32, ptr %v5_data, i64 0
  store i32 1, ptr %v5_ptr0, align 4
  %v5_ptr1 = getelementptr i32, ptr %v5_data, i64 1
  store i32 2, ptr %v5_ptr1, align 4
  %v5_ptr2 = getelementptr i32, ptr %v5_data, i64 2
  store i32 3, ptr %v5_ptr2, align 4
  %v5_ptr3 = getelementptr i32, ptr %v5_data, i64 3
  store i32 4, ptr %v5_ptr3, align 4
  %v5_0 = insertvalue %sollang.array.i32 poison, ptr %v5_data, 0
  %v5_1 = insertvalue %sollang.array.i32 %v5_0, i64 4, 1
  %v5 = insertvalue %sollang.array.i32 %v5_1, i64 4, 2
  %v4_input = extractvalue %sollang.array.i32 %v5, 0
  %v4_length = extractvalue %sollang.array.i32 %v5, 1
  %v4_bytes = mul i64 %v4_length, 4
  %v4_data = call ptr @sollang_alloc(i64 %v4_bytes)
  %v12 = freeze i32 10
  %v4_index_slot = alloca i64, align 8
  store i64 0, ptr %v4_index_slot, align 8
  br label %parallel118372_header
parallel118372_header:
  %v4_index = load i64, ptr %v4_index_slot, align 8
  %v4_done = icmp eq i64 %v4_index, %v4_length
  br i1 %v4_done, label %parallel118372_exit, label %parallel118372_body
parallel118372_body:
  %v4_input_ptr = getelementptr i32, ptr %v4_input, i64 %v4_index
  %v4_item = load i32, ptr %v4_input_ptr, align 4
  %v4_mapped = call i32 @sollang_fn_addOffset(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, i32 %v4_item, i32 %v12)
  %v4_output_ptr = getelementptr i32, ptr %v4_data, i64 %v4_index
  store i32 %v4_mapped, ptr %v4_output_ptr, align 4
  %v4_next = add i64 %v4_index, 1
  store i64 %v4_next, ptr %v4_index_slot, align 8
  br label %parallel118372_header
parallel118372_exit:
  %v4_0 = insertvalue %sollang.array.i32 poison, ptr %v4_data, 0
  %v4_1 = insertvalue %sollang.array.i32 %v4_0, i64 %v4_length, 1
  %v4 = insertvalue %sollang.array.i32 %v4_1, i64 %v4_length, 2
  %v14 = freeze %sollang.array.i32 %v4
  %each13_data = extractvalue %sollang.array.i32 %v14, 0
  %each13_length = extractvalue %sollang.array.i32 %v14, 1
  store i64 0, ptr %each13_index_slot, align 8
  br label %each13_header
each13_header:
  %each13_index = load i64, ptr %each13_index_slot, align 8
  %each13_done = icmp eq i64 %each13_index, %each13_length
  br i1 %each13_done, label %each13_exit, label %each13_body
each13_body:
  %each13_item_ptr = getelementptr i32, ptr %each13_data, i64 %each13_index
  %each13_item = load i32, ptr %each13_item_ptr, align 4
  %each_role_m144_s8 = freeze i32 %each13_item
  %v16_ptr = insertvalue %sollang.text poison, ptr @sollang_str_entry_00, 0
  %v16 = insertvalue %sollang.text %v16_ptr, i64 6, 1
  %v15_expression_literal0 = getelementptr i8, ptr @sollang_str_entry_00, i64 0
  call void @sollang_runtime_print(ptr %stdout, ptr %written, ptr %ok_state, ptr %v15_expression_literal0, i64 0, i1 false)
  call void @sollang_runtime_print_i32(ptr %stdout, ptr %written, ptr %ok_state, i32 %each_role_m144_s8, i1 false)
  %v15_expression_suffix = getelementptr i8, ptr @sollang_str_entry_00, i64 6
  call void @sollang_runtime_print(ptr %stdout, ptr %written, ptr %ok_state, ptr %v15_expression_suffix, i64 0, i1 true)
  br label %each13_continue
each13_continue:
  %each13_next = add i64 %each13_index, 1
  store i64 %each13_next, ptr %each13_index_slot, align 8
  br label %each13_header
each13_exit:
  call void @sollang_drop_t697(%sollang.array.i32 %v4)
  call void @sollang_runtime_flush_stdout()
  %context_ok = load i1, ptr %ok_state, align 1
  %exit_code = select i1 %context_ok, i32 0, i32 1
  ret i32 %exit_code
}
attributes #0 = { nounwind }
; sollang.codegen.end

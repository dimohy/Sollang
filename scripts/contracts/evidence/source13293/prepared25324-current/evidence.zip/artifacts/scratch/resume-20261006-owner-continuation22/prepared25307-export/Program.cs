return SelfHostPolicyTests.Run(args[0], args[1]);

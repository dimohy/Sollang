; sollang cpu contract cpu1-d-r1-a3fe-f0
target triple = "x86_64-pc-windows-msvc"

%sollang.text = type { ptr, i64 }
%sollang.source_text = type { ptr, i64, ptr, i64 }
%sollang.int_slice = type { ptr, i64 }
%sollang.mutable_container = type { ptr, ptr, ptr }
%sollang.dynamic_int_array = type { ptr, i64, i64 }
%sollang.int_dictionary = type { ptr, i64, i64 }
%sollang.read_int_result = type { i64, i32 }
%sollang.file_int_result = type { i64, i32 }
%sollang.file_count_result = type { i64, i32 }
%sollang.file_handle_result = type { i64, i32 }
%sollang.socket_result = type { i64, i32, i32 }
%sollang.mapped_bytes = type { ptr, i64, ptr, i64, i1 }
%sollang.environment_result = type { ptr, i64, i1, i1 }
%sollang.process_result = type { i32, i32 }
%sollang.process_poll_result = type { i32, i32 }
%sollang.process_spawn_result = type { i64, i64, i32 }
%sollang.process_capture_result = type { i32, ptr, i64, i64, i1, ptr, i64, i64, i1, i32 }
%sollang.process_environment_result = type { ptr, i64, i64, i1 }
%sollang.task = type { ptr, ptr }
%sollang.stream = type { ptr, ptr, ptr }
%sollang.event_stream = type { ptr, ptr, ptr }
%sollang.dyn = type { ptr, ptr }
%sollang.task_control = type { ptr, ptr, ptr, ptr, i32, i32, ptr, ptr, i64, ptr, ptr, i32, i32, i64, i64, i32, ptr, i64, i64, i32, i32, ptr, ptr }%sollang.struct.27 = type { i64 }
%sollang.struct.29 = type { i64 }
%sollang.struct.30 = type { i64 }
%sollang.struct.31 = type { i64 }
%sollang.struct.32 = type { %sollang.dynamic_int_array, %sollang.text, i1, %sollang.dynamic_int_array, i1, %sollang.enum.1582, %sollang.enum.1583, %sollang.enum.1583 }
%sollang.struct.33 = type { %sollang.text, %sollang.text }
%sollang.struct.34 = type { %sollang.dynamic_int_array, %sollang.enum.35 }
%sollang.struct.43 = type { i32, i32 }
%sollang.struct.44 = type { i32, i32, i32, i32, %sollang.enum.45 }
%sollang.struct.1024 = type { %sollang.enum.1448 }
%sollang.struct.1025 = type {  }
%sollang.struct.1026 = type { i32, i1 }
%sollang.struct.1027 = type { i32, i32 }
%sollang.struct.1028 = type { %sollang.enum.1454, i64 }
%sollang.struct.1029 = type { i32, i32, i32, i32, i32 }
%sollang.struct.1030 = type { %sollang.struct.1029 }
%sollang.struct.1031 = type { i32, i32, i32 }
%sollang.struct.1032 = type { %sollang.struct.1029, %sollang.enum.1452, i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32, i32, i32, %sollang.dynamic_int_array, i32, i32, i32, i32, %sollang.dynamic_int_array, i1, %sollang.struct.1031, i32, %sollang.struct.1184, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32, i32, i32, %sollang.dynamic_int_array, i32, i32, %sollang.dynamic_int_array, i32, i1, %sollang.struct.1028 }
%sollang.struct.1033 = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%sollang.struct.1034 = type { %sollang.struct.1033, %sollang.enum.1453, i32, i32, i32, i32, i32, i32, %sollang.struct.1184, %sollang.dynamic_int_array }
%sollang.struct.1035 = type { i32 }
%sollang.struct.1036 = type { %sollang.text, %sollang.text, i32, i64, i32, i32 }
%sollang.struct.1037 = type { i64, %sollang.enum.2151, %sollang.enum.1455, %sollang.enum.1456, %sollang.enum.2151, i64, %sollang.enum.2152 }
%sollang.struct.1038 = type { i64, i64, i64, i1 }
%sollang.struct.1039 = type { i64, i64, i64 }
%sollang.struct.1040 = type { i64 }
%sollang.struct.1041 = type { %sollang.struct.1040, %sollang.enum.1459 }
%sollang.struct.1042 = type { %sollang.enum.1486, i64 }
%sollang.struct.1043 = type { i32, i32, i32, i32, i32 }
%sollang.struct.1044 = type { %sollang.struct.1043 }
%sollang.struct.1045 = type { i32, i32, i32, i32, i32, i32, i1 }
%sollang.struct.1046 = type { i32, i32, i32, i32, i32, i32, %sollang.enum.1485, %sollang.struct.1102, %sollang.struct.1060, %sollang.struct.1079, i32, i1, i32, i32, i32, %sollang.dynamic_int_array, i1, %sollang.struct.1042 }
%sollang.struct.1047 = type { i32, i32 }
%sollang.struct.1048 = type { i32, i32 }
%sollang.struct.1049 = type { i32, i32 }
%sollang.struct.1050 = type { i1, i64 }
%sollang.struct.1051 = type { %sollang.enum.1463, i64 }
%sollang.struct.1052 = type { i32, i32, i32 }
%sollang.struct.1053 = type { %sollang.struct.1071, i32, i32, i32, i32 }
%sollang.struct.1054 = type { %sollang.dynamic_int_array, %sollang.struct.1098 }
%sollang.struct.1055 = type { %sollang.struct.1071, %sollang.struct.1106, i32, i32, i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32, i32, %sollang.enum.1460, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.1460 }
%sollang.struct.1056 = type { %sollang.dynamic_int_array }
%sollang.struct.1057 = type { i32, %sollang.struct.1098 }
%sollang.struct.1058 = type { %sollang.enum.1476, i64 }
%sollang.struct.1059 = type { i32, i32, i32, i32, i32, i32 }
%sollang.struct.1060 = type { %sollang.struct.1089, %sollang.struct.1082, %sollang.struct.1110, i32, i32, i32 }
%sollang.struct.1061 = type { %sollang.enum.1464, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.1487, i32, i32 }
%sollang.struct.1062 = type { i32, i32, i32, i32, i32, %sollang.enum.1487, i32, i32 }
%sollang.struct.1063 = type { %sollang.struct.1089, i32, i32, %sollang.enum.1467, i32, i32, i32, i32, %sollang.enum.1466, %sollang.enum.1466 }
%sollang.struct.1064 = type { %sollang.struct.1060, %sollang.struct.1063, %sollang.enum.1469, i32, %sollang.dynamic_int_array, i32, i32, %sollang.dynamic_int_array }
%sollang.struct.1065 = type { %sollang.dynamic_int_array, i32, i32, i32, %sollang.dynamic_int_array, i32 }
%sollang.struct.1066 = type { %sollang.struct.1065, %sollang.struct.1084, %sollang.enum.1471, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32, i32 }
%sollang.struct.1067 = type { %sollang.dynamic_int_array, i32, i32, i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32, i32 }
%sollang.struct.1068 = type { %sollang.struct.1067, %sollang.struct.1112, %sollang.enum.1473, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array }
%sollang.struct.1069 = type { i32, i32, %sollang.enum.1466, %sollang.enum.1466 }
%sollang.struct.1070 = type { i32, i32, %sollang.struct.1098 }
%sollang.struct.1071 = type { %sollang.dynamic_int_array, i32, i32, i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.struct.1098 }
%sollang.struct.1072 = type { i32, %sollang.struct.1098 }
%sollang.struct.1073 = type { %sollang.struct.1069, %sollang.struct.1098 }
%sollang.struct.1074 = type { %sollang.enum.1486, i64 }
%sollang.struct.1075 = type { i32, i32, i32 }
%sollang.struct.1076 = type { %sollang.struct.1064, %sollang.struct.1092 }
%sollang.struct.1077 = type { %sollang.struct.1066, %sollang.struct.1092 }
%sollang.struct.1078 = type { %sollang.struct.1068, %sollang.struct.1092 }
%sollang.struct.1079 = type { %sollang.struct.1060, %sollang.struct.1075, i32, %sollang.dynamic_int_array, %sollang.enum.1477 }
%sollang.struct.1080 = type { %sollang.enum.1484, i64 }
%sollang.struct.1081 = type { i32, i32, i32 }
%sollang.struct.1082 = type { %sollang.struct.1089, i32, i32 }
%sollang.struct.1083 = type { %sollang.dynamic_int_array, i32, %sollang.struct.1098 }
%sollang.struct.1084 = type { %sollang.struct.1089, i32, i32, i32, %sollang.enum.1480, i32, i32, i32, %sollang.dynamic_int_array, %sollang.enum.1481 }
%sollang.struct.1085 = type { %sollang.dynamic_int_array, i32 }
%sollang.struct.1086 = type { i32, %sollang.struct.1098 }
%sollang.struct.1087 = type { %sollang.enum.1493, i64 }
%sollang.struct.1088 = type { i32, i32 }
%sollang.struct.1089 = type { %sollang.struct.1096, i32 }
%sollang.struct.1090 = type { %sollang.struct.1097, %sollang.struct.1098 }
%sollang.struct.1091 = type { %sollang.enum.1488, i32 }
%sollang.struct.1092 = type { %sollang.struct.1096, i32, i32, i32, %sollang.enum.1490, i32, i32, i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.struct.1091, %sollang.dynamic_int_array, i32, i32, i32, %sollang.enum.1491, i32, i32, i32, i32, i32, i32, %sollang.enum.1491 }
%sollang.struct.1093 = type { i32, %sollang.struct.1098 }
%sollang.struct.1094 = type { %sollang.enum.1496, i64 }
%sollang.struct.1095 = type { i32, i32 }
%sollang.struct.1096 = type { i32, i32 }
%sollang.struct.1097 = type { %sollang.dynamic_int_array, i32 }
%sollang.struct.1098 = type { i32, i32 }
%sollang.struct.1099 = type { i32, %sollang.struct.1098 }
%sollang.struct.1100 = type { i32, i32 }
%sollang.struct.1101 = type { i32 }
%sollang.struct.1102 = type { i64, i32, i32 }
%sollang.struct.1103 = type { i32, i32 }
%sollang.struct.1104 = type { %sollang.enum.1498, i64 }
%sollang.struct.1105 = type { i32 }
%sollang.struct.1106 = type { i32 }
%sollang.struct.1107 = type { i32, %sollang.enum.1497, i32 }
%sollang.struct.1108 = type { %sollang.enum.1500, i64 }
%sollang.struct.1109 = type { i32, i32, i32, i32 }
%sollang.struct.1110 = type { %sollang.struct.1089, i32, i32, i32 }
%sollang.struct.1111 = type { %sollang.dynamic_int_array, %sollang.struct.1098 }
%sollang.struct.1112 = type { %sollang.struct.1089, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.dynamic_int_array }
%sollang.struct.1113 = type { %sollang.dynamic_int_array }
%sollang.struct.1114 = type { %sollang.enum.1502, i64 }
%sollang.struct.1115 = type { i32, i32 }
%sollang.struct.1116 = type { %sollang.struct.1115 }
%sollang.struct.1117 = type { i32, i32 }
%sollang.struct.1118 = type { i32, i32, i32, i32, i1, i1, %sollang.struct.1124 }
%sollang.struct.1119 = type { %sollang.struct.1116, i32, i32, i32, i32, i32, i32, %sollang.enum.1501, i32, i32, i32, i32, i32, i32, i32, i1, i32, i32, i32, i32, i32, i32, i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.struct.1129, %sollang.struct.1129, %sollang.struct.1129, i32, i32, i32, i32, i32, i32, i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32, i1, %sollang.struct.1114, i1, i1 }
%sollang.struct.1120 = type { %sollang.struct.1119 }
%sollang.struct.1121 = type { i32, i32, i32 }
%sollang.struct.1122 = type { i32, i32, i32, i32 }
%sollang.struct.1123 = type { i32, i32 }
%sollang.struct.1124 = type { i32, i32 }
%sollang.struct.1125 = type { i32, i32 }
%sollang.struct.1126 = type { i32, i32, i32 }
%sollang.struct.1127 = type { i32, i32, i32 }
%sollang.struct.1128 = type { i32, i32 }
%sollang.struct.1129 = type { %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32 }
%sollang.struct.1130 = type { %sollang.struct.1129, %sollang.struct.1129 }
%sollang.struct.1131 = type { %sollang.struct.1123, i32, %sollang.dynamic_int_array }
%sollang.struct.1132 = type { i32, %sollang.dynamic_int_array }
%sollang.struct.1133 = type { i32 }
%sollang.struct.1134 = type { i32 }
%sollang.struct.1135 = type { i1, i32 }
%sollang.struct.1136 = type { i1, i32 }
%sollang.struct.1137 = type { i1, i32 }
%sollang.struct.1138 = type { %sollang.enum.1504, i64 }
%sollang.struct.1139 = type { %sollang.dynamic_int_array, %sollang.struct.1149, i1, %sollang.struct.1145, %sollang.struct.1145, %sollang.struct.1145, i1, i1, i1, i32, i32, i32 }
%sollang.struct.1140 = type { i32, i32, i32, i32, i32 }
%sollang.struct.1141 = type { i1 }
%sollang.struct.1142 = type { %sollang.struct.1140, %sollang.struct.1141 }
%sollang.struct.1143 = type { i32, i32, i32, i32, i1, i1, %sollang.struct.1186 }
%sollang.struct.1144 = type { i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.1503, i64, i32, i32, i32, i32, i32, i1, i64, i1, %sollang.struct.1186, i32, i32, i32, i32, i1, %sollang.dynamic_int_array, %sollang.struct.1149, i1, %sollang.struct.1145, %sollang.struct.1145, %sollang.struct.1145, i1, i1, i1, i32, i32, i32, %sollang.dynamic_int_array, i1, %sollang.struct.1138 }
%sollang.struct.1145 = type { %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i32 }
%sollang.struct.1146 = type { %sollang.struct.1145, i32 }
%sollang.struct.1147 = type { i32 }
%sollang.struct.1148 = type { i32, i32, i32 }
%sollang.struct.1149 = type { %sollang.dynamic_int_array, i32 }
%sollang.struct.1150 = type { %sollang.struct.1149, i32 }
%sollang.struct.1151 = type { i32, i32 }
%sollang.struct.1152 = type { %sollang.struct.1145, %sollang.struct.1145, %sollang.struct.1145, i1, i1, i1, i32, i32, i32, i32 }
%sollang.struct.1153 = type { i32, i32, i32 }
%sollang.struct.1154 = type { %sollang.dynamic_int_array, %sollang.struct.1145, %sollang.struct.1145, %sollang.struct.1145, i1, i1, i1, i32, i32, i32 }
%sollang.struct.1155 = type { %sollang.dynamic_int_array }
%sollang.struct.1156 = type { %sollang.int_slice }
%sollang.struct.1157 = type { %sollang.dynamic_int_array, %sollang.int_slice }
%sollang.struct.1158 = type { %sollang.struct.1155, %sollang.int_slice }
%sollang.struct.1159 = type { %sollang.int_slice }
%sollang.struct.1160 = type { %sollang.enum.1510 }
%sollang.struct.1161 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.1162 = type { %sollang.struct.1164, %sollang.struct.1164 }
%sollang.struct.1163 = type { i8 }
%sollang.struct.1164 = type { %sollang.int_slice, %sollang.int_slice, i32, i64 }
%sollang.struct.1165 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.1166 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.1167 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.1168 = type { %sollang.enum.1512, i64 }
%sollang.struct.1169 = type { i32, i32 }
%sollang.struct.1170 = type { i32, i32 }
%sollang.struct.1171 = type { %sollang.enum.1513, %sollang.enum.1514 }
%sollang.struct.1172 = type { %sollang.struct.1171, i32, i32, i64, i8, i8, i32 }
%sollang.struct.1173 = type { %sollang.struct.1171, i32, i32, i64, i32, i32, i32, i32, i64, i64, i64, i64, i32, i1 }
%sollang.struct.1174 = type { i32, i32, i64, i32, i32, i32, i32, i64, i64, i64, i64, i32, i1 }
%sollang.struct.1175 = type { %sollang.enum.1516, i64 }
%sollang.struct.1176 = type { %sollang.enum.1515, i64 }
%sollang.struct.1177 = type { %sollang.enum.1515, i32, i32 }
%sollang.struct.1178 = type { %sollang.enum.1517, i64 }
%sollang.struct.1179 = type { i32, i32 }
%sollang.struct.1180 = type { i32, i32 }
%sollang.struct.1181 = type { i1 }
%sollang.struct.1182 = type { %sollang.struct.1181, i32, i32, i64 }
%sollang.struct.1183 = type { i32, i32, i64, i32, i64 }
%sollang.struct.1184 = type { %sollang.enum.1518, i32 }
%sollang.struct.1185 = type { i64 }
%sollang.struct.1186 = type { i64, i64, i64, i64, i64, i64, i64, %sollang.int_slice, i32 }
%sollang.struct.1187 = type { %sollang.enum.1519, i64 }
%sollang.struct.1188 = type { i32, %sollang.enum.1521 }
%sollang.struct.1189 = type { i32, i32 }
%sollang.struct.1190 = type { %sollang.dynamic_int_array, i32, %sollang.dynamic_int_array, i32, i32 }
%sollang.struct.1191 = type { %sollang.dynamic_int_array, i32, i32 }
%sollang.struct.1192 = type { %sollang.dynamic_int_array, i32 }
%sollang.struct.1193 = type { i1 }
%sollang.struct.1194 = type { %sollang.struct.1191, %sollang.dynamic_int_array, i32, i1 }
%sollang.struct.1195 = type { %sollang.struct.1191, %sollang.dynamic_int_array, %sollang.enum.1522 }
%sollang.struct.1196 = type { %sollang.struct.1192, %sollang.dynamic_int_array, i32 }
%sollang.struct.1197 = type { %sollang.struct.1192, %sollang.dynamic_int_array, %sollang.enum.1522 }
%sollang.struct.1198 = type { %sollang.dynamic_int_array, i32, i32, i32, i1 }
%sollang.struct.1199 = type { %sollang.struct.1198, %sollang.dynamic_int_array, i32, i1 }
%sollang.struct.1200 = type { %sollang.struct.1198, %sollang.dynamic_int_array, %sollang.enum.1522 }
%sollang.struct.1201 = type { %sollang.struct.1198, %sollang.dynamic_int_array, i32, i1 }
%sollang.struct.1202 = type { %sollang.struct.1198, %sollang.dynamic_int_array, %sollang.enum.1522 }
%sollang.struct.1203 = type { %sollang.struct.29, i64 }
%sollang.struct.1204 = type { %sollang.struct.30, i64 }
%sollang.struct.1205 = type { %sollang.struct.1203, %sollang.dynamic_int_array, i32, i1 }
%sollang.struct.1206 = type { %sollang.struct.1203, %sollang.dynamic_int_array, %sollang.enum.1580 }
%sollang.struct.1207 = type { %sollang.struct.1204, %sollang.dynamic_int_array, i32 }
%sollang.struct.1208 = type { %sollang.struct.1204, %sollang.dynamic_int_array, %sollang.enum.1580 }
%sollang.struct.1209 = type { %sollang.struct.1362, i64 }
%sollang.struct.1210 = type { %sollang.struct.1355, %sollang.struct.1373 }
%sollang.struct.1211 = type { %sollang.struct.1209, %sollang.dynamic_int_array, i64, i1 }
%sollang.struct.1212 = type { %sollang.struct.1209, %sollang.dynamic_int_array, %sollang.struct.1373 }
%sollang.struct.1213 = type { %sollang.struct.1209, %sollang.dynamic_int_array, i64 }
%sollang.struct.1214 = type { %sollang.struct.1209, %sollang.dynamic_int_array, %sollang.struct.1373 }
%sollang.struct.1215 = type { %sollang.text, %sollang.text }
%sollang.struct.1216 = type { %sollang.text }
%sollang.struct.1217 = type { %sollang.enum.1523, %sollang.text }
%sollang.struct.1218 = type { %sollang.enum.1523 }
%sollang.struct.1219 = type { i8, i8, i8, i8 }
%sollang.struct.1220 = type { %sollang.struct.1219, i16 }
%sollang.struct.1221 = type { i16, i16, i16, i16, i16, i16, i16, i16 }
%sollang.struct.1222 = type { %sollang.struct.1221, i16, i32, i32 }
%sollang.struct.1223 = type { %sollang.enum.1542, i64 }
%sollang.struct.1224 = type { %sollang.enum.1527, i32 }
%sollang.struct.1225 = type { %sollang.enum.1526, i64, i64 }
%sollang.struct.1226 = type { %sollang.enum.1534, i64 }
%sollang.struct.1227 = type { i32, i32, i32, i32, i32 }
%sollang.struct.1228 = type { i64, i64 }
%sollang.struct.1229 = type { %sollang.struct.1228, %sollang.struct.1228 }
%sollang.struct.1230 = type { %sollang.struct.1227 }
%sollang.struct.1231 = type { %sollang.source_text, %sollang.struct.1228, %sollang.struct.1228, %sollang.enum.1528, %sollang.dynamic_int_array, i64 }
%sollang.struct.1232 = type { %sollang.source_text, %sollang.enum.1528, i32, %sollang.struct.1228, %sollang.dynamic_int_array, i64 }
%sollang.struct.1233 = type { %sollang.dynamic_int_array, i64 }
%sollang.struct.1234 = type { i32, i32, i32, i32, i32 }
%sollang.struct.1235 = type { %sollang.struct.1234 }
%sollang.struct.1236 = type { %sollang.struct.1235, %sollang.text }
%sollang.struct.1237 = type { %sollang.enum.1529, %sollang.struct.1234 }
%sollang.struct.1238 = type { i64, i64, i1 }
%sollang.struct.1239 = type { %sollang.struct.1234, %sollang.enum.1530, %sollang.enum.1531, i64, i64, i64, i64, %sollang.dynamic_int_array, i1, i64, i32 }
%sollang.struct.1240 = type { i1, i64, i1, i1 }
%sollang.struct.1241 = type { %sollang.enum.1525, %sollang.struct.1230, %sollang.struct.1235, i32, i32 }
%sollang.struct.1242 = type { %sollang.struct.1355, %sollang.struct.1230, %sollang.struct.1235, i32, i32 }
%sollang.struct.1243 = type { %sollang.struct.1355, %sollang.struct.1230, %sollang.struct.1235, i32, i32, %sollang.enum.1537, %sollang.enum.1536 }
%sollang.struct.1244 = type { %sollang.struct.1355, %sollang.struct.1230, %sollang.struct.1235, i32, i32, %sollang.enum.1537, %sollang.enum.1536, %sollang.dynamic_int_array, %sollang.struct.1232, i64 }
%sollang.struct.1245 = type { %sollang.struct.1355, %sollang.struct.1230, %sollang.struct.1235, i32, i32, %sollang.dynamic_int_array, i64, %sollang.dynamic_int_array, i64, %sollang.struct.1239, i1, i1, i1 }
%sollang.struct.1246 = type { i32, i32, i32, i32 }
%sollang.struct.1247 = type { %sollang.struct.1246 }
%sollang.struct.1248 = type { %sollang.struct.1246, %sollang.dynamic_int_array, %sollang.text, i32, i32, i1, i1, i1, i64, %sollang.enum.1536, %sollang.enum.1537 }
%sollang.struct.1249 = type { %sollang.dynamic_int_array, i64, %sollang.enum.1536, %sollang.enum.1537 }
%sollang.struct.1250 = type { i32, i32, i32, i32 }
%sollang.struct.1251 = type { %sollang.struct.1250 }
%sollang.struct.1252 = type { %sollang.struct.1250, %sollang.dynamic_int_array, i32, i32, i1, i1, i1, i64, %sollang.enum.1539 }
%sollang.struct.1253 = type { %sollang.dynamic_int_array, i64, %sollang.enum.1539, %sollang.enum.1538 }
%sollang.struct.1254 = type { %sollang.struct.1352, %sollang.struct.1227 }
%sollang.struct.1255 = type { %sollang.struct.1354, %sollang.struct.1230, i32 }
%sollang.struct.1256 = type { %sollang.struct.1355, %sollang.struct.1230, i32, %sollang.dynamic_int_array, i64 }
%sollang.struct.1257 = type { %sollang.struct.1355, %sollang.struct.1230, i32, %sollang.dynamic_int_array, %sollang.struct.1231, i64, %sollang.dynamic_int_array, i64, i1 }
%sollang.struct.1258 = type { %sollang.struct.1355, %sollang.struct.1230, i32, %sollang.dynamic_int_array, %sollang.struct.1231, i64, %sollang.dynamic_int_array, i64, %sollang.struct.1239 }
%sollang.struct.1259 = type { %sollang.enum.1543, i64 }
%sollang.struct.1260 = type { %sollang.int_slice }
%sollang.struct.1261 = type { %sollang.struct.1356, %sollang.enum.1525, i1, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i64 }
%sollang.struct.1262 = type { i64, i64, i64, i64 }
%sollang.struct.1263 = type { i64, i64, i32, i32, i32, i64, %sollang.struct.1262 }
%sollang.struct.1264 = type { %sollang.struct.1260, %sollang.enum.1525, %sollang.struct.1263, i1 }
%sollang.struct.1265 = type { %sollang.dynamic_int_array, %sollang.enum.1525, %sollang.enum.1525, i1, i32, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.struct.1275, %sollang.struct.1275, i64, i64, i1, %sollang.int_slice, %sollang.dynamic_int_array, %sollang.int_slice, %sollang.dynamic_int_array, i1, i1, %sollang.dynamic_int_array, %sollang.struct.1328, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i64, i32, i64, i1, i1, %sollang.struct.1321, %sollang.struct.1303, %sollang.struct.1304, %sollang.struct.1332, %sollang.struct.1334, i64, i64, i64, i64, i64, i64, i8, i64, i64 }
%sollang.struct.1266 = type { %sollang.struct.1331, i1, i1, i64 }
%sollang.struct.1267 = type { %sollang.struct.1330, i1, i1, i64, i1, i64 }
%sollang.struct.1268 = type { i64, %sollang.struct.1266, %sollang.struct.1267 }
%sollang.struct.1269 = type { i64, %sollang.struct.1266 }
%sollang.struct.1270 = type { i64, %sollang.struct.1267 }
%sollang.struct.1271 = type { i64, i64 }
%sollang.struct.1272 = type { i64, i8 }
%sollang.struct.1273 = type { i64, i64, i64, i64, i64, i64, i64, i8, i64, i64 }
%sollang.struct.1274 = type { %sollang.dynamic_int_array, i64 }
%sollang.struct.1275 = type { i1, i32, %sollang.int_slice, %sollang.struct.1345 }
%sollang.struct.1276 = type { i64, i1, %sollang.enum.1544 }
%sollang.struct.1277 = type { i64, i1, %sollang.dynamic_int_array }
%sollang.struct.1278 = type { i1, i1, i1, %sollang.struct.1332, %sollang.struct.1333 }
%sollang.struct.1279 = type { i64, i8 }
%sollang.struct.1280 = type { %sollang.dynamic_int_array, i64 }
%sollang.struct.1281 = type { %sollang.dynamic_int_array, i64 }
%sollang.struct.1282 = type { %sollang.dynamic_int_array, i64 }
%sollang.struct.1283 = type { i64, %sollang.dynamic_int_array }
%sollang.struct.1284 = type { %sollang.enum.1543, i64 }
%sollang.struct.1285 = type { i64, %sollang.dynamic_int_array }
%sollang.struct.1286 = type { i64, i64, i1, %sollang.dynamic_int_array }
%sollang.struct.1287 = type { i64, i64, i64 }
%sollang.struct.1288 = type { i64, i64 }
%sollang.struct.1289 = type { %sollang.dynamic_int_array }
%sollang.struct.1290 = type { i64, i64 }
%sollang.struct.1291 = type { i1, i64 }
%sollang.struct.1292 = type { i64, i64 }
%sollang.struct.1293 = type { i1, i64 }
%sollang.struct.1294 = type { i1, i64, i64, %sollang.dynamic_int_array }
%sollang.struct.1295 = type { i64, i64, %sollang.dynamic_int_array, %sollang.int_slice }
%sollang.struct.1296 = type { i64, i64 }
%sollang.struct.1297 = type { i64, i64, i64, %sollang.dynamic_int_array }
%sollang.struct.1298 = type { %sollang.enum.1544, i64 }
%sollang.struct.1299 = type { i32, i64, i64, %sollang.dynamic_int_array, i64 }
%sollang.struct.1300 = type { i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i64, %sollang.dynamic_int_array }
%sollang.struct.1301 = type { %sollang.dynamic_int_array, i64, %sollang.dynamic_int_array }
%sollang.struct.1302 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.1303 = type { i1, i64, i64, i64, i64 }
%sollang.struct.1304 = type { i64, i64, i64, i64, i1 }
%sollang.struct.1305 = type { %sollang.int_slice }
%sollang.struct.1306 = type { %sollang.struct.1260, %sollang.int_slice, %sollang.struct.1305 }
%sollang.struct.1307 = type { %sollang.struct.1305, %sollang.int_slice, %sollang.struct.1220, i64, %sollang.dynamic_int_array, %sollang.int_slice }
%sollang.struct.1308 = type { %sollang.struct.1265, %sollang.struct.1268, %sollang.struct.1305 }
%sollang.struct.1309 = type { %sollang.dynamic_int_array }
%sollang.struct.1310 = type { %sollang.struct.1305, %sollang.struct.1268 }
%sollang.struct.1311 = type { i32, i64, %sollang.dynamic_int_array, i64 }
%sollang.struct.1312 = type { i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i64, i64 }
%sollang.struct.1313 = type { i32, i64, %sollang.dynamic_int_array, i64 }
%sollang.struct.1314 = type { i32, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i64, i64 }
%sollang.struct.1315 = type { i1, i64, %sollang.dynamic_int_array }
%sollang.struct.1316 = type { i8, i64, %sollang.dynamic_int_array }
%sollang.struct.1317 = type { %sollang.struct.1326, %sollang.struct.1325 }
%sollang.struct.1318 = type { i32, i64 }
%sollang.struct.1319 = type { i64, i64, i64, i1, i1 }
%sollang.struct.1320 = type { %sollang.struct.1303, %sollang.struct.1304, i64, i64, i64, i64 }
%sollang.struct.1321 = type { %sollang.dynamic_int_array }
%sollang.struct.1322 = type { %sollang.int_slice }
%sollang.struct.1323 = type { %sollang.int_slice }
%sollang.struct.1324 = type { %sollang.int_slice, %sollang.int_slice }
%sollang.struct.1325 = type { %sollang.struct.1155 }
%sollang.struct.1326 = type { %sollang.struct.1158, %sollang.int_slice }
%sollang.struct.1327 = type { %sollang.struct.1330, i64 }
%sollang.struct.1328 = type { %sollang.dynamic_int_array, i64 }
%sollang.struct.1329 = type { i64, i64, %sollang.enum.1545, %sollang.enum.1546 }
%sollang.struct.1330 = type { i64, i64, i64, i1, i64 }
%sollang.struct.1331 = type { i64, i64, i1, i64 }
%sollang.struct.1332 = type { i64, i64, i64, i64, i64 }
%sollang.struct.1333 = type { i64, i64 }
%sollang.struct.1334 = type { i1, i64, i64, i1, i1, i64, i64, i64, i64, i64, i64, i32, %sollang.dynamic_int_array, i32, i32, i32, i32, %sollang.dynamic_int_array, i32, i32, i32 }
%sollang.struct.1335 = type { %sollang.dynamic_int_array }
%sollang.struct.1336 = type { i16, %sollang.dynamic_int_array }
%sollang.struct.1337 = type { %sollang.enum.1547, %sollang.struct.1344, %sollang.int_slice }
%sollang.struct.1338 = type { i8, %sollang.dynamic_int_array, i64 }
%sollang.struct.1339 = type { i16, %sollang.dynamic_int_array, i64 }
%sollang.struct.1340 = type { %sollang.int_slice, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.int_slice, %sollang.dynamic_int_array }
%sollang.struct.1341 = type { %sollang.int_slice, %sollang.dynamic_int_array, %sollang.int_slice }
%sollang.struct.1342 = type { %sollang.dynamic_int_array, %sollang.dynamic_int_array }
%sollang.struct.1343 = type { %sollang.enum.1548, %sollang.struct.1344 }
%sollang.struct.1344 = type { %sollang.dynamic_int_array }
%sollang.struct.1345 = type { %sollang.struct.1317 }
%sollang.struct.1346 = type { i64, %sollang.dynamic_int_array, i64 }
%sollang.struct.1347 = type { i64 }
%sollang.struct.1348 = type { i64, i64 }
%sollang.struct.1349 = type { i32, %sollang.dynamic_int_array }
%sollang.struct.1350 = type { %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array }
%sollang.struct.1351 = type { i8, i64, i64, i64 }
%sollang.struct.1352 = type { %sollang.enum.1525, i32, i1 }
%sollang.struct.1353 = type { %sollang.enum.1525, i1 }
%sollang.struct.1354 = type { i64 }
%sollang.struct.1355 = type { i64 }
%sollang.struct.1356 = type { i64 }
%sollang.struct.1357 = type { ptr, i64, i64 }
%sollang.struct.1358 = type { %sollang.dynamic_int_array }
%sollang.struct.1359 = type { i64, %sollang.enum.1552, %sollang.enum.1551 }
%sollang.struct.1360 = type { i64, i1, i1, i1 }
%sollang.struct.1361 = type { i64, i64, i64 }
%sollang.struct.1362 = type { i64 }
%sollang.struct.1363 = type { i64, %sollang.enum.1553, %sollang.dynamic_int_array, i64, i64, %sollang.enum.1554, %sollang.enum.2176, %sollang.enum.2177, %sollang.enum.2151 }
%sollang.struct.1364 = type { %sollang.struct.1362, %sollang.struct.1355, %sollang.struct.1373 }
%sollang.struct.1365 = type { %sollang.struct.1362, %sollang.struct.1355 }
%sollang.struct.1366 = type { %sollang.struct.1362, %sollang.struct.1373 }
%sollang.struct.1367 = type { %sollang.struct.1362, %sollang.struct.1363 }
%sollang.struct.1368 = type { %sollang.struct.1362, %sollang.struct.1363, %sollang.struct.1373 }
%sollang.struct.1369 = type { %sollang.struct.1363, %sollang.struct.1373 }
%sollang.struct.1370 = type { i64, %sollang.dynamic_int_array }
%sollang.struct.1371 = type { %sollang.enum.1525, %sollang.dynamic_int_array, i1 }
%sollang.struct.1372 = type { %sollang.enum.1525, i64, i1 }
%sollang.struct.1373 = type { %sollang.enum.1557, i32 }
%sollang.struct.1374 = type { %sollang.enum.1559, i64 }
%sollang.struct.1375 = type { i32, i32, i32 }
%sollang.struct.1376 = type { %sollang.enum.1558, i64, i64 }
%sollang.struct.1377 = type { %sollang.enum.1558, i64, i1 }
%sollang.struct.1378 = type { %sollang.source_text, i64, i64, i32, i1, %sollang.struct.1375, %sollang.struct.1377 }
%sollang.struct.1379 = type { %sollang.enum.1561, i64, i32 }
%sollang.struct.1380 = type { i32, i32, i32, i32 }
%sollang.struct.1381 = type { i32, i32, i32, i32 }
%sollang.struct.1382 = type { %sollang.enum.1560, i32 }
%sollang.struct.1383 = type { i32, i32, i32, i1 }
%sollang.struct.1384 = type { %sollang.source_text, i64, i64, i32, i32, i1, %sollang.struct.1382, %sollang.struct.1380 }
%sollang.struct.1385 = type { %sollang.struct.1381, i32, i32, i32, i32 }
%sollang.struct.1386 = type { i64, i64, i64, i32, i1, i1 }
%sollang.struct.1387 = type { i32, i32, i32 }
%sollang.struct.1388 = type { %sollang.enum.1562, i64, i64 }
%sollang.struct.1389 = type { %sollang.source_text, i64, i32, i32 }
%sollang.struct.1390 = type { %sollang.enum.1565, i64 }
%sollang.struct.1391 = type { i32, i32, i32, i32 }
%sollang.struct.1392 = type { %sollang.enum.1563, i64, i64, i64, i64, i32, i32 }
%sollang.struct.1393 = type { %sollang.dynamic_int_array, i32 }
%sollang.struct.1394 = type { %sollang.enum.1564, i64, i64, i1, %sollang.dynamic_int_array, %sollang.dynamic_int_array, %sollang.dynamic_int_array }
%sollang.struct.1395 = type { %sollang.dynamic_int_array, i32 }
%sollang.struct.1396 = type { %sollang.source_text, i64, i64, i8, i32, %sollang.struct.1391, %sollang.dynamic_int_array }
%sollang.struct.1397 = type { %sollang.dynamic_int_array, i32, i32, i32, i8, %sollang.dynamic_int_array }
%sollang.struct.1398 = type { i64, i64, i32 }
%sollang.struct.1399 = type { i32, i32, i32, i32 }
%sollang.struct.1400 = type { %sollang.enum.1566, i64, i64, i64 }
%sollang.struct.1401 = type { i64, i64 }
%sollang.struct.1402 = type { %sollang.source_text, i64, i64, i32, i32, i1, i1, i32, i32 }
%sollang.struct.1403 = type { %sollang.enum.1567, i64, i64, i64, i1, %sollang.enum.1568, i64 }
%sollang.struct.1404 = type { i8, i64 }
%sollang.struct.1405 = type { i32 }
%sollang.struct.1406 = type { i64, i64 }
%sollang.struct.1407 = type { i64 }
%sollang.struct.1408 = type { i64, i64, i64 }
%sollang.struct.1409 = type { i8 }
%sollang.struct.1410 = type { i8 }
%sollang.struct.1411 = type { i64, i64 }
%sollang.struct.1412 = type { i64 }
%sollang.struct.1413 = type { %sollang.struct.1406 }
%sollang.struct.1414 = type { %sollang.struct.1407 }
%sollang.struct.1415 = type { i64 }
%sollang.struct.1416 = type { %sollang.struct.27, %sollang.enum.1569, %sollang.struct.27 }
%sollang.struct.1417 = type { %sollang.dynamic_int_array, %sollang.struct.27, i64, %sollang.enum.1570 }
%sollang.struct.1418 = type { %sollang.struct.1417, %sollang.struct.1406, %sollang.struct.1406, i64 }
%sollang.struct.1419 = type { %sollang.enum.1571 }
%sollang.struct.1420 = type { %sollang.enum.1575, i64 }
%sollang.struct.1421 = type { i64, i64, i1 }
%sollang.struct.1422 = type { %sollang.struct.1421, %sollang.enum.1572, %sollang.enum.1573, %sollang.struct.1421 }
%sollang.struct.1423 = type { %sollang.source_text, %sollang.struct.1421, %sollang.enum.1574, %sollang.struct.1421, %sollang.struct.1421, %sollang.struct.1421 }
%sollang.struct.1424 = type { i1, i1, i1, i1, i1 }
%sollang.struct.1425 = type { %sollang.enum.1576, i64 }
%sollang.struct.1426 = type { i32, i32 }
%sollang.struct.1427 = type { %sollang.enum.1577 }
%sollang.struct.1428 = type { %sollang.enum.1579, i64 }
%sollang.struct.1429 = type { %sollang.int_slice }
%sollang.struct.1430 = type { i8 }
%sollang.struct.1431 = type { %sollang.struct.1410, %sollang.struct.1163 }
%sollang.struct.1432 = type { %sollang.struct.29, %sollang.dynamic_int_array, i64, i1 }
%sollang.struct.1433 = type { %sollang.struct.29, %sollang.dynamic_int_array, %sollang.enum.1580 }
%sollang.struct.1434 = type { %sollang.struct.30, %sollang.dynamic_int_array, i64 }
%sollang.struct.1435 = type { %sollang.struct.30, %sollang.dynamic_int_array, %sollang.enum.1580 }
%sollang.struct.1436 = type { %sollang.enum.1581, i32 }
%sollang.struct.1437 = type { i32, %sollang.enum.46 }
%sollang.struct.1438 = type { %sollang.dynamic_int_array, i8, i64, i64 }
%sollang.struct.1439 = type { %sollang.struct.34, %sollang.enum.38, i64, i64 }
%sollang.struct.1440 = type { %sollang.text, %sollang.text, i1 }
%sollang.struct.1441 = type { i64, i64 }
%sollang.struct.1442 = type { %sollang.struct.1443, %sollang.dynamic_int_array, %sollang.dynamic_int_array, i1, i1 }
%sollang.struct.1443 = type { i32 }
%sollang.struct.1444 = type { i32 }
%sollang.struct.1445 = type { i64 }
%sollang.struct.1446 = type { i64, %sollang.struct.1445, i32, i32 }
%sollang.struct.1447 = type { i32, i32 }
%sollang.enum.35 = type { i32, [0 x i64] }
%sollang.enum.38 = type { i32, [0 x i64] }
%sollang.enum.45 = type { i32, [0 x i64] }
%sollang.enum.46 = type { i32, [0 x i64] }
%sollang.enum.1448 = type { i32, [0 x i64] }
%sollang.enum.1449 = type { i32, [0 x i64] }
%sollang.enum.1450 = type { i32, [0 x i64] }
%sollang.enum.1451 = type { i32, [0 x i64] }
%sollang.enum.1452 = type { i32, [0 x i64] }
%sollang.enum.1453 = type { i32, [0 x i64] }
%sollang.enum.1454 = type { i32, [0 x i64] }
%sollang.enum.1455 = type { i32, [0 x i64] }
%sollang.enum.1456 = type { i32, [0 x i64] }
%sollang.enum.1457 = type { i32, [0 x i64] }
%sollang.enum.1458 = type { i32, [0 x i64] }
%sollang.enum.1459 = type { i32, [0 x i64] }
%sollang.enum.1460 = type { i32, [0 x i64] }
%sollang.enum.1461 = type { i32, [1 x i64] }
%sollang.enum.1462 = type { i32, [1 x i64] }
%sollang.enum.1463 = type { i32, [0 x i64] }
%sollang.enum.1464 = type { i32, [0 x i64] }
%sollang.enum.1465 = type { i32, [5 x i64] }
%sollang.enum.1466 = type { i32, [4 x i64] }
%sollang.enum.1467 = type { i32, [0 x i64] }
%sollang.enum.1468 = type { i32, [1 x i64] }
%sollang.enum.1469 = type { i32, [0 x i64] }
%sollang.enum.1470 = type { i32, [1 x i64] }
%sollang.enum.1471 = type { i32, [0 x i64] }
%sollang.enum.1472 = type { i32, [1 x i64] }
%sollang.enum.1473 = type { i32, [0 x i64] }
%sollang.enum.1474 = type { i32, [1 x i64] }
%sollang.enum.1475 = type { i32, [1 x i64] }
%sollang.enum.1476 = type { i32, [0 x i64] }
%sollang.enum.1477 = type { i32, [66 x i64] }
%sollang.enum.1478 = type { i32, [1 x i64] }
%sollang.enum.1479 = type { i32, [1 x i64] }
%sollang.enum.1480 = type { i32, [0 x i64] }
%sollang.enum.1481 = type { i32, [4 x i64] }
%sollang.enum.1482 = type { i32, [1 x i64] }
%sollang.enum.1483 = type { i32, [1 x i64] }
%sollang.enum.1484 = type { i32, [0 x i64] }
%sollang.enum.1485 = type { i32, [0 x i64] }
%sollang.enum.1486 = type { i32, [0 x i64] }
%sollang.enum.1487 = type { i32, [0 x i64] }
%sollang.enum.1488 = type { i32, [0 x i64] }
%sollang.enum.1489 = type { i32, [1 x i64] }
%sollang.enum.1490 = type { i32, [0 x i64] }
%sollang.enum.1491 = type { i32, [4 x i64] }
%sollang.enum.1492 = type { i32, [1 x i64] }
%sollang.enum.1493 = type { i32, [0 x i64] }
%sollang.enum.1494 = type { i32, [1 x i64] }
%sollang.enum.1495 = type { i32, [1 x i64] }
%sollang.enum.1496 = type { i32, [0 x i64] }
%sollang.enum.1497 = type { i32, [0 x i64] }
%sollang.enum.1498 = type { i32, [0 x i64] }
%sollang.enum.1499 = type { i32, [1 x i64] }
%sollang.enum.1500 = type { i32, [0 x i64] }
%sollang.enum.1501 = type { i32, [0 x i64] }
%sollang.enum.1502 = type { i32, [0 x i64] }
%sollang.enum.1503 = type { i32, [0 x i64] }
%sollang.enum.1504 = type { i32, [0 x i64] }
%sollang.enum.1505 = type { i32, [0 x i64] }
%sollang.enum.1506 = type { i32, [0 x i64] }
%sollang.enum.1507 = type { i32, [0 x i64] }
%sollang.enum.1508 = type { i32, [0 x i64] }
%sollang.enum.1509 = type { i32, [3 x i64] }
%sollang.enum.1510 = type { i32, [0 x i64] }
%sollang.enum.1511 = type { i32, [0 x i64] }
%sollang.enum.1512 = type { i32, [0 x i64] }
%sollang.enum.1513 = type { i32, [0 x i64] }
%sollang.enum.1514 = type { i32, [0 x i64] }
%sollang.enum.1515 = type { i32, [0 x i64] }
%sollang.enum.1516 = type { i32, [0 x i64] }
%sollang.enum.1517 = type { i32, [0 x i64] }
%sollang.enum.1518 = type { i32, [0 x i64] }
%sollang.enum.1519 = type { i32, [0 x i64] }
%sollang.enum.1520 = type { i32, [3 x i64] }
%sollang.enum.1521 = type { i32, [0 x i64] }
%sollang.enum.1522 = type { i32, [2 x i64] }
%sollang.enum.1523 = type { i32, [0 x i64] }
%sollang.enum.1524 = type { i32, [2 x i64] }
%sollang.enum.1525 = type { i32, [4 x i64] }
%sollang.enum.1526 = type { i32, [0 x i64] }
%sollang.enum.1527 = type { i32, [0 x i64] }
%sollang.enum.1528 = type { i32, [0 x i64] }
%sollang.enum.1529 = type { i32, [1 x i64] }
%sollang.enum.1530 = type { i32, [0 x i64] }
%sollang.enum.1531 = type { i32, [0 x i64] }
%sollang.enum.1532 = type { i32, [2 x i64] }
%sollang.enum.1533 = type { i32, [7 x i64] }
%sollang.enum.1534 = type { i32, [0 x i64] }
%sollang.enum.1535 = type { i32, [2 x i64] }
%sollang.enum.1536 = type { i32, [0 x i64] }
%sollang.enum.1537 = type { i32, [0 x i64] }
%sollang.enum.1538 = type { i32, [0 x i64] }
%sollang.enum.1539 = type { i32, [0 x i64] }
%sollang.enum.1540 = type { i32, [2 x i64] }
%sollang.enum.1541 = type { i32, [8 x i64] }
%sollang.enum.1542 = type { i32, [0 x i64] }
%sollang.enum.1543 = type { i32, [0 x i64] }
%sollang.enum.1544 = type { i32, [7 x i64] }
%sollang.enum.1545 = type { i32, [0 x i64] }
%sollang.enum.1546 = type { i32, [0 x i64] }
%sollang.enum.1547 = type { i32, [0 x i64] }
%sollang.enum.1548 = type { i32, [0 x i64] }
%sollang.enum.1549 = type { i32, [0 x i64] }
%sollang.enum.1550 = type { i32, [0 x i64] }
%sollang.enum.1551 = type { i32, [0 x i64] }
%sollang.enum.1552 = type { i32, [1 x i64] }
%sollang.enum.1553 = type { i32, [0 x i64] }
%sollang.enum.1554 = type { i32, [0 x i64] }
%sollang.enum.1555 = type { i32, [16 x i64] }
%sollang.enum.1556 = type { i32, [16 x i64] }
%sollang.enum.1557 = type { i32, [0 x i64] }
%sollang.enum.1558 = type { i32, [0 x i64] }
%sollang.enum.1559 = type { i32, [0 x i64] }
%sollang.enum.1560 = type { i32, [0 x i64] }
%sollang.enum.1561 = type { i32, [0 x i64] }
%sollang.enum.1562 = type { i32, [0 x i64] }
%sollang.enum.1563 = type { i32, [0 x i64] }
%sollang.enum.1564 = type { i32, [0 x i64] }
%sollang.enum.1565 = type { i32, [0 x i64] }
%sollang.enum.1566 = type { i32, [0 x i64] }
%sollang.enum.1567 = type { i32, [0 x i64] }
%sollang.enum.1568 = type { i32, [0 x i64] }
%sollang.enum.1569 = type { i32, [0 x i64] }
%sollang.enum.1570 = type { i32, [0 x i64] }
%sollang.enum.1571 = type { i32, [0 x i64] }
%sollang.enum.1572 = type { i32, [3 x i64] }
%sollang.enum.1573 = type { i32, [1 x i64] }
%sollang.enum.1574 = type { i32, [12 x i64] }
%sollang.enum.1575 = type { i32, [0 x i64] }
%sollang.enum.1576 = type { i32, [0 x i64] }
%sollang.enum.1577 = type { i32, [0 x i64] }
%sollang.enum.1578 = type { i32, [0 x i64] }
%sollang.enum.1579 = type { i32, [0 x i64] }
%sollang.enum.1580 = type { i32, [2 x i64] }
%sollang.enum.1581 = type { i32, [0 x i64] }
%sollang.enum.1582 = type { i32, [2 x i64] }
%sollang.enum.1583 = type { i32, [2 x i64] }
%sollang.enum.1584 = type { i32, [1 x i64] }
%sollang.enum.2151 = type { i32, [1 x i64] }
%sollang.enum.2152 = type { i32, [7 x i64] }
%sollang.enum.2176 = type { i32, [1 x i64] }
%sollang.enum.2177 = type { i32, [2 x i64] }
%sollang.enum.2186 = type { i32, [2 x i64] }
%sollang.enum.2189 = type { i32, [1 x i64] }
%sollang.enum.2190 = type { i32, [1 x i64] }
%sollang.enum.2191 = type { i32, [3 x i64] }
%sollang.enum.2192 = type { i32, [44 x i64] }
%sollang.enum.2193 = type { i32, [2 x i64] }
%sollang.enum.2194 = type { i32, [13 x i64] }
%sollang.enum.2195 = type { i32, [2 x i64] }
%sollang.enum.2197 = type { i32, [1 x i64] }
%sollang.enum.2200 = type { i32, [3 x i64] }
%sollang.enum.2201 = type { i32, [3 x i64] }
%sollang.enum.2202 = type { i32, [4 x i64] }
%sollang.enum.2203 = type { i32, [105 x i64] }
%sollang.enum.2204 = type { i32, [2 x i64] }
%sollang.enum.2205 = type { i32, [3 x i64] }
%sollang.enum.2206 = type { i32, [9 x i64] }
%sollang.enum.2207 = type { i32, [26 x i64] }
%sollang.enum.2208 = type { i32, [81 x i64] }
%sollang.enum.2209 = type { i32, [2 x i64] }
%sollang.enum.2212 = type { i32, [26 x i64] }
%sollang.enum.2213 = type { i32, [4 x i64] }
%sollang.enum.2214 = type { i32, [2 x i64] }
%sollang.enum.2215 = type { i32, [2 x i64] }
%sollang.enum.2216 = type { i32, [2 x i64] }
%sollang.enum.2217 = type { i32, [50 x i64] }
%sollang.enum.2218 = type { i32, [2 x i64] }
%sollang.enum.2219 = type { i32, [3 x i64] }
%sollang.enum.2220 = type { i32, [2 x i64] }
%sollang.enum.2221 = type { i32, [2 x i64] }
%sollang.enum.2223 = type { i32, [2 x i64] }
%sollang.enum.2224 = type { i32, [2 x i64] }
%sollang.enum.2226 = type { i32, [9 x i64] }
%sollang.enum.2227 = type { i32, [24 x i64] }
%sollang.enum.2228 = type { i32, [2 x i64] }
%sollang.enum.2229 = type { i32, [12 x i64] }
%sollang.enum.2230 = type { i32, [11 x i64] }
%sollang.enum.2231 = type { i32, [2 x i64] }
%sollang.enum.2232 = type { i32, [32 x i64] }
%sollang.enum.2233 = type { i32, [34 x i64] }
%sollang.enum.2234 = type { i32, [2 x i64] }
%sollang.enum.2235 = type { i32, [9 x i64] }
%sollang.enum.2236 = type { i32, [31 x i64] }
%sollang.enum.2237 = type { i32, [2 x i64] }
%sollang.enum.2238 = type { i32, [15 x i64] }
%sollang.enum.2239 = type { i32, [34 x i64] }
%sollang.enum.2240 = type { i32, [2 x i64] }
%sollang.enum.2241 = type { i32, [2 x i64] }
%sollang.enum.2242 = type { i32, [6 x i64] }
%sollang.enum.2243 = type { i32, [2 x i64] }
%sollang.enum.2244 = type { i32, [2 x i64] }
%sollang.enum.2245 = type { i32, [2 x i64] }
%sollang.enum.2247 = type { i32, [14 x i64] }
%sollang.enum.2248 = type { i32, [9 x i64] }
%sollang.enum.2249 = type { i32, [5 x i64] }
%sollang.enum.2250 = type { i32, [5 x i64] }
%sollang.enum.2251 = type { i32, [4 x i64] }
%sollang.enum.2252 = type { i32, [2 x i64] }
%sollang.enum.2254 = type { i32, [2 x i64] }
%sollang.enum.2255 = type { i32, [2 x i64] }
%sollang.enum.2256 = type { i32, [81 x i64] }
%sollang.enum.2257 = type { i32, [3 x i64] }
%sollang.enum.2258 = type { i32, [2 x i64] }
%sollang.enum.2259 = type { i32, [3 x i64] }
%sollang.enum.2260 = type { i32, [5 x i64] }
%sollang.enum.2261 = type { i32, [2 x i64] }
%sollang.enum.2262 = type { i32, [14 x i64] }
%sollang.enum.2263 = type { i32, [2 x i64] }
%sollang.enum.2264 = type { i32, [32 x i64] }
%sollang.enum.2265 = type { i32, [4 x i64] }
%sollang.enum.2266 = type { i32, [2 x i64] }
%sollang.enum.2268 = type { i32, [5 x i64] }
%sollang.enum.2269 = type { i32, [2 x i64] }
%sollang.enum.2270 = type { i32, [2 x i64] }
%sollang.enum.2271 = type { i32, [5 x i64] }
%sollang.enum.2272 = type { i32, [2 x i64] }
%sollang.enum.2273 = type { i32, [2 x i64] }
%sollang.enum.2274 = type { i32, [32 x i64] }
%sollang.enum.2275 = type { i32, [2 x i64] }
%sollang.enum.2276 = type { i32, [4 x i64] }
%sollang.enum.2278 = type { i32, [2 x i64] }
%sollang.enum.2279 = type { i32, [2 x i64] }
%sollang.enum.2280 = type { i32, [4 x i64] }
%sollang.enum.2281 = type { i32, [2 x i64] }
%sollang.enum.2282 = type { i32, [2 x i64] }
%sollang.enum.2283 = type { i32, [2 x i64] }
%sollang.enum.2284 = type { i32, [2 x i64] }
%sollang.enum.2285 = type { i32, [2 x i64] }
%sollang.enum.2286 = type { i32, [2 x i64] }
%sollang.enum.2287 = type { i32, [3 x i64] }
%sollang.enum.2288 = type { i32, [2 x i64] }
%sollang.enum.2290 = type { i32, [3 x i64] }
%sollang.enum.2291 = type { i32, [4 x i64] }
%sollang.enum.2292 = type { i32, [9 x i64] }
%sollang.enum.2293 = type { i32, [2 x i64] }
%sollang.enum.2294 = type { i32, [32 x i64] }
%sollang.enum.2295 = type { i32, [3 x i64] }
%sollang.enum.2297 = type { i32, [5 x i64] }
%sollang.enum.2298 = type { i32, [2 x i64] }
%sollang.enum.2299 = type { i32, [2 x i64] }
%sollang.enum.2300 = type { i32, [4 x i64] }
%sollang.enum.2301 = type { i32, [4 x i64] }
%sollang.enum.2302 = type { i32, [72 x i64] }
%sollang.enum.2303 = type { i32, [2 x i64] }
%sollang.enum.2304 = type { i32, [2 x i64] }
%sollang.enum.2305 = type { i32, [3 x i64] }
%sollang.enum.2306 = type { i32, [2 x i64] }
%sollang.enum.2307 = type { i32, [13 x i64] }
%sollang.enum.2308 = type { i32, [26 x i64] }
%sollang.enum.2309 = type { i32, [5 x i64] }
%sollang.enum.2310 = type { i32, [2 x i64] }
%sollang.enum.2313 = type { i32, [2 x i64] }
%sollang.enum.2314 = type { i32, [72 x i64] }
%sollang.enum.2315 = type { i32, [3 x i64] }
%sollang.enum.2316 = type { i32, [13 x i64] }
%sollang.enum.2317 = type { i32, [70 x i64] }
%sollang.enum.2318 = type { i32, [2 x i64] }
%sollang.enum.2319 = type { i32, [3 x i64] }
%sollang.enum.2320 = type { i32, [40 x i64] }
%sollang.enum.2324 = type { i32, [10 x i64] }
%sollang.enum.2325 = type { i32, [11 x i64] }
%sollang.enum.2326 = type { i32, [2 x i64] }
%sollang.enum.2327 = type { i32, [1 x i64] }
%sollang.enum.2328 = type { i32, [5 x i64] }
%sollang.enum.2329 = type { i32, [3 x i64] }
%sollang.enum.2330 = type { i32, [3 x i64] }
%sollang.enum.2331 = type { i32, [10 x i64] }
%sollang.enum.2332 = type { i32, [33 x i64] }
%sollang.enum.2333 = type { i32, [35 x i64] }
%sollang.enum.2334 = type { i32, [1 x i64] }
%sollang.enum.2336 = type { i32, [8 x i64] }
%sollang.enum.2337 = type { i32, [2 x i64] }
%sollang.enum.2338 = type { i32, [2 x i64] }
%sollang.enum.2339 = type { i32, [1 x i64] }
%sollang.enum.2340 = type { i32, [2 x i64] }
%sollang.enum.2343 = type { i32, [3 x i64] }
%sollang.enum.2345 = type { i32, [2 x i64] }
%sollang.enum.2346 = type { i32, [2 x i64] }
%sollang.enum.2347 = type { i32, [2 x i64] }
%sollang.enum.2348 = type { i32, [5 x i64] }
%sollang.enum.2349 = type { i32, [11 x i64] }
%sollang.enum.2350 = type { i32, [9 x i64] }
%sollang.enum.2352 = type { i32, [3 x i64] }
%sollang.enum.2353 = type { i32, [2 x i64] }
%sollang.enum.2354 = type { i32, [2 x i64] }
%sollang.enum.2355 = type { i32, [2 x i64] }
%sollang.enum.2356 = type { i32, [2 x i64] }
%sollang.enum.2357 = type { i32, [2 x i64] }
%sollang.enum.2358 = type { i32, [2 x i64] }
%sollang.enum.2359 = type { i32, [2 x i64] }
%sollang.enum.2360 = type { i32, [2 x i64] }
%sollang.enum.2361 = type { i32, [3 x i64] }
%sollang.enum.2362 = type { i32, [3 x i64] }
%sollang.enum.2363 = type { i32, [4 x i64] }
%sollang.enum.2364 = type { i32, [2 x i64] }
%sollang.enum.2365 = type { i32, [4 x i64] }
%sollang.enum.2366 = type { i32, [4 x i64] }
%sollang.enum.2367 = type { i32, [2 x i64] }
%sollang.enum.2368 = type { i32, [8 x i64] }
%sollang.enum.2369 = type { i32, [2 x i64] }
%sollang.enum.2370 = type { i32, [4 x i64] }
%sollang.enum.2371 = type { i32, [3 x i64] }
%sollang.enum.2372 = type { i32, [2 x i64] }
%sollang.enum.2373 = type { i32, [2 x i64] }
%sollang.enum.2374 = type { i32, [5 x i64] }
%sollang.enum.2375 = type { i32, [10 x i64] }
%sollang.enum.2376 = type { i32, [10 x i64] }
%sollang.enum.2377 = type { i32, [11 x i64] }
%sollang.enum.2378 = type { i32, [11 x i64] }
%sollang.enum.2379 = type { i32, [7 x i64] }
%sollang.enum.2380 = type { i32, [8 x i64] }
%sollang.enum.2381 = type { i32, [7 x i64] }
%sollang.enum.2382 = type { i32, [8 x i64] }
%sollang.enum.2383 = type { i32, [2 x i64] }
%sollang.enum.2384 = type { i32, [7 x i64] }
%sollang.enum.2385 = type { i32, [7 x i64] }
%sollang.enum.2386 = type { i32, [3 x i64] }
%sollang.enum.2387 = type { i32, [3 x i64] }
%sollang.enum.2388 = type { i32, [2 x i64] }
%sollang.enum.2389 = type { i32, [2 x i64] }
%sollang.enum.2391 = type { i32, [2 x i64] }
%sollang.enum.2392 = type { i32, [4 x i64] }
%sollang.enum.2393 = type { i32, [3 x i64] }
%sollang.enum.2394 = type { i32, [3 x i64] }
%sollang.enum.2395 = type { i32, [13 x i64] }
%sollang.enum.2396 = type { i32, [12 x i64] }
%sollang.enum.2397 = type { i32, [4 x i64] }
%sollang.enum.2398 = type { i32, [2 x i64] }
%sollang.enum.2399 = type { i32, [2 x i64] }
%sollang.enum.2401 = type { i32, [2 x i64] }
%sollang.enum.2402 = type { i32, [5 x i64] }
%sollang.enum.2403 = type { i32, [3 x i64] }
%sollang.enum.2404 = type { i32, [15 x i64] }
%sollang.enum.2405 = type { i32, [3 x i64] }
%sollang.enum.2406 = type { i32, [2 x i64] }
%sollang.enum.2407 = type { i32, [3 x i64] }
%sollang.enum.2412 = type { i32, [2 x i64] }
%sollang.enum.2413 = type { i32, [3 x i64] }
%sollang.enum.2414 = type { i32, [3 x i64] }
%sollang.enum.2415 = type { i32, [15 x i64] }
%sollang.enum.2416 = type { i32, [25 x i64] }
%sollang.enum.2417 = type { i32, [7 x i64] }
%sollang.enum.2418 = type { i32, [5 x i64] }
%sollang.enum.2419 = type { i32, [9 x i64] }
%sollang.enum.2420 = type { i32, [31 x i64] }
%sollang.enum.2421 = type { i32, [3 x i64] }
%sollang.enum.2422 = type { i32, [8 x i64] }
%sollang.enum.2423 = type { i32, [2 x i64] }
%sollang.enum.2424 = type { i32, [12 x i64] }
%sollang.enum.2425 = type { i32, [6 x i64] }
%sollang.enum.2426 = type { i32, [2 x i64] }
%sollang.enum.2427 = type { i32, [9 x i64] }
%sollang.enum.2428 = type { i32, [6 x i64] }
%sollang.enum.2429 = type { i32, [3 x i64] }
%sollang.enum.2430 = type { i32, [26 x i64] }
%sollang.enum.2431 = type { i32, [4 x i64] }
%sollang.enum.2432 = type { i32, [5 x i64] }
%sollang.enum.2433 = type { i32, [8 x i64] }
%sollang.enum.2434 = type { i32, [40 x i64] }
%sollang.enum.2435 = type { i32, [9 x i64] }
%sollang.enum.2436 = type { i32, [3 x i64] }
%sollang.enum.2440 = type { i32, [2 x i64] }
%sollang.enum.2441 = type { i32, [2 x i64] }
%sollang.enum.2442 = type { i32, [9 x i64] }
%sollang.enum.2443 = type { i32, [21 x i64] }
%sollang.enum.2444 = type { i32, [2 x i64] }
%sollang.enum.2445 = type { i32, [2 x i64] }
%sollang.enum.2446 = type { i32, [4 x i64] }
%sollang.enum.2447 = type { i32, [3 x i64] }
%sollang.enum.2448 = type { i32, [9 x i64] }
%sollang.enum.2449 = type { i32, [2 x i64] }
%sollang.enum.2450 = type { i32, [5 x i64] }
%sollang.enum.2451 = type { i32, [2 x i64] }
%sollang.enum.2452 = type { i32, [14 x i64] }
%sollang.enum.2454 = type { i32, [11 x i64] }
%sollang.enum.2455 = type { i32, [16 x i64] }
%sollang.enum.2456 = type { i32, [7 x i64] }
%sollang.enum.2459 = type { i32, [7 x i64] }
%sollang.enum.2460 = type { i32, [4 x i64] }
%sollang.enum.2461 = type { i32, [6 x i64] }
%sollang.enum.2462 = type { i32, [7 x i64] }
%sollang.enum.2463 = type { i32, [6 x i64] }
%sollang.enum.2464 = type { i32, [5 x i64] }
%sollang.enum.2465 = type { i32, [2 x i64] }
%sollang.enum.2466 = type { i32, [4 x i64] }
%sollang.enum.2467 = type { i32, [10 x i64] }
%sollang.enum.2468 = type { i32, [131 x i64] }
%sollang.enum.2469 = type { i32, [2 x i64] }
%sollang.enum.2470 = type { i32, [16 x i64] }
%sollang.enum.2471 = type { i32, [7 x i64] }
%sollang.enum.2472 = type { i32, [10 x i64] }
%sollang.enum.2473 = type { i32, [5 x i64] }
%sollang.enum.2475 = type { i32, [2 x i64] }
%sollang.enum.2476 = type { i32, [17 x i64] }
%sollang.enum.2478 = type { i32, [10 x i64] }
%sollang.enum.2479 = type { i32, [5 x i64] }
%sollang.enum.2480 = type { i32, [3 x i64] }
%sollang.enum.2481 = type { i32, [8 x i64] }
%sollang.enum.2482 = type { i32, [2 x i64] }
%sollang.enum.2483 = type { i32, [4 x i64] }
%sollang.enum.2484 = type { i32, [2 x i64] }
%sollang.enum.2485 = type { i32, [9 x i64] }
%sollang.enum.2486 = type { i32, [3 x i64] }
%sollang.enum.2487 = type { i32, [7 x i64] }
%sollang.enum.2488 = type { i32, [11 x i64] }
%sollang.enum.2489 = type { i32, [7 x i64] }
%sollang.enum.2493 = type { i32, [6 x i64] }
%sollang.enum.2495 = type { i32, [11 x i64] }
%sollang.enum.2496 = type { i32, [2 x i64] }
%sollang.enum.2497 = type { i32, [18 x i64] }
%sollang.enum.2498 = type { i32, [149 x i64] }
%sollang.enum.2500 = type { i32, [3 x i64] }
%sollang.enum.2501 = type { i32, [2 x i64] }
%sollang.enum.2502 = type { i32, [2 x i64] }
%sollang.enum.2504 = type { i32, [12 x i64] }
%sollang.enum.2505 = type { i32, [9 x i64] }
%sollang.enum.2506 = type { i32, [5 x i64] }
%sollang.enum.2507 = type { i32, [5 x i64] }
%sollang.enum.2508 = type { i32, [6 x i64] }
%sollang.enum.2509 = type { i32, [6 x i64] }
%sollang.enum.2510 = type { i32, [2 x i64] }
%sollang.enum.2511 = type { i32, [14 x i64] }
%sollang.enum.2512 = type { i32, [6 x i64] }
%sollang.enum.2513 = type { i32, [6 x i64] }
%sollang.enum.2514 = type { i32, [4 x i64] }
%sollang.enum.2515 = type { i32, [5 x i64] }
%sollang.enum.2516 = type { i32, [4 x i64] }
%sollang.enum.2517 = type { i32, [21 x i64] }
%sollang.enum.2518 = type { i32, [4 x i64] }
%sollang.enum.2519 = type { i32, [5 x i64] }
%sollang.enum.2520 = type { i32, [2 x i64] }
%sollang.enum.2522 = type { i32, [3 x i64] }
%sollang.enum.2523 = type { i32, [4 x i64] }
%sollang.enum.2524 = type { i32, [2 x i64] }
%sollang.enum.2525 = type { i32, [6 x i64] }
%sollang.enum.2526 = type { i32, [5 x i64] }
%sollang.enum.2527 = type { i32, [5 x i64] }
%sollang.enum.2530 = type { i32, [16 x i64] }
%sollang.enum.2531 = type { i32, [7 x i64] }
%sollang.enum.2532 = type { i32, [6 x i64] }
%sollang.enum.2533 = type { i32, [4 x i64] }
%sollang.enum.2534 = type { i32, [5 x i64] }
%sollang.enum.2535 = type { i32, [2 x i64] }
%sollang.enum.2536 = type { i32, [2 x i64] }
%sollang.enum.2537 = type { i32, [4 x i64] }
%sollang.enum.2539 = type { i32, [9 x i64] }
%sollang.enum.2540 = type { i32, [4 x i64] }
%sollang.enum.2541 = type { i32, [3 x i64] }
%sollang.enum.2542 = type { i32, [17 x i64] }
%sollang.enum.2543 = type { i32, [2 x i64] }
%sollang.enum.2544 = type { i32, [3 x i64] }
%sollang.enum.2545 = type { i32, [12 x i64] }
%sollang.enum.2546 = type { i32, [3 x i64] }
%sollang.enum.2547 = type { i32, [4 x i64] }
%sollang.enum.2548 = type { i32, [12 x i64] }
%sollang.enum.2549 = type { i32, [4 x i64] }
%sollang.enum.2550 = type { i32, [3 x i64] }
%sollang.enum.2551 = type { i32, [3 x i64] }
%sollang.enum.2552 = type { i32, [4 x i64] }
%sollang.enum.2553 = type { i32, [2 x i64] }
%sollang.enum.2554 = type { i32, [3 x i64] }
%sollang.enum.2556 = type { i32, [6 x i64] }
%sollang.enum.2557 = type { i32, [3 x i64] }
%sollang.enum.2558 = type { i32, [2 x i64] }
%sollang.enum.2559 = type { i32, [2 x i64] }
%sollang.enum.2560 = type { i32, [2 x i64] }
%sollang.enum.2561 = type { i32, [3 x i64] }
%sollang.enum.2562 = type { i32, [2 x i64] }
%sollang.enum.2563 = type { i32, [2 x i64] }
%sollang.enum.2564 = type { i32, [12 x i64] }
%sollang.enum.2565 = type { i32, [6 x i64] }
%sollang.enum.2566 = type { i32, [3 x i64] }
%sollang.enum.2567 = type { i32, [2 x i64] }
%sollang.enum.2568 = type { i32, [8 x i64] }
%sollang.enum.2570 = type { i32, [2 x i64] }
%sollang.enum.2571 = type { i32, [4 x i64] }
%sollang.enum.2574 = type { i32, [4 x i64] }
%sollang.enum.2575 = type { i32, [4 x i64] }
%sollang.enum.2576 = type { i32, [7 x i64] }
%sollang.enum.2577 = type { i32, [4 x i64] }
%sollang.enum.2579 = type { i32, [9 x i64] }
%sollang.enum.2580 = type { i32, [2 x i64] }
%sollang.enum.2581 = type { i32, [4 x i64] }
%sollang.enum.2582 = type { i32, [1 x i64] }
%sollang.enum.2583 = type { i32, [1 x i64] }
%sollang.enum.2584 = type { i32, [2 x i64] }
%sollang.enum.2585 = type { i32, [2 x i64] }
%sollang.enum.2586 = type { i32, [2 x i64] }
%sollang.enum.2587 = type { i32, [6 x i64] }
%sollang.enum.2588 = type { i32, [1 x i64] }
%sollang.enum.2589 = type { i32, [1 x i64] }
%sollang.enum.2590 = type { i32, [1 x i64] }
%sollang.enum.2591 = type { i32, [1 x i64] }
%sollang.enum.2592 = type { i32, [11 x i64] }
%sollang.enum.2593 = type { i32, [29 x i64] }
%sollang.enum.2594 = type { i32, [12 x i64] }
%sollang.enum.2595 = type { i32, [2 x i64] }
%sollang.enum.2596 = type { i32, [3 x i64] }
%sollang.enum.2597 = type { i32, [2 x i64] }
%sollang.enum.2599 = type { i32, [2 x i64] }
%sollang.enum.2600 = type { i32, [3 x i64] }
%sollang.enum.2601 = type { i32, [2 x i64] }
%sollang.enum.2602 = type { i32, [1 x i64] }
%sollang.enum.2603 = type { i32, [1 x i64] }
%sollang.enum.2606 = type { i32, [2 x i64] }
%sollang.enum.2607 = type { i32, [2 x i64] }
%sollang.enum.2608 = type { i32, [2 x i64] }
%sollang.enum.2611 = type { i32, [2 x i64] }
%sollang.enum.2612 = type { i32, [7 x i64] }
%sollang.enum.2613 = type { i32, [4 x i64] }
%sollang.enum.2614 = type { i32, [2 x i64] }
%sollang.enum.2615 = type { i32, [2 x i64] }
%sollang.enum.2617 = type { i32, [3 x i64] }
%sollang.enum.2620 = type { i32, [6 x i64] }
%sollang.enum.2621 = type { i32, [2 x i64] }
%sollang.enum.2622 = type { i32, [3 x i64] }
%sollang.enum.2623 = type { i32, [8 x i64] }
%sollang.enum.2624 = type { i32, [2 x i64] }
%sollang.enum.2625 = type { i32, [3 x i64] }
%sollang.enum.2626 = type { i32, [1 x i64] }
%sollang.enum.2627 = type { i32, [2 x i64] }
%sollang.enum.2628 = type { i32, [2 x i64] }
%sollang.enum.2630 = type { i32, [2 x i64] }
%sollang.enum.2631 = type { i32, [4 x i64] }
%sollang.enum.2632 = type { i32, [3 x i64] }
%sollang.enum.2633 = type { i32, [18 x i64] }
%sollang.enum.2634 = type { i32, [3 x i64] }
%sollang.enum.2635 = type { i32, [16 x i64] }
%sollang.enum.2636 = type { i32, [2 x i64] }
%sollang.enum.2637 = type { i32, [2 x i64] }
%sollang.enum.2638 = type { i32, [2 x i64] }
%sollang.enum.2639 = type { i32, [2 x i64] }
%sollang.enum.2641 = type { i32, [1 x i64] }
%sollang.enum.2642 = type { i32, [2 x i64] }
%sollang.enum.2643 = type { i32, [5 x i64] }
%sollang.enum.2644 = type { i32, [2 x i64] }
%sollang.enum.2645 = type { i32, [3 x i64] }
%sollang.enum.2648 = type { i32, [2 x i64] }
%sollang.enum.2649 = type { i32, [9 x i64] }
%sollang.enum.2650 = type { i32, [7 x i64] }

@sollang_file_writer = internal global ptr null
@sollang_file_reader = internal global ptr null
@sollang_argument_count_value = internal global i64 0
@sollang_argument_records = internal global ptr null
@sollang_environment_allocations = internal global ptr null
@sollang_environment_empty = internal constant [1 x i8] zeroinitializer, align 1
@sollang_stdout_buffer = internal global [1048576 x i8] zeroinitializer, align 16
@sollang_stdout_buffer_count = internal global i64 0
@sollang_stdout_line_buffered = internal global i1 false
@_fltused = global i32 0
@sollang_random_state = internal global i64 88172645463393265
@sollang_writer_buffer = internal global [8192 x i64] zeroinitializer, align 8
@sollang_writer_buffer_count = internal global i64 0

declare dllimport ptr @GetStdHandle(i32)
declare dllimport i32 @GetConsoleMode(ptr, ptr)
declare dllimport i32 @WriteConsoleW(ptr, ptr, i32, ptr, ptr)
declare dllimport i32 @WriteFile(ptr, ptr, i32, ptr, ptr)
declare dllimport i32 @ReadFile(ptr, ptr, i32, ptr, ptr)
declare dllimport i32 @GetOverlappedResult(ptr, ptr, ptr, i32)
declare dllimport ptr @CreateFileA(ptr, i32, i32, ptr, i32, i32, ptr)
declare dllimport ptr @CreateFileW(ptr, i32, i32, ptr, i32, i32, ptr)
declare dllimport i32 @CloseHandle(ptr)
declare dllimport ptr @GetCurrentProcess()
declare dllimport i32 @DuplicateHandle(ptr, ptr, ptr, ptr, i32, i32, i32)
declare dllimport i32 @SetFilePointerEx(ptr, i64, ptr, i32)
declare dllimport i32 @GetFileSizeEx(ptr, ptr)
declare dllimport i32 @SetEndOfFile(ptr)
declare dllimport ptr @CreateFileMappingA(ptr, ptr, i32, i32, i32, ptr)
declare dllimport ptr @MapViewOfFile(ptr, i32, i32, i32, i64)
declare dllimport i32 @UnmapViewOfFile(ptr)
declare dllimport i32 @FlushViewOfFile(ptr, i64)
declare dllimport i32 @FlushFileBuffers(ptr)
declare dllimport i32 @MoveFileExA(ptr, ptr, i32)
declare dllimport i32 @MoveFileExW(ptr, ptr, i32)
declare dllimport i32 @DeleteFileA(ptr)
declare dllimport i32 @DeleteFileW(ptr)
declare dllimport ptr @GetProcessHeap()
declare dllimport ptr @HeapAlloc(ptr, i32, i64)
declare dllimport i32 @HeapFree(ptr, i32, ptr)
declare dllimport i64 @GetTickCount64()
declare dllimport void @GetSystemTimePreciseAsFileTime(ptr)
declare dllimport void @Sleep(i32)
declare dllimport ptr @GetCommandLineW()
declare dllimport ptr @CommandLineToArgvW(ptr, ptr)
declare dllimport i32 @WideCharToMultiByte(i32, i32, ptr, i32, ptr, i32, ptr, ptr)
declare dllimport ptr @LocalFree(ptr)
declare dllimport i32 @MultiByteToWideChar(i32, i32, ptr, i32, ptr, i32)
declare dllimport i32 @GetEnvironmentVariableW(ptr, ptr, i32)
declare dllimport i32 @GetLastError()
declare dllimport void @SetLastError(i32)
define internal i32 @sollang_windows_utf8_path(ptr %data, i64 %length, ptr %wide, i32 %capacity) #0 {
entry:
  %positive = icmp ugt i64 %length, 0
  %fits_i32 = icmp ule i64 %length, 2147483647
  %length_valid = and i1 %positive, %fits_i32
  br i1 %length_valid, label %check, label %failure
check:
  %index = phi i64 [ 0, %entry ], [ %next, %advance ]
  %done = icmp eq i64 %index, %length
  br i1 %done, label %convert, label %inspect
inspect:
  %byte_ptr = getelementptr i8, ptr %data, i64 %index
  %byte = load i8, ptr %byte_ptr, align 1
  %nul = icmp eq i8 %byte, 0
  br i1 %nul, label %failure, label %advance
advance:
  %next = add i64 %index, 1
  br label %check
convert:
  %length32 = trunc i64 %length to i32
  %room = sub i32 %capacity, 1
  %converted = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %length32, ptr %wide, i32 %room)
  %converted_ok = icmp sgt i32 %converted, 0
  br i1 %converted_ok, label %terminate, label %failure
terminate:
  %zero = getelementptr i16, ptr %wide, i32 %converted
  store i16 0, ptr %zero, align 2
  ret i32 1
failure:
  ret i32 0
}

declare void @llvm.trap()
declare i64 @llvm.ctpop.i64(i64)
declare i16 @llvm.cttz.i16(i16, i1 immarg)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg)
declare void @llvm.memcpy.p0.p0.i64(ptr nocapture writeonly, ptr nocapture readonly, i64, i1 immarg)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture)

define internal void @sollang_drop_48(%sollang.int_slice %value) #0 {
entry:
  %fixed_array_ptr0 = extractvalue %sollang.int_slice %value, 0
  %fixed_array_len1 = extractvalue %sollang.int_slice %value, 1
  call void @sollang_free(ptr %fixed_array_ptr0)
  ret void
}

define internal void @sollang_drop_2668(%sollang.int_slice %value) #0 {
entry:
  %fixed_array_ptr2 = extractvalue %sollang.int_slice %value, 0
  %fixed_array_len3 = extractvalue %sollang.int_slice %value, 1
  call void @sollang_free(ptr %fixed_array_ptr2)
  ret void
}

define internal void @sollang_drop_36(%sollang.dynamic_int_array %value) #0 {
entry:
  %drop_array_ptr4 = extractvalue %sollang.dynamic_int_array %value, 0
  call void @sollang_free(ptr %drop_array_ptr4)
  ret void
}

define internal void @sollang_drop_1155(%sollang.struct.1155 %value) #0 {
entry:
  %drop_field5 = extractvalue %sollang.struct.1155 %value, 0
  call void @sollang_drop_36(%sollang.dynamic_int_array %drop_field5)
  ret void
}

define internal void @sollang_drop_1156(%sollang.struct.1156 %value) #0 {
entry:
  %drop_field6 = extractvalue %sollang.struct.1156 %value, 0
  call void @sollang_drop_48(%sollang.int_slice %drop_field6)
  ret void
}

@.slg.str.module.x.0 = private unnamed_addr constant [29 x i8] c".sp800Block:allocation_failed", align 1
@.slg.str.module.x.1 = private unnamed_addr constant [33 x i8] c".zeroCiphertext:allocation_failed", align 1
@.slg.str.module.x.2 = private unnamed_addr constant [34 x i8] c".incrementingKey:allocation_failed", align 1
@.slg.str.module.x.3 = private unnamed_addr constant [34 x i8] c".sp800Ciphertext:allocation_failed", align 1
@.slg.str.module.x.4 = private unnamed_addr constant [36 x i8] c".incrementingBlock:allocation_failed", align 1
@.slg.str.module.x.5 = private unnamed_addr constant [41 x i8] c".incrementingCiphertext:allocation_failed", align 1
@.slg.str.module.x.6 = private unnamed_addr constant [30 x i8] c".matches:bb_slice_bounds_fail6", align 1
@.slg.str.module.x.7 = private unnamed_addr constant [30 x i8] c".matches:bb_slice_bounds_fail8", align 1
@.slg.str.module.x.8 = private unnamed_addr constant [26 x i8] c".zeroKey:allocation_failed", align 1
@.slg.str.module.x.9 = private unnamed_addr constant [27 x i8] c".sp800Key:allocation_failed", align 1
@.slg.str.module.x.10 = private unnamed_addr constant [28 x i8] c".zeroBlock:allocation_failed", align 1
define internal %sollang.int_slice @sollang_fn_sp800Block(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) #0 {
entry:
  %trap_written3 = alloca i32, align 4
  %heap0 = call ptr @sollang_alloc(i64 16)
  %heap_ok1 = icmp ne ptr %heap0, null
  br i1 %heap_ok1, label %bb_alloc_ok0, label %bb_alloc_fail1

bb_alloc_fail1:
  %trap_stderr2 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr2, ptr @.slg.str.module.x.0, i32 29, ptr %trap_written3, ptr null)
  call void @llvm.trap()
  unreachable

bb_alloc_ok0:
  %inline_array_slot4 = getelementptr i8, ptr %heap0, i64 0
  store i8 107, ptr %inline_array_slot4, align 1
  %inline_array_slot5 = getelementptr i8, ptr %heap0, i64 1
  store i8 193, ptr %inline_array_slot5, align 1
  %inline_array_slot6 = getelementptr i8, ptr %heap0, i64 2
  store i8 190, ptr %inline_array_slot6, align 1
  %inline_array_slot7 = getelementptr i8, ptr %heap0, i64 3
  store i8 226, ptr %inline_array_slot7, align 1
  %inline_array_slot8 = getelementptr i8, ptr %heap0, i64 4
  store i8 46, ptr %inline_array_slot8, align 1
  %inline_array_slot9 = getelementptr i8, ptr %heap0, i64 5
  store i8 64, ptr %inline_array_slot9, align 1
  %inline_array_slot10 = getelementptr i8, ptr %heap0, i64 6
  store i8 159, ptr %inline_array_slot10, align 1
  %inline_array_slot11 = getelementptr i8, ptr %heap0, i64 7
  store i8 150, ptr %inline_array_slot11, align 1
  %inline_array_slot12 = getelementptr i8, ptr %heap0, i64 8
  store i8 233, ptr %inline_array_slot12, align 1
  %inline_array_slot13 = getelementptr i8, ptr %heap0, i64 9
  store i8 61, ptr %inline_array_slot13, align 1
  %inline_array_slot14 = getelementptr i8, ptr %heap0, i64 10
  store i8 126, ptr %inline_array_slot14, align 1
  %inline_array_slot15 = getelementptr i8, ptr %heap0, i64 11
  store i8 17, ptr %inline_array_slot15, align 1
  %inline_array_slot16 = getelementptr i8, ptr %heap0, i64 12
  store i8 115, ptr %inline_array_slot16, align 1
  %inline_array_slot17 = getelementptr i8, ptr %heap0, i64 13
  store i8 147, ptr %inline_array_slot17, align 1
  %inline_array_slot18 = getelementptr i8, ptr %heap0, i64 14
  store i8 23, ptr %inline_array_slot18, align 1
  %inline_array_slot19 = getelementptr i8, ptr %heap0, i64 15
  store i8 42, ptr %inline_array_slot19, align 1
  %slice_value20 = insertvalue %sollang.int_slice poison, ptr %heap0, 0
  %slice_value21 = insertvalue %sollang.int_slice %slice_value20, i64 16, 1
  ret %sollang.int_slice %slice_value21
}

define internal %sollang.int_slice @sollang_fn_zeroCiphertext(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) #0 {
entry:
  %trap_written3 = alloca i32, align 4
  %heap0 = call ptr @sollang_alloc(i64 16)
  %heap_ok1 = icmp ne ptr %heap0, null
  br i1 %heap_ok1, label %bb_alloc_ok0, label %bb_alloc_fail1

bb_alloc_fail1:
  %trap_stderr2 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr2, ptr @.slg.str.module.x.1, i32 33, ptr %trap_written3, ptr null)
  call void @llvm.trap()
  unreachable

bb_alloc_ok0:
  %inline_array_slot4 = getelementptr i8, ptr %heap0, i64 0
  store i8 102, ptr %inline_array_slot4, align 1
  %inline_array_slot5 = getelementptr i8, ptr %heap0, i64 1
  store i8 233, ptr %inline_array_slot5, align 1
  %inline_array_slot6 = getelementptr i8, ptr %heap0, i64 2
  store i8 75, ptr %inline_array_slot6, align 1
  %inline_array_slot7 = getelementptr i8, ptr %heap0, i64 3
  store i8 212, ptr %inline_array_slot7, align 1
  %inline_array_slot8 = getelementptr i8, ptr %heap0, i64 4
  store i8 239, ptr %inline_array_slot8, align 1
  %inline_array_slot9 = getelementptr i8, ptr %heap0, i64 5
  store i8 138, ptr %inline_array_slot9, align 1
  %inline_array_slot10 = getelementptr i8, ptr %heap0, i64 6
  store i8 44, ptr %inline_array_slot10, align 1
  %inline_array_slot11 = getelementptr i8, ptr %heap0, i64 7
  store i8 59, ptr %inline_array_slot11, align 1
  %inline_array_slot12 = getelementptr i8, ptr %heap0, i64 8
  store i8 136, ptr %inline_array_slot12, align 1
  %inline_array_slot13 = getelementptr i8, ptr %heap0, i64 9
  store i8 76, ptr %inline_array_slot13, align 1
  %inline_array_slot14 = getelementptr i8, ptr %heap0, i64 10
  store i8 250, ptr %inline_array_slot14, align 1
  %inline_array_slot15 = getelementptr i8, ptr %heap0, i64 11
  store i8 89, ptr %inline_array_slot15, align 1
  %inline_array_slot16 = getelementptr i8, ptr %heap0, i64 12
  store i8 202, ptr %inline_array_slot16, align 1
  %inline_array_slot17 = getelementptr i8, ptr %heap0, i64 13
  store i8 52, ptr %inline_array_slot17, align 1
  %inline_array_slot18 = getelementptr i8, ptr %heap0, i64 14
  store i8 43, ptr %inline_array_slot18, align 1
  %inline_array_slot19 = getelementptr i8, ptr %heap0, i64 15
  store i8 46, ptr %inline_array_slot19, align 1
  %slice_value20 = insertvalue %sollang.int_slice poison, ptr %heap0, 0
  %slice_value21 = insertvalue %sollang.int_slice %slice_value20, i64 16, 1
  ret %sollang.int_slice %slice_value21
}

define internal %sollang.int_slice @sollang_fn_incrementingKey(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) #0 {
entry:
  %trap_written3 = alloca i32, align 4
  %heap0 = call ptr @sollang_alloc(i64 16)
  %heap_ok1 = icmp ne ptr %heap0, null
  br i1 %heap_ok1, label %bb_alloc_ok0, label %bb_alloc_fail1

bb_alloc_fail1:
  %trap_stderr2 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr2, ptr @.slg.str.module.x.2, i32 34, ptr %trap_written3, ptr null)
  call void @llvm.trap()
  unreachable

bb_alloc_ok0:
  %inline_array_slot4 = getelementptr i8, ptr %heap0, i64 0
  store i8 0, ptr %inline_array_slot4, align 1
  %inline_array_slot5 = getelementptr i8, ptr %heap0, i64 1
  store i8 1, ptr %inline_array_slot5, align 1
  %inline_array_slot6 = getelementptr i8, ptr %heap0, i64 2
  store i8 2, ptr %inline_array_slot6, align 1
  %inline_array_slot7 = getelementptr i8, ptr %heap0, i64 3
  store i8 3, ptr %inline_array_slot7, align 1
  %inline_array_slot8 = getelementptr i8, ptr %heap0, i64 4
  store i8 4, ptr %inline_array_slot8, align 1
  %inline_array_slot9 = getelementptr i8, ptr %heap0, i64 5
  store i8 5, ptr %inline_array_slot9, align 1
  %inline_array_slot10 = getelementptr i8, ptr %heap0, i64 6
  store i8 6, ptr %inline_array_slot10, align 1
  %inline_array_slot11 = getelementptr i8, ptr %heap0, i64 7
  store i8 7, ptr %inline_array_slot11, align 1
  %inline_array_slot12 = getelementptr i8, ptr %heap0, i64 8
  store i8 8, ptr %inline_array_slot12, align 1
  %inline_array_slot13 = getelementptr i8, ptr %heap0, i64 9
  store i8 9, ptr %inline_array_slot13, align 1
  %inline_array_slot14 = getelementptr i8, ptr %heap0, i64 10
  store i8 10, ptr %inline_array_slot14, align 1
  %inline_array_slot15 = getelementptr i8, ptr %heap0, i64 11
  store i8 11, ptr %inline_array_slot15, align 1
  %inline_array_slot16 = getelementptr i8, ptr %heap0, i64 12
  store i8 12, ptr %inline_array_slot16, align 1
  %inline_array_slot17 = getelementptr i8, ptr %heap0, i64 13
  store i8 13, ptr %inline_array_slot17, align 1
  %inline_array_slot18 = getelementptr i8, ptr %heap0, i64 14
  store i8 14, ptr %inline_array_slot18, align 1
  %inline_array_slot19 = getelementptr i8, ptr %heap0, i64 15
  store i8 15, ptr %inline_array_slot19, align 1
  %slice_value20 = insertvalue %sollang.int_slice poison, ptr %heap0, 0
  %slice_value21 = insertvalue %sollang.int_slice %slice_value20, i64 16, 1
  ret %sollang.int_slice %slice_value21
}

define internal %sollang.int_slice @sollang_fn_sp800Ciphertext(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) #0 {
entry:
  %trap_written3 = alloca i32, align 4
  %heap0 = call ptr @sollang_alloc(i64 16)
  %heap_ok1 = icmp ne ptr %heap0, null
  br i1 %heap_ok1, label %bb_alloc_ok0, label %bb_alloc_fail1

bb_alloc_fail1:
  %trap_stderr2 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr2, ptr @.slg.str.module.x.3, i32 34, ptr %trap_written3, ptr null)
  call void @llvm.trap()
  unreachable

bb_alloc_ok0:
  %inline_array_slot4 = getelementptr i8, ptr %heap0, i64 0
  store i8 58, ptr %inline_array_slot4, align 1
  %inline_array_slot5 = getelementptr i8, ptr %heap0, i64 1
  store i8 215, ptr %inline_array_slot5, align 1
  %inline_array_slot6 = getelementptr i8, ptr %heap0, i64 2
  store i8 123, ptr %inline_array_slot6, align 1
  %inline_array_slot7 = getelementptr i8, ptr %heap0, i64 3
  store i8 180, ptr %inline_array_slot7, align 1
  %inline_array_slot8 = getelementptr i8, ptr %heap0, i64 4
  store i8 13, ptr %inline_array_slot8, align 1
  %inline_array_slot9 = getelementptr i8, ptr %heap0, i64 5
  store i8 122, ptr %inline_array_slot9, align 1
  %inline_array_slot10 = getelementptr i8, ptr %heap0, i64 6
  store i8 54, ptr %inline_array_slot10, align 1
  %inline_array_slot11 = getelementptr i8, ptr %heap0, i64 7
  store i8 96, ptr %inline_array_slot11, align 1
  %inline_array_slot12 = getelementptr i8, ptr %heap0, i64 8
  store i8 168, ptr %inline_array_slot12, align 1
  %inline_array_slot13 = getelementptr i8, ptr %heap0, i64 9
  store i8 158, ptr %inline_array_slot13, align 1
  %inline_array_slot14 = getelementptr i8, ptr %heap0, i64 10
  store i8 202, ptr %inline_array_slot14, align 1
  %inline_array_slot15 = getelementptr i8, ptr %heap0, i64 11
  store i8 243, ptr %inline_array_slot15, align 1
  %inline_array_slot16 = getelementptr i8, ptr %heap0, i64 12
  store i8 36, ptr %inline_array_slot16, align 1
  %inline_array_slot17 = getelementptr i8, ptr %heap0, i64 13
  store i8 102, ptr %inline_array_slot17, align 1
  %inline_array_slot18 = getelementptr i8, ptr %heap0, i64 14
  store i8 239, ptr %inline_array_slot18, align 1
  %inline_array_slot19 = getelementptr i8, ptr %heap0, i64 15
  store i8 151, ptr %inline_array_slot19, align 1
  %slice_value20 = insertvalue %sollang.int_slice poison, ptr %heap0, 0
  %slice_value21 = insertvalue %sollang.int_slice %slice_value20, i64 16, 1
  ret %sollang.int_slice %slice_value21
}

define internal %sollang.int_slice @sollang_fn_incrementingBlock(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) #0 {
entry:
  %trap_written3 = alloca i32, align 4
  %heap0 = call ptr @sollang_alloc(i64 16)
  %heap_ok1 = icmp ne ptr %heap0, null
  br i1 %heap_ok1, label %bb_alloc_ok0, label %bb_alloc_fail1

bb_alloc_fail1:
  %trap_stderr2 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr2, ptr @.slg.str.module.x.4, i32 36, ptr %trap_written3, ptr null)
  call void @llvm.trap()
  unreachable

bb_alloc_ok0:
  %inline_array_slot4 = getelementptr i8, ptr %heap0, i64 0
  store i8 0, ptr %inline_array_slot4, align 1
  %inline_array_slot5 = getelementptr i8, ptr %heap0, i64 1
  store i8 17, ptr %inline_array_slot5, align 1
  %inline_array_slot6 = getelementptr i8, ptr %heap0, i64 2
  store i8 34, ptr %inline_array_slot6, align 1
  %inline_array_slot7 = getelementptr i8, ptr %heap0, i64 3
  store i8 51, ptr %inline_array_slot7, align 1
  %inline_array_slot8 = getelementptr i8, ptr %heap0, i64 4
  store i8 68, ptr %inline_array_slot8, align 1
  %inline_array_slot9 = getelementptr i8, ptr %heap0, i64 5
  store i8 85, ptr %inline_array_slot9, align 1
  %inline_array_slot10 = getelementptr i8, ptr %heap0, i64 6
  store i8 102, ptr %inline_array_slot10, align 1
  %inline_array_slot11 = getelementptr i8, ptr %heap0, i64 7
  store i8 119, ptr %inline_array_slot11, align 1
  %inline_array_slot12 = getelementptr i8, ptr %heap0, i64 8
  store i8 136, ptr %inline_array_slot12, align 1
  %inline_array_slot13 = getelementptr i8, ptr %heap0, i64 9
  store i8 153, ptr %inline_array_slot13, align 1
  %inline_array_slot14 = getelementptr i8, ptr %heap0, i64 10
  store i8 170, ptr %inline_array_slot14, align 1
  %inline_array_slot15 = getelementptr i8, ptr %heap0, i64 11
  store i8 187, ptr %inline_array_slot15, align 1
  %inline_array_slot16 = getelementptr i8, ptr %heap0, i64 12
  store i8 204, ptr %inline_array_slot16, align 1
  %inline_array_slot17 = getelementptr i8, ptr %heap0, i64 13
  store i8 221, ptr %inline_array_slot17, align 1
  %inline_array_slot18 = getelementptr i8, ptr %heap0, i64 14
  store i8 238, ptr %inline_array_slot18, align 1
  %inline_array_slot19 = getelementptr i8, ptr %heap0, i64 15
  store i8 255, ptr %inline_array_slot19, align 1
  %slice_value20 = insertvalue %sollang.int_slice poison, ptr %heap0, 0
  %slice_value21 = insertvalue %sollang.int_slice %slice_value20, i64 16, 1
  ret %sollang.int_slice %slice_value21
}

define internal %sollang.int_slice @sollang_fn_incrementingCiphertext(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) #0 {
entry:
  %trap_written3 = alloca i32, align 4
  %heap0 = call ptr @sollang_alloc(i64 16)
  %heap_ok1 = icmp ne ptr %heap0, null
  br i1 %heap_ok1, label %bb_alloc_ok0, label %bb_alloc_fail1

bb_alloc_fail1:
  %trap_stderr2 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr2, ptr @.slg.str.module.x.5, i32 41, ptr %trap_written3, ptr null)
  call void @llvm.trap()
  unreachable

bb_alloc_ok0:
  %inline_array_slot4 = getelementptr i8, ptr %heap0, i64 0
  store i8 105, ptr %inline_array_slot4, align 1
  %inline_array_slot5 = getelementptr i8, ptr %heap0, i64 1
  store i8 196, ptr %inline_array_slot5, align 1
  %inline_array_slot6 = getelementptr i8, ptr %heap0, i64 2
  store i8 224, ptr %inline_array_slot6, align 1
  %inline_array_slot7 = getelementptr i8, ptr %heap0, i64 3
  store i8 216, ptr %inline_array_slot7, align 1
  %inline_array_slot8 = getelementptr i8, ptr %heap0, i64 4
  store i8 106, ptr %inline_array_slot8, align 1
  %inline_array_slot9 = getelementptr i8, ptr %heap0, i64 5
  store i8 123, ptr %inline_array_slot9, align 1
  %inline_array_slot10 = getelementptr i8, ptr %heap0, i64 6
  store i8 4, ptr %inline_array_slot10, align 1
  %inline_array_slot11 = getelementptr i8, ptr %heap0, i64 7
  store i8 48, ptr %inline_array_slot11, align 1
  %inline_array_slot12 = getelementptr i8, ptr %heap0, i64 8
  store i8 216, ptr %inline_array_slot12, align 1
  %inline_array_slot13 = getelementptr i8, ptr %heap0, i64 9
  store i8 205, ptr %inline_array_slot13, align 1
  %inline_array_slot14 = getelementptr i8, ptr %heap0, i64 10
  store i8 183, ptr %inline_array_slot14, align 1
  %inline_array_slot15 = getelementptr i8, ptr %heap0, i64 11
  store i8 128, ptr %inline_array_slot15, align 1
  %inline_array_slot16 = getelementptr i8, ptr %heap0, i64 12
  store i8 112, ptr %inline_array_slot16, align 1
  %inline_array_slot17 = getelementptr i8, ptr %heap0, i64 13
  store i8 180, ptr %inline_array_slot17, align 1
  %inline_array_slot18 = getelementptr i8, ptr %heap0, i64 14
  store i8 197, ptr %inline_array_slot18, align 1
  %inline_array_slot19 = getelementptr i8, ptr %heap0, i64 15
  store i8 90, ptr %inline_array_slot19, align 1
  %slice_value20 = insertvalue %sollang.int_slice poison, ptr %heap0, 0
  %slice_value21 = insertvalue %sollang.int_slice %slice_value20, i64 16, 1
  ret %sollang.int_slice %slice_value21
}

define internal i1 @sollang_fn_matches(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.int_slice %it, %sollang.int_slice %arg_0) #0 {
entry:
  %mutable_scalar_slot4 = alloca i1, align 1
  %mutable_scalar_slot5 = alloca i32, align 4
  %trap_written15 = alloca i32, align 4
  %trap_written22 = alloca i32, align 4
  %param_slice_ptr0 = extractvalue %sollang.int_slice %it, 0
  %param_slice_len1 = extractvalue %sollang.int_slice %it, 1
  %slice_ptr2 = extractvalue %sollang.int_slice %arg_0, 0
  %slice_len3 = extractvalue %sollang.int_slice %arg_0, 1
  store i1 true, ptr %mutable_scalar_slot4, align 1
  store i32 0, ptr %mutable_scalar_slot5, align 4
  br label %bb_while_condition0
bb_while_condition0:
  %mutable_scalar6 = load i32, ptr %mutable_scalar_slot5, align 4
  %slice_len_value7 = trunc i64 %param_slice_len1 to i32
  %cmp8 = icmp slt i32 %mutable_scalar6, %slice_len_value7
  br i1 %cmp8, label %bb_and_rhs3, label %bb_and_end4
bb_and_rhs3:
  %mutable_scalar9 = load i1, ptr %mutable_scalar_slot4, align 1
  br label %bb_and_end4
bb_and_end4:
  %and10 = phi i1 [ false, %bb_while_condition0 ], [ %mutable_scalar9, %bb_and_rhs3 ]
  br i1 %and10, label %bb_while_body1, label %bb_while_end2
bb_while_body1:
  %mutable_scalar11 = load i32, ptr %mutable_scalar_slot5, align 4
  %index_size12 = sext i32 %mutable_scalar11 to i64
  %slice_in_bounds13 = icmp ult i64 %index_size12, %param_slice_len1
  br i1 %slice_in_bounds13, label %bb_slice_bounds_ok5, label %bb_slice_bounds_fail6

bb_slice_bounds_fail6:
  %trap_stderr14 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr14, ptr @.slg.str.module.x.6, i32 30, ptr %trap_written15, ptr null)
  call void @llvm.trap()
  unreachable

bb_slice_bounds_ok5:
  %slice_slot16 = getelementptr i8, ptr %param_slice_ptr0, i64 %index_size12
  %slice_item17 = load i8, ptr %slice_slot16, align 1
  %mutable_scalar18 = load i32, ptr %mutable_scalar_slot5, align 4
  %index_size19 = sext i32 %mutable_scalar18 to i64
  %slice_in_bounds20 = icmp ult i64 %index_size19, %slice_len3
  br i1 %slice_in_bounds20, label %bb_slice_bounds_ok7, label %bb_slice_bounds_fail8

bb_slice_bounds_fail8:
  %trap_stderr21 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr21, ptr @.slg.str.module.x.7, i32 30, ptr %trap_written22, ptr null)
  call void @llvm.trap()
  unreachable

bb_slice_bounds_ok7:
  %slice_slot23 = getelementptr i8, ptr %slice_ptr2, i64 %index_size19
  %slice_item24 = load i8, ptr %slice_slot23, align 1
  %cmp25 = icmp ne i8 %slice_item17, %slice_item24
  br i1 %cmp25, label %bb_if_then9, label %bb_if_end10
bb_if_then9:
  store i1 false, ptr %mutable_scalar_slot4, align 1
  br label %bb_if_end10
bb_if_end10:
  %mutable_scalar26 = load i32, ptr %mutable_scalar_slot5, align 4
  %add27 = add i32 %mutable_scalar26, 1
  store i32 %add27, ptr %mutable_scalar_slot5, align 4
  br label %bb_while_condition0
bb_while_end2:
  %mutable_scalar28 = load i1, ptr %mutable_scalar_slot4, align 1
  ret i1 %mutable_scalar28
}

define internal %sollang.int_slice @sollang_fn_zeroKey(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) #0 {
entry:
  %trap_written3 = alloca i32, align 4
  %heap0 = call ptr @sollang_alloc(i64 16)
  %heap_ok1 = icmp ne ptr %heap0, null
  br i1 %heap_ok1, label %bb_alloc_ok0, label %bb_alloc_fail1

bb_alloc_fail1:
  %trap_stderr2 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr2, ptr @.slg.str.module.x.8, i32 26, ptr %trap_written3, ptr null)
  call void @llvm.trap()
  unreachable

bb_alloc_ok0:
  %inline_array_slot4 = getelementptr i8, ptr %heap0, i64 0
  store i8 0, ptr %inline_array_slot4, align 1
  %inline_array_slot5 = getelementptr i8, ptr %heap0, i64 1
  store i8 0, ptr %inline_array_slot5, align 1
  %inline_array_slot6 = getelementptr i8, ptr %heap0, i64 2
  store i8 0, ptr %inline_array_slot6, align 1
  %inline_array_slot7 = getelementptr i8, ptr %heap0, i64 3
  store i8 0, ptr %inline_array_slot7, align 1
  %inline_array_slot8 = getelementptr i8, ptr %heap0, i64 4
  store i8 0, ptr %inline_array_slot8, align 1
  %inline_array_slot9 = getelementptr i8, ptr %heap0, i64 5
  store i8 0, ptr %inline_array_slot9, align 1
  %inline_array_slot10 = getelementptr i8, ptr %heap0, i64 6
  store i8 0, ptr %inline_array_slot10, align 1
  %inline_array_slot11 = getelementptr i8, ptr %heap0, i64 7
  store i8 0, ptr %inline_array_slot11, align 1
  %inline_array_slot12 = getelementptr i8, ptr %heap0, i64 8
  store i8 0, ptr %inline_array_slot12, align 1
  %inline_array_slot13 = getelementptr i8, ptr %heap0, i64 9
  store i8 0, ptr %inline_array_slot13, align 1
  %inline_array_slot14 = getelementptr i8, ptr %heap0, i64 10
  store i8 0, ptr %inline_array_slot14, align 1
  %inline_array_slot15 = getelementptr i8, ptr %heap0, i64 11
  store i8 0, ptr %inline_array_slot15, align 1
  %inline_array_slot16 = getelementptr i8, ptr %heap0, i64 12
  store i8 0, ptr %inline_array_slot16, align 1
  %inline_array_slot17 = getelementptr i8, ptr %heap0, i64 13
  store i8 0, ptr %inline_array_slot17, align 1
  %inline_array_slot18 = getelementptr i8, ptr %heap0, i64 14
  store i8 0, ptr %inline_array_slot18, align 1
  %inline_array_slot19 = getelementptr i8, ptr %heap0, i64 15
  store i8 0, ptr %inline_array_slot19, align 1
  %slice_value20 = insertvalue %sollang.int_slice poison, ptr %heap0, 0
  %slice_value21 = insertvalue %sollang.int_slice %slice_value20, i64 16, 1
  ret %sollang.int_slice %slice_value21
}

define internal %sollang.int_slice @sollang_fn_sp800Key(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) #0 {
entry:
  %trap_written3 = alloca i32, align 4
  %heap0 = call ptr @sollang_alloc(i64 16)
  %heap_ok1 = icmp ne ptr %heap0, null
  br i1 %heap_ok1, label %bb_alloc_ok0, label %bb_alloc_fail1

bb_alloc_fail1:
  %trap_stderr2 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr2, ptr @.slg.str.module.x.9, i32 27, ptr %trap_written3, ptr null)
  call void @llvm.trap()
  unreachable

bb_alloc_ok0:
  %inline_array_slot4 = getelementptr i8, ptr %heap0, i64 0
  store i8 43, ptr %inline_array_slot4, align 1
  %inline_array_slot5 = getelementptr i8, ptr %heap0, i64 1
  store i8 126, ptr %inline_array_slot5, align 1
  %inline_array_slot6 = getelementptr i8, ptr %heap0, i64 2
  store i8 21, ptr %inline_array_slot6, align 1
  %inline_array_slot7 = getelementptr i8, ptr %heap0, i64 3
  store i8 22, ptr %inline_array_slot7, align 1
  %inline_array_slot8 = getelementptr i8, ptr %heap0, i64 4
  store i8 40, ptr %inline_array_slot8, align 1
  %inline_array_slot9 = getelementptr i8, ptr %heap0, i64 5
  store i8 174, ptr %inline_array_slot9, align 1
  %inline_array_slot10 = getelementptr i8, ptr %heap0, i64 6
  store i8 210, ptr %inline_array_slot10, align 1
  %inline_array_slot11 = getelementptr i8, ptr %heap0, i64 7
  store i8 166, ptr %inline_array_slot11, align 1
  %inline_array_slot12 = getelementptr i8, ptr %heap0, i64 8
  store i8 171, ptr %inline_array_slot12, align 1
  %inline_array_slot13 = getelementptr i8, ptr %heap0, i64 9
  store i8 247, ptr %inline_array_slot13, align 1
  %inline_array_slot14 = getelementptr i8, ptr %heap0, i64 10
  store i8 21, ptr %inline_array_slot14, align 1
  %inline_array_slot15 = getelementptr i8, ptr %heap0, i64 11
  store i8 136, ptr %inline_array_slot15, align 1
  %inline_array_slot16 = getelementptr i8, ptr %heap0, i64 12
  store i8 9, ptr %inline_array_slot16, align 1
  %inline_array_slot17 = getelementptr i8, ptr %heap0, i64 13
  store i8 207, ptr %inline_array_slot17, align 1
  %inline_array_slot18 = getelementptr i8, ptr %heap0, i64 14
  store i8 79, ptr %inline_array_slot18, align 1
  %inline_array_slot19 = getelementptr i8, ptr %heap0, i64 15
  store i8 60, ptr %inline_array_slot19, align 1
  %slice_value20 = insertvalue %sollang.int_slice poison, ptr %heap0, 0
  %slice_value21 = insertvalue %sollang.int_slice %slice_value20, i64 16, 1
  ret %sollang.int_slice %slice_value21
}

define internal %sollang.int_slice @sollang_fn_zeroBlock(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) #0 {
entry:
  %trap_written3 = alloca i32, align 4
  %heap0 = call ptr @sollang_alloc(i64 16)
  %heap_ok1 = icmp ne ptr %heap0, null
  br i1 %heap_ok1, label %bb_alloc_ok0, label %bb_alloc_fail1

bb_alloc_fail1:
  %trap_stderr2 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr2, ptr @.slg.str.module.x.10, i32 28, ptr %trap_written3, ptr null)
  call void @llvm.trap()
  unreachable

bb_alloc_ok0:
  %inline_array_slot4 = getelementptr i8, ptr %heap0, i64 0
  store i8 0, ptr %inline_array_slot4, align 1
  %inline_array_slot5 = getelementptr i8, ptr %heap0, i64 1
  store i8 0, ptr %inline_array_slot5, align 1
  %inline_array_slot6 = getelementptr i8, ptr %heap0, i64 2
  store i8 0, ptr %inline_array_slot6, align 1
  %inline_array_slot7 = getelementptr i8, ptr %heap0, i64 3
  store i8 0, ptr %inline_array_slot7, align 1
  %inline_array_slot8 = getelementptr i8, ptr %heap0, i64 4
  store i8 0, ptr %inline_array_slot8, align 1
  %inline_array_slot9 = getelementptr i8, ptr %heap0, i64 5
  store i8 0, ptr %inline_array_slot9, align 1
  %inline_array_slot10 = getelementptr i8, ptr %heap0, i64 6
  store i8 0, ptr %inline_array_slot10, align 1
  %inline_array_slot11 = getelementptr i8, ptr %heap0, i64 7
  store i8 0, ptr %inline_array_slot11, align 1
  %inline_array_slot12 = getelementptr i8, ptr %heap0, i64 8
  store i8 0, ptr %inline_array_slot12, align 1
  %inline_array_slot13 = getelementptr i8, ptr %heap0, i64 9
  store i8 0, ptr %inline_array_slot13, align 1
  %inline_array_slot14 = getelementptr i8, ptr %heap0, i64 10
  store i8 0, ptr %inline_array_slot14, align 1
  %inline_array_slot15 = getelementptr i8, ptr %heap0, i64 11
  store i8 0, ptr %inline_array_slot15, align 1
  %inline_array_slot16 = getelementptr i8, ptr %heap0, i64 12
  store i8 0, ptr %inline_array_slot16, align 1
  %inline_array_slot17 = getelementptr i8, ptr %heap0, i64 13
  store i8 0, ptr %inline_array_slot17, align 1
  %inline_array_slot18 = getelementptr i8, ptr %heap0, i64 14
  store i8 0, ptr %inline_array_slot18, align 1
  %inline_array_slot19 = getelementptr i8, ptr %heap0, i64 15
  store i8 0, ptr %inline_array_slot19, align 1
  %slice_value20 = insertvalue %sollang.int_slice poison, ptr %heap0, 0
  %slice_value21 = insertvalue %sollang.int_slice %slice_value20, i64 16, 1
  ret %sollang.int_slice %slice_value21
}

@.slg.data.module.x7374642E63727970746F2E616573313238.0 = private unnamed_addr constant [256 x i8] [i8 99, i8 124, i8 119, i8 123, i8 242, i8 107, i8 111, i8 197, i8 48, i8 1, i8 103, i8 43, i8 254, i8 215, i8 171, i8 118, i8 202, i8 130, i8 201, i8 125, i8 250, i8 89, i8 71, i8 240, i8 173, i8 212, i8 162, i8 175, i8 156, i8 164, i8 114, i8 192, i8 183, i8 253, i8 147, i8 38, i8 54, i8 63, i8 247, i8 204, i8 52, i8 165, i8 229, i8 241, i8 113, i8 216, i8 49, i8 21, i8 4, i8 199, i8 35, i8 195, i8 24, i8 150, i8 5, i8 154, i8 7, i8 18, i8 128, i8 226, i8 235, i8 39, i8 178, i8 117, i8 9, i8 131, i8 44, i8 26, i8 27, i8 110, i8 90, i8 160, i8 82, i8 59, i8 214, i8 179, i8 41, i8 227, i8 47, i8 132, i8 83, i8 209, i8 0, i8 237, i8 32, i8 252, i8 177, i8 91, i8 106, i8 203, i8 190, i8 57, i8 74, i8 76, i8 88, i8 207, i8 208, i8 239, i8 170, i8 251, i8 67, i8 77, i8 51, i8 133, i8 69, i8 249, i8 2, i8 127, i8 80, i8 60, i8 159, i8 168, i8 81, i8 163, i8 64, i8 143, i8 146, i8 157, i8 56, i8 245, i8 188, i8 182, i8 218, i8 33, i8 16, i8 255, i8 243, i8 210, i8 205, i8 12, i8 19, i8 236, i8 95, i8 151, i8 68, i8 23, i8 196, i8 167, i8 126, i8 61, i8 100, i8 93, i8 25, i8 115, i8 96, i8 129, i8 79, i8 220, i8 34, i8 42, i8 144, i8 136, i8 70, i8 238, i8 184, i8 20, i8 222, i8 94, i8 11, i8 219, i8 224, i8 50, i8 58, i8 10, i8 73, i8 6, i8 36, i8 92, i8 194, i8 211, i8 172, i8 98, i8 145, i8 149, i8 228, i8 121, i8 231, i8 200, i8 55, i8 109, i8 141, i8 213, i8 78, i8 169, i8 108, i8 86, i8 244, i8 234, i8 101, i8 122, i8 174, i8 8, i8 186, i8 120, i8 37, i8 46, i8 28, i8 166, i8 180, i8 198, i8 232, i8 221, i8 116, i8 31, i8 75, i8 189, i8 139, i8 138, i8 112, i8 62, i8 181, i8 102, i8 72, i8 3, i8 246, i8 14, i8 97, i8 53, i8 87, i8 185, i8 134, i8 193, i8 29, i8 158, i8 225, i8 248, i8 152, i8 17, i8 105, i8 217, i8 142, i8 148, i8 155, i8 30, i8 135, i8 233, i8 206, i8 85, i8 40, i8 223, i8 140, i8 161, i8 137, i8 13, i8 191, i8 230, i8 66, i8 104, i8 65, i8 153, i8 45, i8 15, i8 176, i8 84, i8 187, i8 22], align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.0 = private unnamed_addr constant [63 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:allocation_failed", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.1 = private unnamed_addr constant [63 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:allocation_failed", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.2 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_inline_array_bounds_fail17", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.3 = private unnamed_addr constant [84 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_dynamic_inline_assign_bounds_fail19", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.4 = private unnamed_addr constant [63 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:allocation_failed", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.5 = private unnamed_addr constant [77 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_dynamic_inline_bounds_fail29", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.6 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_inline_array_assign_bounds_fail31", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.7 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_inline_array_bounds_fail35", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.8 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_inline_array_bounds_fail37", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.9 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_slice_bounds_fail39", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.10 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_inline_array_assign_bounds_fail41", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.11 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_inline_array_bounds_fail43", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.12 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_slice_bounds_fail45", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.13 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_inline_array_assign_bounds_fail47", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.14 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_inline_array_bounds_fail49", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.15 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_slice_bounds_fail51", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.16 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_inline_array_assign_bounds_fail53", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.17 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_slice_bounds_fail55", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.18 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_inline_array_assign_bounds_fail57", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.19 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_inline_array_bounds_fail59", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.20 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_slice_bounds_fail61", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.21 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.22 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_inline_array_assign_bounds_fail72", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.23 = private unnamed_addr constant [77 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_dynamic_inline_bounds_fail77", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.24 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_inline_array_bounds_fail79", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.25 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.26 = private unnamed_addr constant [84 x i8] c"std.crypto.aes128.std.crypto.aes128.expandKey:bb_dynamic_inline_assign_bounds_fail90", align 1
@.slg.data.module.x7374642E63727970746F2E616573313238.1 = private unnamed_addr constant [10 x i8] [i8 1, i8 2, i8 4, i8 8, i8 16, i8 32, i8 64, i8 128, i8 27, i8 54], align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.27 = private unnamed_addr constant [70 x i8] c"std.crypto.aes128.std.crypto.aes128.Key.encryptBlock:allocation_failed", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.28 = private unnamed_addr constant [81 x i8] c"std.crypto.aes128.std.crypto.aes128.Key.encryptBlock:bb_inline_array_bounds_fail6", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.29 = private unnamed_addr constant [88 x i8] c"std.crypto.aes128.std.crypto.aes128.Key.encryptBlock:bb_inline_array_assign_bounds_fail8", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.30 = private unnamed_addr constant [77 x i8] c"std.crypto.aes128.std.crypto.aes128.addRoundKey:bb_inline_array_bounds_fail13", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.31 = private unnamed_addr constant [70 x i8] c"std.crypto.aes128.std.crypto.aes128.addRoundKey:bb_slice_bounds_fail15", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.32 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.33 = private unnamed_addr constant [84 x i8] c"std.crypto.aes128.std.crypto.aes128.addRoundKey:bb_inline_array_assign_bounds_fail26", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.34 = private unnamed_addr constant [74 x i8] c"std.crypto.aes128.std.crypto.aes128.subBytes:bb_inline_array_bounds_fail34", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.35 = private unnamed_addr constant [67 x i8] c"std.crypto.aes128.std.crypto.aes128.subBytes:bb_slice_bounds_fail36", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.36 = private unnamed_addr constant [81 x i8] c"std.crypto.aes128.std.crypto.aes128.subBytes:bb_inline_array_assign_bounds_fail38", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.37 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail40", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.38 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail42", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.39 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail44", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.40 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail46", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.41 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail48", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.42 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail50", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.43 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail52", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.44 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail54", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.45 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail56", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.46 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail58", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.47 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail60", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.48 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail62", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.49 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail64", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.50 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail66", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.51 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail68", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.52 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail70", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.53 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail72", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.54 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail74", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.55 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail76", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.56 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail78", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.57 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail80", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.58 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail82", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.59 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail84", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.60 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail86", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.61 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.mixColumns:bb_inline_array_bounds_fail91", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.62 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.mixColumns:bb_inline_array_bounds_fail93", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.63 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.mixColumns:bb_inline_array_bounds_fail95", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.64 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.mixColumns:bb_inline_array_bounds_fail97", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.65 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.66 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.67 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.68 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.69 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.70 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.71 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.72 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.73 = private unnamed_addr constant [84 x i8] c"std.crypto.aes128.std.crypto.aes128.mixColumns:bb_inline_array_assign_bounds_fail163", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.74 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.75 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.76 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.77 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.78 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.79 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.80 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.81 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.82 = private unnamed_addr constant [84 x i8] c"std.crypto.aes128.std.crypto.aes128.mixColumns:bb_inline_array_assign_bounds_fail229", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.83 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.84 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.85 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.86 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.87 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.88 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.89 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.90 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.91 = private unnamed_addr constant [84 x i8] c"std.crypto.aes128.std.crypto.aes128.mixColumns:bb_inline_array_assign_bounds_fail295", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.92 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.93 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.94 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.95 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.96 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.97 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.98 = private unnamed_addr constant [66 x i8] c"std.crypto.aes128.std.crypto.aes128.xtime:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.99 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.100 = private unnamed_addr constant [84 x i8] c"std.crypto.aes128.std.crypto.aes128.mixColumns:bb_inline_array_assign_bounds_fail361", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.101 = private unnamed_addr constant [78 x i8] c"std.crypto.aes128.std.crypto.aes128.addRoundKey:bb_inline_array_bounds_fail366", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.102 = private unnamed_addr constant [71 x i8] c"std.crypto.aes128.std.crypto.aes128.addRoundKey:bb_slice_bounds_fail368", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.103 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.104 = private unnamed_addr constant [85 x i8] c"std.crypto.aes128.std.crypto.aes128.addRoundKey:bb_inline_array_assign_bounds_fail379", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.105 = private unnamed_addr constant [75 x i8] c"std.crypto.aes128.std.crypto.aes128.subBytes:bb_inline_array_bounds_fail384", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.106 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.subBytes:bb_slice_bounds_fail386", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.107 = private unnamed_addr constant [82 x i8] c"std.crypto.aes128.std.crypto.aes128.subBytes:bb_inline_array_assign_bounds_fail388", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.108 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail390", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.109 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail392", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.110 = private unnamed_addr constant [83 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail394", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.111 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail396", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.112 = private unnamed_addr constant [83 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail398", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.113 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail400", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.114 = private unnamed_addr constant [83 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail402", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.115 = private unnamed_addr constant [83 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail404", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.116 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail406", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.117 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail408", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.118 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail410", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.119 = private unnamed_addr constant [83 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail412", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.120 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail414", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.121 = private unnamed_addr constant [83 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail416", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.122 = private unnamed_addr constant [83 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail418", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.123 = private unnamed_addr constant [83 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail420", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.124 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail422", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.125 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail424", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.126 = private unnamed_addr constant [83 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail426", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.127 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail428", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.128 = private unnamed_addr constant [83 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail430", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.129 = private unnamed_addr constant [76 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_bounds_fail432", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.130 = private unnamed_addr constant [83 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail434", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.131 = private unnamed_addr constant [83 x i8] c"std.crypto.aes128.std.crypto.aes128.shiftRows:bb_inline_array_assign_bounds_fail436", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.132 = private unnamed_addr constant [78 x i8] c"std.crypto.aes128.std.crypto.aes128.addRoundKey:bb_inline_array_bounds_fail441", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.133 = private unnamed_addr constant [71 x i8] c"std.crypto.aes128.std.crypto.aes128.addRoundKey:bb_slice_bounds_fail443", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.134 = private unnamed_addr constant [68 x i8] c"std.crypto.aes128.std.crypto.aes128.xorByte:numeric_conversion_upper", align 1
@.slg.str.module.x7374642E63727970746F2E616573313238.135 = private unnamed_addr constant [85 x i8] c"std.crypto.aes128.std.crypto.aes128.addRoundKey:bb_inline_array_assign_bounds_fail454", align 1
define internal %sollang.int_slice @sollang_fn_std_crypto_aes128_sbox(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) #0 {
entry:
  %slice_value0 = insertvalue %sollang.int_slice poison, ptr @.slg.data.module.x7374642E63727970746F2E616573313238.0, 0
  %slice_value1 = insertvalue %sollang.int_slice %slice_value0, i64 256, 1
  ret %sollang.int_slice %slice_value1
}

define internal %sollang.dynamic_int_array @sollang_fn_std_crypto_aes128_expandKey(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.int_slice %it) #0 {
entry:
  %trap_written5 = alloca i32, align 4
  %mutable_ptr_addr6 = alloca ptr, align 8
  %mutable_len_addr7 = alloca i64, align 8
  %mutable_capacity_addr8 = alloca i64, align 8
  %mutable_scalar_slot9 = alloca i32, align 4
  %trap_written25 = alloca i32, align 4
  %mutable_scalar_slot39 = alloca i32, align 4
  %trap_written49 = alloca i32, align 4
  %trap_written56 = alloca i32, align 4
  %mutable_scalar_slot60 = alloca i32, align 4
  %mutable_scalar_slot61 = alloca i32, align 4
  %trap_written65 = alloca i32, align 4
  %mutable_ptr_addr70 = alloca ptr, align 8
  %mutable_len_addr71 = alloca i64, align 8
  %mutable_capacity_addr72 = alloca i64, align 8
  %mutable_scalar_slot75 = alloca i32, align 4
  %trap_written91 = alloca i32, align 4
  %trap_written98 = alloca i32, align 4
  %trap_written111 = alloca i32, align 4
  %trap_written126 = alloca i32, align 4
  %trap_written133 = alloca i32, align 4
  %trap_written139 = alloca i32, align 4
  %trap_written153 = alloca i32, align 4
  %trap_written160 = alloca i32, align 4
  %trap_written166 = alloca i32, align 4
  %trap_written180 = alloca i32, align 4
  %trap_written187 = alloca i32, align 4
  %trap_written193 = alloca i32, align 4
  %trap_written205 = alloca i32, align 4
  %trap_written211 = alloca i32, align 4
  %trap_written222 = alloca i32, align 4
  %trap_written232 = alloca i32, align 4
  %mutable_scalar_slot237 = alloca i32, align 4
  %mutable_scalar_slot238 = alloca i32, align 4
  %mutable_scalar_slot239 = alloca i32, align 4
  %trap_written261 = alloca i32, align 4
  %trap_written266 = alloca i32, align 4
  %mutable_scalar_slot270 = alloca i32, align 4
  %trap_written284 = alloca i32, align 4
  %trap_written294 = alloca i32, align 4
  %mutable_scalar_slot299 = alloca i32, align 4
  %mutable_scalar_slot300 = alloca i32, align 4
  %mutable_scalar_slot301 = alloca i32, align 4
  %trap_written323 = alloca i32, align 4
  %trap_written329 = alloca i32, align 4
  %param_fixed_ptr0 = extractvalue %sollang.int_slice %it, 0
  %param_fixed_len1 = extractvalue %sollang.int_slice %it, 1
  %heap2 = call ptr @sollang_alloc(i64 176)
  %heap_ok3 = icmp ne ptr %heap2, null
  br i1 %heap_ok3, label %bb_alloc_ok0, label %bb_alloc_fail1

bb_alloc_fail1:
  %trap_stderr4 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr4, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.0, i32 63, ptr %trap_written5, ptr null)
  call void @llvm.trap()
  unreachable

bb_alloc_ok0:
  store ptr %heap2, ptr %mutable_ptr_addr6, align 8
  store i64 0, ptr %mutable_len_addr7, align 8
  store i64 176, ptr %mutable_capacity_addr8, align 8
  store i32 0, ptr %mutable_scalar_slot9, align 4
  br label %bb_while_condition2
bb_while_condition2:
  %mutable_scalar10 = load i32, ptr %mutable_scalar_slot9, align 4
  %cmp11 = icmp slt i32 %mutable_scalar10, 176
  br i1 %cmp11, label %bb_while_body3, label %bb_while_end4
bb_while_body3:
  %mutable_ptr12 = load ptr, ptr %mutable_ptr_addr6, align 8
  %mutable_len13 = load i64, ptr %mutable_len_addr7, align 8
  %mutable_capacity14 = load i64, ptr %mutable_capacity_addr8, align 8
  %generic_array_has_capacity15 = icmp ult i64 %mutable_len13, %mutable_capacity14
  br i1 %generic_array_has_capacity15, label %bb_generic_array_push_append5, label %bb_generic_array_push_grow6

bb_generic_array_push_append5:
  %dynamic_inline_slot16 = getelementptr i8, ptr %mutable_ptr12, i64 %mutable_len13
  store i8 0, ptr %dynamic_inline_slot16, align 1
  %generic_array_next_len17 = add i64 %mutable_len13, 1
  br label %bb_generic_array_push_done7

bb_generic_array_push_grow6:
  %generic_array_empty18 = icmp eq i64 %mutable_capacity14, 0
  %generic_array_doubled19 = mul i64 %mutable_capacity14, 2
  %generic_array_new_capacity20 = select i1 %generic_array_empty18, i64 4, i64 %generic_array_doubled19
  %generic_array_new_bytes21 = mul i64 %generic_array_new_capacity20, 1
  %heap22 = call ptr @sollang_alloc(i64 %generic_array_new_bytes21)
  %heap_ok23 = icmp ne ptr %heap22, null
  br i1 %heap_ok23, label %bb_alloc_ok8, label %bb_alloc_fail9

bb_alloc_fail9:
  %trap_stderr24 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr24, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.1, i32 63, ptr %trap_written25, ptr null)
  call void @llvm.trap()
  unreachable

bb_alloc_ok8:
  br label %bb_generic_array_copy10

bb_generic_array_copy10:
  %generic_array_copy_i27 = phi i64 [ 0, %bb_alloc_ok8 ], [ %generic_array_copy_next_i26, %bb_generic_array_copy_body11 ]
  %generic_array_copy_active28 = icmp ult i64 %generic_array_copy_i27, %mutable_len13
  br i1 %generic_array_copy_active28, label %bb_generic_array_copy_body11, label %bb_generic_array_copy_done12

bb_generic_array_copy_body11:
  %generic_array_copy_src29 = getelementptr i8, ptr %mutable_ptr12, i64 %generic_array_copy_i27
  %generic_array_copy_dst30 = getelementptr i8, ptr %heap22, i64 %generic_array_copy_i27
  %generic_array_copy_value31 = load i8, ptr %generic_array_copy_src29, align 1
  store i8 %generic_array_copy_value31, ptr %generic_array_copy_dst30, align 1
  %generic_array_copy_next_i26 = add i64 %generic_array_copy_i27, 1
  br label %bb_generic_array_copy10

bb_generic_array_copy_done12:
  call void @sollang_free(ptr %mutable_ptr12)
  %dynamic_inline_slot32 = getelementptr i8, ptr %heap22, i64 %mutable_len13
  store i8 0, ptr %dynamic_inline_slot32, align 1
  %generic_array_next_len33 = add i64 %mutable_len13, 1
  br label %bb_generic_array_push_done7

bb_generic_array_push_done7:
  %generic_array_ptr34 = phi ptr [ %mutable_ptr12, %bb_generic_array_push_append5 ], [ %heap22, %bb_generic_array_copy_done12 ]
  %generic_array_len35 = phi i64 [ %generic_array_next_len17, %bb_generic_array_push_append5 ], [ %generic_array_next_len33, %bb_generic_array_copy_done12 ]
  %generic_array_capacity36 = phi i64 [ %mutable_capacity14, %bb_generic_array_push_append5 ], [ %generic_array_new_capacity20, %bb_generic_array_copy_done12 ]
  store ptr %generic_array_ptr34, ptr %mutable_ptr_addr6, align 8
  store i64 %generic_array_len35, ptr %mutable_len_addr7, align 8
  store i64 %generic_array_capacity36, ptr %mutable_capacity_addr8, align 8
  %mutable_scalar37 = load i32, ptr %mutable_scalar_slot9, align 4
  %add38 = add i32 %mutable_scalar37, 1
  store i32 %add38, ptr %mutable_scalar_slot9, align 4
  br label %bb_while_condition2
bb_while_end4:
  store i32 0, ptr %mutable_scalar_slot39, align 4
  br label %bb_while_condition13
bb_while_condition13:
  %mutable_scalar40 = load i32, ptr %mutable_scalar_slot39, align 4
  %cmp41 = icmp slt i32 %mutable_scalar40, 16
  br i1 %cmp41, label %bb_while_body14, label %bb_while_end15
bb_while_body14:
  %mutable_ptr42 = load ptr, ptr %mutable_ptr_addr6, align 8
  %mutable_len43 = load i64, ptr %mutable_len_addr7, align 8
  %mutable_capacity44 = load i64, ptr %mutable_capacity_addr8, align 8
  %mutable_scalar45 = load i32, ptr %mutable_scalar_slot39, align 4
  %index_size46 = sext i32 %mutable_scalar45 to i64
  %inline_array_in_bounds47 = icmp ult i64 %index_size46, %param_fixed_len1
  br i1 %inline_array_in_bounds47, label %bb_inline_array_bounds_ok16, label %bb_inline_array_bounds_fail17

bb_inline_array_bounds_fail17:
  %trap_stderr48 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr48, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.2, i32 75, ptr %trap_written49, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok16:
  %inline_array_slot50 = getelementptr i8, ptr %param_fixed_ptr0, i64 %index_size46
  %inline_array_item51 = load i8, ptr %inline_array_slot50, align 1
  %mutable_scalar52 = load i32, ptr %mutable_scalar_slot39, align 4
  %assignment_index53 = sext i32 %mutable_scalar52 to i64
  %dynamic_inline_assign_in_bounds54 = icmp ult i64 %assignment_index53, %mutable_len43
  br i1 %dynamic_inline_assign_in_bounds54, label %bb_dynamic_inline_assign_bounds_ok18, label %bb_dynamic_inline_assign_bounds_fail19

bb_dynamic_inline_assign_bounds_fail19:
  %trap_stderr55 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr55, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.3, i32 84, ptr %trap_written56, ptr null)
  call void @llvm.trap()
  unreachable

bb_dynamic_inline_assign_bounds_ok18:
  %dynamic_inline_assign_slot57 = getelementptr i8, ptr %mutable_ptr42, i64 %assignment_index53
  store i8 %inline_array_item51, ptr %dynamic_inline_assign_slot57, align 1
  %mutable_scalar58 = load i32, ptr %mutable_scalar_slot39, align 4
  %add59 = add i32 %mutable_scalar58, 1
  store i32 %add59, ptr %mutable_scalar_slot39, align 4
  br label %bb_while_condition13
bb_while_end15:
  store i32 16, ptr %mutable_scalar_slot60, align 4
  store i32 0, ptr %mutable_scalar_slot61, align 4
  %heap62 = call ptr @sollang_alloc(i64 4)
  %heap_ok63 = icmp ne ptr %heap62, null
  br i1 %heap_ok63, label %bb_alloc_ok20, label %bb_alloc_fail21

bb_alloc_fail21:
  %trap_stderr64 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr64, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.4, i32 63, ptr %trap_written65, ptr null)
  call void @llvm.trap()
  unreachable

bb_alloc_ok20:
  %inline_array_slot66 = getelementptr i8, ptr %heap62, i64 0
  store i8 0, ptr %inline_array_slot66, align 1
  %inline_array_slot67 = getelementptr i8, ptr %heap62, i64 1
  store i8 0, ptr %inline_array_slot67, align 1
  %inline_array_slot68 = getelementptr i8, ptr %heap62, i64 2
  store i8 0, ptr %inline_array_slot68, align 1
  %inline_array_slot69 = getelementptr i8, ptr %heap62, i64 3
  store i8 0, ptr %inline_array_slot69, align 1
  store ptr %heap62, ptr %mutable_ptr_addr70, align 8
  store i64 4, ptr %mutable_len_addr71, align 8
  store i64 4, ptr %mutable_capacity_addr72, align 8
  br label %bb_while_condition22
bb_while_condition22:
  %mutable_scalar73 = load i32, ptr %mutable_scalar_slot60, align 4
  %cmp74 = icmp slt i32 %mutable_scalar73, 176
  br i1 %cmp74, label %bb_while_body23, label %bb_while_end24
bb_while_body23:
  store i32 0, ptr %mutable_scalar_slot75, align 4
  br label %bb_while_condition25
bb_while_condition25:
  %mutable_scalar76 = load i32, ptr %mutable_scalar_slot75, align 4
  %cmp77 = icmp slt i32 %mutable_scalar76, 4
  br i1 %cmp77, label %bb_while_body26, label %bb_while_end27
bb_while_body26:
  %mutable_ptr78 = load ptr, ptr %mutable_ptr_addr70, align 8
  %mutable_len79 = load i64, ptr %mutable_len_addr71, align 8
  %mutable_capacity80 = load i64, ptr %mutable_capacity_addr72, align 8
  %mutable_ptr81 = load ptr, ptr %mutable_ptr_addr6, align 8
  %mutable_len82 = load i64, ptr %mutable_len_addr7, align 8
  %mutable_capacity83 = load i64, ptr %mutable_capacity_addr8, align 8
  %mutable_scalar84 = load i32, ptr %mutable_scalar_slot60, align 4
  %sub85 = sub i32 %mutable_scalar84, 4
  %mutable_scalar86 = load i32, ptr %mutable_scalar_slot75, align 4
  %add87 = add i32 %sub85, %mutable_scalar86
  %index_size88 = sext i32 %add87 to i64
  %dynamic_inline_in_bounds89 = icmp ult i64 %index_size88, %mutable_len82
  br i1 %dynamic_inline_in_bounds89, label %bb_dynamic_inline_bounds_ok28, label %bb_dynamic_inline_bounds_fail29

bb_dynamic_inline_bounds_fail29:
  %trap_stderr90 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr90, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.5, i32 77, ptr %trap_written91, ptr null)
  call void @llvm.trap()
  unreachable

bb_dynamic_inline_bounds_ok28:
  %dynamic_inline_slot92 = getelementptr i8, ptr %mutable_ptr81, i64 %index_size88
  %dynamic_inline_item93 = load i8, ptr %dynamic_inline_slot92, align 1
  %mutable_scalar94 = load i32, ptr %mutable_scalar_slot75, align 4
  %assignment_index95 = sext i32 %mutable_scalar94 to i64
  %inline_array_assign_in_bounds96 = icmp ult i64 %assignment_index95, %mutable_len79
  br i1 %inline_array_assign_in_bounds96, label %bb_inline_array_assign_bounds_ok30, label %bb_inline_array_assign_bounds_fail31

bb_inline_array_assign_bounds_fail31:
  %trap_stderr97 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr97, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.6, i32 82, ptr %trap_written98, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok30:
  %inline_array_assign_slot99 = getelementptr i8, ptr %mutable_ptr78, i64 %assignment_index95
  store i8 %dynamic_inline_item93, ptr %inline_array_assign_slot99, align 1
  %mutable_scalar100 = load i32, ptr %mutable_scalar_slot75, align 4
  %add101 = add i32 %mutable_scalar100, 1
  store i32 %add101, ptr %mutable_scalar_slot75, align 4
  br label %bb_while_condition25
bb_while_end27:
  %mutable_scalar102 = load i32, ptr %mutable_scalar_slot60, align 4
  %mod103 = srem i32 %mutable_scalar102, 16
  %cmp104 = icmp eq i32 %mod103, 0
  br i1 %cmp104, label %bb_if_then32, label %bb_if_end33
bb_if_then32:
  %mutable_ptr105 = load ptr, ptr %mutable_ptr_addr70, align 8
  %mutable_len106 = load i64, ptr %mutable_len_addr71, align 8
  %mutable_capacity107 = load i64, ptr %mutable_capacity_addr72, align 8
  %index_size108 = sext i32 0 to i64
  %inline_array_in_bounds109 = icmp ult i64 %index_size108, %mutable_len106
  br i1 %inline_array_in_bounds109, label %bb_inline_array_bounds_ok34, label %bb_inline_array_bounds_fail35

bb_inline_array_bounds_fail35:
  %trap_stderr110 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr110, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.7, i32 75, ptr %trap_written111, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok34:
  %inline_array_slot112 = getelementptr i8, ptr %mutable_ptr105, i64 %index_size108
  %inline_array_item113 = load i8, ptr %inline_array_slot112, align 1
  %mutable_ptr114 = load ptr, ptr %mutable_ptr_addr70, align 8
  %mutable_len115 = load i64, ptr %mutable_len_addr71, align 8
  %mutable_capacity116 = load i64, ptr %mutable_capacity_addr72, align 8
  %struct_call117 = call %sollang.int_slice @sollang_fn_std_crypto_aes128_sbox(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %slice_ptr118 = extractvalue %sollang.int_slice %struct_call117, 0
  %slice_len119 = extractvalue %sollang.int_slice %struct_call117, 1
  %mutable_ptr120 = load ptr, ptr %mutable_ptr_addr70, align 8
  %mutable_len121 = load i64, ptr %mutable_len_addr71, align 8
  %mutable_capacity122 = load i64, ptr %mutable_capacity_addr72, align 8
  %index_size123 = sext i32 1 to i64
  %inline_array_in_bounds124 = icmp ult i64 %index_size123, %mutable_len121
  br i1 %inline_array_in_bounds124, label %bb_inline_array_bounds_ok36, label %bb_inline_array_bounds_fail37

bb_inline_array_bounds_fail37:
  %trap_stderr125 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr125, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.8, i32 75, ptr %trap_written126, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok36:
  %inline_array_slot127 = getelementptr i8, ptr %mutable_ptr120, i64 %index_size123
  %inline_array_item128 = load i8, ptr %inline_array_slot127, align 1
  %numeric_convert129 = zext i8 %inline_array_item128 to i32
  %index_size130 = sext i32 %numeric_convert129 to i64
  %slice_in_bounds131 = icmp ult i64 %index_size130, %slice_len119
  br i1 %slice_in_bounds131, label %bb_slice_bounds_ok38, label %bb_slice_bounds_fail39

bb_slice_bounds_fail39:
  %trap_stderr132 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr132, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.9, i32 68, ptr %trap_written133, ptr null)
  call void @llvm.trap()
  unreachable

bb_slice_bounds_ok38:
  %slice_slot134 = getelementptr i8, ptr %slice_ptr118, i64 %index_size130
  %slice_item135 = load i8, ptr %slice_slot134, align 1
  %assignment_index136 = sext i32 0 to i64
  %inline_array_assign_in_bounds137 = icmp ult i64 %assignment_index136, %mutable_len115
  br i1 %inline_array_assign_in_bounds137, label %bb_inline_array_assign_bounds_ok40, label %bb_inline_array_assign_bounds_fail41

bb_inline_array_assign_bounds_fail41:
  %trap_stderr138 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr138, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.10, i32 82, ptr %trap_written139, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok40:
  %inline_array_assign_slot140 = getelementptr i8, ptr %mutable_ptr114, i64 %assignment_index136
  store i8 %slice_item135, ptr %inline_array_assign_slot140, align 1
  %mutable_ptr141 = load ptr, ptr %mutable_ptr_addr70, align 8
  %mutable_len142 = load i64, ptr %mutable_len_addr71, align 8
  %mutable_capacity143 = load i64, ptr %mutable_capacity_addr72, align 8
  %struct_call144 = call %sollang.int_slice @sollang_fn_std_crypto_aes128_sbox(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %slice_ptr145 = extractvalue %sollang.int_slice %struct_call144, 0
  %slice_len146 = extractvalue %sollang.int_slice %struct_call144, 1
  %mutable_ptr147 = load ptr, ptr %mutable_ptr_addr70, align 8
  %mutable_len148 = load i64, ptr %mutable_len_addr71, align 8
  %mutable_capacity149 = load i64, ptr %mutable_capacity_addr72, align 8
  %index_size150 = sext i32 2 to i64
  %inline_array_in_bounds151 = icmp ult i64 %index_size150, %mutable_len148
  br i1 %inline_array_in_bounds151, label %bb_inline_array_bounds_ok42, label %bb_inline_array_bounds_fail43

bb_inline_array_bounds_fail43:
  %trap_stderr152 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr152, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.11, i32 75, ptr %trap_written153, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok42:
  %inline_array_slot154 = getelementptr i8, ptr %mutable_ptr147, i64 %index_size150
  %inline_array_item155 = load i8, ptr %inline_array_slot154, align 1
  %numeric_convert156 = zext i8 %inline_array_item155 to i32
  %index_size157 = sext i32 %numeric_convert156 to i64
  %slice_in_bounds158 = icmp ult i64 %index_size157, %slice_len146
  br i1 %slice_in_bounds158, label %bb_slice_bounds_ok44, label %bb_slice_bounds_fail45

bb_slice_bounds_fail45:
  %trap_stderr159 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr159, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.12, i32 68, ptr %trap_written160, ptr null)
  call void @llvm.trap()
  unreachable

bb_slice_bounds_ok44:
  %slice_slot161 = getelementptr i8, ptr %slice_ptr145, i64 %index_size157
  %slice_item162 = load i8, ptr %slice_slot161, align 1
  %assignment_index163 = sext i32 1 to i64
  %inline_array_assign_in_bounds164 = icmp ult i64 %assignment_index163, %mutable_len142
  br i1 %inline_array_assign_in_bounds164, label %bb_inline_array_assign_bounds_ok46, label %bb_inline_array_assign_bounds_fail47

bb_inline_array_assign_bounds_fail47:
  %trap_stderr165 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr165, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.13, i32 82, ptr %trap_written166, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok46:
  %inline_array_assign_slot167 = getelementptr i8, ptr %mutable_ptr141, i64 %assignment_index163
  store i8 %slice_item162, ptr %inline_array_assign_slot167, align 1
  %mutable_ptr168 = load ptr, ptr %mutable_ptr_addr70, align 8
  %mutable_len169 = load i64, ptr %mutable_len_addr71, align 8
  %mutable_capacity170 = load i64, ptr %mutable_capacity_addr72, align 8
  %struct_call171 = call %sollang.int_slice @sollang_fn_std_crypto_aes128_sbox(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %slice_ptr172 = extractvalue %sollang.int_slice %struct_call171, 0
  %slice_len173 = extractvalue %sollang.int_slice %struct_call171, 1
  %mutable_ptr174 = load ptr, ptr %mutable_ptr_addr70, align 8
  %mutable_len175 = load i64, ptr %mutable_len_addr71, align 8
  %mutable_capacity176 = load i64, ptr %mutable_capacity_addr72, align 8
  %index_size177 = sext i32 3 to i64
  %inline_array_in_bounds178 = icmp ult i64 %index_size177, %mutable_len175
  br i1 %inline_array_in_bounds178, label %bb_inline_array_bounds_ok48, label %bb_inline_array_bounds_fail49

bb_inline_array_bounds_fail49:
  %trap_stderr179 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr179, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.14, i32 75, ptr %trap_written180, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok48:
  %inline_array_slot181 = getelementptr i8, ptr %mutable_ptr174, i64 %index_size177
  %inline_array_item182 = load i8, ptr %inline_array_slot181, align 1
  %numeric_convert183 = zext i8 %inline_array_item182 to i32
  %index_size184 = sext i32 %numeric_convert183 to i64
  %slice_in_bounds185 = icmp ult i64 %index_size184, %slice_len173
  br i1 %slice_in_bounds185, label %bb_slice_bounds_ok50, label %bb_slice_bounds_fail51

bb_slice_bounds_fail51:
  %trap_stderr186 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr186, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.15, i32 68, ptr %trap_written187, ptr null)
  call void @llvm.trap()
  unreachable

bb_slice_bounds_ok50:
  %slice_slot188 = getelementptr i8, ptr %slice_ptr172, i64 %index_size184
  %slice_item189 = load i8, ptr %slice_slot188, align 1
  %assignment_index190 = sext i32 2 to i64
  %inline_array_assign_in_bounds191 = icmp ult i64 %assignment_index190, %mutable_len169
  br i1 %inline_array_assign_in_bounds191, label %bb_inline_array_assign_bounds_ok52, label %bb_inline_array_assign_bounds_fail53

bb_inline_array_assign_bounds_fail53:
  %trap_stderr192 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr192, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.16, i32 82, ptr %trap_written193, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok52:
  %inline_array_assign_slot194 = getelementptr i8, ptr %mutable_ptr168, i64 %assignment_index190
  store i8 %slice_item189, ptr %inline_array_assign_slot194, align 1
  %mutable_ptr195 = load ptr, ptr %mutable_ptr_addr70, align 8
  %mutable_len196 = load i64, ptr %mutable_len_addr71, align 8
  %mutable_capacity197 = load i64, ptr %mutable_capacity_addr72, align 8
  %struct_call198 = call %sollang.int_slice @sollang_fn_std_crypto_aes128_sbox(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %slice_ptr199 = extractvalue %sollang.int_slice %struct_call198, 0
  %slice_len200 = extractvalue %sollang.int_slice %struct_call198, 1
  %numeric_convert201 = zext i8 %inline_array_item113 to i32
  %index_size202 = sext i32 %numeric_convert201 to i64
  %slice_in_bounds203 = icmp ult i64 %index_size202, %slice_len200
  br i1 %slice_in_bounds203, label %bb_slice_bounds_ok54, label %bb_slice_bounds_fail55

bb_slice_bounds_fail55:
  %trap_stderr204 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr204, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.17, i32 68, ptr %trap_written205, ptr null)
  call void @llvm.trap()
  unreachable

bb_slice_bounds_ok54:
  %slice_slot206 = getelementptr i8, ptr %slice_ptr199, i64 %index_size202
  %slice_item207 = load i8, ptr %slice_slot206, align 1
  %assignment_index208 = sext i32 3 to i64
  %inline_array_assign_in_bounds209 = icmp ult i64 %assignment_index208, %mutable_len196
  br i1 %inline_array_assign_in_bounds209, label %bb_inline_array_assign_bounds_ok56, label %bb_inline_array_assign_bounds_fail57

bb_inline_array_assign_bounds_fail57:
  %trap_stderr210 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr210, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.18, i32 82, ptr %trap_written211, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok56:
  %inline_array_assign_slot212 = getelementptr i8, ptr %mutable_ptr195, i64 %assignment_index208
  store i8 %slice_item207, ptr %inline_array_assign_slot212, align 1
  %mutable_ptr213 = load ptr, ptr %mutable_ptr_addr70, align 8
  %mutable_len214 = load i64, ptr %mutable_len_addr71, align 8
  %mutable_capacity215 = load i64, ptr %mutable_capacity_addr72, align 8
  %mutable_ptr216 = load ptr, ptr %mutable_ptr_addr70, align 8
  %mutable_len217 = load i64, ptr %mutable_len_addr71, align 8
  %mutable_capacity218 = load i64, ptr %mutable_capacity_addr72, align 8
  %index_size219 = sext i32 0 to i64
  %inline_array_in_bounds220 = icmp ult i64 %index_size219, %mutable_len217
  br i1 %inline_array_in_bounds220, label %bb_inline_array_bounds_ok58, label %bb_inline_array_bounds_fail59

bb_inline_array_bounds_fail59:
  %trap_stderr221 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr221, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.19, i32 75, ptr %trap_written222, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok58:
  %inline_array_slot223 = getelementptr i8, ptr %mutable_ptr216, i64 %index_size219
  %inline_array_item224 = load i8, ptr %inline_array_slot223, align 1
  %struct_call225 = call %sollang.int_slice @sollang_fn_std_crypto_aes128_roundConstants(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %slice_ptr226 = extractvalue %sollang.int_slice %struct_call225, 0
  %slice_len227 = extractvalue %sollang.int_slice %struct_call225, 1
  %mutable_scalar228 = load i32, ptr %mutable_scalar_slot61, align 4
  %index_size229 = sext i32 %mutable_scalar228 to i64
  %slice_in_bounds230 = icmp ult i64 %index_size229, %slice_len227
  br i1 %slice_in_bounds230, label %bb_slice_bounds_ok60, label %bb_slice_bounds_fail61

bb_slice_bounds_fail61:
  %trap_stderr231 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr231, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.20, i32 68, ptr %trap_written232, ptr null)
  call void @llvm.trap()
  unreachable

bb_slice_bounds_ok60:
  %slice_slot233 = getelementptr i8, ptr %slice_ptr226, i64 %index_size229
  %slice_item234 = load i8, ptr %slice_slot233, align 1
  %numeric_convert235 = zext i8 %inline_array_item224 to i32
  %numeric_convert236 = zext i8 %slice_item234 to i32
  store i32 0, ptr %mutable_scalar_slot237, align 4
  store i32 1, ptr %mutable_scalar_slot238, align 4
  store i32 0, ptr %mutable_scalar_slot239, align 4
  br label %bb_while_condition62
bb_while_condition62:
  %mutable_scalar240 = load i32, ptr %mutable_scalar_slot239, align 4
  %cmp241 = icmp ult i32 %mutable_scalar240, 32
  br i1 %cmp241, label %bb_while_body63, label %bb_while_end64
bb_while_body63:
  %mutable_scalar242 = load i32, ptr %mutable_scalar_slot238, align 4
  %div243 = udiv i32 %numeric_convert235, %mutable_scalar242
  %mod244 = urem i32 %div243, 2
  %mutable_scalar245 = load i32, ptr %mutable_scalar_slot238, align 4
  %div246 = udiv i32 %numeric_convert236, %mutable_scalar245
  %mod247 = urem i32 %div246, 2
  %cmp248 = icmp ne i32 %mod244, %mod247
  br i1 %cmp248, label %bb_if_then65, label %bb_if_end66
bb_if_then65:
  %mutable_scalar249 = load i32, ptr %mutable_scalar_slot237, align 4
  %mutable_scalar250 = load i32, ptr %mutable_scalar_slot238, align 4
  %add251 = add i32 %mutable_scalar249, %mutable_scalar250
  store i32 %add251, ptr %mutable_scalar_slot237, align 4
  br label %bb_if_end66
bb_if_end66:
  %mutable_scalar252 = load i32, ptr %mutable_scalar_slot239, align 4
  %add253 = add i32 %mutable_scalar252, 1
  store i32 %add253, ptr %mutable_scalar_slot239, align 4
  %mutable_scalar254 = load i32, ptr %mutable_scalar_slot239, align 4
  %cmp255 = icmp ult i32 %mutable_scalar254, 32
  br i1 %cmp255, label %bb_if_then67, label %bb_if_end68
bb_if_then67:
  %mutable_scalar256 = load i32, ptr %mutable_scalar_slot238, align 4
  %mul257 = mul i32 %mutable_scalar256, 2
  store i32 %mul257, ptr %mutable_scalar_slot238, align 4
  br label %bb_if_end68
bb_if_end68:
  br label %bb_while_condition62
bb_while_end64:
  %mutable_scalar258 = load i32, ptr %mutable_scalar_slot237, align 4
  %numeric_upper_bound259 = icmp ule i32 %mutable_scalar258, 255
  br i1 %numeric_upper_bound259, label %bb_numeric_conversion_upper_ok69, label %bb_numeric_conversion_upper_fail70

bb_numeric_conversion_upper_fail70:
  %trap_stderr260 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr260, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.21, i32 68, ptr %trap_written261, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok69:
  %numeric_convert262 = trunc i32 %mutable_scalar258 to i8
  %assignment_index263 = sext i32 0 to i64
  %inline_array_assign_in_bounds264 = icmp ult i64 %assignment_index263, %mutable_len214
  br i1 %inline_array_assign_in_bounds264, label %bb_inline_array_assign_bounds_ok71, label %bb_inline_array_assign_bounds_fail72

bb_inline_array_assign_bounds_fail72:
  %trap_stderr265 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr265, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.22, i32 82, ptr %trap_written266, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok71:
  %inline_array_assign_slot267 = getelementptr i8, ptr %mutable_ptr213, i64 %assignment_index263
  store i8 %numeric_convert262, ptr %inline_array_assign_slot267, align 1
  %mutable_scalar268 = load i32, ptr %mutable_scalar_slot61, align 4
  %add269 = add i32 %mutable_scalar268, 1
  store i32 %add269, ptr %mutable_scalar_slot61, align 4
  br label %bb_if_end33
bb_if_end33:
  store i32 0, ptr %mutable_scalar_slot270, align 4
  br label %bb_while_condition73
bb_while_condition73:
  %mutable_scalar271 = load i32, ptr %mutable_scalar_slot270, align 4
  %cmp272 = icmp slt i32 %mutable_scalar271, 4
  br i1 %cmp272, label %bb_while_body74, label %bb_while_end75
bb_while_body74:
  %mutable_ptr273 = load ptr, ptr %mutable_ptr_addr6, align 8
  %mutable_len274 = load i64, ptr %mutable_len_addr7, align 8
  %mutable_capacity275 = load i64, ptr %mutable_capacity_addr8, align 8
  %mutable_ptr276 = load ptr, ptr %mutable_ptr_addr6, align 8
  %mutable_len277 = load i64, ptr %mutable_len_addr7, align 8
  %mutable_capacity278 = load i64, ptr %mutable_capacity_addr8, align 8
  %mutable_scalar279 = load i32, ptr %mutable_scalar_slot60, align 4
  %sub280 = sub i32 %mutable_scalar279, 16
  %index_size281 = sext i32 %sub280 to i64
  %dynamic_inline_in_bounds282 = icmp ult i64 %index_size281, %mutable_len277
  br i1 %dynamic_inline_in_bounds282, label %bb_dynamic_inline_bounds_ok76, label %bb_dynamic_inline_bounds_fail77

bb_dynamic_inline_bounds_fail77:
  %trap_stderr283 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr283, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.23, i32 77, ptr %trap_written284, ptr null)
  call void @llvm.trap()
  unreachable

bb_dynamic_inline_bounds_ok76:
  %dynamic_inline_slot285 = getelementptr i8, ptr %mutable_ptr276, i64 %index_size281
  %dynamic_inline_item286 = load i8, ptr %dynamic_inline_slot285, align 1
  %mutable_ptr287 = load ptr, ptr %mutable_ptr_addr70, align 8
  %mutable_len288 = load i64, ptr %mutable_len_addr71, align 8
  %mutable_capacity289 = load i64, ptr %mutable_capacity_addr72, align 8
  %mutable_scalar290 = load i32, ptr %mutable_scalar_slot270, align 4
  %index_size291 = sext i32 %mutable_scalar290 to i64
  %inline_array_in_bounds292 = icmp ult i64 %index_size291, %mutable_len288
  br i1 %inline_array_in_bounds292, label %bb_inline_array_bounds_ok78, label %bb_inline_array_bounds_fail79

bb_inline_array_bounds_fail79:
  %trap_stderr293 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr293, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.24, i32 75, ptr %trap_written294, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok78:
  %inline_array_slot295 = getelementptr i8, ptr %mutable_ptr287, i64 %index_size291
  %inline_array_item296 = load i8, ptr %inline_array_slot295, align 1
  %numeric_convert297 = zext i8 %dynamic_inline_item286 to i32
  %numeric_convert298 = zext i8 %inline_array_item296 to i32
  store i32 0, ptr %mutable_scalar_slot299, align 4
  store i32 1, ptr %mutable_scalar_slot300, align 4
  store i32 0, ptr %mutable_scalar_slot301, align 4
  br label %bb_while_condition80
bb_while_condition80:
  %mutable_scalar302 = load i32, ptr %mutable_scalar_slot301, align 4
  %cmp303 = icmp ult i32 %mutable_scalar302, 32
  br i1 %cmp303, label %bb_while_body81, label %bb_while_end82
bb_while_body81:
  %mutable_scalar304 = load i32, ptr %mutable_scalar_slot300, align 4
  %div305 = udiv i32 %numeric_convert297, %mutable_scalar304
  %mod306 = urem i32 %div305, 2
  %mutable_scalar307 = load i32, ptr %mutable_scalar_slot300, align 4
  %div308 = udiv i32 %numeric_convert298, %mutable_scalar307
  %mod309 = urem i32 %div308, 2
  %cmp310 = icmp ne i32 %mod306, %mod309
  br i1 %cmp310, label %bb_if_then83, label %bb_if_end84
bb_if_then83:
  %mutable_scalar311 = load i32, ptr %mutable_scalar_slot299, align 4
  %mutable_scalar312 = load i32, ptr %mutable_scalar_slot300, align 4
  %add313 = add i32 %mutable_scalar311, %mutable_scalar312
  store i32 %add313, ptr %mutable_scalar_slot299, align 4
  br label %bb_if_end84
bb_if_end84:
  %mutable_scalar314 = load i32, ptr %mutable_scalar_slot301, align 4
  %add315 = add i32 %mutable_scalar314, 1
  store i32 %add315, ptr %mutable_scalar_slot301, align 4
  %mutable_scalar316 = load i32, ptr %mutable_scalar_slot301, align 4
  %cmp317 = icmp ult i32 %mutable_scalar316, 32
  br i1 %cmp317, label %bb_if_then85, label %bb_if_end86
bb_if_then85:
  %mutable_scalar318 = load i32, ptr %mutable_scalar_slot300, align 4
  %mul319 = mul i32 %mutable_scalar318, 2
  store i32 %mul319, ptr %mutable_scalar_slot300, align 4
  br label %bb_if_end86
bb_if_end86:
  br label %bb_while_condition80
bb_while_end82:
  %mutable_scalar320 = load i32, ptr %mutable_scalar_slot299, align 4
  %numeric_upper_bound321 = icmp ule i32 %mutable_scalar320, 255
  br i1 %numeric_upper_bound321, label %bb_numeric_conversion_upper_ok87, label %bb_numeric_conversion_upper_fail88

bb_numeric_conversion_upper_fail88:
  %trap_stderr322 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr322, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.25, i32 68, ptr %trap_written323, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok87:
  %numeric_convert324 = trunc i32 %mutable_scalar320 to i8
  %mutable_scalar325 = load i32, ptr %mutable_scalar_slot60, align 4
  %assignment_index326 = sext i32 %mutable_scalar325 to i64
  %dynamic_inline_assign_in_bounds327 = icmp ult i64 %assignment_index326, %mutable_len274
  br i1 %dynamic_inline_assign_in_bounds327, label %bb_dynamic_inline_assign_bounds_ok89, label %bb_dynamic_inline_assign_bounds_fail90

bb_dynamic_inline_assign_bounds_fail90:
  %trap_stderr328 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr328, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.26, i32 84, ptr %trap_written329, ptr null)
  call void @llvm.trap()
  unreachable

bb_dynamic_inline_assign_bounds_ok89:
  %dynamic_inline_assign_slot330 = getelementptr i8, ptr %mutable_ptr273, i64 %assignment_index326
  store i8 %numeric_convert324, ptr %dynamic_inline_assign_slot330, align 1
  %mutable_scalar331 = load i32, ptr %mutable_scalar_slot60, align 4
  %add332 = add i32 %mutable_scalar331, 1
  store i32 %add332, ptr %mutable_scalar_slot60, align 4
  %mutable_scalar333 = load i32, ptr %mutable_scalar_slot270, align 4
  %add334 = add i32 %mutable_scalar333, 1
  store i32 %add334, ptr %mutable_scalar_slot270, align 4
  br label %bb_while_condition73
bb_while_end75:
  br label %bb_while_condition22
bb_while_end24:
  %mutable_ptr335 = load ptr, ptr %mutable_ptr_addr6, align 8
  %mutable_len336 = load i64, ptr %mutable_len_addr7, align 8
  %mutable_capacity337 = load i64, ptr %mutable_capacity_addr8, align 8
  %mutable_ptr338 = load ptr, ptr %mutable_ptr_addr70, align 8
  %mutable_len339 = load i64, ptr %mutable_len_addr71, align 8
  %mutable_capacity340 = load i64, ptr %mutable_capacity_addr72, align 8
  call void @sollang_free(ptr %mutable_ptr338)
  %generic_array_value341 = insertvalue %sollang.dynamic_int_array poison, ptr %mutable_ptr335, 0
  %generic_array_value342 = insertvalue %sollang.dynamic_int_array %generic_array_value341, i64 %mutable_len336, 1
  %generic_array_value343 = insertvalue %sollang.dynamic_int_array %generic_array_value342, i64 %mutable_capacity337, 2
  ret %sollang.dynamic_int_array %generic_array_value343
}

define internal %sollang.int_slice @sollang_fn_std_crypto_aes128_roundConstants(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) #0 {
entry:
  %slice_value0 = insertvalue %sollang.int_slice poison, ptr @.slg.data.module.x7374642E63727970746F2E616573313238.1, 0
  %slice_value1 = insertvalue %sollang.int_slice %slice_value0, i64 10, 1
  ret %sollang.int_slice %slice_value1
}

define internal %sollang.int_slice @sollang_fn_std_crypto_aes128_Key_encryptBlock_portable(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.struct.1155 %it, %sollang.int_slice %arg_0) #0 {
entry:
  %trap_written5 = alloca i32, align 4
  %mutable_ptr_addr28 = alloca ptr, align 8
  %mutable_len_addr29 = alloca i64, align 8
  %mutable_capacity_addr30 = alloca i64, align 8
  %mutable_scalar_slot31 = alloca i32, align 4
  %trap_written41 = alloca i32, align 4
  %trap_written48 = alloca i32, align 4
  %mutable_scalar_slot59 = alloca i32, align 4
  %trap_written66 = alloca i32, align 4
  %trap_written74 = alloca i32, align 4
  %mutable_scalar_slot79 = alloca i32, align 4
  %mutable_scalar_slot80 = alloca i32, align 4
  %mutable_scalar_slot81 = alloca i32, align 4
  %trap_written103 = alloca i32, align 4
  %trap_written109 = alloca i32, align 4
  %mutable_scalar_slot113 = alloca i32, align 4
  %mutable_scalar_slot119 = alloca i32, align 4
  %trap_written129 = alloca i32, align 4
  %trap_written136 = alloca i32, align 4
  %trap_written143 = alloca i32, align 4
  %trap_written153 = alloca i32, align 4
  %trap_written159 = alloca i32, align 4
  %trap_written165 = alloca i32, align 4
  %trap_written170 = alloca i32, align 4
  %trap_written176 = alloca i32, align 4
  %trap_written181 = alloca i32, align 4
  %trap_written187 = alloca i32, align 4
  %trap_written192 = alloca i32, align 4
  %trap_written197 = alloca i32, align 4
  %trap_written203 = alloca i32, align 4
  %trap_written209 = alloca i32, align 4
  %trap_written215 = alloca i32, align 4
  %trap_written220 = alloca i32, align 4
  %trap_written226 = alloca i32, align 4
  %trap_written231 = alloca i32, align 4
  %trap_written236 = alloca i32, align 4
  %trap_written241 = alloca i32, align 4
  %trap_written247 = alloca i32, align 4
  %trap_written253 = alloca i32, align 4
  %trap_written258 = alloca i32, align 4
  %trap_written264 = alloca i32, align 4
  %trap_written269 = alloca i32, align 4
  %trap_written275 = alloca i32, align 4
  %trap_written280 = alloca i32, align 4
  %mutable_scalar_slot285 = alloca i32, align 4
  %trap_written293 = alloca i32, align 4
  %trap_written300 = alloca i32, align 4
  %trap_written307 = alloca i32, align 4
  %trap_written314 = alloca i32, align 4
  %trap_written322 = alloca i32, align 4
  %mutable_scalar_slot326 = alloca i32, align 4
  %mutable_scalar_slot327 = alloca i32, align 4
  %mutable_scalar_slot328 = alloca i32, align 4
  %trap_written350 = alloca i32, align 4
  %trap_written358 = alloca i32, align 4
  %mutable_scalar_slot362 = alloca i32, align 4
  %mutable_scalar_slot363 = alloca i32, align 4
  %mutable_scalar_slot364 = alloca i32, align 4
  %trap_written386 = alloca i32, align 4
  %mutable_scalar_slot391 = alloca i32, align 4
  %mutable_scalar_slot392 = alloca i32, align 4
  %mutable_scalar_slot393 = alloca i32, align 4
  %trap_written415 = alloca i32, align 4
  %mutable_scalar_slot419 = alloca i32, align 4
  %mutable_scalar_slot420 = alloca i32, align 4
  %mutable_scalar_slot421 = alloca i32, align 4
  %trap_written443 = alloca i32, align 4
  %mutable_scalar_slot447 = alloca i32, align 4
  %mutable_scalar_slot448 = alloca i32, align 4
  %mutable_scalar_slot449 = alloca i32, align 4
  %trap_written471 = alloca i32, align 4
  %mutable_scalar_slot475 = alloca i32, align 4
  %mutable_scalar_slot476 = alloca i32, align 4
  %mutable_scalar_slot477 = alloca i32, align 4
  %trap_written499 = alloca i32, align 4
  %trap_written504 = alloca i32, align 4
  %trap_written511 = alloca i32, align 4
  %mutable_scalar_slot515 = alloca i32, align 4
  %mutable_scalar_slot516 = alloca i32, align 4
  %mutable_scalar_slot517 = alloca i32, align 4
  %trap_written539 = alloca i32, align 4
  %mutable_scalar_slot544 = alloca i32, align 4
  %mutable_scalar_slot545 = alloca i32, align 4
  %mutable_scalar_slot546 = alloca i32, align 4
  %trap_written568 = alloca i32, align 4
  %trap_written575 = alloca i32, align 4
  %mutable_scalar_slot579 = alloca i32, align 4
  %mutable_scalar_slot580 = alloca i32, align 4
  %mutable_scalar_slot581 = alloca i32, align 4
  %trap_written603 = alloca i32, align 4
  %mutable_scalar_slot608 = alloca i32, align 4
  %mutable_scalar_slot609 = alloca i32, align 4
  %mutable_scalar_slot610 = alloca i32, align 4
  %trap_written632 = alloca i32, align 4
  %mutable_scalar_slot636 = alloca i32, align 4
  %mutable_scalar_slot637 = alloca i32, align 4
  %mutable_scalar_slot638 = alloca i32, align 4
  %trap_written660 = alloca i32, align 4
  %mutable_scalar_slot664 = alloca i32, align 4
  %mutable_scalar_slot665 = alloca i32, align 4
  %mutable_scalar_slot666 = alloca i32, align 4
  %trap_written688 = alloca i32, align 4
  %trap_written694 = alloca i32, align 4
  %mutable_scalar_slot698 = alloca i32, align 4
  %mutable_scalar_slot699 = alloca i32, align 4
  %mutable_scalar_slot700 = alloca i32, align 4
  %trap_written722 = alloca i32, align 4
  %trap_written729 = alloca i32, align 4
  %mutable_scalar_slot733 = alloca i32, align 4
  %mutable_scalar_slot734 = alloca i32, align 4
  %mutable_scalar_slot735 = alloca i32, align 4
  %trap_written757 = alloca i32, align 4
  %mutable_scalar_slot762 = alloca i32, align 4
  %mutable_scalar_slot763 = alloca i32, align 4
  %mutable_scalar_slot764 = alloca i32, align 4
  %trap_written786 = alloca i32, align 4
  %trap_written793 = alloca i32, align 4
  %mutable_scalar_slot797 = alloca i32, align 4
  %mutable_scalar_slot798 = alloca i32, align 4
  %mutable_scalar_slot799 = alloca i32, align 4
  %trap_written821 = alloca i32, align 4
  %mutable_scalar_slot826 = alloca i32, align 4
  %mutable_scalar_slot827 = alloca i32, align 4
  %mutable_scalar_slot828 = alloca i32, align 4
  %trap_written850 = alloca i32, align 4
  %mutable_scalar_slot854 = alloca i32, align 4
  %mutable_scalar_slot855 = alloca i32, align 4
  %mutable_scalar_slot856 = alloca i32, align 4
  %trap_written878 = alloca i32, align 4
  %trap_written884 = alloca i32, align 4
  %trap_written891 = alloca i32, align 4
  %mutable_scalar_slot895 = alloca i32, align 4
  %mutable_scalar_slot896 = alloca i32, align 4
  %mutable_scalar_slot897 = alloca i32, align 4
  %trap_written919 = alloca i32, align 4
  %mutable_scalar_slot924 = alloca i32, align 4
  %mutable_scalar_slot925 = alloca i32, align 4
  %mutable_scalar_slot926 = alloca i32, align 4
  %trap_written948 = alloca i32, align 4
  %mutable_scalar_slot952 = alloca i32, align 4
  %mutable_scalar_slot953 = alloca i32, align 4
  %mutable_scalar_slot954 = alloca i32, align 4
  %trap_written976 = alloca i32, align 4
  %mutable_scalar_slot980 = alloca i32, align 4
  %mutable_scalar_slot981 = alloca i32, align 4
  %mutable_scalar_slot982 = alloca i32, align 4
  %trap_written1004 = alloca i32, align 4
  %trap_written1011 = alloca i32, align 4
  %mutable_scalar_slot1015 = alloca i32, align 4
  %mutable_scalar_slot1016 = alloca i32, align 4
  %mutable_scalar_slot1017 = alloca i32, align 4
  %trap_written1039 = alloca i32, align 4
  %mutable_scalar_slot1044 = alloca i32, align 4
  %mutable_scalar_slot1045 = alloca i32, align 4
  %mutable_scalar_slot1046 = alloca i32, align 4
  %trap_written1068 = alloca i32, align 4
  %trap_written1074 = alloca i32, align 4
  %mutable_scalar_slot1087 = alloca i32, align 4
  %trap_written1094 = alloca i32, align 4
  %trap_written1102 = alloca i32, align 4
  %mutable_scalar_slot1107 = alloca i32, align 4
  %mutable_scalar_slot1108 = alloca i32, align 4
  %mutable_scalar_slot1109 = alloca i32, align 4
  %trap_written1131 = alloca i32, align 4
  %trap_written1137 = alloca i32, align 4
  %mutable_scalar_slot1146 = alloca i32, align 4
  %trap_written1156 = alloca i32, align 4
  %trap_written1163 = alloca i32, align 4
  %trap_written1170 = alloca i32, align 4
  %trap_written1180 = alloca i32, align 4
  %trap_written1186 = alloca i32, align 4
  %trap_written1192 = alloca i32, align 4
  %trap_written1197 = alloca i32, align 4
  %trap_written1203 = alloca i32, align 4
  %trap_written1208 = alloca i32, align 4
  %trap_written1214 = alloca i32, align 4
  %trap_written1219 = alloca i32, align 4
  %trap_written1224 = alloca i32, align 4
  %trap_written1230 = alloca i32, align 4
  %trap_written1236 = alloca i32, align 4
  %trap_written1242 = alloca i32, align 4
  %trap_written1247 = alloca i32, align 4
  %trap_written1253 = alloca i32, align 4
  %trap_written1258 = alloca i32, align 4
  %trap_written1263 = alloca i32, align 4
  %trap_written1268 = alloca i32, align 4
  %trap_written1274 = alloca i32, align 4
  %trap_written1280 = alloca i32, align 4
  %trap_written1285 = alloca i32, align 4
  %trap_written1291 = alloca i32, align 4
  %trap_written1296 = alloca i32, align 4
  %trap_written1302 = alloca i32, align 4
  %trap_written1307 = alloca i32, align 4
  %mutable_scalar_slot1316 = alloca i32, align 4
  %trap_written1323 = alloca i32, align 4
  %trap_written1331 = alloca i32, align 4
  %mutable_scalar_slot1336 = alloca i32, align 4
  %mutable_scalar_slot1337 = alloca i32, align 4
  %mutable_scalar_slot1338 = alloca i32, align 4
  %trap_written1360 = alloca i32, align 4
  %trap_written1366 = alloca i32, align 4
  %fixed_array_ptr0 = extractvalue %sollang.int_slice %arg_0, 0
  %fixed_array_len1 = extractvalue %sollang.int_slice %arg_0, 1
  %heap2 = call ptr @sollang_alloc(i64 16)
  %heap_ok3 = icmp ne ptr %heap2, null
  br i1 %heap_ok3, label %bb_alloc_ok0, label %bb_alloc_fail1

bb_alloc_fail1:
  %trap_stderr4 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr4, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.27, i32 70, ptr %trap_written5, ptr null)
  call void @llvm.trap()
  unreachable

bb_alloc_ok0:
  %inline_array_slot6 = getelementptr i8, ptr %heap2, i64 0
  store i8 0, ptr %inline_array_slot6, align 1
  %inline_array_slot7 = getelementptr i8, ptr %heap2, i64 1
  store i8 0, ptr %inline_array_slot7, align 1
  %inline_array_slot8 = getelementptr i8, ptr %heap2, i64 2
  store i8 0, ptr %inline_array_slot8, align 1
  %inline_array_slot9 = getelementptr i8, ptr %heap2, i64 3
  store i8 0, ptr %inline_array_slot9, align 1
  %inline_array_slot10 = getelementptr i8, ptr %heap2, i64 4
  store i8 0, ptr %inline_array_slot10, align 1
  %inline_array_slot11 = getelementptr i8, ptr %heap2, i64 5
  store i8 0, ptr %inline_array_slot11, align 1
  %inline_array_slot12 = getelementptr i8, ptr %heap2, i64 6
  store i8 0, ptr %inline_array_slot12, align 1
  %inline_array_slot13 = getelementptr i8, ptr %heap2, i64 7
  store i8 0, ptr %inline_array_slot13, align 1
  %inline_array_slot14 = getelementptr i8, ptr %heap2, i64 8
  store i8 0, ptr %inline_array_slot14, align 1
  %inline_array_slot15 = getelementptr i8, ptr %heap2, i64 9
  store i8 0, ptr %inline_array_slot15, align 1
  %inline_array_slot16 = getelementptr i8, ptr %heap2, i64 10
  store i8 0, ptr %inline_array_slot16, align 1
  %inline_array_slot17 = getelementptr i8, ptr %heap2, i64 11
  store i8 0, ptr %inline_array_slot17, align 1
  %inline_array_slot18 = getelementptr i8, ptr %heap2, i64 12
  store i8 0, ptr %inline_array_slot18, align 1
  %inline_array_slot19 = getelementptr i8, ptr %heap2, i64 13
  store i8 0, ptr %inline_array_slot19, align 1
  %inline_array_slot20 = getelementptr i8, ptr %heap2, i64 14
  store i8 0, ptr %inline_array_slot20, align 1
  %inline_array_slot21 = getelementptr i8, ptr %heap2, i64 15
  store i8 0, ptr %inline_array_slot21, align 1
  %slice_value22 = insertvalue %sollang.int_slice poison, ptr %heap2, 0
  %slice_value23 = insertvalue %sollang.int_slice %slice_value22, i64 16, 1
  %struct_init24 = insertvalue %sollang.struct.1156 poison, %sollang.int_slice %slice_value23, 0
  %field25 = extractvalue %sollang.struct.1156 %struct_init24, 0
  %fixed_array_ptr26 = extractvalue %sollang.int_slice %field25, 0
  %fixed_array_len27 = extractvalue %sollang.int_slice %field25, 1
  store ptr %fixed_array_ptr26, ptr %mutable_ptr_addr28, align 8
  store i64 %fixed_array_len27, ptr %mutable_len_addr29, align 8
  store i64 16, ptr %mutable_capacity_addr30, align 8
  store i32 0, ptr %mutable_scalar_slot31, align 4
  br label %bb_while_condition2
bb_while_condition2:
  %mutable_scalar32 = load i32, ptr %mutable_scalar_slot31, align 4
  %cmp33 = icmp slt i32 %mutable_scalar32, 16
  br i1 %cmp33, label %bb_while_body3, label %bb_while_end4
bb_while_body3:
  %mutable_ptr34 = load ptr, ptr %mutable_ptr_addr28, align 8
  %mutable_len35 = load i64, ptr %mutable_len_addr29, align 8
  %mutable_capacity36 = load i64, ptr %mutable_capacity_addr30, align 8
  %mutable_scalar37 = load i32, ptr %mutable_scalar_slot31, align 4
  %index_size38 = sext i32 %mutable_scalar37 to i64
  %inline_array_in_bounds39 = icmp ult i64 %index_size38, %fixed_array_len1
  br i1 %inline_array_in_bounds39, label %bb_inline_array_bounds_ok5, label %bb_inline_array_bounds_fail6

bb_inline_array_bounds_fail6:
  %trap_stderr40 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr40, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.28, i32 81, ptr %trap_written41, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok5:
  %inline_array_slot42 = getelementptr i8, ptr %fixed_array_ptr0, i64 %index_size38
  %inline_array_item43 = load i8, ptr %inline_array_slot42, align 1
  %mutable_scalar44 = load i32, ptr %mutable_scalar_slot31, align 4
  %assignment_index45 = sext i32 %mutable_scalar44 to i64
  %inline_array_assign_in_bounds46 = icmp ult i64 %assignment_index45, %mutable_len35
  br i1 %inline_array_assign_in_bounds46, label %bb_inline_array_assign_bounds_ok7, label %bb_inline_array_assign_bounds_fail8

bb_inline_array_assign_bounds_fail8:
  %trap_stderr47 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr47, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.29, i32 88, ptr %trap_written48, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok7:
  %inline_array_assign_slot49 = getelementptr i8, ptr %mutable_ptr34, i64 %assignment_index45
  store i8 %inline_array_item43, ptr %inline_array_assign_slot49, align 1
  %mutable_scalar50 = load i32, ptr %mutable_scalar_slot31, align 4
  %add51 = add i32 %mutable_scalar50, 1
  store i32 %add51, ptr %mutable_scalar_slot31, align 4
  br label %bb_while_condition2
bb_while_end4:
  %mutable_ptr52 = load ptr, ptr %mutable_ptr_addr28, align 8
  %mutable_len53 = load i64, ptr %mutable_len_addr29, align 8
  %mutable_capacity54 = load i64, ptr %mutable_capacity_addr30, align 8
  %field55 = extractvalue %sollang.struct.1155 %it, 0
  %array_ptr56 = extractvalue %sollang.dynamic_int_array %field55, 0
  %array_len57 = extractvalue %sollang.dynamic_int_array %field55, 1
  %array_capacity58 = extractvalue %sollang.dynamic_int_array %field55, 2
  store i32 0, ptr %mutable_scalar_slot59, align 4
  br label %bb_while_condition9
bb_while_condition9:
  %mutable_scalar60 = load i32, ptr %mutable_scalar_slot59, align 4
  %cmp61 = icmp slt i32 %mutable_scalar60, 16
  br i1 %cmp61, label %bb_while_body10, label %bb_while_end11
bb_while_body10:
  %mutable_scalar62 = load i32, ptr %mutable_scalar_slot59, align 4
  %index_size63 = sext i32 %mutable_scalar62 to i64
  %inline_array_in_bounds64 = icmp ult i64 %index_size63, %mutable_len53
  br i1 %inline_array_in_bounds64, label %bb_inline_array_bounds_ok12, label %bb_inline_array_bounds_fail13

bb_inline_array_bounds_fail13:
  %trap_stderr65 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr65, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.30, i32 77, ptr %trap_written66, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok12:
  %inline_array_slot67 = getelementptr i8, ptr %mutable_ptr52, i64 %index_size63
  %inline_array_item68 = load i8, ptr %inline_array_slot67, align 1
  %mutable_scalar69 = load i32, ptr %mutable_scalar_slot59, align 4
  %add70 = add i32 0, %mutable_scalar69
  %index_size71 = sext i32 %add70 to i64
  %slice_in_bounds72 = icmp ult i64 %index_size71, %array_len57
  br i1 %slice_in_bounds72, label %bb_slice_bounds_ok14, label %bb_slice_bounds_fail15

bb_slice_bounds_fail15:
  %trap_stderr73 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr73, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.31, i32 70, ptr %trap_written74, ptr null)
  call void @llvm.trap()
  unreachable

bb_slice_bounds_ok14:
  %slice_slot75 = getelementptr i8, ptr %array_ptr56, i64 %index_size71
  %slice_item76 = load i8, ptr %slice_slot75, align 1
  %numeric_convert77 = zext i8 %inline_array_item68 to i32
  %numeric_convert78 = zext i8 %slice_item76 to i32
  store i32 0, ptr %mutable_scalar_slot79, align 4
  store i32 1, ptr %mutable_scalar_slot80, align 4
  store i32 0, ptr %mutable_scalar_slot81, align 4
  br label %bb_while_condition16
bb_while_condition16:
  %mutable_scalar82 = load i32, ptr %mutable_scalar_slot81, align 4
  %cmp83 = icmp ult i32 %mutable_scalar82, 32
  br i1 %cmp83, label %bb_while_body17, label %bb_while_end18
bb_while_body17:
  %mutable_scalar84 = load i32, ptr %mutable_scalar_slot80, align 4
  %div85 = udiv i32 %numeric_convert77, %mutable_scalar84
  %mod86 = urem i32 %div85, 2
  %mutable_scalar87 = load i32, ptr %mutable_scalar_slot80, align 4
  %div88 = udiv i32 %numeric_convert78, %mutable_scalar87
  %mod89 = urem i32 %div88, 2
  %cmp90 = icmp ne i32 %mod86, %mod89
  br i1 %cmp90, label %bb_if_then19, label %bb_if_end20
bb_if_then19:
  %mutable_scalar91 = load i32, ptr %mutable_scalar_slot79, align 4
  %mutable_scalar92 = load i32, ptr %mutable_scalar_slot80, align 4
  %add93 = add i32 %mutable_scalar91, %mutable_scalar92
  store i32 %add93, ptr %mutable_scalar_slot79, align 4
  br label %bb_if_end20
bb_if_end20:
  %mutable_scalar94 = load i32, ptr %mutable_scalar_slot81, align 4
  %add95 = add i32 %mutable_scalar94, 1
  store i32 %add95, ptr %mutable_scalar_slot81, align 4
  %mutable_scalar96 = load i32, ptr %mutable_scalar_slot81, align 4
  %cmp97 = icmp ult i32 %mutable_scalar96, 32
  br i1 %cmp97, label %bb_if_then21, label %bb_if_end22
bb_if_then21:
  %mutable_scalar98 = load i32, ptr %mutable_scalar_slot80, align 4
  %mul99 = mul i32 %mutable_scalar98, 2
  store i32 %mul99, ptr %mutable_scalar_slot80, align 4
  br label %bb_if_end22
bb_if_end22:
  br label %bb_while_condition16
bb_while_end18:
  %mutable_scalar100 = load i32, ptr %mutable_scalar_slot79, align 4
  %numeric_upper_bound101 = icmp ule i32 %mutable_scalar100, 255
  br i1 %numeric_upper_bound101, label %bb_numeric_conversion_upper_ok23, label %bb_numeric_conversion_upper_fail24

bb_numeric_conversion_upper_fail24:
  %trap_stderr102 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr102, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.32, i32 68, ptr %trap_written103, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok23:
  %numeric_convert104 = trunc i32 %mutable_scalar100 to i8
  %mutable_scalar105 = load i32, ptr %mutable_scalar_slot59, align 4
  %assignment_index106 = sext i32 %mutable_scalar105 to i64
  %inline_array_assign_in_bounds107 = icmp ult i64 %assignment_index106, %mutable_len53
  br i1 %inline_array_assign_in_bounds107, label %bb_inline_array_assign_bounds_ok25, label %bb_inline_array_assign_bounds_fail26

bb_inline_array_assign_bounds_fail26:
  %trap_stderr108 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr108, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.33, i32 84, ptr %trap_written109, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok25:
  %inline_array_assign_slot110 = getelementptr i8, ptr %mutable_ptr52, i64 %assignment_index106
  store i8 %numeric_convert104, ptr %inline_array_assign_slot110, align 1
  %mutable_scalar111 = load i32, ptr %mutable_scalar_slot59, align 4
  %add112 = add i32 %mutable_scalar111, 1
  store i32 %add112, ptr %mutable_scalar_slot59, align 4
  br label %bb_while_condition9
bb_while_end11:
  store i32 1, ptr %mutable_scalar_slot113, align 4
  br label %bb_while_condition27
bb_while_condition27:
  %mutable_scalar114 = load i32, ptr %mutable_scalar_slot113, align 4
  %cmp115 = icmp slt i32 %mutable_scalar114, 10
  br i1 %cmp115, label %bb_while_body28, label %bb_while_end29
bb_while_body28:
  %mutable_ptr116 = load ptr, ptr %mutable_ptr_addr28, align 8
  %mutable_len117 = load i64, ptr %mutable_len_addr29, align 8
  %mutable_capacity118 = load i64, ptr %mutable_capacity_addr30, align 8
  store i32 0, ptr %mutable_scalar_slot119, align 4
  br label %bb_while_condition30
bb_while_condition30:
  %mutable_scalar120 = load i32, ptr %mutable_scalar_slot119, align 4
  %cmp121 = icmp slt i32 %mutable_scalar120, 16
  br i1 %cmp121, label %bb_while_body31, label %bb_while_end32
bb_while_body31:
  %struct_call122 = call %sollang.int_slice @sollang_fn_std_crypto_aes128_sbox(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %slice_ptr123 = extractvalue %sollang.int_slice %struct_call122, 0
  %slice_len124 = extractvalue %sollang.int_slice %struct_call122, 1
  %mutable_scalar125 = load i32, ptr %mutable_scalar_slot119, align 4
  %index_size126 = sext i32 %mutable_scalar125 to i64
  %inline_array_in_bounds127 = icmp ult i64 %index_size126, %mutable_len117
  br i1 %inline_array_in_bounds127, label %bb_inline_array_bounds_ok33, label %bb_inline_array_bounds_fail34

bb_inline_array_bounds_fail34:
  %trap_stderr128 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr128, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.34, i32 74, ptr %trap_written129, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok33:
  %inline_array_slot130 = getelementptr i8, ptr %mutable_ptr116, i64 %index_size126
  %inline_array_item131 = load i8, ptr %inline_array_slot130, align 1
  %numeric_convert132 = zext i8 %inline_array_item131 to i32
  %index_size133 = sext i32 %numeric_convert132 to i64
  %slice_in_bounds134 = icmp ult i64 %index_size133, %slice_len124
  br i1 %slice_in_bounds134, label %bb_slice_bounds_ok35, label %bb_slice_bounds_fail36

bb_slice_bounds_fail36:
  %trap_stderr135 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr135, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.35, i32 67, ptr %trap_written136, ptr null)
  call void @llvm.trap()
  unreachable

bb_slice_bounds_ok35:
  %slice_slot137 = getelementptr i8, ptr %slice_ptr123, i64 %index_size133
  %slice_item138 = load i8, ptr %slice_slot137, align 1
  %mutable_scalar139 = load i32, ptr %mutable_scalar_slot119, align 4
  %assignment_index140 = sext i32 %mutable_scalar139 to i64
  %inline_array_assign_in_bounds141 = icmp ult i64 %assignment_index140, %mutable_len117
  br i1 %inline_array_assign_in_bounds141, label %bb_inline_array_assign_bounds_ok37, label %bb_inline_array_assign_bounds_fail38

bb_inline_array_assign_bounds_fail38:
  %trap_stderr142 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr142, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.36, i32 81, ptr %trap_written143, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok37:
  %inline_array_assign_slot144 = getelementptr i8, ptr %mutable_ptr116, i64 %assignment_index140
  store i8 %slice_item138, ptr %inline_array_assign_slot144, align 1
  %mutable_scalar145 = load i32, ptr %mutable_scalar_slot119, align 4
  %add146 = add i32 %mutable_scalar145, 1
  store i32 %add146, ptr %mutable_scalar_slot119, align 4
  br label %bb_while_condition30
bb_while_end32:
  %mutable_ptr147 = load ptr, ptr %mutable_ptr_addr28, align 8
  %mutable_len148 = load i64, ptr %mutable_len_addr29, align 8
  %mutable_capacity149 = load i64, ptr %mutable_capacity_addr30, align 8
  %index_size150 = sext i32 1 to i64
  %inline_array_in_bounds151 = icmp ult i64 %index_size150, %mutable_len148
  br i1 %inline_array_in_bounds151, label %bb_inline_array_bounds_ok39, label %bb_inline_array_bounds_fail40

bb_inline_array_bounds_fail40:
  %trap_stderr152 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr152, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.37, i32 75, ptr %trap_written153, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok39:
  %inline_array_slot154 = getelementptr i8, ptr %mutable_ptr147, i64 %index_size150
  %inline_array_item155 = load i8, ptr %inline_array_slot154, align 1
  %index_size156 = sext i32 5 to i64
  %inline_array_in_bounds157 = icmp ult i64 %index_size156, %mutable_len148
  br i1 %inline_array_in_bounds157, label %bb_inline_array_bounds_ok41, label %bb_inline_array_bounds_fail42

bb_inline_array_bounds_fail42:
  %trap_stderr158 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr158, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.38, i32 75, ptr %trap_written159, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok41:
  %inline_array_slot160 = getelementptr i8, ptr %mutable_ptr147, i64 %index_size156
  %inline_array_item161 = load i8, ptr %inline_array_slot160, align 1
  %assignment_index162 = sext i32 1 to i64
  %inline_array_assign_in_bounds163 = icmp ult i64 %assignment_index162, %mutable_len148
  br i1 %inline_array_assign_in_bounds163, label %bb_inline_array_assign_bounds_ok43, label %bb_inline_array_assign_bounds_fail44

bb_inline_array_assign_bounds_fail44:
  %trap_stderr164 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr164, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.39, i32 82, ptr %trap_written165, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok43:
  %inline_array_assign_slot166 = getelementptr i8, ptr %mutable_ptr147, i64 %assignment_index162
  store i8 %inline_array_item161, ptr %inline_array_assign_slot166, align 1
  %index_size167 = sext i32 9 to i64
  %inline_array_in_bounds168 = icmp ult i64 %index_size167, %mutable_len148
  br i1 %inline_array_in_bounds168, label %bb_inline_array_bounds_ok45, label %bb_inline_array_bounds_fail46

bb_inline_array_bounds_fail46:
  %trap_stderr169 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr169, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.40, i32 75, ptr %trap_written170, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok45:
  %inline_array_slot171 = getelementptr i8, ptr %mutable_ptr147, i64 %index_size167
  %inline_array_item172 = load i8, ptr %inline_array_slot171, align 1
  %assignment_index173 = sext i32 5 to i64
  %inline_array_assign_in_bounds174 = icmp ult i64 %assignment_index173, %mutable_len148
  br i1 %inline_array_assign_in_bounds174, label %bb_inline_array_assign_bounds_ok47, label %bb_inline_array_assign_bounds_fail48

bb_inline_array_assign_bounds_fail48:
  %trap_stderr175 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr175, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.41, i32 82, ptr %trap_written176, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok47:
  %inline_array_assign_slot177 = getelementptr i8, ptr %mutable_ptr147, i64 %assignment_index173
  store i8 %inline_array_item172, ptr %inline_array_assign_slot177, align 1
  %index_size178 = sext i32 13 to i64
  %inline_array_in_bounds179 = icmp ult i64 %index_size178, %mutable_len148
  br i1 %inline_array_in_bounds179, label %bb_inline_array_bounds_ok49, label %bb_inline_array_bounds_fail50

bb_inline_array_bounds_fail50:
  %trap_stderr180 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr180, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.42, i32 75, ptr %trap_written181, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok49:
  %inline_array_slot182 = getelementptr i8, ptr %mutable_ptr147, i64 %index_size178
  %inline_array_item183 = load i8, ptr %inline_array_slot182, align 1
  %assignment_index184 = sext i32 9 to i64
  %inline_array_assign_in_bounds185 = icmp ult i64 %assignment_index184, %mutable_len148
  br i1 %inline_array_assign_in_bounds185, label %bb_inline_array_assign_bounds_ok51, label %bb_inline_array_assign_bounds_fail52

bb_inline_array_assign_bounds_fail52:
  %trap_stderr186 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr186, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.43, i32 82, ptr %trap_written187, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok51:
  %inline_array_assign_slot188 = getelementptr i8, ptr %mutable_ptr147, i64 %assignment_index184
  store i8 %inline_array_item183, ptr %inline_array_assign_slot188, align 1
  %assignment_index189 = sext i32 13 to i64
  %inline_array_assign_in_bounds190 = icmp ult i64 %assignment_index189, %mutable_len148
  br i1 %inline_array_assign_in_bounds190, label %bb_inline_array_assign_bounds_ok53, label %bb_inline_array_assign_bounds_fail54

bb_inline_array_assign_bounds_fail54:
  %trap_stderr191 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr191, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.44, i32 82, ptr %trap_written192, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok53:
  %inline_array_assign_slot193 = getelementptr i8, ptr %mutable_ptr147, i64 %assignment_index189
  store i8 %inline_array_item155, ptr %inline_array_assign_slot193, align 1
  %index_size194 = sext i32 2 to i64
  %inline_array_in_bounds195 = icmp ult i64 %index_size194, %mutable_len148
  br i1 %inline_array_in_bounds195, label %bb_inline_array_bounds_ok55, label %bb_inline_array_bounds_fail56

bb_inline_array_bounds_fail56:
  %trap_stderr196 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr196, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.45, i32 75, ptr %trap_written197, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok55:
  %inline_array_slot198 = getelementptr i8, ptr %mutable_ptr147, i64 %index_size194
  %inline_array_item199 = load i8, ptr %inline_array_slot198, align 1
  %index_size200 = sext i32 6 to i64
  %inline_array_in_bounds201 = icmp ult i64 %index_size200, %mutable_len148
  br i1 %inline_array_in_bounds201, label %bb_inline_array_bounds_ok57, label %bb_inline_array_bounds_fail58

bb_inline_array_bounds_fail58:
  %trap_stderr202 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr202, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.46, i32 75, ptr %trap_written203, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok57:
  %inline_array_slot204 = getelementptr i8, ptr %mutable_ptr147, i64 %index_size200
  %inline_array_item205 = load i8, ptr %inline_array_slot204, align 1
  %index_size206 = sext i32 10 to i64
  %inline_array_in_bounds207 = icmp ult i64 %index_size206, %mutable_len148
  br i1 %inline_array_in_bounds207, label %bb_inline_array_bounds_ok59, label %bb_inline_array_bounds_fail60

bb_inline_array_bounds_fail60:
  %trap_stderr208 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr208, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.47, i32 75, ptr %trap_written209, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok59:
  %inline_array_slot210 = getelementptr i8, ptr %mutable_ptr147, i64 %index_size206
  %inline_array_item211 = load i8, ptr %inline_array_slot210, align 1
  %assignment_index212 = sext i32 2 to i64
  %inline_array_assign_in_bounds213 = icmp ult i64 %assignment_index212, %mutable_len148
  br i1 %inline_array_assign_in_bounds213, label %bb_inline_array_assign_bounds_ok61, label %bb_inline_array_assign_bounds_fail62

bb_inline_array_assign_bounds_fail62:
  %trap_stderr214 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr214, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.48, i32 82, ptr %trap_written215, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok61:
  %inline_array_assign_slot216 = getelementptr i8, ptr %mutable_ptr147, i64 %assignment_index212
  store i8 %inline_array_item211, ptr %inline_array_assign_slot216, align 1
  %index_size217 = sext i32 14 to i64
  %inline_array_in_bounds218 = icmp ult i64 %index_size217, %mutable_len148
  br i1 %inline_array_in_bounds218, label %bb_inline_array_bounds_ok63, label %bb_inline_array_bounds_fail64

bb_inline_array_bounds_fail64:
  %trap_stderr219 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr219, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.49, i32 75, ptr %trap_written220, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok63:
  %inline_array_slot221 = getelementptr i8, ptr %mutable_ptr147, i64 %index_size217
  %inline_array_item222 = load i8, ptr %inline_array_slot221, align 1
  %assignment_index223 = sext i32 6 to i64
  %inline_array_assign_in_bounds224 = icmp ult i64 %assignment_index223, %mutable_len148
  br i1 %inline_array_assign_in_bounds224, label %bb_inline_array_assign_bounds_ok65, label %bb_inline_array_assign_bounds_fail66

bb_inline_array_assign_bounds_fail66:
  %trap_stderr225 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr225, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.50, i32 82, ptr %trap_written226, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok65:
  %inline_array_assign_slot227 = getelementptr i8, ptr %mutable_ptr147, i64 %assignment_index223
  store i8 %inline_array_item222, ptr %inline_array_assign_slot227, align 1
  %assignment_index228 = sext i32 10 to i64
  %inline_array_assign_in_bounds229 = icmp ult i64 %assignment_index228, %mutable_len148
  br i1 %inline_array_assign_in_bounds229, label %bb_inline_array_assign_bounds_ok67, label %bb_inline_array_assign_bounds_fail68

bb_inline_array_assign_bounds_fail68:
  %trap_stderr230 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr230, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.51, i32 82, ptr %trap_written231, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok67:
  %inline_array_assign_slot232 = getelementptr i8, ptr %mutable_ptr147, i64 %assignment_index228
  store i8 %inline_array_item199, ptr %inline_array_assign_slot232, align 1
  %assignment_index233 = sext i32 14 to i64
  %inline_array_assign_in_bounds234 = icmp ult i64 %assignment_index233, %mutable_len148
  br i1 %inline_array_assign_in_bounds234, label %bb_inline_array_assign_bounds_ok69, label %bb_inline_array_assign_bounds_fail70

bb_inline_array_assign_bounds_fail70:
  %trap_stderr235 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr235, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.52, i32 82, ptr %trap_written236, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok69:
  %inline_array_assign_slot237 = getelementptr i8, ptr %mutable_ptr147, i64 %assignment_index233
  store i8 %inline_array_item205, ptr %inline_array_assign_slot237, align 1
  %index_size238 = sext i32 3 to i64
  %inline_array_in_bounds239 = icmp ult i64 %index_size238, %mutable_len148
  br i1 %inline_array_in_bounds239, label %bb_inline_array_bounds_ok71, label %bb_inline_array_bounds_fail72

bb_inline_array_bounds_fail72:
  %trap_stderr240 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr240, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.53, i32 75, ptr %trap_written241, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok71:
  %inline_array_slot242 = getelementptr i8, ptr %mutable_ptr147, i64 %index_size238
  %inline_array_item243 = load i8, ptr %inline_array_slot242, align 1
  %index_size244 = sext i32 15 to i64
  %inline_array_in_bounds245 = icmp ult i64 %index_size244, %mutable_len148
  br i1 %inline_array_in_bounds245, label %bb_inline_array_bounds_ok73, label %bb_inline_array_bounds_fail74

bb_inline_array_bounds_fail74:
  %trap_stderr246 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr246, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.54, i32 75, ptr %trap_written247, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok73:
  %inline_array_slot248 = getelementptr i8, ptr %mutable_ptr147, i64 %index_size244
  %inline_array_item249 = load i8, ptr %inline_array_slot248, align 1
  %assignment_index250 = sext i32 3 to i64
  %inline_array_assign_in_bounds251 = icmp ult i64 %assignment_index250, %mutable_len148
  br i1 %inline_array_assign_in_bounds251, label %bb_inline_array_assign_bounds_ok75, label %bb_inline_array_assign_bounds_fail76

bb_inline_array_assign_bounds_fail76:
  %trap_stderr252 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr252, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.55, i32 82, ptr %trap_written253, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok75:
  %inline_array_assign_slot254 = getelementptr i8, ptr %mutable_ptr147, i64 %assignment_index250
  store i8 %inline_array_item249, ptr %inline_array_assign_slot254, align 1
  %index_size255 = sext i32 11 to i64
  %inline_array_in_bounds256 = icmp ult i64 %index_size255, %mutable_len148
  br i1 %inline_array_in_bounds256, label %bb_inline_array_bounds_ok77, label %bb_inline_array_bounds_fail78

bb_inline_array_bounds_fail78:
  %trap_stderr257 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr257, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.56, i32 75, ptr %trap_written258, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok77:
  %inline_array_slot259 = getelementptr i8, ptr %mutable_ptr147, i64 %index_size255
  %inline_array_item260 = load i8, ptr %inline_array_slot259, align 1
  %assignment_index261 = sext i32 15 to i64
  %inline_array_assign_in_bounds262 = icmp ult i64 %assignment_index261, %mutable_len148
  br i1 %inline_array_assign_in_bounds262, label %bb_inline_array_assign_bounds_ok79, label %bb_inline_array_assign_bounds_fail80

bb_inline_array_assign_bounds_fail80:
  %trap_stderr263 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr263, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.57, i32 82, ptr %trap_written264, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok79:
  %inline_array_assign_slot265 = getelementptr i8, ptr %mutable_ptr147, i64 %assignment_index261
  store i8 %inline_array_item260, ptr %inline_array_assign_slot265, align 1
  %index_size266 = sext i32 7 to i64
  %inline_array_in_bounds267 = icmp ult i64 %index_size266, %mutable_len148
  br i1 %inline_array_in_bounds267, label %bb_inline_array_bounds_ok81, label %bb_inline_array_bounds_fail82

bb_inline_array_bounds_fail82:
  %trap_stderr268 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr268, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.58, i32 75, ptr %trap_written269, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok81:
  %inline_array_slot270 = getelementptr i8, ptr %mutable_ptr147, i64 %index_size266
  %inline_array_item271 = load i8, ptr %inline_array_slot270, align 1
  %assignment_index272 = sext i32 11 to i64
  %inline_array_assign_in_bounds273 = icmp ult i64 %assignment_index272, %mutable_len148
  br i1 %inline_array_assign_in_bounds273, label %bb_inline_array_assign_bounds_ok83, label %bb_inline_array_assign_bounds_fail84

bb_inline_array_assign_bounds_fail84:
  %trap_stderr274 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr274, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.59, i32 82, ptr %trap_written275, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok83:
  %inline_array_assign_slot276 = getelementptr i8, ptr %mutable_ptr147, i64 %assignment_index272
  store i8 %inline_array_item271, ptr %inline_array_assign_slot276, align 1
  %assignment_index277 = sext i32 7 to i64
  %inline_array_assign_in_bounds278 = icmp ult i64 %assignment_index277, %mutable_len148
  br i1 %inline_array_assign_in_bounds278, label %bb_inline_array_assign_bounds_ok85, label %bb_inline_array_assign_bounds_fail86

bb_inline_array_assign_bounds_fail86:
  %trap_stderr279 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr279, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.60, i32 82, ptr %trap_written280, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok85:
  %inline_array_assign_slot281 = getelementptr i8, ptr %mutable_ptr147, i64 %assignment_index277
  store i8 %inline_array_item243, ptr %inline_array_assign_slot281, align 1
  %mutable_ptr282 = load ptr, ptr %mutable_ptr_addr28, align 8
  %mutable_len283 = load i64, ptr %mutable_len_addr29, align 8
  %mutable_capacity284 = load i64, ptr %mutable_capacity_addr30, align 8
  store i32 0, ptr %mutable_scalar_slot285, align 4
  br label %bb_while_condition87
bb_while_condition87:
  %mutable_scalar286 = load i32, ptr %mutable_scalar_slot285, align 4
  %cmp287 = icmp slt i32 %mutable_scalar286, 4
  br i1 %cmp287, label %bb_while_body88, label %bb_while_end89
bb_while_body88:
  %mutable_scalar288 = load i32, ptr %mutable_scalar_slot285, align 4
  %mul289 = mul i32 %mutable_scalar288, 4
  %index_size290 = sext i32 %mul289 to i64
  %inline_array_in_bounds291 = icmp ult i64 %index_size290, %mutable_len283
  br i1 %inline_array_in_bounds291, label %bb_inline_array_bounds_ok90, label %bb_inline_array_bounds_fail91

bb_inline_array_bounds_fail91:
  %trap_stderr292 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr292, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.61, i32 76, ptr %trap_written293, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok90:
  %inline_array_slot294 = getelementptr i8, ptr %mutable_ptr282, i64 %index_size290
  %inline_array_item295 = load i8, ptr %inline_array_slot294, align 1
  %add296 = add i32 %mul289, 1
  %index_size297 = sext i32 %add296 to i64
  %inline_array_in_bounds298 = icmp ult i64 %index_size297, %mutable_len283
  br i1 %inline_array_in_bounds298, label %bb_inline_array_bounds_ok92, label %bb_inline_array_bounds_fail93

bb_inline_array_bounds_fail93:
  %trap_stderr299 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr299, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.62, i32 76, ptr %trap_written300, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok92:
  %inline_array_slot301 = getelementptr i8, ptr %mutable_ptr282, i64 %index_size297
  %inline_array_item302 = load i8, ptr %inline_array_slot301, align 1
  %add303 = add i32 %mul289, 2
  %index_size304 = sext i32 %add303 to i64
  %inline_array_in_bounds305 = icmp ult i64 %index_size304, %mutable_len283
  br i1 %inline_array_in_bounds305, label %bb_inline_array_bounds_ok94, label %bb_inline_array_bounds_fail95

bb_inline_array_bounds_fail95:
  %trap_stderr306 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr306, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.63, i32 76, ptr %trap_written307, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok94:
  %inline_array_slot308 = getelementptr i8, ptr %mutable_ptr282, i64 %index_size304
  %inline_array_item309 = load i8, ptr %inline_array_slot308, align 1
  %add310 = add i32 %mul289, 3
  %index_size311 = sext i32 %add310 to i64
  %inline_array_in_bounds312 = icmp ult i64 %index_size311, %mutable_len283
  br i1 %inline_array_in_bounds312, label %bb_inline_array_bounds_ok96, label %bb_inline_array_bounds_fail97

bb_inline_array_bounds_fail97:
  %trap_stderr313 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr313, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.64, i32 76, ptr %trap_written314, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok96:
  %inline_array_slot315 = getelementptr i8, ptr %mutable_ptr282, i64 %index_size311
  %inline_array_item316 = load i8, ptr %inline_array_slot315, align 1
  %numeric_convert317 = zext i8 %inline_array_item295 to i32
  %cmp318 = icmp ult i32 %numeric_convert317, 128
  br i1 %cmp318, label %bb_if_then98, label %bb_if_else99
bb_if_then98:
  %mul319 = mul i32 %numeric_convert317, 2
  %numeric_upper_bound320 = icmp ule i32 %mul319, 255
  br i1 %numeric_upper_bound320, label %bb_numeric_conversion_upper_ok101, label %bb_numeric_conversion_upper_fail102

bb_numeric_conversion_upper_fail102:
  %trap_stderr321 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr321, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.65, i32 66, ptr %trap_written322, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok101:
  %numeric_convert323 = trunc i32 %mul319 to i8
  br label %bb_if_end100
bb_if_else99:
  %mul324 = mul i32 %numeric_convert317, 2
  %mod325 = urem i32 %mul324, 256
  store i32 0, ptr %mutable_scalar_slot326, align 4
  store i32 1, ptr %mutable_scalar_slot327, align 4
  store i32 0, ptr %mutable_scalar_slot328, align 4
  br label %bb_while_condition103
bb_while_condition103:
  %mutable_scalar329 = load i32, ptr %mutable_scalar_slot328, align 4
  %cmp330 = icmp ult i32 %mutable_scalar329, 32
  br i1 %cmp330, label %bb_while_body104, label %bb_while_end105
bb_while_body104:
  %mutable_scalar331 = load i32, ptr %mutable_scalar_slot327, align 4
  %div332 = udiv i32 %mod325, %mutable_scalar331
  %mod333 = urem i32 %div332, 2
  %mutable_scalar334 = load i32, ptr %mutable_scalar_slot327, align 4
  %div335 = udiv i32 27, %mutable_scalar334
  %mod336 = urem i32 %div335, 2
  %cmp337 = icmp ne i32 %mod333, %mod336
  br i1 %cmp337, label %bb_if_then106, label %bb_if_end107
bb_if_then106:
  %mutable_scalar338 = load i32, ptr %mutable_scalar_slot326, align 4
  %mutable_scalar339 = load i32, ptr %mutable_scalar_slot327, align 4
  %add340 = add i32 %mutable_scalar338, %mutable_scalar339
  store i32 %add340, ptr %mutable_scalar_slot326, align 4
  br label %bb_if_end107
bb_if_end107:
  %mutable_scalar341 = load i32, ptr %mutable_scalar_slot328, align 4
  %add342 = add i32 %mutable_scalar341, 1
  store i32 %add342, ptr %mutable_scalar_slot328, align 4
  %mutable_scalar343 = load i32, ptr %mutable_scalar_slot328, align 4
  %cmp344 = icmp ult i32 %mutable_scalar343, 32
  br i1 %cmp344, label %bb_if_then108, label %bb_if_end109
bb_if_then108:
  %mutable_scalar345 = load i32, ptr %mutable_scalar_slot327, align 4
  %mul346 = mul i32 %mutable_scalar345, 2
  store i32 %mul346, ptr %mutable_scalar_slot327, align 4
  br label %bb_if_end109
bb_if_end109:
  br label %bb_while_condition103
bb_while_end105:
  %mutable_scalar347 = load i32, ptr %mutable_scalar_slot326, align 4
  %numeric_upper_bound348 = icmp ule i32 %mutable_scalar347, 255
  br i1 %numeric_upper_bound348, label %bb_numeric_conversion_upper_ok110, label %bb_numeric_conversion_upper_fail111

bb_numeric_conversion_upper_fail111:
  %trap_stderr349 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr349, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.66, i32 66, ptr %trap_written350, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok110:
  %numeric_convert351 = trunc i32 %mutable_scalar347 to i8
  br label %bb_if_end100
bb_if_end100:
  %if352 = phi i8 [ %numeric_convert323, %bb_numeric_conversion_upper_ok101 ], [ %numeric_convert351, %bb_numeric_conversion_upper_ok110 ]
  %numeric_convert353 = zext i8 %inline_array_item302 to i32
  %cmp354 = icmp ult i32 %numeric_convert353, 128
  br i1 %cmp354, label %bb_if_then112, label %bb_if_else113
bb_if_then112:
  %mul355 = mul i32 %numeric_convert353, 2
  %numeric_upper_bound356 = icmp ule i32 %mul355, 255
  br i1 %numeric_upper_bound356, label %bb_numeric_conversion_upper_ok115, label %bb_numeric_conversion_upper_fail116

bb_numeric_conversion_upper_fail116:
  %trap_stderr357 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr357, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.67, i32 66, ptr %trap_written358, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok115:
  %numeric_convert359 = trunc i32 %mul355 to i8
  br label %bb_if_end114
bb_if_else113:
  %mul360 = mul i32 %numeric_convert353, 2
  %mod361 = urem i32 %mul360, 256
  store i32 0, ptr %mutable_scalar_slot362, align 4
  store i32 1, ptr %mutable_scalar_slot363, align 4
  store i32 0, ptr %mutable_scalar_slot364, align 4
  br label %bb_while_condition117
bb_while_condition117:
  %mutable_scalar365 = load i32, ptr %mutable_scalar_slot364, align 4
  %cmp366 = icmp ult i32 %mutable_scalar365, 32
  br i1 %cmp366, label %bb_while_body118, label %bb_while_end119
bb_while_body118:
  %mutable_scalar367 = load i32, ptr %mutable_scalar_slot363, align 4
  %div368 = udiv i32 %mod361, %mutable_scalar367
  %mod369 = urem i32 %div368, 2
  %mutable_scalar370 = load i32, ptr %mutable_scalar_slot363, align 4
  %div371 = udiv i32 27, %mutable_scalar370
  %mod372 = urem i32 %div371, 2
  %cmp373 = icmp ne i32 %mod369, %mod372
  br i1 %cmp373, label %bb_if_then120, label %bb_if_end121
bb_if_then120:
  %mutable_scalar374 = load i32, ptr %mutable_scalar_slot362, align 4
  %mutable_scalar375 = load i32, ptr %mutable_scalar_slot363, align 4
  %add376 = add i32 %mutable_scalar374, %mutable_scalar375
  store i32 %add376, ptr %mutable_scalar_slot362, align 4
  br label %bb_if_end121
bb_if_end121:
  %mutable_scalar377 = load i32, ptr %mutable_scalar_slot364, align 4
  %add378 = add i32 %mutable_scalar377, 1
  store i32 %add378, ptr %mutable_scalar_slot364, align 4
  %mutable_scalar379 = load i32, ptr %mutable_scalar_slot364, align 4
  %cmp380 = icmp ult i32 %mutable_scalar379, 32
  br i1 %cmp380, label %bb_if_then122, label %bb_if_end123
bb_if_then122:
  %mutable_scalar381 = load i32, ptr %mutable_scalar_slot363, align 4
  %mul382 = mul i32 %mutable_scalar381, 2
  store i32 %mul382, ptr %mutable_scalar_slot363, align 4
  br label %bb_if_end123
bb_if_end123:
  br label %bb_while_condition117
bb_while_end119:
  %mutable_scalar383 = load i32, ptr %mutable_scalar_slot362, align 4
  %numeric_upper_bound384 = icmp ule i32 %mutable_scalar383, 255
  br i1 %numeric_upper_bound384, label %bb_numeric_conversion_upper_ok124, label %bb_numeric_conversion_upper_fail125

bb_numeric_conversion_upper_fail125:
  %trap_stderr385 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr385, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.68, i32 66, ptr %trap_written386, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok124:
  %numeric_convert387 = trunc i32 %mutable_scalar383 to i8
  br label %bb_if_end114
bb_if_end114:
  %if388 = phi i8 [ %numeric_convert359, %bb_numeric_conversion_upper_ok115 ], [ %numeric_convert387, %bb_numeric_conversion_upper_ok124 ]
  %numeric_convert389 = zext i8 %if388 to i32
  %numeric_convert390 = zext i8 %inline_array_item302 to i32
  store i32 0, ptr %mutable_scalar_slot391, align 4
  store i32 1, ptr %mutable_scalar_slot392, align 4
  store i32 0, ptr %mutable_scalar_slot393, align 4
  br label %bb_while_condition126
bb_while_condition126:
  %mutable_scalar394 = load i32, ptr %mutable_scalar_slot393, align 4
  %cmp395 = icmp ult i32 %mutable_scalar394, 32
  br i1 %cmp395, label %bb_while_body127, label %bb_while_end128
bb_while_body127:
  %mutable_scalar396 = load i32, ptr %mutable_scalar_slot392, align 4
  %div397 = udiv i32 %numeric_convert389, %mutable_scalar396
  %mod398 = urem i32 %div397, 2
  %mutable_scalar399 = load i32, ptr %mutable_scalar_slot392, align 4
  %div400 = udiv i32 %numeric_convert390, %mutable_scalar399
  %mod401 = urem i32 %div400, 2
  %cmp402 = icmp ne i32 %mod398, %mod401
  br i1 %cmp402, label %bb_if_then129, label %bb_if_end130
bb_if_then129:
  %mutable_scalar403 = load i32, ptr %mutable_scalar_slot391, align 4
  %mutable_scalar404 = load i32, ptr %mutable_scalar_slot392, align 4
  %add405 = add i32 %mutable_scalar403, %mutable_scalar404
  store i32 %add405, ptr %mutable_scalar_slot391, align 4
  br label %bb_if_end130
bb_if_end130:
  %mutable_scalar406 = load i32, ptr %mutable_scalar_slot393, align 4
  %add407 = add i32 %mutable_scalar406, 1
  store i32 %add407, ptr %mutable_scalar_slot393, align 4
  %mutable_scalar408 = load i32, ptr %mutable_scalar_slot393, align 4
  %cmp409 = icmp ult i32 %mutable_scalar408, 32
  br i1 %cmp409, label %bb_if_then131, label %bb_if_end132
bb_if_then131:
  %mutable_scalar410 = load i32, ptr %mutable_scalar_slot392, align 4
  %mul411 = mul i32 %mutable_scalar410, 2
  store i32 %mul411, ptr %mutable_scalar_slot392, align 4
  br label %bb_if_end132
bb_if_end132:
  br label %bb_while_condition126
bb_while_end128:
  %mutable_scalar412 = load i32, ptr %mutable_scalar_slot391, align 4
  %numeric_upper_bound413 = icmp ule i32 %mutable_scalar412, 255
  br i1 %numeric_upper_bound413, label %bb_numeric_conversion_upper_ok133, label %bb_numeric_conversion_upper_fail134

bb_numeric_conversion_upper_fail134:
  %trap_stderr414 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr414, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.69, i32 68, ptr %trap_written415, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok133:
  %numeric_convert416 = trunc i32 %mutable_scalar412 to i8
  %numeric_convert417 = zext i8 %if352 to i32
  %numeric_convert418 = zext i8 %numeric_convert416 to i32
  store i32 0, ptr %mutable_scalar_slot419, align 4
  store i32 1, ptr %mutable_scalar_slot420, align 4
  store i32 0, ptr %mutable_scalar_slot421, align 4
  br label %bb_while_condition135
bb_while_condition135:
  %mutable_scalar422 = load i32, ptr %mutable_scalar_slot421, align 4
  %cmp423 = icmp ult i32 %mutable_scalar422, 32
  br i1 %cmp423, label %bb_while_body136, label %bb_while_end137
bb_while_body136:
  %mutable_scalar424 = load i32, ptr %mutable_scalar_slot420, align 4
  %div425 = udiv i32 %numeric_convert417, %mutable_scalar424
  %mod426 = urem i32 %div425, 2
  %mutable_scalar427 = load i32, ptr %mutable_scalar_slot420, align 4
  %div428 = udiv i32 %numeric_convert418, %mutable_scalar427
  %mod429 = urem i32 %div428, 2
  %cmp430 = icmp ne i32 %mod426, %mod429
  br i1 %cmp430, label %bb_if_then138, label %bb_if_end139
bb_if_then138:
  %mutable_scalar431 = load i32, ptr %mutable_scalar_slot419, align 4
  %mutable_scalar432 = load i32, ptr %mutable_scalar_slot420, align 4
  %add433 = add i32 %mutable_scalar431, %mutable_scalar432
  store i32 %add433, ptr %mutable_scalar_slot419, align 4
  br label %bb_if_end139
bb_if_end139:
  %mutable_scalar434 = load i32, ptr %mutable_scalar_slot421, align 4
  %add435 = add i32 %mutable_scalar434, 1
  store i32 %add435, ptr %mutable_scalar_slot421, align 4
  %mutable_scalar436 = load i32, ptr %mutable_scalar_slot421, align 4
  %cmp437 = icmp ult i32 %mutable_scalar436, 32
  br i1 %cmp437, label %bb_if_then140, label %bb_if_end141
bb_if_then140:
  %mutable_scalar438 = load i32, ptr %mutable_scalar_slot420, align 4
  %mul439 = mul i32 %mutable_scalar438, 2
  store i32 %mul439, ptr %mutable_scalar_slot420, align 4
  br label %bb_if_end141
bb_if_end141:
  br label %bb_while_condition135
bb_while_end137:
  %mutable_scalar440 = load i32, ptr %mutable_scalar_slot419, align 4
  %numeric_upper_bound441 = icmp ule i32 %mutable_scalar440, 255
  br i1 %numeric_upper_bound441, label %bb_numeric_conversion_upper_ok142, label %bb_numeric_conversion_upper_fail143

bb_numeric_conversion_upper_fail143:
  %trap_stderr442 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr442, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.70, i32 68, ptr %trap_written443, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok142:
  %numeric_convert444 = trunc i32 %mutable_scalar440 to i8
  %numeric_convert445 = zext i8 %numeric_convert444 to i32
  %numeric_convert446 = zext i8 %inline_array_item309 to i32
  store i32 0, ptr %mutable_scalar_slot447, align 4
  store i32 1, ptr %mutable_scalar_slot448, align 4
  store i32 0, ptr %mutable_scalar_slot449, align 4
  br label %bb_while_condition144
bb_while_condition144:
  %mutable_scalar450 = load i32, ptr %mutable_scalar_slot449, align 4
  %cmp451 = icmp ult i32 %mutable_scalar450, 32
  br i1 %cmp451, label %bb_while_body145, label %bb_while_end146
bb_while_body145:
  %mutable_scalar452 = load i32, ptr %mutable_scalar_slot448, align 4
  %div453 = udiv i32 %numeric_convert445, %mutable_scalar452
  %mod454 = urem i32 %div453, 2
  %mutable_scalar455 = load i32, ptr %mutable_scalar_slot448, align 4
  %div456 = udiv i32 %numeric_convert446, %mutable_scalar455
  %mod457 = urem i32 %div456, 2
  %cmp458 = icmp ne i32 %mod454, %mod457
  br i1 %cmp458, label %bb_if_then147, label %bb_if_end148
bb_if_then147:
  %mutable_scalar459 = load i32, ptr %mutable_scalar_slot447, align 4
  %mutable_scalar460 = load i32, ptr %mutable_scalar_slot448, align 4
  %add461 = add i32 %mutable_scalar459, %mutable_scalar460
  store i32 %add461, ptr %mutable_scalar_slot447, align 4
  br label %bb_if_end148
bb_if_end148:
  %mutable_scalar462 = load i32, ptr %mutable_scalar_slot449, align 4
  %add463 = add i32 %mutable_scalar462, 1
  store i32 %add463, ptr %mutable_scalar_slot449, align 4
  %mutable_scalar464 = load i32, ptr %mutable_scalar_slot449, align 4
  %cmp465 = icmp ult i32 %mutable_scalar464, 32
  br i1 %cmp465, label %bb_if_then149, label %bb_if_end150
bb_if_then149:
  %mutable_scalar466 = load i32, ptr %mutable_scalar_slot448, align 4
  %mul467 = mul i32 %mutable_scalar466, 2
  store i32 %mul467, ptr %mutable_scalar_slot448, align 4
  br label %bb_if_end150
bb_if_end150:
  br label %bb_while_condition144
bb_while_end146:
  %mutable_scalar468 = load i32, ptr %mutable_scalar_slot447, align 4
  %numeric_upper_bound469 = icmp ule i32 %mutable_scalar468, 255
  br i1 %numeric_upper_bound469, label %bb_numeric_conversion_upper_ok151, label %bb_numeric_conversion_upper_fail152

bb_numeric_conversion_upper_fail152:
  %trap_stderr470 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr470, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.71, i32 68, ptr %trap_written471, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok151:
  %numeric_convert472 = trunc i32 %mutable_scalar468 to i8
  %numeric_convert473 = zext i8 %numeric_convert472 to i32
  %numeric_convert474 = zext i8 %inline_array_item316 to i32
  store i32 0, ptr %mutable_scalar_slot475, align 4
  store i32 1, ptr %mutable_scalar_slot476, align 4
  store i32 0, ptr %mutable_scalar_slot477, align 4
  br label %bb_while_condition153
bb_while_condition153:
  %mutable_scalar478 = load i32, ptr %mutable_scalar_slot477, align 4
  %cmp479 = icmp ult i32 %mutable_scalar478, 32
  br i1 %cmp479, label %bb_while_body154, label %bb_while_end155
bb_while_body154:
  %mutable_scalar480 = load i32, ptr %mutable_scalar_slot476, align 4
  %div481 = udiv i32 %numeric_convert473, %mutable_scalar480
  %mod482 = urem i32 %div481, 2
  %mutable_scalar483 = load i32, ptr %mutable_scalar_slot476, align 4
  %div484 = udiv i32 %numeric_convert474, %mutable_scalar483
  %mod485 = urem i32 %div484, 2
  %cmp486 = icmp ne i32 %mod482, %mod485
  br i1 %cmp486, label %bb_if_then156, label %bb_if_end157
bb_if_then156:
  %mutable_scalar487 = load i32, ptr %mutable_scalar_slot475, align 4
  %mutable_scalar488 = load i32, ptr %mutable_scalar_slot476, align 4
  %add489 = add i32 %mutable_scalar487, %mutable_scalar488
  store i32 %add489, ptr %mutable_scalar_slot475, align 4
  br label %bb_if_end157
bb_if_end157:
  %mutable_scalar490 = load i32, ptr %mutable_scalar_slot477, align 4
  %add491 = add i32 %mutable_scalar490, 1
  store i32 %add491, ptr %mutable_scalar_slot477, align 4
  %mutable_scalar492 = load i32, ptr %mutable_scalar_slot477, align 4
  %cmp493 = icmp ult i32 %mutable_scalar492, 32
  br i1 %cmp493, label %bb_if_then158, label %bb_if_end159
bb_if_then158:
  %mutable_scalar494 = load i32, ptr %mutable_scalar_slot476, align 4
  %mul495 = mul i32 %mutable_scalar494, 2
  store i32 %mul495, ptr %mutable_scalar_slot476, align 4
  br label %bb_if_end159
bb_if_end159:
  br label %bb_while_condition153
bb_while_end155:
  %mutable_scalar496 = load i32, ptr %mutable_scalar_slot475, align 4
  %numeric_upper_bound497 = icmp ule i32 %mutable_scalar496, 255
  br i1 %numeric_upper_bound497, label %bb_numeric_conversion_upper_ok160, label %bb_numeric_conversion_upper_fail161

bb_numeric_conversion_upper_fail161:
  %trap_stderr498 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr498, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.72, i32 68, ptr %trap_written499, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok160:
  %numeric_convert500 = trunc i32 %mutable_scalar496 to i8
  %assignment_index501 = sext i32 %mul289 to i64
  %inline_array_assign_in_bounds502 = icmp ult i64 %assignment_index501, %mutable_len283
  br i1 %inline_array_assign_in_bounds502, label %bb_inline_array_assign_bounds_ok162, label %bb_inline_array_assign_bounds_fail163

bb_inline_array_assign_bounds_fail163:
  %trap_stderr503 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr503, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.73, i32 84, ptr %trap_written504, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok162:
  %inline_array_assign_slot505 = getelementptr i8, ptr %mutable_ptr282, i64 %assignment_index501
  store i8 %numeric_convert500, ptr %inline_array_assign_slot505, align 1
  %numeric_convert506 = zext i8 %inline_array_item302 to i32
  %cmp507 = icmp ult i32 %numeric_convert506, 128
  br i1 %cmp507, label %bb_if_then164, label %bb_if_else165
bb_if_then164:
  %mul508 = mul i32 %numeric_convert506, 2
  %numeric_upper_bound509 = icmp ule i32 %mul508, 255
  br i1 %numeric_upper_bound509, label %bb_numeric_conversion_upper_ok167, label %bb_numeric_conversion_upper_fail168

bb_numeric_conversion_upper_fail168:
  %trap_stderr510 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr510, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.74, i32 66, ptr %trap_written511, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok167:
  %numeric_convert512 = trunc i32 %mul508 to i8
  br label %bb_if_end166
bb_if_else165:
  %mul513 = mul i32 %numeric_convert506, 2
  %mod514 = urem i32 %mul513, 256
  store i32 0, ptr %mutable_scalar_slot515, align 4
  store i32 1, ptr %mutable_scalar_slot516, align 4
  store i32 0, ptr %mutable_scalar_slot517, align 4
  br label %bb_while_condition169
bb_while_condition169:
  %mutable_scalar518 = load i32, ptr %mutable_scalar_slot517, align 4
  %cmp519 = icmp ult i32 %mutable_scalar518, 32
  br i1 %cmp519, label %bb_while_body170, label %bb_while_end171
bb_while_body170:
  %mutable_scalar520 = load i32, ptr %mutable_scalar_slot516, align 4
  %div521 = udiv i32 %mod514, %mutable_scalar520
  %mod522 = urem i32 %div521, 2
  %mutable_scalar523 = load i32, ptr %mutable_scalar_slot516, align 4
  %div524 = udiv i32 27, %mutable_scalar523
  %mod525 = urem i32 %div524, 2
  %cmp526 = icmp ne i32 %mod522, %mod525
  br i1 %cmp526, label %bb_if_then172, label %bb_if_end173
bb_if_then172:
  %mutable_scalar527 = load i32, ptr %mutable_scalar_slot515, align 4
  %mutable_scalar528 = load i32, ptr %mutable_scalar_slot516, align 4
  %add529 = add i32 %mutable_scalar527, %mutable_scalar528
  store i32 %add529, ptr %mutable_scalar_slot515, align 4
  br label %bb_if_end173
bb_if_end173:
  %mutable_scalar530 = load i32, ptr %mutable_scalar_slot517, align 4
  %add531 = add i32 %mutable_scalar530, 1
  store i32 %add531, ptr %mutable_scalar_slot517, align 4
  %mutable_scalar532 = load i32, ptr %mutable_scalar_slot517, align 4
  %cmp533 = icmp ult i32 %mutable_scalar532, 32
  br i1 %cmp533, label %bb_if_then174, label %bb_if_end175
bb_if_then174:
  %mutable_scalar534 = load i32, ptr %mutable_scalar_slot516, align 4
  %mul535 = mul i32 %mutable_scalar534, 2
  store i32 %mul535, ptr %mutable_scalar_slot516, align 4
  br label %bb_if_end175
bb_if_end175:
  br label %bb_while_condition169
bb_while_end171:
  %mutable_scalar536 = load i32, ptr %mutable_scalar_slot515, align 4
  %numeric_upper_bound537 = icmp ule i32 %mutable_scalar536, 255
  br i1 %numeric_upper_bound537, label %bb_numeric_conversion_upper_ok176, label %bb_numeric_conversion_upper_fail177

bb_numeric_conversion_upper_fail177:
  %trap_stderr538 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr538, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.75, i32 66, ptr %trap_written539, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok176:
  %numeric_convert540 = trunc i32 %mutable_scalar536 to i8
  br label %bb_if_end166
bb_if_end166:
  %if541 = phi i8 [ %numeric_convert512, %bb_numeric_conversion_upper_ok167 ], [ %numeric_convert540, %bb_numeric_conversion_upper_ok176 ]
  %numeric_convert542 = zext i8 %inline_array_item295 to i32
  %numeric_convert543 = zext i8 %if541 to i32
  store i32 0, ptr %mutable_scalar_slot544, align 4
  store i32 1, ptr %mutable_scalar_slot545, align 4
  store i32 0, ptr %mutable_scalar_slot546, align 4
  br label %bb_while_condition178
bb_while_condition178:
  %mutable_scalar547 = load i32, ptr %mutable_scalar_slot546, align 4
  %cmp548 = icmp ult i32 %mutable_scalar547, 32
  br i1 %cmp548, label %bb_while_body179, label %bb_while_end180
bb_while_body179:
  %mutable_scalar549 = load i32, ptr %mutable_scalar_slot545, align 4
  %div550 = udiv i32 %numeric_convert542, %mutable_scalar549
  %mod551 = urem i32 %div550, 2
  %mutable_scalar552 = load i32, ptr %mutable_scalar_slot545, align 4
  %div553 = udiv i32 %numeric_convert543, %mutable_scalar552
  %mod554 = urem i32 %div553, 2
  %cmp555 = icmp ne i32 %mod551, %mod554
  br i1 %cmp555, label %bb_if_then181, label %bb_if_end182
bb_if_then181:
  %mutable_scalar556 = load i32, ptr %mutable_scalar_slot544, align 4
  %mutable_scalar557 = load i32, ptr %mutable_scalar_slot545, align 4
  %add558 = add i32 %mutable_scalar556, %mutable_scalar557
  store i32 %add558, ptr %mutable_scalar_slot544, align 4
  br label %bb_if_end182
bb_if_end182:
  %mutable_scalar559 = load i32, ptr %mutable_scalar_slot546, align 4
  %add560 = add i32 %mutable_scalar559, 1
  store i32 %add560, ptr %mutable_scalar_slot546, align 4
  %mutable_scalar561 = load i32, ptr %mutable_scalar_slot546, align 4
  %cmp562 = icmp ult i32 %mutable_scalar561, 32
  br i1 %cmp562, label %bb_if_then183, label %bb_if_end184
bb_if_then183:
  %mutable_scalar563 = load i32, ptr %mutable_scalar_slot545, align 4
  %mul564 = mul i32 %mutable_scalar563, 2
  store i32 %mul564, ptr %mutable_scalar_slot545, align 4
  br label %bb_if_end184
bb_if_end184:
  br label %bb_while_condition178
bb_while_end180:
  %mutable_scalar565 = load i32, ptr %mutable_scalar_slot544, align 4
  %numeric_upper_bound566 = icmp ule i32 %mutable_scalar565, 255
  br i1 %numeric_upper_bound566, label %bb_numeric_conversion_upper_ok185, label %bb_numeric_conversion_upper_fail186

bb_numeric_conversion_upper_fail186:
  %trap_stderr567 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr567, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.76, i32 68, ptr %trap_written568, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok185:
  %numeric_convert569 = trunc i32 %mutable_scalar565 to i8
  %numeric_convert570 = zext i8 %inline_array_item309 to i32
  %cmp571 = icmp ult i32 %numeric_convert570, 128
  br i1 %cmp571, label %bb_if_then187, label %bb_if_else188
bb_if_then187:
  %mul572 = mul i32 %numeric_convert570, 2
  %numeric_upper_bound573 = icmp ule i32 %mul572, 255
  br i1 %numeric_upper_bound573, label %bb_numeric_conversion_upper_ok190, label %bb_numeric_conversion_upper_fail191

bb_numeric_conversion_upper_fail191:
  %trap_stderr574 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr574, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.77, i32 66, ptr %trap_written575, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok190:
  %numeric_convert576 = trunc i32 %mul572 to i8
  br label %bb_if_end189
bb_if_else188:
  %mul577 = mul i32 %numeric_convert570, 2
  %mod578 = urem i32 %mul577, 256
  store i32 0, ptr %mutable_scalar_slot579, align 4
  store i32 1, ptr %mutable_scalar_slot580, align 4
  store i32 0, ptr %mutable_scalar_slot581, align 4
  br label %bb_while_condition192
bb_while_condition192:
  %mutable_scalar582 = load i32, ptr %mutable_scalar_slot581, align 4
  %cmp583 = icmp ult i32 %mutable_scalar582, 32
  br i1 %cmp583, label %bb_while_body193, label %bb_while_end194
bb_while_body193:
  %mutable_scalar584 = load i32, ptr %mutable_scalar_slot580, align 4
  %div585 = udiv i32 %mod578, %mutable_scalar584
  %mod586 = urem i32 %div585, 2
  %mutable_scalar587 = load i32, ptr %mutable_scalar_slot580, align 4
  %div588 = udiv i32 27, %mutable_scalar587
  %mod589 = urem i32 %div588, 2
  %cmp590 = icmp ne i32 %mod586, %mod589
  br i1 %cmp590, label %bb_if_then195, label %bb_if_end196
bb_if_then195:
  %mutable_scalar591 = load i32, ptr %mutable_scalar_slot579, align 4
  %mutable_scalar592 = load i32, ptr %mutable_scalar_slot580, align 4
  %add593 = add i32 %mutable_scalar591, %mutable_scalar592
  store i32 %add593, ptr %mutable_scalar_slot579, align 4
  br label %bb_if_end196
bb_if_end196:
  %mutable_scalar594 = load i32, ptr %mutable_scalar_slot581, align 4
  %add595 = add i32 %mutable_scalar594, 1
  store i32 %add595, ptr %mutable_scalar_slot581, align 4
  %mutable_scalar596 = load i32, ptr %mutable_scalar_slot581, align 4
  %cmp597 = icmp ult i32 %mutable_scalar596, 32
  br i1 %cmp597, label %bb_if_then197, label %bb_if_end198
bb_if_then197:
  %mutable_scalar598 = load i32, ptr %mutable_scalar_slot580, align 4
  %mul599 = mul i32 %mutable_scalar598, 2
  store i32 %mul599, ptr %mutable_scalar_slot580, align 4
  br label %bb_if_end198
bb_if_end198:
  br label %bb_while_condition192
bb_while_end194:
  %mutable_scalar600 = load i32, ptr %mutable_scalar_slot579, align 4
  %numeric_upper_bound601 = icmp ule i32 %mutable_scalar600, 255
  br i1 %numeric_upper_bound601, label %bb_numeric_conversion_upper_ok199, label %bb_numeric_conversion_upper_fail200

bb_numeric_conversion_upper_fail200:
  %trap_stderr602 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr602, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.78, i32 66, ptr %trap_written603, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok199:
  %numeric_convert604 = trunc i32 %mutable_scalar600 to i8
  br label %bb_if_end189
bb_if_end189:
  %if605 = phi i8 [ %numeric_convert576, %bb_numeric_conversion_upper_ok190 ], [ %numeric_convert604, %bb_numeric_conversion_upper_ok199 ]
  %numeric_convert606 = zext i8 %if605 to i32
  %numeric_convert607 = zext i8 %inline_array_item309 to i32
  store i32 0, ptr %mutable_scalar_slot608, align 4
  store i32 1, ptr %mutable_scalar_slot609, align 4
  store i32 0, ptr %mutable_scalar_slot610, align 4
  br label %bb_while_condition201
bb_while_condition201:
  %mutable_scalar611 = load i32, ptr %mutable_scalar_slot610, align 4
  %cmp612 = icmp ult i32 %mutable_scalar611, 32
  br i1 %cmp612, label %bb_while_body202, label %bb_while_end203
bb_while_body202:
  %mutable_scalar613 = load i32, ptr %mutable_scalar_slot609, align 4
  %div614 = udiv i32 %numeric_convert606, %mutable_scalar613
  %mod615 = urem i32 %div614, 2
  %mutable_scalar616 = load i32, ptr %mutable_scalar_slot609, align 4
  %div617 = udiv i32 %numeric_convert607, %mutable_scalar616
  %mod618 = urem i32 %div617, 2
  %cmp619 = icmp ne i32 %mod615, %mod618
  br i1 %cmp619, label %bb_if_then204, label %bb_if_end205
bb_if_then204:
  %mutable_scalar620 = load i32, ptr %mutable_scalar_slot608, align 4
  %mutable_scalar621 = load i32, ptr %mutable_scalar_slot609, align 4
  %add622 = add i32 %mutable_scalar620, %mutable_scalar621
  store i32 %add622, ptr %mutable_scalar_slot608, align 4
  br label %bb_if_end205
bb_if_end205:
  %mutable_scalar623 = load i32, ptr %mutable_scalar_slot610, align 4
  %add624 = add i32 %mutable_scalar623, 1
  store i32 %add624, ptr %mutable_scalar_slot610, align 4
  %mutable_scalar625 = load i32, ptr %mutable_scalar_slot610, align 4
  %cmp626 = icmp ult i32 %mutable_scalar625, 32
  br i1 %cmp626, label %bb_if_then206, label %bb_if_end207
bb_if_then206:
  %mutable_scalar627 = load i32, ptr %mutable_scalar_slot609, align 4
  %mul628 = mul i32 %mutable_scalar627, 2
  store i32 %mul628, ptr %mutable_scalar_slot609, align 4
  br label %bb_if_end207
bb_if_end207:
  br label %bb_while_condition201
bb_while_end203:
  %mutable_scalar629 = load i32, ptr %mutable_scalar_slot608, align 4
  %numeric_upper_bound630 = icmp ule i32 %mutable_scalar629, 255
  br i1 %numeric_upper_bound630, label %bb_numeric_conversion_upper_ok208, label %bb_numeric_conversion_upper_fail209

bb_numeric_conversion_upper_fail209:
  %trap_stderr631 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr631, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.79, i32 68, ptr %trap_written632, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok208:
  %numeric_convert633 = trunc i32 %mutable_scalar629 to i8
  %numeric_convert634 = zext i8 %numeric_convert569 to i32
  %numeric_convert635 = zext i8 %numeric_convert633 to i32
  store i32 0, ptr %mutable_scalar_slot636, align 4
  store i32 1, ptr %mutable_scalar_slot637, align 4
  store i32 0, ptr %mutable_scalar_slot638, align 4
  br label %bb_while_condition210
bb_while_condition210:
  %mutable_scalar639 = load i32, ptr %mutable_scalar_slot638, align 4
  %cmp640 = icmp ult i32 %mutable_scalar639, 32
  br i1 %cmp640, label %bb_while_body211, label %bb_while_end212
bb_while_body211:
  %mutable_scalar641 = load i32, ptr %mutable_scalar_slot637, align 4
  %div642 = udiv i32 %numeric_convert634, %mutable_scalar641
  %mod643 = urem i32 %div642, 2
  %mutable_scalar644 = load i32, ptr %mutable_scalar_slot637, align 4
  %div645 = udiv i32 %numeric_convert635, %mutable_scalar644
  %mod646 = urem i32 %div645, 2
  %cmp647 = icmp ne i32 %mod643, %mod646
  br i1 %cmp647, label %bb_if_then213, label %bb_if_end214
bb_if_then213:
  %mutable_scalar648 = load i32, ptr %mutable_scalar_slot636, align 4
  %mutable_scalar649 = load i32, ptr %mutable_scalar_slot637, align 4
  %add650 = add i32 %mutable_scalar648, %mutable_scalar649
  store i32 %add650, ptr %mutable_scalar_slot636, align 4
  br label %bb_if_end214
bb_if_end214:
  %mutable_scalar651 = load i32, ptr %mutable_scalar_slot638, align 4
  %add652 = add i32 %mutable_scalar651, 1
  store i32 %add652, ptr %mutable_scalar_slot638, align 4
  %mutable_scalar653 = load i32, ptr %mutable_scalar_slot638, align 4
  %cmp654 = icmp ult i32 %mutable_scalar653, 32
  br i1 %cmp654, label %bb_if_then215, label %bb_if_end216
bb_if_then215:
  %mutable_scalar655 = load i32, ptr %mutable_scalar_slot637, align 4
  %mul656 = mul i32 %mutable_scalar655, 2
  store i32 %mul656, ptr %mutable_scalar_slot637, align 4
  br label %bb_if_end216
bb_if_end216:
  br label %bb_while_condition210
bb_while_end212:
  %mutable_scalar657 = load i32, ptr %mutable_scalar_slot636, align 4
  %numeric_upper_bound658 = icmp ule i32 %mutable_scalar657, 255
  br i1 %numeric_upper_bound658, label %bb_numeric_conversion_upper_ok217, label %bb_numeric_conversion_upper_fail218

bb_numeric_conversion_upper_fail218:
  %trap_stderr659 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr659, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.80, i32 68, ptr %trap_written660, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok217:
  %numeric_convert661 = trunc i32 %mutable_scalar657 to i8
  %numeric_convert662 = zext i8 %numeric_convert661 to i32
  %numeric_convert663 = zext i8 %inline_array_item316 to i32
  store i32 0, ptr %mutable_scalar_slot664, align 4
  store i32 1, ptr %mutable_scalar_slot665, align 4
  store i32 0, ptr %mutable_scalar_slot666, align 4
  br label %bb_while_condition219
bb_while_condition219:
  %mutable_scalar667 = load i32, ptr %mutable_scalar_slot666, align 4
  %cmp668 = icmp ult i32 %mutable_scalar667, 32
  br i1 %cmp668, label %bb_while_body220, label %bb_while_end221
bb_while_body220:
  %mutable_scalar669 = load i32, ptr %mutable_scalar_slot665, align 4
  %div670 = udiv i32 %numeric_convert662, %mutable_scalar669
  %mod671 = urem i32 %div670, 2
  %mutable_scalar672 = load i32, ptr %mutable_scalar_slot665, align 4
  %div673 = udiv i32 %numeric_convert663, %mutable_scalar672
  %mod674 = urem i32 %div673, 2
  %cmp675 = icmp ne i32 %mod671, %mod674
  br i1 %cmp675, label %bb_if_then222, label %bb_if_end223
bb_if_then222:
  %mutable_scalar676 = load i32, ptr %mutable_scalar_slot664, align 4
  %mutable_scalar677 = load i32, ptr %mutable_scalar_slot665, align 4
  %add678 = add i32 %mutable_scalar676, %mutable_scalar677
  store i32 %add678, ptr %mutable_scalar_slot664, align 4
  br label %bb_if_end223
bb_if_end223:
  %mutable_scalar679 = load i32, ptr %mutable_scalar_slot666, align 4
  %add680 = add i32 %mutable_scalar679, 1
  store i32 %add680, ptr %mutable_scalar_slot666, align 4
  %mutable_scalar681 = load i32, ptr %mutable_scalar_slot666, align 4
  %cmp682 = icmp ult i32 %mutable_scalar681, 32
  br i1 %cmp682, label %bb_if_then224, label %bb_if_end225
bb_if_then224:
  %mutable_scalar683 = load i32, ptr %mutable_scalar_slot665, align 4
  %mul684 = mul i32 %mutable_scalar683, 2
  store i32 %mul684, ptr %mutable_scalar_slot665, align 4
  br label %bb_if_end225
bb_if_end225:
  br label %bb_while_condition219
bb_while_end221:
  %mutable_scalar685 = load i32, ptr %mutable_scalar_slot664, align 4
  %numeric_upper_bound686 = icmp ule i32 %mutable_scalar685, 255
  br i1 %numeric_upper_bound686, label %bb_numeric_conversion_upper_ok226, label %bb_numeric_conversion_upper_fail227

bb_numeric_conversion_upper_fail227:
  %trap_stderr687 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr687, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.81, i32 68, ptr %trap_written688, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok226:
  %numeric_convert689 = trunc i32 %mutable_scalar685 to i8
  %add690 = add i32 %mul289, 1
  %assignment_index691 = sext i32 %add690 to i64
  %inline_array_assign_in_bounds692 = icmp ult i64 %assignment_index691, %mutable_len283
  br i1 %inline_array_assign_in_bounds692, label %bb_inline_array_assign_bounds_ok228, label %bb_inline_array_assign_bounds_fail229

bb_inline_array_assign_bounds_fail229:
  %trap_stderr693 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr693, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.82, i32 84, ptr %trap_written694, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok228:
  %inline_array_assign_slot695 = getelementptr i8, ptr %mutable_ptr282, i64 %assignment_index691
  store i8 %numeric_convert689, ptr %inline_array_assign_slot695, align 1
  %numeric_convert696 = zext i8 %inline_array_item295 to i32
  %numeric_convert697 = zext i8 %inline_array_item302 to i32
  store i32 0, ptr %mutable_scalar_slot698, align 4
  store i32 1, ptr %mutable_scalar_slot699, align 4
  store i32 0, ptr %mutable_scalar_slot700, align 4
  br label %bb_while_condition230
bb_while_condition230:
  %mutable_scalar701 = load i32, ptr %mutable_scalar_slot700, align 4
  %cmp702 = icmp ult i32 %mutable_scalar701, 32
  br i1 %cmp702, label %bb_while_body231, label %bb_while_end232
bb_while_body231:
  %mutable_scalar703 = load i32, ptr %mutable_scalar_slot699, align 4
  %div704 = udiv i32 %numeric_convert696, %mutable_scalar703
  %mod705 = urem i32 %div704, 2
  %mutable_scalar706 = load i32, ptr %mutable_scalar_slot699, align 4
  %div707 = udiv i32 %numeric_convert697, %mutable_scalar706
  %mod708 = urem i32 %div707, 2
  %cmp709 = icmp ne i32 %mod705, %mod708
  br i1 %cmp709, label %bb_if_then233, label %bb_if_end234
bb_if_then233:
  %mutable_scalar710 = load i32, ptr %mutable_scalar_slot698, align 4
  %mutable_scalar711 = load i32, ptr %mutable_scalar_slot699, align 4
  %add712 = add i32 %mutable_scalar710, %mutable_scalar711
  store i32 %add712, ptr %mutable_scalar_slot698, align 4
  br label %bb_if_end234
bb_if_end234:
  %mutable_scalar713 = load i32, ptr %mutable_scalar_slot700, align 4
  %add714 = add i32 %mutable_scalar713, 1
  store i32 %add714, ptr %mutable_scalar_slot700, align 4
  %mutable_scalar715 = load i32, ptr %mutable_scalar_slot700, align 4
  %cmp716 = icmp ult i32 %mutable_scalar715, 32
  br i1 %cmp716, label %bb_if_then235, label %bb_if_end236
bb_if_then235:
  %mutable_scalar717 = load i32, ptr %mutable_scalar_slot699, align 4
  %mul718 = mul i32 %mutable_scalar717, 2
  store i32 %mul718, ptr %mutable_scalar_slot699, align 4
  br label %bb_if_end236
bb_if_end236:
  br label %bb_while_condition230
bb_while_end232:
  %mutable_scalar719 = load i32, ptr %mutable_scalar_slot698, align 4
  %numeric_upper_bound720 = icmp ule i32 %mutable_scalar719, 255
  br i1 %numeric_upper_bound720, label %bb_numeric_conversion_upper_ok237, label %bb_numeric_conversion_upper_fail238

bb_numeric_conversion_upper_fail238:
  %trap_stderr721 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr721, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.83, i32 68, ptr %trap_written722, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok237:
  %numeric_convert723 = trunc i32 %mutable_scalar719 to i8
  %numeric_convert724 = zext i8 %inline_array_item309 to i32
  %cmp725 = icmp ult i32 %numeric_convert724, 128
  br i1 %cmp725, label %bb_if_then239, label %bb_if_else240
bb_if_then239:
  %mul726 = mul i32 %numeric_convert724, 2
  %numeric_upper_bound727 = icmp ule i32 %mul726, 255
  br i1 %numeric_upper_bound727, label %bb_numeric_conversion_upper_ok242, label %bb_numeric_conversion_upper_fail243

bb_numeric_conversion_upper_fail243:
  %trap_stderr728 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr728, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.84, i32 66, ptr %trap_written729, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok242:
  %numeric_convert730 = trunc i32 %mul726 to i8
  br label %bb_if_end241
bb_if_else240:
  %mul731 = mul i32 %numeric_convert724, 2
  %mod732 = urem i32 %mul731, 256
  store i32 0, ptr %mutable_scalar_slot733, align 4
  store i32 1, ptr %mutable_scalar_slot734, align 4
  store i32 0, ptr %mutable_scalar_slot735, align 4
  br label %bb_while_condition244
bb_while_condition244:
  %mutable_scalar736 = load i32, ptr %mutable_scalar_slot735, align 4
  %cmp737 = icmp ult i32 %mutable_scalar736, 32
  br i1 %cmp737, label %bb_while_body245, label %bb_while_end246
bb_while_body245:
  %mutable_scalar738 = load i32, ptr %mutable_scalar_slot734, align 4
  %div739 = udiv i32 %mod732, %mutable_scalar738
  %mod740 = urem i32 %div739, 2
  %mutable_scalar741 = load i32, ptr %mutable_scalar_slot734, align 4
  %div742 = udiv i32 27, %mutable_scalar741
  %mod743 = urem i32 %div742, 2
  %cmp744 = icmp ne i32 %mod740, %mod743
  br i1 %cmp744, label %bb_if_then247, label %bb_if_end248
bb_if_then247:
  %mutable_scalar745 = load i32, ptr %mutable_scalar_slot733, align 4
  %mutable_scalar746 = load i32, ptr %mutable_scalar_slot734, align 4
  %add747 = add i32 %mutable_scalar745, %mutable_scalar746
  store i32 %add747, ptr %mutable_scalar_slot733, align 4
  br label %bb_if_end248
bb_if_end248:
  %mutable_scalar748 = load i32, ptr %mutable_scalar_slot735, align 4
  %add749 = add i32 %mutable_scalar748, 1
  store i32 %add749, ptr %mutable_scalar_slot735, align 4
  %mutable_scalar750 = load i32, ptr %mutable_scalar_slot735, align 4
  %cmp751 = icmp ult i32 %mutable_scalar750, 32
  br i1 %cmp751, label %bb_if_then249, label %bb_if_end250
bb_if_then249:
  %mutable_scalar752 = load i32, ptr %mutable_scalar_slot734, align 4
  %mul753 = mul i32 %mutable_scalar752, 2
  store i32 %mul753, ptr %mutable_scalar_slot734, align 4
  br label %bb_if_end250
bb_if_end250:
  br label %bb_while_condition244
bb_while_end246:
  %mutable_scalar754 = load i32, ptr %mutable_scalar_slot733, align 4
  %numeric_upper_bound755 = icmp ule i32 %mutable_scalar754, 255
  br i1 %numeric_upper_bound755, label %bb_numeric_conversion_upper_ok251, label %bb_numeric_conversion_upper_fail252

bb_numeric_conversion_upper_fail252:
  %trap_stderr756 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr756, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.85, i32 66, ptr %trap_written757, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok251:
  %numeric_convert758 = trunc i32 %mutable_scalar754 to i8
  br label %bb_if_end241
bb_if_end241:
  %if759 = phi i8 [ %numeric_convert730, %bb_numeric_conversion_upper_ok242 ], [ %numeric_convert758, %bb_numeric_conversion_upper_ok251 ]
  %numeric_convert760 = zext i8 %numeric_convert723 to i32
  %numeric_convert761 = zext i8 %if759 to i32
  store i32 0, ptr %mutable_scalar_slot762, align 4
  store i32 1, ptr %mutable_scalar_slot763, align 4
  store i32 0, ptr %mutable_scalar_slot764, align 4
  br label %bb_while_condition253
bb_while_condition253:
  %mutable_scalar765 = load i32, ptr %mutable_scalar_slot764, align 4
  %cmp766 = icmp ult i32 %mutable_scalar765, 32
  br i1 %cmp766, label %bb_while_body254, label %bb_while_end255
bb_while_body254:
  %mutable_scalar767 = load i32, ptr %mutable_scalar_slot763, align 4
  %div768 = udiv i32 %numeric_convert760, %mutable_scalar767
  %mod769 = urem i32 %div768, 2
  %mutable_scalar770 = load i32, ptr %mutable_scalar_slot763, align 4
  %div771 = udiv i32 %numeric_convert761, %mutable_scalar770
  %mod772 = urem i32 %div771, 2
  %cmp773 = icmp ne i32 %mod769, %mod772
  br i1 %cmp773, label %bb_if_then256, label %bb_if_end257
bb_if_then256:
  %mutable_scalar774 = load i32, ptr %mutable_scalar_slot762, align 4
  %mutable_scalar775 = load i32, ptr %mutable_scalar_slot763, align 4
  %add776 = add i32 %mutable_scalar774, %mutable_scalar775
  store i32 %add776, ptr %mutable_scalar_slot762, align 4
  br label %bb_if_end257
bb_if_end257:
  %mutable_scalar777 = load i32, ptr %mutable_scalar_slot764, align 4
  %add778 = add i32 %mutable_scalar777, 1
  store i32 %add778, ptr %mutable_scalar_slot764, align 4
  %mutable_scalar779 = load i32, ptr %mutable_scalar_slot764, align 4
  %cmp780 = icmp ult i32 %mutable_scalar779, 32
  br i1 %cmp780, label %bb_if_then258, label %bb_if_end259
bb_if_then258:
  %mutable_scalar781 = load i32, ptr %mutable_scalar_slot763, align 4
  %mul782 = mul i32 %mutable_scalar781, 2
  store i32 %mul782, ptr %mutable_scalar_slot763, align 4
  br label %bb_if_end259
bb_if_end259:
  br label %bb_while_condition253
bb_while_end255:
  %mutable_scalar783 = load i32, ptr %mutable_scalar_slot762, align 4
  %numeric_upper_bound784 = icmp ule i32 %mutable_scalar783, 255
  br i1 %numeric_upper_bound784, label %bb_numeric_conversion_upper_ok260, label %bb_numeric_conversion_upper_fail261

bb_numeric_conversion_upper_fail261:
  %trap_stderr785 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr785, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.86, i32 68, ptr %trap_written786, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok260:
  %numeric_convert787 = trunc i32 %mutable_scalar783 to i8
  %numeric_convert788 = zext i8 %inline_array_item316 to i32
  %cmp789 = icmp ult i32 %numeric_convert788, 128
  br i1 %cmp789, label %bb_if_then262, label %bb_if_else263
bb_if_then262:
  %mul790 = mul i32 %numeric_convert788, 2
  %numeric_upper_bound791 = icmp ule i32 %mul790, 255
  br i1 %numeric_upper_bound791, label %bb_numeric_conversion_upper_ok265, label %bb_numeric_conversion_upper_fail266

bb_numeric_conversion_upper_fail266:
  %trap_stderr792 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr792, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.87, i32 66, ptr %trap_written793, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok265:
  %numeric_convert794 = trunc i32 %mul790 to i8
  br label %bb_if_end264
bb_if_else263:
  %mul795 = mul i32 %numeric_convert788, 2
  %mod796 = urem i32 %mul795, 256
  store i32 0, ptr %mutable_scalar_slot797, align 4
  store i32 1, ptr %mutable_scalar_slot798, align 4
  store i32 0, ptr %mutable_scalar_slot799, align 4
  br label %bb_while_condition267
bb_while_condition267:
  %mutable_scalar800 = load i32, ptr %mutable_scalar_slot799, align 4
  %cmp801 = icmp ult i32 %mutable_scalar800, 32
  br i1 %cmp801, label %bb_while_body268, label %bb_while_end269
bb_while_body268:
  %mutable_scalar802 = load i32, ptr %mutable_scalar_slot798, align 4
  %div803 = udiv i32 %mod796, %mutable_scalar802
  %mod804 = urem i32 %div803, 2
  %mutable_scalar805 = load i32, ptr %mutable_scalar_slot798, align 4
  %div806 = udiv i32 27, %mutable_scalar805
  %mod807 = urem i32 %div806, 2
  %cmp808 = icmp ne i32 %mod804, %mod807
  br i1 %cmp808, label %bb_if_then270, label %bb_if_end271
bb_if_then270:
  %mutable_scalar809 = load i32, ptr %mutable_scalar_slot797, align 4
  %mutable_scalar810 = load i32, ptr %mutable_scalar_slot798, align 4
  %add811 = add i32 %mutable_scalar809, %mutable_scalar810
  store i32 %add811, ptr %mutable_scalar_slot797, align 4
  br label %bb_if_end271
bb_if_end271:
  %mutable_scalar812 = load i32, ptr %mutable_scalar_slot799, align 4
  %add813 = add i32 %mutable_scalar812, 1
  store i32 %add813, ptr %mutable_scalar_slot799, align 4
  %mutable_scalar814 = load i32, ptr %mutable_scalar_slot799, align 4
  %cmp815 = icmp ult i32 %mutable_scalar814, 32
  br i1 %cmp815, label %bb_if_then272, label %bb_if_end273
bb_if_then272:
  %mutable_scalar816 = load i32, ptr %mutable_scalar_slot798, align 4
  %mul817 = mul i32 %mutable_scalar816, 2
  store i32 %mul817, ptr %mutable_scalar_slot798, align 4
  br label %bb_if_end273
bb_if_end273:
  br label %bb_while_condition267
bb_while_end269:
  %mutable_scalar818 = load i32, ptr %mutable_scalar_slot797, align 4
  %numeric_upper_bound819 = icmp ule i32 %mutable_scalar818, 255
  br i1 %numeric_upper_bound819, label %bb_numeric_conversion_upper_ok274, label %bb_numeric_conversion_upper_fail275

bb_numeric_conversion_upper_fail275:
  %trap_stderr820 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr820, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.88, i32 66, ptr %trap_written821, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok274:
  %numeric_convert822 = trunc i32 %mutable_scalar818 to i8
  br label %bb_if_end264
bb_if_end264:
  %if823 = phi i8 [ %numeric_convert794, %bb_numeric_conversion_upper_ok265 ], [ %numeric_convert822, %bb_numeric_conversion_upper_ok274 ]
  %numeric_convert824 = zext i8 %if823 to i32
  %numeric_convert825 = zext i8 %inline_array_item316 to i32
  store i32 0, ptr %mutable_scalar_slot826, align 4
  store i32 1, ptr %mutable_scalar_slot827, align 4
  store i32 0, ptr %mutable_scalar_slot828, align 4
  br label %bb_while_condition276
bb_while_condition276:
  %mutable_scalar829 = load i32, ptr %mutable_scalar_slot828, align 4
  %cmp830 = icmp ult i32 %mutable_scalar829, 32
  br i1 %cmp830, label %bb_while_body277, label %bb_while_end278
bb_while_body277:
  %mutable_scalar831 = load i32, ptr %mutable_scalar_slot827, align 4
  %div832 = udiv i32 %numeric_convert824, %mutable_scalar831
  %mod833 = urem i32 %div832, 2
  %mutable_scalar834 = load i32, ptr %mutable_scalar_slot827, align 4
  %div835 = udiv i32 %numeric_convert825, %mutable_scalar834
  %mod836 = urem i32 %div835, 2
  %cmp837 = icmp ne i32 %mod833, %mod836
  br i1 %cmp837, label %bb_if_then279, label %bb_if_end280
bb_if_then279:
  %mutable_scalar838 = load i32, ptr %mutable_scalar_slot826, align 4
  %mutable_scalar839 = load i32, ptr %mutable_scalar_slot827, align 4
  %add840 = add i32 %mutable_scalar838, %mutable_scalar839
  store i32 %add840, ptr %mutable_scalar_slot826, align 4
  br label %bb_if_end280
bb_if_end280:
  %mutable_scalar841 = load i32, ptr %mutable_scalar_slot828, align 4
  %add842 = add i32 %mutable_scalar841, 1
  store i32 %add842, ptr %mutable_scalar_slot828, align 4
  %mutable_scalar843 = load i32, ptr %mutable_scalar_slot828, align 4
  %cmp844 = icmp ult i32 %mutable_scalar843, 32
  br i1 %cmp844, label %bb_if_then281, label %bb_if_end282
bb_if_then281:
  %mutable_scalar845 = load i32, ptr %mutable_scalar_slot827, align 4
  %mul846 = mul i32 %mutable_scalar845, 2
  store i32 %mul846, ptr %mutable_scalar_slot827, align 4
  br label %bb_if_end282
bb_if_end282:
  br label %bb_while_condition276
bb_while_end278:
  %mutable_scalar847 = load i32, ptr %mutable_scalar_slot826, align 4
  %numeric_upper_bound848 = icmp ule i32 %mutable_scalar847, 255
  br i1 %numeric_upper_bound848, label %bb_numeric_conversion_upper_ok283, label %bb_numeric_conversion_upper_fail284

bb_numeric_conversion_upper_fail284:
  %trap_stderr849 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr849, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.89, i32 68, ptr %trap_written850, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok283:
  %numeric_convert851 = trunc i32 %mutable_scalar847 to i8
  %numeric_convert852 = zext i8 %numeric_convert787 to i32
  %numeric_convert853 = zext i8 %numeric_convert851 to i32
  store i32 0, ptr %mutable_scalar_slot854, align 4
  store i32 1, ptr %mutable_scalar_slot855, align 4
  store i32 0, ptr %mutable_scalar_slot856, align 4
  br label %bb_while_condition285
bb_while_condition285:
  %mutable_scalar857 = load i32, ptr %mutable_scalar_slot856, align 4
  %cmp858 = icmp ult i32 %mutable_scalar857, 32
  br i1 %cmp858, label %bb_while_body286, label %bb_while_end287
bb_while_body286:
  %mutable_scalar859 = load i32, ptr %mutable_scalar_slot855, align 4
  %div860 = udiv i32 %numeric_convert852, %mutable_scalar859
  %mod861 = urem i32 %div860, 2
  %mutable_scalar862 = load i32, ptr %mutable_scalar_slot855, align 4
  %div863 = udiv i32 %numeric_convert853, %mutable_scalar862
  %mod864 = urem i32 %div863, 2
  %cmp865 = icmp ne i32 %mod861, %mod864
  br i1 %cmp865, label %bb_if_then288, label %bb_if_end289
bb_if_then288:
  %mutable_scalar866 = load i32, ptr %mutable_scalar_slot854, align 4
  %mutable_scalar867 = load i32, ptr %mutable_scalar_slot855, align 4
  %add868 = add i32 %mutable_scalar866, %mutable_scalar867
  store i32 %add868, ptr %mutable_scalar_slot854, align 4
  br label %bb_if_end289
bb_if_end289:
  %mutable_scalar869 = load i32, ptr %mutable_scalar_slot856, align 4
  %add870 = add i32 %mutable_scalar869, 1
  store i32 %add870, ptr %mutable_scalar_slot856, align 4
  %mutable_scalar871 = load i32, ptr %mutable_scalar_slot856, align 4
  %cmp872 = icmp ult i32 %mutable_scalar871, 32
  br i1 %cmp872, label %bb_if_then290, label %bb_if_end291
bb_if_then290:
  %mutable_scalar873 = load i32, ptr %mutable_scalar_slot855, align 4
  %mul874 = mul i32 %mutable_scalar873, 2
  store i32 %mul874, ptr %mutable_scalar_slot855, align 4
  br label %bb_if_end291
bb_if_end291:
  br label %bb_while_condition285
bb_while_end287:
  %mutable_scalar875 = load i32, ptr %mutable_scalar_slot854, align 4
  %numeric_upper_bound876 = icmp ule i32 %mutable_scalar875, 255
  br i1 %numeric_upper_bound876, label %bb_numeric_conversion_upper_ok292, label %bb_numeric_conversion_upper_fail293

bb_numeric_conversion_upper_fail293:
  %trap_stderr877 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr877, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.90, i32 68, ptr %trap_written878, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok292:
  %numeric_convert879 = trunc i32 %mutable_scalar875 to i8
  %add880 = add i32 %mul289, 2
  %assignment_index881 = sext i32 %add880 to i64
  %inline_array_assign_in_bounds882 = icmp ult i64 %assignment_index881, %mutable_len283
  br i1 %inline_array_assign_in_bounds882, label %bb_inline_array_assign_bounds_ok294, label %bb_inline_array_assign_bounds_fail295

bb_inline_array_assign_bounds_fail295:
  %trap_stderr883 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr883, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.91, i32 84, ptr %trap_written884, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok294:
  %inline_array_assign_slot885 = getelementptr i8, ptr %mutable_ptr282, i64 %assignment_index881
  store i8 %numeric_convert879, ptr %inline_array_assign_slot885, align 1
  %numeric_convert886 = zext i8 %inline_array_item295 to i32
  %cmp887 = icmp ult i32 %numeric_convert886, 128
  br i1 %cmp887, label %bb_if_then296, label %bb_if_else297
bb_if_then296:
  %mul888 = mul i32 %numeric_convert886, 2
  %numeric_upper_bound889 = icmp ule i32 %mul888, 255
  br i1 %numeric_upper_bound889, label %bb_numeric_conversion_upper_ok299, label %bb_numeric_conversion_upper_fail300

bb_numeric_conversion_upper_fail300:
  %trap_stderr890 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr890, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.92, i32 66, ptr %trap_written891, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok299:
  %numeric_convert892 = trunc i32 %mul888 to i8
  br label %bb_if_end298
bb_if_else297:
  %mul893 = mul i32 %numeric_convert886, 2
  %mod894 = urem i32 %mul893, 256
  store i32 0, ptr %mutable_scalar_slot895, align 4
  store i32 1, ptr %mutable_scalar_slot896, align 4
  store i32 0, ptr %mutable_scalar_slot897, align 4
  br label %bb_while_condition301
bb_while_condition301:
  %mutable_scalar898 = load i32, ptr %mutable_scalar_slot897, align 4
  %cmp899 = icmp ult i32 %mutable_scalar898, 32
  br i1 %cmp899, label %bb_while_body302, label %bb_while_end303
bb_while_body302:
  %mutable_scalar900 = load i32, ptr %mutable_scalar_slot896, align 4
  %div901 = udiv i32 %mod894, %mutable_scalar900
  %mod902 = urem i32 %div901, 2
  %mutable_scalar903 = load i32, ptr %mutable_scalar_slot896, align 4
  %div904 = udiv i32 27, %mutable_scalar903
  %mod905 = urem i32 %div904, 2
  %cmp906 = icmp ne i32 %mod902, %mod905
  br i1 %cmp906, label %bb_if_then304, label %bb_if_end305
bb_if_then304:
  %mutable_scalar907 = load i32, ptr %mutable_scalar_slot895, align 4
  %mutable_scalar908 = load i32, ptr %mutable_scalar_slot896, align 4
  %add909 = add i32 %mutable_scalar907, %mutable_scalar908
  store i32 %add909, ptr %mutable_scalar_slot895, align 4
  br label %bb_if_end305
bb_if_end305:
  %mutable_scalar910 = load i32, ptr %mutable_scalar_slot897, align 4
  %add911 = add i32 %mutable_scalar910, 1
  store i32 %add911, ptr %mutable_scalar_slot897, align 4
  %mutable_scalar912 = load i32, ptr %mutable_scalar_slot897, align 4
  %cmp913 = icmp ult i32 %mutable_scalar912, 32
  br i1 %cmp913, label %bb_if_then306, label %bb_if_end307
bb_if_then306:
  %mutable_scalar914 = load i32, ptr %mutable_scalar_slot896, align 4
  %mul915 = mul i32 %mutable_scalar914, 2
  store i32 %mul915, ptr %mutable_scalar_slot896, align 4
  br label %bb_if_end307
bb_if_end307:
  br label %bb_while_condition301
bb_while_end303:
  %mutable_scalar916 = load i32, ptr %mutable_scalar_slot895, align 4
  %numeric_upper_bound917 = icmp ule i32 %mutable_scalar916, 255
  br i1 %numeric_upper_bound917, label %bb_numeric_conversion_upper_ok308, label %bb_numeric_conversion_upper_fail309

bb_numeric_conversion_upper_fail309:
  %trap_stderr918 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr918, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.93, i32 66, ptr %trap_written919, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok308:
  %numeric_convert920 = trunc i32 %mutable_scalar916 to i8
  br label %bb_if_end298
bb_if_end298:
  %if921 = phi i8 [ %numeric_convert892, %bb_numeric_conversion_upper_ok299 ], [ %numeric_convert920, %bb_numeric_conversion_upper_ok308 ]
  %numeric_convert922 = zext i8 %if921 to i32
  %numeric_convert923 = zext i8 %inline_array_item295 to i32
  store i32 0, ptr %mutable_scalar_slot924, align 4
  store i32 1, ptr %mutable_scalar_slot925, align 4
  store i32 0, ptr %mutable_scalar_slot926, align 4
  br label %bb_while_condition310
bb_while_condition310:
  %mutable_scalar927 = load i32, ptr %mutable_scalar_slot926, align 4
  %cmp928 = icmp ult i32 %mutable_scalar927, 32
  br i1 %cmp928, label %bb_while_body311, label %bb_while_end312
bb_while_body311:
  %mutable_scalar929 = load i32, ptr %mutable_scalar_slot925, align 4
  %div930 = udiv i32 %numeric_convert922, %mutable_scalar929
  %mod931 = urem i32 %div930, 2
  %mutable_scalar932 = load i32, ptr %mutable_scalar_slot925, align 4
  %div933 = udiv i32 %numeric_convert923, %mutable_scalar932
  %mod934 = urem i32 %div933, 2
  %cmp935 = icmp ne i32 %mod931, %mod934
  br i1 %cmp935, label %bb_if_then313, label %bb_if_end314
bb_if_then313:
  %mutable_scalar936 = load i32, ptr %mutable_scalar_slot924, align 4
  %mutable_scalar937 = load i32, ptr %mutable_scalar_slot925, align 4
  %add938 = add i32 %mutable_scalar936, %mutable_scalar937
  store i32 %add938, ptr %mutable_scalar_slot924, align 4
  br label %bb_if_end314
bb_if_end314:
  %mutable_scalar939 = load i32, ptr %mutable_scalar_slot926, align 4
  %add940 = add i32 %mutable_scalar939, 1
  store i32 %add940, ptr %mutable_scalar_slot926, align 4
  %mutable_scalar941 = load i32, ptr %mutable_scalar_slot926, align 4
  %cmp942 = icmp ult i32 %mutable_scalar941, 32
  br i1 %cmp942, label %bb_if_then315, label %bb_if_end316
bb_if_then315:
  %mutable_scalar943 = load i32, ptr %mutable_scalar_slot925, align 4
  %mul944 = mul i32 %mutable_scalar943, 2
  store i32 %mul944, ptr %mutable_scalar_slot925, align 4
  br label %bb_if_end316
bb_if_end316:
  br label %bb_while_condition310
bb_while_end312:
  %mutable_scalar945 = load i32, ptr %mutable_scalar_slot924, align 4
  %numeric_upper_bound946 = icmp ule i32 %mutable_scalar945, 255
  br i1 %numeric_upper_bound946, label %bb_numeric_conversion_upper_ok317, label %bb_numeric_conversion_upper_fail318

bb_numeric_conversion_upper_fail318:
  %trap_stderr947 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr947, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.94, i32 68, ptr %trap_written948, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok317:
  %numeric_convert949 = trunc i32 %mutable_scalar945 to i8
  %numeric_convert950 = zext i8 %numeric_convert949 to i32
  %numeric_convert951 = zext i8 %inline_array_item302 to i32
  store i32 0, ptr %mutable_scalar_slot952, align 4
  store i32 1, ptr %mutable_scalar_slot953, align 4
  store i32 0, ptr %mutable_scalar_slot954, align 4
  br label %bb_while_condition319
bb_while_condition319:
  %mutable_scalar955 = load i32, ptr %mutable_scalar_slot954, align 4
  %cmp956 = icmp ult i32 %mutable_scalar955, 32
  br i1 %cmp956, label %bb_while_body320, label %bb_while_end321
bb_while_body320:
  %mutable_scalar957 = load i32, ptr %mutable_scalar_slot953, align 4
  %div958 = udiv i32 %numeric_convert950, %mutable_scalar957
  %mod959 = urem i32 %div958, 2
  %mutable_scalar960 = load i32, ptr %mutable_scalar_slot953, align 4
  %div961 = udiv i32 %numeric_convert951, %mutable_scalar960
  %mod962 = urem i32 %div961, 2
  %cmp963 = icmp ne i32 %mod959, %mod962
  br i1 %cmp963, label %bb_if_then322, label %bb_if_end323
bb_if_then322:
  %mutable_scalar964 = load i32, ptr %mutable_scalar_slot952, align 4
  %mutable_scalar965 = load i32, ptr %mutable_scalar_slot953, align 4
  %add966 = add i32 %mutable_scalar964, %mutable_scalar965
  store i32 %add966, ptr %mutable_scalar_slot952, align 4
  br label %bb_if_end323
bb_if_end323:
  %mutable_scalar967 = load i32, ptr %mutable_scalar_slot954, align 4
  %add968 = add i32 %mutable_scalar967, 1
  store i32 %add968, ptr %mutable_scalar_slot954, align 4
  %mutable_scalar969 = load i32, ptr %mutable_scalar_slot954, align 4
  %cmp970 = icmp ult i32 %mutable_scalar969, 32
  br i1 %cmp970, label %bb_if_then324, label %bb_if_end325
bb_if_then324:
  %mutable_scalar971 = load i32, ptr %mutable_scalar_slot953, align 4
  %mul972 = mul i32 %mutable_scalar971, 2
  store i32 %mul972, ptr %mutable_scalar_slot953, align 4
  br label %bb_if_end325
bb_if_end325:
  br label %bb_while_condition319
bb_while_end321:
  %mutable_scalar973 = load i32, ptr %mutable_scalar_slot952, align 4
  %numeric_upper_bound974 = icmp ule i32 %mutable_scalar973, 255
  br i1 %numeric_upper_bound974, label %bb_numeric_conversion_upper_ok326, label %bb_numeric_conversion_upper_fail327

bb_numeric_conversion_upper_fail327:
  %trap_stderr975 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr975, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.95, i32 68, ptr %trap_written976, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok326:
  %numeric_convert977 = trunc i32 %mutable_scalar973 to i8
  %numeric_convert978 = zext i8 %numeric_convert977 to i32
  %numeric_convert979 = zext i8 %inline_array_item309 to i32
  store i32 0, ptr %mutable_scalar_slot980, align 4
  store i32 1, ptr %mutable_scalar_slot981, align 4
  store i32 0, ptr %mutable_scalar_slot982, align 4
  br label %bb_while_condition328
bb_while_condition328:
  %mutable_scalar983 = load i32, ptr %mutable_scalar_slot982, align 4
  %cmp984 = icmp ult i32 %mutable_scalar983, 32
  br i1 %cmp984, label %bb_while_body329, label %bb_while_end330
bb_while_body329:
  %mutable_scalar985 = load i32, ptr %mutable_scalar_slot981, align 4
  %div986 = udiv i32 %numeric_convert978, %mutable_scalar985
  %mod987 = urem i32 %div986, 2
  %mutable_scalar988 = load i32, ptr %mutable_scalar_slot981, align 4
  %div989 = udiv i32 %numeric_convert979, %mutable_scalar988
  %mod990 = urem i32 %div989, 2
  %cmp991 = icmp ne i32 %mod987, %mod990
  br i1 %cmp991, label %bb_if_then331, label %bb_if_end332
bb_if_then331:
  %mutable_scalar992 = load i32, ptr %mutable_scalar_slot980, align 4
  %mutable_scalar993 = load i32, ptr %mutable_scalar_slot981, align 4
  %add994 = add i32 %mutable_scalar992, %mutable_scalar993
  store i32 %add994, ptr %mutable_scalar_slot980, align 4
  br label %bb_if_end332
bb_if_end332:
  %mutable_scalar995 = load i32, ptr %mutable_scalar_slot982, align 4
  %add996 = add i32 %mutable_scalar995, 1
  store i32 %add996, ptr %mutable_scalar_slot982, align 4
  %mutable_scalar997 = load i32, ptr %mutable_scalar_slot982, align 4
  %cmp998 = icmp ult i32 %mutable_scalar997, 32
  br i1 %cmp998, label %bb_if_then333, label %bb_if_end334
bb_if_then333:
  %mutable_scalar999 = load i32, ptr %mutable_scalar_slot981, align 4
  %mul1000 = mul i32 %mutable_scalar999, 2
  store i32 %mul1000, ptr %mutable_scalar_slot981, align 4
  br label %bb_if_end334
bb_if_end334:
  br label %bb_while_condition328
bb_while_end330:
  %mutable_scalar1001 = load i32, ptr %mutable_scalar_slot980, align 4
  %numeric_upper_bound1002 = icmp ule i32 %mutable_scalar1001, 255
  br i1 %numeric_upper_bound1002, label %bb_numeric_conversion_upper_ok335, label %bb_numeric_conversion_upper_fail336

bb_numeric_conversion_upper_fail336:
  %trap_stderr1003 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1003, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.96, i32 68, ptr %trap_written1004, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok335:
  %numeric_convert1005 = trunc i32 %mutable_scalar1001 to i8
  %numeric_convert1006 = zext i8 %inline_array_item316 to i32
  %cmp1007 = icmp ult i32 %numeric_convert1006, 128
  br i1 %cmp1007, label %bb_if_then337, label %bb_if_else338
bb_if_then337:
  %mul1008 = mul i32 %numeric_convert1006, 2
  %numeric_upper_bound1009 = icmp ule i32 %mul1008, 255
  br i1 %numeric_upper_bound1009, label %bb_numeric_conversion_upper_ok340, label %bb_numeric_conversion_upper_fail341

bb_numeric_conversion_upper_fail341:
  %trap_stderr1010 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1010, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.97, i32 66, ptr %trap_written1011, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok340:
  %numeric_convert1012 = trunc i32 %mul1008 to i8
  br label %bb_if_end339
bb_if_else338:
  %mul1013 = mul i32 %numeric_convert1006, 2
  %mod1014 = urem i32 %mul1013, 256
  store i32 0, ptr %mutable_scalar_slot1015, align 4
  store i32 1, ptr %mutable_scalar_slot1016, align 4
  store i32 0, ptr %mutable_scalar_slot1017, align 4
  br label %bb_while_condition342
bb_while_condition342:
  %mutable_scalar1018 = load i32, ptr %mutable_scalar_slot1017, align 4
  %cmp1019 = icmp ult i32 %mutable_scalar1018, 32
  br i1 %cmp1019, label %bb_while_body343, label %bb_while_end344
bb_while_body343:
  %mutable_scalar1020 = load i32, ptr %mutable_scalar_slot1016, align 4
  %div1021 = udiv i32 %mod1014, %mutable_scalar1020
  %mod1022 = urem i32 %div1021, 2
  %mutable_scalar1023 = load i32, ptr %mutable_scalar_slot1016, align 4
  %div1024 = udiv i32 27, %mutable_scalar1023
  %mod1025 = urem i32 %div1024, 2
  %cmp1026 = icmp ne i32 %mod1022, %mod1025
  br i1 %cmp1026, label %bb_if_then345, label %bb_if_end346
bb_if_then345:
  %mutable_scalar1027 = load i32, ptr %mutable_scalar_slot1015, align 4
  %mutable_scalar1028 = load i32, ptr %mutable_scalar_slot1016, align 4
  %add1029 = add i32 %mutable_scalar1027, %mutable_scalar1028
  store i32 %add1029, ptr %mutable_scalar_slot1015, align 4
  br label %bb_if_end346
bb_if_end346:
  %mutable_scalar1030 = load i32, ptr %mutable_scalar_slot1017, align 4
  %add1031 = add i32 %mutable_scalar1030, 1
  store i32 %add1031, ptr %mutable_scalar_slot1017, align 4
  %mutable_scalar1032 = load i32, ptr %mutable_scalar_slot1017, align 4
  %cmp1033 = icmp ult i32 %mutable_scalar1032, 32
  br i1 %cmp1033, label %bb_if_then347, label %bb_if_end348
bb_if_then347:
  %mutable_scalar1034 = load i32, ptr %mutable_scalar_slot1016, align 4
  %mul1035 = mul i32 %mutable_scalar1034, 2
  store i32 %mul1035, ptr %mutable_scalar_slot1016, align 4
  br label %bb_if_end348
bb_if_end348:
  br label %bb_while_condition342
bb_while_end344:
  %mutable_scalar1036 = load i32, ptr %mutable_scalar_slot1015, align 4
  %numeric_upper_bound1037 = icmp ule i32 %mutable_scalar1036, 255
  br i1 %numeric_upper_bound1037, label %bb_numeric_conversion_upper_ok349, label %bb_numeric_conversion_upper_fail350

bb_numeric_conversion_upper_fail350:
  %trap_stderr1038 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1038, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.98, i32 66, ptr %trap_written1039, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok349:
  %numeric_convert1040 = trunc i32 %mutable_scalar1036 to i8
  br label %bb_if_end339
bb_if_end339:
  %if1041 = phi i8 [ %numeric_convert1012, %bb_numeric_conversion_upper_ok340 ], [ %numeric_convert1040, %bb_numeric_conversion_upper_ok349 ]
  %numeric_convert1042 = zext i8 %numeric_convert1005 to i32
  %numeric_convert1043 = zext i8 %if1041 to i32
  store i32 0, ptr %mutable_scalar_slot1044, align 4
  store i32 1, ptr %mutable_scalar_slot1045, align 4
  store i32 0, ptr %mutable_scalar_slot1046, align 4
  br label %bb_while_condition351
bb_while_condition351:
  %mutable_scalar1047 = load i32, ptr %mutable_scalar_slot1046, align 4
  %cmp1048 = icmp ult i32 %mutable_scalar1047, 32
  br i1 %cmp1048, label %bb_while_body352, label %bb_while_end353
bb_while_body352:
  %mutable_scalar1049 = load i32, ptr %mutable_scalar_slot1045, align 4
  %div1050 = udiv i32 %numeric_convert1042, %mutable_scalar1049
  %mod1051 = urem i32 %div1050, 2
  %mutable_scalar1052 = load i32, ptr %mutable_scalar_slot1045, align 4
  %div1053 = udiv i32 %numeric_convert1043, %mutable_scalar1052
  %mod1054 = urem i32 %div1053, 2
  %cmp1055 = icmp ne i32 %mod1051, %mod1054
  br i1 %cmp1055, label %bb_if_then354, label %bb_if_end355
bb_if_then354:
  %mutable_scalar1056 = load i32, ptr %mutable_scalar_slot1044, align 4
  %mutable_scalar1057 = load i32, ptr %mutable_scalar_slot1045, align 4
  %add1058 = add i32 %mutable_scalar1056, %mutable_scalar1057
  store i32 %add1058, ptr %mutable_scalar_slot1044, align 4
  br label %bb_if_end355
bb_if_end355:
  %mutable_scalar1059 = load i32, ptr %mutable_scalar_slot1046, align 4
  %add1060 = add i32 %mutable_scalar1059, 1
  store i32 %add1060, ptr %mutable_scalar_slot1046, align 4
  %mutable_scalar1061 = load i32, ptr %mutable_scalar_slot1046, align 4
  %cmp1062 = icmp ult i32 %mutable_scalar1061, 32
  br i1 %cmp1062, label %bb_if_then356, label %bb_if_end357
bb_if_then356:
  %mutable_scalar1063 = load i32, ptr %mutable_scalar_slot1045, align 4
  %mul1064 = mul i32 %mutable_scalar1063, 2
  store i32 %mul1064, ptr %mutable_scalar_slot1045, align 4
  br label %bb_if_end357
bb_if_end357:
  br label %bb_while_condition351
bb_while_end353:
  %mutable_scalar1065 = load i32, ptr %mutable_scalar_slot1044, align 4
  %numeric_upper_bound1066 = icmp ule i32 %mutable_scalar1065, 255
  br i1 %numeric_upper_bound1066, label %bb_numeric_conversion_upper_ok358, label %bb_numeric_conversion_upper_fail359

bb_numeric_conversion_upper_fail359:
  %trap_stderr1067 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1067, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.99, i32 68, ptr %trap_written1068, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok358:
  %numeric_convert1069 = trunc i32 %mutable_scalar1065 to i8
  %add1070 = add i32 %mul289, 3
  %assignment_index1071 = sext i32 %add1070 to i64
  %inline_array_assign_in_bounds1072 = icmp ult i64 %assignment_index1071, %mutable_len283
  br i1 %inline_array_assign_in_bounds1072, label %bb_inline_array_assign_bounds_ok360, label %bb_inline_array_assign_bounds_fail361

bb_inline_array_assign_bounds_fail361:
  %trap_stderr1073 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1073, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.100, i32 84, ptr %trap_written1074, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok360:
  %inline_array_assign_slot1075 = getelementptr i8, ptr %mutable_ptr282, i64 %assignment_index1071
  store i8 %numeric_convert1069, ptr %inline_array_assign_slot1075, align 1
  %mutable_scalar1076 = load i32, ptr %mutable_scalar_slot285, align 4
  %add1077 = add i32 %mutable_scalar1076, 1
  store i32 %add1077, ptr %mutable_scalar_slot285, align 4
  br label %bb_while_condition87
bb_while_end89:
  %mutable_ptr1078 = load ptr, ptr %mutable_ptr_addr28, align 8
  %mutable_len1079 = load i64, ptr %mutable_len_addr29, align 8
  %mutable_capacity1080 = load i64, ptr %mutable_capacity_addr30, align 8
  %field1081 = extractvalue %sollang.struct.1155 %it, 0
  %array_ptr1082 = extractvalue %sollang.dynamic_int_array %field1081, 0
  %array_len1083 = extractvalue %sollang.dynamic_int_array %field1081, 1
  %array_capacity1084 = extractvalue %sollang.dynamic_int_array %field1081, 2
  %mutable_scalar1085 = load i32, ptr %mutable_scalar_slot113, align 4
  %mul1086 = mul i32 %mutable_scalar1085, 16
  store i32 0, ptr %mutable_scalar_slot1087, align 4
  br label %bb_while_condition362
bb_while_condition362:
  %mutable_scalar1088 = load i32, ptr %mutable_scalar_slot1087, align 4
  %cmp1089 = icmp slt i32 %mutable_scalar1088, 16
  br i1 %cmp1089, label %bb_while_body363, label %bb_while_end364
bb_while_body363:
  %mutable_scalar1090 = load i32, ptr %mutable_scalar_slot1087, align 4
  %index_size1091 = sext i32 %mutable_scalar1090 to i64
  %inline_array_in_bounds1092 = icmp ult i64 %index_size1091, %mutable_len1079
  br i1 %inline_array_in_bounds1092, label %bb_inline_array_bounds_ok365, label %bb_inline_array_bounds_fail366

bb_inline_array_bounds_fail366:
  %trap_stderr1093 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1093, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.101, i32 78, ptr %trap_written1094, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok365:
  %inline_array_slot1095 = getelementptr i8, ptr %mutable_ptr1078, i64 %index_size1091
  %inline_array_item1096 = load i8, ptr %inline_array_slot1095, align 1
  %mutable_scalar1097 = load i32, ptr %mutable_scalar_slot1087, align 4
  %add1098 = add i32 %mul1086, %mutable_scalar1097
  %index_size1099 = sext i32 %add1098 to i64
  %slice_in_bounds1100 = icmp ult i64 %index_size1099, %array_len1083
  br i1 %slice_in_bounds1100, label %bb_slice_bounds_ok367, label %bb_slice_bounds_fail368

bb_slice_bounds_fail368:
  %trap_stderr1101 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1101, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.102, i32 71, ptr %trap_written1102, ptr null)
  call void @llvm.trap()
  unreachable

bb_slice_bounds_ok367:
  %slice_slot1103 = getelementptr i8, ptr %array_ptr1082, i64 %index_size1099
  %slice_item1104 = load i8, ptr %slice_slot1103, align 1
  %numeric_convert1105 = zext i8 %inline_array_item1096 to i32
  %numeric_convert1106 = zext i8 %slice_item1104 to i32
  store i32 0, ptr %mutable_scalar_slot1107, align 4
  store i32 1, ptr %mutable_scalar_slot1108, align 4
  store i32 0, ptr %mutable_scalar_slot1109, align 4
  br label %bb_while_condition369
bb_while_condition369:
  %mutable_scalar1110 = load i32, ptr %mutable_scalar_slot1109, align 4
  %cmp1111 = icmp ult i32 %mutable_scalar1110, 32
  br i1 %cmp1111, label %bb_while_body370, label %bb_while_end371
bb_while_body370:
  %mutable_scalar1112 = load i32, ptr %mutable_scalar_slot1108, align 4
  %div1113 = udiv i32 %numeric_convert1105, %mutable_scalar1112
  %mod1114 = urem i32 %div1113, 2
  %mutable_scalar1115 = load i32, ptr %mutable_scalar_slot1108, align 4
  %div1116 = udiv i32 %numeric_convert1106, %mutable_scalar1115
  %mod1117 = urem i32 %div1116, 2
  %cmp1118 = icmp ne i32 %mod1114, %mod1117
  br i1 %cmp1118, label %bb_if_then372, label %bb_if_end373
bb_if_then372:
  %mutable_scalar1119 = load i32, ptr %mutable_scalar_slot1107, align 4
  %mutable_scalar1120 = load i32, ptr %mutable_scalar_slot1108, align 4
  %add1121 = add i32 %mutable_scalar1119, %mutable_scalar1120
  store i32 %add1121, ptr %mutable_scalar_slot1107, align 4
  br label %bb_if_end373
bb_if_end373:
  %mutable_scalar1122 = load i32, ptr %mutable_scalar_slot1109, align 4
  %add1123 = add i32 %mutable_scalar1122, 1
  store i32 %add1123, ptr %mutable_scalar_slot1109, align 4
  %mutable_scalar1124 = load i32, ptr %mutable_scalar_slot1109, align 4
  %cmp1125 = icmp ult i32 %mutable_scalar1124, 32
  br i1 %cmp1125, label %bb_if_then374, label %bb_if_end375
bb_if_then374:
  %mutable_scalar1126 = load i32, ptr %mutable_scalar_slot1108, align 4
  %mul1127 = mul i32 %mutable_scalar1126, 2
  store i32 %mul1127, ptr %mutable_scalar_slot1108, align 4
  br label %bb_if_end375
bb_if_end375:
  br label %bb_while_condition369
bb_while_end371:
  %mutable_scalar1128 = load i32, ptr %mutable_scalar_slot1107, align 4
  %numeric_upper_bound1129 = icmp ule i32 %mutable_scalar1128, 255
  br i1 %numeric_upper_bound1129, label %bb_numeric_conversion_upper_ok376, label %bb_numeric_conversion_upper_fail377

bb_numeric_conversion_upper_fail377:
  %trap_stderr1130 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1130, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.103, i32 68, ptr %trap_written1131, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok376:
  %numeric_convert1132 = trunc i32 %mutable_scalar1128 to i8
  %mutable_scalar1133 = load i32, ptr %mutable_scalar_slot1087, align 4
  %assignment_index1134 = sext i32 %mutable_scalar1133 to i64
  %inline_array_assign_in_bounds1135 = icmp ult i64 %assignment_index1134, %mutable_len1079
  br i1 %inline_array_assign_in_bounds1135, label %bb_inline_array_assign_bounds_ok378, label %bb_inline_array_assign_bounds_fail379

bb_inline_array_assign_bounds_fail379:
  %trap_stderr1136 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1136, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.104, i32 85, ptr %trap_written1137, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok378:
  %inline_array_assign_slot1138 = getelementptr i8, ptr %mutable_ptr1078, i64 %assignment_index1134
  store i8 %numeric_convert1132, ptr %inline_array_assign_slot1138, align 1
  %mutable_scalar1139 = load i32, ptr %mutable_scalar_slot1087, align 4
  %add1140 = add i32 %mutable_scalar1139, 1
  store i32 %add1140, ptr %mutable_scalar_slot1087, align 4
  br label %bb_while_condition362
bb_while_end364:
  %mutable_scalar1141 = load i32, ptr %mutable_scalar_slot113, align 4
  %add1142 = add i32 %mutable_scalar1141, 1
  store i32 %add1142, ptr %mutable_scalar_slot113, align 4
  br label %bb_while_condition27
bb_while_end29:
  %mutable_ptr1143 = load ptr, ptr %mutable_ptr_addr28, align 8
  %mutable_len1144 = load i64, ptr %mutable_len_addr29, align 8
  %mutable_capacity1145 = load i64, ptr %mutable_capacity_addr30, align 8
  store i32 0, ptr %mutable_scalar_slot1146, align 4
  br label %bb_while_condition380
bb_while_condition380:
  %mutable_scalar1147 = load i32, ptr %mutable_scalar_slot1146, align 4
  %cmp1148 = icmp slt i32 %mutable_scalar1147, 16
  br i1 %cmp1148, label %bb_while_body381, label %bb_while_end382
bb_while_body381:
  %struct_call1149 = call %sollang.int_slice @sollang_fn_std_crypto_aes128_sbox(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %slice_ptr1150 = extractvalue %sollang.int_slice %struct_call1149, 0
  %slice_len1151 = extractvalue %sollang.int_slice %struct_call1149, 1
  %mutable_scalar1152 = load i32, ptr %mutable_scalar_slot1146, align 4
  %index_size1153 = sext i32 %mutable_scalar1152 to i64
  %inline_array_in_bounds1154 = icmp ult i64 %index_size1153, %mutable_len1144
  br i1 %inline_array_in_bounds1154, label %bb_inline_array_bounds_ok383, label %bb_inline_array_bounds_fail384

bb_inline_array_bounds_fail384:
  %trap_stderr1155 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1155, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.105, i32 75, ptr %trap_written1156, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok383:
  %inline_array_slot1157 = getelementptr i8, ptr %mutable_ptr1143, i64 %index_size1153
  %inline_array_item1158 = load i8, ptr %inline_array_slot1157, align 1
  %numeric_convert1159 = zext i8 %inline_array_item1158 to i32
  %index_size1160 = sext i32 %numeric_convert1159 to i64
  %slice_in_bounds1161 = icmp ult i64 %index_size1160, %slice_len1151
  br i1 %slice_in_bounds1161, label %bb_slice_bounds_ok385, label %bb_slice_bounds_fail386

bb_slice_bounds_fail386:
  %trap_stderr1162 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1162, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.106, i32 68, ptr %trap_written1163, ptr null)
  call void @llvm.trap()
  unreachable

bb_slice_bounds_ok385:
  %slice_slot1164 = getelementptr i8, ptr %slice_ptr1150, i64 %index_size1160
  %slice_item1165 = load i8, ptr %slice_slot1164, align 1
  %mutable_scalar1166 = load i32, ptr %mutable_scalar_slot1146, align 4
  %assignment_index1167 = sext i32 %mutable_scalar1166 to i64
  %inline_array_assign_in_bounds1168 = icmp ult i64 %assignment_index1167, %mutable_len1144
  br i1 %inline_array_assign_in_bounds1168, label %bb_inline_array_assign_bounds_ok387, label %bb_inline_array_assign_bounds_fail388

bb_inline_array_assign_bounds_fail388:
  %trap_stderr1169 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1169, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.107, i32 82, ptr %trap_written1170, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok387:
  %inline_array_assign_slot1171 = getelementptr i8, ptr %mutable_ptr1143, i64 %assignment_index1167
  store i8 %slice_item1165, ptr %inline_array_assign_slot1171, align 1
  %mutable_scalar1172 = load i32, ptr %mutable_scalar_slot1146, align 4
  %add1173 = add i32 %mutable_scalar1172, 1
  store i32 %add1173, ptr %mutable_scalar_slot1146, align 4
  br label %bb_while_condition380
bb_while_end382:
  %mutable_ptr1174 = load ptr, ptr %mutable_ptr_addr28, align 8
  %mutable_len1175 = load i64, ptr %mutable_len_addr29, align 8
  %mutable_capacity1176 = load i64, ptr %mutable_capacity_addr30, align 8
  %index_size1177 = sext i32 1 to i64
  %inline_array_in_bounds1178 = icmp ult i64 %index_size1177, %mutable_len1175
  br i1 %inline_array_in_bounds1178, label %bb_inline_array_bounds_ok389, label %bb_inline_array_bounds_fail390

bb_inline_array_bounds_fail390:
  %trap_stderr1179 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1179, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.108, i32 76, ptr %trap_written1180, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok389:
  %inline_array_slot1181 = getelementptr i8, ptr %mutable_ptr1174, i64 %index_size1177
  %inline_array_item1182 = load i8, ptr %inline_array_slot1181, align 1
  %index_size1183 = sext i32 5 to i64
  %inline_array_in_bounds1184 = icmp ult i64 %index_size1183, %mutable_len1175
  br i1 %inline_array_in_bounds1184, label %bb_inline_array_bounds_ok391, label %bb_inline_array_bounds_fail392

bb_inline_array_bounds_fail392:
  %trap_stderr1185 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1185, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.109, i32 76, ptr %trap_written1186, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok391:
  %inline_array_slot1187 = getelementptr i8, ptr %mutable_ptr1174, i64 %index_size1183
  %inline_array_item1188 = load i8, ptr %inline_array_slot1187, align 1
  %assignment_index1189 = sext i32 1 to i64
  %inline_array_assign_in_bounds1190 = icmp ult i64 %assignment_index1189, %mutable_len1175
  br i1 %inline_array_assign_in_bounds1190, label %bb_inline_array_assign_bounds_ok393, label %bb_inline_array_assign_bounds_fail394

bb_inline_array_assign_bounds_fail394:
  %trap_stderr1191 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1191, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.110, i32 83, ptr %trap_written1192, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok393:
  %inline_array_assign_slot1193 = getelementptr i8, ptr %mutable_ptr1174, i64 %assignment_index1189
  store i8 %inline_array_item1188, ptr %inline_array_assign_slot1193, align 1
  %index_size1194 = sext i32 9 to i64
  %inline_array_in_bounds1195 = icmp ult i64 %index_size1194, %mutable_len1175
  br i1 %inline_array_in_bounds1195, label %bb_inline_array_bounds_ok395, label %bb_inline_array_bounds_fail396

bb_inline_array_bounds_fail396:
  %trap_stderr1196 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1196, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.111, i32 76, ptr %trap_written1197, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok395:
  %inline_array_slot1198 = getelementptr i8, ptr %mutable_ptr1174, i64 %index_size1194
  %inline_array_item1199 = load i8, ptr %inline_array_slot1198, align 1
  %assignment_index1200 = sext i32 5 to i64
  %inline_array_assign_in_bounds1201 = icmp ult i64 %assignment_index1200, %mutable_len1175
  br i1 %inline_array_assign_in_bounds1201, label %bb_inline_array_assign_bounds_ok397, label %bb_inline_array_assign_bounds_fail398

bb_inline_array_assign_bounds_fail398:
  %trap_stderr1202 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1202, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.112, i32 83, ptr %trap_written1203, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok397:
  %inline_array_assign_slot1204 = getelementptr i8, ptr %mutable_ptr1174, i64 %assignment_index1200
  store i8 %inline_array_item1199, ptr %inline_array_assign_slot1204, align 1
  %index_size1205 = sext i32 13 to i64
  %inline_array_in_bounds1206 = icmp ult i64 %index_size1205, %mutable_len1175
  br i1 %inline_array_in_bounds1206, label %bb_inline_array_bounds_ok399, label %bb_inline_array_bounds_fail400

bb_inline_array_bounds_fail400:
  %trap_stderr1207 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1207, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.113, i32 76, ptr %trap_written1208, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok399:
  %inline_array_slot1209 = getelementptr i8, ptr %mutable_ptr1174, i64 %index_size1205
  %inline_array_item1210 = load i8, ptr %inline_array_slot1209, align 1
  %assignment_index1211 = sext i32 9 to i64
  %inline_array_assign_in_bounds1212 = icmp ult i64 %assignment_index1211, %mutable_len1175
  br i1 %inline_array_assign_in_bounds1212, label %bb_inline_array_assign_bounds_ok401, label %bb_inline_array_assign_bounds_fail402

bb_inline_array_assign_bounds_fail402:
  %trap_stderr1213 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1213, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.114, i32 83, ptr %trap_written1214, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok401:
  %inline_array_assign_slot1215 = getelementptr i8, ptr %mutable_ptr1174, i64 %assignment_index1211
  store i8 %inline_array_item1210, ptr %inline_array_assign_slot1215, align 1
  %assignment_index1216 = sext i32 13 to i64
  %inline_array_assign_in_bounds1217 = icmp ult i64 %assignment_index1216, %mutable_len1175
  br i1 %inline_array_assign_in_bounds1217, label %bb_inline_array_assign_bounds_ok403, label %bb_inline_array_assign_bounds_fail404

bb_inline_array_assign_bounds_fail404:
  %trap_stderr1218 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1218, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.115, i32 83, ptr %trap_written1219, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok403:
  %inline_array_assign_slot1220 = getelementptr i8, ptr %mutable_ptr1174, i64 %assignment_index1216
  store i8 %inline_array_item1182, ptr %inline_array_assign_slot1220, align 1
  %index_size1221 = sext i32 2 to i64
  %inline_array_in_bounds1222 = icmp ult i64 %index_size1221, %mutable_len1175
  br i1 %inline_array_in_bounds1222, label %bb_inline_array_bounds_ok405, label %bb_inline_array_bounds_fail406

bb_inline_array_bounds_fail406:
  %trap_stderr1223 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1223, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.116, i32 76, ptr %trap_written1224, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok405:
  %inline_array_slot1225 = getelementptr i8, ptr %mutable_ptr1174, i64 %index_size1221
  %inline_array_item1226 = load i8, ptr %inline_array_slot1225, align 1
  %index_size1227 = sext i32 6 to i64
  %inline_array_in_bounds1228 = icmp ult i64 %index_size1227, %mutable_len1175
  br i1 %inline_array_in_bounds1228, label %bb_inline_array_bounds_ok407, label %bb_inline_array_bounds_fail408

bb_inline_array_bounds_fail408:
  %trap_stderr1229 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1229, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.117, i32 76, ptr %trap_written1230, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok407:
  %inline_array_slot1231 = getelementptr i8, ptr %mutable_ptr1174, i64 %index_size1227
  %inline_array_item1232 = load i8, ptr %inline_array_slot1231, align 1
  %index_size1233 = sext i32 10 to i64
  %inline_array_in_bounds1234 = icmp ult i64 %index_size1233, %mutable_len1175
  br i1 %inline_array_in_bounds1234, label %bb_inline_array_bounds_ok409, label %bb_inline_array_bounds_fail410

bb_inline_array_bounds_fail410:
  %trap_stderr1235 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1235, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.118, i32 76, ptr %trap_written1236, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok409:
  %inline_array_slot1237 = getelementptr i8, ptr %mutable_ptr1174, i64 %index_size1233
  %inline_array_item1238 = load i8, ptr %inline_array_slot1237, align 1
  %assignment_index1239 = sext i32 2 to i64
  %inline_array_assign_in_bounds1240 = icmp ult i64 %assignment_index1239, %mutable_len1175
  br i1 %inline_array_assign_in_bounds1240, label %bb_inline_array_assign_bounds_ok411, label %bb_inline_array_assign_bounds_fail412

bb_inline_array_assign_bounds_fail412:
  %trap_stderr1241 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1241, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.119, i32 83, ptr %trap_written1242, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok411:
  %inline_array_assign_slot1243 = getelementptr i8, ptr %mutable_ptr1174, i64 %assignment_index1239
  store i8 %inline_array_item1238, ptr %inline_array_assign_slot1243, align 1
  %index_size1244 = sext i32 14 to i64
  %inline_array_in_bounds1245 = icmp ult i64 %index_size1244, %mutable_len1175
  br i1 %inline_array_in_bounds1245, label %bb_inline_array_bounds_ok413, label %bb_inline_array_bounds_fail414

bb_inline_array_bounds_fail414:
  %trap_stderr1246 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1246, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.120, i32 76, ptr %trap_written1247, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok413:
  %inline_array_slot1248 = getelementptr i8, ptr %mutable_ptr1174, i64 %index_size1244
  %inline_array_item1249 = load i8, ptr %inline_array_slot1248, align 1
  %assignment_index1250 = sext i32 6 to i64
  %inline_array_assign_in_bounds1251 = icmp ult i64 %assignment_index1250, %mutable_len1175
  br i1 %inline_array_assign_in_bounds1251, label %bb_inline_array_assign_bounds_ok415, label %bb_inline_array_assign_bounds_fail416

bb_inline_array_assign_bounds_fail416:
  %trap_stderr1252 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1252, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.121, i32 83, ptr %trap_written1253, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok415:
  %inline_array_assign_slot1254 = getelementptr i8, ptr %mutable_ptr1174, i64 %assignment_index1250
  store i8 %inline_array_item1249, ptr %inline_array_assign_slot1254, align 1
  %assignment_index1255 = sext i32 10 to i64
  %inline_array_assign_in_bounds1256 = icmp ult i64 %assignment_index1255, %mutable_len1175
  br i1 %inline_array_assign_in_bounds1256, label %bb_inline_array_assign_bounds_ok417, label %bb_inline_array_assign_bounds_fail418

bb_inline_array_assign_bounds_fail418:
  %trap_stderr1257 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1257, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.122, i32 83, ptr %trap_written1258, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok417:
  %inline_array_assign_slot1259 = getelementptr i8, ptr %mutable_ptr1174, i64 %assignment_index1255
  store i8 %inline_array_item1226, ptr %inline_array_assign_slot1259, align 1
  %assignment_index1260 = sext i32 14 to i64
  %inline_array_assign_in_bounds1261 = icmp ult i64 %assignment_index1260, %mutable_len1175
  br i1 %inline_array_assign_in_bounds1261, label %bb_inline_array_assign_bounds_ok419, label %bb_inline_array_assign_bounds_fail420

bb_inline_array_assign_bounds_fail420:
  %trap_stderr1262 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1262, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.123, i32 83, ptr %trap_written1263, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok419:
  %inline_array_assign_slot1264 = getelementptr i8, ptr %mutable_ptr1174, i64 %assignment_index1260
  store i8 %inline_array_item1232, ptr %inline_array_assign_slot1264, align 1
  %index_size1265 = sext i32 3 to i64
  %inline_array_in_bounds1266 = icmp ult i64 %index_size1265, %mutable_len1175
  br i1 %inline_array_in_bounds1266, label %bb_inline_array_bounds_ok421, label %bb_inline_array_bounds_fail422

bb_inline_array_bounds_fail422:
  %trap_stderr1267 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1267, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.124, i32 76, ptr %trap_written1268, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok421:
  %inline_array_slot1269 = getelementptr i8, ptr %mutable_ptr1174, i64 %index_size1265
  %inline_array_item1270 = load i8, ptr %inline_array_slot1269, align 1
  %index_size1271 = sext i32 15 to i64
  %inline_array_in_bounds1272 = icmp ult i64 %index_size1271, %mutable_len1175
  br i1 %inline_array_in_bounds1272, label %bb_inline_array_bounds_ok423, label %bb_inline_array_bounds_fail424

bb_inline_array_bounds_fail424:
  %trap_stderr1273 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1273, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.125, i32 76, ptr %trap_written1274, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok423:
  %inline_array_slot1275 = getelementptr i8, ptr %mutable_ptr1174, i64 %index_size1271
  %inline_array_item1276 = load i8, ptr %inline_array_slot1275, align 1
  %assignment_index1277 = sext i32 3 to i64
  %inline_array_assign_in_bounds1278 = icmp ult i64 %assignment_index1277, %mutable_len1175
  br i1 %inline_array_assign_in_bounds1278, label %bb_inline_array_assign_bounds_ok425, label %bb_inline_array_assign_bounds_fail426

bb_inline_array_assign_bounds_fail426:
  %trap_stderr1279 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1279, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.126, i32 83, ptr %trap_written1280, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok425:
  %inline_array_assign_slot1281 = getelementptr i8, ptr %mutable_ptr1174, i64 %assignment_index1277
  store i8 %inline_array_item1276, ptr %inline_array_assign_slot1281, align 1
  %index_size1282 = sext i32 11 to i64
  %inline_array_in_bounds1283 = icmp ult i64 %index_size1282, %mutable_len1175
  br i1 %inline_array_in_bounds1283, label %bb_inline_array_bounds_ok427, label %bb_inline_array_bounds_fail428

bb_inline_array_bounds_fail428:
  %trap_stderr1284 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1284, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.127, i32 76, ptr %trap_written1285, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok427:
  %inline_array_slot1286 = getelementptr i8, ptr %mutable_ptr1174, i64 %index_size1282
  %inline_array_item1287 = load i8, ptr %inline_array_slot1286, align 1
  %assignment_index1288 = sext i32 15 to i64
  %inline_array_assign_in_bounds1289 = icmp ult i64 %assignment_index1288, %mutable_len1175
  br i1 %inline_array_assign_in_bounds1289, label %bb_inline_array_assign_bounds_ok429, label %bb_inline_array_assign_bounds_fail430

bb_inline_array_assign_bounds_fail430:
  %trap_stderr1290 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1290, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.128, i32 83, ptr %trap_written1291, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok429:
  %inline_array_assign_slot1292 = getelementptr i8, ptr %mutable_ptr1174, i64 %assignment_index1288
  store i8 %inline_array_item1287, ptr %inline_array_assign_slot1292, align 1
  %index_size1293 = sext i32 7 to i64
  %inline_array_in_bounds1294 = icmp ult i64 %index_size1293, %mutable_len1175
  br i1 %inline_array_in_bounds1294, label %bb_inline_array_bounds_ok431, label %bb_inline_array_bounds_fail432

bb_inline_array_bounds_fail432:
  %trap_stderr1295 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1295, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.129, i32 76, ptr %trap_written1296, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok431:
  %inline_array_slot1297 = getelementptr i8, ptr %mutable_ptr1174, i64 %index_size1293
  %inline_array_item1298 = load i8, ptr %inline_array_slot1297, align 1
  %assignment_index1299 = sext i32 11 to i64
  %inline_array_assign_in_bounds1300 = icmp ult i64 %assignment_index1299, %mutable_len1175
  br i1 %inline_array_assign_in_bounds1300, label %bb_inline_array_assign_bounds_ok433, label %bb_inline_array_assign_bounds_fail434

bb_inline_array_assign_bounds_fail434:
  %trap_stderr1301 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1301, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.130, i32 83, ptr %trap_written1302, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok433:
  %inline_array_assign_slot1303 = getelementptr i8, ptr %mutable_ptr1174, i64 %assignment_index1299
  store i8 %inline_array_item1298, ptr %inline_array_assign_slot1303, align 1
  %assignment_index1304 = sext i32 7 to i64
  %inline_array_assign_in_bounds1305 = icmp ult i64 %assignment_index1304, %mutable_len1175
  br i1 %inline_array_assign_in_bounds1305, label %bb_inline_array_assign_bounds_ok435, label %bb_inline_array_assign_bounds_fail436

bb_inline_array_assign_bounds_fail436:
  %trap_stderr1306 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1306, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.131, i32 83, ptr %trap_written1307, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok435:
  %inline_array_assign_slot1308 = getelementptr i8, ptr %mutable_ptr1174, i64 %assignment_index1304
  store i8 %inline_array_item1270, ptr %inline_array_assign_slot1308, align 1
  %mutable_ptr1309 = load ptr, ptr %mutable_ptr_addr28, align 8
  %mutable_len1310 = load i64, ptr %mutable_len_addr29, align 8
  %mutable_capacity1311 = load i64, ptr %mutable_capacity_addr30, align 8
  %field1312 = extractvalue %sollang.struct.1155 %it, 0
  %array_ptr1313 = extractvalue %sollang.dynamic_int_array %field1312, 0
  %array_len1314 = extractvalue %sollang.dynamic_int_array %field1312, 1
  %array_capacity1315 = extractvalue %sollang.dynamic_int_array %field1312, 2
  store i32 0, ptr %mutable_scalar_slot1316, align 4
  br label %bb_while_condition437
bb_while_condition437:
  %mutable_scalar1317 = load i32, ptr %mutable_scalar_slot1316, align 4
  %cmp1318 = icmp slt i32 %mutable_scalar1317, 16
  br i1 %cmp1318, label %bb_while_body438, label %bb_while_end439
bb_while_body438:
  %mutable_scalar1319 = load i32, ptr %mutable_scalar_slot1316, align 4
  %index_size1320 = sext i32 %mutable_scalar1319 to i64
  %inline_array_in_bounds1321 = icmp ult i64 %index_size1320, %mutable_len1310
  br i1 %inline_array_in_bounds1321, label %bb_inline_array_bounds_ok440, label %bb_inline_array_bounds_fail441

bb_inline_array_bounds_fail441:
  %trap_stderr1322 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1322, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.132, i32 78, ptr %trap_written1323, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_bounds_ok440:
  %inline_array_slot1324 = getelementptr i8, ptr %mutable_ptr1309, i64 %index_size1320
  %inline_array_item1325 = load i8, ptr %inline_array_slot1324, align 1
  %mutable_scalar1326 = load i32, ptr %mutable_scalar_slot1316, align 4
  %add1327 = add i32 160, %mutable_scalar1326
  %index_size1328 = sext i32 %add1327 to i64
  %slice_in_bounds1329 = icmp ult i64 %index_size1328, %array_len1314
  br i1 %slice_in_bounds1329, label %bb_slice_bounds_ok442, label %bb_slice_bounds_fail443

bb_slice_bounds_fail443:
  %trap_stderr1330 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1330, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.133, i32 71, ptr %trap_written1331, ptr null)
  call void @llvm.trap()
  unreachable

bb_slice_bounds_ok442:
  %slice_slot1332 = getelementptr i8, ptr %array_ptr1313, i64 %index_size1328
  %slice_item1333 = load i8, ptr %slice_slot1332, align 1
  %numeric_convert1334 = zext i8 %inline_array_item1325 to i32
  %numeric_convert1335 = zext i8 %slice_item1333 to i32
  store i32 0, ptr %mutable_scalar_slot1336, align 4
  store i32 1, ptr %mutable_scalar_slot1337, align 4
  store i32 0, ptr %mutable_scalar_slot1338, align 4
  br label %bb_while_condition444
bb_while_condition444:
  %mutable_scalar1339 = load i32, ptr %mutable_scalar_slot1338, align 4
  %cmp1340 = icmp ult i32 %mutable_scalar1339, 32
  br i1 %cmp1340, label %bb_while_body445, label %bb_while_end446
bb_while_body445:
  %mutable_scalar1341 = load i32, ptr %mutable_scalar_slot1337, align 4
  %div1342 = udiv i32 %numeric_convert1334, %mutable_scalar1341
  %mod1343 = urem i32 %div1342, 2
  %mutable_scalar1344 = load i32, ptr %mutable_scalar_slot1337, align 4
  %div1345 = udiv i32 %numeric_convert1335, %mutable_scalar1344
  %mod1346 = urem i32 %div1345, 2
  %cmp1347 = icmp ne i32 %mod1343, %mod1346
  br i1 %cmp1347, label %bb_if_then447, label %bb_if_end448
bb_if_then447:
  %mutable_scalar1348 = load i32, ptr %mutable_scalar_slot1336, align 4
  %mutable_scalar1349 = load i32, ptr %mutable_scalar_slot1337, align 4
  %add1350 = add i32 %mutable_scalar1348, %mutable_scalar1349
  store i32 %add1350, ptr %mutable_scalar_slot1336, align 4
  br label %bb_if_end448
bb_if_end448:
  %mutable_scalar1351 = load i32, ptr %mutable_scalar_slot1338, align 4
  %add1352 = add i32 %mutable_scalar1351, 1
  store i32 %add1352, ptr %mutable_scalar_slot1338, align 4
  %mutable_scalar1353 = load i32, ptr %mutable_scalar_slot1338, align 4
  %cmp1354 = icmp ult i32 %mutable_scalar1353, 32
  br i1 %cmp1354, label %bb_if_then449, label %bb_if_end450
bb_if_then449:
  %mutable_scalar1355 = load i32, ptr %mutable_scalar_slot1337, align 4
  %mul1356 = mul i32 %mutable_scalar1355, 2
  store i32 %mul1356, ptr %mutable_scalar_slot1337, align 4
  br label %bb_if_end450
bb_if_end450:
  br label %bb_while_condition444
bb_while_end446:
  %mutable_scalar1357 = load i32, ptr %mutable_scalar_slot1336, align 4
  %numeric_upper_bound1358 = icmp ule i32 %mutable_scalar1357, 255
  br i1 %numeric_upper_bound1358, label %bb_numeric_conversion_upper_ok451, label %bb_numeric_conversion_upper_fail452

bb_numeric_conversion_upper_fail452:
  %trap_stderr1359 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1359, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.134, i32 68, ptr %trap_written1360, ptr null)
  call void @llvm.trap()
  unreachable

bb_numeric_conversion_upper_ok451:
  %numeric_convert1361 = trunc i32 %mutable_scalar1357 to i8
  %mutable_scalar1362 = load i32, ptr %mutable_scalar_slot1316, align 4
  %assignment_index1363 = sext i32 %mutable_scalar1362 to i64
  %inline_array_assign_in_bounds1364 = icmp ult i64 %assignment_index1363, %mutable_len1310
  br i1 %inline_array_assign_in_bounds1364, label %bb_inline_array_assign_bounds_ok453, label %bb_inline_array_assign_bounds_fail454

bb_inline_array_assign_bounds_fail454:
  %trap_stderr1365 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr1365, ptr @.slg.str.module.x7374642E63727970746F2E616573313238.135, i32 85, ptr %trap_written1366, ptr null)
  call void @llvm.trap()
  unreachable

bb_inline_array_assign_bounds_ok453:
  %inline_array_assign_slot1367 = getelementptr i8, ptr %mutable_ptr1309, i64 %assignment_index1363
  store i8 %numeric_convert1361, ptr %inline_array_assign_slot1367, align 1
  %mutable_scalar1368 = load i32, ptr %mutable_scalar_slot1316, align 4
  %add1369 = add i32 %mutable_scalar1368, 1
  store i32 %add1369, ptr %mutable_scalar_slot1316, align 4
  br label %bb_while_condition437
bb_while_end439:
  %mutable_ptr1370 = load ptr, ptr %mutable_ptr_addr28, align 8
  %mutable_len1371 = load i64, ptr %mutable_len_addr29, align 8
  %mutable_capacity1372 = load i64, ptr %mutable_capacity_addr30, align 8
  %slice_value1373 = insertvalue %sollang.int_slice poison, ptr %mutable_ptr1370, 0
  %slice_value1374 = insertvalue %sollang.int_slice %slice_value1373, i64 %mutable_len1371, 1
  ret %sollang.int_slice %slice_value1374
}

@sollang_cpu_features = internal global i64 -1, align 8
@sollang_aes128_selected = internal global ptr @sollang_fn_std_crypto_aes128_Key_encryptBlock_resolve, align 8
declare <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64>, <2 x i64>)
declare <2 x i64> @llvm.x86.aesni.aesenclast(<2 x i64>, <2 x i64>)

define internal i64 @sollang_cpu_features_once() {
entry:
  %cached = load atomic i64, ptr @sollang_cpu_features monotonic, align 8
  %initialized = icmp ne i64 %cached, -1
  br i1 %initialized, label %ready, label %detect
detect:
  %leaf1 = call { i32, i32, i32, i32 } asm "xchgq %rbx, ${1:q}\0Acpuid\0Axchgq %rbx, ${1:q}", "={ax},=r,={cx},={dx},0,2"(i32 1, i32 0)
  %leaf1_ecx = extractvalue { i32, i32, i32, i32 } %leaf1, 2
  %leaf1_edx = extractvalue { i32, i32, i32, i32 } %leaf1, 3
  %sse2_bits = and i32 %leaf1_edx, 67108864
  %has_sse2 = icmp ne i32 %sse2_bits, 0
  %sse2_mask = select i1 %has_sse2, i64 1, i64 0
  %aes_bits = and i32 %leaf1_ecx, 33554432
  %has_aes = icmp ne i32 %aes_bits, 0
  %aes_mask = select i1 %has_aes, i64 8, i64 0
  %detected = or i64 %sse2_mask, %aes_mask
  %installed = cmpxchg ptr @sollang_cpu_features, i64 -1, i64 %detected monotonic monotonic
  %observed = extractvalue { i64, i1 } %installed, 0
  %won = extractvalue { i64, i1 } %installed, 1
  %features = select i1 %won, i64 %detected, i64 %observed
  ret i64 %features
ready:
  ret i64 %cached
}

define internal %sollang.int_slice @sollang_fn_std_crypto_aes128_Key_encryptBlock_x86(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.struct.1155 %it, %sollang.int_slice %arg_0) #1 {
entry:
  %expanded_slice = extractvalue %sollang.struct.1155 %it, 0
  %expanded = extractvalue %sollang.dynamic_int_array %expanded_slice, 0
  %input = extractvalue %sollang.int_slice %arg_0, 0
  %output = call ptr @sollang_alloc(i64 16)
  %allocated = icmp ne ptr %output, null
  br i1 %allocated, label %encrypt, label %allocation_failed
allocation_failed:
  call void @llvm.trap()
  unreachable
encrypt:
  %input_value = load <2 x i64>, ptr %input, align 1
  %round0 = load <2 x i64>, ptr %expanded, align 1
  %state0 = xor <2 x i64> %input_value, %round0
  %key1_ptr = getelementptr i8, ptr %expanded, i64 16
  %key1 = load <2 x i64>, ptr %key1_ptr, align 1
  %state1 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state0, <2 x i64> %key1)
  %key2_ptr = getelementptr i8, ptr %expanded, i64 32
  %key2 = load <2 x i64>, ptr %key2_ptr, align 1
  %state2 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state1, <2 x i64> %key2)
  %key3_ptr = getelementptr i8, ptr %expanded, i64 48
  %key3 = load <2 x i64>, ptr %key3_ptr, align 1
  %state3 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state2, <2 x i64> %key3)
  %key4_ptr = getelementptr i8, ptr %expanded, i64 64
  %key4 = load <2 x i64>, ptr %key4_ptr, align 1
  %state4 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state3, <2 x i64> %key4)
  %key5_ptr = getelementptr i8, ptr %expanded, i64 80
  %key5 = load <2 x i64>, ptr %key5_ptr, align 1
  %state5 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state4, <2 x i64> %key5)
  %key6_ptr = getelementptr i8, ptr %expanded, i64 96
  %key6 = load <2 x i64>, ptr %key6_ptr, align 1
  %state6 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state5, <2 x i64> %key6)
  %key7_ptr = getelementptr i8, ptr %expanded, i64 112
  %key7 = load <2 x i64>, ptr %key7_ptr, align 1
  %state7 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state6, <2 x i64> %key7)
  %key8_ptr = getelementptr i8, ptr %expanded, i64 128
  %key8 = load <2 x i64>, ptr %key8_ptr, align 1
  %state8 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state7, <2 x i64> %key8)
  %key9_ptr = getelementptr i8, ptr %expanded, i64 144
  %key9 = load <2 x i64>, ptr %key9_ptr, align 1
  %state9 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state8, <2 x i64> %key9)
  %key10_ptr = getelementptr i8, ptr %expanded, i64 160
  %key10 = load <2 x i64>, ptr %key10_ptr, align 1
  %state10 = call <2 x i64> @llvm.x86.aesni.aesenclast(<2 x i64> %state9, <2 x i64> %key10)
  store <2 x i64> %state10, ptr %output, align 1
  %result0 = insertvalue %sollang.int_slice poison, ptr %output, 0
  %result = insertvalue %sollang.int_slice %result0, i64 16, 1
  ret %sollang.int_slice %result
}

define internal %sollang.int_slice @sollang_fn_std_crypto_aes128_Key_encryptBlock_resolve(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.struct.1155 %it, %sollang.int_slice %arg_0) {
entry:
  %features = call i64 @sollang_cpu_features_once()
  %aes_feature = and i64 %features, 8
  %has_aes = icmp eq i64 %aes_feature, 8
  %selected = select i1 %has_aes, ptr @sollang_fn_std_crypto_aes128_Key_encryptBlock_x86, ptr @sollang_fn_std_crypto_aes128_Key_encryptBlock_portable
  store atomic ptr %selected, ptr @sollang_aes128_selected monotonic, align 8
  %result = tail call %sollang.int_slice %selected(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.struct.1155 %it, %sollang.int_slice %arg_0)
  ret %sollang.int_slice %result
}

define internal %sollang.int_slice @sollang_fn_std_crypto_aes128_Key_encryptBlock(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.struct.1155 %it, %sollang.int_slice %arg_0) {
entry:
  %selected = load atomic ptr, ptr @sollang_aes128_selected monotonic, align 8
  %result = tail call %sollang.int_slice %selected(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.struct.1155 %it, %sollang.int_slice %arg_0)
  ret %sollang.int_slice %result
}

@.slg.str.suffix.0 = private unnamed_addr constant [18 x i8] c"aes128-dispatch=ok", align 1
@.slg.str.suffix.1 = private unnamed_addr constant [22 x i8] c"aes128-dispatch=failed", align 1
@.slg.str.suffix.2 = private unnamed_addr constant [1 x i8] c"\0A", align 1
define internal %sollang.read_int_result @sollang_read_i64(ptr %stdin, ptr %read) #0 {
entry:
  %buf = alloca [64 x i8], align 1
  %ok = call i32 @sollang_read_stdin(ptr %stdin, ptr %buf, i64 64, ptr %read)
  %read_ok = icmp ne i32 %ok, 0
  br i1 %read_ok, label %prepare, label %fail

prepare:
  %read32 = load i32, ptr %read, align 4
  %len = zext i32 %read32 to i64
  br label %skip

skip:
  %skip_idx = phi i64 [ 0, %prepare ], [ %skip_next, %skip_ws ]
  %skip_has = icmp ult i64 %skip_idx, %len
  br i1 %skip_has, label %skip_char, label %fail

skip_char:
  %skip_ptr = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 %skip_idx
  %skip_ch = load i8, ptr %skip_ptr, align 1
  %skip_sp = icmp eq i8 %skip_ch, 32
  %skip_tab = icmp eq i8 %skip_ch, 9
  %skip_cr = icmp eq i8 %skip_ch, 13
  %skip_lf = icmp eq i8 %skip_ch, 10
  %skip_sp_tab = or i1 %skip_sp, %skip_tab
  %skip_cr_lf = or i1 %skip_cr, %skip_lf
  %skip_is_ws = or i1 %skip_sp_tab, %skip_cr_lf
  br i1 %skip_is_ws, label %skip_ws, label %digit_entry

skip_ws:
  %skip_next = add i64 %skip_idx, 1
  br label %skip

digit_entry:
  %first_ge = icmp uge i8 %skip_ch, 48
  %first_le = icmp ule i8 %skip_ch, 57
  %first_digit = and i1 %first_ge, %first_le
  br i1 %first_digit, label %digits, label %fail

digits:
  %digit_idx = phi i64 [ %skip_idx, %digit_entry ], [ %digit_next, %digit_continue ]
  %value = phi i64 [ 0, %digit_entry ], [ %value_next, %digit_continue ]
  %digit_has = icmp ult i64 %digit_idx, %len
  br i1 %digit_has, label %digit_char, label %success

digit_char:
  %digit_ptr = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 %digit_idx
  %digit_ch = load i8, ptr %digit_ptr, align 1
  %digit_ge = icmp uge i8 %digit_ch, 48
  %digit_le = icmp ule i8 %digit_ch, 57
  %is_digit = and i1 %digit_ge, %digit_le
  br i1 %is_digit, label %digit_continue, label %trail_entry

digit_continue:
  %digit64 = zext i8 %digit_ch to i64
  %digit_value = sub i64 %digit64, 48
  %value_x10 = mul i64 %value, 10
  %value_next = add i64 %value_x10, %digit_value
  %digit_next = add i64 %digit_idx, 1
  br label %digits

trail_entry:
  br label %trail

trail:
  %trail_idx = phi i64 [ %digit_idx, %trail_entry ], [ %trail_next, %trail_ws ]
  %trail_has = icmp ult i64 %trail_idx, %len
  br i1 %trail_has, label %trail_char, label %success

trail_char:
  %trail_ptr = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 %trail_idx
  %trail_ch = load i8, ptr %trail_ptr, align 1
  %trail_sp = icmp eq i8 %trail_ch, 32
  %trail_tab = icmp eq i8 %trail_ch, 9
  %trail_cr = icmp eq i8 %trail_ch, 13
  %trail_lf = icmp eq i8 %trail_ch, 10
  %trail_sp_tab = or i1 %trail_sp, %trail_tab
  %trail_cr_lf = or i1 %trail_cr, %trail_lf
  %trail_is_ws = or i1 %trail_sp_tab, %trail_cr_lf
  br i1 %trail_is_ws, label %trail_ws, label %fail

trail_ws:
  %trail_next = add i64 %trail_idx, 1
  br label %trail

success:
  %success_value = phi i64 [ %value, %digits ], [ %value, %trail ]
  %success0 = insertvalue %sollang.read_int_result poison, i64 %success_value, 0
  %success1 = insertvalue %sollang.read_int_result %success0, i32 1, 1
  ret %sollang.read_int_result %success1

fail:
  %fail0 = insertvalue %sollang.read_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.read_int_result %fail0, i32 0, 1
  ret %sollang.read_int_result %fail1
}
define dso_local void @__chkstk() naked nounwind {
entry:
  call void asm sideeffect inteldialect "push rcx\0Apush rax\0Alea rcx, [rsp + 24]\0Acmp rax, 4096\0Ajb .Lsollang_chkstk_tail\0A.Lsollang_chkstk_loop:\0Asub rcx, 4096\0Atest byte ptr [rcx], 0\0Asub rax, 4096\0Acmp rax, 4096\0Ajae .Lsollang_chkstk_loop\0A.Lsollang_chkstk_tail:\0Asub rcx, rax\0Atest byte ptr [rcx], 0\0Apop rax\0Apop rcx\0Aret", "~{memory},~{flags}"()
  unreachable
}

define internal i32 @sollang_write_stream_chunk(ptr %handle, ptr %data, i32 %len, ptr %written, i1 %is_console) #0 {
entry:
  %empty = icmp eq i32 %len, 0
  br i1 %empty, label %success_empty, label %classify

success_empty:
  store i32 0, ptr %written, align 4
  ret i32 1

classify:
  br i1 %is_console, label %console_prepare, label %redirected

redirected:
  br label %redirected_write

redirected_write:
  %redirected_offset = phi i32 [ 0, %redirected ], [ %redirected_next, %redirected_advance ]
  %redirected_remaining = sub i32 %len, %redirected_offset
  %redirected_offset64 = zext i32 %redirected_offset to i64
  %redirected_data = getelementptr i8, ptr %data, i64 %redirected_offset64
  store i32 0, ptr %written, align 4
  %redirected_ok = call i32 @WriteFile(ptr %handle, ptr %redirected_data, i32 %redirected_remaining, ptr %written, ptr null)
  %redirected_count = load i32, ptr %written, align 4
  %redirected_succeeded = icmp ne i32 %redirected_ok, 0
  %redirected_progress = icmp ugt i32 %redirected_count, 0
  %redirected_bounded = icmp ule i32 %redirected_count, %redirected_remaining
  %redirected_valid0 = and i1 %redirected_succeeded, %redirected_progress
  %redirected_valid = and i1 %redirected_valid0, %redirected_bounded
  br i1 %redirected_valid, label %redirected_advance, label %write_failed

redirected_advance:
  %redirected_next = add i32 %redirected_offset, %redirected_count
  %redirected_complete = icmp eq i32 %redirected_next, %len
  br i1 %redirected_complete, label %write_succeeded, label %redirected_write

console_prepare:
  %wide_chars = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %len, ptr null, i32 0)
  %valid_utf8 = icmp sgt i32 %wide_chars, 0
  br i1 %valid_utf8, label %allocate, label %conversion_failed

allocate:
  %wide_bytes32 = shl i32 %wide_chars, 1
  %wide_bytes = zext i32 %wide_bytes32 to i64
  %heap = call ptr @GetProcessHeap()
  %wide = call ptr @HeapAlloc(ptr %heap, i32 0, i64 %wide_bytes)
  %wide_written = alloca i32, align 4
  %allocated = icmp ne ptr %wide, null
  br i1 %allocated, label %convert, label %conversion_failed

convert:
  %converted = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %len, ptr %wide, i32 %wide_chars)
  %converted_all = icmp eq i32 %converted, %wide_chars
  br i1 %converted_all, label %console_write, label %conversion_free

console_write:
  %console_offset = phi i32 [ 0, %convert ], [ %console_next, %console_advance ]
  %console_remaining = sub i32 %wide_chars, %console_offset
  %console_offset64 = zext i32 %console_offset to i64
  %console_data = getelementptr i16, ptr %wide, i64 %console_offset64
  store i32 0, ptr %wide_written, align 4
  %console_ok = call i32 @WriteConsoleW(ptr %handle, ptr %console_data, i32 %console_remaining, ptr %wide_written, ptr null)
  %console_count = load i32, ptr %wide_written, align 4
  %console_succeeded = icmp ne i32 %console_ok, 0
  %console_progress = icmp ugt i32 %console_count, 0
  %console_bounded = icmp ule i32 %console_count, %console_remaining
  %console_valid0 = and i1 %console_succeeded, %console_progress
  %console_valid = and i1 %console_valid0, %console_bounded
  br i1 %console_valid, label %console_advance, label %console_write_failed

console_advance:
  %console_next = add i32 %console_offset, %console_count
  %console_complete = icmp eq i32 %console_next, %wide_chars
  br i1 %console_complete, label %console_write_succeeded, label %console_write

console_write_succeeded:
  %freed = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %write_succeeded

console_write_failed:
  %freed_after_write_failure = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %write_failed

write_succeeded:
  store i32 %len, ptr %written, align 4
  ret i32 1

write_failed:
  store i32 0, ptr %written, align 4
  ret i32 0

conversion_free:
  %freed_after_failure = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %conversion_failed

conversion_failed:
  store i32 0, ptr %written, align 4
  ret i32 0
}

define internal i32 @sollang_write_stream(ptr %handle, ptr %data, i64 %len64, ptr %written, i1 %is_console) #0 {
entry:
  %empty = icmp eq i64 %len64, 0
  br i1 %empty, label %success_empty, label %prepare

success_empty:
  store i32 0, ptr %written, align 4
  ret i32 1

prepare:
  %offset = phi i64 [ 0, %entry ], [ %next, %advance ]
  %remaining = sub i64 %len64, %offset
  %current = getelementptr i8, ptr %data, i64 %offset
  %more = icmp ugt i64 %remaining, 1048576
  %proposed = select i1 %more, i64 1048576, i64 %remaining
  %split_console = and i1 %more, %is_console
  br i1 %split_console, label %trim_boundary, label %write

trim_boundary:
  %boundary = phi i64 [ 1048576, %prepare ], [ %previous, %trim_next ]
  %boundary_ptr = getelementptr i8, ptr %current, i64 %boundary
  %boundary_byte = load i8, ptr %boundary_ptr, align 1
  %prefix = and i8 %boundary_byte, -64
  %continuation = icmp eq i8 %prefix, -128
  br i1 %continuation, label %trim_next, label %write

trim_next:
  %can_trim = icmp ugt i64 %boundary, 1048573
  %previous = sub i64 %boundary, 1
  br i1 %can_trim, label %trim_boundary, label %failure

write:
  %chunk64 = phi i64 [ %proposed, %prepare ], [ %boundary, %trim_boundary ]
  %chunk32 = trunc i64 %chunk64 to i32
  %ok = call i32 @sollang_write_stream_chunk(ptr %handle, ptr %current, i32 %chunk32, ptr %written, i1 %is_console)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %advance, label %failure

advance:
  %next = add i64 %offset, %chunk64
  %complete = icmp eq i64 %next, %len64
  br i1 %complete, label %success, label %prepare

success:
  ret i32 1

failure:
  store i32 0, ptr %written, align 4
  ret i32 0
}

define internal i32 @sollang_write_stdout_bytes(ptr %stdout, ptr %data, i32 %len, ptr %written) #0 {
entry:
  %is_console = load i1, ptr @sollang_stdout_line_buffered, align 1
  %ok = call i32 @sollang_write_stream_chunk(ptr %stdout, ptr %data, i32 %len, ptr %written, i1 %is_console)
  ret i32 %ok
}

define internal i32 @sollang_flush_stdout(ptr %stdout, ptr %written) #0 {
entry:
  %count64 = load i64, ptr @sollang_stdout_buffer_count, align 8
  %has_data = icmp ne i64 %count64, 0
  br i1 %has_data, label %write, label %empty

write:
  %count = trunc i64 %count64 to i32
  %buffer = getelementptr inbounds [1048576 x i8], ptr @sollang_stdout_buffer, i64 0, i64 0
  %ok = call i32 @sollang_write_stdout_bytes(ptr %stdout, ptr %buffer, i32 %count, ptr %written)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %clear, label %failure

clear:
  store i64 0, ptr @sollang_stdout_buffer_count, align 8
  ret i32 %ok

failure:
  call void @llvm.trap()
  unreachable

empty:
  store i32 0, ptr %written, align 4
  ret i32 1
}

define internal i32 @sollang_write(ptr %stdout, ptr %data, i64 %len64, ptr %written) #0 {
entry:
  br label %write_prepare

write_prepare:
  %oversized = icmp ugt i64 %len64, 1048576
  br i1 %oversized, label %write_direct_prepare, label %buffer_prepare

write_direct_prepare:
  %flushed_direct = call i32 @sollang_flush_stdout(ptr %stdout, ptr %written)
  %direct_console = load i1, ptr @sollang_stdout_line_buffered, align 1
  %direct_ok = call i32 @sollang_write_stream(ptr %stdout, ptr %data, i64 %len64, ptr %written, i1 %direct_console)
  %direct_succeeded = icmp ne i32 %direct_ok, 0
  br i1 %direct_succeeded, label %write_direct_done, label %write_direct_failure

write_direct_done:
  ret i32 1

write_direct_failure:
  call void @llvm.trap()
  unreachable

buffer_prepare:
  %count = load i64, ptr @sollang_stdout_buffer_count, align 8
  %combined = add i64 %count, %len64
  %needs_flush = icmp ugt i64 %combined, 1048576
  br i1 %needs_flush, label %flush, label %append

flush:
  %flushed = call i32 @sollang_flush_stdout(ptr %stdout, ptr %written)
  br label %append

append:
  %offset = phi i64 [ %count, %buffer_prepare ], [ 0, %flush ]
  %destination = getelementptr inbounds [1048576 x i8], ptr @sollang_stdout_buffer, i64 0, i64 %offset
  %copied = call ptr @memcpy(ptr %destination, ptr %data, i64 %len64)
  %next_count = add i64 %offset, %len64
  store i64 %next_count, ptr @sollang_stdout_buffer_count, align 8
  %written32 = trunc i64 %len64 to i32
  store i32 %written32, ptr %written, align 4
  %single_byte = icmp eq i64 %len64, 1
  br i1 %single_byte, label %inspect_newline, label %done

inspect_newline:
  %byte = load i8, ptr %data, align 1
  %newline = icmp eq i8 %byte, 10
  %line_buffered = load i1, ptr @sollang_stdout_line_buffered, align 1
  %flush_newline = and i1 %newline, %line_buffered
  br i1 %flush_newline, label %flush_line, label %done

flush_line:
  %line_ok = call i32 @sollang_flush_stdout(ptr %stdout, ptr %written)
  ret i32 %line_ok

done:
  ret i32 1
}

define internal i32 @sollang_read_stdin(ptr %stdin, ptr %data, i64 %len64, ptr %read) #0 {
entry:
  %exceeds_dword = icmp ugt i64 %len64, 4294967295
  %bounded_len = select i1 %exceeds_dword, i64 4294967295, i64 %len64
  %len = trunc i64 %bounded_len to i32
  %ok = call i32 @ReadFile(ptr %stdin, ptr %data, i32 %len, ptr %read, ptr null)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %success, label %inspect_error

inspect_error:
  %error = call i32 @GetLastError()
  %broken_pipe = icmp eq i32 %error, 109
  br i1 %broken_pipe, label %eof, label %failure

eof:
  store i32 0, ptr %read, align 4
  ret i32 1

success:
  ret i32 1

failure:
  ret i32 0
}
define internal i32 @sollang_platform_create_exclusive_file(ptr %path, i64 %len) #0 {
entry:
  %buf = alloca [260 x i16], align 2
  %buf_ptr = getelementptr inbounds [260 x i16], ptr %buf, i64 0, i64 0
  %fits = icmp ule i64 %len, 259
  br i1 %fits, label %convert, label %fail
convert:
  %copy_ok = call i32 @sollang_windows_utf8_path(ptr %path, i64 %len, ptr %buf_ptr, i32 260)
  %copied = icmp ne i32 %copy_ok, 0
  br i1 %copied, label %create, label %fail

create:
  %handle = call ptr @CreateFileW(ptr %buf_ptr, i32 1073741824, i32 0, ptr null, i32 1, i32 128, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %create_failed, label %close

close:
  %closed = call i32 @CloseHandle(ptr %handle)
  %close_ok = icmp ne i32 %closed, 0
  %status = select i1 %close_ok, i32 1, i32 -1
  ret i32 %status

create_failed:
  %error = call i32 @GetLastError()
  %file_exists = icmp eq i32 %error, 80
  %already_exists = icmp eq i32 %error, 183
  %exists = or i1 %file_exists, %already_exists
  %status_failed = select i1 %exists, i32 0, i32 -1
  ret i32 %status_failed

fail:
  ret i32 -1
}

define internal i32 @sollang_platform_remove_file(ptr %path, i64 %len) #0 {
entry:
  %buf = alloca [260 x i16], align 2
  %buf_ptr = getelementptr inbounds [260 x i16], ptr %buf, i64 0, i64 0
  %fits = icmp ule i64 %len, 259
  br i1 %fits, label %convert, label %fail
convert:
  %copy_ok = call i32 @sollang_windows_utf8_path(ptr %path, i64 %len, ptr %buf_ptr, i32 260)
  %copied = icmp ne i32 %copy_ok, 0
  br i1 %copied, label %remove, label %fail

remove:
  %removed = call i32 @DeleteFileW(ptr %buf_ptr)
  %success = icmp ne i32 %removed, 0
  br i1 %success, label %removed_file, label %remove_failed

removed_file:
  ret i32 1

remove_failed:
  %error = call i32 @GetLastError()
  %file_missing = icmp eq i32 %error, 2
  %path_missing = icmp eq i32 %error, 3
  %missing = or i1 %file_missing, %path_missing
  %status = select i1 %missing, i32 0, i32 -1
  ret i32 %status

fail:
  ret i32 -1
}

define internal i32 @sollang_platform_atomic_replace_file(ptr %temporary, i64 %temporary_len, ptr %destination, i64 %destination_len) #0 {
entry:
  %temporary_buf = alloca [260 x i16], align 2
  %temporary_ptr = getelementptr inbounds [260 x i16], ptr %temporary_buf, i64 0, i64 0
  %temporary_fits = icmp ule i64 %temporary_len, 259
  br i1 %temporary_fits, label %convert_temporary, label %fail
convert_temporary:
  %temporary_ok = call i32 @sollang_windows_utf8_path(ptr %temporary, i64 %temporary_len, ptr %temporary_ptr, i32 260)
  %temporary_valid = icmp ne i32 %temporary_ok, 0
  br i1 %temporary_valid, label %copy_destination, label %fail

copy_destination:
  %destination_buf = alloca [260 x i16], align 2
  %destination_ptr = getelementptr inbounds [260 x i16], ptr %destination_buf, i64 0, i64 0
  %destination_fits = icmp ule i64 %destination_len, 259
  br i1 %destination_fits, label %convert_destination, label %fail
convert_destination:
  %destination_ok = call i32 @sollang_windows_utf8_path(ptr %destination, i64 %destination_len, ptr %destination_ptr, i32 260)
  %destination_valid = icmp ne i32 %destination_ok, 0
  br i1 %destination_valid, label %replace, label %fail

replace:
  %result = call i32 @MoveFileExW(ptr %temporary_ptr, ptr %destination_ptr, i32 9)
  ret i32 %result

fail:
  ret i32 0
}

define internal %sollang.file_handle_result @sollang_platform_open_owned_read_file(ptr %path, i64 %len) #0 {
entry:
  %buf = alloca [260 x i16], align 2
  %buf_ptr = getelementptr inbounds [260 x i16], ptr %buf, i64 0, i64 0
  %fits = icmp ule i64 %len, 259
  br i1 %fits, label %convert, label %fail
convert:
  %copy_ok = call i32 @sollang_windows_utf8_path(ptr %path, i64 %len, ptr %buf_ptr, i32 260)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileW(ptr %buf_ptr, i32 -2147483648, i32 1, ptr null, i32 3, i32 1073741952, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  %ok0 = insertvalue %sollang.file_handle_result poison, i64 %handle_int, 0
  %ok1 = insertvalue %sollang.file_handle_result %ok0, i32 1, 1
  ret %sollang.file_handle_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_handle_result poison, i64 -1, 0
  %fail1 = insertvalue %sollang.file_handle_result %fail0, i32 0, 1
  ret %sollang.file_handle_result %fail1
}

define internal %sollang.file_handle_result @sollang_platform_open_owned_write_file(ptr %path, i64 %len) #0 {
entry:
  %buf = alloca [260 x i16], align 2
  %buf_ptr = getelementptr inbounds [260 x i16], ptr %buf, i64 0, i64 0
  %fits = icmp ule i64 %len, 259
  br i1 %fits, label %convert, label %fail
convert:
  %copy_ok = call i32 @sollang_windows_utf8_path(ptr %path, i64 %len, ptr %buf_ptr, i32 260)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileW(ptr %buf_ptr, i32 1073741824, i32 1, ptr null, i32 2, i32 1073741952, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  %ok0 = insertvalue %sollang.file_handle_result poison, i64 %handle_int, 0
  %ok1 = insertvalue %sollang.file_handle_result %ok0, i32 1, 1
  ret %sollang.file_handle_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_handle_result poison, i64 -1, 0
  %fail1 = insertvalue %sollang.file_handle_result %fail0, i32 0, 1
  ret %sollang.file_handle_result %fail1
}

define internal i64 @sollang_platform_duplicate_owned_file(i64 %source_value) #0 {
entry:
  %source = inttoptr i64 %source_value to ptr
  %process = call ptr @GetCurrentProcess()
  %target_slot = alloca ptr, align 8
  %ok = call i32 @DuplicateHandle(ptr %process, ptr %source, ptr %process, ptr %target_slot, i32 0, i32 0, i32 2)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %success, label %fail

success:
  %target = load ptr, ptr %target_slot, align 8
  %target_value = ptrtoint ptr %target to i64
  ret i64 %target_value

fail:
  ret i64 -1
}

define internal %sollang.file_count_result @sollang_platform_read_owned_file_at(i64 %handle_value, ptr %data, i64 %len64, i64 %offset) #0 {
entry:
  %valid_handle = icmp ne i64 %handle_value, -1
  %valid_offset = icmp ule i64 %offset, 9223372036854775807
  %fits = icmp ule i64 %len64, 4294967295
  %ready0 = and i1 %valid_handle, %valid_offset
  %ready = and i1 %ready0, %fits
  br i1 %ready, label %read, label %fail

read:
  %handle = inttoptr i64 %handle_value to ptr
  %overlapped = alloca [32 x i8], align 8
  call void @llvm.memset.p0.i64(ptr %overlapped, i8 0, i64 32, i1 false)
  %offset_low_slot = getelementptr i8, ptr %overlapped, i64 16
  %offset_low = trunc i64 %offset to i32
  store i32 %offset_low, ptr %offset_low_slot, align 4
  %offset_high_slot = getelementptr i8, ptr %overlapped, i64 20
  %offset_shifted = lshr i64 %offset, 32
  %offset_high = trunc i64 %offset_shifted to i32
  store i32 %offset_high, ptr %offset_high_slot, align 4
  %count_slot = alloca i32, align 4
  store i32 0, ptr %count_slot, align 4
  %len = trunc i64 %len64 to i32
  %started = call i32 @ReadFile(ptr %handle, ptr %data, i32 %len, ptr null, ptr %overlapped)
  %completed = call i32 @GetOverlappedResult(ptr %handle, ptr %overlapped, ptr %count_slot, i32 1)
  %ok = icmp ne i32 %completed, 0
  br i1 %ok, label %success, label %classify_failure

classify_failure:
  %error = call i32 @GetLastError()
  %eof = icmp eq i32 %error, 38
  br i1 %eof, label %success, label %fail

success:
  %count32 = load i32, ptr %count_slot, align 4
  %count = zext i32 %count32 to i64
  %ok0 = insertvalue %sollang.file_count_result poison, i64 %count, 0
  %ok1 = insertvalue %sollang.file_count_result %ok0, i32 1, 1
  ret %sollang.file_count_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_count_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.file_count_result %fail0, i32 0, 1
  ret %sollang.file_count_result %fail1
}

define internal %sollang.file_count_result @sollang_platform_write_owned_file_at(i64 %handle_value, ptr %data, i64 %len64, i64 %offset) #0 {
entry:
  %valid_handle = icmp ne i64 %handle_value, -1
  %valid_offset = icmp ule i64 %offset, 9223372036854775807
  %fits = icmp ule i64 %len64, 4294967295
  %ready0 = and i1 %valid_handle, %valid_offset
  %ready = and i1 %ready0, %fits
  br i1 %ready, label %write, label %fail

write:
  %handle = inttoptr i64 %handle_value to ptr
  %overlapped = alloca [32 x i8], align 8
  call void @llvm.memset.p0.i64(ptr %overlapped, i8 0, i64 32, i1 false)
  %offset_low_slot = getelementptr i8, ptr %overlapped, i64 16
  %offset_low = trunc i64 %offset to i32
  store i32 %offset_low, ptr %offset_low_slot, align 4
  %offset_high_slot = getelementptr i8, ptr %overlapped, i64 20
  %offset_shifted = lshr i64 %offset, 32
  %offset_high = trunc i64 %offset_shifted to i32
  store i32 %offset_high, ptr %offset_high_slot, align 4
  %count_slot = alloca i32, align 4
  store i32 0, ptr %count_slot, align 4
  %len = trunc i64 %len64 to i32
  %started = call i32 @WriteFile(ptr %handle, ptr %data, i32 %len, ptr null, ptr %overlapped)
  %completed = call i32 @GetOverlappedResult(ptr %handle, ptr %overlapped, ptr %count_slot, i32 1)
  %ok = icmp ne i32 %completed, 0
  br i1 %ok, label %success, label %fail

success:
  %count32 = load i32, ptr %count_slot, align 4
  %count = zext i32 %count32 to i64
  %ok0 = insertvalue %sollang.file_count_result poison, i64 %count, 0
  %ok1 = insertvalue %sollang.file_count_result %ok0, i32 1, 1
  ret %sollang.file_count_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_count_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.file_count_result %fail0, i32 0, 1
  ret %sollang.file_count_result %fail1
}

define internal i32 @sollang_platform_sync_owned_file(i64 %handle_value) #0 {
entry:
  %valid = icmp ne i64 %handle_value, -1
  br i1 %valid, label %sync, label %fail

sync:
  %handle = inttoptr i64 %handle_value to ptr
  %ok = call i32 @FlushFileBuffers(ptr %handle)
  ret i32 %ok

fail:
  ret i32 0
}

define internal void @sollang_platform_close_owned_file(i64 %handle_value) #0 {
entry:
  %valid = icmp ne i64 %handle_value, -1
  br i1 %valid, label %close, label %done

close:
  %handle = inttoptr i64 %handle_value to ptr
  %ignored = call i32 @CloseHandle(ptr %handle)
  br label %done

done:
  ret void
}

define internal i32 @sollang_platform_open_write_file(ptr %path, i64 %len) #0 {
entry:
  %buf = alloca [260 x i8], align 1
  %buf_ptr = getelementptr inbounds [260 x i8], ptr %buf, i64 0, i64 0
  %copy_ok = call i32 @sollang_copy_text_to_c_path(ptr %path, i64 %len, ptr %buf_ptr)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileA(ptr %buf_ptr, i32 1073741824, i32 0, ptr null, i32 2, i32 128, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  store ptr %handle, ptr @sollang_file_writer, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_platform_write_file_bytes(ptr %data, i64 %len64) #0 {
entry:
  %handle = load ptr, ptr @sollang_file_writer, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %write, label %fail

write:
  %written = alloca i32, align 4
  %len = trunc i64 %len64 to i32
  %ok = call i32 @WriteFile(ptr %handle, ptr %data, i32 %len, ptr %written, ptr null)
  %written32 = load i32, ptr %written, align 4
  %written64 = zext i32 %written32 to i64
  %write_ok = icmp ne i32 %ok, 0
  %full = icmp eq i64 %written64, %len64
  %all_ok = and i1 %write_ok, %full
  %result = zext i1 %all_ok to i32
  ret i32 %result

fail:
  ret i32 0
}

define internal i32 @sollang_platform_close_write_file() #0 {
entry:
  %handle = load ptr, ptr @sollang_file_writer, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %close, label %fail

close:
  %ok = call i32 @CloseHandle(ptr %handle)
  %close_ok = icmp ne i32 %ok, 0
  br i1 %close_ok, label %success, label %fail

success:
  store ptr null, ptr @sollang_file_writer, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_platform_open_read_file(ptr %path, i64 %len) #0 {
entry:
  %buf = alloca [260 x i8], align 1
  %buf_ptr = getelementptr inbounds [260 x i8], ptr %buf, i64 0, i64 0
  %copy_ok = call i32 @sollang_copy_text_to_c_path(ptr %path, i64 %len, ptr %buf_ptr)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileA(ptr %buf_ptr, i32 -2147483648, i32 1, ptr null, i32 3, i32 128, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  store ptr %handle, ptr @sollang_file_reader, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal %sollang.file_count_result @sollang_platform_i64_file_count() #0 {
entry:
  %handle = load ptr, ptr @sollang_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %size, label %fail

size:
  %size_ptr = alloca i64, align 8
  %ok = call i32 @GetFileSizeEx(ptr %handle, ptr %size_ptr)
  %size_ok = icmp ne i32 %ok, 0
  br i1 %size_ok, label %check, label %fail

check:
  %bytes = load i64, ptr %size_ptr, align 8
  %rem = urem i64 %bytes, 8
  %aligned = icmp eq i64 %rem, 0
  br i1 %aligned, label %success, label %fail

success:
  %count = udiv i64 %bytes, 8
  %ok0 = insertvalue %sollang.file_count_result poison, i64 %count, 0
  %ok1 = insertvalue %sollang.file_count_result %ok0, i32 1, 1
  ret %sollang.file_count_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_count_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.file_count_result %fail0, i32 0, 1
  ret %sollang.file_count_result %fail1
}

define internal %sollang.file_int_result @sollang_platform_read_i64_at(i64 %index) #0 {
entry:
  %handle = load ptr, ptr @sollang_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %seek, label %fail

seek:
  %offset = mul i64 %index, 8
  %seek_ok = call i32 @SetFilePointerEx(ptr %handle, i64 %offset, ptr null, i32 0)
  %seek_is_ok = icmp ne i32 %seek_ok, 0
  br i1 %seek_is_ok, label %read, label %fail

read:
  %value_ptr = alloca i64, align 8
  %read_bytes = alloca i32, align 4
  %ok = call i32 @ReadFile(ptr %handle, ptr %value_ptr, i32 8, ptr %read_bytes, ptr null)
  %read_ok = icmp ne i32 %ok, 0
  %read_count = load i32, ptr %read_bytes, align 4
  %read_full = icmp eq i32 %read_count, 8
  %all_ok = and i1 %read_ok, %read_full
  br i1 %all_ok, label %success, label %fail

success:
  %value = load i64, ptr %value_ptr, align 8
  %ok0 = insertvalue %sollang.file_int_result poison, i64 %value, 0
  %ok1 = insertvalue %sollang.file_int_result %ok0, i32 1, 1
  ret %sollang.file_int_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.file_int_result %fail0, i32 0, 1
  ret %sollang.file_int_result %fail1
}

define internal %sollang.file_count_result @sollang_platform_read_file_bytes(ptr %data, i64 %len64) #0 {
entry:
  %handle = load ptr, ptr @sollang_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  %fits = icmp ule i64 %len64, 4294967295
  %ready = and i1 %has_handle, %fits
  br i1 %ready, label %read, label %fail

read:
  %len = trunc i64 %len64 to i32
  %count_ptr = alloca i32, align 4
  %result = call i32 @ReadFile(ptr %handle, ptr %data, i32 %len, ptr %count_ptr, ptr null)
  %ok = icmp ne i32 %result, 0
  br i1 %ok, label %success, label %fail

success:
  %count32 = load i32, ptr %count_ptr, align 4
  %count = zext i32 %count32 to i64
  %ok0 = insertvalue %sollang.file_count_result poison, i64 %count, 0
  %ok1 = insertvalue %sollang.file_count_result %ok0, i32 1, 1
  ret %sollang.file_count_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_count_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.file_count_result %fail0, i32 0, 1
  ret %sollang.file_count_result %fail1
}

define internal i32 @sollang_platform_close_read_file() #0 {
entry:
  %handle = load ptr, ptr @sollang_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %close, label %fail

close:
  %ok = call i32 @CloseHandle(ptr %handle)
  %close_ok = icmp ne i32 %ok, 0
  br i1 %close_ok, label %success, label %fail

success:
  store ptr null, ptr @sollang_file_reader, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal %sollang.mapped_bytes @sollang_map_file(ptr %path, i64 %path_len, i64 %offset, i64 %requested_len, i64 %requested_size, i1 %writable) #0 {
entry:
  %buf = alloca [260 x i16], align 2
  %buf_ptr = getelementptr inbounds [260 x i16], ptr %buf, i64 0, i64 0
  %copy_ok = call i32 @sollang_windows_utf8_path(ptr %path, i64 %path_len, ptr %buf_ptr, i32 260)
  %path_ok = icmp ne i32 %copy_ok, 0
  br i1 %path_ok, label %open, label %fail

open:
  %access = select i1 %writable, i32 -1073741824, i32 -2147483648
  %creation = select i1 %writable, i32 4, i32 3
  %file = call ptr @CreateFileW(ptr %buf_ptr, i32 %access, i32 1, ptr null, i32 %creation, i32 128, ptr null)
  %file_int = ptrtoint ptr %file to i64
  %file_ok = icmp ne i64 %file_int, -1
  br i1 %file_ok, label %resize_check, label %fail

resize_check:
  %has_requested_size = icmp ne i64 %requested_size, 0
  %resize = and i1 %writable, %has_requested_size
  br i1 %resize, label %resize_file, label %read_size

resize_file:
  %seek_ok = call i32 @SetFilePointerEx(ptr %file, i64 %requested_size, ptr null, i32 0)
  %seek_valid = icmp ne i32 %seek_ok, 0
  br i1 %seek_valid, label %resize_end, label %close_fail

resize_end:
  %end_ok = call i32 @SetEndOfFile(ptr %file)
  %resize_valid = icmp ne i32 %end_ok, 0
  br i1 %resize_valid, label %read_size, label %close_fail

read_size:
  %size_slot = alloca i64, align 8
  %size_ok = call i32 @GetFileSizeEx(ptr %file, ptr %size_slot)
  %size_valid = icmp ne i32 %size_ok, 0
  br i1 %size_valid, label %bounds, label %close_fail

bounds:
  %file_size = load i64, ptr %size_slot, align 8
  %offset_ok = icmp ule i64 %offset, %file_size
  %remaining = sub i64 %file_size, %offset
  %whole = icmp eq i64 %requested_len, 0
  %view_len = select i1 %whole, i64 %remaining, i64 %requested_len
  %len_nonzero = icmp ne i64 %view_len, 0
  %len_ok = icmp ule i64 %view_len, %remaining
  %bounds1 = and i1 %offset_ok, %len_nonzero
  %bounds_ok = and i1 %bounds1, %len_ok
  br i1 %bounds_ok, label %mapping, label %close_fail

mapping:
  %protect = select i1 %writable, i32 4, i32 2
  %mapping_handle = call ptr @CreateFileMappingA(ptr %file, ptr null, i32 %protect, i32 0, i32 0, ptr null)
  %mapping_ok = icmp ne ptr %mapping_handle, null
  br i1 %mapping_ok, label %view, label %close_fail

view:
  %aligned = and i64 %offset, -65536
  %delta = sub i64 %offset, %aligned
  %mapped_len = add i64 %delta, %view_len
  %high64 = lshr i64 %aligned, 32
  %high = trunc i64 %high64 to i32
  %low = trunc i64 %aligned to i32
  %desired = select i1 %writable, i32 2, i32 4
  %base = call ptr @MapViewOfFile(ptr %mapping_handle, i32 %desired, i32 %high, i32 %low, i64 %mapped_len)
  %base_ok = icmp ne ptr %base, null
  br i1 %base_ok, label %success, label %mapping_close_fail

success:
  %data = getelementptr i8, ptr %base, i64 %delta
  %ignored_mapping = call i32 @CloseHandle(ptr %mapping_handle)
  %ignored_file = call i32 @CloseHandle(ptr %file)
  %r0 = insertvalue %sollang.mapped_bytes poison, ptr %data, 0
  %r1 = insertvalue %sollang.mapped_bytes %r0, i64 %view_len, 1
  %r2 = insertvalue %sollang.mapped_bytes %r1, ptr %base, 2
  %r3 = insertvalue %sollang.mapped_bytes %r2, i64 %mapped_len, 3
  %r4 = insertvalue %sollang.mapped_bytes %r3, i1 %writable, 4
  ret %sollang.mapped_bytes %r4

mapping_close_fail:
  %ignored_mapping_fail = call i32 @CloseHandle(ptr %mapping_handle)
  br label %close_fail

close_fail:
  %ignored_close = call i32 @CloseHandle(ptr %file)
  br label %fail

fail:
  %f0 = insertvalue %sollang.mapped_bytes zeroinitializer, i1 %writable, 4
  ret %sollang.mapped_bytes %f0
}

define internal i32 @sollang_mapped_flush(ptr %base, i64 %mapped_len) #0 {
entry:
  %ok = call i32 @FlushViewOfFile(ptr %base, i64 %mapped_len)
  ret i32 %ok
}

define internal void @sollang_mapped_unmap(ptr %base, i64 %mapped_len) #0 {
entry:
  %ignored = call i32 @UnmapViewOfFile(ptr %base)
  ret void
}

define internal i64 @sollang_now_millis() #0 {
entry:
  %millis = call i64 @GetTickCount64()
  ret i64 %millis
}

define internal i64 @sollang_utc_now_millis() #0 {
entry:
  %filetime = alloca [2 x i32], align 4
  call void @GetSystemTimePreciseAsFileTime(ptr %filetime)
  %low_ptr = getelementptr inbounds [2 x i32], ptr %filetime, i64 0, i64 0
  %high_ptr = getelementptr inbounds [2 x i32], ptr %filetime, i64 0, i64 1
  %low32 = load i32, ptr %low_ptr, align 4
  %high32 = load i32, ptr %high_ptr, align 4
  %low = zext i32 %low32 to i64
  %high = zext i32 %high32 to i64
  %shifted = shl i64 %high, 32
  %ticks = or i64 %shifted, %low
  %unix_ticks = sub i64 %ticks, 116444736000000000
  %millis = udiv i64 %unix_ticks, 10000
  ret i64 %millis
}

define internal void @sollang_wait_millis(i64 %requested) #0 {
entry:
  %positive = icmp sgt i64 %requested, 0
  br i1 %positive, label %clamp, label %done

clamp:
  %too_large = icmp ugt i64 %requested, 4294967294
  %bounded = select i1 %too_large, i64 4294967294, i64 %requested
  %millis = trunc i64 %bounded to i32
  call void @Sleep(i32 %millis)
  br label %done

done:
  ret void
}

define internal ptr @sollang_alloc(i64 %bytes) #0 {
entry:
  %heap = call ptr @GetProcessHeap()
  %ptr = call ptr @HeapAlloc(ptr %heap, i32 0, i64 %bytes)
  ret ptr %ptr
}

define internal void @sollang_free(ptr %ptr) #0 {
entry:
  %is_null = icmp eq ptr %ptr, null
  br i1 %is_null, label %done, label %free

free:
  %heap = call ptr @GetProcessHeap()
  %ignored = call i32 @HeapFree(ptr %heap, i32 0, ptr %ptr)
  br label %done

done:
  ret void
}

define dso_local ptr @memset(ptr %dest, i32 %value, i64 %count) #0 {
entry:
  %byte = trunc i32 %value to i8
  br label %loop

loop:
  %i = phi i64 [ 0, %entry ], [ %next, %body ]
  %active = icmp ult i64 %i, %count
  br i1 %active, label %body, label %done

body:
  %slot = getelementptr i8, ptr %dest, i64 %i
  store i8 %byte, ptr %slot, align 1
  %next = add i64 %i, 1
  br label %loop

done:
  ret ptr %dest
}

define dso_local ptr @memcpy(ptr %dest, ptr %source, i64 %count) #0 {
entry:
  br label %loop

loop:
  %i = phi i64 [ 0, %entry ], [ %next, %body ]
  %active = icmp ult i64 %i, %count
  br i1 %active, label %body, label %done

body:
  %src_slot = getelementptr i8, ptr %source, i64 %i
  %dst_slot = getelementptr i8, ptr %dest, i64 %i
  %byte = load i8, ptr %src_slot, align 1
  store i8 %byte, ptr %dst_slot, align 1
  %next = add i64 %i, 1
  br label %loop

done:
  ret ptr %dest
}

define dso_local ptr @memmove(ptr %dest, ptr %source, i64 %count) #0 {
entry:
  %same = icmp eq ptr %dest, %source
  %empty = icmp eq i64 %count, 0
  %done_early = or i1 %same, %empty
  br i1 %done_early, label %done, label %choose_direction

choose_direction:
  %forward = icmp ult ptr %dest, %source
  br i1 %forward, label %forward_loop, label %backward_loop

forward_loop:
  %forward_i = phi i64 [ 0, %choose_direction ], [ %forward_next, %forward_body ]
  %forward_active = icmp ult i64 %forward_i, %count
  br i1 %forward_active, label %forward_body, label %done

forward_body:
  %forward_src = getelementptr i8, ptr %source, i64 %forward_i
  %forward_dst = getelementptr i8, ptr %dest, i64 %forward_i
  %forward_byte = load i8, ptr %forward_src, align 1
  store i8 %forward_byte, ptr %forward_dst, align 1
  %forward_next = add i64 %forward_i, 1
  br label %forward_loop

backward_loop:
  %backward_i = phi i64 [ %count, %choose_direction ], [ %backward_next, %backward_body ]
  %backward_active = icmp ugt i64 %backward_i, 0
  br i1 %backward_active, label %backward_body, label %done

backward_body:
  %backward_next = sub i64 %backward_i, 1
  %backward_src = getelementptr i8, ptr %source, i64 %backward_next
  %backward_dst = getelementptr i8, ptr %dest, i64 %backward_next
  %backward_byte = load i8, ptr %backward_src, align 1
  store i8 %backward_byte, ptr %backward_dst, align 1
  br label %backward_loop

done:
  ret ptr %dest
}
define internal i64 @sollang_format_u64(ptr %dest, i64 %value) #0 {
entry:
  br label %count

count:
  %count_n = phi i64 [ %value, %entry ], [ %count_q, %count_more ]
  %length = phi i64 [ 1, %entry ], [ %next_length, %count_more ]
  %count_q = udiv i64 %count_n, 10
  %count_done = icmp eq i64 %count_q, 0
  br i1 %count_done, label %write_entry, label %count_more

count_more:
  %next_length = add i64 %length, 1
  br label %count

write_entry:
  %last_index = sub i64 %length, 1
  br label %write

write:
  %write_n = phi i64 [ %value, %write_entry ], [ %write_q, %write ]
  %index = phi i64 [ %last_index, %write_entry ], [ %previous_index, %write ]
  %digit = urem i64 %write_n, 10
  %write_q = udiv i64 %write_n, 10
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  %slot = getelementptr i8, ptr %dest, i64 %index
  store i8 %ascii, ptr %slot, align 1
  %previous_index = sub i64 %index, 1
  %write_done = icmp eq i64 %write_q, 0
  br i1 %write_done, label %return, label %write

return:
  ret i64 %length
}

define internal i64 @sollang_format_i64(ptr %dest, i64 %value) #0 {
entry:
  %negative = icmp slt i64 %value, 0
  br i1 %negative, label %negative_value, label %positive_value

negative_value:
  store i8 45, ptr %dest, align 1
  %digits_dest = getelementptr i8, ptr %dest, i64 1
  %magnitude = sub i64 0, %value
  %negative_digits = call i64 @sollang_format_u64(ptr %digits_dest, i64 %magnitude)
  %negative_length = add i64 %negative_digits, 1
  ret i64 %negative_length

positive_value:
  %positive_length = call i64 @sollang_format_u64(ptr %dest, i64 %value)
  ret i64 %positive_length
}

define internal i32 @sollang_write_u64(ptr %stdout, i64 %value, ptr %written) #0 {
entry:
  %buffer = alloca [20 x i8], align 1
  %data = getelementptr inbounds [20 x i8], ptr %buffer, i64 0, i64 0
  %length = call i64 @sollang_format_u64(ptr %data, i64 %value)
  %ok = call i32 @sollang_write(ptr %stdout, ptr %data, i64 %length, ptr %written)
  ret i32 %ok
}

define internal i32 @sollang_write_i64(ptr %stdout, i64 %value, ptr %written) #0 {
entry:
  %buffer = alloca [21 x i8], align 1
  %data = getelementptr inbounds [21 x i8], ptr %buffer, i64 0, i64 0
  %length = call i64 @sollang_format_i64(ptr %data, i64 %value)
  %ok = call i32 @sollang_write(ptr %stdout, ptr %data, i64 %length, ptr %written)
  ret i32 %ok
}

define internal i32 @sollang_copy_text_to_c_path(ptr %data, i64 %len, ptr %out) #0 {
entry:
  %too_long = icmp ugt i64 %len, 259
  br i1 %too_long, label %fail, label %copy

copy:
  %i = phi i64 [ 0, %entry ], [ %next, %copy_body ]
  %done = icmp eq i64 %i, %len
  br i1 %done, label %nul, label %copy_body

copy_body:
  %src = getelementptr i8, ptr %data, i64 %i
  %ch = load i8, ptr %src, align 1
  %dst = getelementptr i8, ptr %out, i64 %i
  store i8 %ch, ptr %dst, align 1
  %next = add i64 %i, 1
  br label %copy

nul:
  %nul_ptr = getelementptr i8, ptr %out, i64 %len
  store i8 0, ptr %nul_ptr, align 1
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_file_path_has_no_nul(ptr %data, i64 %len) #0 {
entry:
  br label %check

check:
  %i = phi i64 [ 0, %entry ], [ %next, %advance ]
  %done = icmp eq i64 %i, %len
  br i1 %done, label %valid, label %read

read:
  %src = getelementptr i8, ptr %data, i64 %i
  %ch = load i8, ptr %src, align 1
  %is_nul = icmp eq i8 %ch, 0
  br i1 %is_nul, label %invalid, label %advance

advance:
  %next = add i64 %i, 1
  br label %check

valid:
  ret i32 1

invalid:
  ret i32 0
}

define internal i32 @sollang_seed_random(i64 %seed) #0 {
entry:
  store i64 %seed, ptr @sollang_random_state, align 8
  ret i32 1
}

define internal %sollang.file_int_result @sollang_random_below(i64 %max) #0 {
entry:
  %valid = icmp sgt i64 %max, 0
  br i1 %valid, label %next, label %fail

next:
  %state = load i64, ptr @sollang_random_state, align 8
  %mul = mul i64 %state, 6364136223846793005
  %new_state = add i64 %mul, 1442695040888963407
  store i64 %new_state, ptr @sollang_random_state, align 8
  %value = urem i64 %new_state, %max
  %ok0 = insertvalue %sollang.file_int_result poison, i64 %value, 0
  %ok1 = insertvalue %sollang.file_int_result %ok0, i32 1, 1
  ret %sollang.file_int_result %ok1

fail:
  %fail0 = insertvalue %sollang.file_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.file_int_result %fail0, i32 0, 1
  ret %sollang.file_int_result %fail1
}

define internal i32 @sollang_open_write_i64_file(ptr %path, i64 %len) #0 {
entry:
  store i64 0, ptr @sollang_writer_buffer_count, align 8
  %ok = call i32 @sollang_platform_open_write_file(ptr %path, i64 %len)
  ret i32 %ok
}

define internal i32 @sollang_flush_i64_file() #0 {
entry:
  %count = load i64, ptr @sollang_writer_buffer_count, align 8
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %success, label %flush

flush:
  %bytes = mul i64 %count, 8
  %ok = call i32 @sollang_platform_write_file_bytes(ptr @sollang_writer_buffer, i64 %bytes)
  %is_ok = icmp ne i32 %ok, 0
  br i1 %is_ok, label %reset, label %fail

reset:
  store i64 0, ptr @sollang_writer_buffer_count, align 8
  br label %success

success:
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_write_i64_file(i64 %value) #0 {
entry:
  %count = load i64, ptr @sollang_writer_buffer_count, align 8
  %slot = getelementptr inbounds [8192 x i64], ptr @sollang_writer_buffer, i64 0, i64 %count
  store i64 %value, ptr %slot, align 8
  %next = add i64 %count, 1
  store i64 %next, ptr @sollang_writer_buffer_count, align 8
  %full = icmp eq i64 %next, 8192
  br i1 %full, label %flush, label %success

flush:
  %ok = call i32 @sollang_flush_i64_file()
  ret i32 %ok

success:
  ret i32 1
}

define internal i32 @sollang_close_write_i64_file() #0 {
entry:
  %flush_ok = call i32 @sollang_flush_i64_file()
  %flush_is_ok = icmp ne i32 %flush_ok, 0
  br i1 %flush_is_ok, label %close, label %fail

close:
  %close_ok = call i32 @sollang_platform_close_write_file()
  ret i32 %close_ok

fail:
  ret i32 0
}

define internal %sollang.file_int_result @sollang_closest_i64_file(i64 %target) #0 {
entry:
  %count_result = call %sollang.file_count_result @sollang_platform_i64_file_count()
  %count = extractvalue %sollang.file_count_result %count_result, 0
  %count_ok = extractvalue %sollang.file_count_result %count_result, 1
  %count_is_ok = icmp ne i32 %count_ok, 0
  %has_values = icmp sgt i64 %count, 0
  %can_search = and i1 %count_is_ok, %has_values
  br i1 %can_search, label %search, label %fail

search:
  br label %loop

loop:
  %low = phi i64 [ 0, %search ], [ %next_low, %step ]
  %high = phi i64 [ %count, %search ], [ %next_high, %step ]
  %active = icmp slt i64 %low, %high
  br i1 %active, label %probe, label %choose

probe:
  %span = sub i64 %high, %low
  %half = sdiv i64 %span, 2
  %mid = add i64 %low, %half
  %mid_result = call %sollang.file_int_result @sollang_platform_read_i64_at(i64 %mid)
  %mid_value = extractvalue %sollang.file_int_result %mid_result, 0
  %mid_ok = extractvalue %sollang.file_int_result %mid_result, 1
  %mid_is_ok = icmp ne i32 %mid_ok, 0
  br i1 %mid_is_ok, label %compare_mid, label %fail

compare_mid:
  %less = icmp slt i64 %mid_value, %target
  br i1 %less, label %move_low, label %move_high

move_low:
  %low_plus = add i64 %mid, 1
  br label %step

move_high:
  br label %step

step:
  %next_low = phi i64 [ %low_plus, %move_low ], [ %low, %move_high ]
  %next_high = phi i64 [ %high, %move_low ], [ %mid, %move_high ]
  br label %loop

choose:
  %at_start = icmp eq i64 %low, 0
  br i1 %at_start, label %read_low, label %check_end

check_end:
  %at_end = icmp eq i64 %low, %count
  br i1 %at_end, label %read_prev_only, label %read_pair

read_low:
  %first_result = call %sollang.file_int_result @sollang_platform_read_i64_at(i64 0)
  ret %sollang.file_int_result %first_result

read_prev_only:
  %last_index = sub i64 %count, 1
  %last_result = call %sollang.file_int_result @sollang_platform_read_i64_at(i64 %last_index)
  ret %sollang.file_int_result %last_result

read_pair:
  %prev_index = sub i64 %low, 1
  %prev_result = call %sollang.file_int_result @sollang_platform_read_i64_at(i64 %prev_index)
  %next_result = call %sollang.file_int_result @sollang_platform_read_i64_at(i64 %low)
  %prev_ok = extractvalue %sollang.file_int_result %prev_result, 1
  %next_ok = extractvalue %sollang.file_int_result %next_result, 1
  %prev_is_ok = icmp ne i32 %prev_ok, 0
  %next_is_ok = icmp ne i32 %next_ok, 0
  %both_ok = and i1 %prev_is_ok, %next_is_ok
  br i1 %both_ok, label %compare_pair, label %fail

compare_pair:
  %prev_value = extractvalue %sollang.file_int_result %prev_result, 0
  %next_value = extractvalue %sollang.file_int_result %next_result, 0
  %prev_diff = sub i64 %target, %prev_value
  %next_diff = sub i64 %next_value, %target
  %prefer_prev = icmp sle i64 %prev_diff, %next_diff
  br i1 %prefer_prev, label %return_prev, label %return_next

return_prev:
  ret %sollang.file_int_result %prev_result

return_next:
  ret %sollang.file_int_result %next_result

fail:
  %fail0 = insertvalue %sollang.file_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.file_int_result %fail0, i32 0, 1
  ret %sollang.file_int_result %fail1
}

define internal i64 @sollang_utf8_decode(ptr %data, i64 %len, i64 %index) #0 {
entry:
  %has_first = icmp ult i64 %index, %len
  br i1 %has_first, label %first, label %invalid

first:
  %p0 = getelementptr i8, ptr %data, i64 %index
  %b0raw = load i8, ptr %p0, align 1
  %b0 = zext i8 %b0raw to i32
  %ascii = icmp ult i32 %b0, 128
  br i1 %ascii, label %ascii_result, label %classify

ascii_result:
  %ascii_wide = zext i32 %b0 to i64
  %ascii_packed = or i64 %ascii_wide, 4294967296
  ret i64 %ascii_packed

classify:
  %is2lo = icmp uge i32 %b0, 194
  %is2hi = icmp ule i32 %b0, 223
  %is2 = and i1 %is2lo, %is2hi
  %is3lo = icmp uge i32 %b0, 224
  %is3hi = icmp ule i32 %b0, 239
  %is3 = and i1 %is3lo, %is3hi
  %is4lo = icmp uge i32 %b0, 240
  %is4hi = icmp ule i32 %b0, 244
  %is4 = and i1 %is4lo, %is4hi
  br i1 %is2, label %decode2, label %check3

check3:
  br i1 %is3, label %decode3, label %check4

check4:
  br i1 %is4, label %decode4, label %invalid

decode2:
  %end2 = add i64 %index, 1
  %has2 = icmp ult i64 %end2, %len
  br i1 %has2, label %load2, label %invalid

load2:
  %p1_2 = getelementptr i8, ptr %data, i64 %end2
  %b1_2raw = load i8, ptr %p1_2, align 1
  %b1_2 = zext i8 %b1_2raw to i32
  %c1_2lo = icmp uge i32 %b1_2, 128
  %c1_2hi = icmp ule i32 %b1_2, 191
  %c1_2 = and i1 %c1_2lo, %c1_2hi
  br i1 %c1_2, label %result2, label %invalid

result2:
  %h2 = and i32 %b0, 31
  %h2s = shl i32 %h2, 6
  %l2 = and i32 %b1_2, 63
  %cp2 = or i32 %h2s, %l2
  %cp2wide = zext i32 %cp2 to i64
  %packed2 = or i64 %cp2wide, 8589934592
  ret i64 %packed2

decode3:
  %end3 = add i64 %index, 2
  %has3 = icmp ult i64 %end3, %len
  br i1 %has3, label %load3, label %invalid

load3:
  %i1_3 = add i64 %index, 1
  %p1_3 = getelementptr i8, ptr %data, i64 %i1_3
  %p2_3 = getelementptr i8, ptr %data, i64 %end3
  %b1_3raw = load i8, ptr %p1_3, align 1
  %b2_3raw = load i8, ptr %p2_3, align 1
  %b1_3 = zext i8 %b1_3raw to i32
  %b2_3 = zext i8 %b2_3raw to i32
  %c1_3lo = icmp uge i32 %b1_3, 128
  %c1_3hi = icmp ule i32 %b1_3, 191
  %c1_3 = and i1 %c1_3lo, %c1_3hi
  %c2_3lo = icmp uge i32 %b2_3, 128
  %c2_3hi = icmp ule i32 %b2_3, 191
  %c2_3 = and i1 %c2_3lo, %c2_3hi
  %cont3 = and i1 %c1_3, %c2_3
  br i1 %cont3, label %value3, label %invalid

value3:
  %h3 = and i32 %b0, 15
  %h3s = shl i32 %h3, 12
  %m3 = and i32 %b1_3, 63
  %m3s = shl i32 %m3, 6
  %hm3 = or i32 %h3s, %m3s
  %l3 = and i32 %b2_3, 63
  %cp3 = or i32 %hm3, %l3
  %min3 = icmp uge i32 %cp3, 2048
  %below_surrogate = icmp ult i32 %cp3, 55296
  %above_surrogate = icmp ugt i32 %cp3, 57343
  %not_surrogate = or i1 %below_surrogate, %above_surrogate
  %valid3 = and i1 %min3, %not_surrogate
  br i1 %valid3, label %result3, label %invalid

result3:
  %cp3wide = zext i32 %cp3 to i64
  %packed3 = or i64 %cp3wide, 12884901888
  ret i64 %packed3

decode4:
  %end4 = add i64 %index, 3
  %has4 = icmp ult i64 %end4, %len
  br i1 %has4, label %load4, label %invalid

load4:
  %i1_4 = add i64 %index, 1
  %i2_4 = add i64 %index, 2
  %p1_4 = getelementptr i8, ptr %data, i64 %i1_4
  %p2_4 = getelementptr i8, ptr %data, i64 %i2_4
  %p3_4 = getelementptr i8, ptr %data, i64 %end4
  %b1_4raw = load i8, ptr %p1_4, align 1
  %b2_4raw = load i8, ptr %p2_4, align 1
  %b3_4raw = load i8, ptr %p3_4, align 1
  %b1_4 = zext i8 %b1_4raw to i32
  %b2_4 = zext i8 %b2_4raw to i32
  %b3_4 = zext i8 %b3_4raw to i32
  %c1_4lo = icmp uge i32 %b1_4, 128
  %c1_4hi = icmp ule i32 %b1_4, 191
  %c1_4 = and i1 %c1_4lo, %c1_4hi
  %c2_4lo = icmp uge i32 %b2_4, 128
  %c2_4hi = icmp ule i32 %b2_4, 191
  %c2_4 = and i1 %c2_4lo, %c2_4hi
  %c3_4lo = icmp uge i32 %b3_4, 128
  %c3_4hi = icmp ule i32 %b3_4, 191
  %c3_4 = and i1 %c3_4lo, %c3_4hi
  %cont12_4 = and i1 %c1_4, %c2_4
  %cont4 = and i1 %cont12_4, %c3_4
  br i1 %cont4, label %value4, label %invalid

value4:
  %h4 = and i32 %b0, 7
  %h4s = shl i32 %h4, 18
  %m1_4 = and i32 %b1_4, 63
  %m1_4s = shl i32 %m1_4, 12
  %m2_4 = and i32 %b2_4, 63
  %m2_4s = shl i32 %m2_4, 6
  %hm1_4 = or i32 %h4s, %m1_4s
  %hm2_4 = or i32 %hm1_4, %m2_4s
  %l4 = and i32 %b3_4, 63
  %cp4 = or i32 %hm2_4, %l4
  %min4 = icmp uge i32 %cp4, 65536
  %max4 = icmp ule i32 %cp4, 1114111
  %valid4 = and i1 %min4, %max4
  br i1 %valid4, label %result4, label %invalid

result4:
  %cp4wide = zext i32 %cp4 to i64
  %packed4 = or i64 %cp4wide, 17179869184
  ret i64 %packed4

invalid:
  ret i64 -1
}

define dso_local i32 @sollang_start() local_unnamed_addr {
entry:
  %written = alloca i32, align 4
  %read = alloca i32, align 4
  %ok_state = alloca i1, align 1
  store i1 true, ptr %ok_state, align 1
  %stdin = call ptr @GetStdHandle(i32 -10)
  %stdout = call ptr @GetStdHandle(i32 -11)
  %stdout_mode = alloca i32, align 4
  %stdout_is_console_status = call i32 @GetConsoleMode(ptr %stdout, ptr %stdout_mode)
  %stdout_is_console = icmp ne i32 %stdout_is_console_status, 0
  store i1 %stdout_is_console, ptr @sollang_stdout_line_buffered, align 1
  %struct_call0 = call %sollang.int_slice @sollang_fn_zeroKey(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %fixed_array_ptr1 = extractvalue %sollang.int_slice %struct_call0, 0
  %fixed_array_len2 = extractvalue %sollang.int_slice %struct_call0, 1
  %slice_arg4 = insertvalue %sollang.int_slice poison, ptr %fixed_array_ptr1, 0
  %slice_arg5 = insertvalue %sollang.int_slice %slice_arg4, i64 %fixed_array_len2, 1
  %generic_array3 = call %sollang.dynamic_int_array @sollang_fn_std_crypto_aes128_expandKey(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.int_slice %slice_arg5)
  %generic_array_ptr6 = extractvalue %sollang.dynamic_int_array %generic_array3, 0
  %generic_array_len7 = extractvalue %sollang.dynamic_int_array %generic_array3, 1
  %generic_array_capacity8 = extractvalue %sollang.dynamic_int_array %generic_array3, 2
  %generic_array_value9 = insertvalue %sollang.dynamic_int_array poison, ptr %generic_array_ptr6, 0
  %generic_array_value10 = insertvalue %sollang.dynamic_int_array %generic_array_value9, i64 %generic_array_len7, 1
  %generic_array_value11 = insertvalue %sollang.dynamic_int_array %generic_array_value10, i64 %generic_array_capacity8, 2
  %struct_init12 = insertvalue %sollang.struct.1155 poison, %sollang.dynamic_int_array %generic_array_value11, 0
  call void @sollang_free(ptr %fixed_array_ptr1)
  %struct_call13 = call %sollang.int_slice @sollang_fn_zeroBlock(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %fixed_array_ptr14 = extractvalue %sollang.int_slice %struct_call13, 0
  %fixed_array_len15 = extractvalue %sollang.int_slice %struct_call13, 1
  %slice_arg17 = insertvalue %sollang.int_slice poison, ptr %fixed_array_ptr14, 0
  %slice_arg18 = insertvalue %sollang.int_slice %slice_arg17, i64 %fixed_array_len15, 1
  %struct_call16 = call %sollang.int_slice @sollang_fn_std_crypto_aes128_Key_encryptBlock(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.struct.1155 %struct_init12, %sollang.int_slice %slice_arg18)
  %fixed_array_ptr19 = extractvalue %sollang.int_slice %struct_call16, 0
  %fixed_array_len20 = extractvalue %sollang.int_slice %struct_call16, 1
  call void @sollang_free(ptr %fixed_array_ptr14)
  %struct_call21 = call %sollang.int_slice @sollang_fn_incrementingKey(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %fixed_array_ptr22 = extractvalue %sollang.int_slice %struct_call21, 0
  %fixed_array_len23 = extractvalue %sollang.int_slice %struct_call21, 1
  %slice_arg25 = insertvalue %sollang.int_slice poison, ptr %fixed_array_ptr22, 0
  %slice_arg26 = insertvalue %sollang.int_slice %slice_arg25, i64 %fixed_array_len23, 1
  %generic_array24 = call %sollang.dynamic_int_array @sollang_fn_std_crypto_aes128_expandKey(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.int_slice %slice_arg26)
  %generic_array_ptr27 = extractvalue %sollang.dynamic_int_array %generic_array24, 0
  %generic_array_len28 = extractvalue %sollang.dynamic_int_array %generic_array24, 1
  %generic_array_capacity29 = extractvalue %sollang.dynamic_int_array %generic_array24, 2
  %generic_array_value30 = insertvalue %sollang.dynamic_int_array poison, ptr %generic_array_ptr27, 0
  %generic_array_value31 = insertvalue %sollang.dynamic_int_array %generic_array_value30, i64 %generic_array_len28, 1
  %generic_array_value32 = insertvalue %sollang.dynamic_int_array %generic_array_value31, i64 %generic_array_capacity29, 2
  %struct_init33 = insertvalue %sollang.struct.1155 poison, %sollang.dynamic_int_array %generic_array_value32, 0
  call void @sollang_free(ptr %fixed_array_ptr22)
  %struct_call34 = call %sollang.int_slice @sollang_fn_incrementingBlock(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %fixed_array_ptr35 = extractvalue %sollang.int_slice %struct_call34, 0
  %fixed_array_len36 = extractvalue %sollang.int_slice %struct_call34, 1
  %slice_arg38 = insertvalue %sollang.int_slice poison, ptr %fixed_array_ptr35, 0
  %slice_arg39 = insertvalue %sollang.int_slice %slice_arg38, i64 %fixed_array_len36, 1
  %struct_call37 = call %sollang.int_slice @sollang_fn_std_crypto_aes128_Key_encryptBlock(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.struct.1155 %struct_init33, %sollang.int_slice %slice_arg39)
  %fixed_array_ptr40 = extractvalue %sollang.int_slice %struct_call37, 0
  %fixed_array_len41 = extractvalue %sollang.int_slice %struct_call37, 1
  call void @sollang_free(ptr %fixed_array_ptr35)
  %struct_call42 = call %sollang.int_slice @sollang_fn_sp800Key(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %fixed_array_ptr43 = extractvalue %sollang.int_slice %struct_call42, 0
  %fixed_array_len44 = extractvalue %sollang.int_slice %struct_call42, 1
  %slice_arg46 = insertvalue %sollang.int_slice poison, ptr %fixed_array_ptr43, 0
  %slice_arg47 = insertvalue %sollang.int_slice %slice_arg46, i64 %fixed_array_len44, 1
  %generic_array45 = call %sollang.dynamic_int_array @sollang_fn_std_crypto_aes128_expandKey(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.int_slice %slice_arg47)
  %generic_array_ptr48 = extractvalue %sollang.dynamic_int_array %generic_array45, 0
  %generic_array_len49 = extractvalue %sollang.dynamic_int_array %generic_array45, 1
  %generic_array_capacity50 = extractvalue %sollang.dynamic_int_array %generic_array45, 2
  %generic_array_value51 = insertvalue %sollang.dynamic_int_array poison, ptr %generic_array_ptr48, 0
  %generic_array_value52 = insertvalue %sollang.dynamic_int_array %generic_array_value51, i64 %generic_array_len49, 1
  %generic_array_value53 = insertvalue %sollang.dynamic_int_array %generic_array_value52, i64 %generic_array_capacity50, 2
  %struct_init54 = insertvalue %sollang.struct.1155 poison, %sollang.dynamic_int_array %generic_array_value53, 0
  call void @sollang_free(ptr %fixed_array_ptr43)
  %struct_call55 = call %sollang.int_slice @sollang_fn_sp800Block(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %fixed_array_ptr56 = extractvalue %sollang.int_slice %struct_call55, 0
  %fixed_array_len57 = extractvalue %sollang.int_slice %struct_call55, 1
  %slice_arg59 = insertvalue %sollang.int_slice poison, ptr %fixed_array_ptr56, 0
  %slice_arg60 = insertvalue %sollang.int_slice %slice_arg59, i64 %fixed_array_len57, 1
  %struct_call58 = call %sollang.int_slice @sollang_fn_std_crypto_aes128_Key_encryptBlock(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.struct.1155 %struct_init54, %sollang.int_slice %slice_arg60)
  %fixed_array_ptr61 = extractvalue %sollang.int_slice %struct_call58, 0
  %fixed_array_len62 = extractvalue %sollang.int_slice %struct_call58, 1
  call void @sollang_free(ptr %fixed_array_ptr56)
  %struct_call63 = call %sollang.int_slice @sollang_fn_zeroCiphertext(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %fixed_array_ptr64 = extractvalue %sollang.int_slice %struct_call63, 0
  %fixed_array_len65 = extractvalue %sollang.int_slice %struct_call63, 1
  %slice_arg67 = insertvalue %sollang.int_slice poison, ptr %fixed_array_ptr19, 0
  %slice_arg68 = insertvalue %sollang.int_slice %slice_arg67, i64 %fixed_array_len20, 1
  %slice_arg69 = insertvalue %sollang.int_slice poison, ptr %fixed_array_ptr64, 0
  %slice_arg70 = insertvalue %sollang.int_slice %slice_arg69, i64 %fixed_array_len65, 1
  %call66 = call i1 @sollang_fn_matches(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.int_slice %slice_arg68, %sollang.int_slice %slice_arg70)
  call void @sollang_free(ptr %fixed_array_ptr64)
  br i1 %call66, label %bb_and_rhs0, label %bb_and_end1
bb_and_rhs0:
  %struct_call71 = call %sollang.int_slice @sollang_fn_incrementingCiphertext(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %fixed_array_ptr72 = extractvalue %sollang.int_slice %struct_call71, 0
  %fixed_array_len73 = extractvalue %sollang.int_slice %struct_call71, 1
  %slice_arg75 = insertvalue %sollang.int_slice poison, ptr %fixed_array_ptr40, 0
  %slice_arg76 = insertvalue %sollang.int_slice %slice_arg75, i64 %fixed_array_len41, 1
  %slice_arg77 = insertvalue %sollang.int_slice poison, ptr %fixed_array_ptr72, 0
  %slice_arg78 = insertvalue %sollang.int_slice %slice_arg77, i64 %fixed_array_len73, 1
  %call74 = call i1 @sollang_fn_matches(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.int_slice %slice_arg76, %sollang.int_slice %slice_arg78)
  call void @sollang_free(ptr %fixed_array_ptr72)
  br label %bb_and_end1
bb_and_end1:
  %and79 = phi i1 [ false, %entry ], [ %call74, %bb_and_rhs0 ]
  br i1 %and79, label %bb_and_rhs2, label %bb_and_end3
bb_and_rhs2:
  %struct_call80 = call %sollang.int_slice @sollang_fn_sp800Ciphertext(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state)
  %fixed_array_ptr81 = extractvalue %sollang.int_slice %struct_call80, 0
  %fixed_array_len82 = extractvalue %sollang.int_slice %struct_call80, 1
  %slice_arg84 = insertvalue %sollang.int_slice poison, ptr %fixed_array_ptr61, 0
  %slice_arg85 = insertvalue %sollang.int_slice %slice_arg84, i64 %fixed_array_len62, 1
  %slice_arg86 = insertvalue %sollang.int_slice poison, ptr %fixed_array_ptr81, 0
  %slice_arg87 = insertvalue %sollang.int_slice %slice_arg86, i64 %fixed_array_len82, 1
  %call83 = call i1 @sollang_fn_matches(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.int_slice %slice_arg85, %sollang.int_slice %slice_arg87)
  call void @sollang_free(ptr %fixed_array_ptr81)
  br label %bb_and_end3
bb_and_end3:
  %and88 = phi i1 [ false, %bb_and_end1 ], [ %call83, %bb_and_rhs2 ]
  br i1 %and88, label %bb_if_then4, label %bb_if_else5
bb_if_then4:
  br label %bb_if_end6
bb_if_else5:
  br label %bb_if_end6
bb_if_end6:
  %if_ptr89 = phi ptr [ @.slg.str.suffix.0, %bb_if_then4 ], [ @.slg.str.suffix.1, %bb_if_else5 ]
  %if_len90 = phi i64 [ 18, %bb_if_then4 ], [ 22, %bb_if_else5 ]
  %write91 = call i32 @sollang_write(ptr %stdout, ptr %if_ptr89, i64 %if_len90, ptr %written)
  %is_ok92 = icmp ne i32 %write91, 0
  %previous_ok93 = load i1, ptr %ok_state, align 1
  %ok94 = and i1 %previous_ok93, %is_ok92
  store i1 %ok94, ptr %ok_state, align 1
  %write95 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.suffix.2, i64 1, ptr %written)
  %is_ok96 = icmp ne i32 %write95, 0
  %previous_ok97 = load i1, ptr %ok_state, align 1
  %ok98 = and i1 %previous_ok97, %is_ok96
  store i1 %ok98, ptr %ok_state, align 1
  call void @sollang_free(ptr %fixed_array_ptr61)
  call void @sollang_drop_1155(%sollang.struct.1155 %struct_init54)
  call void @sollang_free(ptr %fixed_array_ptr40)
  call void @sollang_drop_1155(%sollang.struct.1155 %struct_init33)
  call void @sollang_free(ptr %fixed_array_ptr19)
  call void @sollang_drop_1155(%sollang.struct.1155 %struct_init12)
  %stdout_flushed = call i32 @sollang_flush_stdout(ptr %stdout, ptr %written)
  %final_ok99 = load i1, ptr %ok_state, align 1
  %exit100 = select i1 %final_ok99, i32 0, i32 1
  ret i32 %exit100
}

attributes #0 = { nounwind }
attributes #1 = { nounwind "target-features"="+aes,+sse2" }

from pathlib import Path
import hashlib,json,sys,time
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(r/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
planPath=b/'diagnostic19810-fact-plan.json';plan=read(planPath);previous=read(b/'diagnostic19801-slg-source/result.json')
assert previous['status']=='failed' and previous['inputsStable'] and previous['processesStopped']
assert plan['producerBuilds']==1 and plan['maxExecutions']==6 and plan['caseBudgetSeconds']==180 and plan['retryCount']==0
paths=[Path(p) for p in previous['inputHashes']]+[planPath,b/'diagnostic19801-slg-source/result.json',r/plan['source'],Path(__file__)]
assert all(p.is_file() for p in paths)
changes={}
for p,wanted in previous['inputHashes'].items():
 current=sha(p)
 if current!=wanted:
  name=Path(p).resolve().relative_to(r).as_posix();observed=dict(previous=wanted,current=current)
  assert plan['sourceDeltas'].get(name)==observed,name
  changes[name]=observed
assert changes==plan['sourceDeltas'],'UNEXPECTED_SOURCE_DELTA'

paths=list(dict.fromkeys(paths));out=b/'diagnostic19811-fact-observation'
initialize_output(r,out,reusable_directories=[b/'v18915/compiler-build01',b/'v19080/compiler-build01',b/'v19418/compiler-build01']);out.mkdir(exist_ok=False)
with VerificationContractLease(paths):
 pins={str(p):sha(p) for p in paths};stable=lambda:all(Path(p).is_file() and sha(p)==wanted for p,wanted in pins.items())
 d=dict(schemaVersion=1,status='running',mode='diagnostic-only',completed=0,total=6,cases=[],inputHashes=pins,scope='Bounded source-fact observation, not implementation acceptance. One host fixture build and six import-free core snapshots; no emitted program LLVM or general Native build.',claimsFocusedFixComplete=False,claimsPhaseComplete=False,claimsGoalComplete=False)
 x=VerificationExecution(r,out,d,stable,sha);error=None;started=time.monotonic()
 try:
  command=next(p['command'] for p in previous['processes'] if len(p['command'])>2 and p['command'][1]=='build').copy()
  command[2]=str(r/plan['source']);command[command.index('-o')+1]=str(out/'probe.exe')
  built=x.run(command,out/'build',timeout=180);assert built.returncode==0,built.stderr
  d['producerSha256']=sha(out/'probe.exe')
  for index,program in enumerate(plan['programs']):
   row=dict(id=Path(program).stem,status='running',program=program);d['cases'].append(row);x.save()
   remaining=180-(time.monotonic()-started);assert remaining>0,'WHOLE_CASE_BUDGET_EXHAUSTED'
   observed=x.run([str(out/'probe.exe'),program],out/('observe-'+str(index)),timeout=remaining)
   assert observed.returncode==0 and observed.stderr=='' and observed.stdout.rstrip().endswith('TRACE_END'),(observed.returncode,observed.stderr)
   elapsed=time.monotonic()-started;assert elapsed<180,'WHOLE_CASE_BUDGET_EXHAUSTED'
   row.update(status='passed',observationComplete=True,wholeCaseBudgetSeconds=180,wholeCaseElapsedSeconds=elapsed,stdout=observed.stdout,stderr=observed.stderr)
   d['completed']+=1;x.save();print(row['id']+': source facts observed',flush=True)
  d['status']='passed'
 except BaseException as failure:error=failure
 finally:x.finalize(error,cleanup=False)
 print(json.dumps({k:d.get(k) for k in ('status','completed','total','inputsStable','processesStopped','failure')}))
 if error:raise error

from pathlib import Path
import hashlib,json,subprocess
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22'
programs=[(b/'diagnostic19767-inputs'/name).relative_to(r).as_posix() for name in ['parameter-moved.slg','before-move.slg','borrowed.slg','terminating-branch.slg','fresh-loop-owner.slg']]
assert all(not any(line.strip().startswith('import ') for line in (r/p).read_text(encoding='utf-8-sig').splitlines()) for p in programs)
derived=b/'diagnostic19810-parameter-direct-read.slg';assert not derived.exists()
t=(r/programs[0]).read_text(encoding='utf-8-sig');assert t.count('"$values"')==1;derived.write_text(t.replace('"$values"','values'),encoding='utf-8')
subprocess.run([str(b/'v18915/compiler-build01/compiler.exe'),'format',str(derived)],check=True,capture_output=True)
programs.append(derived.relative_to(r).as_posix())
t=(b/'diagnostic19785-fact-plan.py').read_text(encoding='utf-8-sig')
old="order=c['reusableCheckedProducer']['stdlibSourceOrder']";assert old in t;t=t.replace(old,'order=[]')
start=t.index('programs=[');end=t.index('\nspec=',start);t=t[:start]+'programs='+repr(programs)+t[end:]
t=t.replace('diagnostic19785','diagnostic19810').replace('standardLibrarySourceCount: 144','standardLibrarySourceCount: 0')
t=t.replace('import sollang.compiler.llvm.target as traceTarget\\n','import sollang.compiler.llvm.target as traceTarget\\nimport sollang.compiler.ir.typed as traceIr\\n')
old='            "MOVE|$(event.siteIr)|$(event.valueIr)|$(event.bindingIr)|$(event.symbol)|$(event.regionIr)|$(event.memberIr)" -> println'
new='            event -> traceIr.moveBindingDeclaration(context.ir) => declaration\n'+old.replace('$(event.memberIr)"','$(event.memberIr)|$declaration"')
assert old in t;t=t.replace(old,new)
t=t.replace('maxExecutions=2','maxExecutions=6').replace('programs=2,builds=1','programs=6,builds=1')
p=b/'diagnostic19810-fact-plan.py';assert not p.exists();p.write_text(t,encoding='utf-8')
subprocess.run(['python',str(p)],check=True)
p=b/'diagnostic19810-fact-plan.json';plan=json.loads(p.read_text(encoding='utf-8-sig'));previous=json.loads((b/'diagnostic19801-slg-source/result.json').read_text(encoding='utf-8-sig'))
plan.update(maxTotalSeconds=180,reason='Current full-package source suite passed5 then failed the move-input interpolation. Observe the canonical declaration link and remaining positive visibility controls before another full-package replay.',dependencyScope='Observed programs use core primitives and local functions only and have no imports. Standard-library prefix0 is explicit for this diagnostic-only probe; no full-package or emitted-runtime acceptance is claimed.',sourceDeltas={})
for name in ['selfhost/ir/typed.slg','selfhost/semantic/ownership_check.slg']:
 path=(r/name).resolve();plan['sourceDeltas'][name]=dict(previous=previous['inputHashes'][str(path)],current=hashlib.sha256(path.read_bytes()).hexdigest().upper())
p.write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8')
t=(b/'diagnostic19786-facts.py').read_text(encoding='utf-8-sig')
for old,new in [('diagnostic19785-fact-plan.json','diagnostic19810-fact-plan.json'),('diagnostic19780-slg-source/result.json','diagnostic19801-slg-source/result.json'),('diagnostic19786-fact-observation','diagnostic19811-fact-observation'),("plan['maxExecutions']==2","plan['maxExecutions']==6"),('completed=0,total=2','completed=0,total=6'),('   if index:started=time.monotonic()\n',''),('two program snapshots','six import-free core snapshots')]:
 assert old in t,old;t=t.replace(old,new)
old="for p,wanted in previous['inputHashes'].items():assert sha(p)==wanted,p"
new="""changes={}
for p,wanted in previous['inputHashes'].items():
 current=sha(p)
 if current!=wanted:
  name=Path(p).resolve().relative_to(r).as_posix();observed=dict(previous=wanted,current=current)
  assert plan['sourceDeltas'].get(name)==observed,name
  changes[name]=observed
assert changes==plan['sourceDeltas'],'UNEXPECTED_SOURCE_DELTA'
"""
assert old in t;t=t.replace(old,new)
p=b/'diagnostic19811-facts.py';assert not p.exists();p.write_text(t,encoding='utf-8')

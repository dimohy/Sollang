from pathlib import Path
import importlib.util,json,sys
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(r/'scripts'))
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
c=read(b/'diagnostic19740-contract.json');pending=read(b/'diagnostic19737-reference-binding.json')['wasmPending'];assert len(pending)==1
row=pending[0]['original'];reference=pending[0]['reference'];assert row['target']=='wasm32-browser' and reference['passed']
paths=[p['path'] for p in row['sourceInputs']];assert len(paths)==1
spec=importlib.util.spec_from_file_location('selection_generator',r/'scripts/generate-selection-result-emitter.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
order=c['reusableCheckedProducer']['stdlibSourceOrder'];additional=c['reusableCheckedProducer']['additionalSources']
source=b/'diagnostic19744-wasm-emitter.slg';assert not source.exists()
text=g.render((r/paths[0]).read_text(encoding='utf-8-sig'),checked=True,package_paths=order,program_path=paths[0]).decode('utf-8')
old=f'compiler.emitCheckedWithPaths(paths!, {len(order)})';assert text.count(old)==1
text=text.replace(old,f'compiler.emitWasmCheckedWithPaths(paths!, {len(order)})')
source.write_text(text,encoding='utf-8')
contract=dict(schemaVersion=1,scope='C754 original wasm semantic rejection through actual SLG wasm checked-emission API. Host fixture success signals the expected rejection; no browser link/run or general Native CLI acceptance.',
 expectedManagedDllSha256=c['expectedManagedDllSha256'],semanticPreflightProof=c['semanticPreflightProof'],stdlibSourcePreflightProof=c['stdlibSourcePreflightProof'],
 harnessBuildOptimization='-O0',harnessBuildJobs=4,budget=dict(buildSeconds=180,caseSeconds=180,retryCount=0),
 runtimeInputFiles=order+paths,formatCheckSources=[source.relative_to(r).as_posix()],cases=[dict(id='original-'+row['id'],source=source.relative_to(r).as_posix(),additionalSources=additional,exit=0,stderr='',stdout=reference['buildStderr'].strip()+'\nselection-emission-rejected',emittedLlvm=False,runStderr='')])
p=b/'diagnostic19744-wasm-contract.json';assert not p.exists();p.write_text(json.dumps(contract,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(program=paths[0],runtimeInputs=len(order+paths))))

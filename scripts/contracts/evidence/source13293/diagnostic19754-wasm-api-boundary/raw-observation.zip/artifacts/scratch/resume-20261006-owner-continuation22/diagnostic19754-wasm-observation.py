from pathlib import Path
import hashlib,json,zipfile
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';e=r/'scripts/contracts/evidence/source13293/diagnostic19754-wasm-api-boundary'
e.mkdir(exist_ok=False)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
rawPath=b/'diagnostic19745-wasm-source/result.json';raw=read(rawPath);actual=raw['cases'][0]
assert raw['status']=='failed' and raw['inputsStable'] and raw['processesStopped']
assert actual['buildExit']==0 and actual['buildStderr']=='' and actual['runExit']==0 and actual['runStderr']==''
assert actual['wholeCaseBudgetSeconds']==180 and actual['wholeCaseElapsedSeconds']<180
for path,value in raw['inputHashes'].items():assert sha(Path(path))==value,path
ref=next(x for x in read(b/'semantic19733-managed-diagnostics/result.json')['cases'] if x['id']=='browser-async-actionable-rejection')
intent=next(x for x in read(b/'semantic19732-diagnostic-inputs.json')['cases'] if x['id']==ref['id'])
assert ref['passed'] and ref['buildExit']==1 and ref['buildStdout']=='' and ref['buildStderr'].startswith('sollang: ')
message=ref['buildStderr'].removeprefix('sollang: ').rstrip('\n')
prefix='; sollang semantic error: '
assert prefix+message+'" -> println' in (r/'selfhost/llvm/text/core_calls.slg').read_text(encoding='utf-8-sig')
assert actual['runStdout']==prefix+message+'\nselection-emission-rejected'
assert intent['mode']=='stderr-contains' and intent['text'] in message and intent['requireNoLlvm'] is False
# The exact two-line stream contains no LLVM body. The fixture emits the marker
# only for diagnosticCount != 0; host exit0 is not compiler acceptance.
receipt=dict(schemaVersion=1,status='passed',completed=1,total=1,inputsStable=True,processesStopped=True,
 scope='Reused observed SLG wasm SDK rejection at its actual API transport boundary. No new execution, Native CLI equivalence, wasm link/run, phase closure or whole goal acceptance.',
 originalExecutionStatus='failed',originalExecution=rawPath.relative_to(r).as_posix(),originalFailure=raw['failure'],
 correction='The first harness wrongly required CSharp CLI framing from the lower-level LLVM SDK API. Preserve the failed record; compare the exact common CSharp message using the SDK prefix owned by core_calls.slg. The original managed assertion is unchanged.',
 canonicalMessage=message,csharpReference=ref,originalConstraint=intent,
 sourceAuthority=dict(path='selfhost/llvm/text/core_calls.slg',sha256=sha(r/'selfhost/llvm/text/core_calls.slg'),function='emitWasmRuntimeTargetDiagnostics'),
 cases=[dict(id=actual['id'],status='passed',passed=True,reusedObservation=True,observedBuildExit=0,observedHarnessExit=0,semanticRejectionConfirmed=True,observedStdout=actual['runStdout'],observedStderr='',wholeCaseElapsedSeconds=actual['wholeCaseElapsedSeconds'])],
 claimsPhaseComplete=False,claimsGoalComplete=False)
put(e/'result.json',receipt)
files=[rawPath,b/'diagnostic19744-wasm-contract.json',b/'diagnostic19744-wasm-emitter.slg',b/'diagnostic19744-wasm-plan.py',Path(__file__)]
files += [p for p in (b/'diagnostic19745-wasm-source').rglob('*') if p.is_file() and p.suffix in ('.stdout','.stderr','.json') and '.sollang-cache' not in p.parts]
with zipfile.ZipFile(e/'raw-observation.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in dict.fromkeys(files):z.writestr(p.relative_to(r).as_posix(),p.read_bytes())
with zipfile.ZipFile(e/'raw-observation.zip') as z:
 for p in dict.fromkeys(files):assert hashlib.sha256(z.read(p.relative_to(r).as_posix())).hexdigest().upper()==sha(p)
print(json.dumps(dict(status='qualified-api-observation',executionsAdded=0,originalFailedRecordPreserved=True)))

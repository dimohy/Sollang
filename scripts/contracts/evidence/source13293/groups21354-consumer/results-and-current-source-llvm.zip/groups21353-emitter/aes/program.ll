target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"
declare ptr @GetProcessHeap()
declare ptr @HeapAlloc(ptr, i32, i64)
declare i32 @HeapFree(ptr, i32, ptr)
define internal ptr @sollang_alloc(i64 %bytes) {
entry:
  %heap = call ptr @GetProcessHeap()
  %value = call ptr @HeapAlloc(ptr %heap, i32 0, i64 %bytes)
  ret ptr %value
}
define internal void @sollang_free(ptr %value) {
entry:
  %is_null = icmp eq ptr %value, null
  br i1 %is_null, label %done, label %release
release:
  %heap = call ptr @GetProcessHeap()
  %ignored = call i32 @HeapFree(ptr %heap, i32 0, ptr %value)
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1 immarg)
declare ptr @GetStdHandle(i32)
declare i32 @GetConsoleMode(ptr, ptr)
declare i32 @WriteConsoleW(ptr, ptr, i32, ptr, ptr)
declare i32 @WriteFile(ptr, ptr, i32, ptr, ptr)
declare i32 @MultiByteToWideChar(i32, i32, ptr, i32, ptr, i32)
define internal i32 @sollang_write_stream_chunk(ptr %handle, ptr %data, i32 %len, ptr %written, i1 %is_console) {
entry:
  %empty = icmp eq i32 %len, 0
  br i1 %empty, label %success_empty, label %classify

success_empty:
  store i32 0, ptr %written, align 4
  ret i32 1

classify:
  br i1 %is_console, label %console_prepare, label %redirected

redirected:
  br label %redirected_write

redirected_write:
  %redirected_offset = phi i32 [ 0, %redirected ], [ %redirected_next, %redirected_advance ]
  %redirected_remaining = sub i32 %len, %redirected_offset
  %redirected_offset64 = zext i32 %redirected_offset to i64
  %redirected_data = getelementptr i8, ptr %data, i64 %redirected_offset64
  store i32 0, ptr %written, align 4
  %redirected_ok = call i32 @WriteFile(ptr %handle, ptr %redirected_data, i32 %redirected_remaining, ptr %written, ptr null)
  %redirected_count = load i32, ptr %written, align 4
  %redirected_succeeded = icmp ne i32 %redirected_ok, 0
  %redirected_progress = icmp ugt i32 %redirected_count, 0
  %redirected_bounded = icmp ule i32 %redirected_count, %redirected_remaining
  %redirected_valid0 = and i1 %redirected_succeeded, %redirected_progress
  %redirected_valid = and i1 %redirected_valid0, %redirected_bounded
  br i1 %redirected_valid, label %redirected_advance, label %write_failed

redirected_advance:
  %redirected_next = add i32 %redirected_offset, %redirected_count
  %redirected_complete = icmp eq i32 %redirected_next, %len
  br i1 %redirected_complete, label %write_succeeded, label %redirected_write

console_prepare:
  %wide_chars = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %len, ptr null, i32 0)
  %valid_utf8 = icmp sgt i32 %wide_chars, 0
  br i1 %valid_utf8, label %allocate, label %conversion_failed

allocate:
  %wide_bytes32 = shl i32 %wide_chars, 1
  %wide_bytes = zext i32 %wide_bytes32 to i64
  %heap = call ptr @GetProcessHeap()
  %wide = call ptr @HeapAlloc(ptr %heap, i32 0, i64 %wide_bytes)
  %wide_written = alloca i32, align 4
  %allocated = icmp ne ptr %wide, null
  br i1 %allocated, label %convert, label %conversion_failed

convert:
  %converted = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %len, ptr %wide, i32 %wide_chars)
  %converted_all = icmp eq i32 %converted, %wide_chars
  br i1 %converted_all, label %console_write, label %conversion_free

console_write:
  %console_offset = phi i32 [ 0, %convert ], [ %console_next, %console_advance ]
  %console_remaining = sub i32 %wide_chars, %console_offset
  %console_offset64 = zext i32 %console_offset to i64
  %console_data = getelementptr i16, ptr %wide, i64 %console_offset64
  store i32 0, ptr %wide_written, align 4
  %console_ok = call i32 @WriteConsoleW(ptr %handle, ptr %console_data, i32 %console_remaining, ptr %wide_written, ptr null)
  %console_count = load i32, ptr %wide_written, align 4
  %console_succeeded = icmp ne i32 %console_ok, 0
  %console_progress = icmp ugt i32 %console_count, 0
  %console_bounded = icmp ule i32 %console_count, %console_remaining
  %console_valid0 = and i1 %console_succeeded, %console_progress
  %console_valid = and i1 %console_valid0, %console_bounded
  br i1 %console_valid, label %console_advance, label %console_write_failed

console_advance:
  %console_next = add i32 %console_offset, %console_count
  %console_complete = icmp eq i32 %console_next, %wide_chars
  br i1 %console_complete, label %console_write_succeeded, label %console_write

console_write_succeeded:
  %freed = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %write_succeeded

console_write_failed:
  %freed_after_write_failure = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %write_failed

write_succeeded:
  store i32 %len, ptr %written, align 4
  ret i32 1

write_failed:
  store i32 0, ptr %written, align 4
  ret i32 0

conversion_free:
  %freed_after_failure = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %conversion_failed

conversion_failed:
  store i32 0, ptr %written, align 4
  ret i32 0
}

define internal i32 @sollang_write_stream(ptr %handle, ptr %data, i64 %len64, ptr %written, i1 %is_console) {
entry:
  %empty = icmp eq i64 %len64, 0
  br i1 %empty, label %success_empty, label %prepare

success_empty:
  store i32 0, ptr %written, align 4
  ret i32 1

prepare:
  %offset = phi i64 [ 0, %entry ], [ %next, %advance ]
  %remaining = sub i64 %len64, %offset
  %current = getelementptr i8, ptr %data, i64 %offset
  %more = icmp ugt i64 %remaining, 1048576
  %proposed = select i1 %more, i64 1048576, i64 %remaining
  %split_console = and i1 %more, %is_console
  br i1 %split_console, label %trim_boundary, label %write

trim_boundary:
  %boundary = phi i64 [ 1048576, %prepare ], [ %previous, %trim_next ]
  %boundary_ptr = getelementptr i8, ptr %current, i64 %boundary
  %boundary_byte = load i8, ptr %boundary_ptr, align 1
  %prefix = and i8 %boundary_byte, -64
  %continuation = icmp eq i8 %prefix, -128
  br i1 %continuation, label %trim_next, label %write

trim_next:
  %can_trim = icmp ugt i64 %boundary, 1048573
  %previous = sub i64 %boundary, 1
  br i1 %can_trim, label %trim_boundary, label %failure

write:
  %chunk64 = phi i64 [ %proposed, %prepare ], [ %boundary, %trim_boundary ]
  %chunk32 = trunc i64 %chunk64 to i32
  %ok = call i32 @sollang_write_stream_chunk(ptr %handle, ptr %current, i32 %chunk32, ptr %written, i1 %is_console)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %advance, label %failure

advance:
  %next = add i64 %offset, %chunk64
  %complete = icmp eq i64 %next, %len64
  br i1 %complete, label %success, label %prepare

success:
  ret i32 1

failure:
  store i32 0, ptr %written, align 4
  ret i32 0
}

define internal i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %len) {
entry:
  %written = alloca i32, align 4
  %mode = alloca i32, align 4
  %empty = icmp eq i64 %len, 0
  br i1 %empty, label %success, label %classify
classify:
  %console_status = call i32 @GetConsoleMode(ptr %handle, ptr %mode)
  %is_console = icmp ne i32 %console_status, 0
  %ok = call i32 @sollang_write_stream(ptr %handle, ptr %data, i64 %len, ptr %written, i1 %is_console)
  ret i32 %ok
success:
  ret i32 1
}
define internal i32 @sollang_runtime_write_stdout_bytes(ptr %handle, ptr %data, i32 %len) {
entry:
  %length = zext i32 %len to i64
  %ok = call i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %length)
  ret i32 %ok
}
@sollang_runtime_newline = private constant [1 x i8] c"\0A"
@sollang_runtime_stdout_buffer = private global [1048576 x i8] zeroinitializer
@sollang_runtime_stdout_count = private global i64 0
define internal void @sollang_runtime_flush_stdout() {
entry:
  %count = load i64, ptr @sollang_runtime_stdout_count, align 8
  %has_data = icmp ugt i64 %count, 0
  br i1 %has_data, label %write, label %done
write:
  %handle = call ptr @GetStdHandle(i32 -11)
  %count32 = trunc i64 %count to i32
  %ok = call i32 @sollang_runtime_write_stdout_bytes(ptr %handle, ptr @sollang_runtime_stdout_buffer, i32 %count32)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %clear, label %failure
clear:
  store i64 0, ptr @sollang_runtime_stdout_count, align 8
  br label %done
failure:
  call void @llvm.trap()
  unreachable
done:
  ret void
}
define internal void @sollang_runtime_append_stdout(ptr %data, i64 %len) {
entry:
  %count = load i64, ptr @sollang_runtime_stdout_count, align 8
  %total = add i64 %count, %len
  %available = sub i64 1048576, %count
  %fits = icmp ule i64 %len, %available
  br i1 %fits, label %append, label %flush
flush:
  call void @sollang_runtime_flush_stdout()
  %large = icmp ugt i64 %len, 1048576
  br i1 %large, label %direct, label %append_empty
direct:
  %handle = call ptr @GetStdHandle(i32 -11)
  %ok = call i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %len)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %direct_done, label %direct_failure
direct_done:
  ret void
direct_failure:
  call void @llvm.trap()
  unreachable
append_empty:
  call void @llvm.memcpy.p0.p0.i64(ptr @sollang_runtime_stdout_buffer, ptr %data, i64 %len, i1 false)
  store i64 %len, ptr @sollang_runtime_stdout_count, align 8
  ret void
append:
  %slot = getelementptr i8, ptr @sollang_runtime_stdout_buffer, i64 %count
  call void @llvm.memcpy.p0.p0.i64(ptr %slot, ptr %data, i64 %len, i1 false)
  store i64 %total, ptr @sollang_runtime_stdout_count, align 8
  ret void
}
define internal void @sollang_runtime_print(ptr %data, i64 %len, i1 %newline) {
entry:
  call void @sollang_runtime_append_stdout(ptr %data, i64 %len)
  br i1 %newline, label %write_newline, label %done
write_newline:
  call void @sollang_runtime_append_stdout(ptr @sollang_runtime_newline, i64 1)
  br label %done
done:
  ret void
}
@sollang_runtime_error_newline = private constant [2 x i8] c"\0D\0A"
define internal void @sollang_runtime_eprint(ptr %data, i64 %len, i1 %newline) {
entry:
  %handle = call ptr @GetStdHandle(i32 -12)
  %ok = call i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %len)
  br i1 %newline, label %write_newline, label %done
write_newline:
  %newline_ok = call i32 @sollang_runtime_write_stdout_bytes(ptr %handle, ptr @sollang_runtime_error_newline, i32 2)
  br label %done
done:
  ret void
}
define internal void @sollang_runtime_eprintln(ptr %data, i64 %len) {
entry:
  call void @sollang_runtime_eprint(ptr %data, i64 %len, i1 true)
  ret void
}
define internal i64 @sollang_format_u64(ptr %dest, i64 %value) {
entry:
  br label %count
count:
  %count_n = phi i64 [ %value, %entry ], [ %count_q, %count_more ]
  %length = phi i64 [ 1, %entry ], [ %next_length, %count_more ]
  %count_q = udiv i64 %count_n, 10
  %count_done = icmp eq i64 %count_q, 0
  br i1 %count_done, label %write_entry, label %count_more
count_more:
  %next_length = add i64 %length, 1
  br label %count
write_entry:
  %last_index = sub i64 %length, 1
  br label %write
write:
  %write_n = phi i64 [ %value, %write_entry ], [ %write_q, %write ]
  %index = phi i64 [ %last_index, %write_entry ], [ %previous_index, %write ]
  %digit = urem i64 %write_n, 10
  %write_q = udiv i64 %write_n, 10
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  %slot = getelementptr i8, ptr %dest, i64 %index
  store i8 %ascii, ptr %slot, align 1
  %previous_index = sub i64 %index, 1
  %write_done = icmp eq i64 %write_q, 0
  br i1 %write_done, label %return, label %write
return:
  ret i64 %length
}
define internal i64 @sollang_format_i64(ptr %dest, i64 %value) {
entry:
  %negative = icmp slt i64 %value, 0
  br i1 %negative, label %negative_value, label %positive_value
negative_value:
  store i8 45, ptr %dest, align 1
  %digits_dest = getelementptr i8, ptr %dest, i64 1
  %magnitude = sub i64 0, %value
  %negative_digits = call i64 @sollang_format_u64(ptr %digits_dest, i64 %magnitude)
  %negative_length = add i64 %negative_digits, 1
  ret i64 %negative_length
positive_value:
  %positive_length = call i64 @sollang_format_u64(ptr %dest, i64 %value)
  ret i64 %positive_length
}
declare dllimport ptr @CreateFileA(ptr, i32, i32, ptr, i32, i32, ptr)
declare dllimport ptr @CreateFileW(ptr, i32, i32, ptr, i32, i32, ptr)
declare dllimport i32 @CloseHandle(ptr)
@sollang_bool_true_bytes = private constant [4 x i8] c"true"
@sollang_bool_false_bytes = private constant [5 x i8] c"false"
%sollang.source_text = type { ptr, i64, ptr, i64 }
%sollang.text = type { ptr, i64 }
%sollang.stream = type { ptr, ptr, ptr }
%sollang.event_stream = type { ptr, ptr, ptr }
%sollang.enum.t32 = type { i32, [0 x i64] }
%sollang.enum.t43 = type { i32, [0 x i64] }
%sollang.enum.t55 = type { i32, [0 x i64] }
%sollang.enum.t58 = type { i32, [0 x i64] }
%sollang.enum.t78 = type { i32, [1 x i64] }
%sollang.enum.t85 = type { i32, [1 x i64] }
%sollang.enum.t88 = type { i32, [1 x i64] }
%sollang.enum.t99 = type { i32, [0 x i64] }
%sollang.enum.t100 = type { i32, [0 x i64] }
%sollang.enum.t106 = type { i32, [3 x i64] }
%sollang.enum.t113 = type { i32, [1 x i64] }
%sollang.enum.t115 = type { i32, [4 x i64] }
%sollang.enum.t116 = type { i32, [4 x i64] }
%sollang.enum.t117 = type { i32, [2 x i64] }
%sollang.enum.t118 = type { i32, [8 x i64] }
%sollang.enum.t119 = type { i32, [2 x i64] }
%sollang.enum.t120 = type { i32, [4 x i64] }
%sollang.enum.t121 = type { i32, [2 x i64] }
%sollang.enum.t122 = type { i32, [2 x i64] }
%sollang.enum.t124 = type { i32, [3 x i64] }
%sollang.enum.t125 = type { i32, [0 x i64] }
%sollang.enum.t131 = type { i32, [2 x i64] }
%sollang.enum.t132 = type { i32, [3 x i64] }
%sollang.enum.t137 = type { i32, [0 x i64] }
%sollang.enum.t139 = type { i32, [4 x i64] }
%sollang.enum.t140 = type { i32, [2 x i64] }
%sollang.enum.t141 = type { i32, [2 x i64] }
%sollang.enum.t143 = type { i32, [2 x i64] }
%sollang.enum.t144 = type { i32, [4 x i64] }
%sollang.enum.t145 = type { i32, [0 x i64] }
%sollang.enum.t146 = type { i32, [0 x i64] }
%sollang.enum.t150 = type { i32, [0 x i64] }
%sollang.enum.t153 = type { i32, [3 x i64] }
%sollang.enum.t154 = type { i32, [12 x i64] }
%sollang.enum.t155 = type { i32, [3 x i64] }
%sollang.enum.t156 = type { i32, [4 x i64] }
%sollang.enum.t173 = type { i32, [0 x i64] }
%sollang.enum.t174 = type { i32, [0 x i64] }
%sollang.enum.t176 = type { i32, [0 x i64] }
%sollang.enum.t188 = type { i32, [1 x i64] }
%sollang.enum.t189 = type { i32, [1 x i64] }
%sollang.enum.t190 = type { i32, [2 x i64] }
%sollang.enum.t191 = type { i32, [2 x i64] }
%sollang.enum.t192 = type { i32, [2 x i64] }
%sollang.enum.t193 = type { i32, [6 x i64] }
%sollang.enum.t194 = type { i32, [1 x i64] }
%sollang.enum.t195 = type { i32, [1 x i64] }
%sollang.enum.t196 = type { i32, [1 x i64] }
%sollang.enum.t197 = type { i32, [1 x i64] }
%sollang.enum.t198 = type { i32, [11 x i64] }
%sollang.enum.t199 = type { i32, [0 x i64] }
%sollang.enum.t201 = type { i32, [3 x i64] }
%sollang.enum.t202 = type { i32, [1 x i64] }
%sollang.enum.t204 = type { i32, [12 x i64] }
%sollang.enum.t208 = type { i32, [29 x i64] }
%sollang.enum.t209 = type { i32, [12 x i64] }
%sollang.enum.t210 = type { i32, [2 x i64] }
%sollang.enum.t212 = type { i32, [2 x i64] }
%sollang.enum.t214 = type { i32, [3 x i64] }
%sollang.enum.t215 = type { i32, [0 x i64] }
%sollang.enum.t221 = type { i32, [0 x i64] }
%sollang.enum.t223 = type { i32, [2 x i64] }
%sollang.enum.t224 = type { i32, [1 x i64] }
%sollang.enum.t225 = type { i32, [1 x i64] }
%sollang.enum.t227 = type { i32, [0 x i64] }
%sollang.enum.t230 = type { i32, [4 x i64] }
%sollang.enum.t231 = type { i32, [3 x i64] }
%sollang.enum.t236 = type { i32, [2 x i64] }
%sollang.enum.t246 = type { i32, [2 x i64] }
%sollang.enum.t247 = type { i32, [2 x i64] }
%sollang.enum.t248 = type { i32, [2 x i64] }
%sollang.enum.t249 = type { i32, [7 x i64] }
%sollang.enum.t250 = type { i32, [7 x i64] }
%sollang.enum.t251 = type { i32, [0 x i64] }
%sollang.enum.t252 = type { i32, [0 x i64] }
%sollang.enum.t253 = type { i32, [2 x i64] }
%sollang.enum.t254 = type { i32, [2 x i64] }
%sollang.enum.t257 = type { i32, [7 x i64] }
%sollang.enum.t258 = type { i32, [4 x i64] }
%sollang.enum.t259 = type { i32, [2 x i64] }
%sollang.enum.t263 = type { i32, [2 x i64] }
%sollang.enum.t264 = type { i32, [2 x i64] }
%sollang.enum.t270 = type { i32, [2 x i64] }
%sollang.enum.t275 = type { i32, [1 x i64] }
%sollang.enum.t276 = type { i32, [0 x i64] }
%sollang.enum.t278 = type { i32, [0 x i64] }
%sollang.enum.t284 = type { i32, [0 x i64] }
%sollang.enum.t290 = type { i32, [3 x i64] }
%sollang.enum.t291 = type { i32, [44 x i64] }
%sollang.enum.t292 = type { i32, [2 x i64] }
%sollang.enum.t293 = type { i32, [13 x i64] }
%sollang.enum.t294 = type { i32, [2 x i64] }
%sollang.enum.t295 = type { i32, [0 x i64] }
%sollang.enum.t296 = type { i32, [0 x i64] }
%sollang.enum.t299 = type { i32, [0 x i64] }
%sollang.enum.t301 = type { i32, [0 x i64] }
%sollang.enum.t303 = type { i32, [0 x i64] }
%sollang.enum.t308 = type { i32, [1 x i64] }
%sollang.enum.t309 = type { i32, [7 x i64] }
%sollang.enum.t310 = type { i32, [1 x i64] }
%sollang.enum.t313 = type { i32, [3 x i64] }
%sollang.enum.t316 = type { i32, [1 x i64] }
%sollang.enum.t317 = type { i32, [0 x i64] }
%sollang.enum.t319 = type { i32, [0 x i64] }
%sollang.enum.t328 = type { i32, [0 x i64] }
%sollang.enum.t329 = type { i32, [0 x i64] }
%sollang.enum.t336 = type { i32, [3 x i64] }
%sollang.enum.t337 = type { i32, [4 x i64] }
%sollang.enum.t338 = type { i32, [105 x i64] }
%sollang.enum.t339 = type { i32, [2 x i64] }
%sollang.enum.t340 = type { i32, [9 x i64] }
%sollang.enum.t341 = type { i32, [26 x i64] }
%sollang.enum.t342 = type { i32, [81 x i64] }
%sollang.enum.t343 = type { i32, [2 x i64] }
%sollang.enum.t346 = type { i32, [3 x i64] }
%sollang.enum.t347 = type { i32, [0 x i64] }
%sollang.enum.t351 = type { i32, [0 x i64] }
%sollang.enum.t372 = type { i32, [2 x i64] }
%sollang.enum.t373 = type { i32, [4 x i64] }
%sollang.enum.t374 = type { i32, [4 x i64] }
%sollang.enum.t375 = type { i32, [72 x i64] }
%sollang.enum.t376 = type { i32, [2 x i64] }
%sollang.enum.t377 = type { i32, [2 x i64] }
%sollang.enum.t378 = type { i32, [2 x i64] }
%sollang.enum.t379 = type { i32, [13 x i64] }
%sollang.enum.t380 = type { i32, [26 x i64] }
%sollang.enum.t381 = type { i32, [5 x i64] }
%sollang.enum.t382 = type { i32, [2 x i64] }
%sollang.enum.t386 = type { i32, [2 x i64] }
%sollang.enum.t387 = type { i32, [72 x i64] }
%sollang.enum.t388 = type { i32, [3 x i64] }
%sollang.enum.t389 = type { i32, [0 x i64] }
%sollang.enum.t395 = type { i32, [0 x i64] }
%sollang.enum.t401 = type { i32, [3 x i64] }
%sollang.enum.t402 = type { i32, [13 x i64] }
%sollang.enum.t403 = type { i32, [70 x i64] }
%sollang.enum.t404 = type { i32, [2 x i64] }
%sollang.enum.t405 = type { i32, [40 x i64] }
%sollang.enum.t409 = type { i32, [3 x i64] }
%sollang.enum.t415 = type { i32, [3 x i64] }
%sollang.enum.t417 = type { i32, [0 x i64] }
%sollang.enum.t420 = type { i32, [0 x i64] }
%sollang.enum.t426 = type { i32, [8 x i64] }
%sollang.enum.t427 = type { i32, [1 x i64] }
%sollang.enum.t428 = type { i32, [2 x i64] }
%sollang.enum.t429 = type { i32, [2 x i64] }
%sollang.enum.t430 = type { i32, [2 x i64] }
%sollang.enum.t436 = type { i32, [3 x i64] }
%sollang.enum.t442 = type { i32, [0 x i64] }
%sollang.enum.t443 = type { i32, [0 x i64] }
%sollang.enum.t444 = type { i32, [0 x i64] }
%sollang.enum.t452 = type { i32, [2 x i64] }
%sollang.enum.t453 = type { i32, [2 x i64] }
%sollang.enum.t454 = type { i32, [2 x i64] }
%sollang.enum.t455 = type { i32, [5 x i64] }
%sollang.enum.t456 = type { i32, [11 x i64] }
%sollang.enum.t457 = type { i32, [9 x i64] }
%sollang.enum.t459 = type { i32, [3 x i64] }
%sollang.enum.t460 = type { i32, [0 x i64] }
%sollang.enum.t461 = type { i32, [0 x i64] }
%sollang.enum.t465 = type { i32, [2 x i64] }
%sollang.enum.t466 = type { i32, [2 x i64] }
%sollang.enum.t467 = type { i32, [2 x i64] }
%sollang.enum.t468 = type { i32, [2 x i64] }
%sollang.enum.t469 = type { i32, [2 x i64] }
%sollang.enum.t470 = type { i32, [0 x i64] }
%sollang.enum.t477 = type { i32, [2 x i64] }
%sollang.enum.t478 = type { i32, [2 x i64] }
%sollang.enum.t479 = type { i32, [2 x i64] }
%sollang.enum.t480 = type { i32, [3 x i64] }
%sollang.enum.t481 = type { i32, [4 x i64] }
%sollang.enum.t482 = type { i32, [2 x i64] }
%sollang.enum.t483 = type { i32, [3 x i64] }
%sollang.enum.t484 = type { i32, [0 x i64] }
%sollang.enum.t486 = type { i32, [2 x i64] }
%sollang.enum.t497 = type { i32, [5 x i64] }
%sollang.enum.t498 = type { i32, [10 x i64] }
%sollang.enum.t499 = type { i32, [10 x i64] }
%sollang.enum.t500 = type { i32, [11 x i64] }
%sollang.enum.t501 = type { i32, [11 x i64] }
%sollang.enum.t510 = type { i32, [8 x i64] }
%sollang.enum.t511 = type { i32, [8 x i64] }
%sollang.enum.t512 = type { i32, [2 x i64] }
%sollang.enum.t522 = type { i32, [16 x i64] }
%sollang.enum.t524 = type { i32, [7 x i64] }
%sollang.enum.t525 = type { i32, [7 x i64] }
%sollang.enum.t526 = type { i32, [3 x i64] }
%sollang.enum.t527 = type { i32, [0 x i64] }
%sollang.enum.t528 = type { i32, [0 x i64] }
%sollang.enum.t531 = type { i32, [0 x i64] }
%sollang.enum.t534 = type { i32, [0 x i64] }
%sollang.enum.t542 = type { i32, [3 x i64] }
%sollang.enum.t543 = type { i32, [3 x i64] }
%sollang.enum.t544 = type { i32, [13 x i64] }
%sollang.enum.t545 = type { i32, [12 x i64] }
%sollang.enum.t546 = type { i32, [4 x i64] }
%sollang.enum.t547 = type { i32, [2 x i64] }
%sollang.enum.t548 = type { i32, [2 x i64] }
%sollang.enum.t549 = type { i32, [2 x i64] }
%sollang.enum.t550 = type { i32, [0 x i64] }
%sollang.enum.t593 = type { i32, [7 x i64] }
%sollang.enum.t607 = type { i32, [2 x i64] }
%sollang.enum.t608 = type { i32, [2 x i64] }
%sollang.enum.t609 = type { i32, [9 x i64] }
%sollang.enum.t610 = type { i32, [21 x i64] }
%sollang.enum.t611 = type { i32, [4 x i64] }
%sollang.enum.t612 = type { i32, [9 x i64] }
%sollang.enum.t613 = type { i32, [2 x i64] }
%sollang.enum.t614 = type { i32, [5 x i64] }
%sollang.enum.t615 = type { i32, [2 x i64] }
%sollang.enum.t616 = type { i32, [14 x i64] }
%sollang.enum.t618 = type { i32, [11 x i64] }
%sollang.enum.t619 = type { i32, [16 x i64] }
%sollang.enum.t620 = type { i32, [7 x i64] }
%sollang.enum.t623 = type { i32, [7 x i64] }
%sollang.enum.t624 = type { i32, [4 x i64] }
%sollang.enum.t625 = type { i32, [6 x i64] }
%sollang.enum.t626 = type { i32, [7 x i64] }
%sollang.enum.t627 = type { i32, [6 x i64] }
%sollang.enum.t628 = type { i32, [5 x i64] }
%sollang.enum.t629 = type { i32, [2 x i64] }
%sollang.enum.t630 = type { i32, [4 x i64] }
%sollang.enum.t631 = type { i32, [10 x i64] }
%sollang.enum.t632 = type { i32, [131 x i64] }
%sollang.enum.t633 = type { i32, [2 x i64] }
%sollang.enum.t634 = type { i32, [16 x i64] }
%sollang.enum.t635 = type { i32, [7 x i64] }
%sollang.enum.t636 = type { i32, [10 x i64] }
%sollang.enum.t638 = type { i32, [5 x i64] }
%sollang.enum.t640 = type { i32, [2 x i64] }
%sollang.enum.t641 = type { i32, [17 x i64] }
%sollang.enum.t642 = type { i32, [2 x i64] }
%sollang.enum.t643 = type { i32, [2 x i64] }
%sollang.enum.t644 = type { i32, [3 x i64] }
%sollang.enum.t647 = type { i32, [1 x i64] }
%sollang.enum.t648 = type { i32, [0 x i64] }
%sollang.enum.t649 = type { i32, [0 x i64] }
%sollang.enum.t650 = type { i32, [0 x i64] }
%sollang.enum.t653 = type { i32, [0 x i64] }
%sollang.enum.t662 = type { i32, [2 x i64] }
%sollang.enum.t663 = type { i32, [3 x i64] }
%sollang.enum.t664 = type { i32, [17 x i64] }
%sollang.enum.t666 = type { i32, [2 x i64] }
%sollang.enum.t667 = type { i32, [2 x i64] }
%sollang.enum.t675 = type { i32, [0 x i64] }
%sollang.enum.t676 = type { i32, [0 x i64] }
%sollang.enum.t685 = type { i32, [12 x i64] }
%sollang.enum.t686 = type { i32, [4 x i64] }
%sollang.enum.t687 = type { i32, [3 x i64] }
%sollang.enum.t688 = type { i32, [3 x i64] }
%sollang.enum.t689 = type { i32, [4 x i64] }
%sollang.enum.t690 = type { i32, [2 x i64] }
%sollang.enum.t692 = type { i32, [3 x i64] }
%sollang.enum.t693 = type { i32, [0 x i64] }
%sollang.enum.t697 = type { i32, [6 x i64] }
%sollang.enum.t698 = type { i32, [3 x i64] }
%sollang.enum.t699 = type { i32, [0 x i64] }
%sollang.enum.t700 = type { i32, [0 x i64] }
%sollang.enum.t701 = type { i32, [0 x i64] }
%sollang.enum.t713 = type { i32, [2 x i64] }
%sollang.enum.t714 = type { i32, [2 x i64] }
%sollang.enum.t715 = type { i32, [2 x i64] }
%sollang.enum.t716 = type { i32, [2 x i64] }
%sollang.enum.t717 = type { i32, [2 x i64] }
%sollang.enum.t718 = type { i32, [12 x i64] }
%sollang.enum.t719 = type { i32, [6 x i64] }
%sollang.enum.t720 = type { i32, [3 x i64] }
%sollang.enum.t721 = type { i32, [2 x i64] }
%sollang.enum.t722 = type { i32, [8 x i64] }
%sollang.enum.t724 = type { i32, [2 x i64] }
%sollang.enum.t725 = type { i32, [4 x i64] }
%sollang.enum.t728 = type { i32, [3 x i64] }
%sollang.enum.t729 = type { i32, [0 x i64] }
%sollang.enum.t730 = type { i32, [0 x i64] }
%sollang.enum.t731 = type { i32, [0 x i64] }
%sollang.enum.t739 = type { i32, [4 x i64] }
%sollang.enum.t740 = type { i32, [4 x i64] }
%sollang.enum.t741 = type { i32, [7 x i64] }
%sollang.enum.t742 = type { i32, [4 x i64] }
%sollang.enum.t744 = type { i32, [9 x i64] }
%sollang.enum.t745 = type { i32, [2 x i64] }
%sollang.enum.t746 = type { i32, [4 x i64] }
%sollang.enum.t747 = type { i32, [0 x i64] }
%sollang.enum.t748 = type { i32, [0 x i64] }
%sollang.enum.t752 = type { i32, [2 x i64] }
%sollang.enum.t753 = type { i32, [3 x i64] }
%sollang.enum.t754 = type { i32, [0 x i64] }
%sollang.enum.t755 = type { i32, [0 x i64] }
%sollang.enum.t756 = type { i32, [0 x i64] }
%sollang.enum.t759 = type { i32, [2 x i64] }
%sollang.enum.t762 = type { i32, [3 x i64] }
%sollang.enum.t773 = type { i32, [0 x i64] }
%sollang.enum.t774 = type { i32, [3 x i64] }
%sollang.enum.t775 = type { i32, [6 x i64] }
%sollang.enum.t776 = type { i32, [1 x i64] }
%sollang.enum.t777 = type { i32, [2 x i64] }
%sollang.enum.t778 = type { i32, [3 x i64] }
%sollang.enum.t779 = type { i32, [8 x i64] }
%sollang.enum.t780 = type { i32, [2 x i64] }
%sollang.enum.t781 = type { i32, [1 x i64] }
%sollang.enum.t782 = type { i32, [2 x i64] }
%sollang.enum.t783 = type { i32, [3 x i64] }
%sollang.enum.t784 = type { i32, [2 x i64] }
%sollang.enum.t786 = type { i32, [16 x i64] }
%sollang.enum.t787 = type { i32, [0 x i64] }
%sollang.enum.t788 = type { i32, [0 x i64] }
%sollang.enum.t789 = type { i32, [2 x i64] }
%sollang.enum.t790 = type { i32, [4 x i64] }
%sollang.enum.t791 = type { i32, [3 x i64] }
%sollang.enum.t792 = type { i32, [18 x i64] }
%sollang.enum.t793 = type { i32, [3 x i64] }
%sollang.enum.t794 = type { i32, [16 x i64] }
%sollang.enum.t795 = type { i32, [2 x i64] }
%sollang.enum.t796 = type { i32, [2 x i64] }
%sollang.enum.t797 = type { i32, [2 x i64] }
%sollang.enum.t799 = type { i32, [1 x i64] }
%sollang.enum.t800 = type { i32, [2 x i64] }
%sollang.enum.t801 = type { i32, [2 x i64] }
%sollang.enum.t802 = type { i32, [5 x i64] }
%sollang.enum.t803 = type { i32, [2 x i64] }
%sollang.enum.t806 = type { i32, [9 x i64] }
%sollang.enum.t807 = type { i32, [7 x i64] }
%sollang.enum.t808 = type { i32, [3 x i64] }
%sollang.enum.t809 = type { i32, [2 x i64] }
%sollang.enum.t811 = type { i32, [0 x i64] }
%sollang.enum.t817 = type { i32, [1 x i64] }
%sollang.enum.t819 = type { i32, [0 x i64] }
%sollang.enum.t820 = type { i32, [0 x i64] }
%sollang.enum.t822 = type { i32, [1 x i64] }
%sollang.enum.t823 = type { i32, [1 x i64] }
%sollang.enum.t826 = type { i32, [26 x i64] }
%sollang.enum.t827 = type { i32, [4 x i64] }
%sollang.enum.t828 = type { i32, [2 x i64] }
%sollang.enum.t829 = type { i32, [2 x i64] }
%sollang.enum.t830 = type { i32, [2 x i64] }
%sollang.enum.t831 = type { i32, [50 x i64] }
%sollang.enum.t832 = type { i32, [2 x i64] }
%sollang.enum.t833 = type { i32, [3 x i64] }
%sollang.enum.t834 = type { i32, [2 x i64] }
%sollang.enum.t835 = type { i32, [2 x i64] }
%sollang.enum.t837 = type { i32, [2 x i64] }
%sollang.enum.t838 = type { i32, [2 x i64] }
%sollang.enum.t843 = type { i32, [0 x i64] }
%sollang.enum.t844 = type { i32, [0 x i64] }
%sollang.enum.t846 = type { i32, [0 x i64] }
%sollang.enum.t847 = type { i32, [4 x i64] }
%sollang.enum.t849 = type { i32, [0 x i64] }
%sollang.enum.t852 = type { i32, [0 x i64] }
%sollang.enum.t855 = type { i32, [0 x i64] }
%sollang.enum.t859 = type { i32, [1 x i64] }
%sollang.enum.t862 = type { i32, [1 x i64] }
%sollang.enum.t864 = type { i32, [1 x i64] }
%sollang.enum.t866 = type { i32, [1 x i64] }
%sollang.enum.t868 = type { i32, [5 x i64] }
%sollang.enum.t869 = type { i32, [1 x i64] }
%sollang.enum.t870 = type { i32, [0 x i64] }
%sollang.enum.t871 = type { i32, [0 x i64] }
%sollang.enum.t872 = type { i32, [0 x i64] }
%sollang.enum.t881 = type { i32, [9 x i64] }
%sollang.enum.t882 = type { i32, [24 x i64] }
%sollang.enum.t883 = type { i32, [2 x i64] }
%sollang.enum.t884 = type { i32, [12 x i64] }
%sollang.enum.t885 = type { i32, [11 x i64] }
%sollang.enum.t886 = type { i32, [2 x i64] }
%sollang.enum.t887 = type { i32, [32 x i64] }
%sollang.enum.t888 = type { i32, [34 x i64] }
%sollang.enum.t889 = type { i32, [2 x i64] }
%sollang.enum.t890 = type { i32, [9 x i64] }
%sollang.enum.t891 = type { i32, [31 x i64] }
%sollang.enum.t892 = type { i32, [2 x i64] }
%sollang.enum.t893 = type { i32, [15 x i64] }
%sollang.enum.t894 = type { i32, [34 x i64] }
%sollang.enum.t895 = type { i32, [2 x i64] }
%sollang.enum.t896 = type { i32, [2 x i64] }
%sollang.enum.t897 = type { i32, [6 x i64] }
%sollang.enum.t898 = type { i32, [2 x i64] }
%sollang.enum.t899 = type { i32, [2 x i64] }
%sollang.enum.t900 = type { i32, [2 x i64] }
%sollang.enum.t902 = type { i32, [14 x i64] }
%sollang.enum.t903 = type { i32, [9 x i64] }
%sollang.enum.t904 = type { i32, [5 x i64] }
%sollang.enum.t905 = type { i32, [5 x i64] }
%sollang.enum.t906 = type { i32, [4 x i64] }
%sollang.enum.t907 = type { i32, [2 x i64] }
%sollang.enum.t909 = type { i32, [2 x i64] }
%sollang.enum.t914 = type { i32, [66 x i64] }
%sollang.enum.t915 = type { i32, [1 x i64] }
%sollang.enum.t917 = type { i32, [1 x i64] }
%sollang.enum.t918 = type { i32, [2 x i64] }
%sollang.enum.t919 = type { i32, [81 x i64] }
%sollang.enum.t920 = type { i32, [2 x i64] }
%sollang.enum.t921 = type { i32, [3 x i64] }
%sollang.enum.t922 = type { i32, [0 x i64] }
%sollang.enum.t923 = type { i32, [4 x i64] }
%sollang.enum.t926 = type { i32, [1 x i64] }
%sollang.enum.t928 = type { i32, [1 x i64] }
%sollang.enum.t930 = type { i32, [3 x i64] }
%sollang.enum.t931 = type { i32, [5 x i64] }
%sollang.enum.t932 = type { i32, [2 x i64] }
%sollang.enum.t933 = type { i32, [14 x i64] }
%sollang.enum.t934 = type { i32, [2 x i64] }
%sollang.enum.t935 = type { i32, [32 x i64] }
%sollang.enum.t936 = type { i32, [4 x i64] }
%sollang.enum.t937 = type { i32, [2 x i64] }
%sollang.enum.t939 = type { i32, [5 x i64] }
%sollang.enum.t940 = type { i32, [2 x i64] }
%sollang.enum.t942 = type { i32, [0 x i64] }
%sollang.enum.t943 = type { i32, [0 x i64] }
%sollang.enum.t945 = type { i32, [4 x i64] }
%sollang.enum.t948 = type { i32, [1 x i64] }
%sollang.enum.t949 = type { i32, [1 x i64] }
%sollang.enum.t951 = type { i32, [2 x i64] }
%sollang.enum.t952 = type { i32, [5 x i64] }
%sollang.enum.t953 = type { i32, [2 x i64] }
%sollang.enum.t954 = type { i32, [2 x i64] }
%sollang.enum.t955 = type { i32, [32 x i64] }
%sollang.enum.t956 = type { i32, [2 x i64] }
%sollang.enum.t957 = type { i32, [4 x i64] }
%sollang.enum.t959 = type { i32, [2 x i64] }
%sollang.enum.t962 = type { i32, [1 x i64] }
%sollang.enum.t966 = type { i32, [2 x i64] }
%sollang.enum.t967 = type { i32, [4 x i64] }
%sollang.enum.t968 = type { i32, [2 x i64] }
%sollang.enum.t969 = type { i32, [2 x i64] }
%sollang.enum.t970 = type { i32, [2 x i64] }
%sollang.enum.t971 = type { i32, [2 x i64] }
%sollang.enum.t972 = type { i32, [2 x i64] }
%sollang.enum.t973 = type { i32, [0 x i64] }
%sollang.enum.t977 = type { i32, [2 x i64] }
%sollang.enum.t978 = type { i32, [3 x i64] }
%sollang.enum.t979 = type { i32, [2 x i64] }
%sollang.enum.t981 = type { i32, [1 x i64] }
%sollang.enum.t984 = type { i32, [3 x i64] }
%sollang.enum.t985 = type { i32, [4 x i64] }
%sollang.enum.t986 = type { i32, [9 x i64] }
%sollang.enum.t987 = type { i32, [2 x i64] }
%sollang.enum.t988 = type { i32, [32 x i64] }
%sollang.enum.t989 = type { i32, [3 x i64] }
%sollang.enum.t991 = type { i32, [5 x i64] }
%sollang.enum.t992 = type { i32, [2 x i64] }
%sollang.enum.t993 = type { i32, [0 x i64] }
%sollang.enum.t997 = type { i32, [10 x i64] }
%sollang.enum.t998 = type { i32, [11 x i64] }
%sollang.enum.t999 = type { i32, [2 x i64] }
%sollang.enum.t1000 = type { i32, [1 x i64] }
%sollang.enum.t1001 = type { i32, [0 x i64] }
%sollang.enum.t1003 = type { i32, [5 x i64] }
%sollang.enum.t1004 = type { i32, [3 x i64] }
%sollang.enum.t1005 = type { i32, [3 x i64] }
%sollang.enum.t1006 = type { i32, [0 x i64] }
%sollang.enum.t1010 = type { i32, [0 x i64] }
%sollang.enum.t1012 = type { i32, [10 x i64] }
%sollang.enum.t1013 = type { i32, [33 x i64] }
%sollang.enum.t1014 = type { i32, [35 x i64] }
%sollang.enum.t1015 = type { i32, [1 x i64] }
%sollang.enum.t1018 = type { i32, [1 x i64] }
%sollang.enum.t1019 = type { i32, [0 x i64] }
%sollang.enum.t1020 = type { i32, [0 x i64] }
%sollang.enum.t1026 = type { i32, [5 x i64] }
%sollang.enum.t1027 = type { i32, [3 x i64] }
%sollang.enum.t1028 = type { i32, [15 x i64] }
%sollang.enum.t1029 = type { i32, [3 x i64] }
%sollang.enum.t1030 = type { i32, [2 x i64] }
%sollang.enum.t1031 = type { i32, [3 x i64] }
%sollang.enum.t1036 = type { i32, [0 x i64] }
%sollang.enum.t1037 = type { i32, [0 x i64] }
%sollang.enum.t1039 = type { i32, [2 x i64] }
%sollang.enum.t1045 = type { i32, [7 x i64] }
%sollang.enum.t1046 = type { i32, [3 x i64] }
%sollang.enum.t1047 = type { i32, [3 x i64] }
%sollang.enum.t1048 = type { i32, [15 x i64] }
%sollang.enum.t1049 = type { i32, [25 x i64] }
%sollang.enum.t1050 = type { i32, [7 x i64] }
%sollang.enum.t1051 = type { i32, [5 x i64] }
%sollang.enum.t1052 = type { i32, [9 x i64] }
%sollang.enum.t1053 = type { i32, [31 x i64] }
%sollang.enum.t1054 = type { i32, [3 x i64] }
%sollang.enum.t1055 = type { i32, [8 x i64] }
%sollang.enum.t1059 = type { i32, [2 x i64] }
%sollang.enum.t1060 = type { i32, [2 x i64] }
%sollang.enum.t1061 = type { i32, [12 x i64] }
%sollang.enum.t1062 = type { i32, [6 x i64] }
%sollang.enum.t1064 = type { i32, [0 x i64] }
%sollang.enum.t1065 = type { i32, [0 x i64] }
%sollang.enum.t1069 = type { i32, [2 x i64] }
%sollang.enum.t1070 = type { i32, [9 x i64] }
%sollang.enum.t1071 = type { i32, [6 x i64] }
%sollang.enum.t1073 = type { i32, [2 x i64] }
%sollang.enum.t1075 = type { i32, [8 x i64] }
%sollang.enum.t1079 = type { i32, [3 x i64] }
%sollang.enum.t1080 = type { i32, [26 x i64] }
%sollang.enum.t1081 = type { i32, [4 x i64] }
%sollang.enum.t1082 = type { i32, [5 x i64] }
%sollang.enum.t1083 = type { i32, [8 x i64] }
%sollang.enum.t1084 = type { i32, [40 x i64] }
%sollang.enum.t1085 = type { i32, [9 x i64] }
%sollang.enum.t1086 = type { i32, [3 x i64] }
%sollang.enum.t1090 = type { i32, [10 x i64] }
%sollang.enum.t1091 = type { i32, [5 x i64] }
%sollang.enum.t1092 = type { i32, [3 x i64] }
%sollang.enum.t1095 = type { i32, [8 x i64] }
%sollang.enum.t1102 = type { i32, [2 x i64] }
%sollang.enum.t1103 = type { i32, [4 x i64] }
%sollang.enum.t1113 = type { i32, [2 x i64] }
%sollang.enum.t1114 = type { i32, [9 x i64] }
%sollang.enum.t1115 = type { i32, [3 x i64] }
%sollang.enum.t1116 = type { i32, [7 x i64] }
%sollang.enum.t1117 = type { i32, [11 x i64] }
%sollang.enum.t1118 = type { i32, [7 x i64] }
%sollang.enum.t1129 = type { i32, [6 x i64] }
%sollang.enum.t1131 = type { i32, [11 x i64] }
%sollang.enum.t1132 = type { i32, [18 x i64] }
%sollang.enum.t1134 = type { i32, [149 x i64] }
%sollang.enum.t1135 = type { i32, [3 x i64] }
%sollang.enum.t1136 = type { i32, [2 x i64] }
%sollang.enum.t1147 = type { i32, [2 x i64] }
%sollang.enum.t1148 = type { i32, [2 x i64] }
%sollang.enum.t1150 = type { i32, [12 x i64] }
%sollang.enum.t1151 = type { i32, [9 x i64] }
%sollang.enum.t1152 = type { i32, [5 x i64] }
%sollang.enum.t1153 = type { i32, [5 x i64] }
%sollang.enum.t1154 = type { i32, [6 x i64] }
%sollang.enum.t1155 = type { i32, [6 x i64] }
%sollang.enum.t1156 = type { i32, [2 x i64] }
%sollang.enum.t1160 = type { i32, [14 x i64] }
%sollang.enum.t1167 = type { i32, [6 x i64] }
%sollang.enum.t1168 = type { i32, [6 x i64] }
%sollang.enum.t1169 = type { i32, [0 x i64] }
%sollang.enum.t1170 = type { i32, [0 x i64] }
%sollang.enum.t1173 = type { i32, [4 x i64] }
%sollang.enum.t1174 = type { i32, [5 x i64] }
%sollang.enum.t1175 = type { i32, [4 x i64] }
%sollang.enum.t1176 = type { i32, [21 x i64] }
%sollang.enum.t1177 = type { i32, [4 x i64] }
%sollang.enum.t1178 = type { i32, [5 x i64] }
%sollang.enum.t1181 = type { i32, [2 x i64] }
%sollang.enum.t1183 = type { i32, [3 x i64] }
%sollang.enum.t1184 = type { i32, [4 x i64] }
%sollang.enum.t1185 = type { i32, [2 x i64] }
%sollang.enum.t1186 = type { i32, [0 x i64] }
%sollang.enum.t1188 = type { i32, [6 x i64] }
%sollang.enum.t1191 = type { i32, [5 x i64] }
%sollang.enum.t1192 = type { i32, [5 x i64] }
%sollang.enum.t1195 = type { i32, [16 x i64] }
%sollang.enum.t1196 = type { i32, [7 x i64] }
%sollang.enum.t1197 = type { i32, [6 x i64] }
%sollang.enum.t1198 = type { i32, [0 x i64] }
%sollang.enum.t1199 = type { i32, [4 x i64] }
%sollang.enum.t1201 = type { i32, [5 x i64] }
%sollang.enum.t1202 = type { i32, [2 x i64] }
%sollang.enum.t1204 = type { i32, [2 x i64] }
%sollang.enum.t1206 = type { i32, [4 x i64] }
%sollang.enum.t1209 = type { i32, [9 x i64] }
%sollang.enum.t1211 = type { i32, [4 x i64] }
%sollang.struct.m0_s10 = type {  }
%sollang.struct.m0_s8 = type { %sollang.enum.t32 }
%sollang.struct.m0_s14 = type { i32, i32 }
%sollang.struct.m0_s11 = type { i32, i1 }
%sollang.struct.m1_s7 = type { %sollang.enum.t99, i64 }
%sollang.struct.m1_s38 = type { %sollang.array.i32, i32, i32 }
%sollang.struct.m1_s42 = type { %sollang.array.i32, i32 }
%sollang.struct.m1_s29 = type { i32, i32 }
%sollang.struct.m1_s32 = type { %sollang.array.i32, i32, %sollang.array.i32, i32, i32 }
%sollang.struct.m1_s26 = type { i32, %sollang.enum.t100 }
%sollang.struct.m2_s6 = type { %sollang.text, %sollang.text }
%sollang.struct.m2_s9 = type { %sollang.text }
%sollang.struct.m2_s19 = type { %sollang.enum.t125 }
%sollang.struct.m2_s11 = type { %sollang.enum.t125, %sollang.text }
%sollang.struct.m3_s0 = type { i8, i8, i8, i8 }
%sollang.struct.m3_s8 = type { i16, i16, i16, i16, i16, i16, i16, i16 }
%sollang.struct.m3_s5 = type { %sollang.struct.m3_s0, i16 }
%sollang.struct.m3_s17 = type { %sollang.struct.m3_s8, i16, i32, i32 }
%sollang.struct.m3_s28 = type { %sollang.enum.t137, i64 }
%sollang.struct.m4_s19 = type { i32, i32, i32 }
%sollang.struct.m4_s27 = type { %sollang.enum.t146, i64, i1 }
%sollang.struct.m4_s16 = type { %sollang.enum.t145, i64 }
%sollang.struct.m4_s31 = type { %sollang.source_text, i64, i64, i32, i1, %sollang.struct.m4_s19, %sollang.struct.m4_s27 }
%sollang.struct.m4_s23 = type { %sollang.enum.t146, i64, i64 }
%sollang.struct.m6_s2 = type { i64, i64 }
%sollang.struct.m6_s5 = type { i64 }
%sollang.struct.m6_s0 = type { i64 }
%sollang.struct.m6_s38 = type { %sollang.array.i32, %sollang.struct.m6_s0, i64, %sollang.enum.t174 }
%sollang.struct.m6_s59 = type { %sollang.enum.t176 }
%sollang.struct.m6_s7 = type { i64, i64, i64 }
%sollang.struct.m6_s11 = type { i8 }
%sollang.struct.m6_s13 = type { i8 }
%sollang.struct.m6_s15 = type { i64, i64 }
%sollang.struct.m6_s18 = type { i64 }
%sollang.struct.m6_s22 = type { %sollang.struct.m6_s5 }
%sollang.struct.m6_s24 = type { i64 }
%sollang.struct.m6_s20 = type { %sollang.struct.m6_s2 }
%sollang.struct.m6_s30 = type { %sollang.struct.m6_s0, %sollang.enum.t173, %sollang.struct.m6_s0 }
%sollang.struct.m6_s43 = type { %sollang.struct.m6_s38, %sollang.struct.m6_s2, %sollang.struct.m6_s2, i64 }
%sollang.struct.m7_s7 = type { i64, i64, i1 }
%sollang.struct.m7_s14 = type { %sollang.struct.m7_s7, %sollang.enum.t201, %sollang.enum.t202, %sollang.struct.m7_s7 }
%sollang.struct.m7_s29 = type { i1, i1, i1, i1, i1 }
%sollang.struct.m7_s22 = type { %sollang.source_text, %sollang.struct.m7_s7, %sollang.enum.t204, %sollang.struct.m7_s7, %sollang.struct.m7_s7, %sollang.struct.m7_s7 }
%sollang.struct.m7_s0 = type { %sollang.enum.t199, i64 }
%sollang.struct.m30_s2 = type { i8 }
%sollang.struct.m8_s8 = type { %sollang.int_slice }
%sollang.struct.m8_s0 = type { %sollang.enum.t215, i64 }
%sollang.struct.m8_s10 = type { i8 }
%sollang.struct.m8_s12 = type { %sollang.struct.m6_s13, %sollang.struct.m30_s2 }
%sollang.struct.m12_s0 = type { %sollang.array.i32, %sollang.enum.t150 }
%sollang.struct.m9_s0 = type { %sollang.array.i32, i64 }
%sollang.struct.m9_s3 = type { %sollang.struct.m12_s0, %sollang.enum.t227 }
%sollang.struct.m10_s0 = type { i64 }
%sollang.struct.m10_s2 = type { i64 }
%sollang.struct.m10_s13 = type { %sollang.struct.m10_s0, %sollang.array.i32, i64, i1 }
%sollang.struct.m10_s18 = type { %sollang.struct.m10_s0, %sollang.array.i32, %sollang.enum.t236 }
%sollang.struct.m10_s22 = type { %sollang.struct.m10_s2, %sollang.array.i32, i64 }
%sollang.struct.m10_s26 = type { %sollang.struct.m10_s2, %sollang.array.i32, %sollang.enum.t236 }
%sollang.struct.m10_s4 = type { %sollang.text, %sollang.text }
%sollang.struct.m12_s8 = type { %sollang.struct.m12_s0, %sollang.enum.t227, i64, i64 }
%sollang.struct.m12_s3 = type { %sollang.array.i32, i8, i64, i64 }
%sollang.struct.m13_s30 = type { i32 }
%sollang.struct.m13_s0 = type { %sollang.text, %sollang.text, i1 }
%sollang.struct.m13_s32 = type { i32 }
%sollang.struct.m13_s37 = type { i64 }
%sollang.struct.m13_s21 = type { %sollang.array.i32, %sollang.text, i1, %sollang.array.i32, i1, %sollang.enum.t263, %sollang.enum.t264, %sollang.enum.t264 }
%sollang.struct.m13_s12 = type { i64, i64 }
%sollang.struct.m13_s15 = type { %sollang.struct.m13_s30, %sollang.array.i32, %sollang.array.i32, i1, i1 }
%sollang.struct.m13_s39 = type { i64, %sollang.struct.m13_s37, i32, i32 }
%sollang.struct.m13_s44 = type { i32, i32 }
%sollang.struct.m16_s3 = type { i32, i32, i32, i32, i32 }
%sollang.struct.m19_s62 = type { %sollang.struct.m19_s19 }
%sollang.struct.m16_s11 = type { i32, i32, i32 }
%sollang.struct.m39_s3 = type { %sollang.enum.t484, i32 }
%sollang.struct.m16_s0 = type { %sollang.enum.t276, i64 }
%sollang.struct.m16_s46 = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%sollang.struct.m16_s9 = type { %sollang.struct.m16_s3 }
%sollang.struct.m16_s15 = type { %sollang.struct.m16_s3, %sollang.enum.t278, i32, %sollang.array.i32, %sollang.array.i32, i32, i32, i32, %sollang.array.i32, i32, i32, i32, i32, %sollang.array.i32, i1, %sollang.struct.m16_s11, i32, %sollang.struct.m39_s3, %sollang.array.i32, %sollang.array.i32, i32, i32, i32, %sollang.array.i32, i32, i32, %sollang.array.i32, i32, i1, %sollang.struct.m16_s0 }
%sollang.struct.m16_s55 = type { %sollang.struct.m16_s46, %sollang.enum.t284, i32, i32, i32, i32, i32, i32, %sollang.struct.m39_s3, %sollang.array.i32 }
%sollang.struct.m19_s0 = type { %sollang.enum.t347, i64 }
%sollang.struct.m17_s22 = type { %sollang.text, %sollang.text, i32, i64, i32, i32 }
%sollang.struct.m17_s46 = type { i64 }
%sollang.struct.m17_s20 = type { i32 }
%sollang.struct.m17_s29 = type { i64, %sollang.enum.t308, %sollang.enum.t295, %sollang.enum.t296, %sollang.enum.t308, i64, %sollang.enum.t309 }
%sollang.struct.m17_s37 = type { i64, i64, i64, i1 }
%sollang.struct.m17_s42 = type { i64, i64, i64 }
%sollang.struct.m17_s48 = type { %sollang.struct.m17_s46, %sollang.enum.t299 }
%sollang.struct.m18_s3 = type { i32, i32, i32, i32, i32 }
%sollang.struct.m82_s26 = type { i64, i32, i32 }
%sollang.struct.m75_s10 = type { %sollang.struct.m81_s6, %sollang.struct.m77_s7, %sollang.struct.m85_s8, i32, i32, i32 }
%sollang.struct.m76_s26 = type { %sollang.struct.m75_s10, %sollang.struct.m76_s3, i32, %sollang.array.i32, %sollang.enum.t914 }
%sollang.struct.m18_s0 = type { %sollang.enum.t317, i64 }
%sollang.struct.m18_s9 = type { %sollang.struct.m18_s3 }
%sollang.struct.m18_s11 = type { i32, i32, i32, i32, i32, i32, i1 }
%sollang.struct.m18_s19 = type { i32, i32, i32, i32, i32, i32, %sollang.enum.t319, %sollang.struct.m82_s26, %sollang.struct.m75_s10, %sollang.struct.m76_s26, i32, i1, i32, i32, i32, %sollang.array.i32, i1, %sollang.struct.m18_s0 }
%sollang.struct.m74_s7 = type { %sollang.struct.m75_s168, i32, i32, i32, i32 }
%sollang.struct.m75_s168 = type { %sollang.array.i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.struct.m82_s12 }
%sollang.struct.m18_s38 = type { i32, i32 }
%sollang.struct.m18_s41 = type { i32, i32 }
%sollang.struct.m18_s44 = type { i32, i32 }
%sollang.struct.m18_s47 = type { i1, i64 }
%sollang.struct.m82_s12 = type { i32, i32 }
%sollang.struct.m19_s3 = type { i32, i32 }
%sollang.struct.m19_s76 = type { i32, i32 }
%sollang.struct.m19_s6 = type { %sollang.struct.m19_s3 }
%sollang.struct.m19_s93 = type { %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32 }
%sollang.struct.m19_s19 = type { %sollang.struct.m19_s6, i32, i32, i32, i32, i32, i32, %sollang.enum.t351, i32, i32, i32, i32, i32, i32, i32, i1, i32, i32, i32, i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.struct.m19_s93, %sollang.struct.m19_s93, %sollang.struct.m19_s93, i32, i32, i32, i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, i32, i1, %sollang.struct.m19_s0, i1, i1 }
%sollang.struct.m19_s73 = type { i32, i32 }
%sollang.struct.m19_s11 = type { i32, i32, i32, i32, i1, i1, %sollang.struct.m19_s76 }
%sollang.struct.m19_s106 = type { i32, %sollang.array.i32 }
%sollang.struct.m19_s64 = type { i32, i32, i32 }
%sollang.struct.m19_s68 = type { i32, i32, i32, i32 }
%sollang.struct.m19_s99 = type { %sollang.struct.m19_s93, %sollang.struct.m19_s93 }
%sollang.struct.m19_s102 = type { %sollang.struct.m19_s73, i32, %sollang.array.i32 }
%sollang.struct.m19_s119 = type { i1, i32 }
%sollang.struct.m19_s111 = type { i32 }
%sollang.struct.m19_s113 = type { i1, i32 }
%sollang.struct.m19_s79 = type { i32, i32 }
%sollang.struct.m19_s82 = type { i32, i32, i32 }
%sollang.struct.m19_s86 = type { i32, i32, i32 }
%sollang.struct.m19_s90 = type { i32, i32 }
%sollang.struct.m19_s109 = type { i32 }
%sollang.struct.m19_s116 = type { i1, i32 }
%sollang.struct.m19_s8 = type { i32, i32 }
%sollang.struct.m91_s2 = type { %sollang.array.i32, i32 }
%sollang.struct.m90_s2 = type { %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32 }
%sollang.struct.m20_s16 = type { i32, i32, i32, i32, i32 }
%sollang.struct.m20_s22 = type { i1 }
%sollang.struct.m40_s2 = type { i64, i64, i64, i64, i64, i64, i64, %sollang.int_slice, i32 }
%sollang.struct.m20_s0 = type { %sollang.enum.t389, i64 }
%sollang.struct.m20_s24 = type { %sollang.struct.m20_s16, %sollang.struct.m20_s22 }
%sollang.struct.m20_s27 = type { i32, i32, i32, i32, i1, i1, %sollang.struct.m40_s2 }
%sollang.struct.m20_s35 = type { i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.t395, i64, i32, i32, i32, i32, i32, i1, i64, i1, %sollang.struct.m40_s2, i32, i32, i32, i32, i1, %sollang.array.i32, %sollang.struct.m91_s2, i1, %sollang.struct.m90_s2, %sollang.struct.m90_s2, %sollang.struct.m90_s2, i1, i1, i1, i32, i32, i32, %sollang.array.i32, i1, %sollang.struct.m20_s0 }
%sollang.struct.m20_s3 = type { %sollang.array.i32, %sollang.struct.m91_s2, i1, %sollang.struct.m90_s2, %sollang.struct.m90_s2, %sollang.struct.m90_s2, i1, i1, i1, i32, i32, i32 }
%sollang.struct.m21_s2 = type { %sollang.array.i32 }
%sollang.struct.m21_s4 = type { %sollang.int_slice }
%sollang.struct.m22_s6 = type { %sollang.int_slice }
%sollang.struct.m22_s3 = type { %sollang.struct.m21_s2, %sollang.int_slice }
%sollang.struct.m22_s0 = type { %sollang.array.i32, %sollang.int_slice }
%sollang.struct.m25_s2 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.m25_s0 = type { %sollang.enum.t417 }
%sollang.struct.m31_s89 = type { %sollang.int_slice, %sollang.int_slice, i32, i64 }
%sollang.struct.m29_s8 = type { %sollang.struct.m31_s89, %sollang.struct.m31_s89 }
%sollang.struct.m34_s5 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.m34_s0 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.m34_s9 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.m36_s9 = type { %sollang.enum.t443, %sollang.enum.t444 }
%sollang.struct.m36_s0 = type { %sollang.enum.t442, i64 }
%sollang.struct.m36_s3 = type { i32, i32 }
%sollang.struct.m36_s6 = type { i32, i32 }
%sollang.struct.m36_s12 = type { %sollang.struct.m36_s9, i32, i32, i64, i8, i8, i32 }
%sollang.struct.m36_s20 = type { %sollang.struct.m36_s9, i32, i32, i64, i32, i32, i32, i32, i64, i64, i64, i64, i32, i1 }
%sollang.struct.m36_s35 = type { i32, i32, i64, i32, i32, i32, i32, i64, i64, i64, i64, i32, i1 }
%sollang.struct.m37_s3 = type { %sollang.enum.t460, i64 }
%sollang.struct.m37_s6 = type { %sollang.enum.t461, i64 }
%sollang.struct.m37_s9 = type { %sollang.enum.t461, i32, i32 }
%sollang.struct.m38_s9 = type { i1 }
%sollang.struct.m38_s0 = type { %sollang.enum.t470, i64 }
%sollang.struct.m38_s3 = type { i32, i32 }
%sollang.struct.m38_s6 = type { i32, i32 }
%sollang.struct.m38_s11 = type { %sollang.struct.m38_s9, i32, i32, i64 }
%sollang.struct.m38_s16 = type { i32, i32, i64, i32, i64 }
%sollang.struct.m40_s0 = type { i64 }
%sollang.struct.m41_s24 = type { %sollang.array.i32, i32, i32, i32, i1 }
%sollang.struct.m41_s30 = type { %sollang.struct.m41_s24, %sollang.array.i32, i32, i1 }
%sollang.struct.m41_s35 = type { %sollang.struct.m41_s24, %sollang.array.i32, %sollang.enum.t486 }
%sollang.struct.m41_s39 = type { %sollang.struct.m41_s24, %sollang.array.i32, i32, i1 }
%sollang.struct.m41_s44 = type { %sollang.struct.m41_s24, %sollang.array.i32, %sollang.enum.t486 }
%sollang.struct.m41_s5 = type { i1 }
%sollang.struct.m41_s7 = type { %sollang.struct.m1_s38, %sollang.array.i32, i32, i1 }
%sollang.struct.m41_s12 = type { %sollang.struct.m1_s38, %sollang.array.i32, %sollang.enum.t486 }
%sollang.struct.m41_s16 = type { %sollang.struct.m1_s42, %sollang.array.i32, i32 }
%sollang.struct.m41_s20 = type { %sollang.struct.m1_s42, %sollang.array.i32, %sollang.enum.t486 }
%sollang.struct.m42_s0 = type { %sollang.struct.m10_s0, i64 }
%sollang.struct.m42_s3 = type { %sollang.struct.m10_s2, i64 }
%sollang.struct.m42_s6 = type { %sollang.struct.m42_s0, %sollang.array.i32, i32, i1 }
%sollang.struct.m42_s11 = type { %sollang.struct.m42_s0, %sollang.array.i32, %sollang.enum.t236 }
%sollang.struct.m42_s15 = type { %sollang.struct.m42_s3, %sollang.array.i32, i32 }
%sollang.struct.m42_s19 = type { %sollang.struct.m42_s3, %sollang.array.i32, %sollang.enum.t236 }
%sollang.struct.m1_s13 = type {  }
%sollang.struct.m1_s17 = type {  }
%sollang.struct.m48_s52 = type { i64 }
%sollang.struct.m48_s9 = type { i64 }
%sollang.struct.m48_s188 = type { %sollang.enum.t653, i32 }
%sollang.struct.m43_s0 = type { %sollang.struct.m48_s52, i64 }
%sollang.struct.m48_s62 = type { i64, %sollang.enum.t649, %sollang.array.i32, i64, i64, %sollang.enum.t650, %sollang.enum.t275, %sollang.enum.t662, %sollang.enum.t308 }
%sollang.struct.m43_s6 = type { %sollang.struct.m43_s0, %sollang.array.i32, i64, i1 }
%sollang.struct.m43_s11 = type { %sollang.struct.m43_s0, %sollang.array.i32, %sollang.struct.m48_s188 }
%sollang.struct.m43_s15 = type { %sollang.struct.m43_s0, %sollang.array.i32, i64 }
%sollang.struct.m43_s19 = type { %sollang.struct.m43_s0, %sollang.array.i32, %sollang.struct.m48_s188 }
%sollang.struct.m43_s3 = type { %sollang.struct.m48_s9, %sollang.struct.m48_s188 }
%sollang.struct.m44_s17 = type { %sollang.enum.t528, i64, i64 }
%sollang.struct.m44_s14 = type { %sollang.enum.t527, i32 }
%sollang.struct.m45_s12 = type { i64, i64 }
%sollang.struct.m45_s6 = type { i32, i32, i32, i32, i32 }
%sollang.struct.m45_s15 = type { %sollang.struct.m45_s12, %sollang.struct.m45_s12 }
%sollang.struct.m45_s3 = type { %sollang.enum.t531, i64 }
%sollang.struct.m45_s18 = type { %sollang.struct.m45_s6 }
%sollang.struct.m45_s20 = type { %sollang.source_text, %sollang.struct.m45_s12, %sollang.struct.m45_s12, %sollang.enum.t534, %sollang.array.i32, i64 }
%sollang.struct.m45_s27 = type { %sollang.source_text, %sollang.enum.t534, i32, %sollang.struct.m45_s12, %sollang.array.i32, i64 }
%sollang.struct.m45_s34 = type { %sollang.array.i32, i64 }
%sollang.struct.m48_s11 = type { i64 }
%sollang.struct.m47_s97 = type { i64, i64 }
%sollang.struct.m48_s168 = type { %sollang.enum.t139, %sollang.array.i32, i1 }
%sollang.struct.m47_s12 = type { i64, i64, i64, i64 }
%sollang.struct.m47_s3 = type { %sollang.int_slice }
%sollang.struct.m47_s17 = type { i64, i64, i32, i32, i32, i64, %sollang.struct.m47_s12 }
%sollang.struct.m103_s0 = type { i1, i32, %sollang.int_slice, %sollang.struct.m127_s0 }
%sollang.struct.m117_s3 = type { %sollang.array.i32, i64 }
%sollang.struct.m107_s8 = type { i64, i64, i64 }
%sollang.struct.m107_s12 = type { i64, i64 }
%sollang.struct.m107_s15 = type { %sollang.array.i32 }
%sollang.struct.m107_s17 = type { i64, i64 }
%sollang.struct.m115_s13 = type { %sollang.array.i32 }
%sollang.struct.m111_s0 = type { i1, i64, i64, i64, i64 }
%sollang.struct.m111_s6 = type { i64, i64, i64, i64, i1 }
%sollang.struct.m118_s22 = type { i64, i64, i64, i64, i64 }
%sollang.struct.m118_s31 = type { i1, i64, i64, i1, i1, i64, i64, i64, i64, i64, i64, i32, %sollang.array.i32, i32, i32, i32, i32, %sollang.array.i32, i32, i32, i32 }
%sollang.struct.m118_s17 = type { i64, i64, i1, i64 }
%sollang.struct.m118_s11 = type { i64, i64, i64, i1, i64 }
%sollang.struct.m47_s75 = type { %sollang.struct.m118_s17, i1, i1, i64 }
%sollang.struct.m47_s80 = type { %sollang.struct.m118_s11, i1, i1, i64, i1, i64 }
%sollang.struct.m47_s5 = type { %sollang.struct.m48_s11, %sollang.enum.t139, i1, %sollang.array.i32, %sollang.array.i32, i64 }
%sollang.struct.m47_s100 = type { i64, i8 }
%sollang.struct.m47_s0 = type { %sollang.enum.t550, i64 }
%sollang.struct.m106_s18 = type { %sollang.enum.t550, i64 }
%sollang.struct.m47_s172 = type { %sollang.array.i32, i64 }
%sollang.struct.m109_s0 = type { i32, %sollang.array.i32, %sollang.array.i32, i64, %sollang.array.i32 }
%sollang.struct.m123_s6 = type { %sollang.int_slice, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.int_slice, %sollang.array.i32 }
%sollang.struct.m123_s13 = type { %sollang.int_slice, %sollang.array.i32, %sollang.int_slice }
%sollang.struct.m47_s30 = type { %sollang.array.i32, %sollang.enum.t139, %sollang.enum.t139, i1, i32, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.struct.m103_s0, %sollang.struct.m103_s0, i64, i64, i1, %sollang.int_slice, %sollang.array.i32, %sollang.int_slice, %sollang.array.i32, i1, i1, %sollang.array.i32, %sollang.struct.m117_s3, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i64, i32, i64, i1, i1, %sollang.struct.m115_s13, %sollang.struct.m111_s0, %sollang.struct.m111_s6, %sollang.struct.m118_s22, %sollang.struct.m118_s31, i64, i64, i64, i64, i64, i64, i8, i64, i64 }
%sollang.struct.m109_s6 = type { %sollang.array.i32, i64, %sollang.array.i32 }
%sollang.struct.m125_s0 = type { %sollang.enum.t1198, %sollang.struct.m126_s0 }
%sollang.struct.m123_s17 = type { %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.m108_s0 = type { i32, i64, i64, %sollang.array.i32, i64 }
%sollang.struct.m121_s0 = type { %sollang.enum.t1186, %sollang.struct.m126_s0, %sollang.int_slice }
%sollang.struct.m128_s0 = type { i64, %sollang.array.i32, i64 }
%sollang.struct.m130_s0 = type { i32, %sollang.array.i32 }
%sollang.struct.m47_s110 = type { i64, i64, i64, i64, i64, i64, i64, i8, i64, i64 }
%sollang.struct.m47_s25 = type { %sollang.struct.m47_s3, %sollang.enum.t139, %sollang.struct.m47_s17, i1 }
%sollang.struct.m47_s87 = type { i64, %sollang.struct.m47_s75, %sollang.struct.m47_s80 }
%sollang.struct.m47_s91 = type { i64, %sollang.struct.m47_s75 }
%sollang.struct.m47_s94 = type { i64, %sollang.struct.m47_s80 }
%sollang.struct.m103_s9 = type { i64, i1, %sollang.array.i32 }
%sollang.struct.m107_s42 = type { i64, i64, i64, %sollang.array.i32 }
%sollang.struct.m107_s3 = type { i64, i64, i1, %sollang.array.i32 }
%sollang.struct.m48_s17 = type { %sollang.array.i32 }
%sollang.struct.m48_s7 = type { i64 }
%sollang.struct.m48_s85 = type { %sollang.struct.m48_s52, %sollang.struct.m48_s62 }
%sollang.struct.m48_s96 = type { %sollang.struct.m48_s62, %sollang.struct.m48_s188 }
%sollang.struct.m48_s92 = type { %sollang.struct.m48_s52, %sollang.struct.m48_s62, %sollang.struct.m48_s188 }
%sollang.struct.m48_s48 = type { i64, i64, i64 }
%sollang.struct.m48_s39 = type { i64, %sollang.enum.t647, %sollang.enum.t648 }
%sollang.struct.m48_s143 = type { i64, %sollang.array.i32 }
%sollang.struct.m48_s43 = type { i64, i1, i1, i1 }
%sollang.struct.m48_s0 = type { %sollang.enum.t139, i32, i1 }
%sollang.struct.m48_s4 = type { %sollang.enum.t139, i1 }
%sollang.struct.m48_s13 = type { ptr, i64, i64 }
%sollang.struct.m48_s72 = type { %sollang.struct.m48_s52, %sollang.struct.m48_s9, %sollang.struct.m48_s188 }
%sollang.struct.m48_s76 = type { %sollang.struct.m48_s52, %sollang.struct.m48_s9 }
%sollang.struct.m48_s79 = type { %sollang.struct.m48_s52, %sollang.struct.m48_s188 }
%sollang.struct.m48_s172 = type { %sollang.enum.t139, i64, i1 }
%sollang.struct.m49_s34 = type { %sollang.enum.t676, i32 }
%sollang.struct.m49_s24 = type { i32, i32, i32, i32 }
%sollang.struct.m49_s29 = type { i32, i32, i32, i32 }
%sollang.struct.m49_s20 = type { %sollang.enum.t675, i64, i32 }
%sollang.struct.m49_s42 = type { %sollang.source_text, i64, i64, i32, i32, i1, %sollang.struct.m49_s34, %sollang.struct.m49_s24 }
%sollang.struct.m49_s51 = type { %sollang.struct.m49_s29, i32, i32, i32, i32 }
%sollang.struct.m49_s57 = type { i64, i64, i64, i32, i1, i1 }
%sollang.struct.m49_s37 = type { i32, i32, i32, i1 }
%sollang.struct.m50_s10 = type { %sollang.enum.t693, i64, i64 }
%sollang.struct.m50_s0 = type { i32, i32, i32 }
%sollang.struct.m50_s14 = type { %sollang.source_text, i64, i32, i32 }
%sollang.struct.m51_s35 = type { %sollang.array.i32, i32 }
%sollang.struct.m51_s38 = type { %sollang.enum.t701, i64, i64, i1, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.m51_s15 = type { i32, i32, i32, i32 }
%sollang.struct.m51_s20 = type { %sollang.enum.t700, i64, i64, i64, i64, i32, i32 }
%sollang.struct.m51_s12 = type { %sollang.enum.t699, i64 }
%sollang.struct.m51_s49 = type { %sollang.source_text, i64, i64, i8, i32, %sollang.struct.m51_s15, %sollang.array.i32 }
%sollang.struct.m51_s110 = type { i64, i64, i32 }
%sollang.struct.m51_s57 = type { %sollang.array.i32, i32, i32, i32, i8, %sollang.array.i32 }
%sollang.struct.m51_s46 = type { %sollang.array.i32, i32 }
%sollang.struct.m52_s17 = type { %sollang.enum.t729, i64, i64, i64 }
%sollang.struct.m52_s61 = type { i32 }
%sollang.struct.m52_s58 = type { i8, i64 }
%sollang.struct.m52_s50 = type { %sollang.enum.t731, i64, i64, i64, i1, %sollang.enum.t730, i64 }
%sollang.struct.m52_s0 = type { i32, i32, i32, i32 }
%sollang.struct.m52_s25 = type { %sollang.source_text, i64, i64, i32, i32, i1, i1, i32, i32 }
%sollang.struct.m52_s22 = type { i64, i64 }
%sollang.struct.m54_s3 = type { i32, i32 }
%sollang.struct.m54_s0 = type { %sollang.enum.t747, i64 }
%sollang.struct.m54_s6 = type { %sollang.enum.t748 }
%sollang.struct.m57_s20 = type { i32, %sollang.enum.t756 }
%sollang.struct.m57_s17 = type { %sollang.enum.t755, i32 }
%sollang.struct.m57_s0 = type { i32, i32, i32, i32, %sollang.enum.t754 }
%sollang.struct.m83_s5 = type { i32 }
%sollang.struct.m74_s0 = type { %sollang.enum.t329, i64 }
%sollang.struct.m74_s13 = type { %sollang.array.i32, %sollang.struct.m82_s12 }
%sollang.struct.m74_s63 = type { i32, %sollang.struct.m82_s12 }
%sollang.struct.m82_s15 = type { i32, %sollang.struct.m82_s12 }
%sollang.struct.m74_s28 = type { %sollang.struct.m75_s168, %sollang.struct.m83_s5, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32, i32, %sollang.enum.t811, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.t811 }
%sollang.struct.m74_s58 = type { %sollang.array.i32 }
%sollang.struct.m75_s159 = type { i32, i32, %sollang.enum.t847, %sollang.enum.t847 }
%sollang.struct.m82_s9 = type { %sollang.array.i32, i32 }
%sollang.struct.m74_s3 = type { i32, i32, i32 }
%sollang.struct.m81_s6 = type { %sollang.struct.m82_s6, i32 }
%sollang.struct.m77_s7 = type { %sollang.struct.m81_s6, i32, i32 }
%sollang.struct.m85_s8 = type { %sollang.struct.m81_s6, i32, i32, i32 }
%sollang.struct.m75_s49 = type { i32, i32, i32, i32, i32, %sollang.enum.t844, i32, i32 }
%sollang.struct.m75_s76 = type { %sollang.struct.m81_s6, i32, i32, %sollang.enum.t846, i32, i32, i32, i32, %sollang.enum.t847, %sollang.enum.t847 }
%sollang.struct.m75_s111 = type { %sollang.array.i32, i32, i32, i32, %sollang.array.i32, i32 }
%sollang.struct.m77_s29 = type { %sollang.struct.m81_s6, i32, i32, i32, %sollang.enum.t922, i32, i32, i32, %sollang.array.i32, %sollang.enum.t923 }
%sollang.struct.m75_s134 = type { %sollang.array.i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32, i32 }
%sollang.struct.m85_s16 = type { %sollang.struct.m81_s6, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.array.i32 }
%sollang.struct.m75_s0 = type { %sollang.enum.t328, i64 }
%sollang.struct.m75_s180 = type { i32, %sollang.struct.m82_s12 }
%sollang.struct.m75_s183 = type { %sollang.struct.m75_s159, %sollang.struct.m82_s12 }
%sollang.struct.m81_s35 = type { %sollang.struct.m82_s6, i32, i32, i32, %sollang.enum.t943, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.struct.m81_s17, %sollang.array.i32, i32, i32, i32, %sollang.enum.t945, i32, i32, i32, i32, i32, i32, %sollang.enum.t945 }
%sollang.struct.m75_s97 = type { %sollang.struct.m75_s10, %sollang.struct.m75_s76, %sollang.enum.t849, i32, %sollang.array.i32, i32, i32, %sollang.array.i32 }
%sollang.struct.m75_s122 = type { %sollang.struct.m75_s111, %sollang.struct.m77_s29, %sollang.enum.t852, %sollang.array.i32, %sollang.array.i32, i32, i32 }
%sollang.struct.m75_s149 = type { %sollang.struct.m75_s134, %sollang.struct.m85_s16, %sollang.enum.t855, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.m75_s164 = type { i32, i32, %sollang.struct.m82_s12 }
%sollang.struct.m81_s9 = type { %sollang.struct.m82_s9, %sollang.struct.m82_s12 }
%sollang.struct.m77_s11 = type { %sollang.array.i32, i32, %sollang.struct.m82_s12 }
%sollang.struct.m85_s13 = type { %sollang.array.i32, %sollang.struct.m82_s12 }
%sollang.struct.m75_s34 = type { %sollang.enum.t843, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.t844, i32, i32 }
%sollang.struct.m75_s3 = type { i32, i32, i32, i32, i32, i32 }
%sollang.struct.m76_s7 = type { %sollang.struct.m75_s97, %sollang.struct.m81_s35 }
%sollang.struct.m76_s10 = type { %sollang.struct.m75_s122, %sollang.struct.m81_s35 }
%sollang.struct.m76_s13 = type { %sollang.struct.m75_s149, %sollang.struct.m81_s35 }
%sollang.struct.m76_s3 = type { i32, i32, i32 }
%sollang.struct.m76_s0 = type { %sollang.enum.t317, i64 }
%sollang.struct.m77_s0 = type { %sollang.enum.t871, i64 }
%sollang.struct.m77_s50 = type { i32, %sollang.struct.m82_s12 }
%sollang.struct.m77_s44 = type { %sollang.array.i32, i32 }
%sollang.struct.m77_s3 = type { i32, i32, i32 }
%sollang.struct.m82_s6 = type { i32, i32 }
%sollang.struct.m81_s17 = type { %sollang.enum.t942, i32 }
%sollang.struct.m81_s0 = type { %sollang.enum.t870, i64 }
%sollang.struct.m81_s62 = type { i32, %sollang.struct.m82_s12 }
%sollang.struct.m81_s3 = type { i32, i32 }
%sollang.struct.m82_s18 = type { i32, i32 }
%sollang.struct.m82_s0 = type { %sollang.enum.t819, i64 }
%sollang.struct.m82_s33 = type { i32, i32 }
%sollang.struct.m82_s3 = type { i32, i32 }
%sollang.struct.m82_s24 = type { i32 }
%sollang.struct.m83_s0 = type { %sollang.enum.t820, i64 }
%sollang.struct.m83_s29 = type { i32, %sollang.enum.t973, i32 }
%sollang.struct.m83_s3 = type { i32 }
%sollang.struct.m85_s0 = type { %sollang.enum.t872, i64 }
%sollang.struct.m85_s30 = type { %sollang.array.i32 }
%sollang.struct.m85_s3 = type { i32, i32, i32, i32 }
%sollang.struct.m90_s7 = type { %sollang.struct.m90_s2, i32 }
%sollang.struct.m90_s12 = type { i32, i32, i32 }
%sollang.struct.m90_s10 = type { i32 }
%sollang.struct.m91_s5 = type { %sollang.struct.m91_s2, i32 }
%sollang.struct.m92_s9 = type { %sollang.struct.m90_s2, %sollang.struct.m90_s2, %sollang.struct.m90_s2, i1, i1, i1, i32, i32, i32, i32 }
%sollang.struct.m92_s24 = type { %sollang.array.i32, %sollang.struct.m90_s2, %sollang.struct.m90_s2, %sollang.struct.m90_s2, i1, i1, i1, i32, i32, i32 }
%sollang.struct.m92_s6 = type { i32, i32 }
%sollang.struct.m92_s20 = type { i32, i32, i32 }
%sollang.struct.m97_s0 = type { i32, i32, i32, i32, i32 }
%sollang.struct.m97_s6 = type { %sollang.struct.m97_s0 }
%sollang.struct.m97_s17 = type { %sollang.enum.t1018, %sollang.struct.m97_s0 }
%sollang.struct.m97_s42 = type { %sollang.struct.m97_s0, %sollang.enum.t1019, %sollang.enum.t1020, i64, i64, i64, i64, %sollang.array.i32, i1, i64, i32 }
%sollang.struct.m97_s20 = type { i64, i64, i1 }
%sollang.struct.m97_s54 = type { i1, i64, i1, i1 }
%sollang.struct.m97_s8 = type { %sollang.struct.m97_s6, %sollang.text }
%sollang.struct.m98_s15 = type { %sollang.struct.m48_s9, %sollang.struct.m45_s18, %sollang.struct.m97_s6, i32, i32 }
%sollang.struct.m98_s21 = type { %sollang.struct.m48_s9, %sollang.struct.m45_s18, %sollang.struct.m97_s6, i32, i32, %sollang.enum.t1036, %sollang.enum.t1037 }
%sollang.struct.m98_s29 = type { %sollang.struct.m48_s9, %sollang.struct.m45_s18, %sollang.struct.m97_s6, i32, i32, %sollang.enum.t1036, %sollang.enum.t1037, %sollang.array.i32, %sollang.struct.m45_s27, i64 }
%sollang.struct.m98_s0 = type { %sollang.enum.t139, %sollang.struct.m45_s18, %sollang.struct.m97_s6, i32, i32 }
%sollang.struct.m100_s31 = type { %sollang.array.i32, i64, %sollang.enum.t1037, %sollang.enum.t1036 }
%sollang.struct.m98_s40 = type { %sollang.struct.m48_s9, %sollang.struct.m45_s18, %sollang.struct.m97_s6, i32, i32, %sollang.array.i32, i64, %sollang.array.i32, i64, %sollang.struct.m97_s42, i1, i1, i1 }
%sollang.struct.m100_s0 = type { i32, i32, i32, i32 }
%sollang.struct.m100_s5 = type { %sollang.struct.m100_s0 }
%sollang.struct.m100_s19 = type { %sollang.struct.m100_s0, %sollang.array.i32, %sollang.text, i32, i32, i1, i1, i1, i64, %sollang.enum.t1037, %sollang.enum.t1036 }
%sollang.struct.m101_s0 = type { i32, i32, i32, i32 }
%sollang.struct.m101_s5 = type { %sollang.struct.m101_s0 }
%sollang.struct.m101_s14 = type { %sollang.struct.m101_s0, %sollang.array.i32, i32, i32, i1, i1, i1, i64, %sollang.enum.t1064 }
%sollang.struct.m101_s24 = type { %sollang.array.i32, i64, %sollang.enum.t1064, %sollang.enum.t1065 }
%sollang.struct.m102_s17 = type { %sollang.struct.m48_s9, %sollang.struct.m45_s18, i32, %sollang.array.i32, i64 }
%sollang.struct.m102_s26 = type { %sollang.struct.m48_s9, %sollang.struct.m45_s18, i32, %sollang.array.i32, %sollang.struct.m45_s20, i64, %sollang.array.i32, i64, i1 }
%sollang.struct.m102_s0 = type { %sollang.struct.m48_s0, %sollang.struct.m45_s6 }
%sollang.struct.m102_s13 = type { %sollang.struct.m48_s7, %sollang.struct.m45_s18, i32 }
%sollang.struct.m102_s36 = type { %sollang.struct.m48_s9, %sollang.struct.m45_s18, i32, %sollang.array.i32, %sollang.struct.m45_s20, i64, %sollang.array.i32, i64, %sollang.struct.m97_s42 }
%sollang.struct.m127_s0 = type { %sollang.struct.m113_s33 }
%sollang.struct.m103_s5 = type { i64, i1, %sollang.enum.t593 }
%sollang.struct.m118_s28 = type { i64, i64 }
%sollang.struct.m104_s0 = type { i1, i1, i1, %sollang.struct.m118_s22, %sollang.struct.m118_s28 }
%sollang.struct.m105_s0 = type { i64, i8 }
%sollang.struct.m105_s3 = type { %sollang.array.i32, i64 }
%sollang.struct.m105_s6 = type { %sollang.array.i32, i64 }
%sollang.struct.m105_s9 = type { %sollang.array.i32, i64 }
%sollang.struct.m105_s12 = type { i64, %sollang.array.i32 }
%sollang.struct.m107_s39 = type { i64, i64 }
%sollang.struct.m107_s0 = type { i64, %sollang.array.i32 }
%sollang.struct.m107_s20 = type { i1, i64 }
%sollang.struct.m107_s23 = type { i64, i64 }
%sollang.struct.m107_s26 = type { i1, i64 }
%sollang.struct.m107_s34 = type { i64, i64, %sollang.array.i32, %sollang.int_slice }
%sollang.struct.m107_s29 = type { i1, i64, i64, %sollang.array.i32 }
%sollang.struct.m107_s66 = type { %sollang.enum.t593, i64 }
%sollang.struct.m110_s0 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.m112_s0 = type { %sollang.int_slice }
%sollang.struct.m112_s2 = type { %sollang.struct.m47_s3, %sollang.int_slice, %sollang.struct.m112_s0 }
%sollang.struct.m112_s6 = type { %sollang.struct.m112_s0, %sollang.int_slice, %sollang.struct.m3_s5, i64, %sollang.array.i32, %sollang.int_slice }
%sollang.struct.m112_s19 = type { %sollang.struct.m112_s0, %sollang.struct.m47_s87 }
%sollang.struct.m112_s13 = type { %sollang.struct.m47_s30, %sollang.struct.m47_s87, %sollang.struct.m112_s0 }
%sollang.struct.m112_s17 = type { %sollang.array.i32 }
%sollang.struct.m116_s9 = type { %sollang.struct.m22_s3, %sollang.int_slice }
%sollang.struct.m116_s7 = type { %sollang.struct.m21_s2 }
%sollang.struct.m113_s33 = type { %sollang.struct.m116_s9, %sollang.struct.m116_s7 }
%sollang.struct.m114_s0 = type { i32, i64 }
%sollang.struct.m113_s7 = type { i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i64, i64 }
%sollang.struct.m113_s19 = type { i32, %sollang.array.i32, %sollang.array.i32, i64, i64 }
%sollang.struct.m113_s29 = type { i8, i64, %sollang.array.i32 }
%sollang.struct.m113_s25 = type { i1, i64, %sollang.array.i32 }
%sollang.struct.m113_s2 = type { i32, i64, %sollang.array.i32, i64 }
%sollang.struct.m113_s14 = type { i32, i64, %sollang.array.i32, i64 }
%sollang.struct.m115_s0 = type { i64, i64, i64, i1, i1 }
%sollang.struct.m115_s6 = type { %sollang.struct.m111_s0, %sollang.struct.m111_s6, i64, i64, i64, i64 }
%sollang.struct.m116_s4 = type { %sollang.int_slice, %sollang.int_slice }
%sollang.struct.m116_s0 = type { %sollang.int_slice }
%sollang.struct.m116_s2 = type { %sollang.int_slice }
%sollang.struct.m117_s0 = type { %sollang.struct.m118_s11, i64 }
%sollang.struct.m118_s6 = type { i64, i64, %sollang.enum.t1169, %sollang.enum.t1170 }
%sollang.struct.m119_s0 = type { %sollang.array.i32 }
%sollang.struct.m119_s2 = type { i16, %sollang.array.i32 }
%sollang.struct.m126_s0 = type { %sollang.array.i32 }
%sollang.struct.m122_s0 = type { i8, %sollang.array.i32, i64 }
%sollang.struct.m122_s4 = type { i16, %sollang.array.i32, i64 }
%sollang.struct.m128_s4 = type { i64 }
%sollang.struct.m129_s0 = type { i64, i64 }
%sollang.struct.m131_s0 = type { %sollang.array.i32, %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.m132_s0 = type { i8, i64, i64, i64 }
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture)
%sollang.dyn = type { ptr, ptr }
%sollang.mutable_container = type { ptr, ptr, ptr }
%sollang.int_slice = type { ptr, i64 }
%sollang.array.i32 = type { ptr, i64, i64 }
define internal void @sollang_drop_t112(%sollang.array.i32 %value) {
entry:
  %data = extractvalue %sollang.array.i32 %value, 0
  %length = extractvalue %sollang.array.i32 %value, 1
  call void @sollang_free(ptr %data)
  ret void
}
define internal void @sollang_drop_t410(%sollang.struct.m21_s2 %value) {
entry:
  %field0 = extractvalue %sollang.struct.m21_s2 %value, 0
  call void @sollang_drop_t112(%sollang.array.i32 %field0)
  ret void
}
define internal void @sollang_drop_t411(%sollang.struct.m21_s4 %value) {
entry:
  %field0 = extractvalue %sollang.struct.m21_s4 %value, 0
  %field_data0 = extractvalue %sollang.int_slice %field0, 0
  call void @sollang_free(ptr %field_data0)
  ret void
}
declare void @llvm.trap()
declare dllimport void @ExitProcess(i32)
@sollang_str_7763 = private unnamed_addr constant [0 x i8] c""
@sollang_str_7791 = private unnamed_addr constant [0 x i8] c""
@sollang_str_7795 = private unnamed_addr constant [0 x i8] c""
@sollang_str_7799 = private unnamed_addr constant [0 x i8] c""
@sollang_str_7921 = private unnamed_addr constant [1 x i8] c"0"
@sollang_str_7926 = private unnamed_addr constant [1 x i8] c"1"
@sollang_str_7931 = private unnamed_addr constant [1 x i8] c"2"
@sollang_str_7936 = private unnamed_addr constant [1 x i8] c"3"
@sollang_str_7941 = private unnamed_addr constant [1 x i8] c"4"
@sollang_str_7946 = private unnamed_addr constant [1 x i8] c"5"
@sollang_str_7951 = private unnamed_addr constant [1 x i8] c"6"
@sollang_str_7956 = private unnamed_addr constant [1 x i8] c"7"
@sollang_str_7961 = private unnamed_addr constant [1 x i8] c"8"
@sollang_str_7966 = private unnamed_addr constant [1 x i8] c"9"
@sollang_str_7971 = private unnamed_addr constant [1 x i8] c"a"
@sollang_str_7976 = private unnamed_addr constant [1 x i8] c"b"
@sollang_str_7981 = private unnamed_addr constant [1 x i8] c"c"
@sollang_str_7986 = private unnamed_addr constant [1 x i8] c"d"
@sollang_str_7991 = private unnamed_addr constant [1 x i8] c"e"
@sollang_str_7993 = private unnamed_addr constant [1 x i8] c"f"
@sollang_str_8961 = private unnamed_addr constant [1296 x i8] c"$((Int(self.bytes[0]) / 16) -> hexDigit)$((Int(self.bytes[0]) % 16) -> hexDigit)$((Int(self.bytes[1]) / 16) -> hexDigit)$((Int(self.bytes[1]) % 16) -> hexDigit)$((Int(self.bytes[2]) / 16) -> hexDigit)$((Int(self.bytes[2]) % 16) -> hexDigit)$((Int(self.bytes[3]) / 16) -> hexDigit)$((Int(self.bytes[3]) % 16) -> hexDigit)-$((Int(self.bytes[4]) / 16) -> hexDigit)$((Int(self.bytes[4]) % 16) -> hexDigit)$((Int(self.bytes[5]) / 16) -> hexDigit)$((Int(self.bytes[5]) % 16) -> hexDigit)-$((Int(self.bytes[6]) / 16) -> hexDigit)$((Int(self.bytes[6]) % 16) -> hexDigit)$((Int(self.bytes[7]) / 16) -> hexDigit)$((Int(self.bytes[7]) % 16) -> hexDigit)-$((Int(self.bytes[8]) / 16) -> hexDigit)$((Int(self.bytes[8]) % 16) -> hexDigit)$((Int(self.bytes[9]) / 16) -> hexDigit)$((Int(self.bytes[9]) % 16) -> hexDigit)-$((Int(self.bytes[10]) / 16) -> hexDigit)$((Int(self.bytes[10]) % 16) -> hexDigit)$((Int(self.bytes[11]) / 16) -> hexDigit)$((Int(self.bytes[11]) % 16) -> hexDigit)$((Int(self.bytes[12]) / 16) -> hexDigit)$((Int(self.bytes[12]) % 16) -> hexDigit)$((Int(self.bytes[13]) / 16) -> hexDigit)$((Int(self.bytes[13]) % 16) -> hexDigit)$((Int(self.bytes[14]) / 16) -> hexDigit)$((Int(self.bytes[14]) % 16) -> hexDigit)$((Int(self.bytes[15]) / 16) -> hexDigit)$((Int(self.bytes[15]) % 16) -> hexDigit)"
@sollang_str_9112 = private unnamed_addr constant [2 x i8] c"io"
@sollang_str_9447 = private unnamed_addr constant [2 x i8] c"io"
@sollang_str_9821 = private unnamed_addr constant [23 x i8] c"path is not valid UTF-8"
@sollang_str_10155 = private unnamed_addr constant [19 x i8] c"absolute child path"
@sollang_str_10379 = private unnamed_addr constant [18 x i8] c"path styles differ"
@sollang_str_10387 = private unnamed_addr constant [29 x i8] c"cannot join an absolute child"
@sollang_str_10428 = private unnamed_addr constant [18 x i8] c"path styles differ"
@sollang_str_10770 = private unnamed_addr constant [17 x i8] c"path contains NUL"
@sollang_str_10824 = private unnamed_addr constant [20 x i8] c"invalid drive prefix"
@sollang_str_10917 = private unnamed_addr constant [26 x i8] c"unsupported path namespace"
@sollang_str_10947 = private unnamed_addr constant [26 x i8] c"unsupported path namespace"
@sollang_str_10972 = private unnamed_addr constant [16 x i8] c"invalid UNC path"
@sollang_str_11279 = private unnamed_addr constant [17 x i8] c"path escapes root"
@sollang_str_11292 = private unnamed_addr constant [19 x i8] c"incomplete UNC path"
@sollang_str_11326 = private unnamed_addr constant [0 x i8] c""
@sollang_str_11402 = private unnamed_addr constant [0 x i8] c""
@sollang_str_35993 = private unnamed_addr constant [10 x i8] c"ext binder"
@sollang_str_36001 = private unnamed_addr constant [10 x i8] c"res binder"
@sollang_str_36037 = private unnamed_addr constant [11 x i8] c"c e traffic"
@sollang_str_36041 = private unnamed_addr constant [12 x i8] c"e exp master"
@sollang_str_36078 = private unnamed_addr constant [7 x i8] c"derived"
@sollang_str_36085 = private unnamed_addr constant [12 x i8] c"c hs traffic"
@sollang_str_36089 = private unnamed_addr constant [12 x i8] c"s hs traffic"
@sollang_str_36093 = private unnamed_addr constant [7 x i8] c"derived"
@sollang_str_36152 = private unnamed_addr constant [12 x i8] c"c ap traffic"
@sollang_str_36156 = private unnamed_addr constant [12 x i8] c"s ap traffic"
@sollang_str_36160 = private unnamed_addr constant [10 x i8] c"exp master"
@sollang_str_36187 = private unnamed_addr constant [10 x i8] c"res master"
@sollang_str_36197 = private unnamed_addr constant [8 x i8] c"finished"
@sollang_str_36226 = private unnamed_addr constant [11 x i8] c"traffic upd"
@sollang_str_42021 = private unnamed_addr constant [8 x i8] c"HTTP/1.0"
@sollang_str_42031 = private unnamed_addr constant [8 x i8] c"HTTP/1.1"
@sollang_str_50954 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_50965 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_50989 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_52450 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_52503 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_52556 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_55478 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_55489 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_55493 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_55767 = private unnamed_addr constant [6 x i8] c"$value"
@sollang_str_55774 = private unnamed_addr constant [6 x i8] c"$value"
@sollang_str_56104 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_56143 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_56148 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_58433 = private unnamed_addr constant [4 x i8] c"wait"
@sollang_str_58474 = private unnamed_addr constant [4 x i8] c"wait"
@sollang_str_58522 = private unnamed_addr constant [6 x i8] c"signal"
@sollang_str_58543 = private unnamed_addr constant [4 x i8] c"kill"
@sollang_str_94363 = private unnamed_addr constant [7 x i8] c"chunked"
@sollang_str_94445 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_94478 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_94913 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_94918 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_95117 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_95142 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_95927 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_95934 = private unnamed_addr constant [5 x i8] c"close"
@sollang_str_95955 = private unnamed_addr constant [10 x i8] c"keep-alive"
@sollang_str_96390 = private unnamed_addr constant [3 x i8] c"GET"
@sollang_str_96397 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_96404 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_97054 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_97062 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_97155 = private unnamed_addr constant [4 x i8] c"Host"
@sollang_str_97158 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_97161 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_97164 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_97167 = private unnamed_addr constant [7 x i8] c"Trailer"
@sollang_str_97206 = private unnamed_addr constant [8 x i8] c"HTTP/1.0"
@sollang_str_97212 = private unnamed_addr constant [8 x i8] c"HTTP/1.1"
@sollang_str_97369 = private unnamed_addr constant [2 x i8] c": "
@sollang_str_97375 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_97382 = private unnamed_addr constant [16 x i8] c"Content-Length: "
@sollang_str_97388 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_97900 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_97958 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_98137 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_98169 = private unnamed_addr constant [7 x i8] c"OPTIONS"
@sollang_str_98361 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_98621 = private unnamed_addr constant [4 x i8] c"Host"
@sollang_str_98636 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_98637 = private unnamed_addr constant [5 x i8] c"close"
@sollang_str_98644 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_98645 = private unnamed_addr constant [10 x i8] c"keep-alive"
@sollang_str_98648 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_98906 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_98909 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_98912 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_98915 = private unnamed_addr constant [7 x i8] c"Trailer"
@sollang_str_98953 = private unnamed_addr constant [8 x i8] c"HTTP/1.0"
@sollang_str_98959 = private unnamed_addr constant [8 x i8] c"HTTP/1.1"
@sollang_str_99089 = private unnamed_addr constant [2 x i8] c": "
@sollang_str_99095 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_99102 = private unnamed_addr constant [16 x i8] c"Content-Length: "
@sollang_str_99108 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_99247 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_99261 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_99407 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_99673 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_99674 = private unnamed_addr constant [5 x i8] c"close"
@sollang_str_99681 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_99682 = private unnamed_addr constant [10 x i8] c"keep-alive"
@sollang_str_99685 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_104594 = private unnamed_addr constant [9 x i8] c"client in"
@sollang_str_104598 = private unnamed_addr constant [9 x i8] c"server in"
@sollang_str_104606 = private unnamed_addr constant [10 x i8] c"quicv2 key"
@sollang_str_104608 = private unnamed_addr constant [8 x i8] c"quic key"
@sollang_str_104615 = private unnamed_addr constant [9 x i8] c"quicv2 iv"
@sollang_str_104617 = private unnamed_addr constant [7 x i8] c"quic iv"
@sollang_str_104624 = private unnamed_addr constant [9 x i8] c"quicv2 hp"
@sollang_str_104626 = private unnamed_addr constant [7 x i8] c"quic hp"
@sollang_str_115485 = private unnamed_addr constant [10 x i8] c"quicv2 key"
@sollang_str_115487 = private unnamed_addr constant [8 x i8] c"quic key"
@sollang_str_115494 = private unnamed_addr constant [9 x i8] c"quicv2 iv"
@sollang_str_115496 = private unnamed_addr constant [7 x i8] c"quic iv"
@sollang_str_115503 = private unnamed_addr constant [9 x i8] c"quicv2 hp"
@sollang_str_115505 = private unnamed_addr constant [7 x i8] c"quic hp"
@sollang_str_118235 = private unnamed_addr constant [9 x i8] c"aes128=ok"
@sollang_str_118237 = private unnamed_addr constant [13 x i8] c"aes128=failed"
define %sollang.int_slice @sollang_m144_s0() {
entry:
  %heap_v118107 = call ptr @sollang_alloc(i64 16)
  %v118107_data = getelementptr i8, ptr %heap_v118107, i64 0
  %v118107_allocation_ok = icmp ne ptr %v118107_data, null
  br i1 %v118107_allocation_ok, label %v118107_allocation_ready, label %v118107_allocation_failed
v118107_allocation_failed:
  %v118107_allocation_diagnostic = alloca [22 x i8], align 1
  store [22 x i8] c"\2E\6B\65\79\3A\61\6C\6C\6F\63\61\74\69\6F\6E\5F\66\61\69\6C\65\64", ptr %v118107_allocation_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v118107_allocation_diagnostic, i64 22, i1 false)
  call void @llvm.trap()
  unreachable
v118107_allocation_ready:
  %v118107_ptr0 = getelementptr i8, ptr %v118107_data, i64 0
  store i8 0, ptr %v118107_ptr0, align 1
  %v118107_ptr1 = getelementptr i8, ptr %v118107_data, i64 1
  store i8 1, ptr %v118107_ptr1, align 1
  %v118107_ptr2 = getelementptr i8, ptr %v118107_data, i64 2
  store i8 2, ptr %v118107_ptr2, align 1
  %v118107_ptr3 = getelementptr i8, ptr %v118107_data, i64 3
  store i8 3, ptr %v118107_ptr3, align 1
  %v118107_ptr4 = getelementptr i8, ptr %v118107_data, i64 4
  store i8 4, ptr %v118107_ptr4, align 1
  %v118107_ptr5 = getelementptr i8, ptr %v118107_data, i64 5
  store i8 5, ptr %v118107_ptr5, align 1
  %v118107_ptr6 = getelementptr i8, ptr %v118107_data, i64 6
  store i8 6, ptr %v118107_ptr6, align 1
  %v118107_ptr7 = getelementptr i8, ptr %v118107_data, i64 7
  store i8 7, ptr %v118107_ptr7, align 1
  %v118107_ptr8 = getelementptr i8, ptr %v118107_data, i64 8
  store i8 8, ptr %v118107_ptr8, align 1
  %v118107_ptr9 = getelementptr i8, ptr %v118107_data, i64 9
  store i8 9, ptr %v118107_ptr9, align 1
  %v118107_ptr10 = getelementptr i8, ptr %v118107_data, i64 10
  store i8 10, ptr %v118107_ptr10, align 1
  %v118107_ptr11 = getelementptr i8, ptr %v118107_data, i64 11
  store i8 11, ptr %v118107_ptr11, align 1
  %v118107_ptr12 = getelementptr i8, ptr %v118107_data, i64 12
  store i8 12, ptr %v118107_ptr12, align 1
  %v118107_ptr13 = getelementptr i8, ptr %v118107_data, i64 13
  store i8 13, ptr %v118107_ptr13, align 1
  %v118107_ptr14 = getelementptr i8, ptr %v118107_data, i64 14
  store i8 14, ptr %v118107_ptr14, align 1
  %v118107_ptr15 = getelementptr i8, ptr %v118107_data, i64 15
  store i8 15, ptr %v118107_ptr15, align 1
  %v118107_0 = insertvalue %sollang.int_slice poison, ptr %v118107_data, 0
  %v118107 = insertvalue %sollang.int_slice %v118107_0, i64 16, 1
  ret %sollang.int_slice %v118107
}
define %sollang.int_slice @sollang_m144_s1() {
entry:
  %heap_v118126 = call ptr @sollang_alloc(i64 16)
  %v118126_data = getelementptr i8, ptr %heap_v118126, i64 0
  %v118126_allocation_ok = icmp ne ptr %v118126_data, null
  br i1 %v118126_allocation_ok, label %v118126_allocation_ready, label %v118126_allocation_failed
v118126_allocation_failed:
  %v118126_allocation_diagnostic = alloca [24 x i8], align 1
  store [24 x i8] c"\2E\69\6E\70\75\74\3A\61\6C\6C\6F\63\61\74\69\6F\6E\5F\66\61\69\6C\65\64", ptr %v118126_allocation_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v118126_allocation_diagnostic, i64 24, i1 false)
  call void @llvm.trap()
  unreachable
v118126_allocation_ready:
  %v118126_ptr0 = getelementptr i8, ptr %v118126_data, i64 0
  store i8 0, ptr %v118126_ptr0, align 1
  %v118126_ptr1 = getelementptr i8, ptr %v118126_data, i64 1
  store i8 17, ptr %v118126_ptr1, align 1
  %v118126_ptr2 = getelementptr i8, ptr %v118126_data, i64 2
  store i8 34, ptr %v118126_ptr2, align 1
  %v118126_ptr3 = getelementptr i8, ptr %v118126_data, i64 3
  store i8 51, ptr %v118126_ptr3, align 1
  %v118126_ptr4 = getelementptr i8, ptr %v118126_data, i64 4
  store i8 68, ptr %v118126_ptr4, align 1
  %v118126_ptr5 = getelementptr i8, ptr %v118126_data, i64 5
  store i8 85, ptr %v118126_ptr5, align 1
  %v118126_ptr6 = getelementptr i8, ptr %v118126_data, i64 6
  store i8 102, ptr %v118126_ptr6, align 1
  %v118126_ptr7 = getelementptr i8, ptr %v118126_data, i64 7
  store i8 119, ptr %v118126_ptr7, align 1
  %v118126_ptr8 = getelementptr i8, ptr %v118126_data, i64 8
  store i8 136, ptr %v118126_ptr8, align 1
  %v118126_ptr9 = getelementptr i8, ptr %v118126_data, i64 9
  store i8 153, ptr %v118126_ptr9, align 1
  %v118126_ptr10 = getelementptr i8, ptr %v118126_data, i64 10
  store i8 170, ptr %v118126_ptr10, align 1
  %v118126_ptr11 = getelementptr i8, ptr %v118126_data, i64 11
  store i8 187, ptr %v118126_ptr11, align 1
  %v118126_ptr12 = getelementptr i8, ptr %v118126_data, i64 12
  store i8 204, ptr %v118126_ptr12, align 1
  %v118126_ptr13 = getelementptr i8, ptr %v118126_data, i64 13
  store i8 221, ptr %v118126_ptr13, align 1
  %v118126_ptr14 = getelementptr i8, ptr %v118126_data, i64 14
  store i8 238, ptr %v118126_ptr14, align 1
  %v118126_ptr15 = getelementptr i8, ptr %v118126_data, i64 15
  store i8 255, ptr %v118126_ptr15, align 1
  %v118126_0 = insertvalue %sollang.int_slice poison, ptr %v118126_data, 0
  %v118126 = insertvalue %sollang.int_slice %v118126_0, i64 16, 1
  ret %sollang.int_slice %v118126
}
@sollang_static_array_m21_s0_v29650 = private unnamed_addr constant [256 x i8] [i8 99, i8 124, i8 119, i8 123, i8 242, i8 107, i8 111, i8 197, i8 48, i8 1, i8 103, i8 43, i8 254, i8 215, i8 171, i8 118, i8 202, i8 130, i8 201, i8 125, i8 250, i8 89, i8 71, i8 240, i8 173, i8 212, i8 162, i8 175, i8 156, i8 164, i8 114, i8 192, i8 183, i8 253, i8 147, i8 38, i8 54, i8 63, i8 247, i8 204, i8 52, i8 165, i8 229, i8 241, i8 113, i8 216, i8 49, i8 21, i8 4, i8 199, i8 35, i8 195, i8 24, i8 150, i8 5, i8 154, i8 7, i8 18, i8 128, i8 226, i8 235, i8 39, i8 178, i8 117, i8 9, i8 131, i8 44, i8 26, i8 27, i8 110, i8 90, i8 160, i8 82, i8 59, i8 214, i8 179, i8 41, i8 227, i8 47, i8 132, i8 83, i8 209, i8 0, i8 237, i8 32, i8 252, i8 177, i8 91, i8 106, i8 203, i8 190, i8 57, i8 74, i8 76, i8 88, i8 207, i8 208, i8 239, i8 170, i8 251, i8 67, i8 77, i8 51, i8 133, i8 69, i8 249, i8 2, i8 127, i8 80, i8 60, i8 159, i8 168, i8 81, i8 163, i8 64, i8 143, i8 146, i8 157, i8 56, i8 245, i8 188, i8 182, i8 218, i8 33, i8 16, i8 255, i8 243, i8 210, i8 205, i8 12, i8 19, i8 236, i8 95, i8 151, i8 68, i8 23, i8 196, i8 167, i8 126, i8 61, i8 100, i8 93, i8 25, i8 115, i8 96, i8 129, i8 79, i8 220, i8 34, i8 42, i8 144, i8 136, i8 70, i8 238, i8 184, i8 20, i8 222, i8 94, i8 11, i8 219, i8 224, i8 50, i8 58, i8 10, i8 73, i8 6, i8 36, i8 92, i8 194, i8 211, i8 172, i8 98, i8 145, i8 149, i8 228, i8 121, i8 231, i8 200, i8 55, i8 109, i8 141, i8 213, i8 78, i8 169, i8 108, i8 86, i8 244, i8 234, i8 101, i8 122, i8 174, i8 8, i8 186, i8 120, i8 37, i8 46, i8 28, i8 166, i8 180, i8 198, i8 232, i8 221, i8 116, i8 31, i8 75, i8 189, i8 139, i8 138, i8 112, i8 62, i8 181, i8 102, i8 72, i8 3, i8 246, i8 14, i8 97, i8 53, i8 87, i8 185, i8 134, i8 193, i8 29, i8 158, i8 225, i8 248, i8 152, i8 17, i8 105, i8 217, i8 142, i8 148, i8 155, i8 30, i8 135, i8 233, i8 206, i8 85, i8 40, i8 223, i8 140, i8 161, i8 137, i8 13, i8 191, i8 230, i8 66, i8 104, i8 65, i8 153, i8 45, i8 15, i8 176, i8 84, i8 187, i8 22], align 1
define %sollang.int_slice @sollang_m21_s0() {
entry:
  %v29650_data = getelementptr [256 x i8], ptr @sollang_static_array_m21_s0_v29650, i64 0, i64 0
  %v29650_0 = insertvalue %sollang.int_slice poison, ptr %v29650_data, 0
  %v29650 = insertvalue %sollang.int_slice %v29650_0, i64 256, 1
  ret %sollang.int_slice %v29650
}
@sollang_static_array_m21_s1_v29909 = private unnamed_addr constant [10 x i8] [i8 1, i8 2, i8 4, i8 8, i8 16, i8 32, i8 64, i8 128, i8 27, i8 54], align 1
define %sollang.int_slice @sollang_m21_s1() {
entry:
  %v29909_data = getelementptr [10 x i8], ptr @sollang_static_array_m21_s1_v29909, i64 0, i64 0
  %v29909_0 = insertvalue %sollang.int_slice poison, ptr %v29909_data, 0
  %v29909 = insertvalue %sollang.int_slice %v29909_0, i64 10, 1
  ret %sollang.int_slice %v29909
}
define i8 @sollang_m21_s6(i8 %arg, i8 %arg1) {
entry:
  %v29929 = freeze i8 %arg1
  %v29926 = zext i8 %arg to i32
  %v29928 = zext i8 %arg1 to i32
  %v29925 = call i32 @sollang_m24_s6(i32 %v29926, i32 %v29928)
  %v29924_conversion_upper_valid = icmp ule i32 %v29925, 255
  br i1 %v29924_conversion_upper_valid, label %v29924_conversion_upper_ok, label %v29924_conversion_upper_fail
v29924_conversion_upper_fail:
  %v29924_conversion_upper_diagnostic = alloca [68 x i8], align 1
  store [68 x i8] c"\73\74\64\2E\63\72\79\70\74\6F\2E\61\65\73\31\32\38\2E\73\74\64\2E\63\72\79\70\74\6F\2E\61\65\73\31\32\38\2E\78\6F\72\42\79\74\65\3A\6E\75\6D\65\72\69\63\5F\63\6F\6E\76\65\72\73\69\6F\6E\5F\75\70\70\65\72", ptr %v29924_conversion_upper_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v29924_conversion_upper_diagnostic, i64 68, i1 false)
  call void @llvm.trap()
  unreachable
v29924_conversion_upper_ok:
  %v29924 = trunc i32 %v29925 to i8
  ret i8 %v29924
}
define i8 @sollang_m21_s8(i8 %arg) {
entry:
  %if29940_result = alloca i8, align 1
  %v29934 = zext i8 %arg to i32
  %v29938 = freeze i32 %v29934
  %v29937 = icmp ult i32 %v29938, 128
  br i1 %v29937, label %if29940_then, label %if29940_else
if29940_then:
  %v29944 = freeze i32 %v29934
  %v29943 = mul i32 %v29944, 2
  %v29942_conversion_upper_valid = icmp ule i32 %v29943, 255
  br i1 %v29942_conversion_upper_valid, label %v29942_conversion_upper_ok, label %v29942_conversion_upper_fail
v29942_conversion_upper_fail:
  %v29942_conversion_upper_diagnostic = alloca [66 x i8], align 1
  store [66 x i8] c"\73\74\64\2E\63\72\79\70\74\6F\2E\61\65\73\31\32\38\2E\73\74\64\2E\63\72\79\70\74\6F\2E\61\65\73\31\32\38\2E\78\74\69\6D\65\3A\6E\75\6D\65\72\69\63\5F\63\6F\6E\76\65\72\73\69\6F\6E\5F\75\70\70\65\72", ptr %v29942_conversion_upper_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v29942_conversion_upper_diagnostic, i64 66, i1 false)
  call void @llvm.trap()
  unreachable
v29942_conversion_upper_ok:
  %v29942 = trunc i32 %v29943 to i8
  store i8 %v29942, ptr %if29940_result, align 1
  br label %if29940_merge
if29940_else:
  %v29951 = freeze i32 %v29934
  %v29950 = mul i32 %v29951, 2
  %v29949 = urem i32 %v29950, 256
  %v29948 = call i32 @sollang_m24_s6(i32 %v29949, i32 27)
  %v29947_conversion_upper_valid = icmp ule i32 %v29948, 255
  br i1 %v29947_conversion_upper_valid, label %v29947_conversion_upper_ok, label %v29947_conversion_upper_fail
v29947_conversion_upper_fail:
  %v29947_conversion_upper_diagnostic = alloca [66 x i8], align 1
  store [66 x i8] c"\73\74\64\2E\63\72\79\70\74\6F\2E\61\65\73\31\32\38\2E\73\74\64\2E\63\72\79\70\74\6F\2E\61\65\73\31\32\38\2E\78\74\69\6D\65\3A\6E\75\6D\65\72\69\63\5F\63\6F\6E\76\65\72\73\69\6F\6E\5F\75\70\70\65\72", ptr %v29947_conversion_upper_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v29947_conversion_upper_diagnostic, i64 66, i1 false)
  call void @llvm.trap()
  unreachable
v29947_conversion_upper_ok:
  %v29947 = trunc i32 %v29948 to i8
  store i8 %v29947, ptr %if29940_result, align 1
  br label %if29940_merge
if29940_merge:
  %v29940 = load i8, ptr %if29940_result, align 1
  ret i8 %v29940
}
define i8 @sollang_m21_s10(i8 %arg) {
entry:
  %v29959 = call i8 @sollang_m21_s8(i8 %arg)
  %v29958 = call i8 @sollang_m21_s6(i8 %v29959, i8 %arg)
  ret i8 %v29958
}
define %sollang.array.i32 @sollang_m21_s11(%sollang.int_slice %arg) {
entry:
  %slot29965 = alloca %sollang.array.i32, align 8
  %slot29966 = alloca i32, align 4
  %slot29968 = alloca i32, align 4
  %slot29970 = alloca i32, align 4
  %slot29971 = alloca i32, align 4
  %slot29972 = alloca %sollang.int_slice, align 1
  %slot29973 = alloca i32, align 4
  %slot29977 = alloca i32, align 4
  %heap_v29980 = call ptr @sollang_alloc(i64 176)
  %v29980_data = getelementptr i8, ptr %heap_v29980, i64 0
  %v29980_allocation_ok = icmp ne ptr %v29980_data, null
  br i1 %v29980_allocation_ok, label %v29980_allocation_ready, label %v29980_allocation_failed
v29980_allocation_failed:
  %v29980_allocation_diagnostic = alloca [63 x i8], align 1
  store [63 x i8] c"\73\74\64\2E\63\72\79\70\74\6F\2E\61\65\73\31\32\38\2E\73\74\64\2E\63\72\79\70\74\6F\2E\61\65\73\31\32\38\2E\65\78\70\61\6E\64\4B\65\79\3A\61\6C\6C\6F\63\61\74\69\6F\6E\5F\66\61\69\6C\65\64", ptr %v29980_allocation_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v29980_allocation_diagnostic, i64 63, i1 false)
  call void @llvm.trap()
  unreachable
v29980_allocation_ready:
  %v29980_0 = insertvalue %sollang.array.i32 poison, ptr %v29980_data, 0
  %v29980_1 = insertvalue %sollang.array.i32 %v29980_0, i64 0, 1
  %v29980 = insertvalue %sollang.array.i32 %v29980_1, i64 176, 2
  store %sollang.array.i32 %v29980, ptr %slot29965, align 8
  store i32 0, ptr %slot29966, align 4
  store i32 0, ptr %slot29968, align 4
  store i32 16, ptr %slot29970, align 4
  store i32 0, ptr %slot29971, align 4
  br label %while29986_header
while29986_header:
  %while29986_v29984 = load i32, ptr %slot29966, align 4
  %while29986_v29983 = icmp slt i32 %while29986_v29984, 176
  br i1 %while29986_v29983, label %while29986_body, label %while29986_exit
while29986_body:
  %v29989 = load %sollang.array.i32, ptr %slot29965, align 8
  %push29988_data = extractvalue %sollang.array.i32 %v29989, 0
  %push29988_length = extractvalue %sollang.array.i32 %v29989, 1
  %push29988_capacity = extractvalue %sollang.array.i32 %v29989, 2
  %push29988_full = icmp eq i64 %push29988_length, %push29988_capacity
  %push29988_empty = icmp eq i64 %push29988_capacity, 0
  %push29988_doubled = mul i64 %push29988_capacity, 2
  %push29988_grown_capacity = select i1 %push29988_empty, i64 4, i64 %push29988_doubled
  %push29988_append_capacity = select i1 %push29988_full, i64 %push29988_grown_capacity, i64 %push29988_capacity
  %push29988_append_bytes = mul i64 %push29988_append_capacity, 1
  br i1 %push29988_full, label %push29988_grow, label %push29988_keep
push29988_keep:
  br label %push29988_ready
push29988_grow:
  %push29988_grown_data = call ptr @sollang_alloc(i64 %push29988_append_bytes)
  %push29988_allocated = icmp ne ptr %push29988_grown_data, null
  br i1 %push29988_allocated, label %push29988_copy, label %push29988_allocation_failed
push29988_allocation_failed:
  call void @llvm.trap()
  unreachable
push29988_copy:
  %push29988_copy_bytes = mul i64 %push29988_length, 1
  call void @llvm.memcpy.p0.p0.i64(ptr %push29988_grown_data, ptr %push29988_data, i64 %push29988_copy_bytes, i1 false)
  call void @sollang_free(ptr %push29988_data)
  br label %push29988_ready
push29988_ready:
  %push29988_append_data = phi ptr [ %push29988_data, %push29988_keep ], [ %push29988_grown_data, %push29988_copy ]
  %push29988_slot = getelementptr i8, ptr %push29988_append_data, i64 %push29988_length
  store i8 0, ptr %push29988_slot, align 1
  %push29988_new_length = add i64 %push29988_length, 1
  %push29988_array0 = insertvalue %sollang.array.i32 poison, ptr %push29988_append_data, 0
  %push29988_array1 = insertvalue %sollang.array.i32 %push29988_array0, i64 %push29988_new_length, 1
  %push29988_array2 = insertvalue %sollang.array.i32 %push29988_array1, i64 %push29988_append_capacity, 2
  store %sollang.array.i32 %push29988_array2, ptr %slot29965, align 8
  %v29992 = load i32, ptr %slot29966, align 4
  %v29991 = add i32 %v29992, 1
  store i32 %v29991, ptr %slot29966, align 4
  br label %while29986_header
while29986_exit:
  br label %while29999_header
while29999_header:
  %while29999_v29997 = load i32, ptr %slot29968, align 4
  %while29999_v29996 = icmp slt i32 %while29999_v29997, 16
  br i1 %while29999_v29996, label %while29999_body, label %while29999_exit
while29999_body:
  %v30004 = load i32, ptr %slot29968, align 4
  %v30005 = load i32, ptr %slot29968, align 4
  %v30002_data = extractvalue %sollang.int_slice %arg, 0
  %v30002_length = extractvalue %sollang.int_slice %arg, 1
  %v30002_index = sext i32 %v30004 to i64
  %v30002_in_bounds = icmp ult i64 %v30002_index, %v30002_length
  br i1 %v30002_in_bounds, label %v30002_index_ok, label %v30002_index_fail
v30002_index_fail:
  call void @llvm.trap()
  unreachable
v30002_index_ok:
  %v30002_ptr = getelementptr i8, ptr %v30002_data, i64 %v30002_index
  %v30002 = load i8, ptr %v30002_ptr, align 1
  %assign30001_array = load %sollang.array.i32, ptr %slot29965, align 8
  %assign30001_data = extractvalue %sollang.array.i32 %assign30001_array, 0
  %assign30001_index = sext i32 %v30005 to i64
  %assign30001_ptr = getelementptr i8, ptr %assign30001_data, i64 %assign30001_index
  store i8 %v30002, ptr %assign30001_ptr, align 1
  %v30007 = load i32, ptr %slot29968, align 4
  %v30006 = add i32 %v30007, 1
  store i32 %v30006, ptr %slot29968, align 4
  br label %while29999_header
while29999_exit:
  %v30012 = add i8 0, 0
  %heap_v30011 = call ptr @sollang_alloc(i64 4)
  %v30011_data = getelementptr i8, ptr %heap_v30011, i64 0
  %v30011_allocation_ok = icmp ne ptr %v30011_data, null
  br i1 %v30011_allocation_ok, label %v30011_allocation_ready, label %v30011_allocation_failed
v30011_allocation_failed:
  %v30011_allocation_diagnostic = alloca [63 x i8], align 1
  store [63 x i8] c"\73\74\64\2E\63\72\79\70\74\6F\2E\61\65\73\31\32\38\2E\73\74\64\2E\63\72\79\70\74\6F\2E\61\65\73\31\32\38\2E\65\78\70\61\6E\64\4B\65\79\3A\61\6C\6C\6F\63\61\74\69\6F\6E\5F\66\61\69\6C\65\64", ptr %v30011_allocation_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v30011_allocation_diagnostic, i64 63, i1 false)
  call void @llvm.trap()
  unreachable
v30011_allocation_ready:
  %v30011_ptr0 = getelementptr i8, ptr %v30011_data, i64 0
  store i8 %v30012, ptr %v30011_ptr0, align 1
  %v30011_ptr1 = getelementptr i8, ptr %v30011_data, i64 1
  store i8 %v30012, ptr %v30011_ptr1, align 1
  %v30011_ptr2 = getelementptr i8, ptr %v30011_data, i64 2
  store i8 %v30012, ptr %v30011_ptr2, align 1
  %v30011_ptr3 = getelementptr i8, ptr %v30011_data, i64 3
  store i8 %v30012, ptr %v30011_ptr3, align 1
  %v30011_0 = insertvalue %sollang.int_slice poison, ptr %v30011_data, 0
  %v30011 = insertvalue %sollang.int_slice %v30011_0, i64 4, 1
  store %sollang.int_slice %v30011, ptr %slot29972, align 1
  br label %while30018_header
while30018_header:
  %while30018_v30016 = load i32, ptr %slot29970, align 4
  %while30018_v30015 = icmp slt i32 %while30018_v30016, 176
  br i1 %while30018_v30015, label %while30018_body, label %while30018_exit
while30018_body:
  store i32 0, ptr %slot29973, align 4
  br label %while30025_header
while30025_header:
  %while30025_v30023 = load i32, ptr %slot29973, align 4
  %while30025_v30022 = icmp slt i32 %while30025_v30023, 4
  br i1 %while30025_v30022, label %while30025_body, label %while30025_exit
while30025_body:
  %v30029 = load %sollang.array.i32, ptr %slot29965, align 8
  %v30031 = load i32, ptr %slot29970, align 4
  %v30033 = load i32, ptr %slot29973, align 4
  %v30034 = load i32, ptr %slot29973, align 4
  %v30116 = sub i32 %v30031, 4
  %v30030 = add i32 %v30116, %v30033
  %v30028_data = extractvalue %sollang.array.i32 %v30029, 0
  %v30028_length = extractvalue %sollang.array.i32 %v30029, 1
  %v30028_index = sext i32 %v30030 to i64
  %v30028_in_bounds = icmp ult i64 %v30028_index, %v30028_length
  br i1 %v30028_in_bounds, label %v30028_index_ok, label %v30028_index_fail
v30028_index_fail:
  call void @llvm.trap()
  unreachable
v30028_index_ok:
  %v30028_ptr = getelementptr i8, ptr %v30028_data, i64 %v30028_index
  %v30028 = load i8, ptr %v30028_ptr, align 1
  %assign30027_array = load %sollang.int_slice, ptr %slot29972, align 8
  %assign30027_data = extractvalue %sollang.int_slice %assign30027_array, 0
  %assign30027_index = sext i32 %v30034 to i64
  %assign30027_ptr = getelementptr i8, ptr %assign30027_data, i64 %assign30027_index
  store i8 %v30028, ptr %assign30027_ptr, align 1
  %v30036 = load i32, ptr %slot29973, align 4
  %v30035 = add i32 %v30036, 1
  store i32 %v30035, ptr %slot29973, align 4
  br label %while30025_header
while30025_exit:
  %v30041 = load i32, ptr %slot29970, align 4
  %v30040 = srem i32 %v30041, 16
  %v30039 = icmp eq i32 %v30040, 0
  br i1 %v30039, label %if30044_then, label %if30044_merge
if30044_then:
  %v30047 = load %sollang.int_slice, ptr %slot29972, align 1
  %v30046_data = extractvalue %sollang.int_slice %v30047, 0
  %v30046_length = extractvalue %sollang.int_slice %v30047, 1
  %v30046_in_bounds = icmp ult i64 0, %v30046_length
  br i1 %v30046_in_bounds, label %v30046_index_ok, label %v30046_index_fail
v30046_index_fail:
  call void @llvm.trap()
  unreachable
v30046_index_ok:
  %v30046_ptr = getelementptr i8, ptr %v30046_data, i64 0
  %v30046 = load i8, ptr %v30046_ptr, align 1
  %v30051 = call %sollang.int_slice @sollang_m21_s0()
  %v30054 = load %sollang.int_slice, ptr %slot29972, align 1
  %v30053_data = extractvalue %sollang.int_slice %v30054, 0
  %v30053_length = extractvalue %sollang.int_slice %v30054, 1
  %v30053_in_bounds = icmp ult i64 1, %v30053_length
  br i1 %v30053_in_bounds, label %v30053_index_ok, label %v30053_index_fail
v30053_index_fail:
  call void @llvm.trap()
  unreachable
v30053_index_ok:
  %v30053_ptr = getelementptr i8, ptr %v30053_data, i64 1
  %v30053 = load i8, ptr %v30053_ptr, align 1
  %v30052 = zext i8 %v30053 to i32
  %v30050_data = extractvalue %sollang.int_slice %v30051, 0
  %v30050_length = extractvalue %sollang.int_slice %v30051, 1
  %v30050_index = sext i32 %v30052 to i64
  %v30050_in_bounds = icmp ult i64 %v30050_index, %v30050_length
  br i1 %v30050_in_bounds, label %v30050_index_ok, label %v30050_index_fail
v30050_index_fail:
  call void @llvm.trap()
  unreachable
v30050_index_ok:
  %v30050_ptr = getelementptr i8, ptr %v30050_data, i64 %v30050_index
  %v30050 = load i8, ptr %v30050_ptr, align 1
  %assign30049_array = load %sollang.int_slice, ptr %slot29972, align 8
  %assign30049_data = extractvalue %sollang.int_slice %assign30049_array, 0
  %assign30049_index = sext i32 0 to i64
  %assign30049_ptr = getelementptr i8, ptr %assign30049_data, i64 %assign30049_index
  store i8 %v30050, ptr %assign30049_ptr, align 1
  %v30059 = call %sollang.int_slice @sollang_m21_s0()
  %v30062 = load %sollang.int_slice, ptr %slot29972, align 1
  %v30061_data = extractvalue %sollang.int_slice %v30062, 0
  %v30061_length = extractvalue %sollang.int_slice %v30062, 1
  %v30061_in_bounds = icmp ult i64 2, %v30061_length
  br i1 %v30061_in_bounds, label %v30061_index_ok, label %v30061_index_fail
v30061_index_fail:
  call void @llvm.trap()
  unreachable
v30061_index_ok:
  %v30061_ptr = getelementptr i8, ptr %v30061_data, i64 2
  %v30061 = load i8, ptr %v30061_ptr, align 1
  %v30060 = zext i8 %v30061 to i32
  %v30058_data = extractvalue %sollang.int_slice %v30059, 0
  %v30058_length = extractvalue %sollang.int_slice %v30059, 1
  %v30058_index = sext i32 %v30060 to i64
  %v30058_in_bounds = icmp ult i64 %v30058_index, %v30058_length
  br i1 %v30058_in_bounds, label %v30058_index_ok, label %v30058_index_fail
v30058_index_fail:
  call void @llvm.trap()
  unreachable
v30058_index_ok:
  %v30058_ptr = getelementptr i8, ptr %v30058_data, i64 %v30058_index
  %v30058 = load i8, ptr %v30058_ptr, align 1
  %assign30057_array = load %sollang.int_slice, ptr %slot29972, align 8
  %assign30057_data = extractvalue %sollang.int_slice %assign30057_array, 0
  %assign30057_index = sext i32 1 to i64
  %assign30057_ptr = getelementptr i8, ptr %assign30057_data, i64 %assign30057_index
  store i8 %v30058, ptr %assign30057_ptr, align 1
  %v30067 = call %sollang.int_slice @sollang_m21_s0()
  %v30070 = load %sollang.int_slice, ptr %slot29972, align 1
  %v30069_data = extractvalue %sollang.int_slice %v30070, 0
  %v30069_length = extractvalue %sollang.int_slice %v30070, 1
  %v30069_in_bounds = icmp ult i64 3, %v30069_length
  br i1 %v30069_in_bounds, label %v30069_index_ok, label %v30069_index_fail
v30069_index_fail:
  call void @llvm.trap()
  unreachable
v30069_index_ok:
  %v30069_ptr = getelementptr i8, ptr %v30069_data, i64 3
  %v30069 = load i8, ptr %v30069_ptr, align 1
  %v30068 = zext i8 %v30069 to i32
  %v30066_data = extractvalue %sollang.int_slice %v30067, 0
  %v30066_length = extractvalue %sollang.int_slice %v30067, 1
  %v30066_index = sext i32 %v30068 to i64
  %v30066_in_bounds = icmp ult i64 %v30066_index, %v30066_length
  br i1 %v30066_in_bounds, label %v30066_index_ok, label %v30066_index_fail
v30066_index_fail:
  call void @llvm.trap()
  unreachable
v30066_index_ok:
  %v30066_ptr = getelementptr i8, ptr %v30066_data, i64 %v30066_index
  %v30066 = load i8, ptr %v30066_ptr, align 1
  %assign30065_array = load %sollang.int_slice, ptr %slot29972, align 8
  %assign30065_data = extractvalue %sollang.int_slice %assign30065_array, 0
  %assign30065_index = sext i32 2 to i64
  %assign30065_ptr = getelementptr i8, ptr %assign30065_data, i64 %assign30065_index
  store i8 %v30066, ptr %assign30065_ptr, align 1
  %v30075 = call %sollang.int_slice @sollang_m21_s0()
  %v30077 = freeze i8 %v30046
  %v30076 = zext i8 %v30077 to i32
  %v30074_data = extractvalue %sollang.int_slice %v30075, 0
  %v30074_length = extractvalue %sollang.int_slice %v30075, 1
  %v30074_index = sext i32 %v30076 to i64
  %v30074_in_bounds = icmp ult i64 %v30074_index, %v30074_length
  br i1 %v30074_in_bounds, label %v30074_index_ok, label %v30074_index_fail
v30074_index_fail:
  call void @llvm.trap()
  unreachable
v30074_index_ok:
  %v30074_ptr = getelementptr i8, ptr %v30074_data, i64 %v30074_index
  %v30074 = load i8, ptr %v30074_ptr, align 1
  %assign30073_array = load %sollang.int_slice, ptr %slot29972, align 8
  %assign30073_data = extractvalue %sollang.int_slice %assign30073_array, 0
  %assign30073_index = sext i32 3 to i64
  %assign30073_ptr = getelementptr i8, ptr %assign30073_data, i64 %assign30073_index
  store i8 %v30074, ptr %assign30073_ptr, align 1
  %v30082 = load %sollang.int_slice, ptr %slot29972, align 1
  %v30085 = call %sollang.int_slice @sollang_m21_s1()
  %v30086 = load i32, ptr %slot29971, align 4
  %v30081_data = extractvalue %sollang.int_slice %v30082, 0
  %v30081_length = extractvalue %sollang.int_slice %v30082, 1
  %v30081_in_bounds = icmp ult i64 0, %v30081_length
  br i1 %v30081_in_bounds, label %v30081_index_ok, label %v30081_index_fail
v30081_index_fail:
  call void @llvm.trap()
  unreachable
v30081_index_ok:
  %v30081_ptr = getelementptr i8, ptr %v30081_data, i64 0
  %v30081 = load i8, ptr %v30081_ptr, align 1
  %v30084_data = extractvalue %sollang.int_slice %v30085, 0
  %v30084_length = extractvalue %sollang.int_slice %v30085, 1
  %v30084_index = sext i32 %v30086 to i64
  %v30084_in_bounds = icmp ult i64 %v30084_index, %v30084_length
  br i1 %v30084_in_bounds, label %v30084_index_ok, label %v30084_index_fail
v30084_index_fail:
  call void @llvm.trap()
  unreachable
v30084_index_ok:
  %v30084_ptr = getelementptr i8, ptr %v30084_data, i64 %v30084_index
  %v30084 = load i8, ptr %v30084_ptr, align 1
  %v30080 = call i8 @sollang_m21_s6(i8 %v30081, i8 %v30084)
  %assign30079_array = load %sollang.int_slice, ptr %slot29972, align 8
  %assign30079_data = extractvalue %sollang.int_slice %assign30079_array, 0
  %assign30079_index = sext i32 0 to i64
  %assign30079_ptr = getelementptr i8, ptr %assign30079_data, i64 %assign30079_index
  store i8 %v30080, ptr %assign30079_ptr, align 1
  %v30089 = load i32, ptr %slot29971, align 4
  %v30088 = add i32 %v30089, 1
  store i32 %v30088, ptr %slot29971, align 4
  br label %if30044_merge
if30044_merge:
  store i32 0, ptr %slot29977, align 4
  br label %while30096_header
while30096_header:
  %while30096_v30094 = load i32, ptr %slot29977, align 4
  %while30096_v30093 = icmp slt i32 %while30096_v30094, 4
  br i1 %while30096_v30093, label %while30096_body, label %while30096_exit
while30096_body:
  %v30101 = load %sollang.array.i32, ptr %slot29965, align 8
  %v30103 = load i32, ptr %slot29970, align 4
  %v30106 = load %sollang.int_slice, ptr %slot29972, align 1
  %v30107 = load i32, ptr %slot29977, align 4
  %v30108 = load i32, ptr %slot29970, align 4
  %v30102 = sub i32 %v30103, 16
  %v30105_data = extractvalue %sollang.int_slice %v30106, 0
  %v30105_length = extractvalue %sollang.int_slice %v30106, 1
  %v30105_index = sext i32 %v30107 to i64
  %v30105_in_bounds = icmp ult i64 %v30105_index, %v30105_length
  br i1 %v30105_in_bounds, label %v30105_index_ok, label %v30105_index_fail
v30105_index_fail:
  call void @llvm.trap()
  unreachable
v30105_index_ok:
  %v30105_ptr = getelementptr i8, ptr %v30105_data, i64 %v30105_index
  %v30105 = load i8, ptr %v30105_ptr, align 1
  %v30100_data = extractvalue %sollang.array.i32 %v30101, 0
  %v30100_length = extractvalue %sollang.array.i32 %v30101, 1
  %v30100_index = sext i32 %v30102 to i64
  %v30100_in_bounds = icmp ult i64 %v30100_index, %v30100_length
  br i1 %v30100_in_bounds, label %v30100_index_ok, label %v30100_index_fail
v30100_index_fail:
  call void @llvm.trap()
  unreachable
v30100_index_ok:
  %v30100_ptr = getelementptr i8, ptr %v30100_data, i64 %v30100_index
  %v30100 = load i8, ptr %v30100_ptr, align 1
  %v30099 = call i8 @sollang_m21_s6(i8 %v30100, i8 %v30105)
  %assign30098_array = load %sollang.array.i32, ptr %slot29965, align 8
  %assign30098_data = extractvalue %sollang.array.i32 %assign30098_array, 0
  %assign30098_index = sext i32 %v30108 to i64
  %assign30098_ptr = getelementptr i8, ptr %assign30098_data, i64 %assign30098_index
  store i8 %v30099, ptr %assign30098_ptr, align 1
  %v30110 = load i32, ptr %slot29970, align 4
  %v30109 = add i32 %v30110, 1
  store i32 %v30109, ptr %slot29970, align 4
  %v30113 = load i32, ptr %slot29977, align 4
  %v30112 = add i32 %v30113, 1
  store i32 %v30112, ptr %slot29977, align 4
  br label %while30096_header
while30096_exit:
  br label %while30018_header
while30018_exit:
  %v30115 = load %sollang.array.i32, ptr %slot29965, align 8
  %dropfixedliteral29972 = extractvalue %sollang.int_slice %v30011, 0
  call void @sollang_free(ptr %dropfixedliteral29972)
  ret %sollang.array.i32 %v30115
}
define void @sollang_m21_s27(ptr %arg_mut_struct, %sollang.int_slice %arg1, i32 %arg2) {
entry:
  %arg_value0 = insertvalue %sollang.int_slice poison, ptr %arg_mut_struct, 0
  %arg = insertvalue %sollang.int_slice %arg_value0, i64 16, 1
  %slot30122 = alloca i32, align 4
  store i32 0, ptr %slot30122, align 4
  br label %while30129_header
while30129_header:
  %while30129_v30127 = load i32, ptr %slot30122, align 4
  %while30129_v30126 = icmp slt i32 %while30129_v30127, 16
  br i1 %while30129_v30126, label %while30129_body, label %while30129_exit
while30129_body:
  %v30134 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30135 = load i32, ptr %slot30122, align 4
  %v30137 = freeze %sollang.int_slice %arg1
  %v30139 = freeze i32 %arg2
  %v30140 = load i32, ptr %slot30122, align 4
  %v30141 = load i32, ptr %slot30122, align 4
  %v30133_data = extractvalue %sollang.int_slice %v30134, 0
  %v30133_length = extractvalue %sollang.int_slice %v30134, 1
  %v30133_index = sext i32 %v30135 to i64
  %v30133_in_bounds = icmp ult i64 %v30133_index, %v30133_length
  br i1 %v30133_in_bounds, label %v30133_index_ok, label %v30133_index_fail
v30133_index_fail:
  call void @llvm.trap()
  unreachable
v30133_index_ok:
  %v30133_ptr = getelementptr i8, ptr %v30133_data, i64 %v30133_index
  %v30133 = load i8, ptr %v30133_ptr, align 1
  %v30138 = add i32 %arg2, %v30140
  %v30136_data = extractvalue %sollang.int_slice %arg1, 0
  %v30136_length = extractvalue %sollang.int_slice %arg1, 1
  %v30136_index = sext i32 %v30138 to i64
  %v30136_in_bounds = icmp ult i64 %v30136_index, %v30136_length
  br i1 %v30136_in_bounds, label %v30136_index_ok, label %v30136_index_fail
v30136_index_fail:
  call void @llvm.trap()
  unreachable
v30136_index_ok:
  %v30136_ptr = getelementptr i8, ptr %v30136_data, i64 %v30136_index
  %v30136 = load i8, ptr %v30136_ptr, align 1
  %v30132 = call i8 @sollang_m21_s6(i8 %v30133, i8 %v30136)
  %assign30131_data = extractvalue %sollang.int_slice %arg, 0
  %assign30131_index = sext i32 %v30141 to i64
  %assign30131_ptr = getelementptr i8, ptr %assign30131_data, i64 %assign30131_index
  store i8 %v30132, ptr %assign30131_ptr, align 1
  %v30143 = load i32, ptr %slot30122, align 4
  %v30142 = add i32 %v30143, 1
  store i32 %v30142, ptr %slot30122, align 4
  br label %while30129_header
while30129_exit:
  ret void
}
define void @sollang_m21_s32(ptr %arg_mut_struct) {
entry:
  %arg_value0 = insertvalue %sollang.int_slice poison, ptr %arg_mut_struct, 0
  %arg = insertvalue %sollang.int_slice %arg_value0, i64 16, 1
  %slot30148 = alloca i32, align 4
  store i32 0, ptr %slot30148, align 4
  br label %while30155_header
while30155_header:
  %while30155_v30153 = load i32, ptr %slot30148, align 4
  %while30155_v30152 = icmp slt i32 %while30155_v30153, 16
  br i1 %while30155_v30152, label %while30155_body, label %while30155_exit
while30155_body:
  %v30159 = call %sollang.int_slice @sollang_m21_s0()
  %v30162 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30163 = load i32, ptr %slot30148, align 4
  %v30164 = load i32, ptr %slot30148, align 4
  %v30161_data = extractvalue %sollang.int_slice %v30162, 0
  %v30161_length = extractvalue %sollang.int_slice %v30162, 1
  %v30161_index = sext i32 %v30163 to i64
  %v30161_in_bounds = icmp ult i64 %v30161_index, %v30161_length
  br i1 %v30161_in_bounds, label %v30161_index_ok, label %v30161_index_fail
v30161_index_fail:
  call void @llvm.trap()
  unreachable
v30161_index_ok:
  %v30161_ptr = getelementptr i8, ptr %v30161_data, i64 %v30161_index
  %v30161 = load i8, ptr %v30161_ptr, align 1
  %v30160 = zext i8 %v30161 to i32
  %v30158_data = extractvalue %sollang.int_slice %v30159, 0
  %v30158_length = extractvalue %sollang.int_slice %v30159, 1
  %v30158_index = sext i32 %v30160 to i64
  %v30158_in_bounds = icmp ult i64 %v30158_index, %v30158_length
  br i1 %v30158_in_bounds, label %v30158_index_ok, label %v30158_index_fail
v30158_index_fail:
  call void @llvm.trap()
  unreachable
v30158_index_ok:
  %v30158_ptr = getelementptr i8, ptr %v30158_data, i64 %v30158_index
  %v30158 = load i8, ptr %v30158_ptr, align 1
  %assign30157_data = extractvalue %sollang.int_slice %arg, 0
  %assign30157_index = sext i32 %v30164 to i64
  %assign30157_ptr = getelementptr i8, ptr %assign30157_data, i64 %assign30157_index
  store i8 %v30158, ptr %assign30157_ptr, align 1
  %v30166 = load i32, ptr %slot30148, align 4
  %v30165 = add i32 %v30166, 1
  store i32 %v30165, ptr %slot30148, align 4
  br label %while30155_header
while30155_exit:
  ret void
}
define void @sollang_m21_s35(ptr %arg_mut_struct) {
entry:
  %arg_value0 = insertvalue %sollang.int_slice poison, ptr %arg_mut_struct, 0
  %arg = insertvalue %sollang.int_slice %arg_value0, i64 16, 1
  %v30176 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30180 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30175_data = extractvalue %sollang.int_slice %v30176, 0
  %v30175_length = extractvalue %sollang.int_slice %v30176, 1
  %v30175_in_bounds = icmp ult i64 1, %v30175_length
  br i1 %v30175_in_bounds, label %v30175_index_ok, label %v30175_index_fail
v30175_index_fail:
  call void @llvm.trap()
  unreachable
v30175_index_ok:
  %v30175_ptr = getelementptr i8, ptr %v30175_data, i64 1
  %v30175 = load i8, ptr %v30175_ptr, align 1
  %v30179_data = extractvalue %sollang.int_slice %v30180, 0
  %v30179_length = extractvalue %sollang.int_slice %v30180, 1
  %v30179_in_bounds = icmp ult i64 5, %v30179_length
  br i1 %v30179_in_bounds, label %v30179_index_ok, label %v30179_index_fail
v30179_index_fail:
  call void @llvm.trap()
  unreachable
v30179_index_ok:
  %v30179_ptr = getelementptr i8, ptr %v30179_data, i64 5
  %v30179 = load i8, ptr %v30179_ptr, align 1
  %assign30178_data = extractvalue %sollang.int_slice %arg, 0
  %assign30178_index = sext i32 1 to i64
  %assign30178_ptr = getelementptr i8, ptr %assign30178_data, i64 %assign30178_index
  store i8 %v30179, ptr %assign30178_ptr, align 1
  %v30185 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30194 = freeze i8 %v30175
  %v30184_data = extractvalue %sollang.int_slice %v30185, 0
  %v30184_length = extractvalue %sollang.int_slice %v30185, 1
  %v30184_in_bounds = icmp ult i64 9, %v30184_length
  br i1 %v30184_in_bounds, label %v30184_index_ok, label %v30184_index_fail
v30184_index_fail:
  call void @llvm.trap()
  unreachable
v30184_index_ok:
  %v30184_ptr = getelementptr i8, ptr %v30184_data, i64 9
  %v30184 = load i8, ptr %v30184_ptr, align 1
  %assign30183_data = extractvalue %sollang.int_slice %arg, 0
  %assign30183_index = sext i32 5 to i64
  %assign30183_ptr = getelementptr i8, ptr %assign30183_data, i64 %assign30183_index
  store i8 %v30184, ptr %assign30183_ptr, align 1
  %v30190 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30189_data = extractvalue %sollang.int_slice %v30190, 0
  %v30189_length = extractvalue %sollang.int_slice %v30190, 1
  %v30189_in_bounds = icmp ult i64 13, %v30189_length
  br i1 %v30189_in_bounds, label %v30189_index_ok, label %v30189_index_fail
v30189_index_fail:
  call void @llvm.trap()
  unreachable
v30189_index_ok:
  %v30189_ptr = getelementptr i8, ptr %v30189_data, i64 13
  %v30189 = load i8, ptr %v30189_ptr, align 1
  %assign30188_data = extractvalue %sollang.int_slice %arg, 0
  %assign30188_index = sext i32 9 to i64
  %assign30188_ptr = getelementptr i8, ptr %assign30188_data, i64 %assign30188_index
  store i8 %v30189, ptr %assign30188_ptr, align 1
  %assign30193_data = extractvalue %sollang.int_slice %arg, 0
  %assign30193_index = sext i32 13 to i64
  %assign30193_ptr = getelementptr i8, ptr %assign30193_data, i64 %assign30193_index
  store i8 %v30194, ptr %assign30193_ptr, align 1
  %v30197 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30200 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30204 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30196_data = extractvalue %sollang.int_slice %v30197, 0
  %v30196_length = extractvalue %sollang.int_slice %v30197, 1
  %v30196_in_bounds = icmp ult i64 2, %v30196_length
  br i1 %v30196_in_bounds, label %v30196_index_ok, label %v30196_index_fail
v30196_index_fail:
  call void @llvm.trap()
  unreachable
v30196_index_ok:
  %v30196_ptr = getelementptr i8, ptr %v30196_data, i64 2
  %v30196 = load i8, ptr %v30196_ptr, align 1
  %v30203_data = extractvalue %sollang.int_slice %v30204, 0
  %v30203_length = extractvalue %sollang.int_slice %v30204, 1
  %v30203_in_bounds = icmp ult i64 10, %v30203_length
  br i1 %v30203_in_bounds, label %v30203_index_ok, label %v30203_index_fail
v30203_index_fail:
  call void @llvm.trap()
  unreachable
v30203_index_ok:
  %v30203_ptr = getelementptr i8, ptr %v30203_data, i64 10
  %v30203 = load i8, ptr %v30203_ptr, align 1
  %v30199_data = extractvalue %sollang.int_slice %v30200, 0
  %v30199_length = extractvalue %sollang.int_slice %v30200, 1
  %v30199_in_bounds = icmp ult i64 6, %v30199_length
  br i1 %v30199_in_bounds, label %v30199_index_ok, label %v30199_index_fail
v30199_index_fail:
  call void @llvm.trap()
  unreachable
v30199_index_ok:
  %v30199_ptr = getelementptr i8, ptr %v30199_data, i64 6
  %v30199 = load i8, ptr %v30199_ptr, align 1
  %v30213 = freeze i8 %v30196
  %assign30202_data = extractvalue %sollang.int_slice %arg, 0
  %assign30202_index = sext i32 2 to i64
  %assign30202_ptr = getelementptr i8, ptr %assign30202_data, i64 %assign30202_index
  store i8 %v30203, ptr %assign30202_ptr, align 1
  %v30209 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30216 = freeze i8 %v30199
  %v30208_data = extractvalue %sollang.int_slice %v30209, 0
  %v30208_length = extractvalue %sollang.int_slice %v30209, 1
  %v30208_in_bounds = icmp ult i64 14, %v30208_length
  br i1 %v30208_in_bounds, label %v30208_index_ok, label %v30208_index_fail
v30208_index_fail:
  call void @llvm.trap()
  unreachable
v30208_index_ok:
  %v30208_ptr = getelementptr i8, ptr %v30208_data, i64 14
  %v30208 = load i8, ptr %v30208_ptr, align 1
  %assign30207_data = extractvalue %sollang.int_slice %arg, 0
  %assign30207_index = sext i32 6 to i64
  %assign30207_ptr = getelementptr i8, ptr %assign30207_data, i64 %assign30207_index
  store i8 %v30208, ptr %assign30207_ptr, align 1
  %assign30212_data = extractvalue %sollang.int_slice %arg, 0
  %assign30212_index = sext i32 10 to i64
  %assign30212_ptr = getelementptr i8, ptr %assign30212_data, i64 %assign30212_index
  store i8 %v30213, ptr %assign30212_ptr, align 1
  %assign30215_data = extractvalue %sollang.int_slice %arg, 0
  %assign30215_index = sext i32 14 to i64
  %assign30215_ptr = getelementptr i8, ptr %assign30215_data, i64 %assign30215_index
  store i8 %v30216, ptr %assign30215_ptr, align 1
  %v30219 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30223 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30218_data = extractvalue %sollang.int_slice %v30219, 0
  %v30218_length = extractvalue %sollang.int_slice %v30219, 1
  %v30218_in_bounds = icmp ult i64 3, %v30218_length
  br i1 %v30218_in_bounds, label %v30218_index_ok, label %v30218_index_fail
v30218_index_fail:
  call void @llvm.trap()
  unreachable
v30218_index_ok:
  %v30218_ptr = getelementptr i8, ptr %v30218_data, i64 3
  %v30218 = load i8, ptr %v30218_ptr, align 1
  %v30222_data = extractvalue %sollang.int_slice %v30223, 0
  %v30222_length = extractvalue %sollang.int_slice %v30223, 1
  %v30222_in_bounds = icmp ult i64 15, %v30222_length
  br i1 %v30222_in_bounds, label %v30222_index_ok, label %v30222_index_fail
v30222_index_fail:
  call void @llvm.trap()
  unreachable
v30222_index_ok:
  %v30222_ptr = getelementptr i8, ptr %v30222_data, i64 15
  %v30222 = load i8, ptr %v30222_ptr, align 1
  %assign30221_data = extractvalue %sollang.int_slice %arg, 0
  %assign30221_index = sext i32 3 to i64
  %assign30221_ptr = getelementptr i8, ptr %assign30221_data, i64 %assign30221_index
  store i8 %v30222, ptr %assign30221_ptr, align 1
  %v30228 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30237 = freeze i8 %v30218
  %v30227_data = extractvalue %sollang.int_slice %v30228, 0
  %v30227_length = extractvalue %sollang.int_slice %v30228, 1
  %v30227_in_bounds = icmp ult i64 11, %v30227_length
  br i1 %v30227_in_bounds, label %v30227_index_ok, label %v30227_index_fail
v30227_index_fail:
  call void @llvm.trap()
  unreachable
v30227_index_ok:
  %v30227_ptr = getelementptr i8, ptr %v30227_data, i64 11
  %v30227 = load i8, ptr %v30227_ptr, align 1
  %assign30226_data = extractvalue %sollang.int_slice %arg, 0
  %assign30226_index = sext i32 15 to i64
  %assign30226_ptr = getelementptr i8, ptr %assign30226_data, i64 %assign30226_index
  store i8 %v30227, ptr %assign30226_ptr, align 1
  %v30233 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30232_data = extractvalue %sollang.int_slice %v30233, 0
  %v30232_length = extractvalue %sollang.int_slice %v30233, 1
  %v30232_in_bounds = icmp ult i64 7, %v30232_length
  br i1 %v30232_in_bounds, label %v30232_index_ok, label %v30232_index_fail
v30232_index_fail:
  call void @llvm.trap()
  unreachable
v30232_index_ok:
  %v30232_ptr = getelementptr i8, ptr %v30232_data, i64 7
  %v30232 = load i8, ptr %v30232_ptr, align 1
  %assign30231_data = extractvalue %sollang.int_slice %arg, 0
  %assign30231_index = sext i32 11 to i64
  %assign30231_ptr = getelementptr i8, ptr %assign30231_data, i64 %assign30231_index
  store i8 %v30232, ptr %assign30231_ptr, align 1
  %assign30236_data = extractvalue %sollang.int_slice %arg, 0
  %assign30236_index = sext i32 7 to i64
  %assign30236_ptr = getelementptr i8, ptr %assign30236_data, i64 %assign30236_index
  store i8 %v30237, ptr %assign30236_ptr, align 1
  ret void
}
define void @sollang_m21_s40(ptr %arg_mut_struct) {
entry:
  %arg_value0 = insertvalue %sollang.int_slice poison, ptr %arg_mut_struct, 0
  %arg = insertvalue %sollang.int_slice %arg_value0, i64 16, 1
  %slot30242 = alloca i32, align 4
  store i32 0, ptr %slot30242, align 4
  br label %while30254_header
while30254_header:
  %while30254_v30252 = load i32, ptr %slot30242, align 4
  %while30254_v30251 = icmp slt i32 %while30254_v30252, 4
  br i1 %while30254_v30251, label %while30254_body, label %while30254_exit
while30254_body:
  %v30257 = load i32, ptr %slot30242, align 4
  %v30256 = mul i32 %v30257, 4
  %v30260 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30261 = freeze i32 %v30256
  %v30259_data = extractvalue %sollang.int_slice %v30260, 0
  %v30259_length = extractvalue %sollang.int_slice %v30260, 1
  %v30259_index = sext i32 %v30261 to i64
  %v30259_in_bounds = icmp ult i64 %v30259_index, %v30259_length
  br i1 %v30259_in_bounds, label %v30259_index_ok, label %v30259_index_fail
v30259_index_fail:
  call void @llvm.trap()
  unreachable
v30259_index_ok:
  %v30259_ptr = getelementptr i8, ptr %v30259_data, i64 %v30259_index
  %v30259 = load i8, ptr %v30259_ptr, align 1
  %v30263 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30265 = freeze i32 %v30256
  %v30264 = add i32 %v30265, 1
  %v30262_data = extractvalue %sollang.int_slice %v30263, 0
  %v30262_length = extractvalue %sollang.int_slice %v30263, 1
  %v30262_index = sext i32 %v30264 to i64
  %v30262_in_bounds = icmp ult i64 %v30262_index, %v30262_length
  br i1 %v30262_in_bounds, label %v30262_index_ok, label %v30262_index_fail
v30262_index_fail:
  call void @llvm.trap()
  unreachable
v30262_index_ok:
  %v30262_ptr = getelementptr i8, ptr %v30262_data, i64 %v30262_index
  %v30262 = load i8, ptr %v30262_ptr, align 1
  %v30268 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30270 = freeze i32 %v30256
  %v30269 = add i32 %v30270, 2
  %v30267_data = extractvalue %sollang.int_slice %v30268, 0
  %v30267_length = extractvalue %sollang.int_slice %v30268, 1
  %v30267_index = sext i32 %v30269 to i64
  %v30267_in_bounds = icmp ult i64 %v30267_index, %v30267_length
  br i1 %v30267_in_bounds, label %v30267_index_ok, label %v30267_index_fail
v30267_index_fail:
  call void @llvm.trap()
  unreachable
v30267_index_ok:
  %v30267_ptr = getelementptr i8, ptr %v30267_data, i64 %v30267_index
  %v30267 = load i8, ptr %v30267_ptr, align 1
  %v30273 = insertvalue %sollang.int_slice %arg, i64 16, 1
  %v30275 = freeze i32 %v30256
  %v30274 = add i32 %v30275, 3
  %v30272_data = extractvalue %sollang.int_slice %v30273, 0
  %v30272_length = extractvalue %sollang.int_slice %v30273, 1
  %v30272_index = sext i32 %v30274 to i64
  %v30272_in_bounds = icmp ult i64 %v30272_index, %v30272_length
  br i1 %v30272_in_bounds, label %v30272_index_ok, label %v30272_index_fail
v30272_index_fail:
  call void @llvm.trap()
  unreachable
v30272_index_ok:
  %v30272_ptr = getelementptr i8, ptr %v30272_data, i64 %v30272_index
  %v30272 = load i8, ptr %v30272_ptr, align 1
  %v30282 = freeze i8 %v30259
  %v30284 = freeze i8 %v30262
  %v30285 = freeze i8 %v30267
  %v30286 = freeze i8 %v30272
  %v30287 = freeze i32 %v30256
  %v30281 = call i8 @sollang_m21_s8(i8 %v30282)
  %v30283 = call i8 @sollang_m21_s10(i8 %v30284)
  %v30280 = call i8 @sollang_m21_s6(i8 %v30281, i8 %v30283)
  %v30279 = call i8 @sollang_m21_s6(i8 %v30280, i8 %v30285)
  %v30278 = call i8 @sollang_m21_s6(i8 %v30279, i8 %v30286)
  %assign30277_data = extractvalue %sollang.int_slice %arg, 0
  %assign30277_index = sext i32 %v30287 to i64
  %assign30277_ptr = getelementptr i8, ptr %assign30277_data, i64 %assign30277_index
  store i8 %v30278, ptr %assign30277_ptr, align 1
  %v30292 = freeze i8 %v30259
  %v30294 = freeze i8 %v30262
  %v30296 = freeze i8 %v30267
  %v30297 = freeze i8 %v30272
  %v30299 = freeze i32 %v30256
  %v30293 = call i8 @sollang_m21_s8(i8 %v30294)
  %v30295 = call i8 @sollang_m21_s10(i8 %v30296)
  %v30298 = add i32 %v30299, 1
  %v30291 = call i8 @sollang_m21_s6(i8 %v30292, i8 %v30293)
  %v30290 = call i8 @sollang_m21_s6(i8 %v30291, i8 %v30295)
  %v30289 = call i8 @sollang_m21_s6(i8 %v30290, i8 %v30297)
  %assign30288_data = extractvalue %sollang.int_slice %arg, 0
  %assign30288_index = sext i32 %v30298 to i64
  %assign30288_ptr = getelementptr i8, ptr %assign30288_data, i64 %assign30288_index
  store i8 %v30289, ptr %assign30288_ptr, align 1
  %v30305 = freeze i8 %v30259
  %v30306 = freeze i8 %v30262
  %v30308 = freeze i8 %v30267
  %v30310 = freeze i8 %v30272
  %v30312 = freeze i32 %v30256
  %v30304 = call i8 @sollang_m21_s6(i8 %v30305, i8 %v30306)
  %v30307 = call i8 @sollang_m21_s8(i8 %v30308)
  %v30309 = call i8 @sollang_m21_s10(i8 %v30310)
  %v30311 = add i32 %v30312, 2
  %v30303 = call i8 @sollang_m21_s6(i8 %v30304, i8 %v30307)
  %v30302 = call i8 @sollang_m21_s6(i8 %v30303, i8 %v30309)
  %assign30301_data = extractvalue %sollang.int_slice %arg, 0
  %assign30301_index = sext i32 %v30311 to i64
  %assign30301_ptr = getelementptr i8, ptr %assign30301_data, i64 %assign30301_index
  store i8 %v30302, ptr %assign30301_ptr, align 1
  %v30319 = freeze i8 %v30259
  %v30320 = freeze i8 %v30262
  %v30321 = freeze i8 %v30267
  %v30323 = freeze i8 %v30272
  %v30325 = freeze i32 %v30256
  %v30318 = call i8 @sollang_m21_s10(i8 %v30319)
  %v30322 = call i8 @sollang_m21_s8(i8 %v30323)
  %v30324 = add i32 %v30325, 3
  %v30317 = call i8 @sollang_m21_s6(i8 %v30318, i8 %v30320)
  %v30316 = call i8 @sollang_m21_s6(i8 %v30317, i8 %v30321)
  %v30315 = call i8 @sollang_m21_s6(i8 %v30316, i8 %v30322)
  %assign30314_data = extractvalue %sollang.int_slice %arg, 0
  %assign30314_index = sext i32 %v30324 to i64
  %assign30314_ptr = getelementptr i8, ptr %assign30314_data, i64 %assign30314_index
  store i8 %v30315, ptr %assign30314_ptr, align 1
  %v30328 = load i32, ptr %slot30242, align 4
  %v30327 = add i32 %v30328, 1
  store i32 %v30327, ptr %slot30242, align 4
  br label %while30254_header
while30254_exit:
  ret void
}
define %sollang.struct.m21_s2 @sollang_m21_s48(%sollang.int_slice %arg) {
entry:
  %v30334 = call %sollang.array.i32 @sollang_m21_s11(%sollang.int_slice %arg)
  %v30333 = insertvalue %sollang.struct.m21_s2 poison, %sollang.array.i32 %v30334, 0
  ret %sollang.struct.m21_s2 %v30333
}
define %sollang.int_slice @sollang_m21_s50_portable(%sollang.struct.m21_s2 %arg, %sollang.int_slice %arg1) {
entry:
  %slot30340 = alloca %sollang.int_slice, align 1
  %slot30341 = alloca i32, align 4
  %slot30343 = alloca i32, align 4
  store i32 0, ptr %slot30341, align 4
  store i32 1, ptr %slot30343, align 4
  %heap_v30347 = call ptr @sollang_alloc(i64 16)
  %v30347_data = getelementptr i8, ptr %heap_v30347, i64 0
  %v30347_allocation_ok = icmp ne ptr %v30347_data, null
  br i1 %v30347_allocation_ok, label %v30347_allocation_ready, label %v30347_allocation_failed
v30347_allocation_failed:
  %v30347_allocation_diagnostic = alloca [70 x i8], align 1
  store [70 x i8] c"\73\74\64\2E\63\72\79\70\74\6F\2E\61\65\73\31\32\38\2E\73\74\64\2E\63\72\79\70\74\6F\2E\61\65\73\31\32\38\2E\4B\65\79\2E\65\6E\63\72\79\70\74\42\6C\6F\63\6B\3A\61\6C\6C\6F\63\61\74\69\6F\6E\5F\66\61\69\6C\65\64", ptr %v30347_allocation_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v30347_allocation_diagnostic, i64 70, i1 false)
  call void @llvm.trap()
  unreachable
v30347_allocation_ready:
  %v30347_ptr0 = getelementptr i8, ptr %v30347_data, i64 0
  store i8 0, ptr %v30347_ptr0, align 1
  %v30347_ptr1 = getelementptr i8, ptr %v30347_data, i64 1
  store i8 0, ptr %v30347_ptr1, align 1
  %v30347_ptr2 = getelementptr i8, ptr %v30347_data, i64 2
  store i8 0, ptr %v30347_ptr2, align 1
  %v30347_ptr3 = getelementptr i8, ptr %v30347_data, i64 3
  store i8 0, ptr %v30347_ptr3, align 1
  %v30347_ptr4 = getelementptr i8, ptr %v30347_data, i64 4
  store i8 0, ptr %v30347_ptr4, align 1
  %v30347_ptr5 = getelementptr i8, ptr %v30347_data, i64 5
  store i8 0, ptr %v30347_ptr5, align 1
  %v30347_ptr6 = getelementptr i8, ptr %v30347_data, i64 6
  store i8 0, ptr %v30347_ptr6, align 1
  %v30347_ptr7 = getelementptr i8, ptr %v30347_data, i64 7
  store i8 0, ptr %v30347_ptr7, align 1
  %v30347_ptr8 = getelementptr i8, ptr %v30347_data, i64 8
  store i8 0, ptr %v30347_ptr8, align 1
  %v30347_ptr9 = getelementptr i8, ptr %v30347_data, i64 9
  store i8 0, ptr %v30347_ptr9, align 1
  %v30347_ptr10 = getelementptr i8, ptr %v30347_data, i64 10
  store i8 0, ptr %v30347_ptr10, align 1
  %v30347_ptr11 = getelementptr i8, ptr %v30347_data, i64 11
  store i8 0, ptr %v30347_ptr11, align 1
  %v30347_ptr12 = getelementptr i8, ptr %v30347_data, i64 12
  store i8 0, ptr %v30347_ptr12, align 1
  %v30347_ptr13 = getelementptr i8, ptr %v30347_data, i64 13
  store i8 0, ptr %v30347_ptr13, align 1
  %v30347_ptr14 = getelementptr i8, ptr %v30347_data, i64 14
  store i8 0, ptr %v30347_ptr14, align 1
  %v30347_ptr15 = getelementptr i8, ptr %v30347_data, i64 15
  store i8 0, ptr %v30347_ptr15, align 1
  %v30347_0 = insertvalue %sollang.int_slice poison, ptr %v30347_data, 0
  %v30347 = insertvalue %sollang.int_slice %v30347_0, i64 16, 1
  %v30366 = extractvalue %sollang.struct.m21_s2 %arg, 0
  %v30398 = extractvalue %sollang.struct.m21_s2 %arg, 0
  %v30346 = insertvalue %sollang.struct.m21_s4 poison, %sollang.int_slice %v30347, 0
  %v30345 = extractvalue %sollang.struct.m21_s4 %v30346, 0
  store %sollang.int_slice %v30345, ptr %slot30340, align 1
  br label %while30354_header
while30354_header:
  %while30354_v30352 = load i32, ptr %slot30341, align 4
  %while30354_v30351 = icmp slt i32 %while30354_v30352, 16
  br i1 %while30354_v30351, label %while30354_body, label %while30354_exit
while30354_body:
  %v30358 = freeze %sollang.int_slice %arg1
  %v30359 = load i32, ptr %slot30341, align 4
  %v30360 = load i32, ptr %slot30341, align 4
  %v30357_data = extractvalue %sollang.int_slice %arg1, 0
  %v30357_length = extractvalue %sollang.int_slice %arg1, 1
  %v30357_index = sext i32 %v30359 to i64
  %v30357_in_bounds = icmp ult i64 %v30357_index, %v30357_length
  br i1 %v30357_in_bounds, label %v30357_index_ok, label %v30357_index_fail
v30357_index_fail:
  call void @llvm.trap()
  unreachable
v30357_index_ok:
  %v30357_ptr = getelementptr i8, ptr %v30357_data, i64 %v30357_index
  %v30357 = load i8, ptr %v30357_ptr, align 1
  %assign30356_array = load %sollang.int_slice, ptr %slot30340, align 8
  %assign30356_data = extractvalue %sollang.int_slice %assign30356_array, 0
  %assign30356_index = sext i32 %v30360 to i64
  %assign30356_ptr = getelementptr i8, ptr %assign30356_data, i64 %assign30356_index
  store i8 %v30357, ptr %assign30356_ptr, align 1
  %v30362 = load i32, ptr %slot30341, align 4
  %v30361 = add i32 %v30362, 1
  store i32 %v30361, ptr %slot30341, align 4
  br label %while30354_header
while30354_exit:
  %v30365 = load %sollang.int_slice, ptr %slot30340, align 1
  %callmut30364_arg0_fixed = load %sollang.int_slice, ptr %slot30340, align 1
  %callmut30364_arg0 = extractvalue %sollang.int_slice %callmut30364_arg0_fixed, 0
  %call30364_arg1_slice_data = extractvalue %sollang.array.i32 %v30366, 0
  %call30364_arg1_slice_length = extractvalue %sollang.array.i32 %v30366, 1
  %call30364_arg1_slice0 = insertvalue %sollang.int_slice poison, ptr %call30364_arg1_slice_data, 0
  %call30364_arg1_slice = insertvalue %sollang.int_slice %call30364_arg1_slice0, i64 %call30364_arg1_slice_length, 1
  call void @sollang_m21_s27(ptr %callmut30364_arg0, %sollang.int_slice %call30364_arg1_slice, i32 0)
  br label %while30374_header
while30374_header:
  %while30374_v30372 = load i32, ptr %slot30343, align 4
  %while30374_v30371 = icmp slt i32 %while30374_v30372, 10
  br i1 %while30374_v30371, label %while30374_body, label %while30374_exit
while30374_body:
  %v30377 = load %sollang.int_slice, ptr %slot30340, align 1
  %callmut30376_arg0_fixed = load %sollang.int_slice, ptr %slot30340, align 1
  %callmut30376_arg0 = extractvalue %sollang.int_slice %callmut30376_arg0_fixed, 0
  call void @sollang_m21_s32(ptr %callmut30376_arg0)
  %v30379 = load %sollang.int_slice, ptr %slot30340, align 1
  %callmut30378_arg0_fixed = load %sollang.int_slice, ptr %slot30340, align 1
  %callmut30378_arg0 = extractvalue %sollang.int_slice %callmut30378_arg0_fixed, 0
  call void @sollang_m21_s35(ptr %callmut30378_arg0)
  %v30381 = load %sollang.int_slice, ptr %slot30340, align 1
  %callmut30380_arg0_fixed = load %sollang.int_slice, ptr %slot30340, align 1
  %callmut30380_arg0 = extractvalue %sollang.int_slice %callmut30380_arg0_fixed, 0
  call void @sollang_m21_s40(ptr %callmut30380_arg0)
  %v30383 = load %sollang.int_slice, ptr %slot30340, align 1
  %v30387 = load i32, ptr %slot30343, align 4
  %v30384 = extractvalue %sollang.struct.m21_s2 %arg, 0
  %v30386 = mul i32 %v30387, 16
  %callmut30382_arg0_fixed = load %sollang.int_slice, ptr %slot30340, align 1
  %callmut30382_arg0 = extractvalue %sollang.int_slice %callmut30382_arg0_fixed, 0
  %call30382_arg1_slice_data = extractvalue %sollang.array.i32 %v30384, 0
  %call30382_arg1_slice_length = extractvalue %sollang.array.i32 %v30384, 1
  %call30382_arg1_slice0 = insertvalue %sollang.int_slice poison, ptr %call30382_arg1_slice_data, 0
  %call30382_arg1_slice = insertvalue %sollang.int_slice %call30382_arg1_slice0, i64 %call30382_arg1_slice_length, 1
  call void @sollang_m21_s27(ptr %callmut30382_arg0, %sollang.int_slice %call30382_arg1_slice, i32 %v30386)
  %v30390 = load i32, ptr %slot30343, align 4
  %v30389 = add i32 %v30390, 1
  store i32 %v30389, ptr %slot30343, align 4
  br label %while30374_header
while30374_exit:
  %v30393 = load %sollang.int_slice, ptr %slot30340, align 1
  %callmut30392_arg0_fixed = load %sollang.int_slice, ptr %slot30340, align 1
  %callmut30392_arg0 = extractvalue %sollang.int_slice %callmut30392_arg0_fixed, 0
  call void @sollang_m21_s32(ptr %callmut30392_arg0)
  %v30395 = load %sollang.int_slice, ptr %slot30340, align 1
  %callmut30394_arg0_fixed = load %sollang.int_slice, ptr %slot30340, align 1
  %callmut30394_arg0 = extractvalue %sollang.int_slice %callmut30394_arg0_fixed, 0
  call void @sollang_m21_s35(ptr %callmut30394_arg0)
  %v30397 = load %sollang.int_slice, ptr %slot30340, align 1
  %callmut30396_arg0_fixed = load %sollang.int_slice, ptr %slot30340, align 1
  %callmut30396_arg0 = extractvalue %sollang.int_slice %callmut30396_arg0_fixed, 0
  %call30396_arg1_slice_data = extractvalue %sollang.array.i32 %v30398, 0
  %call30396_arg1_slice_length = extractvalue %sollang.array.i32 %v30398, 1
  %call30396_arg1_slice0 = insertvalue %sollang.int_slice poison, ptr %call30396_arg1_slice_data, 0
  %call30396_arg1_slice = insertvalue %sollang.int_slice %call30396_arg1_slice0, i64 %call30396_arg1_slice_length, 1
  call void @sollang_m21_s27(ptr %callmut30396_arg0, %sollang.int_slice %call30396_arg1_slice, i32 160)
  %v30401 = load %sollang.int_slice, ptr %slot30340, align 1
  ret %sollang.int_slice %v30401
}
@sollang_cpu_features = internal global i64 -1, align 8
@sollang_aes128_selected = internal global ptr @sollang_m21_s50_resolve, align 8
declare <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64>, <2 x i64>)
declare <2 x i64> @llvm.x86.aesni.aesenclast(<2 x i64>, <2 x i64>)

define internal i64 @sollang_cpu_features_once() {
entry:
  %cached = load atomic i64, ptr @sollang_cpu_features monotonic, align 8
  %initialized = icmp ne i64 %cached, -1
  br i1 %initialized, label %ready, label %detect
detect:
  %leaf1 = call { i32, i32, i32, i32 } asm "xchgq %rbx, ${1:q}\0Acpuid\0Axchgq %rbx, ${1:q}", "={ax},=r,={cx},={dx},0,2"(i32 1, i32 0)
  %leaf1_ecx = extractvalue { i32, i32, i32, i32 } %leaf1, 2
  %leaf1_edx = extractvalue { i32, i32, i32, i32 } %leaf1, 3
  %sse2_bits = and i32 %leaf1_edx, 67108864
  %has_sse2 = icmp ne i32 %sse2_bits, 0
  %sse2_mask = select i1 %has_sse2, i64 1, i64 0
  %aes_bits = and i32 %leaf1_ecx, 33554432
  %has_aes = icmp ne i32 %aes_bits, 0
  %aes_mask = select i1 %has_aes, i64 8, i64 0
  %detected = or i64 %sse2_mask, %aes_mask
  %installed = cmpxchg ptr @sollang_cpu_features, i64 -1, i64 %detected monotonic monotonic
  %observed = extractvalue { i64, i1 } %installed, 0
  %won = extractvalue { i64, i1 } %installed, 1
  %features = select i1 %won, i64 %detected, i64 %observed
  ret i64 %features
ready:
  ret i64 %cached
}

define internal %sollang.int_slice @sollang_m21_s50_x86(%sollang.struct.m21_s2 %arg, %sollang.int_slice %arg1) #1 {
entry:
  %expanded_slice = extractvalue %sollang.struct.m21_s2 %arg, 0
  %expanded = extractvalue %sollang.array.i32 %expanded_slice, 0
  %input = extractvalue %sollang.int_slice %arg1, 0
  %output = call ptr @sollang_alloc(i64 16)
  %allocated = icmp ne ptr %output, null
  br i1 %allocated, label %encrypt, label %allocation_failed
allocation_failed:
  call void @llvm.trap()
  unreachable
encrypt:
  %input_value = load <2 x i64>, ptr %input, align 1
  %round0 = load <2 x i64>, ptr %expanded, align 1
  %state0 = xor <2 x i64> %input_value, %round0
  %key1_ptr = getelementptr i8, ptr %expanded, i64 16
  %key1 = load <2 x i64>, ptr %key1_ptr, align 1
  %state1 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state0, <2 x i64> %key1)
  %key2_ptr = getelementptr i8, ptr %expanded, i64 32
  %key2 = load <2 x i64>, ptr %key2_ptr, align 1
  %state2 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state1, <2 x i64> %key2)
  %key3_ptr = getelementptr i8, ptr %expanded, i64 48
  %key3 = load <2 x i64>, ptr %key3_ptr, align 1
  %state3 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state2, <2 x i64> %key3)
  %key4_ptr = getelementptr i8, ptr %expanded, i64 64
  %key4 = load <2 x i64>, ptr %key4_ptr, align 1
  %state4 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state3, <2 x i64> %key4)
  %key5_ptr = getelementptr i8, ptr %expanded, i64 80
  %key5 = load <2 x i64>, ptr %key5_ptr, align 1
  %state5 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state4, <2 x i64> %key5)
  %key6_ptr = getelementptr i8, ptr %expanded, i64 96
  %key6 = load <2 x i64>, ptr %key6_ptr, align 1
  %state6 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state5, <2 x i64> %key6)
  %key7_ptr = getelementptr i8, ptr %expanded, i64 112
  %key7 = load <2 x i64>, ptr %key7_ptr, align 1
  %state7 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state6, <2 x i64> %key7)
  %key8_ptr = getelementptr i8, ptr %expanded, i64 128
  %key8 = load <2 x i64>, ptr %key8_ptr, align 1
  %state8 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state7, <2 x i64> %key8)
  %key9_ptr = getelementptr i8, ptr %expanded, i64 144
  %key9 = load <2 x i64>, ptr %key9_ptr, align 1
  %state9 = call <2 x i64> @llvm.x86.aesni.aesenc(<2 x i64> %state8, <2 x i64> %key9)
  %key10_ptr = getelementptr i8, ptr %expanded, i64 160
  %key10 = load <2 x i64>, ptr %key10_ptr, align 1
  %state10 = call <2 x i64> @llvm.x86.aesni.aesenclast(<2 x i64> %state9, <2 x i64> %key10)
  store <2 x i64> %state10, ptr %output, align 1
  %result0 = insertvalue %sollang.int_slice poison, ptr %output, 0
  %result = insertvalue %sollang.int_slice %result0, i64 16, 1
  ret %sollang.int_slice %result
}

define internal %sollang.int_slice @sollang_m21_s50_resolve(%sollang.struct.m21_s2 %arg, %sollang.int_slice %arg1) {
entry:
  %features = call i64 @sollang_cpu_features_once()
  %aes_feature = and i64 %features, 8
  %has_aes = icmp eq i64 %aes_feature, 8
  %selected = select i1 %has_aes, ptr @sollang_m21_s50_x86, ptr @sollang_m21_s50_portable
  store atomic ptr %selected, ptr @sollang_aes128_selected monotonic, align 8
  %result = tail call %sollang.int_slice %selected(%sollang.struct.m21_s2 %arg, %sollang.int_slice %arg1)
  ret %sollang.int_slice %result
}

define %sollang.int_slice @sollang_m21_s50(%sollang.struct.m21_s2 %arg, %sollang.int_slice %arg1) {
entry:
  %selected = load atomic ptr, ptr @sollang_aes128_selected monotonic, align 8
  %result = tail call %sollang.int_slice %selected(%sollang.struct.m21_s2 %arg, %sollang.int_slice %arg1)
  ret %sollang.int_slice %result
}
attributes #1 = { nounwind "target-features"="+aes,+sse2" }

define i32 @sollang_m24_s6(i32 %arg, i32 %arg1) {
entry:
  %slot31047 = alloca i32, align 4
  %slot31048 = alloca i32, align 4
  %slot31049 = alloca i32, align 4
  %v31055 = add i32 0, 0
  store i32 %v31055, ptr %slot31047, align 4
  %v31057 = add i32 1, 0
  store i32 %v31057, ptr %slot31048, align 4
  %v31059 = add i32 0, 0
  store i32 %v31059, ptr %slot31049, align 4
  br label %while31065_header
while31065_header:
  %while31065_v31063 = load i32, ptr %slot31049, align 4
  %while31065_v31062 = icmp ult i32 %while31065_v31063, 32
  br i1 %while31065_v31062, label %while31065_body, label %while31065_exit
while31065_body:
  %v31070 = load i32, ptr %slot31048, align 4
  %v31068 = udiv i32 %arg, %v31070
  %v31067 = urem i32 %v31068, 2
  %v31074 = freeze i32 %arg1
  %v31075 = load i32, ptr %slot31048, align 4
  %v31073 = udiv i32 %arg1, %v31075
  %v31072 = urem i32 %v31073, 2
  %v31079 = freeze i32 %v31067
  %v31080 = freeze i32 %v31072
  %v31078 = icmp ne i32 %v31079, %v31080
  br i1 %v31078, label %if31081_then, label %if31081_merge
if31081_then:
  %v31084 = load i32, ptr %slot31047, align 4
  %v31085 = load i32, ptr %slot31048, align 4
  %v31083 = add i32 %v31084, %v31085
  store i32 %v31083, ptr %slot31047, align 4
  br label %if31081_merge
if31081_merge:
  %v31087 = load i32, ptr %slot31049, align 4
  %v31086 = add i32 %v31087, 1
  store i32 %v31086, ptr %slot31049, align 4
  %v31091 = load i32, ptr %slot31049, align 4
  %v31090 = icmp ult i32 %v31091, 32
  br i1 %v31090, label %if31093_then, label %if31093_merge
if31093_then:
  %v31096 = load i32, ptr %slot31048, align 4
  %v31095 = mul i32 %v31096, 2
  store i32 %v31095, ptr %slot31048, align 4
  br label %if31093_merge
if31093_merge:
  br label %while31065_header
while31065_exit:
  %v31098 = load i32, ptr %slot31047, align 4
  ret i32 %v31098
}
define i32 @main() {
entry:
  %if118233_result = alloca %sollang.text, align 8
  %v118147 = call %sollang.int_slice @sollang_m144_s0()
  %v118146 = call %sollang.struct.m21_s2 @sollang_m21_s48(%sollang.int_slice %v118147)
  %call118146_temporary0 = extractvalue %sollang.int_slice %v118147, 0
  call void @sollang_free(ptr %call118146_temporary0)
  %v118149 = freeze %sollang.struct.m21_s2 %v118146
  %v118150 = call %sollang.int_slice @sollang_m144_s1()
  %v118148 = call %sollang.int_slice @sollang_m21_s50(%sollang.struct.m21_s2 %v118149, %sollang.int_slice %v118150)
  %call118148_temporary1 = extractvalue %sollang.int_slice %v118150, 0
  call void @sollang_free(ptr %call118148_temporary1)
  %while118233_v118155 = freeze %sollang.int_slice %v118148
  %while118233_v118154_data = extractvalue %sollang.int_slice %while118233_v118155, 0
  %while118233_v118154_length = extractvalue %sollang.int_slice %while118233_v118155, 1
  %while118233_v118154_index = sext i32 0 to i64
  %while118233_v118154_in_bounds = icmp ult i64 %while118233_v118154_index, %while118233_v118154_length
  br i1 %while118233_v118154_in_bounds, label %while118233_v118154_index_ok, label %while118233_v118154_index_fail
while118233_v118154_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118154_index_ok:
  %while118233_v118154_ptr = getelementptr i8, ptr %while118233_v118154_data, i64 %while118233_v118154_index
  %while118233_v118154 = load i8, ptr %while118233_v118154_ptr, align 1
  %while118233_v118153 = icmp eq i8 %while118233_v118154, 105
  br i1 %while118233_v118153, label %while118233_bool118238_rhs, label %while118233_exit
while118233_bool118238_rhs:
  %while118233_v118160 = freeze %sollang.int_slice %v118148
  %while118233_v118159_data = extractvalue %sollang.int_slice %while118233_v118160, 0
  %while118233_v118159_length = extractvalue %sollang.int_slice %while118233_v118160, 1
  %while118233_v118159_index = sext i32 1 to i64
  %while118233_v118159_in_bounds = icmp ult i64 %while118233_v118159_index, %while118233_v118159_length
  br i1 %while118233_v118159_in_bounds, label %while118233_v118159_index_ok, label %while118233_v118159_index_fail
while118233_v118159_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118159_index_ok:
  %while118233_v118159_ptr = getelementptr i8, ptr %while118233_v118159_data, i64 %while118233_v118159_index
  %while118233_v118159 = load i8, ptr %while118233_v118159_ptr, align 1
  %while118233_v118158 = icmp eq i8 %while118233_v118159, 196
  br i1 %while118233_v118158, label %while118233_bool118239_rhs, label %while118233_exit
while118233_bool118239_rhs:
  %while118233_v118165 = freeze %sollang.int_slice %v118148
  %while118233_v118164_data = extractvalue %sollang.int_slice %while118233_v118165, 0
  %while118233_v118164_length = extractvalue %sollang.int_slice %while118233_v118165, 1
  %while118233_v118164_index = sext i32 2 to i64
  %while118233_v118164_in_bounds = icmp ult i64 %while118233_v118164_index, %while118233_v118164_length
  br i1 %while118233_v118164_in_bounds, label %while118233_v118164_index_ok, label %while118233_v118164_index_fail
while118233_v118164_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118164_index_ok:
  %while118233_v118164_ptr = getelementptr i8, ptr %while118233_v118164_data, i64 %while118233_v118164_index
  %while118233_v118164 = load i8, ptr %while118233_v118164_ptr, align 1
  %while118233_v118163 = icmp eq i8 %while118233_v118164, 224
  br i1 %while118233_v118163, label %while118233_bool118240_rhs, label %while118233_exit
while118233_bool118240_rhs:
  %while118233_v118170 = freeze %sollang.int_slice %v118148
  %while118233_v118169_data = extractvalue %sollang.int_slice %while118233_v118170, 0
  %while118233_v118169_length = extractvalue %sollang.int_slice %while118233_v118170, 1
  %while118233_v118169_index = sext i32 3 to i64
  %while118233_v118169_in_bounds = icmp ult i64 %while118233_v118169_index, %while118233_v118169_length
  br i1 %while118233_v118169_in_bounds, label %while118233_v118169_index_ok, label %while118233_v118169_index_fail
while118233_v118169_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118169_index_ok:
  %while118233_v118169_ptr = getelementptr i8, ptr %while118233_v118169_data, i64 %while118233_v118169_index
  %while118233_v118169 = load i8, ptr %while118233_v118169_ptr, align 1
  %while118233_v118168 = icmp eq i8 %while118233_v118169, 216
  br i1 %while118233_v118168, label %while118233_bool118241_rhs, label %while118233_exit
while118233_bool118241_rhs:
  %while118233_v118175 = freeze %sollang.int_slice %v118148
  %while118233_v118174_data = extractvalue %sollang.int_slice %while118233_v118175, 0
  %while118233_v118174_length = extractvalue %sollang.int_slice %while118233_v118175, 1
  %while118233_v118174_index = sext i32 4 to i64
  %while118233_v118174_in_bounds = icmp ult i64 %while118233_v118174_index, %while118233_v118174_length
  br i1 %while118233_v118174_in_bounds, label %while118233_v118174_index_ok, label %while118233_v118174_index_fail
while118233_v118174_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118174_index_ok:
  %while118233_v118174_ptr = getelementptr i8, ptr %while118233_v118174_data, i64 %while118233_v118174_index
  %while118233_v118174 = load i8, ptr %while118233_v118174_ptr, align 1
  %while118233_v118173 = icmp eq i8 %while118233_v118174, 106
  br i1 %while118233_v118173, label %while118233_bool118242_rhs, label %while118233_exit
while118233_bool118242_rhs:
  %while118233_v118180 = freeze %sollang.int_slice %v118148
  %while118233_v118179_data = extractvalue %sollang.int_slice %while118233_v118180, 0
  %while118233_v118179_length = extractvalue %sollang.int_slice %while118233_v118180, 1
  %while118233_v118179_index = sext i32 5 to i64
  %while118233_v118179_in_bounds = icmp ult i64 %while118233_v118179_index, %while118233_v118179_length
  br i1 %while118233_v118179_in_bounds, label %while118233_v118179_index_ok, label %while118233_v118179_index_fail
while118233_v118179_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118179_index_ok:
  %while118233_v118179_ptr = getelementptr i8, ptr %while118233_v118179_data, i64 %while118233_v118179_index
  %while118233_v118179 = load i8, ptr %while118233_v118179_ptr, align 1
  %while118233_v118178 = icmp eq i8 %while118233_v118179, 123
  br i1 %while118233_v118178, label %while118233_bool118243_rhs, label %while118233_exit
while118233_bool118243_rhs:
  %while118233_v118185 = freeze %sollang.int_slice %v118148
  %while118233_v118184_data = extractvalue %sollang.int_slice %while118233_v118185, 0
  %while118233_v118184_length = extractvalue %sollang.int_slice %while118233_v118185, 1
  %while118233_v118184_index = sext i32 6 to i64
  %while118233_v118184_in_bounds = icmp ult i64 %while118233_v118184_index, %while118233_v118184_length
  br i1 %while118233_v118184_in_bounds, label %while118233_v118184_index_ok, label %while118233_v118184_index_fail
while118233_v118184_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118184_index_ok:
  %while118233_v118184_ptr = getelementptr i8, ptr %while118233_v118184_data, i64 %while118233_v118184_index
  %while118233_v118184 = load i8, ptr %while118233_v118184_ptr, align 1
  %while118233_v118183 = icmp eq i8 %while118233_v118184, 4
  br i1 %while118233_v118183, label %while118233_bool118244_rhs, label %while118233_exit
while118233_bool118244_rhs:
  %while118233_v118190 = freeze %sollang.int_slice %v118148
  %while118233_v118189_data = extractvalue %sollang.int_slice %while118233_v118190, 0
  %while118233_v118189_length = extractvalue %sollang.int_slice %while118233_v118190, 1
  %while118233_v118189_index = sext i32 7 to i64
  %while118233_v118189_in_bounds = icmp ult i64 %while118233_v118189_index, %while118233_v118189_length
  br i1 %while118233_v118189_in_bounds, label %while118233_v118189_index_ok, label %while118233_v118189_index_fail
while118233_v118189_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118189_index_ok:
  %while118233_v118189_ptr = getelementptr i8, ptr %while118233_v118189_data, i64 %while118233_v118189_index
  %while118233_v118189 = load i8, ptr %while118233_v118189_ptr, align 1
  %while118233_v118188 = icmp eq i8 %while118233_v118189, 48
  br i1 %while118233_v118188, label %while118233_bool118245_rhs, label %while118233_exit
while118233_bool118245_rhs:
  %while118233_v118195 = freeze %sollang.int_slice %v118148
  %while118233_v118194_data = extractvalue %sollang.int_slice %while118233_v118195, 0
  %while118233_v118194_length = extractvalue %sollang.int_slice %while118233_v118195, 1
  %while118233_v118194_index = sext i32 8 to i64
  %while118233_v118194_in_bounds = icmp ult i64 %while118233_v118194_index, %while118233_v118194_length
  br i1 %while118233_v118194_in_bounds, label %while118233_v118194_index_ok, label %while118233_v118194_index_fail
while118233_v118194_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118194_index_ok:
  %while118233_v118194_ptr = getelementptr i8, ptr %while118233_v118194_data, i64 %while118233_v118194_index
  %while118233_v118194 = load i8, ptr %while118233_v118194_ptr, align 1
  %while118233_v118193 = icmp eq i8 %while118233_v118194, 216
  br i1 %while118233_v118193, label %while118233_bool118246_rhs, label %while118233_exit
while118233_bool118246_rhs:
  %while118233_v118200 = freeze %sollang.int_slice %v118148
  %while118233_v118199_data = extractvalue %sollang.int_slice %while118233_v118200, 0
  %while118233_v118199_length = extractvalue %sollang.int_slice %while118233_v118200, 1
  %while118233_v118199_index = sext i32 9 to i64
  %while118233_v118199_in_bounds = icmp ult i64 %while118233_v118199_index, %while118233_v118199_length
  br i1 %while118233_v118199_in_bounds, label %while118233_v118199_index_ok, label %while118233_v118199_index_fail
while118233_v118199_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118199_index_ok:
  %while118233_v118199_ptr = getelementptr i8, ptr %while118233_v118199_data, i64 %while118233_v118199_index
  %while118233_v118199 = load i8, ptr %while118233_v118199_ptr, align 1
  %while118233_v118198 = icmp eq i8 %while118233_v118199, 205
  br i1 %while118233_v118198, label %while118233_bool118247_rhs, label %while118233_exit
while118233_bool118247_rhs:
  %while118233_v118205 = freeze %sollang.int_slice %v118148
  %while118233_v118204_data = extractvalue %sollang.int_slice %while118233_v118205, 0
  %while118233_v118204_length = extractvalue %sollang.int_slice %while118233_v118205, 1
  %while118233_v118204_index = sext i32 10 to i64
  %while118233_v118204_in_bounds = icmp ult i64 %while118233_v118204_index, %while118233_v118204_length
  br i1 %while118233_v118204_in_bounds, label %while118233_v118204_index_ok, label %while118233_v118204_index_fail
while118233_v118204_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118204_index_ok:
  %while118233_v118204_ptr = getelementptr i8, ptr %while118233_v118204_data, i64 %while118233_v118204_index
  %while118233_v118204 = load i8, ptr %while118233_v118204_ptr, align 1
  %while118233_v118203 = icmp eq i8 %while118233_v118204, 183
  br i1 %while118233_v118203, label %while118233_bool118248_rhs, label %while118233_exit
while118233_bool118248_rhs:
  %while118233_v118210 = freeze %sollang.int_slice %v118148
  %while118233_v118209_data = extractvalue %sollang.int_slice %while118233_v118210, 0
  %while118233_v118209_length = extractvalue %sollang.int_slice %while118233_v118210, 1
  %while118233_v118209_index = sext i32 11 to i64
  %while118233_v118209_in_bounds = icmp ult i64 %while118233_v118209_index, %while118233_v118209_length
  br i1 %while118233_v118209_in_bounds, label %while118233_v118209_index_ok, label %while118233_v118209_index_fail
while118233_v118209_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118209_index_ok:
  %while118233_v118209_ptr = getelementptr i8, ptr %while118233_v118209_data, i64 %while118233_v118209_index
  %while118233_v118209 = load i8, ptr %while118233_v118209_ptr, align 1
  %while118233_v118208 = icmp eq i8 %while118233_v118209, 128
  br i1 %while118233_v118208, label %while118233_bool118249_rhs, label %while118233_exit
while118233_bool118249_rhs:
  %while118233_v118215 = freeze %sollang.int_slice %v118148
  %while118233_v118214_data = extractvalue %sollang.int_slice %while118233_v118215, 0
  %while118233_v118214_length = extractvalue %sollang.int_slice %while118233_v118215, 1
  %while118233_v118214_index = sext i32 12 to i64
  %while118233_v118214_in_bounds = icmp ult i64 %while118233_v118214_index, %while118233_v118214_length
  br i1 %while118233_v118214_in_bounds, label %while118233_v118214_index_ok, label %while118233_v118214_index_fail
while118233_v118214_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118214_index_ok:
  %while118233_v118214_ptr = getelementptr i8, ptr %while118233_v118214_data, i64 %while118233_v118214_index
  %while118233_v118214 = load i8, ptr %while118233_v118214_ptr, align 1
  %while118233_v118213 = icmp eq i8 %while118233_v118214, 112
  br i1 %while118233_v118213, label %while118233_bool118250_rhs, label %while118233_exit
while118233_bool118250_rhs:
  %while118233_v118220 = freeze %sollang.int_slice %v118148
  %while118233_v118219_data = extractvalue %sollang.int_slice %while118233_v118220, 0
  %while118233_v118219_length = extractvalue %sollang.int_slice %while118233_v118220, 1
  %while118233_v118219_index = sext i32 13 to i64
  %while118233_v118219_in_bounds = icmp ult i64 %while118233_v118219_index, %while118233_v118219_length
  br i1 %while118233_v118219_in_bounds, label %while118233_v118219_index_ok, label %while118233_v118219_index_fail
while118233_v118219_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118219_index_ok:
  %while118233_v118219_ptr = getelementptr i8, ptr %while118233_v118219_data, i64 %while118233_v118219_index
  %while118233_v118219 = load i8, ptr %while118233_v118219_ptr, align 1
  %while118233_v118218 = icmp eq i8 %while118233_v118219, 180
  br i1 %while118233_v118218, label %while118233_bool118251_rhs, label %while118233_exit
while118233_bool118251_rhs:
  %while118233_v118225 = freeze %sollang.int_slice %v118148
  %while118233_v118224_data = extractvalue %sollang.int_slice %while118233_v118225, 0
  %while118233_v118224_length = extractvalue %sollang.int_slice %while118233_v118225, 1
  %while118233_v118224_index = sext i32 14 to i64
  %while118233_v118224_in_bounds = icmp ult i64 %while118233_v118224_index, %while118233_v118224_length
  br i1 %while118233_v118224_in_bounds, label %while118233_v118224_index_ok, label %while118233_v118224_index_fail
while118233_v118224_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118224_index_ok:
  %while118233_v118224_ptr = getelementptr i8, ptr %while118233_v118224_data, i64 %while118233_v118224_index
  %while118233_v118224 = load i8, ptr %while118233_v118224_ptr, align 1
  %while118233_v118223 = icmp eq i8 %while118233_v118224, 197
  br i1 %while118233_v118223, label %while118233_bool118152_rhs, label %while118233_exit
while118233_bool118152_rhs:
  %while118233_v118230 = freeze %sollang.int_slice %v118148
  %while118233_v118229_data = extractvalue %sollang.int_slice %while118233_v118230, 0
  %while118233_v118229_length = extractvalue %sollang.int_slice %while118233_v118230, 1
  %while118233_v118229_index = sext i32 15 to i64
  %while118233_v118229_in_bounds = icmp ult i64 %while118233_v118229_index, %while118233_v118229_length
  br i1 %while118233_v118229_in_bounds, label %while118233_v118229_index_ok, label %while118233_v118229_index_fail
while118233_v118229_index_fail:
  call void @llvm.trap()
  unreachable
while118233_v118229_index_ok:
  %while118233_v118229_ptr = getelementptr i8, ptr %while118233_v118229_data, i64 %while118233_v118229_index
  %while118233_v118229 = load i8, ptr %while118233_v118229_ptr, align 1
  %while118233_v118228 = icmp eq i8 %while118233_v118229, 90
  br i1 %while118233_v118228, label %while118233_body, label %while118233_exit
while118233_body:
  br label %if118233_then
while118233_exit:
  br label %if118233_else
if118233_then:
  %v118235_ptr = insertvalue %sollang.text poison, ptr @sollang_str_118235, 0
  %v118235 = insertvalue %sollang.text %v118235_ptr, i64 9, 1
  store %sollang.text %v118235, ptr %if118233_result, align 8
  br label %if118233_merge
if118233_else:
  %v118237_ptr = insertvalue %sollang.text poison, ptr @sollang_str_118237, 0
  %v118237 = insertvalue %sollang.text %v118237_ptr, i64 13, 1
  store %sollang.text %v118237, ptr %if118233_result, align 8
  br label %if118233_merge
if118233_merge:
  %v118233 = load %sollang.text, ptr %if118233_result, align 8
  %v118151_runtime_ptr = extractvalue %sollang.text %v118233, 0
  %v118151_runtime_len = extractvalue %sollang.text %v118233, 1
  call void @sollang_runtime_print(ptr %v118151_runtime_ptr, i64 %v118151_runtime_len, i1 true)
  %fixedbacking1181436_118148 = extractvalue %sollang.int_slice %v118148, 0
  call void @sollang_free(ptr %fixedbacking1181436_118148)
  call void @sollang_drop_t410(%sollang.struct.m21_s2 %v118146)
  call void @sollang_runtime_flush_stdout()
  ret i32 0
}
%sollang.legacy_int_result = type { i64, i32 }
@sollang_legacy_int_writer_buffer = internal global [8192 x i64] zeroinitializer
@sollang_legacy_int_writer_buffer_count = internal global i64 0
define internal i32 @sollang_legacy_int_copy_text_to_c_path(ptr %data, i64 %len, ptr %out) {
entry:
  %too_long = icmp ugt i64 %len, 259
  br i1 %too_long, label %fail, label %copy

copy:
  %i = phi i64 [ 0, %entry ], [ %next, %copy_body ]
  %done = icmp eq i64 %i, %len
  br i1 %done, label %nul, label %copy_body

copy_body:
  %src = getelementptr i8, ptr %data, i64 %i
  %ch = load i8, ptr %src, align 1
  %dst = getelementptr i8, ptr %out, i64 %i
  store i8 %ch, ptr %dst, align 1
  %next = add i64 %i, 1
  br label %copy

nul:
  %nul_ptr = getelementptr i8, ptr %out, i64 %len
  store i8 0, ptr %nul_ptr, align 1
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_open_write_i64_file(ptr %path, i64 %len) {
entry:
  store i64 0, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %ok = call i32 @sollang_legacy_int_platform_open_write_file(ptr %path, i64 %len)
  ret i32 %ok
}

define internal i32 @sollang_legacy_int_flush_i64_file() {
entry:
  %count = load i64, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %success, label %flush

flush:
  %bytes = mul i64 %count, 8
  %ok = call i32 @sollang_legacy_int_platform_write_file_bytes(ptr @sollang_legacy_int_writer_buffer, i64 %bytes)
  %is_ok = icmp ne i32 %ok, 0
  br i1 %is_ok, label %reset, label %fail

reset:
  store i64 0, ptr @sollang_legacy_int_writer_buffer_count, align 8
  br label %success

success:
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_write_i64_file(i64 %value) {
entry:
  %count = load i64, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %slot = getelementptr inbounds [8192 x i64], ptr @sollang_legacy_int_writer_buffer, i64 0, i64 %count
  store i64 %value, ptr %slot, align 8
  %next = add i64 %count, 1
  store i64 %next, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %full = icmp eq i64 %next, 8192
  br i1 %full, label %flush, label %success

flush:
  %ok = call i32 @sollang_legacy_int_flush_i64_file()
  ret i32 %ok

success:
  ret i32 1
}

define internal i32 @sollang_legacy_int_close_write_i64_file() {
entry:
  %flush_ok = call i32 @sollang_legacy_int_flush_i64_file()
  %flush_is_ok = icmp ne i32 %flush_ok, 0
  br i1 %flush_is_ok, label %close, label %fail

close:
  %close_ok = call i32 @sollang_legacy_int_platform_close_write_file()
  ret i32 %close_ok

fail:
  ret i32 0
}

define internal %sollang.legacy_int_result @sollang_legacy_int_closest_i64_file(i64 %target) {
entry:
  %count_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_i64_file_count()
  %count = extractvalue %sollang.legacy_int_result %count_result, 0
  %count_ok = extractvalue %sollang.legacy_int_result %count_result, 1
  %count_is_ok = icmp ne i32 %count_ok, 0
  %has_values = icmp sgt i64 %count, 0
  %can_search = and i1 %count_is_ok, %has_values
  br i1 %can_search, label %search, label %fail

search:
  br label %loop

loop:
  %low = phi i64 [ 0, %search ], [ %next_low, %step ]
  %high = phi i64 [ %count, %search ], [ %next_high, %step ]
  %active = icmp slt i64 %low, %high
  br i1 %active, label %probe, label %choose

probe:
  %span = sub i64 %high, %low
  %half = sdiv i64 %span, 2
  %mid = add i64 %low, %half
  %mid_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %mid)
  %mid_value = extractvalue %sollang.legacy_int_result %mid_result, 0
  %mid_ok = extractvalue %sollang.legacy_int_result %mid_result, 1
  %mid_is_ok = icmp ne i32 %mid_ok, 0
  br i1 %mid_is_ok, label %compare_mid, label %fail

compare_mid:
  %less = icmp slt i64 %mid_value, %target
  br i1 %less, label %move_low, label %move_high

move_low:
  %low_plus = add i64 %mid, 1
  br label %step

move_high:
  br label %step

step:
  %next_low = phi i64 [ %low_plus, %move_low ], [ %low, %move_high ]
  %next_high = phi i64 [ %high, %move_low ], [ %mid, %move_high ]
  br label %loop

choose:
  %at_start = icmp eq i64 %low, 0
  br i1 %at_start, label %read_low, label %check_end

check_end:
  %at_end = icmp eq i64 %low, %count
  br i1 %at_end, label %read_prev_only, label %read_pair

read_low:
  %first_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 0)
  ret %sollang.legacy_int_result %first_result

read_prev_only:
  %last_index = sub i64 %count, 1
  %last_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %last_index)
  ret %sollang.legacy_int_result %last_result

read_pair:
  %prev_index = sub i64 %low, 1
  %prev_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %prev_index)
  %next_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %low)
  %prev_ok = extractvalue %sollang.legacy_int_result %prev_result, 1
  %next_ok = extractvalue %sollang.legacy_int_result %next_result, 1
  %prev_is_ok = icmp ne i32 %prev_ok, 0
  %next_is_ok = icmp ne i32 %next_ok, 0
  %both_ok = and i1 %prev_is_ok, %next_is_ok
  br i1 %both_ok, label %compare_pair, label %fail

compare_pair:
  %prev_value = extractvalue %sollang.legacy_int_result %prev_result, 0
  %next_value = extractvalue %sollang.legacy_int_result %next_result, 0
  %prev_diff = sub i64 %target, %prev_value
  %next_diff = sub i64 %next_value, %target
  %prefer_prev = icmp sle i64 %prev_diff, %next_diff
  br i1 %prefer_prev, label %return_prev, label %return_next

return_prev:
  ret %sollang.legacy_int_result %prev_result

return_next:
  ret %sollang.legacy_int_result %next_result

fail:
  %fail0 = insertvalue %sollang.legacy_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.legacy_int_result %fail0, i32 0, 1
  ret %sollang.legacy_int_result %fail1
}
define internal void @sollang_legacy_int_require(i32 %status) {
entry:
  %ok = icmp ne i32 %status, 0
  br i1 %ok, label %done, label %failure
failure:
  call void @ExitProcess(i32 1)
unreachable
done:
  ret void
}
define void @sollang_m61_s0(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  %ok = call i32 @sollang_legacy_int_open_write_i64_file(ptr %data, i64 %length)
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define void @sollang_m61_s1(i32 %arg) {
entry:
  %wide = sext i32 %arg to i64
  %ok = call i32 @sollang_legacy_int_write_i64_file(i64 %wide)
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define void @sollang_m61_s2() {
entry:
  %ok = call i32 @sollang_legacy_int_close_write_i64_file()
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define void @sollang_m61_s3(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  %ok = call i32 @sollang_legacy_int_platform_open_read_file(ptr %data, i64 %length)
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define void @sollang_m61_s5() {
entry:
  %ok = call i32 @sollang_legacy_int_platform_close_read_file()
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define i32 @sollang_m61_s4(i32 %arg) {
entry:
  %wide = sext i32 %arg to i64
  %result = call %sollang.legacy_int_result @sollang_legacy_int_closest_i64_file(i64 %wide)
  %status = extractvalue %sollang.legacy_int_result %result, 1
  call void @sollang_legacy_int_require(i32 %status)
  %value = extractvalue %sollang.legacy_int_result %result, 0
  %narrow = trunc i64 %value to i32
  ret i32 %narrow
}
declare dllimport i32 @ReadFile(ptr, ptr, i32, ptr, ptr)
declare dllimport i32 @SetFilePointerEx(ptr, i64, ptr, i32)
@sollang_legacy_int_file_writer = internal global ptr null
@sollang_legacy_int_file_reader = internal global ptr null

define internal i32 @sollang_legacy_int_platform_open_write_file(ptr %path, i64 %len) {
entry:
  %buf = alloca [260 x i8], align 1
  %buf_ptr = getelementptr inbounds [260 x i8], ptr %buf, i64 0, i64 0
  %copy_ok = call i32 @sollang_legacy_int_copy_text_to_c_path(ptr %path, i64 %len, ptr %buf_ptr)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileA(ptr %buf_ptr, i32 1073741824, i32 0, ptr null, i32 2, i32 128, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  store ptr %handle, ptr @sollang_legacy_int_file_writer, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_platform_write_file_bytes(ptr %data, i64 %len64) {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_writer, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %write, label %fail

write:
  %written = alloca i32, align 4
  %len = trunc i64 %len64 to i32
  %ok = call i32 @WriteFile(ptr %handle, ptr %data, i32 %len, ptr %written, ptr null)
  %written32 = load i32, ptr %written, align 4
  %written64 = zext i32 %written32 to i64
  %write_ok = icmp ne i32 %ok, 0
  %full = icmp eq i64 %written64, %len64
  %all_ok = and i1 %write_ok, %full
  %result = zext i1 %all_ok to i32
  ret i32 %result

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_platform_close_write_file() {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_writer, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %close, label %fail

close:
  %ok = call i32 @CloseHandle(ptr %handle)
  %close_ok = icmp ne i32 %ok, 0
  br i1 %close_ok, label %success, label %fail

success:
  store ptr null, ptr @sollang_legacy_int_file_writer, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_platform_open_read_file(ptr %path, i64 %len) {
entry:
  %buf = alloca [260 x i8], align 1
  %buf_ptr = getelementptr inbounds [260 x i8], ptr %buf, i64 0, i64 0
  %copy_ok = call i32 @sollang_legacy_int_copy_text_to_c_path(ptr %path, i64 %len, ptr %buf_ptr)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileA(ptr %buf_ptr, i32 -2147483648, i32 1, ptr null, i32 3, i32 128, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  store ptr %handle, ptr @sollang_legacy_int_file_reader, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal %sollang.legacy_int_result @sollang_legacy_int_platform_i64_file_count() {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %size, label %fail

size:
  %size_ptr = alloca i64, align 8
  %ok = call i32 @GetFileSizeEx(ptr %handle, ptr %size_ptr)
  %size_ok = icmp ne i32 %ok, 0
  br i1 %size_ok, label %check, label %fail

check:
  %bytes = load i64, ptr %size_ptr, align 8
  %rem = urem i64 %bytes, 8
  %aligned = icmp eq i64 %rem, 0
  br i1 %aligned, label %success, label %fail

success:
  %count = udiv i64 %bytes, 8
  %ok0 = insertvalue %sollang.legacy_int_result poison, i64 %count, 0
  %ok1 = insertvalue %sollang.legacy_int_result %ok0, i32 1, 1
  ret %sollang.legacy_int_result %ok1

fail:
  %fail0 = insertvalue %sollang.legacy_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.legacy_int_result %fail0, i32 0, 1
  ret %sollang.legacy_int_result %fail1
}

define internal %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %index) {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %seek, label %fail

seek:
  %offset = mul i64 %index, 8
  %seek_ok = call i32 @SetFilePointerEx(ptr %handle, i64 %offset, ptr null, i32 0)
  %seek_is_ok = icmp ne i32 %seek_ok, 0
  br i1 %seek_is_ok, label %read, label %fail

read:
  %value_ptr = alloca i64, align 8
  %read_bytes = alloca i32, align 4
  %ok = call i32 @ReadFile(ptr %handle, ptr %value_ptr, i32 8, ptr %read_bytes, ptr null)
  %read_ok = icmp ne i32 %ok, 0
  %read_count = load i32, ptr %read_bytes, align 4
  %read_full = icmp eq i32 %read_count, 8
  %all_ok = and i1 %read_ok, %read_full
  br i1 %all_ok, label %success, label %fail

success:
  %value = load i64, ptr %value_ptr, align 8
  %ok0 = insertvalue %sollang.legacy_int_result poison, i64 %value, 0
  %ok1 = insertvalue %sollang.legacy_int_result %ok0, i32 1, 1
  ret %sollang.legacy_int_result %ok1

fail:
  %fail0 = insertvalue %sollang.legacy_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.legacy_int_result %fail0, i32 0, 1
  ret %sollang.legacy_int_result %fail1
}

define internal i32 @sollang_legacy_int_platform_close_read_file() {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %close, label %fail

close:
  %ok = call i32 @CloseHandle(ptr %handle)
  %close_ok = icmp ne i32 %ok, 0
  br i1 %close_ok, label %success, label %fail

success:
  store ptr null, ptr @sollang_legacy_int_file_reader, align 8
  ret i32 1

fail:
  ret i32 0
}
declare i32 @getchar()
declare dllimport i32 @GetFileSizeEx(ptr, ptr)
declare dllimport ptr @CreateFileMappingA(ptr, ptr, i32, i32, i32, ptr)
declare dllimport ptr @MapViewOfFile(ptr, i32, i32, i32, i64)
declare dllimport i32 @UnmapViewOfFile(ptr)
declare dllimport i64 @GetTickCount64()
declare dllimport void @GetSystemTimePreciseAsFileTime(ptr)
@sollang_stage2_random_state = internal global i64 88172645463325252
define void @sollang_m59_s0(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_print(ptr %data, i64 %length, i1 false)
  ret void
}
define void @sollang_m59_s1(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_print(ptr %data, i64 %length, i1 true)
  ret void
}
define i32 @sollang_m59_s2(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_print(ptr %data, i64 %length, i1 false)
  %value_slot = alloca i32, align 4
  %started_slot = alloca i1, align 1
  %negative_slot = alloca i1, align 1
  store i32 0, ptr %value_slot, align 4
  store i1 false, ptr %started_slot, align 1
  store i1 false, ptr %negative_slot, align 1
  br label %read
read:
  %character = call i32 @getchar()
  %eof = icmp eq i32 %character, -1
  br i1 %eof, label %done, label %classify
classify:
  %digit_low = icmp sge i32 %character, 48
  %digit_high = icmp sle i32 %character, 57
  %digit = and i1 %digit_low, %digit_high
  br i1 %digit, label %append, label %non_digit
append:
  %previous = load i32, ptr %value_slot, align 4
  %scaled = mul i32 %previous, 10
  %digit_value = sub i32 %character, 48
  %updated = add i32 %scaled, %digit_value
  store i32 %updated, ptr %value_slot, align 4
  store i1 true, ptr %started_slot, align 1
  br label %read
non_digit:
  %started = load i1, ptr %started_slot, align 1
  br i1 %started, label %done, label %prefix
prefix:
  %minus = icmp eq i32 %character, 45
  br i1 %minus, label %mark_negative, label %read
mark_negative:
  store i1 true, ptr %negative_slot, align 1
  br label %read
done:
  %magnitude = load i32, ptr %value_slot, align 4
  %negative = load i1, ptr %negative_slot, align 1
  %negated = sub i32 0, %magnitude
  %result = select i1 %negative, i32 %negated, i32 %magnitude
  ret i32 %result
}
define void @sollang_m67_s0(i32 %arg) {
entry:
  %seed = sext i32 %arg to i64
  store i64 %seed, ptr @sollang_stage2_random_state, align 8
  ret void
}
define i32 @sollang_m67_s1(i32 %arg) {
entry:
  %valid = icmp sgt i32 %arg, 0
  br i1 %valid, label %next, label %failure
next:
  %state = load i64, ptr @sollang_stage2_random_state, align 8
  %product = mul i64 %state, 6364136223846793005
  %updated = add i64 %product, 1442695040888963407
  store i64 %updated, ptr @sollang_stage2_random_state, align 8
  %bound = zext i32 %arg to i64
  %value = urem i64 %updated, %bound
  %result = trunc i64 %value to i32
  ret i32 %result
failure:
  ret i32 0
}

define i64 @sollang_m58_s0() {
entry:
  %value = call i64 @GetTickCount64()
  ret i64 %value
}
define i64 @sollang_m58_s1() {
entry:
  %filetime = alloca [2 x i32], align 4
  call void @GetSystemTimePreciseAsFileTime(ptr %filetime)
  %low_ptr = getelementptr inbounds [2 x i32], ptr %filetime, i64 0, i64 0
  %high_ptr = getelementptr inbounds [2 x i32], ptr %filetime, i64 0, i64 1
  %low32 = load i32, ptr %low_ptr, align 4
  %high32 = load i32, ptr %high_ptr, align 4
  %low = zext i32 %low32 to i64
  %high = zext i32 %high32 to i64
  %shifted = shl i64 %high, 32
  %ticks = or i64 %shifted, %low
  %unix_ticks = sub i64 %ticks, 116444736000000000
  %millis = udiv i64 %unix_ticks, 10000
  ret i64 %millis
}
define i8 @sollang_m58_s2() { ret i8 0 }
define void @sollang_m59_s3(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_eprint(ptr %data, i64 %length, i1 false)
  ret void
}
define void @sollang_m59_s4(%sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_eprintln(ptr %data, i64 %length)
  ret void
}
define void @sollang_m59_s5() {
entry:
  call void @sollang_runtime_flush_stdout()
  ret void
}

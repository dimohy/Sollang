from pathlib import Path
import sys,json,hashlib,time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from verification_source_proof import current_build_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/sys.argv[1];FIXTURE=ROOT/'scripts/probes/codegen-identity/type-registration-synthetic-controls.slg';MODULE=ROOT/'scripts/probes/codegen-identity/reference-synthetic-type-ids-prototype.slg';MANAGED=B/'managed21139/compiler/Sollang.Compiler.exe';NATIVE=B/'v21262/compiler-build01/compiler.exe';EXPECTED=(B/'typeid21296-controls.expected').read_text()
inputs=[Path(__file__),FIXTURE,MODULE,B/'typeid21296-controls.expected',*managed_runtime_inputs(MANAGED),NATIVE,NATIVE.parent/'result.json',*sorted((ROOT/'stdlib').rglob('*.slg'))]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert sha(MANAGED.with_suffix('.dll'))=='B838CF7C48EF32FFA96ACA2D6B8197645AF8C070D30C48C233DDE65A94FA991E';assert sha(NATIVE)=='C1CA82328D0912F0181B6CCB8B893632727D8A2A9B946B09ADFCCFF080775D52'
inputs+=current_build_inputs(ROOT,json.loads((NATIVE.parent/'result.json').read_text()));inputs=list(dict.fromkeys(inputs));hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21262']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=2,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Research synthetic registration actual SLG execution compiled by CSharp and current Native; eight structural positive/rejection controls; not production ABI diagnostic qualification',claimsGoalComplete=False)
 run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  for label,compiler in [('managed',MANAGED),('native',NATIVE)]:
   d=OUT/label;d.mkdir();start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start))
   built=run.run([str(compiler),'build',str(FIXTURE),str(MODULE),'-o',str(d/'probe.exe'),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0','--keep-temps'],d/'build',timeout=budget())
   assert built.returncode==0 and not built.stderr,built.stdout[-2000:]+built.stderr
   done=run.run([str(d/'probe.exe')],d/'run',timeout=budget());passed=done.returncode==0 and not done.stderr and done.stdout==EXPECTED
   result['cases'].append(dict(id=label,passed=passed,buildExit=built.returncode,runExit=done.returncode,lines=len(done.stdout.splitlines()),wholeCaseElapsedSeconds=time.monotonic()-start));result['completed']+=int(passed);run.save();assert passed,done.stdout[:700]+done.stderr
  result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','cases','inputsStable','processesStopped']},indent=2))

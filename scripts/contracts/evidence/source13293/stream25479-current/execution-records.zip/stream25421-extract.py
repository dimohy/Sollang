from pathlib import Path
import textwrap,re,json,hashlib
R=Path.cwd();O=R/'artifacts/scratch/resume-20261006-owner-continuation22/stream25421';names=['src/Sollang.Compiler/Shared/Policies/NativeRuntimePolicy.cs','src/Sollang.Compiler/CodeGen/LlvmRuntimePlatform.cs','src/Sollang.Compiler/CodeGen/WindowsLlvmRuntimePlatform.cs','src/Sollang.Compiler/CodeGen/LinuxLlvmRuntimePlatform.cs','selfhost/llvm/emitter/stream_join_runtime.slg','selfhost/llvm/runtime.slg']
for n in names:
 p=O/'before-source'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/n).read_bytes())
texts={n:(R/n).read_text(encoding='utf-8-sig') for n in names};values={}
for n,marker,methods in [(names[1],'    private static void EmitConcurrentStreamJoinCommonPrimitives',['StreamJoinWorkerFunctions','StreamJoinLifecycleFunctions']),(names[2],'    protected override void EmitConcurrentStreamJoinPlatformPrimitives',['StreamJoinWindowsFunctions']),(names[3],'    protected override void EmitConcurrentStreamJoinPlatformPrimitives',['StreamJoinLinuxFunctions'])]:
 s=texts[n];start=s.index(marker);m=re.search(r'\n    (?:public|private|protected) [^\n]*\(',s[start+1:]);assert m;end=start+1+m.start();old=s[start:end];matches=re.findall(r'functions.AppendLine\("""\n(.*?)            """\);',old,re.S);assert len(matches)==1;literal=textwrap.dedent(matches[0]);parts=[literal.rstrip('\n')]
 if len(methods)==2:
  split=literal.index('define internal ptr @sollang_stream_join_runtime_create(');parts=[literal[:split].rstrip('\n'),literal[split:].rstrip('\n')]
 assert '\n\n'.join(parts)+'\n\n'==literal,(n,repr(literal[-10:]));header=old[:old.index('    {')];new=header+'    {\n'+''.join('        functions.AppendLine(NativeRuntimePolicy.'+method+'());\n        functions.AppendLine();\n' for method in methods)+'    }\n'
 s=s[:start]+new+s[end:]
 if 'using Sollang.Compiler.Shared;' not in s:s=s.replace('using System.Text;','using System.Text;\nusing Sollang.Compiler.Shared;',1)
 texts[n]=s
 for method,part in zip(methods,parts):values[method]=part
for n,method in [(names[2],'StreamJoinWindowsDeclarations'),(names[3],'StreamJoinLinuxDeclarations')]:
 s=texts[n];pattern=r'(        if \(UsesConcurrentStreamJoins\)\n        \{\n)(.*?)(        \})';matches=list(re.finditer(pattern,s,re.S));assert len(matches)==1;nested=matches[0];block=nested[2];lines=re.findall(r'            functions.AppendLine\("([^"\n]+)"\);\n',block);assert len(lines) in (4,5) and ''.join('            functions.AppendLine("'+x+'");\n' for x in lines)==block;values[method]='\n'.join(lines);texts[n]=s[:nested.start(2)]+'            functions.AppendLine(NativeRuntimePolicy.'+method+'());\n'+s[nested.end(2):]
policy=texts[names[0]];addition='\n    // Bounded concurrent joins share the same platform and lifecycle instructions.\n'
for name,text in values.items():
 assert 0<len(text)<=16384,(name,len(text));addition+='\n    public static string '+name+'() =>\n        """\n'+textwrap.indent(text,'        ')+'\n        """;\n'
assert policy.endswith('}\n');texts[names[0]]=policy[:-2]+addition+'}\n'
for n in names[:4]:(R/n).write_text(texts[n],encoding='utf-8',newline='\n')
(O/'csharp-extraction.json').write_text(json.dumps(dict(status='csharp-only-extracted',literalCharacters={n:len(v) for n,v in values.items()},slgUnchanged=True,sourceHashes={n:hashlib.sha256((R/n).read_bytes()).hexdigest().upper() for n in names}),indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({n:len(v) for n,v in values.items()}))

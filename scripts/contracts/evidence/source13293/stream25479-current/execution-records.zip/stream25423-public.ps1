param([Parameter(Mandatory)][string]$Compiler,[Parameter(Mandatory)][string]$Output)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath('W:\MyWorks\Sollang')
. (Join-Path $repo 'scripts/verification-process.ps1')
. (Join-Path $repo 'scripts/verification-compiler-build.ps1')
foreach($target in @('windows-x64','linux-x64')) {
 $directory=Join-Path $Output $target;[IO.Directory]::CreateDirectory($directory) | Out-Null
 $built=Invoke-VerificationCompilerBuild -Compiler $Compiler -Source (Join-Path $repo 'examples/regression/809-event-stream-merge-bounded-runtime.slg') -Output (Join-Path $directory 'probe.exe') -Target $target -WorkingDirectory $repo -Description "stream-join-public-$target" -TimeoutMilliseconds 180000
 if($built.ExitCode -ne 0 -or -not [string]::IsNullOrWhiteSpace($built.Stderr)) {throw "STREAM_JOIN_PUBLIC_BUILD:$target`:$($built.Stderr)"}
 Write-Host "Public $target stream join build: PASS"
}

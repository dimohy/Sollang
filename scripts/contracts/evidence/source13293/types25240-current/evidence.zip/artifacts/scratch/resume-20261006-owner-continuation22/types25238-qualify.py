from pathlib import Path
import json,copy,sys,hashlib,importlib.util,datetime
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/types25240-current'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
write=lambda p,d:Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
detail=read(B/'types25237-detail-before.json');assert detail==read(R/'scripts/contracts/structural-parity-detail.json')
sys.path.insert(0,str(R/'scripts'));s=importlib.util.spec_from_file_location('audit',R/'scripts/audit-structural-source-connections.py');a=importlib.util.module_from_spec(s);s.loader.exec_module(a)
semantic=next(p for p in detail['phaseProgress'] if p['phase']=='semantic-analysis');inv=next(p for p in detail['phaseProgress'] if p['phase']=='type-commit')['decisionInventory']
typeids='selfhost/semantic/type_ids.slg';paired=read(E/'paired-result.json')
assert paired['inputHashes'][str(R/typeids)]==sha(R/typeids)
write(E/'type-commit-source-association.json',dict(source=typeids,sha256=sha(R/typeids),locations=['implTypePaths:646','implOwnerTypeId:675','resolveAnalyzed:1727'],consumer='selfhost/llvm/emitter/diagnostics.slg:signatureTypeId, traitImplementationReceiverTypeId, traitImplementationDeclarationDiagnostics',decision='The committed TypeReference is selected by sourceModule and typeAst with status0. Impl owner/trait AST paths come from type_ids.implTypePaths. Receiver and associated value types consume the resolved type table before trait admission.',pairedInputVerified=True))
ids=['semantic.standard-enum-constructor-generic-owner','semantic.trait-implementation-declaration-admission']
for oldid in ids:
 d=next(d for d in semantic['decisionInventory']['decisions'] if d['id']==oldid)
 if oldid==ids[1]:
  d['structure']='CSharp DeclareTraitImplementations enumerates declarations before methods. Current SLG traitImplementationDeclarationDiagnostics traverses impl declarations(kind6) independently of methods and runs before traitSignatureDiagnostics method checks.'
  d['logic']='Trait visibility precedes receiver admission. Associated value types resolve before unknown/missing binding names. Both paths register canonical trait/receiver bindings, reuse identical repeats and reject conflicting bindings; declaration admission is independent of method presence.'
  d['completionScope']='11 unchanged declaration cases: three valid, six declaration errors, two type-parse priorities. All eight current negative locations/messages and pre-LLVM rejections match. Required-method inventory remains covered by its separate existing decision.'
 for k,f in [('qualification','qualification.json'),('currentQualification','qualification.json'),('sourceComparisonRecord','source-comparison.json'),('managedFirstRecord','managed-result.json'),('pairedRecord','paired-result.json')]:d[k]=(E/f).relative_to(R).as_posix()
 if oldid==ids[1]:d['negativePairedRecord']=(E/'paired-result.json').relative_to(R).as_posix()
 d['evidenceEpoch']='current-types25240-constructor-and-trait-commitments';new=copy.deepcopy(d);new['id']=oldid.replace('semantic.','type-commit.',1)
 allsources=list(dict.fromkeys([*new['managedSources'],*new['selfhostSources'],*new.get('supportingSources',[]),*([typeids] if oldid==ids[1] else [])]));support=[]
 for side,ext in [('managed','.cs'),('selfhost','.slg')]:
  allowed=a.phase_source_files(R,'type-commit',inv,side,ext);new[side+'Sources']=[n for n in allsources if n.endswith(ext) and n in allowed];support.extend(n for n in allsources if n.endswith(ext) and n not in allowed)
 new['supportingSources']=support
 if oldid==ids[1]:
  new['structure']='CSharp ParseType commits receiver and associated binding types before trait binding checks. SLG type_ids resolves the corresponding source/typeAst TypeReferences, implTypePaths selects the exact owner/trait ASTs, and declaration diagnostics consumes those committed IDs before name/conflict checks.'
  new['sourceAssociationRecord']=(E/'type-commit-source-association.json').relative_to(R).as_posix()
 inv['decisions'].append(new);inv['requiredDecisionIds'].append(new['id'])
audit=a.audit_source_connections(detail,R);count=sum(v['named'] for p in audit['phases'] for v in p['coverage'].values());assert count==509,count
write(R/'scripts/contracts/structural-parity-detail.json',detail);write(E/'source-association.json',audit)
q=dict(schemaVersion=1,status='current-constructor-and-trait-type-commit-focused-qualified-final-gates-pending',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),focused=dict(completed=26,total=26,percentage=100.0,managed=13,native=13,positiveCasesPerSide=5,negativeCasesPerSide=8),sourceHashes={**read(E/'source-comparison.json')['sourceHashes'],typeids:sha(R/typeids)},scope='Original generic Option/Result owner constructors and trait declaration admission; exact frozen output/location/error priority and rejection before LLVM. No new compiler behavior or phase completion claim.',associated=dict(completed=509,total=712,percentage=round(509/712*100,2),remaining=203,newAssociations=2,unit='phase-source associations, not unique physical files'),compilerStabilization=dict(completed=363,total=793,percentage=45.78),sourcePhases=dict(completed=0,total=7),compilerProducerBuilds=0,original1999Runs=0,wholeProfileRuns=0,inputsStable=True,processesStopped=True,failures=dict(current=0,preparation='Two association drafts rejected before authoritative file writes: now-owned dependency left as supporting; then a declaration consumer lived outside the phase scope. Read actual signatureTypeId/implTypePaths and linked its committed source reference producer. Frozen scopes and source denominator unchanged.'),claimsPhaseComplete=False,claimsGoalComplete=False)
for k,f in [('sourceComparisonRecord','source-comparison.json'),('managedFirstRecord','managed-result.json'),('pairedRecord','paired-result.json')]:q[k]=(E/f).relative_to(R).as_posix()
write(E/'qualification.json',q)
g=read(B/'types25237-goal-before.json');assert g==read(R/'scripts/contracts/active-goal-progress.json')
g.update(currentFocusedGate='types25240-focused26',currentFocusedGateDescription=q['scope'],currentFocusedGateScope=q['scope'],currentTypeCommitConstructorTraitUnit=dict(status='focused-qualified-final-gates-pending',completed=26,total=26,percentage=100.0,qualification=(E/'qualification.json').relative_to(R).as_posix(),claimsGoalComplete=False))
g['currentSourceAssociationIntake'].update(qualification=(E/'qualification.json').relative_to(R).as_posix(),associationCompleted=509,associationPercentage=round(509/712*100,2),remainingAssociations=203,registeredDecisionsRetained=sum(len(p['decisionInventory']['decisions']) for p in detail['phaseProgress']),addedSourceAssociations=2)
g['focusedGates'].append(dict(name='types25240-focused26',status='complete',completed=26,total=26,percentage=100.0,failed=0,running=0,unexecuted=0,scope=q['scope'],evidence=(E/'qualification.json').relative_to(R).as_posix()))
g['currentNextTypeCommitDecision']=dict(source='selfhost/semantic/reference_type_ids.slg:nameOf and intrinsicIdentity',observation='Hand-copied CSharp TypeId names/IDs remain in SLG compatibility identities. No current runtime mismatch claimed.',nextAction='CSharp compiled-enum exporter proof, source comparison, generated SLG consumer integration, then actual TypeId and library ABI paired controls. Reuse the existing compiled policy exporter.')
write(R/'scripts/contracts/active-goal-progress.json',g)
print('qualified26/26; associated509/712; remaining203')

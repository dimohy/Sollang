from pathlib import Path
import json,hashlib
B=Path(__file__).resolve().parent
results=[]
for case in ['readonly','struct','fixed-array']:
 observation=B/'typeid21280-definition-observer'/(case+'.stdout')
 rows=[x.split('\t') for x in observation.read_text(encoding='utf-8').splitlines()]
 declarations={(int(x[2]),int(x[3])):x[4] for x in rows if x[0]=='N'}
 types={int(x[1]):list(map(int,x[2:])) for x in rows if x[0]=='T'}
 nominalPath=B/'typeid21265-native-nominal3'/(case+'.stdout')
 nominals={k:int(v) for k,v in (x.split('\t') for x in nominalPath.read_text(encoding='utf-8').splitlines()) if k!='next'}
 boxPath=B/'typeid21272-native-box3'/(case+'.stdout')
 nextId=int(boxPath.read_text(encoding='utf-8').splitlines()[-1].split('\t')[1])
 registered={};cache={};created=[]
 builtin=[0,1,2,4,5,2,6,6,7,8,9,10,11,12,13,15,14,16,17,18,18,19,19,3,31,43]
 def resolve(i):
  global nextId
  if i in cache:return cache[i]
  kind,origin,module,symbol,first,second,length=types[i]
  if kind==1 and origin==1:answer=builtin[symbol]
  elif kind==1 and origin in [0,2]:answer=nominals[declarations[(module,symbol)]]
  else:
   element=resolve(first)
   if kind==3:
    if element==2:answer=23
    elif element==7:answer=36
    elif element==39:answer=40
    else:answer=None
    shape=('dynamic',element)
   elif kind==4:
    answer={(7,12):47,(7,16):48,(7,32):49}.get((element,length));shape=('fixed',element,length)
   elif kind==8:answer=None;shape=('ref',element)
   elif kind==7 and origin==4 and symbol==0:answer=None;shape=('option',element)
   elif kind==7 and origin==4 and symbol==1:answer=None;shape=('result',element,resolve(second))
   else:raise ValueError((i,types[i]))
   if answer is None:
    if shape not in registered:registered[shape]=nextId;created.append(dict(id=nextId,type=i,shape=shape));nextId+=1
    answer=registered[shape]
  cache[i]=answer;return answer
 fields=[x for x in rows if x[0]=='F']
 for name in ['sys.directory.RawResult','sys.directory.ReadResult']:
  owner=next(k for k,v in declarations.items() if v==name)
  payload=[resolve(int(x[5])) for x in fields if (int(x[2]),int(x[3]))==owner]
  assert len(payload)==2
  registered[('result',*payload)]=nominals[name]
 for kind in [3,4]:
  for x in fields:
   if int(x[1])==kind:resolve(int(x[5]))
 oracle=json.loads((B/'typeid21281-shape-trace'/(case+'.stdout')).read_text(encoding='utf-8'))['before']
 expectedIds=set(v for v in oracle['names'].values() if min(x['id'] for x in created)<=v)
 actualIds={x['id'] for x in created}
 result=dict(id=case,created=created,nextAfterDefinitions=nextId,csharpAfterConstructor=oracle['next'],unverifiedConstructorTail=oracle['next']-nextId,allocatedNamedIdRangeMatches=actualIds==expectedIds,inputHashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest().upper() for p in [observation,nominalPath,boxPath,B/'typeid21281-shape-trace'/(case+'.stdout'),Path(__file__)]})
 results.append(result)
 print(case,'created',len(created),'next',nextId,'constructorTail',result['unverifiedConstructorTail'],'rangeMatches',result['allocatedNamedIdRangeMatches'])
(B/'typeid21284-definition-model.json').write_text(json.dumps(dict(schemaVersion=1,scope='research model of CSharp definition allocation order from SLG observed references; not SLG implementation or production verification',cases=results,claimsGoalComplete=False),indent=2)+'\n',encoding='utf-8')

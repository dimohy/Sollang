from pathlib import Path
import sys,json,hashlib,time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/sys.argv[1];compiler=B/(sys.argv[2] if len(sys.argv)>2 else 'managed21139/compiler/Sollang.Compiler.exe');fixture=ROOT/'scripts/probes/codegen-identity/declared-fragment-records.slg';module=ROOT/'selfhost/llvm/codegen_units.slg';oracle=B/'codegen21332-csharp-records/result.json';r=json.loads(oracle.read_text());assert r['status']=='passed' and r['completed']==r['total']==25 and r['inputsStable'] and r['processesStopped'];rows=[c['observation'] for c in r['cases'] if c['id'].startswith('declared-record-')];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();inputs=[Path(__file__),compiler,*managed_runtime_inputs(compiler),fixture,module,oracle,ROOT/'src/Sollang.Compiler/Cli/IncrementalCodegenCache.cs'];hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=6,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Actual SLG codec validate/decode/merge on six exact24-word CSharp-produced artifacts, no oversized payload allocated. Selected Native compiler if any is an explicitly retained seed, not a current full compiler source claim.',claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None;start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start))
 try:
  done=run.run([str(compiler),'build',str(fixture),str(module),'-o',str(OUT/'probe.exe'),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0','--keep-temps'],OUT/'build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout[-2000:]+done.stderr;done=run.run([str(OUT/'probe.exe')],OUT/'run',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout+done.stderr;lines=done.stdout.splitlines();assert len(lines)==6
  for row,line in zip(rows,lines):
   label=str(row['declaredFragmentBytes']);expected=label+'='+('0,0,0' if row['accepted'] else '7,7,7');passed=line==expected;result['cases'].append(dict(id=label,passed=passed,expected=expected,actual=line,csharpAccepted=row['accepted'],runExit=0));result['completed']+=int(passed)
  result['status']='passed' if result['completed']==result['total'] else 'failed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','cases','inputsStable','processesStopped']},indent=2))

from pathlib import Path
import sys,json,hashlib,time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'codegen21342-related8';intentPath=B/'codegen21029-controls-intent.json';intent=json.loads(intentPath.read_text());compilers=[('managed',B/'managed21139/compiler/Sollang.Compiler.exe'),('retained-native',B/'v21323/compiler-build01/compiler.exe')];inputs=[Path(__file__),intentPath,*[p for _,p in compilers],*managed_runtime_inputs(compilers[0][1]),compilers[1][1].parent/'result.json',ROOT/'selfhost/llvm/codegen_units.slg',*[ROOT/c['source'] for c in intent['cases']],*sorted((ROOT/'stdlib').rglob('*.slg'))];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();hashes={str(p):sha(p) for p in inputs};assert sha(compilers[1][1])==json.loads((compilers[1][1].parent/'result.json').read_text())['compilerSha256'];initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False)
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=8,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Unchanged four codec related controls on CSharp then retained Native seed compiling the isolated changed source. No current full Native or whole phase claim.',claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  for role,compiler in compilers:
   for case in intent['cases']:
    d=OUT/(role+'-'+case['id']);d.mkdir();start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));done=run.run([str(compiler),'build',str(ROOT/case['source']),*[str(ROOT/s) for s in case['additionalSources']],'-o',str(d/'probe.exe'),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0','--keep-temps'],d/'build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout[-1200:]+done.stderr;built=done.returncode;done=run.run([str(d/'probe.exe')],d/'run',timeout=budget());expected=case['stdout'] if case['stdout'].endswith('\n') else case['stdout']+'\n';passed=done.returncode==case['exit'] and done.stderr==case['stderr'] and done.stdout==expected;result['cases'].append(dict(id=role+'-'+case['id'],passed=passed,buildExit=built,runExit=done.returncode,stdout=done.stdout,expected=expected));result['completed']+=int(passed);run.save();assert passed,done.stdout+done.stderr
  result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

from pathlib import Path
import sys,json,hashlib,importlib.util,re
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'source25015-validation'
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import initialize_output,cleanup_output
spec=importlib.util.spec_from_file_location('audit',R/'scripts/audit-structural-source-connections.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a);detail=a.DETAIL.read('scripts/contracts/structural-parity-detail.json')
paths=[Path(__file__),R/'scripts/verify-structural-parity-detail.py',R/'scripts/audit-structural-source-connections.py',R/'scripts/test-structural-phase-closure.py',R/'scripts/contracts/structural-parity-detail.json',B/'source25013-before.json',B/'source25013-facts.json',R/'scripts/contracts/evidence/source13293/windowslink24945-current/source-review-reconciliation.json',R/'scripts/contracts/evidence/source13293/dyn24658-current/source-review-reconciliation.json']
for row in detail['phaseProgress']:
 for side,ext in [('managed','.cs'),('selfhost','.slg')]:
  paths += [R/p for p in a.phase_source_files(R,row['phase'],row['decisionInventory'],side,ext)]
 for d in row['decisionInventory']['decisions']:paths += [R/p for p in d.get('supportingSources',[])]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();pins={str(p.resolve()):sha(p) for p in paths};reusable=[B/'return25002-native',B/'product24976-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reusable);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=3,inputHashes=pins,cases=[],claimsPhaseComplete=False,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  x=ex.run([sys.executable,'-B',str(R/'scripts/test-structural-phase-closure.py')],O/'tests',timeout=60);assert x.returncode==0 and re.search(r'Ran 112 tests',x.stderr),(x.stdout,x.stderr);result['cases'].append(dict(id='phase-closure-controls112',passed=True,tests=112));result['completed']+=1;ex.save()
  x=ex.run([sys.executable,'-B',str(R/'scripts/audit-structural-source-connections.py')],O/'source-connections',timeout=30);assert x.returncode==0,x.stderr;observed=json.loads(x.stdout);assert observed['completed']==0 and observed['total']==6 and not observed['claimsPhaseComplete'];result['sourceConnections']=observed;result['cases'].append(dict(id='complete-intake-without-false-phase-credit',passed=True));result['completed']+=1;ex.save()
  x=ex.run([sys.executable,'-B',str(R/'scripts/verify-structural-parity-detail.py'),'--phase-closure-only'],O/'phase-closure',timeout=30);assert x.returncode==0 and '0/7' in x.stdout,(x.stdout,x.stderr);result['cases'].append(dict(id='seven-full-phases-retain-zero-credit',passed=True));result['completed']+=1;result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reusable)
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

from pathlib import Path
import json,hashlib,zipfile,datetime,subprocess
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/source25016-current'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();write=lambda p,d:Path(p).write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
result=read(B/'source25015-validation/result.json');assert result['status']=='passed' and result['completed']==result['total']==3 and result['inputsStable'] and result['processesStopped'];assert all(sha(p)==h for p,h in result['inputHashes'].items())
facts=read(B/'source25013-facts.json');assert len(facts['files'])==26
for f in facts['files']:
 review=read(R/f['completeFileReview']['path']);assert sha(R/f['path'])==f['sha256']==review['sources'][f['path']]['currentSha256']
detail=read(R/'scripts/contracts/structural-parity-detail.json');before=read(B/'source25013-before.json');indexed=read(B/'source25013-index.json');assert detail['phaseProgress']==indexed['phaseProgress'];assert [r['decisionInventory']['sourceScopes'] for r in before['phaseProgress']]==[r['decisionInventory']['sourceScopes'] for r in detail['phaseProgress']]
oldids={d['id'] for r in before['phaseProgress'] for d in r['decisionInventory']['decisions']};ids={d['id'] for r in detail['phaseProgress'] for d in r['decisionInventory']['decisions']};assert oldids==ids and len(ids)==179
audit=result['sourceConnections'];completed=sum(v['named'] for r in audit['phases'] for v in r['coverage'].values());total=sum(v['actual'] for r in audit['phases'] for v in r['coverage'].values());assert (completed,total)==(450,712)
E.mkdir();write(E/'validation.json',result);write(E/'source-connections.json',audit);write(E/'source-comparison.json',facts)
entries={}
def add(p,label=None):
 p=Path(p);entries[label or p.relative_to(R).as_posix()]=p.read_bytes()
for p in [Path(__file__),*[B/x for x in ['source25013-before.json','source25013-index.json','source25013-facts.json','source25015-validation.py']],*[R/f['path'] for f in facts['files']],*[R/p for p in ['src/Sollang.Compiler/Cli/IncrementalCodegenCache.cs','src/Sollang.Compiler/Semantics/SemanticStableIdentity.cs','src/Sollang.Compiler/Semantics/BoundProgram.cs','src/Sollang.Compiler/Shared/Policies/CodegenCacheKeyPolicy.cs','selfhost/llvm/text/context_prepare.slg','scripts/contracts/evidence/source13293/windowslink24945-current/source-review-reconciliation.json','scripts/contracts/evidence/source13293/dyn24658-current/source-review-reconciliation.json','scripts/audit-structural-source-connections.py','scripts/verify-structural-parity-detail.py','scripts/test-structural-phase-closure.py']]]:add(p)
for p in (B/'source25015-validation').rglob('*'):
 if p.is_file():add(p)
archive=E/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,raw in sorted(entries.items()):z.writestr(n,raw)
with zipfile.ZipFile(archive) as z:
 for n,raw in entries.items():assert z.read(n)==raw
write(E/'archive-manifest.json',dict(sha256=sha(archive),readbackVerified=True,entries={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest().upper()) for n,raw in sorted(entries.items())}))
projection=hashlib.sha256(json.dumps(detail['phaseProgress'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest().upper()
q=dict(schemaVersion=1,status='current-source-responsibilities-associated-full-phase-proof-pending',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Same frozen six non-parsing (phase,compiler side,file) association slots; current source facts and unchanged whole-file review reuse only.',associated=dict(completed=completed,total=total,percentage=round(completed/total*100,2),remaining=total-completed),previousAssociated=dict(completed=424,total=712),addedSourceAssociations=26,registeredDecisionsRetained=179,frozenScopesUnchanged=True,selectedCompleteFileReviews=dict(completed=26,total=26,method='Exact-byte review reuse; current API/consumer inspection. Not new compiler execution or complete branch parity.'),newSourceSupportingInputs=['src/Sollang.Compiler/Semantics/BoundProgram.cs','src/Sollang.Compiler/Semantics/SemanticStableIdentity.cs'],controls=dict(completed=112,total=112),integrationChecks=dict(completed=3,total=3),sourceComparison='source-comparison.json',sourceConnections='source-connections.json',fullSourcePhases=dict(completed=0,total=7,percentage=0.0),phaseInventoryProjectionSha256=projection,archive=dict(path='evidence.zip',sha256=sha(archive),entries=len(entries),readbackVerified=True),nativeBuilds=0,newCompilerRuntimeChecks=0,original1999Runs=0,claimsWholePhaseComplete=False,claimsGoalComplete=False)
write(E/'qualification.json',q);print(json.dumps(dict(status=q['status'],associated=q['associated'],archiveEntries=len(entries))))

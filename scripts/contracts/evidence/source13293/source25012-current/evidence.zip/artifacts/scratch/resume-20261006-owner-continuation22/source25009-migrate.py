from pathlib import Path
import json,sys,copy,importlib.util
r=Path.cwd();sys.path.insert(0,str(r/'scripts'));spec=importlib.util.spec_from_file_location('audit',r/'scripts/audit-structural-source-connections.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
b=r/'artifacts/scratch/resume-20261006-owner-continuation22';raw=(r/'scripts/contracts/structural-parity-detail.json').read_bytes();d=json.loads(raw.decode('utf-8-sig'));before=copy.deepcopy(d)
rows={x['phase']:x for x in d['phaseProgress']};src=rows['semantic-analysis']['decisionInventory'];dst=rows['llvm-generation']['decisionInventory'];identity='semantic.compiled-cache-policy-runtime';decision=next(x for x in src['decisions'] if x['id']==identity);src['decisions'].remove(decision);src['requiredDecisionIds'].remove(identity);dst['decisions'].append(decision);dst['requiredDecisionIds'].append(identity)
changed=[]
for row in d['phaseProgress']:
 for side,ext in [('managed','.cs'),('selfhost','.slg')]:
  owned=a.phase_source_files(r,row['phase'],row['decisionInventory'],side,ext)
  for x in row['decisionInventory']['decisions']:
   old=x[side+'Sources'];outside=[p for p in old if p not in owned]
   if outside:
    supporting=x.setdefault('supportingSources',[])
    for p in outside:
     if p not in supporting:supporting.append(p)
    x[side+'Sources']=[p for p in old if p in owned];changed.append(dict(phase=row['phase'],decision=x['id'],side=side,sources=outside))
   assert x[side+'Sources'],(row['phase'],x['id'],side)
def links(v):return {x['id']:set(x['managedSources'])|set(x['selfhostSources'])|set(x.get('supportingSources',[])) for row in v['phaseProgress'] for x in row['decisionInventory']['decisions']}
assert links(before)==links(d)
assert [x['decisionInventory']['sourceScopes'] for x in before['phaseProgress']]==[x['decisionInventory']['sourceScopes'] for x in d['phaseProgress']]
assert len(links(d))==179
result=a.audit_source_connections(d,r)
(b/'source25009-before.json').write_bytes(raw)
(b/'source25009-candidate.json').write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
(b/'source25009-audit.json').write_bytes((json.dumps(result,indent=2)+'\n').encode('utf-8'))
(b/'source25009-migration.json').write_bytes((json.dumps(dict(status='candidate-source-classification-only',decisionsRetained=179,sourceLinksRetained=True,frozenScopesUnchanged=True,movedDecision=dict(id=identity,fromPhase='semantic-analysis',toPhase='llvm-generation',reason='Generated cache arithmetic/key policies are consumed by selfhost/llvm/codegen_cache_keys.slg; there is no semantic consumer.'),supportingLinks=changed,claimsPhaseComplete=False,claimsGoalComplete=False),indent=2)+'\n').encode('utf-8'))
print(json.dumps(dict(decisions=179,supportingOccurrences=sum(len(x['sources']) for x in changed),sourceConnectionPhases=result['completed'],total=result['total'],missing={x['phase']:{s:len(v['missing']) for s,v in x['coverage'].items()} for x in result['phases']})))

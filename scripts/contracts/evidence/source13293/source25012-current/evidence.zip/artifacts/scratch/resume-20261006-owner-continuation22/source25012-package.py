from pathlib import Path
import json,hashlib,zipfile,subprocess,datetime
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/source25012-current'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
write=lambda p,d:Path(p).write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
result=read(B/'source25010-validation/result.json');assert result['status']=='passed' and result['completed']==result['total']==3 and result['inputsStable'] and result['processesStopped'];assert all(sha(p)==h for p,h in result['inputHashes'].items())
detail=read(R/'scripts/contracts/structural-parity-detail.json');indexed=read(B/'source25009-index.json');assert detail['phaseProgress']==indexed['phaseProgress'];audit=result['sourceConnections'];completed=sum(v['named'] for row in audit['phases'] for v in row['coverage'].values());total=sum(v['actual'] for row in audit['phases'] for v in row['coverage'].values());assert (completed,total)==(424,712);assert audit['completed']==0 and audit['total']==6
E.mkdir();write(E/'validation.json',result);write(E/'source-connections.json',audit);write(E/'migration.json',read(B/'source25009-migration.json'))
entries={}
def add(p,label=None):
 p=Path(p);entries[label or p.relative_to(R).as_posix()]=p.read_bytes()
changed=['scripts/verify-structural-parity-detail.py','scripts/audit-structural-source-connections.py','scripts/test-structural-phase-closure.py']
for p in [Path(__file__),*[R/x for x in changed],*[B/x for x in ['source25009-before.json','source25009-candidate.json','source25009-index.json','source25009-migrate.py','source25010-validation.py']]]:add(p)
for name in changed:entries['before-source/'+name]=subprocess.run(['git','show','HEAD:'+name],capture_output=True,check=True).stdout
for p in (B/'source25010-validation').rglob('*'):
 if p.is_file():add(p)
archive=E/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,raw in sorted(entries.items()):z.writestr(n,raw)
with zipfile.ZipFile(archive) as z:
 for n,raw in entries.items():assert z.read(n)==raw
write(E/'archive-manifest.json',dict(sha256=sha(archive),entries={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest().upper()) for n,raw in sorted(entries.items())},readbackVerified=True))
projection=hashlib.sha256(json.dumps(detail['phaseProgress'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest().upper()
q=dict(schemaVersion=1,status='source-dependencies-classified-owned-associations-incomplete',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Existing frozen six non-parsing phase/file associations; each (phase, compiler side, file) is one slot. Independent of whole-file/branch parity and compiler acceptance.',associated=dict(completed=completed,total=total,percentage=round(completed/total*100,2),remaining=total-completed),registeredDecisionsRetained=179,crossPhaseDependencyOccurrencesReclassified=40,existingSupportingOccurrencesValidated=4,allExistingSourceLinksRetained=True,frozenScopesUnchanged=True,movedDecision=read(B/'source25009-migration.json')['movedDecision'],dependencyValidation='Existing supportingSources lists are validated separately from owned files. Supporting inputs must appear in complete source comparison and both compiler proof hashes. Owned-source coverage and fixed scopes remain mandatory.',controls=dict(completed=112,total=112,evidence='validation.json'),integrationChecks=dict(completed=3,total=3,evidence='validation.json'),fullSourcePhases=dict(completed=0,total=7,percentage=0.0),sourceConnectionPhases=dict(completed=0,total=6,percentage=0.0),phaseInventoryProjectionSha256=projection,sourceConnections='source-connections.json',archive=dict(path='evidence.zip',sha256=sha(archive),entries=len(entries),readbackVerified=True),nativeBuilds=0,original1999Runs=0,claimsWholePhaseComplete=False,claimsGoalComplete=False)
write(E/'qualification.json',q);print(json.dumps(dict(status=q['status'],associated=q['associated'],controls=q['controls'],archiveEntries=len(entries))))

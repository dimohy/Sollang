from pathlib import Path
import datetime, hashlib, json, subprocess, zipfile
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/ownership24969-current'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
write=lambda p,d:Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
records={'csharpBase':'ownership24953-csharp','csharpTail':'ownership24962-csharp-tail','nativePair':'ownership24968-native','semantic':'ownership24965-semantic','managedBuild':'ownership24952-managed','nativeBuild':'ownership24967-native'}
data={k:read(B/v/'result.json') for k,v in records.items()}
for d in data.values():assert d['status']=='passed' and d['completed']==d['total'] and d['inputsStable'] and d['processesStopped']
managed=data['csharpBase']['cases']+data['csharpTail']['cases'];native=data['nativePair']['cases'];assert len(managed)==len(native)==10
by_source={x['source']:x for x in managed};comparisons=[]
for n in native:
 m=by_source[n['source']];assert n['returncode']==m['returncode'] and n['stderr']==m['stderr'] and n.get('observedStdout')==m.get('observedStdout')
 p=Path(n['source']);assert sha(p)==data['nativePair']['inputHashes'][str(p)]
 owner=data['csharpBase'] if any(x['source']==n['source'] for x in data['csharpBase']['cases']) else data['csharpTail']
 assert owner['inputHashes'][str(p)]==sha(p)
 comparisons.append(dict(source=p.relative_to(R).as_posix(),sourceSha256=sha(p),exactDiagnostic=True,exactRuntimeStdout=True,passed=True))
E.mkdir()
for k,d in data.items():write(E/(k+'.json'),d)
aliases=[]
for a,b in [('scripts/probes/windows-linker/owned-task-mixed.slg','examples/regression/diagnostics/2847-owned-unit-tail-if-transfer.slg'),('scripts/probes/ownership-tail/mixed-when.slg','examples/regression/diagnostics/2848-owned-unit-tail-when-transfer.slg')]:
 assert (R/a).read_bytes()==(R/b).read_bytes();aliases.append(dict(verifiedSource=a,catalogSource=b,sha256=sha(R/a),byteIdentical=True))
write(E/'source-comparison.json',read(B/'ownership24958-source-comparison.json'))
write(E/'paired-cases.json',dict(completed=20,total=20,programPairs=10,cases=comparisons,catalogAliases=aliases))
historical=['ownership24951-baseline','ownership24954-csharp','ownership24955-csharp','ownership24956-csharp-tail','ownership24957-csharp-tail','ownership24959-native','ownership24960-semantic','ownership24961-semantic','ownership24963-native','ownership24964-native']
history=[]
for n in historical:
 d=read(B/n/'result.json');history.append(dict(output=n,status=d['status'],completed=d.get('completed'),total=d.get('total'),failure=d.get('failure',d.get('failureIds')),claimsCurrentSuccess=False))
write(E/'historical-outcomes.json',history)
entries={}
def add(p,label=None):
 p=Path(p);entries[label or p.relative_to(R).as_posix()]=p.read_bytes()
source_paths=['src/Sollang.Compiler/Semantics/SemanticCompiler.cs','selfhost/semantic/ownership_check.slg','docs/SPEC.md']
for name in source_paths:
 add(R/name,'after-source/'+name);done=subprocess.run(['git','show','HEAD:'+name],capture_output=True,check=True);entries['before-source/'+name]=done.stdout
for p in [B/'ownership24951-check.py',Path(__file__),B/'ownership24958-source-comparison.json',*R.joinpath('scripts/probes/ownership-tail').glob('*'),*[Path(x['source']) for x in managed],*R.joinpath('examples/regression/diagnostics').glob('284[78]-owned-unit-tail-*')]:
 if p.is_file():add(p)
for name in set(records.values())|set(historical):
 for p in (B/name).rglob('*'):
  if p.is_file() and not any(x in p.parts for x in ['compiler','.sollang-cache','.w0','bin','obj']) and not any(x.endswith('.slg-tmp') for x in p.parts) and p.suffix.lower() not in ['.exe','.dll','.pdb','.ll','.bc','.obj','.lib','.pyc']:
   add(p)
# Keep the exact runner versions identified by previous input hashes.
runner=(B/'ownership24951-check.py').read_text(encoding='utf-8');versions=[runner]
old=runner.replace("B/'ownership24967-native'","B/'linker24916-native'");versions.append(old)
without_tail=old.replace("p.add_argument('--tail-only',action='store_true');",'').replace(' if a.tail_only:cases=[]\n','');versions.append(without_tail)
baseline=without_tail.replace('initialize_output, cleanup_output','initialize_output').replace("   row['passed']=True;result['cases'].append(row)","   result['cases'].append(row)").replace('finally:ex.finalize(error,cleanup=False)','finally:ex.finalize(error,cleanup=True)')
baseline='\n'.join(x for x in baseline.split('\n') if not x.startswith(' cleanup_output('));versions.append(baseline)
versions.append(runner.replace("B/'ownership24967-native'","B/'ownership24963-native'"))
version_hashes={}
current_runner=(B/'ownership24951-check.py').read_bytes();current_runner_hash=hashlib.sha256(current_runner).hexdigest().upper()
entries['runner-versions/'+current_runner_hash+'.py']=current_runner;version_hashes[current_runner_hash]=True
for text in versions:
 raw=text.encode('utf-8');h=hashlib.sha256(raw).hexdigest().upper();entries['runner-versions/'+h+'.py']=raw;version_hashes[h]=True
runner_pins={read(B/n/'result.json')['inputHashes'][str(B/'ownership24951-check.py')] for n in ['ownership24951-baseline','ownership24953-csharp','ownership24962-csharp-tail','ownership24959-native','ownership24964-native','ownership24968-native']}
assert runner_pins.issubset(version_hashes),('RUNNER_VERSION_MISSING',runner_pins-set(version_hashes))
archive=E/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,raw in sorted(entries.items()):z.writestr(n,raw)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(entries)
 for n,raw in entries.items():assert z.read(n)==raw
write(E/'archive-manifest.json',dict(sha256=sha(archive),readbackVerified=True,entries={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest().upper()) for n,raw in sorted(entries.items())}))
states={}
for x in read(R/'scripts/contracts/compiler-defects.json')['defects']:states[x['state']]=states.get(x['state'],0)+1
q=dict(schemaVersion=1,status='focused-qualified-parent-and-final-gates-pending',owner='C2026-09-12-385',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Discarded Unit If/When tails in ordinary functions and whole-owner If/When continuing-path joins.',paired=dict(completed=20,total=20,percentage=100.0,programPairs=10,evidence='paired-cases.json'),semantic=dict(completed=4,total=4,evidence='semantic.json'),compilerStates=states,sourceComparison='source-comparison.json',historicalFailures='historical-outcomes.json',producerAttempts=dict(completed=2,total=2,buildsPassed=2,qualifiedProducts=1,cumulativeMilliseconds=sum(read(B/n/'result.json')['processes'][0]['durationMilliseconds'] for n in ['ownership24963-native','ownership24967-native']),cumulativeMaximumMilliseconds=360000),archive=dict(path='evidence.zip',sha256=sha(archive),entries=len(entries),readbackVerified=True),remaining=['C385 and C742 parent acceptance','Original14/source7/runtime2708 and Stage2/Stage3','Frozen stdlib/runtime22 and required platform/performance acceptance'],claimsGoalComplete=False,claimsWholeC385Complete=False)
write(E/'qualification.json',q)
print(json.dumps(dict(status=q['status'],paired=q['paired'],archiveEntries=len(entries),compilerStates=states)))

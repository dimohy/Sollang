from pathlib import Path
from datetime import datetime,timezone
import argparse,json
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';e=r/'scripts/contracts/evidence/source13293/native19913-progress';e.mkdir(exist_ok=True)
parser=argparse.ArgumentParser();parser.add_argument('--negative-result',default='native19914-negative50');args=parser.parse_args()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));rel=lambda p:p.relative_to(r).as_posix()
def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
plan=read(r/'scripts/contracts/evidence/source13293/native19910-paired-plan/execution-plan.json');positive=read(b/'native19909-positive4/result.json');negativePath=b/args.negative_result/'result.json';negative=read(negativePath) if negativePath.exists() else dict(status='pending',completed=0,total=50,cases=[])
assert positive['total']==4 and negative['total']==50
rows={}
for x in positive['cases']:rows['c755-'+x['id']]=dict(x,id='c755-'+x['id'])
for x in negative['cases']:assert x['id'] not in rows;rows[x['id']]=x
assert set(rows).issubset(set(plan['caseIds']))
steps=[dict(id=key,status='complete' if rows.get(key,{}).get('passed') else rows.get(key,{}).get('status','pending')) for key in plan['caseIds']];completed=sum(x['status']=='complete' for x in steps)
failed=any(x.get('status') in ('failed','timed-out','cancelled','canceled') for x in (positive,negative));status='complete' if completed==54 and positive['status']==negative['status']=='passed' else 'failed' if failed else 'running'
snapshot=dict(schemaVersion=1,observedAtUtc=datetime.now(timezone.utc).isoformat(),completed=completed,total=54,positive=positive,negative=negative,claimsPhaseComplete=False,claimsGoalComplete=False);path=e/('snapshot-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f')+'.json');put(path,snapshot)
gate=dict(schemaVersion=1,status=status,completed=completed,total=54,steps=steps,evidence=rel(path),claimsPhaseComplete=False,claimsGoalComplete=False);put(e/'focused-gate.json',gate)
p=r/'scripts/contracts/active-goal-progress.json';a=read(p);entry=next(x for x in a['focusedGates'] if x['name']=='current-native19903-paired54');entry.update(status='complete' if status=='complete' else 'active',completed=completed,total=54,evidence=rel(e/'focused-gate.json'));a['currentNativeCliProgressEvidence']=rel(path)
active=[rel(b/'native19909-positive4/result.json')] if positive['status']=='running' else []
if negative['status']=='running':active.append(rel(negativePath))
a['currentWork'].update(focus=f'Current Native CLI paired54: {completed}/54; state {status}. Positive runtime4 and exact diagnostic50 keep original CSharp assertions.',checkpoint=rel(path),activeExecutions=active);put(p,a)
print(json.dumps(dict(status=status,completed=completed,total=54,evidence=rel(path))))

"""Current Native CLI comparison; exact CSharp references and original inputs."""
from pathlib import Path
import argparse,hashlib,json,sys,time
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(r/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_source_proof import current_build_inputs
from completed_artifact_plan import initialize_output
parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest().upper()
plan=read(args.plan);assert plan['caseSeconds']==180 and plan['retryCount']==0 and len(plan['cases'])==50
compiler=r/plan['compiler'];buildPath=r/plan['buildRecord'];build=read(buildPath);assert sha(compiler)==plan['compilerSha256']==build['compilerSha256']
paths=[Path(__file__).resolve(),args.plan.resolve(),compiler,buildPath,r/plan['sourceComparison'],r/'scripts/verification_execution.py',r/'scripts/verification_contract_lease.py',r/'scripts/completed_artifact_plan.py',*current_build_inputs(r,build)]
for case in plan['cases']:
 assert case['target']=='windows-x64' and case['expectedBuildExit']==1 and case['csharpReference']['passed'] and case['csharpReference']['originalConstraintSatisfied']
 assert case['expectedBuildStdout']==case['csharpReference']['buildStdout'] and case['expectedBuildStderr']==case['csharpReference']['buildStderr']
 binding=Path(case['csharpBindingPath']);assert sha(binding)==case['csharpBindingSha256'];paths.append(binding)
 for item in case['sourceInputs']+case['runtimeInputFiles']:
  p=r/item['path'];assert sha(p)==item['sha256'];paths.append(p)
pins={str(p):sha(p) for p in paths};stable=lambda:all(Path(name).is_file() and sha(Path(name))==value for name,value in pins.items())
out=args.output.resolve();roots=[b/'v18915/compiler-build01',b/'v19080/compiler-build01',b/'v19903/compiler-build01']
with VerificationContractLease(list(map(Path,pins))):
 initialize_output(r,out,reusable_directories=roots);out.mkdir(exist_ok=False)
 d=dict(schemaVersion=1,status='running',completed=0,total=50,cases=[],inputHashes=pins,caseBudgetSeconds=180,retryCount=0,compilerSha256=sha(compiler),scope=plan['scope'],claimsCurrentFullCompilerFixed=False,claimsPhaseComplete=False,claimsGoalComplete=False)
 execution=VerificationExecution(r,out,d,stable,sha);error=None
 try:
  for index,case in enumerate(plan['cases']):
   folder=out/f'{index:03}';folder.mkdir();started=time.monotonic();row=dict(id=case['id'],group=case['group'],status='running',passed=False,wholeCaseBudgetSeconds=180);d['cases'].append(row);execution.save()
   command=[str(compiler),'build',*[str(r/item['path']) for item in case['sourceInputs']],'-o',str(folder/'probe.exe'),'--target','windows-x64','--stdlib',str(r/'stdlib'),'--llvm',str(r/'.tools/llvm-22.1.8'),'--jobs','4','--keep-temps']
   observed=execution.run(command,folder/'compile',timeout=180)
   stdout=observed.stdout.replace('\r\n','\n');stderr=observed.stderr.replace('\r\n','\n');matched=observed.returncode==case['expectedBuildExit'] and stdout==case['expectedBuildStdout'] and stderr==case['expectedBuildStderr']
   row.update(buildExit=observed.returncode,buildStdout=stdout,buildStderr=stderr,expectedStdout=case['expectedBuildStdout'],expectedStderr=case['expectedBuildStderr'],matchesCurrentCSharp=matched,originalConstraintSatisfied=matched,wholeCaseElapsedSeconds=time.monotonic()-started)
   assert not (folder/'probe.exe').exists() and not (folder/'probe.exe.ll').exists(),'PUBLISHED_PRODUCT_ON_REJECTION'
   if case['requireNoLlvm']:assert not any(p.stat().st_size for p in folder.rglob('*.ll')),'ORIGINAL_NO_LLVM_ASSERTION_FAILED'
   assert row['wholeCaseElapsedSeconds']<=180,'WHOLE_CASE_BUDGET_EXHAUSTED'
   assert matched,('NATIVE_DIAGNOSTIC_DIFFERS_FROM_CURRENT_CSHARP',case['id'],observed.returncode,stdout,stderr)
   row.update(status='passed',passed=True);d['completed']+=1;execution.save();print(case['id']+': current Native matched',flush=True)
  d['status']='passed'
 except BaseException as failure:
  error=failure
  if d['cases'] and d['cases'][-1]['status']=='running':d['cases'][-1].update(status='failed',passed=False,failure=str(failure))
 finally:execution.finalize(error,cleanup=False)
print(json.dumps({key:d.get(key) for key in ('status','completed','total','failure','inputsStable','processesStopped')}))
sys.exit(0 if d['status']=='passed' else 1)

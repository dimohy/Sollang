from pathlib import Path
import json,sys,hashlib
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
O=B/'bitset25138-preflight-negative';O.mkdir()
paths=[R/'scripts/build-focused-source-emitter.py',B/'bitset25124-gate-negative.json',B/'bitset25090-prepared-before/result.json'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();pins={str(p.resolve()):sha(p) for p in paths}
with VerificationContractLease(paths):
 result=dict(status='running',completed=0,total=1,inputHashes=pins,cases=[],claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);err=None
 try:
  cmd=[sys.executable,'-B',str(paths[0]),'--compiler',str(B/'bitset25114-managed/compiler/Sollang.Compiler.exe'),'--output',str(B/'bitset25124-blocked-native'),'--semantic-result',str(B/'bitset25121-semantic/result.json'),'--source-comparison',str(paths[1]),'--cli']
  for n in ['bitset25123-native','layout25036-native','v20050/compiler-build01']:cmd+=['--reusable-directory',str(B/n)]
  done=ex.run(cmd,O/'blocked',timeout=15);assert done.returncode!=0 and 'SOURCE_EMITTER_NATIVE_PREFLIGHT_FAILED' in done.stderr;assert not (B/'bitset25124-blocked-native').exists()
  result.update(status='passed',completed=1,cases=[dict(id='failed-production-registration-preflight-blocks-build',passed=True,compilerBuildStarted=False)])
 except BaseException as e:err=e
 finally:ex.finalize(err,cleanup=False)
 if err:raise err
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

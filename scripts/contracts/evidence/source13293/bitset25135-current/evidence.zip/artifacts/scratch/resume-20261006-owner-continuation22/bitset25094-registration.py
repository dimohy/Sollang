from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve();P=R/'scripts/probes/codegen-cache-bitset';S=R/'selfhost/semantic/reference_synthetic_type_ids.slg';E=P/'registration.stdout.txt';reference=B/'bitset25091-csharp-registration/result.json'
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output,cleanup_output
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();paths=[Path(__file__),C,reference,P/'registration.slg',S,E,*sorted((R/'stdlib').rglob('*.slg')),R/'scripts/verification_execution.py',R/'scripts/completed_artifact_plan.py'];
if C.with_suffix('.dll').exists():paths+=managed_runtime_inputs(C)
pins={str(p.resolve()):sha(p) for p in paths};reuse=[B/'layout25036-native',B/'return25002-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir();csharp=json.loads(reference.read_text());assert csharp['status']=='passed' and [x['relative'] for x in csharp['cases'][:6]]==[0,1,0,2,2,3]
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=8,inputHashes=pins,cases=[],claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  done=ex.run([str(C),'build',str(P/'registration.slg'),str(S),'-o',str(O/'registration.exe'),'--target','windows-x64','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')],O/'registration.build',timeout=60);assert done.returncode==0 and not done.stderr,(done.stdout,done.stderr)
  done=ex.run([str(O/'registration.exe')],O/'registration.run',timeout=10);assert done.returncode==0 and not done.stderr and done.stdout==E.read_text(encoding='utf-8-sig').replace('\r\n','\n'),(done.stdout,done.stderr)
  lines=done.stdout.splitlines();result.update(status='passed',completed=8,cases=[dict(id=line.split(':')[0],passed=True,observed=line) for line in lines]);assert len(lines)==8
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reuse)
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

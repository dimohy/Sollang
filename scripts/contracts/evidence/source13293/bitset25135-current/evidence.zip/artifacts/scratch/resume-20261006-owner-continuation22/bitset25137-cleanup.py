from pathlib import Path
import sys,json
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22'
from completed_artifact_plan import cleanup_output,assert_output_shutdown
reuse=[B/'bitset25123-native',B/'layout25036-native',B/'v20050/compiler-build01']
rows=[]
for name in ['bitset25127-native','bitset25128-arithmetic-native','bitset25129-dictionary-native','bitset25130-array-native','bitset25092-prepared-after','return25002-native']:
 d=json.loads((B/name/'result.json').read_text(encoding='utf-8-sig'));assert d['status']=='passed' and d['processesStopped'];assert_output_shutdown(R,B/name)
 p=cleanup_output(R,B/name,reusable_directories=reuse);done=json.loads(Path(str(p)+'.execution.json').read_text());assert done['status']=='completed';rows.append(dict(output=name,reclaimedBytes=done['reclaimedBytes'],execution=str(p)+'.execution.json'))
for name in ['bitset25123-native','bitset25114-managed']:
 p=cleanup_output(R,B/name,reusable_directories=reuse,temporary_only=True);done=json.loads(Path(str(p)+'.execution.json').read_text());assert done['status']=='completed';rows.append(dict(output=name,temporaryOnly=True,reclaimedBytes=done['reclaimedBytes'],execution=str(p)+'.execution.json'))
for p in reuse:assert (p/'compiler.exe').is_file()
assert not (B/'return25002-native/compiler.exe').exists()
d=dict(status='completed',cleanup=rows,reclaimedBytes=sum(r['reclaimedBytes'] for r in rows),reusableNative=list(map(str,reuse)),failedOutputsPreserved=True,claimsGoalComplete=False)
(B/'bitset25137-cleanup.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))

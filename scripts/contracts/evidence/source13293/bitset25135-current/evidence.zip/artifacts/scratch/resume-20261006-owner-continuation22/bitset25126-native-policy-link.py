from pathlib import Path
import sys,json,hashlib,re
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve();P=R/'scripts/probes/windows-linker';M=P/'link.sources.txt';E=P/'expected-import-definitions.json';IR=B/'bitset25110-prepared-native/.l0.ll';F=R/'scripts/probes/codegen-cache-bitset/type-input.slg';L=R/'.tools/llvm-22.1.8';sources=[R/x for x in M.read_text(encoding='utf-8-sig').splitlines() if x.strip()]
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output,cleanup_output
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();paths=[Path(__file__),C,M,E,IR,F,*sources,*sorted((R/'stdlib').rglob('*.slg')),R/'scripts/verification_execution.py',R/'scripts/completed_artifact_plan.py',L/'bin/clang.exe',L/'bin/lld-link.exe',L/'bin/llvm-lib.exe',L/'bin/llvm-readobj.exe']
if C.with_suffix('.dll').exists():paths+=managed_runtime_inputs(C)
pins={str(p.resolve()):sha(p) for p in paths};reuse=[B/'layout25036-native',B/'return25002-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=4,cases=[],inputHashes=pins,scope='Actual SLG production linker and generated shared import policy over immutable Native-produced IR, exact kernel32 definition and TLS PE imports, then production registration API execution',claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  done=ex.run([str(C),'build',*map(str,sources),'-o',str(O/'linker.exe'),'--target','windows-x64','-O1','--jobs','4','--llvm',str(L)],O/'linker.build',timeout=60);assert done.returncode==0 and not done.stderr,(done.stdout,done.stderr)
  (O/'native').mkdir();done=ex.run([str(O/'linker.exe'),str(L),str(IR),str(O/'prepared.exe'),str(O/'native'),'-O0','4','false','4'],O/'production.link',timeout=60);assert done.returncode==0 and not done.stderr and re.fullmatch(r'processors=[1-9][0-9]*\n',done.stdout),(done.stdout,done.stderr)
  expected=json.loads(E.read_text())['kernel32.def'];assert (O/'native/kernel32.def').read_text()==expected
  pe=ex.run([str(L/'bin/llvm-readobj.exe'),'--coff-imports',str(O/'prepared.exe')],O/'tls.imports',timeout=10);assert pe.returncode==0 and not pe.stderr and all(name in pe.stdout for name in ['TlsAlloc','TlsSetValue','TlsGetValue','TlsFree']),pe.stdout+pe.stderr
  done=ex.run([str(O/'prepared.exe'),str(F)],O/'prepared.run',timeout=15);assert done.returncode==0 and not done.stderr and ':error:' not in done.stdout and all(phase+':ok:' in done.stdout for phase in ['metadata','declarations','resolved-uses']),done.stdout+done.stderr
  result.update(status='passed',completed=4,cases=[dict(id=phase,passed=True) for phase in ['shared-definition-and-TLS-imports','metadata','declarations','resolved-uses']],stdout=done.stdout,executableSha256=sha(O/'prepared.exe'))
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reuse)
print(json.dumps({k:result[k] for k in ['status','completed','total','stdout','inputsStable','processesStopped']}))

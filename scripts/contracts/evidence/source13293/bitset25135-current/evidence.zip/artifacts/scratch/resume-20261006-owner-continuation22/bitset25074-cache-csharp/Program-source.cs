using System.Reflection;
using System.Text.Json;

var assembly = Assembly.LoadFrom(args[0]);
var tableType = assembly.GetType("Sollang.Compiler.Semantics.TypeDefinitionTable", true)!;
var constructor = tableType.GetConstructors(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).Single();
var inputs = constructor.GetParameters().Select(parameter => parameter.HasDefaultValue ? parameter.DefaultValue
    : parameter.ParameterType == typeof(int) ? 8
    : Activator.CreateInstance(typeof(Dictionary<,>).MakeGenericType(parameter.ParameterType.GetGenericArguments()))).ToArray();
var table = constructor.Invoke(inputs);
var cache = assembly.GetType("Sollang.Compiler.Cli.IncrementalCodegenCache", true)!;
var hash = cache.GetMethod("BuildTypeUniverseHash", BindingFlags.NonPublic | BindingFlags.Static)!;
var add = tableType.GetMethod("GetOrAddBitSet")!;
var baseline = (ulong)hash.Invoke(null, [table])!;
foreach (var bitCount in new[] { 1, 64, 65, 130, int.MaxValue })
{
    add.Invoke(table, [bitCount]);
    var observed = (ulong)hash.Invoke(null, [table])!;
    if (observed != baseline)
        throw new InvalidOperationException("BitSet unexpectedly contributes a standalone type-universe record");
    Console.WriteLine(JsonSerializer.Serialize(new { bitCount, baseline = baseline.ToString("x16"),
        observed = observed.ToString("x16"), standaloneRecord = false }));
}

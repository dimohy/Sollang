from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=B/'layout25031-managed/compiler/Sollang.Compiler.exe';O=B/'bitset25090-prepared-before';P=R/'scripts/probes/codegen-cache-bitset';M=R/'tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.sources.txt';sources=[R/x for x in M.read_text(encoding='utf-8-sig').splitlines() if x.strip() and not x.endswith('selfhost-sollangc-driver.slg')]
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();paths=[Path(__file__),C,*managed_runtime_inputs(C),M,P/'prepared.slg',P/'type-input.slg',*sources,*sorted((R/'stdlib').rglob('*.slg')),R/'scripts/verification_execution.py',R/'scripts/completed_artifact_plan.py'];pins={str(p.resolve()):sha(p) for p in paths};reuse=[B/'layout25036-native',B/'return25002-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',inputHashes=pins,scope='Observe production metadata/declaration/resolved-use registration APIs before any further compiler producer build',claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  done=ex.run([str(C),'build',str(P/'prepared.slg'),*map(str,sources),'-o',str(O/'prepared.exe'),'--target','windows-x64','-O0','--jobs','24','--llvm',str(R/'.tools/llvm-22.1.8')],O/'prepared.build',timeout=180);assert done.returncode==0 and not done.stderr,(done.stdout[-3000:],done.stderr)
  done=ex.run([str(O/'prepared.exe'),str(P/'type-input.slg')],O/'prepared.run',timeout=15);assert done.returncode==0 and not done.stderr,(done.stdout,done.stderr);result.update(status='observed',stdout=done.stdout)
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','stdout','inputsStable','processesStopped']}))

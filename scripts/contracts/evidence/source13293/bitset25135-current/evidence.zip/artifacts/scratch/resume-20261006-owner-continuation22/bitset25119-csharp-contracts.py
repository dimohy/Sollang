from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'bitset25119-csharp-contracts';C=B/'bitset25114-managed/compiler/Sollang.Compiler.exe';P=R/'scripts/probes/codegen-cache-bitset'
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output,cleanup_output
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();paths=[Path(__file__),C,*managed_runtime_inputs(C),P/'Program.cs',P/'CacheBitSet.csproj',R/'src/Sollang.Compiler/Semantics/BoundProgram.cs',R/'src/Sollang.Compiler/Cli/IncrementalCodegenCache.cs',R/'src/Sollang.Compiler/Shared/Policies/CodegenCacheKeyPolicy.cs',R/'scripts/verification_execution.py',R/'scripts/completed_artifact_plan.py'];pins={str(p.resolve()):sha(p) for p in paths};reuse=[B/'layout25036-native',B/'return25002-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=13,inputHashes=pins,cases=[],claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  done=ex.run(['dotnet','build',str(P/'CacheBitSet.csproj'),'-c','Release','-o',str(O/'probe'),'--artifacts-path',str(O/'dotnet-artifacts'),'--disable-build-servers','-p:UseSharedCompilation=false','-nodeReuse:false','--nologo'],O/'harness.build',timeout=60);assert done.returncode==0 and not done.stderr,(done.stdout,done.stderr)
  for mode in ['registration','universe']:
   done=ex.run(['dotnet',str(O/'probe/CacheBitSet.dll'),str(C.with_suffix('.dll')),*([mode] if mode=='registration' else [])],O/(mode+'.run'),timeout=10);assert done.returncode==0 and not done.stderr,(done.stdout,done.stderr);rows=[json.loads(x) for x in done.stdout.splitlines()]
   if mode=='registration':assert len(rows)==8 and [r['relative'] for r in rows[:6]]==[0,1,0,2,2,3] and rows[6:]==[dict(kind='invalid',bitCount=0,rejected=True),dict(kind='invalid',bitCount=-1,rejected=True)]
   else:assert [r['bitCount'] for r in rows]==[1,64,65,130,2147483647] and all(r['baseline']==r['observed'] and r['standaloneRecord'] is False for r in rows)
   result['cases'] += [dict(id=mode+'-'+str(i),passed=True,**r) for i,r in enumerate(rows)];result['completed']+=len(rows);ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reuse)
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

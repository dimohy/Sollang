from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve();M=R/'scripts/probes/codegen-registered-universe/sources.txt';S=R/'scripts/probes/codegen-registered-universe/input.slg';sources=[R/x for x in M.read_text(encoding='utf-8-sig').splitlines() if x.strip()]
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output,cleanup_output
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();paths=[Path(__file__),C,M,S,*sources,*sorted((R/'stdlib').rglob('*.slg')),R/'scripts/verification_execution.py',R/'scripts/completed_artifact_plan.py',R/'.tools/llvm-22.1.8/bin/clang.exe'];
if C.with_suffix('.dll').exists():paths+=managed_runtime_inputs(C)
pins={str(p.resolve()):sha(p) for p in paths};reuse=[B/'layout25036-native',B/'return25002-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,inputHashes=pins,cases=[],scope='Production registered-type capture API: one valid BitSet, duplicate identity, six malformed geometry/type inputs, existing registered universe controls',claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  done=ex.run([str(C),'build',*map(str,sources),'-o',str(O/'capture.exe'),'--target','windows-x64','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')],O/'capture.build',timeout=180);assert done.returncode==0 and not done.stderr,(done.stdout[-3000:],done.stderr)
  done=ex.run([str(O/'capture.exe'),str(S)],O/'capture.run',timeout=15);assert done.returncode==0 and not done.stderr and 'bitset-capture:8\n' in done.stdout and 'record:struct:' in done.stdout,(done.stdout,done.stderr)
  result.update(status='passed',completed=1,cases=[dict(id='bitset-capture-positive-and-rejection-controls',passed=True,controls=8,observedStdout=done.stdout)],executableSha256=sha(O/'capture.exe'))
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reuse)
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

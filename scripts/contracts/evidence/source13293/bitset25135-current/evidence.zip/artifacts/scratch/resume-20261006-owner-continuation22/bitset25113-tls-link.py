from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve();IR=B/'bitset25110-prepared-native/.l0.ll';P=R/'scripts/probes/windows-tls-linker';L=R/'.tools/llvm-22.1.8';baseline=len(sys.argv)>3
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output,cleanup_output
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();closure=json.loads((B/'bitset25108-semantic-sources.json').read_text());old=json.loads((B/'bitset25110-prepared-native/result.json').read_text());compiled=[R/x for x in closure['sources']]+[R/'scripts/probes/codegen-cache-bitset/prepared.slg',R/'scripts/probes/codegen-cache-bitset/type-input.slg',*sorted((R/'stdlib').rglob('*.slg'))]
assert old['inputsStable'] and old['processesStopped'] and all(old['inputHashes'][str(p.resolve())]==sha(p) for p in compiled), 'GENERATED_IR_COMPILED_INPUT_DRIFT'
assert 'target triple = "x86_64-pc-windows-msvc"' in IR.read_text(encoding='utf-8-sig')
paths=[Path(__file__),C,*managed_runtime_inputs(C),IR,*compiled,B/'bitset25108-semantic-sources.json',P/'Program.cs',P/'TlsLinker.csproj',R/'src/Sollang.Compiler/Shared/Policies/WindowsLinkPolicy.cs',R/'src/Sollang.Compiler/Tooling/WindowsLinker.cs',L/'bin/clang.exe',L/'bin/llvm-lib.exe',L/'bin/lld-link.exe',B/'bitset25110-prepared-native/result.json'];pins={str(p.resolve()):sha(p) for p in paths};reuse=[B/'layout25036-native',B/'return25002-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',inputHashes=pins,scope='Production CSharp linker over immutable LLVM produced by the failed Native API program; no frontend replay or failed-output promotion',irCompatibility=dict(compiledSourceCount=70,allCompiledSourceAndStdlibHashesUnchanged=True,target='windows-x64',originalIrSha256=sha(IR),oldFailedOutputPreserved=True,whole225SourceAcceptance=False),claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  done=ex.run(['dotnet','build',str(P/'TlsLinker.csproj'),'-c','Release','-o',str(O/'probe'),'--artifacts-path',str(O/'dotnet-artifacts'),'--disable-build-servers','-p:UseSharedCompilation=false','-nodeReuse:false','--nologo'],O/'harness.build',timeout=60);assert done.returncode==0 and not done.stderr,(done.stdout,done.stderr)
  done=ex.run(['dotnet',str(O/'probe/TlsLinker.dll'),str(C.with_suffix('.dll')),str(L),str(IR),str(O/'prepared.exe'),str(O/'native')],O/'production.link',timeout=60);result.update(linkExit=done.returncode,linkStdout=done.stdout,linkStderr=done.stderr);ex.save()
  if baseline:
   assert done.returncode==1 and all(name in done.stderr for name in ['TlsAlloc','TlsGetValue','TlsSetValue','TlsFree']),done.stderr;result['status']='observed'
  else:
   assert done.returncode==0 and not done.stderr,(done.stdout,done.stderr)
   done=ex.run([str(O/'prepared.exe'),str(R/'scripts/probes/codegen-cache-bitset/type-input.slg')],O/'prepared.run',timeout=15);assert done.returncode==0 and not done.stderr and all(phase+':ok:' in done.stdout for phase in ['metadata','declarations','resolved-uses']) and ':error:' not in done.stdout,done.stdout+done.stderr
   result.update(status='passed',completed=3,total=3,cases=[dict(id=phase,passed=True) for phase in ['metadata','declarations','resolved-uses']],stdout=done.stdout,executableSha256=sha(O/'prepared.exe'))
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 if not baseline:cleanup_output(R,O,reusable_directories=reuse)
print(json.dumps({k:result.get(k) for k in ['status','completed','total','stdout','linkExit','inputsStable','processesStopped']}))

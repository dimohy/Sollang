from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22'
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output,cleanup_output
C=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve();S=R/'scripts/probes/layout-boundary/bitset-boundary.slg';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
paths=[Path(__file__),S,C,*sorted((R/'stdlib').rglob('*.slg')),*[R/'scripts'/x for x in ['verification_execution.py','verification_contract_lease.py','verification_fingerprints.py','completed_artifact_plan.py','ArtifactLifecycle.ps1']],R/'.tools/llvm-22.1.8/bin/clang.exe']
if C.with_suffix('.dll').exists():paths+=managed_runtime_inputs(C)
pins={str(p.resolve()):sha(p) for p in paths};reuse=[B/'layout25036-native',B/'return25002-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,inputHashes=pins,cases=[],claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  done=ex.run([str(C),'build',str(S),'-o',str(O/'probe.exe'),'--target','windows-x64','-O1','--jobs','4','--keep-temps','--llvm',str(R/'.tools/llvm-22.1.8')],O/'boundary.build',timeout=60)
  result.update(buildExit=done.returncode,buildStdout=done.stdout,buildStderr=done.stderr);ex.save();assert done.returncode==0 and not done.stderr,(done.stdout,done.stderr)
  ir=Path(str(O/'probe.exe')+'.ll').read_text(encoding='utf-8-sig');assert '[33554432 x i64]' in ir,'Canonical maximum BitSet word count absent'
  done=ex.run([str(O/'probe.exe')],O/'boundary.run',timeout=10);assert done.returncode==0 and not done.stderr and done.stdout=='ready\n',(done.stdout,done.stderr)
  result.update(status='passed',completed=1,cases=[dict(id='max-bitset-reference-type',passed=True,observedStdout=done.stdout,wordCount=33554432,bytes=268435456)],executableSha256=sha(O/'probe.exe'),llvmSha256=sha(Path(str(O/'probe.exe')+'.ll')))
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reuse)
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

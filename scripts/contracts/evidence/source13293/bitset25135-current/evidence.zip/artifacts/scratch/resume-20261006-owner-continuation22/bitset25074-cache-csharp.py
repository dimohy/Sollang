from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'bitset25074-cache-csharp';C=B/'layout25031-managed/compiler/Sollang.Compiler.exe';S=R/'scripts/probes/codegen-cache-bitset'
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output,cleanup_output
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();paths=[Path(__file__),C,*managed_runtime_inputs(C),S/'Program.cs',S/'CacheBitSet.csproj',R/'src/Sollang.Compiler/Cli/IncrementalCodegenCache.cs',R/'src/Sollang.Compiler/Shared/Policies/CodegenCacheKeyPolicy.cs',R/'scripts/verification_execution.py',R/'scripts/completed_artifact_plan.py'];pins={str(p.resolve()):sha(p) for p in paths};reuse=[B/'layout25036-native',B/'return25002-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=5,inputHashes=pins,cases=[],claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  done=ex.run(['dotnet','build',str(S/'CacheBitSet.csproj'),'-c','Release','-o',str(O/'probe'),'--artifacts-path',str(O/'dotnet-artifacts'),'--disable-build-servers','-p:UseSharedCompilation=false','-nodeReuse:false','--nologo'],O/'harness.build',timeout=60);assert done.returncode==0 and not done.stderr,(done.stdout,done.stderr)
  done=ex.run(['dotnet',str(O/'probe/CacheBitSet.dll'),str(C.with_suffix('.dll'))],O/'hash.run',timeout=10);assert done.returncode==0 and not done.stderr,(done.stdout,done.stderr)
  rows=[json.loads(x) for x in done.stdout.splitlines()];assert [r['bitCount'] for r in rows]==[1,64,65,130,2147483647]
  assert all(r['baseline']==r['observed'] and r['standaloneRecord'] is False for r in rows)
  result.update(status='passed',completed=5,cases=[dict(id=str(r['bitCount']),passed=True,**r) for r in rows])
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reuse)
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

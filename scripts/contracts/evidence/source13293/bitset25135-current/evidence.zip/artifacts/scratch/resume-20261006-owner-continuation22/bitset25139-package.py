from pathlib import Path
import json,hashlib,zipfile,subprocess,datetime
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/bitset25135-current'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
write=lambda p,d:Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
validation=read(B/'bitset25136-validation/result.json');assert validation['status']=='passed'
audit=validation['sourceConnections'];assert sum(v['named'] for p in audit['phases'] for v in p['coverage'].values())==459
for name,source in [('validation','bitset25136-validation/result.json'),('preflight-negative','bitset25138-preflight-negative/result.json'),('artifact-lifecycle','bitset25137-cleanup.json'),('source-closure','bitset25108-semantic-sources.json'),('producer','bitset25123-native/result.json'),('semantic','bitset25121-semantic/result.json'),('stdlib','bitset25122-stdlib/result.json')]:write(E/(name+'.json'),read(B/source))
write(E/'source-connections.json',audit)
protected=read(B/'block24016-protected-inputs.json')
for p,h in protected.items():assert sha(R/p)==h
entries={}
def add(p):
 p=Path(p);entries[p.relative_to(R).as_posix()]=p.read_bytes()
sourcePaths=['docs/SPEC.md','selfhost/llvm/emitter/layout_arithmetic.slg','selfhost/llvm/type_layouts.slg','selfhost/llvm/text/containers.slg','selfhost/llvm/text/foundation.slg','selfhost/llvm/text/runtime_preamble.slg','selfhost/llvm/codegen_registered_universe.slg','selfhost/semantic/reference_synthetic_type_ids.slg','selfhost/semantic/reference_prepared_type_ids.slg','selfhost/generated/windows_link_policy.slg','src/Sollang.Compiler/Shared/Policies/WindowsLinkPolicy.cs','scripts/verification_execution.py','scripts/completed_artifact_plan.py']
for name in sourcePaths:
 add(R/name);old=subprocess.run(['git','show','HEAD:'+name],capture_output=True,check=True).stdout;entries['before-source/'+name]=old
for folder in ['scripts/probes/layout-boundary','scripts/probes/codegen-cache-bitset','scripts/probes/windows-tls-linker','scripts/probes/codegen-registered-universe']:
 for p in (R/folder).rglob('*'):
  if p.is_file() and not any(x in ['obj','bin'] for x in p.parts):add(p)
# Archive bounded source, result and diagnostic records; retain binaries and failed LLVM in their owned directories.
for item in sorted(B.glob('bitset*')):
 if not (item.name.startswith('bitset250') or item.name.startswith('bitset251')):continue
 paths=item.rglob('*') if item.is_dir() else [item]
 for p in paths:
  if not p.is_file():continue
  if any(x in ['.sollang-cache','compiler','bin','obj','dotnet-artifacts','.w0'] or x.endswith('.slg-tmp') for x in p.parts):continue
  if p.suffix.lower() in ['.exe','.dll','.pdb','.ll','.bc','.obj','.lib','.pyc','.semantic','.zip']:continue
  if p.stat().st_size>8_000_000:continue
  add(p)
for p in [B/'block24016-protected-inputs.json',Path(__file__)]:add(p)
archive=E/'evidence.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(entries.items()):z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(entries)
 for name,raw in entries.items():assert z.read(name)==raw
write(E/'archive-manifest.json',dict(sha256=sha(archive),readbackVerified=True,entries={n:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest().upper()) for n,v in sorted(entries.items())}))
q=dict(schemaVersion=1,status='current-windows-focused-qualified-final-gates-pending',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseCommit=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,check=True,text=True).stdout.strip(),scope='BitSet geometry and synthetic registration; shared Windows TLS imports',defectIds=['C2026-11-03-'+str(x) for x in [791,792,793,794]],focused=dict(completed=36,total=36,percentage=100.0,metadata=16,pairedCli=4,pairedArithmetic=16),related=dict(completed=31,total=31),managedContracts=13,syntheticSourceControls=16,captureSourceControls=16,currentNativePreparationApis=3,managedProductionTlsLinkApis=3,slgProductionLinkerCompiledByCSharpControls=4,semantic=dict(completed=4,total=4),stdlib=dict(completed=1,total=1,sources=144,activeBodies=2071),closureControls=112,layoutControls=2,associated=dict(completed=459,total=712,percentage=64.47,remaining=253),nativeCompilerProducerBuilds=3,maximumNativeCompilerProducerBuilds=3,managedCompilerProducerBuilds=1,original1999Runs=0,wholeProfileRuns=0,currentFocusedFailedCases=0,failedHistoryPreserved=['bitset25057-native-before','bitset25064-native','bitset25082-native','bitset25096-prepared-native','bitset25110-prepared-native','bitset25131-native-linker'],failureClassification=dict(currentFocused='none',open='C2026-11-03-795: Native E20 partial moves while compiling production Windows linker source; CSharp exact source passes',unverified='All225 auxiliary API compiler timeout180; no whole-source success claimed',resolved='BitSet capture/registration and shared TLS imports, proven by fresh current Native36 and production preparation APIs3'),sourceComparison='source-comparison.json',sourceClosure='source-closure.json',lifecycle='artifact-lifecycle.json',protectedInputsVerified=len(protected),progressReportAutomaticValidation='unverified: legacy progress gate status prevents project report; Slogs count contract previously failed; no enforcement claim',overall=dict(completed=None,total=None,percentage=None,unknownReason='Platform and performance denominators are not frozen'),platformScope='windows-x64',archive=dict(path='evidence.zip',sha256=sha(archive),entries=len(entries),bytes=archive.stat().st_size,readbackVerified=True),claimsWholePhaseComplete=False,claimsGoalComplete=False)
write(E/'qualification.json',q)
print(json.dumps(dict(status=q['status'],archiveEntries=len(entries),archiveBytes=archive.stat().st_size,protected=len(protected))))

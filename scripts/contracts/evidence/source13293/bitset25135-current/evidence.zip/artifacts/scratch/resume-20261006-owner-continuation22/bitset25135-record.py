from pathlib import Path
import json,hashlib,datetime
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/bitset25135-current'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));write=lambda p,d:Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
units={'managed':'bitset25116-csharp','arithmeticManaged':'bitset25120-arithmetic-csharp','native':'bitset25127-native','arithmeticNative':'bitset25128-arithmetic-native','dictionaryManaged':'bitset25117-dictionary-csharp','arrayManaged':'bitset25118-array-csharp','dictionaryNative':'bitset25129-dictionary-native','arrayNative':'bitset25130-array-native','managedContracts':'bitset25119-csharp-contracts','preparedNative':'bitset25133-prepared-current','managedTlsLink':'bitset25115-tls-linked','slgTlsLink':'bitset25134-slg-linker-csharp','syntheticManaged':'bitset25094-registration-csharp','syntheticNative':'bitset25095-registration-native','captureManaged':'bitset25077-capture-csharp','captureNative':'bitset25083-capture-native'}
records={k:read(B/name/'result.json') for k,name in units.items()}
for key,d in records.items():
 assert d['status']=='passed' and d['completed']==d['total'] and d['inputsStable'] and d['processesStopped'],key
 assert all(sha(p)==h for p,h in d['inputHashes'].items()),key
 for stream in ['stdout','stderr']:
  assert len({p[stream+'Path'] for p in d['processes']})==len(d['processes'])
  for process in d['processes']:assert sha(process[stream+'Path'])==process[stream+'Sha256']
assert sum(records[k]['completed'] for k in ['managed','arithmeticManaged','native','arithmeticNative'])==36
for a,b in zip(records['arithmeticManaged']['cases'],records['arithmeticNative']['cases']):assert a==b
E.mkdir()
for key,d in records.items():write(E/(key+'.json'),d)
write(E/'source-comparison.json',read(B/'bitset25093-source-comparison.json'))
detailPath=R/'scripts/contracts/structural-parity-detail.json';detail=read(detailPath);write(B/'bitset25135-detail-before.json',detail)
phase=next(p for p in detail['phaseProgress'] if p['phase']=='llvm-generation');decisions=phase['decisionInventory']['decisions'];bit=next(x for x in decisions if x['id']=='llvm-generation.bitset-inline-slot-and-tail-count')
for name in ['src/Sollang.Compiler/CodeGen/LlvmEmitter.Structs.cs','src/Sollang.Compiler/Cli/IncrementalCodegenCache.cs']:
 if name not in bit['managedSources']:bit['managedSources'].append(name)
for name in ['selfhost/llvm/type_layouts.slg','selfhost/llvm/emitter/layout_arithmetic.slg','selfhost/llvm/text/foundation.slg','selfhost/llvm/text/runtime_preamble.slg','selfhost/llvm/codegen_registered_universe.slg']:
 if name not in bit['selfhostSources']:bit['selfhostSources'].append(name)
bit['supportingSources']=sorted(set(bit.get('supportingSources',[])+['src/Sollang.Compiler/Semantics/BoundProgram.cs','selfhost/semantic/reference_synthetic_type_ids.slg','selfhost/semantic/reference_prepared_type_ids.slg']))
bit['structure']='CSharp commits one widened WordCount and inline Size in the type table. SLG type layout, storage emission and all three intrinsic/interpolation consumers share one widened word-count producer. Synthetic BitSet recipes have no element dependency and intern by positive count before dependent reference identities.'
bit['branches']='Small/word-boundary/max-Int32 counts, same-count aliases versus distinct counts, readonly reference registration order, invalid recipe dependencies/counts, duplicate registrations and malformed published geometry. Current shared universe plan deliberately has no standalone BitSet record; validated BitSet identities retain normal module/function/name identity.'
bit['logic']='Widen before +63 and division64, then publish exact Int32 word/byte counts. Preserve BitSet kind and length in declaration/resolved-use recipes. Validate committed layout before applying the same universe category selection as the CSharp production hash. Other unknown/malformed records still fail.'
bit['diagnostics']='Current focused36 and related array/dictionary31 pass. Production CSharp hash/identity contracts13, synthetic source pair16, capture guard source pair16 and current Native preparation APIs3 pass. Earlier all225-source auxiliary API build timed out and remains unverified. Separate Windows-linker-source compilation is rejected by Native E20 and remains open as C795.'
bit['currentQualification']='scripts/contracts/evidence/source13293/bitset25135-current/qualification.json';bit['currentSourceComparisonRecord']='scripts/contracts/evidence/source13293/bitset25135-current/source-comparison.json'
target=next(x for x in decisions if x['id']=='llvm-generation.target-descriptor-and-capability-configuration')
policy='src/Sollang.Compiler/Shared/Policies/WindowsLinkPolicy.cs';assert policy not in target['managedSources'];target['managedSources'].append(policy)
target['supportingSources']=sorted(set(target.get('supportingSources',[])+['src/Sollang.Compiler/Tooling/WindowsLinker.cs','selfhost/windows_linker.slg','selfhost/windows_imports.slg','selfhost/generated/windows_link_policy.slg']))
target['windowsTlsImportFocusedUnit']=dict(qualification=bit['currentQualification'],csharpProductionLink=3,slgProductionLink=4,currentNativeApiBuildAndRun=3,sharedPolicyGenerated=True,standaloneNativeLinkerSourceCompilation='C795 open; not qualified',claimsGoalComplete=False)
phase['latestFocusedUnit']='Current BitSet focused36, related31 and exact registered API3 qualified; shared Windows TLS exports fixed. Separate linker-source E20 is open; whole phase proof remains pending.'
write(detailPath,detail)
ledgerPath=R/'scripts/contracts/compiler-defects.json';ledger=read(ledgerPath)
for number in [791,792,793,794]:
 d=next(x for x in ledger['defects'] if x['id']==f'C2026-11-03-{number}');assert d['state']=='open';d['state']='candidate-fixed';d['qualification']=bit['currentQualification'];d['remaining']='Current focused unit qualified; whole source/runtime/Stage/platform gates remain. Separate C795 linker-source ownership mismatch is open.'
write(ledgerPath,ledger)
goalPath=R/'scripts/contracts/active-goal-progress.json';goal=read(goalPath);write(B/'bitset25135-goal-before.json',goal);scope='Current Windows BitSet: metadata16, actual CLI pair4 and independent arithmetic pair16; related31, hash/identity13 and source API controls separate. No whole source/runtime/Stage credit.'
goal['currentFocusedGate']='bitset25135-focused36';goal['currentFocusedGateDescription']=scope;goal['currentFocusedGateScope']=scope
goal['focusedGates'].append(dict(name=goal['currentFocusedGate'],status='complete',completed=36,total=36,percentage=100.0,failed=0,running=0,unexecuted=0,scope=scope,evidence=bit['currentQualification']))
goal['currentBitSetLayoutAndRegistrationUnit']=dict(status='current-focused-qualified-final-pending',defectIds=[f'C2026-11-03-{x}' for x in [791,792,793,794]],qualification=bit['currentQualification'],completed=36,total=36,relatedCompleted=31,relatedTotal=31,managedContracts=13,currentNativePreparationApis=3,remainingOwnershipMismatch='C2026-11-03-795',nextVerification='CSharp/native source comparison of task partial moves in Windows linker input before full source/runtime/Stage gates.')
intake=goal['currentSourceAssociationIntake'];intake.update(qualification=bit['currentQualification'],associationCompleted=459,associationTotal=712,associationPercentage=64.47,remainingAssociations=253,addedSourceAssociations=1)
write(goalPath,goal)
print(json.dumps(dict(status='recorded',focused='36/36',related='31/31',compilerClosed='363/791',associated='459/712',openC795=True,goalComplete=False)))

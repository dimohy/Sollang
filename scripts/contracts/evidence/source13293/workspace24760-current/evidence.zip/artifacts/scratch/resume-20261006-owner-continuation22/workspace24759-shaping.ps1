$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$root=(Get-Location).Path
$base=Join-Path $root 'artifacts/scratch/resume-20261006-owner-continuation22'
$evidence=Join-Path $root 'scripts/contracts/evidence/C2026-11-03-781'
$before=Get-Content (Join-Path $base 'workspace24741-csharp-first-product-before/result.json') -Raw | ConvertFrom-Json
$after=Get-Content (Join-Path $base 'workspace24746-csharp-first-product-after/result.json') -Raw | ConvertFrom-Json
$native=Get-Content (Join-Path $base 'workspace24754-native-first-product/result.json') -Raw | ConvertFrom-Json
$controls=Get-Content (Join-Path $base 'workspace24757-native-build-controls/result.json') -Raw | ConvertFrom-Json
if($before.status -ne 'failed' -or $before.cases[0].exit -ne 1 -or $after.status -ne 'passed' -or $native.status -ne 'passed' -or $controls.status -ne 'passed'){throw 'required focused proof missing'}
Copy-Item (Join-Path $base 'workspace24754-native-first-product/result.json') (Join-Path $evidence 'native-execution.json')
$inputContract=Get-Content (Join-Path $evidence 'input-contract.json') -Raw | ConvertFrom-Json
$arguments=@{
 DefectId='C2026-11-03-781';InputFingerprint=$inputContract.inputFingerprint
 BaselineCommand=($before.processes[0].command -join ' ')
 BaselineObservation=('[stdout]'+[Environment]::NewLine+$before.cases[0].stdout+'[stderr]'+[Environment]::NewLine+$before.cases[0].stderr)
 BaselineProvenance='scripts/contracts/evidence/C2026-11-03-781/baseline-execution.json'
 CandidateCommand=($after.processes[0].command -join ' ')
 CandidateObservation=('[stdout]'+[Environment]::NewLine+$after.cases[0].stdout+'[stderr]'+[Environment]::NewLine+$after.cases[0].stderr)
 CandidateProvenance='scripts/contracts/evidence/C2026-11-03-781/csharp-execution.json'
 Reason='Share the named-product-or-ordinal-first default across project resolution, initial workspace member and independent workspace members. Actual CSharp and Native resolve the same alternate-product fixture and preserve exact12 resolution cases plus selected-package build controls. Focused repair qualified; final original/source/runtime/Stage closure remains pending.'
 AssetKind='invariant';AuthorityPath='src/Sollang.Compiler/Cli/ProjectGraph.cs'
 SourceEvidence=@('scripts/contracts/evidence/C2026-11-03-781/source-comparison.json','scripts/contracts/evidence/C2026-11-03-781/baseline-execution.json','scripts/contracts/evidence/C2026-11-03-781/input-contract.json')
 ValidatorEvidence=@('scripts/contracts/evidence/C2026-11-03-781/csharp-execution.json','scripts/contracts/evidence/C2026-11-03-781/native-execution.json','artifacts/scratch/resume-20261006-owner-continuation22/workspace24753-native/result.json','artifacts/scratch/resume-20261006-owner-continuation22/workspace24757-native-build-controls/result.json')
 ConsumerEvidence=@('src/Sollang.Compiler/Cli/ProjectGraph.cs','selfhost/cli_project.slg','selfhost/cli_workspace.slg','tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.slg')
}
& (Join-Path $root 'scripts/preserve-compiler-defect-shaping-evidence.ps1') @arguments
if($LASTEXITCODE -ne 0){throw 'shaping evaluator failed'}

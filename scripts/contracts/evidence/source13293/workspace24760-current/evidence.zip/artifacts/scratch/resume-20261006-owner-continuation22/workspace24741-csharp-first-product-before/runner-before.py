from pathlib import Path
import sys,json,hashlib,shutil
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();fixture=R/'examples/regression/projects/437-workspace/packages/base'
initialize_output(R,O,reusable_directories=[B/'process24716-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir();tree=O/'tree';tree.mkdir();shutil.copytree(fixture,tree/'member',ignore=shutil.ignore_patterns('sollang.lock'))
p=tree/'member/sollang.project';s=p.read_text(encoding='utf-8-sig');assert 'root: "src/base.slg"' in s;p.write_text(s.replace('root: "src/base.slg"','products: { alternative: "src/base.slg" }'),encoding='utf-8');(tree/'sollang.workspace').write_text('workspace { members: [ "member" ] }\n',encoding='utf-8')
pins={str(p.resolve()):sha(p) for p in [Path(__file__),C,*managed_runtime_inputs(C),*sorted((R/'src/Sollang.Compiler/Cli').glob('*.cs')),*[p for p in tree.rglob('*') if p.is_file()]]}
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=1,cases=[],inputHashes=pins,scope='A workspace member with only an alternate product is resolvable without selecting a build product',claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  r=ex.run([str(C),'resolve','--workspace',str(tree)],O/'resolve',timeout=30);expected='Resolved 1 package(s) into '+str(tree/'sollang.lock')+'\n';passed=r.returncode==0 and not r.stderr and r.stdout.replace('\r\n','\n')==expected
  result['cases']=[dict(id='first-workspace-member-alternate-product',passed=passed,exit=r.returncode,stdout=r.stdout,stderr=r.stderr,expectedStdout=expected)]
  assert passed,'FIRST_WORKSPACE_MEMBER_PRODUCT_SELECTION_MISMATCH'
  result.update(status='passed',completed=1)
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

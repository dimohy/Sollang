from pathlib import Path
import sys,json,hashlib,time
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=B/'process24705-managed/compiler/Sollang.Compiler.exe';O=B/'workspace24734-discovery';manifest=R/'scripts/probes/workspace-resolve/discovery.sources.txt';sources=[R/p for p in manifest.read_text().splitlines() if p];fixture=R/'examples/regression/projects/437-workspace';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
pins={str(p.resolve()):sha(p) for p in [Path(__file__),C,*managed_runtime_inputs(C),manifest,*sources,*sorted((R/'stdlib').rglob('*.slg')),*[p for p in fixture.rglob('*') if p.is_file()]]}
initialize_output(R,O,reusable_directories=[B/'process24716-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=3,cases=[],inputHashes=pins,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None;start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start))
 try:
  exe=O/'probe.exe';r=ex.run([str(C),'build',*map(str,sources),'-o',str(exe),'--target','windows-x64','--keep-temps','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')],O/'build',timeout=budget());assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  for name,root,filename,expected in [('workspace',fixture/'apps/app/src','sollang.workspace',str(fixture/'sollang.workspace')),('project',fixture/'apps/app/src','sollang.project',str(fixture/'apps/app/sollang.project')),('absent',R,'sollang-absent-discovery24732.project','none')]:
   r=ex.run([str(exe),str(root),filename],O/name,timeout=budget());assert r.returncode==0 and not r.stderr and r.stdout.strip()==expected,r.stdout+r.stderr
   result['cases'].append(dict(id=name,passed=True,expected=expected,actual=r.stdout.strip()));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

from pathlib import Path
import sys,json,hashlib,shutil,time
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve();fixture=R/'examples/regression/projects/437-workspace';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
initialize_output(R,O,reusable_directories=[B/'workspace24738-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir();tree=O/'tree';shutil.copytree(fixture,tree)
expected=R/'examples/regression/expected/437-workspace.stdout.txt';files=[Path(__file__),C,*(managed_runtime_inputs(C) if C.name!='compiler.exe' else []),expected,*[p for p in fixture.rglob('*') if p.is_file()],*[p for p in tree.rglob('*') if p.is_file()],*sorted((R/'selfhost').rglob('*.slg')),*sorted((R/'stdlib').rglob('*.slg'))];pins={str(p.resolve()):sha(p) for p in files}
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=2,cases=[],inputHashes=pins,scope='Existing workspace build package selection and actual original437 locked build/runtime remain intact after resolution loader reuse',claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  args=[str(C),'build','--workspace',str(tree),'--locked','--target','windows-x64','--keep-temps','-O1','--jobs','4','--llvm',str(R/'.tools/llvm-22.1.8')]
  if C.name=='compiler.exe':args+=['--stdlib',str(R/'stdlib')]
  r=ex.run(args,O/'selection',timeout=180);diagnostic='sollang: workspace has multiple packages; select one with --package: app, base, math\n';assert r.returncode==1 and not r.stdout and r.stderr.replace('\r\n','\n')==diagnostic,r.stdout+r.stderr
  result['cases'].append(dict(id='build-still-requires-package-selection',passed=True,stderr=diagnostic));result['completed']+=1;ex.save()
  start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));exe=O/'program.exe';r=ex.run([*args,'--package','app','-o',str(exe)],O/'build',timeout=budget());assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  r=ex.run([str(exe)],O/'run',timeout=budget());oracle=expected.read_text(encoding='utf-8-sig').replace('\r\n','\n');assert r.returncode==0 and not r.stderr and r.stdout.replace('\r\n','\n')==oracle,r.stdout+r.stderr
  result['cases'].append(dict(id='original437-selected-package-locked-build-runtime',passed=True,stdout=oracle));result['completed']+=1;result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

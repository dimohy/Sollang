from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess,copy,datetime
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/workspace24760-current';D=R/'scripts/contracts/evidence/C2026-11-03-781';read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda d:hashlib.sha256(d).hexdigest().upper();rel=lambda p:str(p.relative_to(R)).replace('\\','/')
def write(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
fingerprints={str(p.relative_to(B/'workspace24754-native-first-product/tree')).replace('\\','/'):sha(p.read_bytes()) for p in (B/'workspace24754-native-first-product/tree').rglob('*') if p.is_file() and p.name!='sollang.lock'}
assert fingerprints==read(D/'input-contract.json')['fixtureHashes']
write(D/'evaluation.json',dict(allowed=True,code='AS-US-001-STRUCTURED-AND-APPLIED',command='node ../AgenticShaping/evals/unstructured-to-structured.mjs --trace scripts/contracts/evidence/C2026-11-03-781/as-us-001.json',traceSha256=sha((D/'as-us-001.json').read_bytes()),scope='Actual preservation-tool evaluation and direct node invocation both returned allowed=true; local focused compiler asset only, not Slogs policy or global goal completion.',nativeFixtureByteIdentityVerified=True))
closures=[]
for name in ['process24687-managed','process24716-native','workspace24734-discovery','workspace24737-stdlib','workspace24739-semantic','workspace24747-semantic','workspace24748-stdlib','workspace24756-csharp-build-controls','workspace24757-native-build-controls','workspace24738-native']:
 folder=B/name;j=read(folder/'artifact-cleanup-plan.json.execution.json');assert j['status']=='completed'
 dest=E/'lifecycle'/name;dest.mkdir(parents=True,exist_ok=True)
 for p in folder.glob('artifact-cleanup-plan.json*'):shutil.copyfile(p,dest/p.name)
 closures.append(dict(output=rel(folder),reclaimedBytes=j['reclaimedBytes'],execution=rel(dest/'artifact-cleanup-plan.json.execution.json')))
roots=[B/'workspace24738-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01'];assert all((p/'compiler.exe').is_file() for p in roots);assert not (B/'process24716-native/compiler.exe').exists()
write(E/'artifact-lifecycle.json',dict(status='completed-for-listed-outputs',reclaimedBytes=sum(r['reclaimedBytes'] for r in closures),outputs=closures,reusableNativeCompilerDirectories=[rel(p) for p in roots],reusableNativeCompilerCount=3,managedCompiler='workspace24743-managed retained for pending focused consumers',failedOutputsPreserved=True,historicalExtensionlessElf='target24666 remains preserved pending canonical ownership repair; not reported as cleaned.'))
archive=E/'evidence.zip';manifest=read(E/'archive-manifest.json')
with zipfile.ZipFile(archive) as z:
 entries={p:z.read(p) for p in z.namelist()};assert set(entries)==set(manifest['entries'])
 for p,data in entries.items():assert sha(data)==manifest['entries'][p]['sha256']
for p in D.rglob('*'):
 if p.is_file():entries[rel(p)]=p.read_bytes()
entries[rel(Path(__file__))]=Path(__file__).read_bytes()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,data in sorted(entries.items()):z.writestr(p,data)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(entries)
 for p in z.namelist():assert sha(z.read(p))==sha(entries[p])
write(E/'archive-manifest.json',dict(archiveSha256=sha(archive.read_bytes()),entries={p:dict(sha256=sha(data),bytes=len(data)) for p,data in sorted(entries.items())},readbackVerified=True))
q=read(E/'qualification.json');q['archive'].update(sha256=sha(archive.read_bytes()),entries=len(entries));q['artifactLifecycle']='artifact-lifecycle.json';q['newDefectState']='C2026-11-03-781 candidate-fixed; final gates pending';q['scopedShapingEvaluation']=rel(D/'evaluation.json');write(E/'qualification.json',q)
qualified=rel(E/'qualification.json');gate=dict(name='workspace24731-resolve-pair24',status='passed',completed=24,total=24,percentage=100.0,scope='CSharp12/Native12 project/workspace resolve and option oracles. Product-selection2, existing-build4 and preparatory checks are separate supporting contracts.',evidence=qualified)
unit=dict(status='focused-qualified-final-pending',completed=24,total=24,percentage=100.0,qualification=qualified,sourceComparison=rel(E/'resolve-source-comparison.json'),managedRecord=rel(E/'workspace24745-csharp.json'),nativeRecord=rel(E/'workspace24753-native.json'),newlyRegisteredDefect='C2026-11-03-781',compilerStates=dict(closed=363,candidateFixed=412,open=2,total=777),supportingProductSelection=dict(completed=2,total=2,percentage=100.0,evidence=rel(D/'native-execution.json'),nonAdditiveToMain24=True),relatedBuildControls=dict(completed=4,total=4,percentage=100.0,evidence=qualified,nonAdditiveToMain24=True),claimsGoalComplete=False,claimsWholePhaseComplete=False)
def updateProgress(j):
 j.update(currentFocusedGate=gate['name'],currentWorkspaceResolveUnit=copy.deepcopy(unit));j['focusedGates']=[g for g in j['focusedGates'] if g['name']!=gate['name']]+[copy.deepcopy(gate)]
def updateDetail(j):
 for p in j['phaseProgress']:
  if p['phase']!='llvm-generation':continue
  inventory=p['decisionInventory'];inventory['previousCompleteFileReviewBeforeWorkspace24760']=inventory['currentCompleteFileReview'];inventory['currentCompleteFileReview']=rel(E/'source-review-reconciliation.json');inventory['currentAuthoredDeltaReview']=rel(E/'source-review-reconciliation.json');inventory['workspaceResolveFocusedUnit']=copy.deepcopy(unit)
for name,update in [('scripts/contracts/active-goal-progress.json',updateProgress),('scripts/contracts/structural-parity-detail.json',updateDetail)]:
 path=R/name;work=read(path);base=json.loads(subprocess.check_output(['git','show','HEAD:'+name]).decode('utf-8'));update(work);update(base);write(path,work)
 data=(json.dumps(base,ensure_ascii=False,indent=2)+'\n').encode('utf-8');oid=subprocess.check_output(['git','hash-object','-w','--stdin'],input=data).decode().strip();subprocess.run(['git','update-index','--cacheinfo','100644',oid,name],check=True)
ledger=read(R/'scripts/contracts/compiler-defects.json');missing=[d['id'] for d in ledger['defects'] if int(d['id'].rsplit('-',1)[-1])>=208 and not d.get('shapingEvidence')]
write(E/'ledger-scope.json',dict(total=777,closed=363,candidateFixed=412,open=2,newDefect='C2026-11-03-781',newScopedEvaluation=rel(D/'evaluation.json'),knownMissingShapingEvidenceCount=len(missing),knownMissingShapingEvidence=missing,claimsFullLedgerValidationPassed=False))
protected=read(B/'block24016-protected-inputs.json');assert all(sha((R/p).read_bytes())==h for p,h in protected.items())
print(json.dumps(dict(qualified='24/24 + separate product2 and build4',archiveEntries=len(entries),archiveBytes=archive.stat().st_size,reclaimedBytes=sum(r['reclaimedBytes'] for r in closures),missingShapingEvidence=len(missing),selectiveMetadataStaged=True,protectedInputsUnchanged='8/8')))

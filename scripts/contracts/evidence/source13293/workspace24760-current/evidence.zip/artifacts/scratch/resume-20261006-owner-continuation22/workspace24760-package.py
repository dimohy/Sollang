from pathlib import Path
import json,hashlib,zipfile,datetime,shutil
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/workspace24760-current';E.mkdir(exist_ok=False);D=R/'scripts/contracts/evidence/C2026-11-03-781'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda data:hashlib.sha256(data).hexdigest().upper();rel=lambda p:str(p.relative_to(R)).replace('\\','/')
def write(name,j):(E/name).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
passed=['workspace24729-csharp','workspace24734-discovery','workspace24737-stdlib','workspace24739-semantic','workspace24743-managed','workspace24745-csharp','workspace24746-csharp-first-product-after','workspace24747-semantic','workspace24748-stdlib','workspace24738-native','workspace24753-native','workspace24754-native-first-product','workspace24756-csharp-build-controls','workspace24757-native-build-controls']
failed=['workspace24730-native-before','workspace24732-discovery','workspace24733-discovery','workspace24736-semantic','workspace24741-csharp-first-product-before'];records={n:read(B/n/'result.json') for n in passed+failed}
for n in passed:
 j=records[n];assert j['status']=='passed' and j['completed']==j['total'] and j['inputsStable'] and j['processesStopped'],n
current=['workspace24745-csharp','workspace24746-csharp-first-product-after','workspace24747-semantic','workspace24748-stdlib','workspace24738-native','workspace24753-native','workspace24754-native-first-product','workspace24756-csharp-build-controls','workspace24757-native-build-controls']
for n in current:assert all(Path(p).is_file() and sha(Path(p).read_bytes())==h for p,h in records[n]['inputHashes'].items()),n
protected=read(B/'block24016-protected-inputs.json');assert all(sha((R/p).read_bytes())==h for p,h in protected.items())
lockRows=[]
for n in ['workspace24745-csharp','workspace24753-native','workspace24746-csharp-first-product-after','workspace24754-native-first-product']:
 for row in records[n]['cases']:
  if 'expectedLock' not in row:continue
  p=Path(row['allowedMutation']) if row.get('allowedMutation') else B/n/'tree/sollang.lock';data=p.read_bytes();assert data==row['expectedLock'].encode('utf-8'),str(p)
  if row.get('lockSha256'):assert sha(data)==row['lockSha256']
  lockRows.append(dict(path=rel(p),sha256=sha(data),bytes=len(data),encoding='UTF8-no-BOM-exact-LF',sourceRecord=rel(B/n/'result.json')))
assert len(lockRows)==16
write('lock-byte-readback.json',dict(completed=16,total=16,rows=lockRows,claimsAdditionalTestCredit=False))
prev=R/'scripts/contracts/evidence/source13293/target24726-current/source-review-reconciliation.json';j=read(prev);sources={};changed=[];driver='tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.slg'
for name,row in j['sources'].items():
 h=sha((R/name).read_bytes())
 if h==row['currentSha256']:sources[name]=dict(currentSha256=h,reviewMethod='exact-byte-reuse',previousReview=rel(prev),physicalReviewState='current-complete')
 else:
  assert name==driver,name;before=B/'workspace24731-source-comparison/before'/name;assert sha(before.read_bytes())==row['currentSha256'];changed.append(name)
  sources[name]=dict(currentSha256=h,previousSha256=row['currentSha256'],reviewMethod='direct-complete-authored-delta-read',previousReview=rel(prev),inspection='Resolve command shares manifest ancestor discovery, the workspace loader and path graph. Option presence/errors match CSharp, implicit discovery prefers workspace, resolution visits all members without build selection, lock root is an independent immutable Path and ensureAt owns publication. Actual CSharp12/Native12 and original437 locked build/selection controls passed.',physicalReviewState='current-complete')
assert len(sources)==156 and changed==[driver]
extra={
 'src/Sollang.Compiler/Cli/ProjectGraph.cs':'Shared ImplicitProductName applies same-named then ordinal-first selection for project resolution, first workspace member and independent workspace members. Dependency same-named-product requirement and selected builds retain existing branches; actual first-member alternate-product CSharp1/Native1 passed.',
 'selfhost/cli_workspace.slg':'Load and loadForResolution share loadCore; requireSelection=true preserves old build diagnostics, false selects first ordinal validated member. Existing parsing, member confinement and duplicate validation unchanged.',
 'selfhost/cli_project.slg':'Added resolution-only wrapper using existing graph core with source collection disabled; all package traversal, workspace membership, dependency and version decisions reused.',
 'selfhost/manifest_entry.slg':'Added nearest-ancestor search with one absolute Path owner and scalar prefix cursor. Native absolute-parent resolution preserves roots; return diagnostics materialize in caller storage. Original manifest resolution unchanged. Discovery3 and actual CLI discovery/absence controls passed.'}
write('source-review-reconciliation.json',dict(schemaVersion=1,status='current-scoped-physical-review-delta-qualified-phase-pending',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),completed=156,total=156,sources=sources,authoredDeltas=changed,additionalAuthoredDeltaReviews={p:dict(currentSha256=sha((R/p).read_bytes()),inspection=note,claimsCompletePhysicalFileReview=False) for p,note in extra.items()},claimsWholePhaseComplete=False,claimsGoalComplete=False))
entries={}
def add(p):
 if p.is_file():
  name=rel(p);data=p.read_bytes();assert name not in entries or entries[name]==data;entries[name]=data
for n in passed+failed:
 shutil.copyfile(B/n/'result.json',E/(n+'.json'))
 for p in (B/n).rglob('*'):
  if p.is_file() and not {'.sollang-cache','obj','bin','dotnet-artifacts'}.intersection(p.parts) and (p.suffix.lower() in {'.json','.txt','.log','.stdout','.stderr','.py','.ps1','.slg','.project','.workspace','.cs'} or p.name=='sollang.lock'):add(p)
for folder in [B/'workspace24731-source-comparison',B/'workspace24742-product-selection-comparison',D,R/'scripts/probes/workspace-resolve']:
 for p in folder.rglob('*'):add(p)
for pattern in ['workspace247*.py','workspace247*.ps1','workspace247*.slg']:
 for p in B.glob(pattern):add(p)
for n in current:
 for name,h in records[n]['inputHashes'].items():
  p=Path(name)
  if p.is_relative_to(R) and 'artifacts' not in p.relative_to(R).parts and p.suffix.lower() in {'.cs','.slg','.json','.ps1','.py','.txt','.props','.targets','.csproj','.grammar','.lexer','.project','.workspace'} and sha(p.read_bytes())==h:add(p)
add(Path(__file__));archive=E/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(entries)
 for name in z.namelist():assert sha(z.read(name))==sha(entries[name])
write('archive-manifest.json',dict(archiveSha256=sha(archive.read_bytes()),entries={name:dict(sha256=sha(data),bytes=len(data)) for name,data in sorted(entries.items())},readbackVerified=True))
write('protected-inputs.json',dict(completed=8,total=8,hashes=protected))
for src,name in [(B/'workspace24731-source-comparison/source-comparison.json','resolve-source-comparison.json'),(B/'workspace24731-source-comparison/native-build-plan.json','native-build-plan.json')]:shutil.copyfile(src,E/name)
write('qualification.json',dict(schemaVersion=1,status='focused-qualified-final-pending',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),managedFirst=True,pairedResolution=dict(completed=24,total=24,managed='workspace24745-csharp.json',native='workspace24753-native.json'),supportingProductSelection=dict(completed=2,total=2,managed='workspace24746-csharp-first-product-after.json',native='workspace24754-native-first-product.json',defectId='C2026-11-03-781'),relatedBuildControls=dict(completed=4,total=4,managed='workspace24756-csharp-build-controls.json',native='workspace24757-native-build-controls.json'),nativeProducer='workspace24738-native.json',prerequisites=dict(semantic='passed4/4',fullStdlib='passed1/1',discovery='passed3/3'),lockByteReadback='lock-byte-readback.json',sourceComparisons=[rel(E/'resolve-source-comparison.json'),rel(D/'source-comparison.json')],sourceReview='source-review-reconciliation.json',archive=dict(path='evidence.zip',sha256=sha(archive.read_bytes()),entries=len(entries),readbackVerified=True),nonAdditive='Resolution24, product-selection2 and build-controls4 remain separate contracts. Seed, preflights, build and lock readback are supporting only.',claimsGoalComplete=False,claimsWholePhaseComplete=False,claimsDefectClosed=False,remaining=['Original1999 Native whole180/O1/jobs4 timeout remains; no unchanged replay or profiling-budget reset.','Full source7/runtime2708/Stage2/Stage3/frozen stdlib-runtime22 and platform/performance acceptance pending.','Path dependency resolution scope only; full Git/registry transport and platform support not qualified here. Windows linker partitioning remains separate source work.','Short standalone WSL descendant checks remain failed despite complete actual target-linking unit6 qualified in prior commit.','Preexisting39 missing shapingEvidence and progress report evaluator remain unresolved/unverified; no policy completion claim.','Historical extensionless target24666 ELF remains preserved pending canonical output-ownership repair.','Provisional helper failures32/33 were corrected through normal owned-path and caller diagnostic-storage contracts, not compiler diagnostic suppression. Failed36 remains raw; successful stale-source stdlib37 is historical only.']))
p=R/'scripts/contracts/compiler-defects.json';ledger=read(p);defect=next(d for d in ledger['defects'] if d['id']=='C2026-11-03-781');defect.update(state='candidate-fixed',candidateEvidence=[rel(D/'csharp-execution.json'),rel(D/'native-execution.json'),rel(E/'qualification.json')],shapingEvidence=dict(inputFingerprint=read(D/'input-contract.json')['inputFingerprint'],baselineReceipt=rel(D/'baseline.json'),candidateReceipt=rel(D/'candidate.json'),tracePath=rel(D/'as-us-001.json')));p.write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
counts={state:sum(d['state']==state for d in ledger['defects']) for state in ['closed','candidate-fixed','open']};assert counts=={'closed':363,'candidate-fixed':412,'open':2} and len(ledger['defects'])==777
print(json.dumps(dict(evidence=rel(E),resolutionPair='24/24',productSelection='2/2',buildControls='4/4',exactLockReadbacks=16,archiveEntries=len(entries),archiveBytes=archive.stat().st_size,compilerCounts=counts,totalDefects=777)))

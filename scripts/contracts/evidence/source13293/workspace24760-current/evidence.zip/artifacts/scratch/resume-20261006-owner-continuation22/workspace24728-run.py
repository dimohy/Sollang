from pathlib import Path
import sys,json,hashlib,shutil
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=Path(sys.argv[1]).resolve();O=Path(sys.argv[2]).resolve();contract=R/'scripts/probes/workspace-resolve/contract.json';plan=json.loads(contract.read_text());fixture=R/plan['workspaceFixture'];golden=R/plan['workspaceGolden'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();read=lambda p:Path(p).read_text(encoding='utf-8-sig').replace('\r\n','\n')
initialize_output(R,O,reusable_directories=[B/'process24716-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
assert len(plan['cases'])==12 and plan['pairedTotal']==24
for ancestor in [R,*R.parents]:
 assert not any((ancestor/n).exists() for n in ['sollang.project','sollang.workspace']), 'ANCESTOR_MANIFEST_CHANGES_DISCOVERY_ORACLE'
prepared=[]
for case in plan['cases']:
 folder=O/case['id'];folder.mkdir();tree=folder/'tree';mode=case['mode'];lock=None;cwd=folder
 if mode in ['workspace','project-in-workspace']:
  shutil.copytree(fixture,tree,ignore=shutil.ignore_patterns('sollang.lock'));project=tree/'packages/base'
  if mode=='workspace':
   lock=tree/'sollang.lock';expected=read(golden);target=tree;option='--workspace'
   if case['selection']=='discovery':cwd=tree/'apps/app/src'
  else:lock=project/'sollang.lock';target=project;option='--project';cwd=tree/'apps/app/src'
 elif mode=='project':
  shutil.copytree(fixture/'packages/base',tree,ignore=shutil.ignore_patterns('sollang.lock'));target=tree;lock=tree/'sollang.lock';option='--project'
  if case['selection']=='discovery':cwd=tree/'src'
 if mode.startswith('project'):
  expected='lock {\n    format: 2\n    packages: [\n        {\n            id: "base@1.4.0"\n            source: "path:."\n            dependencies: []\n        }\n    ]\n}\n'
 if lock and case.get('staleLock'):lock.write_text('stale lock must be replaced\n',encoding='utf-8')
 if mode=='diagnostic':args=case['arguments']
 elif case['selection']=='discovery':args=[]
 else:args=[option,str(target/('sollang.workspace' if mode=='workspace' else 'sollang.project')) if case['selection']=='manifest' else str(target)]
 prepared.append((case,folder,cwd,args,lock,expected if lock else None))
files=[Path(__file__),contract,C,*(managed_runtime_inputs(C) if C.name!='compiler.exe' else []),*sorted(fixture.rglob('*')),*sorted((R/'src/Sollang.Compiler').rglob('*.cs')),*sorted((R/'selfhost').rglob('*.slg')),*sorted((R/'stdlib').rglob('*.slg')),*[p for p in O.rglob('*') if p.is_file() and p.name!='sollang.lock']]
pins={str(p.resolve()):sha(p) for p in files if p.is_file()};stable=lambda:all(Path(p).is_file() and sha(p)==h for p,h in pins.items())
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=12,cases=[],processes=[],inputHashes=pins,scope=plan['scope'],compiler=str(C),claimsGoalComplete=False);err=None
 try:
  for case,folder,cwd,args,lock,expected in prepared:
   row=dict(id=case['id'],status='running',workingDirectory=str(cwd),allowedMutation=str(lock) if lock else None);ex=VerificationExecution(cwd,O,row,stable,sha,record_path=O/(case['id']+'.json'));failure=None
   try:
    done=ex.run([str(C),'resolve',*args],folder/'resolve',timeout=plan['maximumCaseSeconds']);stdout=done.stdout.replace('\r\n','\n');stderr=done.stderr.replace('\r\n','\n')
    expectedOut=f'Resolved {3 if case["mode"]=="workspace" else 1} package(s) into {lock}\n' if lock else ''
    ok=done.returncode==case['exit'] and stdout==expectedOut and stderr==case.get('stderr','')
    if lock:
     ok=ok and lock.is_file() and read(lock)==expected
     row.update(expectedLock=expected,actualLock=read(lock) if lock.is_file() else None,lockSha256=sha(lock) if lock.is_file() else None)
    row.update(status='passed' if ok else 'failed',passed=ok,expectedExit=case['exit'],actualExit=done.returncode,expectedStdout=expectedOut,actualStdout=stdout,expectedStderr=case.get('stderr',''),actualStderr=stderr)
   except BaseException as e:failure=e;row.update(status='failed',passed=False)
   finally:ex.finalize(failure,cleanup=False)
   result['cases'].append(row);result['processes'].extend(row['processes']);result['completed']+=int(row.get('passed') is True and row['processesStopped'] and row['inputsStable']);(O/'result.json').write_text(json.dumps(result,indent=2)+'\n')
   if failure:raise failure
  assert result['completed']==result['total'],'WORKSPACE_RESOLVE_CONTRACT_MISMATCH'
  result['status']='passed'
 except BaseException as e:err=e;result.update(status='failed',failure=str(e))
 finally:
  result.update(inputsStable=stable(),processesStopped=all(r.get('shutdownConfirmed') and isinstance(r.get('exit'),int) for r in result['processes']));(O/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 if err:raise err
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

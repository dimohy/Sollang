using System.Globalization;
using Sollang.Compiler.Diagnostics;

namespace Sollang.Compiler.CodeGen;

internal sealed partial class LlvmEmitter
{
    private (MemoryOutputSink Owner, string Label, MemoryOutputSink Output)? _scopeJoinPhis;

    private void EmitLabel(string label)
    {
        EmitFunctionLine($"{label}:");
        _currentBlockLabel = label;
        _currentBlockTerminated = false;
    }

    private void EmitInstruction(string instruction)
    {
        EmitFunctionLine($"  {instruction}");
    }

    private void EmitAssign(string target, string expression)
    {
        EmitInstruction($"{target} = {expression}");
    }

    private void EmitBranch(string label)
    {
        EmitInstruction($"br label %{label}");
        _currentBlockTerminated = true;
    }

    private void EmitConditionalBranch(string condition, string trueLabel, string falseLabel)
    {
        EmitInstruction($"br i1 {condition}, label %{trueLabel}, label %{falseLabel}");
        _currentBlockTerminated = true;
    }

    private void EmitRet(string typeName, string value)
    {
        EmitInstruction($"ret {typeName} {value}");
        _currentBlockTerminated = true;
    }

    private void EmitTrap()
    {
        EmitInstruction("call void @llvm.trap()");
        EmitUnreachable();
    }

    private void EmitUnreachable()
    {
        EmitInstruction("unreachable");
        _currentBlockTerminated = true;
    }

    private void EmitAlloca(string target, string typeName, int align)
    {
        RequireStorageType(typeName, $"allocation '{target}'");
        var instruction = $"  {target} = alloca {typeName}, align {align.ToString(CultureInfo.InvariantCulture)}{Environment.NewLine}";
        if (_currentHoistedAllocas is not null)
        {
            _currentHoistedAllocas.Write(instruction);
            return;
        }

        _activeFunctions.Write(instruction);
    }

    private void EmitLoad(string target, string typeName, string pointer, int align)
    {
        RequireStorageType(typeName, $"load '{target}'");
        EmitAssign(target, $"load {typeName}, ptr {pointer}, align {align.ToString(CultureInfo.InvariantCulture)}");
    }

    private void EmitStore(string typeName, string value, string pointer, int align)
    {
        RequireStorageType(typeName, $"store to '{pointer}'");
        EmitInstruction($"store {typeName} {value}, ptr {pointer}, align {align.ToString(CultureInfo.InvariantCulture)}");
    }

    private static void RequireStorageType(string typeName, string operation)
    {
        if (typeName == "void")
        {
            throw new SollangException(
                $"compiler error S006: {operation} has no canonical storage type; value-producing typed IR cannot use Unit storage");
        }
    }

    private void EmitCall(string? target, string returnType, string functionName, string arguments)
    {
        var call = $"call {returnType} @{functionName}({arguments})";
        if (target is null)
        {
            EmitInstruction(call);
            return;
        }

        EmitAssign(target, call);
    }

    private void EmitIndirectCall(string? target, string returnType, string functionPointer, string arguments)
    {
        var call = $"call {returnType} {functionPointer}({arguments})";
        if (target is null)
        {
            EmitInstruction(call);
            return;
        }

        EmitAssign(target, call);
    }

    private void EmitBinary(string target, string operation, string typeName, string left, string right)
    {
        EmitAssign(target, $"{operation} {typeName} {left}, {right}");
    }

    private void EmitCompare(string target, string predicate, string typeName, string left, string right)
    {
        EmitAssign(target, $"icmp {predicate} {typeName} {left}, {right}");
    }

    private void EmitSelect(string target, string condition, string trueValue, string falseValue)
    {
        EmitAssign(target, $"select i1 {condition}, {trueValue}, {falseValue}");
    }

    private void EmitPhi(string target, string typeName, params (string Value, string Label)[] incoming)
    {
        if (_scopeJoinPhis is { } join
            && ReferenceEquals(join.Owner, _activeFunctions)
            && join.Label == _currentBlockLabel)
        {
            join.Output.WriteLine($"  {target} = phi {typeName} {FormatPhiIncoming(incoming)}");
            return;
        }
        EmitAssign(target, $"phi {typeName} {FormatPhiIncoming(incoming)}");
    }

    private static string FormatPhiIncoming(IEnumerable<(string Value, string Label)> incoming)
    {
        return string.Join(
            ", ",
            incoming.Select(static item => $"[ {item.Value}, %{item.Label} ]"));
    }
}

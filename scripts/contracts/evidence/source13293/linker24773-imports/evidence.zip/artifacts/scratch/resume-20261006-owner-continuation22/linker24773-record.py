from pathlib import Path
import json,hashlib,zipfile,subprocess,copy,datetime
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/linker24773-imports';E.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest().upper();read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));write=lambda p,j:Path(p).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');rel=lambda p:Path(p).relative_to(R).as_posix()
records={'baseline':'linker24764-csharp','csharpCurrent':'linker24767-csharp','managedSourceImports':'linker24770-imports','nativeSourceImports':'linker24771-native-imports','canonicalSemantic':'linker24772-semantic'}
entries={}
for key,name in records.items():
 out=B/name;j=read(out/'result.json');assert j['status']=='passed' and j['inputsStable'] and j['processesStopped'];write(E/(key+'.json'),j)
 for p in out.rglob('*'):
  if p.is_file() and (p.suffix in {'.json','.txt','.def','.cs','.csproj'} or p.name=='input.ll'):
   entries[rel(p)]=p.read_bytes()
for name in ['linker24763-csharp','linker24769-imports']:
 j=read(B/name/'result.json');assert j['status']=='failed';entries[rel(B/name/'result.json')]=(B/name/'result.json').read_bytes()
for p in [*R.joinpath('scripts/probes/windows-linker').glob('*'),R/'src/Sollang.Compiler/Tooling/WindowsLinker.cs',R/'src/Sollang.Compiler/Shared/Policies/WindowsLinkPolicy.cs',R/'selfhost/toolchain.slg',R/'selfhost/generated/windows_link_policy.slg',R/'tests/Sollang.ExampleTests/Fixtures/selfhost-sollangc-driver.sources.txt',R/'scripts/probes/target-linking/sources.txt',R/'scripts/probes/dictionary-storage-boundaries/geometry.sources.txt',R/'docs/AI_SLG_BEST_PRACTICES.md',B/'linker24768-comparison.json',*B.glob('linker2476*.py'),B/'linker24770-imports.py',B/'linker24771-native-imports.py',Path(__file__)]:
 if p.is_file():entries[rel(p)]=p.read_bytes()
archive=E/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(entries)
 for name,data in entries.items():assert z.read(name)==data
write(E/'archive-manifest.json',dict(archiveSha256=sha(archive.read_bytes()),readbackVerified=True,entries={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(entries.items())}))
(E/'.gitattributes').write_text('* -text whitespace=cr-at-eol\n',encoding='utf-8')
q=dict(schemaVersion=1,status='import-foundation-qualified-full-linker-pending',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),csharp=dict(completed=8,total=8,evidence='csharpCurrent.json'),importAdapterPair=dict(completed=4,total=4,evidence=['managedSourceImports.json','nativeSourceImports.json'],nonAdditiveToMain16=True),canonicalSemantic=dict(completed=4,total=4,evidence='canonicalSemantic.json'),currentFocused=dict(completed=8,total=16,percentage=50.0,scope='Windows linker paired contract; SLG linker eight cases still pending'),remaining=['Use generated imports in the complete Windows driver object/link transaction.','Match partition decisions and process concurrency.','Implement and prove effective processor count with affinity, job quotas and configuration.','Match captured tool failures, stack and DLL link flags.','Original1999 timeout, C385/C742 and whole-source/runtime/Stage/platform gates remain unresolved.'],archive=dict(path='evidence.zip',entries=len(entries),sha256=sha(archive.read_bytes())),claimsGoalComplete=False,claimsWholeWindowsLinkerEquivalent=False)
write(E/'qualification.json',q)
gate=dict(name='windows-linker24763-pair16',status='running',completed=8,total=16,percentage=50.0,scope='CSharp8 passed; SLG8 pending. Import adapters4 and semantic4 are separate supporting contracts.',evidence=rel(E/'qualification.json'))
unit=dict(status=q['status'],completed=8,total=16,percentage=50.0,qualification=rel(E/'qualification.json'),sourceComparison=rel(B/'linker24768-comparison.json'),supportingImportPair=dict(completed=4,total=4,nonAdditiveToMain16=True),claimsGoalComplete=False)
name='scripts/contracts/active-goal-progress.json';path=R/name;work=read(path);base=json.loads(subprocess.check_output(['git','show','HEAD:'+name]).decode('utf-8'))
for j in [work,base]:j.update(currentFocusedGate=gate['name'],currentWindowsLinkerUnit=copy.deepcopy(unit));j['focusedGates']=[g for g in j['focusedGates'] if g['name']!=gate['name']]+[copy.deepcopy(gate)]
write(path,work);data=(json.dumps(base,ensure_ascii=False,indent=2)+'\n').encode();oid=subprocess.check_output(['git','hash-object','-w','--stdin'],input=data).decode().strip();subprocess.run(['git','update-index','--cacheinfo','100644',oid,name],check=True)
protected=read(B/'block24016-protected-inputs.json');assert all(sha((R/p).read_bytes())==h for p,h in protected.items())
print(json.dumps(dict(archiveEntries=len(entries),archiveBytes=archive.stat().st_size,readbackVerified=True,currentFocused='8/16',supportingImportAdapters='4/4',protectedInputs='8/8')))

from pathlib import Path
import sys,json,hashlib,time
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=B/'linker24766-managed/compiler/Sollang.Compiler.exe';O=B/'linker24769-imports';L=R/'.tools/llvm-22.1.8';manifest=R/'scripts/probes/windows-linker/imports.sources.txt';sources=[R/p for p in manifest.read_text().splitlines() if p];expected=R/'scripts/probes/windows-linker/expected-import-definitions.json';definitions=json.loads(expected.read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
inputs=[B/'linker24764-csharp'/case/'input.ll' for case in ['small-o0','optional-imports']]
pins={str(p.resolve()):sha(p) for p in [Path(__file__),manifest,expected,C,*managed_runtime_inputs(C),*sources,*inputs,*sorted((R/'stdlib').rglob('*.slg')),L/'bin/llvm-lib.exe']}
initialize_output(R,O,reusable_directories=[B/'workspace24738-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=2,cases=[],inputHashes=pins,claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None;start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start))
 try:
  exe=O/'probe.exe';r=ex.run([str(C),'build',*map(str,sources),'-o',str(exe),'--target','windows-x64','--keep-temps','-O1','--jobs','4','--llvm',str(L)],O/'build',timeout=budget());assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  for source in inputs:
   folder=O/source.parent.name;folder.mkdir();r=ex.run([str(exe),str(L/'bin/llvm-lib.exe'),str(source),str(folder)],folder/'run',timeout=budget());assert r.returncode==0 and not r.stderr and r.stdout.splitlines()[-1]=='result=0',r.stdout+r.stderr
   required=set(definitions) if source.parent.name=='optional-imports' else {'kernel32.def','shell32.def','ucrtbase.def'}
   assert {p.name for p in folder.glob('*.def')}==required
   for name in required:assert (folder/name).read_bytes()==definitions[name].encode(),name
   paths=r.stdout.splitlines()[:-1];assert [Path(p).name for p in paths]==[name.removesuffix('.def')+'.lib' for name in definitions if name in required]
   assert all(Path(p).is_file() for p in paths)
   result['cases'].append(dict(id=source.parent.name,passed=True,definitions=len(required),libraries=paths));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

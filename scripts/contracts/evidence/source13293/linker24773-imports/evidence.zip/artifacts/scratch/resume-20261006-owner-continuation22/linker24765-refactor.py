from pathlib import Path
import re,textwrap,json
r=Path.cwd(); p=r/'src/Sollang.Compiler/Tooling/WindowsLinker.cs';s=p.read_text()
definitions={}
for m in re.finditer(r'private string Create\w+ImportLibrary\(string workDir\)\s*\{.*?File.WriteAllText\(defPath, """\n(.*?)\n\s*"""',s,re.S):
 value=textwrap.dedent(m[1]); definitions[value.splitlines()[0].split()[1].removesuffix('.dll')]=value
assert len(definitions)==6
order=['kernel32','shell32','ole32','ws2_32','bcrypt','ucrtbase']
markers={'ole32':'declare dllimport i32 @CoInitializeEx','ws2_32':'declare dllimport i32 @WSAStartup','bcrypt':'declare dllimport i32 @BCryptGenRandom'}
table='|'.join(';'.join([name,name+'.dll',markers.get(name,''),','.join(definitions[name].splitlines()[2:])]) for name in order)
assert len(table)<4096 and all(32<=ord(c)<=126 for c in table)
policy='''namespace Sollang.Compiler.Shared;

[SelfHostPolicy("sollang.compiler.windows_link_policy",
    "selfhost/generated/windows_link_policy.slg",
    "src/Sollang.Compiler/Shared/Policies/WindowsLinkPolicy.cs")]
internal static class WindowsLinkPolicy
{
    // Rows: base name; DLL; optional declaration prefix; comma-separated exports.
    // Row order is both import-library creation order and final link order.
    public static string ImportLibraries() => "TABLE";
}
'''.replace('TABLE',table)
(r/'src/Sollang.Compiler/Shared/Policies/WindowsLinkPolicy.cs').write_text(policy,encoding='utf-8')
s=s.replace('using Sollang.Compiler.Diagnostics;','using Sollang.Compiler.Diagnostics;\nusing Sollang.Compiler.Shared;')
start=s.index('        var importLib = CreateKernel32ImportLibrary(workDir);');end=s.index('\n\n        var objects',start)
s=s[:start]+'        var importLibraries = CreateImportLibraries(llPath, workDir);'+s[end:]
start=s.index('        linkArguments.AddRange([importLib, shellImportLib]);');end=s.index('        Run(toolchain.LldLink, linkArguments);',start)
s=s[:start]+'''        linkArguments.AddRange(importLibraries);
        linkArguments.Add("/out:" + outputPath);
'''+s[end:]
start=s.index('    private string CreateKernel32ImportLibrary(');end=s.index('    private static bool ContainsPrefixMarker(',start)
s=s[:start]+'''    private IReadOnlyList<string> CreateImportLibraries(string llPath, string workDir)
    {
        var libraries = new List<string>();
        foreach (var row in WindowsLinkPolicy.ImportLibraries().Split('|'))
        {
            var fields = row.Split(';');
            var marker = fields[2];
            if (marker.Length != 0 && !ContainsPrefixMarker(llPath, Encoding.ASCII.GetBytes(marker)))
            {
                continue;
            }
            var defPath = Path.Combine(workDir, fields[0] + ".def");
            var libPath = Path.Combine(workDir, fields[0] + ".lib");
            var definition = "LIBRARY " + fields[1] + "\\nEXPORTS\\n" + fields[3].Replace(',', '\\n');
            File.WriteAllText(defPath, definition, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
            Run(toolchain.LlvmLib,
            [
                "/nologo", "/machine:x64", "/def:" + defPath, "/out:" + libPath
            ]);
            libraries.Add(libPath);
        }
        return libraries;
    }

'''+s[end:]
p.write_text(s,encoding='utf-8')
expected=r/'scripts/probes/windows-linker/expected-import-definitions.json'
expected.write_text(json.dumps({name+'.def':definitions[name] for name in order},indent=2)+'\n',encoding='utf-8')
runner=(r/'artifacts/scratch/resume-20261006-owner-continuation22/linker24764-csharp.py').read_text(encoding='utf-8-sig')
start=runner.index('specs={}');end=runner.index("base='''",start)
runner=runner[:start]+"specification=R/'scripts/probes/windows-linker/expected-import-definitions.json'\nspecs=json.loads(specification.read_text())\n"+runner[end:]
runner=runner.replace('workspace24743-managed','linker24766-managed').replace('linker24764-csharp','linker24767-csharp').replace('paths=[Path(__file__),project,contract,harness,C,','paths=[Path(__file__),project,contract,harness,specification,R/\'src/Sollang.Compiler/Shared/Policies/WindowsLinkPolicy.cs\',C,')
(r/'artifacts/scratch/resume-20261006-owner-continuation22/linker24767-csharp.py').write_text(runner,encoding='utf-8')
print(json.dumps({'importTableBytes':len(table),'definitions':len(definitions)}))

from pathlib import Path
import sys,json,hashlib,time,re,textwrap,ctypes,struct
from xml.sax.saxutils import escape
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=R/'artifacts/scratch/resume-20261006-owner-continuation22';C=B/'workspace24743-managed/compiler/Sollang.Compiler.exe';O=B/'linker24763-csharp';L=R/'.tools/llvm-22.1.8';contract=R/'scripts/probes/windows-linker/contract.json';plan=json.loads(contract.read_text());harness=R/'scripts/probes/windows-linker/reference-harness.cs';linker=R/'src/Sollang.Compiler/Tooling/WindowsLinker.cs';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert len(plan['cases'])==8 and plan['pairedTotal']==16
assert all((L/'bin'/name).is_file() for name in plan['requiredTools']), 'WINDOWS_LINK_TOOLS_MISSING'
initialize_output(R,O,reusable_directories=[B/'workspace24738-native',B/'v20050/compiler-build01',B/'v21323/compiler-build01']);O.mkdir()
project=O/'harness.csproj';project.write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net11.0</TargetFramework><EnableDefaultCompileItems>false</EnableDefaultCompileItems><RestoreSources></RestoreSources></PropertyGroup><ItemGroup><Compile Include="'+escape(str(harness))+'" /></ItemGroup></Project>',encoding='utf-8')
specs={}
for match in re.finditer(r'private string Create\w+ImportLibrary\(string workDir\)\s*\{.*?File.WriteAllText\(defPath, """\r?\n(.*?)\r?\n\s*"""',linker.read_text(),re.S):
 value=textwrap.dedent(match[1]).replace('\r\n','\n');name=value.splitlines()[0].split()[1].removesuffix('.dll')+'.def';specs[name]=value
assert len(specs)==6,specs.keys()
base='''target triple = "x86_64-pc-windows-msvc"
@message = private constant [3 x i8] c"42\\0A"
declare dllimport ptr @GetStdHandle(i32)
declare dllimport i32 @WriteFile(ptr, ptr, i32, ptr, ptr)
declare dllimport void @ExitProcess(i32) noreturn
define void @sollang_start() {
entry:
  %written = alloca i32, align 4
  %handle = call ptr @GetStdHandle(i32 -11)
  %ok = call i32 @WriteFile(ptr %handle, ptr @message, i32 3, ptr %written, ptr null)
  call void @ExitProcess(i32 0)
  unreachable
}
'''
prepared=[]
for case in plan['cases']:
 folder=O/case['id'];folder.mkdir();source=folder/'input.ll';value=base
 if case.get('optionalImports'):value+='declare dllimport i32 @CoInitializeEx(ptr, i32)\ndeclare dllimport i32 @WSAStartup(i16, ptr)\ndeclare dllimport i32 @BCryptGenRandom(ptr, ptr, i32, i32)\n'
 if case.get('shared'):value='target triple = "x86_64-pc-windows-msvc"\ndefine dllexport i64 @answer() { ret i64 42 }\n'
 if case.get('invalid'):value='not LLVM input\n'
 if case.get('large'):
  value+=';'+'partition fixture padding '*((1048576-len(value.encode()))//26+2)+'\n'
  assert 1048576<len(value.encode())<2097152
 source.write_bytes(value.encode());prepared.append((case,folder,source,folder/('product.dll' if case.get('shared') else 'product.exe')))
paths=[Path(__file__),project,contract,harness,C,*managed_runtime_inputs(C),linker,R/'src/Sollang.Compiler/Tooling/LlvmToolchain.cs',*[L/'bin'/name for name in plan['requiredTools']],*[p[2] for p in prepared]];pins={str(p.resolve()):sha(p) for p in paths}
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=8,cases=[],inputHashes=pins,scope=plan['scope'],claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  r=ex.run(['dotnet','build',str(project),'-c','Release','-o',str(O/'harness'),'--nologo','-v','minimal','/nodeReuse:false','/p:UseSharedCompilation=false','/warnaserror'],O/'harness-build',timeout=180);assert r.returncode==0 and not r.stderr,r.stdout+r.stderr
  for case,folder,source,product in prepared:
   start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));work=folder/'work'
   args=['dotnet',str(O/'harness/harness.dll'),str(C.with_suffix('.dll')),str(L),str(source),str(product),str(work),case['optimization'],case['workers'],'true' if case.get('shared') else 'false',case.get('nativeJobs','inherit')]
   r=ex.run(args,folder/'link',timeout=budget());row=dict(id=case['id'],passed=False,linkExit=r.returncode,stdout=r.stdout,stderr=r.stderr)
   if case.get('invalid'):
    assert r.returncode==1 and case['expectedError'] in r.stderr and 'expected top-level entity' in r.stderr and not product.exists(),r.stdout+r.stderr
   else:
    assert r.returncode==0 and not r.stderr,r.stdout+r.stderr;detail=json.loads(r.stdout.splitlines()[-1]);assert detail['processors']>=2,'LINKER_PARTITION_FIXTURE_REQUIRES_TWO_PROCESSORS'
    assert len(detail['objects'])==case['objects'],detail
    required=set(specs) if case.get('optionalImports') else {'kernel32.def','shell32.def','ucrtbase.def'};assert set(detail['definitions'])==required,detail
    for name,text in detail['definitions'].items():assert text==specs[name],name
    row['details']=detail;row['artifactSha256']=sha(product)
    if case.get('shared'):
     from _ctypes import FreeLibrary
     library=ctypes.WinDLL(str(product))
     try:library.answer.restype=ctypes.c_longlong;assert library.answer()==42
     finally:FreeLibrary(library._handle)
     row['libraryAnswer']=42
    else:
     run=ex.run([str(product)],folder/'run',timeout=budget());assert run.returncode==0 and not run.stderr and run.stdout=='42\n',run.stdout+run.stderr;row['runtimeStdout']=run.stdout
    data=product.read_bytes();pe=struct.unpack_from('<I',data,60)[0];optional=pe+24;assert data[pe:pe+4]==b'PE\x00\x00' and struct.unpack_from('<H',data,optional)[0]==0x20b
    reserve,commit=struct.unpack_from('<QQ',data,optional+72);assert reserve==plan['publicStackReserve'] and commit==plan['publicStackCommit'];row['stack']=dict(reserve=reserve,commit=commit)
   row['passed']=True;result['cases'].append(row);result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

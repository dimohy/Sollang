param([string]$Compiler,[string]$Output)
$ErrorActionPreference='Stop'
& ./scripts/verify-native-cli-format.ps1 -Compiler $Compiler -OutputDirectory $Output -ReusableCompilerDirectories @('artifacts/scratch/resume-20261006-owner-continuation22/mouse25498-native','artifacts/scratch/resume-20261006-owner-continuation22/v20050/compiler-build01')
if ($LASTEXITCODE -ne 0) { throw 'Formatter CLI checks failed' }

from pathlib import Path
import sys,json,hashlib
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(r/'scripts'));from verification_execution import VerificationExecution
from verification_source_proof import current_build_inputs
from completed_artifact_plan import initialize_output
c=Path(sys.argv[1]).resolve();o=Path(sys.argv[2]).resolve();reuse=[b/'mouse25539-native',b/'mouse25498-native',b/'v20050/compiler-build01'];initialize_output(r,o,reusable_directories=reuse);o.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();paths=[Path(__file__),b/'mouse25547-format.ps1',r/'scripts/verify-native-cli-format.ps1',r/'scripts/verification-process.ps1',r/'scripts/ArtifactLifecycle.ps1',c,b/'mouse25539-native/result.json',*current_build_inputs(r,json.loads((b/'mouse25539-native/result.json').read_text())),*sorted((r/'tests/Sollang.ExampleTests/Fixtures').glob('native-format-*.slg'))];pins={str(p):sha(p) for p in paths};v=dict(schemaVersion=1,status='running',completed=0,total=19,inputHashes=pins,cases=[],scope='Existing complete formatter CLI controls plus wide delimiter value preservation and idempotence; no whole compiler phase claim.',claimsGoalComplete=False);x=VerificationExecution(r,o,v,lambda:all(sha(p)==h for p,h in pins.items()),sha);err=None
try:
 d=x.run(['pwsh','-NoProfile','-File',str(b/'mouse25547-format.ps1'),'-Compiler',str(c),'-Output',str(o/'checks')],o/'format-cli',timeout=60);assert d.returncode==0 and not d.stderr and 'Native format CLI verification passed (19/19).' in d.stdout,(d.stdout,d.stderr);v.update(status='passed',completed=19,cases=[dict(id='formatter-cli-19',passed=True,completed=19,total=19)])
except BaseException as e:err=e
finally:x.finalize(err,cleanup=False)
if err:raise err
print(json.dumps({k:v[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

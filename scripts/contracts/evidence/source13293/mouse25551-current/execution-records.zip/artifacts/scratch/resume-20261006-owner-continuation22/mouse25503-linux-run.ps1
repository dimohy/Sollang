param([Parameter(Mandatory)][string]$Binary,[Parameter(Mandatory)][string]$Output)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$repo=[IO.Path]::GetFullPath('W:/MyWorks/Sollang')
. (Join-Path $repo 'scripts/verification-process.ps1')
[IO.Directory]::CreateDirectory($Output) | Out-Null
$mapped=Invoke-VerificationProcessCapture -FilePath 'C:/Windows/System32/wsl.exe' -ArgumentList @('-d','Ubuntu','--','wslpath','-a',$Binary.Replace('\','/')) -WorkingDirectory $repo -Description 'mouse-linux-map' -TimeoutMilliseconds 15000 -ExecutionRecordPath (Join-Path $Output 'path.execution.json')
if($mapped.ExitCode -ne 0){throw 'LINUX_MOUSE_PATH'}
$run=Invoke-VerificationProcessCapture -FilePath 'C:/Windows/System32/wsl.exe' -ArgumentList @('-d','Ubuntu','--','/usr/bin/timeout','--kill-after=2s','10s',$mapped.Stdout.Trim()) -WorkingDirectory $repo -Description 'mouse-linux-run' -TimeoutMilliseconds 15000 -ExecutionRecordPath (Join-Path $Output 'run.execution.json')
if($run.ExitCode -ne 0 -or $run.Stdout -cne '' -or $run.Stderr -cne ''){throw 'LINUX_MOUSE_NO_TEXT_ORACLE'}
Write-Host 'Linux no-text program: PASS'

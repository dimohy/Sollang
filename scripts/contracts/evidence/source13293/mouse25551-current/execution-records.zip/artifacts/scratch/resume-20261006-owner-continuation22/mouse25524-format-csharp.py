from pathlib import Path
import json,sys,hashlib
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(r/'scripts'))
from verification_execution import VerificationExecution
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
c=b/'mouse25518-managed/compiler/Sollang.Compiler.exe';o=b/'mouse25524-format-csharp';initialize_output(r,o,reusable_directories=[b/'mouse25498-native',b/'stream25471-native',b/'v20050/compiler-build01']);o.mkdir();source=b/'mouse25517-wide-source.slg';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();pins={str(p):sha(p) for p in [source,c,*managed_runtime_inputs(c),r/'src/Sollang.Compiler/Cli/SourceFormatter.cs']};v=dict(schemaVersion=1,status='running',completed=0,total=2,inputHashes=pins,cases=[],scope='Actual four-quote raw literal preservation plus formatter idempotence, unchanged original source.',claimsGoalComplete=False);ex=VerificationExecution(r,o,v,lambda:all(sha(p)==h for p,h in pins.items()),sha);err=None
try:
 d=ex.run([str(c),'format','--check',str(source)],o/'check',timeout=30);assert d.returncode==0 and not d.stdout and not d.stderr;v['cases'].append(dict(id='unchanged-wide-literal',passed=True));v['completed']=1
 formatted=o/'formatted.slg';formatted.write_bytes(source.read_bytes());d=ex.run([str(c),'format',str(formatted)],o/'format',timeout=30);assert d.returncode==0 and formatted.read_bytes()==source.read_bytes();v['cases'].append(dict(id='idempotent-wide-literal',passed=True));v.update(status='passed',completed=2)
except BaseException as e:err=e
finally:ex.finalize(err,cleanup=False)
if err:raise err
print(json.dumps({k:v[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

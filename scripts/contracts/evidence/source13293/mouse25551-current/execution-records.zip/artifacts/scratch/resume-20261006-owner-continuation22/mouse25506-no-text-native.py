from pathlib import Path
import json,sys,hashlib
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'mouse25506-no-text-native-build';C=B/'mouse25498-native/compiler.exe';sys.path.insert(0,str(R/'scripts'));from verification_execution import VerificationExecution
from verification_source_proof import current_build_inputs
from completed_artifact_plan import initialize_output
reuse=[B/'mouse25498-native',B/'stream25471-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reuse);O.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();paths=[Path(__file__),B/'mouse25496-no-text-public.ps1',B/'mouse25498-native/result.json',C,*current_build_inputs(R,json.loads((B/'mouse25498-native/result.json').read_text(encoding='utf-8-sig'))),R/'scripts/verification-process.ps1',R/'scripts/verification-compiler-build.ps1',R/'scripts/contracts/verification-compiler-build.json',R/'scripts/probes/function-event-source/no-text-output.slg',*sorted((R/'stdlib').rglob('*.slg'))];pins={str(p):sha(p) for p in paths};r=dict(schemaVersion=1,status='running',completed=0,total=2,inputHashes=pins,cases=[],scope='Original interactive809 public program compilation and linking only, both targets; no physical mouse execution claim',claimsGoalComplete=False);x=VerificationExecution(R,O,r,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
try:
 done=x.run(['pwsh','-NoProfile','-File',str(B/'mouse25496-no-text-public.ps1'),'-Compiler',str(C),'-Output',str(O)],O/'public',timeout=390);assert done.returncode==0 and not done.stderr,(done.stdout,done.stderr)
 r.update(status='passed',completed=2,cases=[dict(id=t,passed=True) for t in ['windows-x64','linux-x64']])
except BaseException as e:error=e
finally:x.finalize(error,cleanup=False)
if error:raise error
print(json.dumps({k:r[k] for k in ['status','completed','total','inputsStable','processesStopped']}))


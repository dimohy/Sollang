from pathlib import Path
import sys,json,hashlib
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(r/'scripts'));from verification_execution import VerificationExecution
from completed_artifact_plan import initialize_output
binary=Path(sys.argv[1]).resolve();proof=Path(sys.argv[2]).resolve();o=Path(sys.argv[3]).resolve();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();d=json.loads(proof.read_text());assert d['status']=='passed' and d['inputsStable'] and d['processesStopped'] and d['generatedOutputHashes'][str(binary)]==sha(binary);initialize_output(r,o,reusable_directories=[b/'mouse25498-native',b/'v20050/compiler-build01']);o.mkdir();paths=[Path(__file__),binary,proof,b/'mouse25503-linux-run.ps1',r/'scripts/verification-process.ps1'];pins={str(p):sha(p) for p in paths};v=dict(schemaVersion=1,status='running',completed=0,total=1,inputHashes=pins,cases=[],scope='Actual guarded no-text Linux program through canonical WSL output capture and strict outer process shutdown; no physical input subscription claim.',claimsGoalComplete=False);x=VerificationExecution(r,o,v,lambda:all(sha(p)==h for p,h in pins.items()),sha);err=None
try:
 d=x.run(['pwsh','-NoProfile','-File',str(b/'mouse25503-linux-run.ps1'),'-Binary',str(binary),'-Output',str(o/'execution')],o/'linux',timeout=40);assert d.returncode==0 and not d.stderr and 'Linux no-text program: PASS' in d.stdout,(d.stdout,d.stderr);v.update(status='passed',completed=1,cases=[dict(id='guarded-no-text-linux',passed=True)])
except BaseException as e:err=e
finally:x.finalize(err,cleanup=False)
if err:raise err
print(json.dumps({k:v[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

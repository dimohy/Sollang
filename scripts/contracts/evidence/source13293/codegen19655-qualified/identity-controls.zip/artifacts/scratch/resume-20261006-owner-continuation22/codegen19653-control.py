"""Focused source-library checks with the retained Native compiler; no rebuild claim."""
from pathlib import Path
import hashlib,json,sys
root=Path.cwd();base=root/'artifacts/scratch/resume-20261006-owner-continuation22'
sys.path.insert(0,str(root/'scripts'))
from verification_execution import VerificationExecution
from completed_artifact_plan import initialize_output
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
proof=base/'codegen19651-controls-managed/result.json'
managed=json.loads(proof.read_text(encoding='utf-8-sig'))
assert managed['status']=='passed' and managed['inputsStable'] and managed['processesStopped']
compiler=base/'v19418/compiler-build01/compiler.exe'
assert sha(compiler)=='978EC9087CA687D6D84C655B7F6CF81D56684E1420486E901134F71939E69390'
fixtures=['2845-codegen-identity-utf8-and-order-controls']
paths=[Path(__file__),proof,compiler,root/'selfhost/llvm/codegen_units.slg',
       root/'scripts/verify-native-exact-fixture.ps1',root/'scripts/verification_execution.py',
       *sorted((root/'scripts').glob('native-exact-*.ps1')),*sorted((root/'stdlib').rglob('*.slg'))]
for fixture in fixtures:
    paths.append(root/'examples/regression'/(fixture+'.slg'))
    paths.extend((root/'examples/regression/expected').glob(fixture+'.*'))
pins={str(p):sha(p) for p in paths}
stable=lambda:all(Path(p).is_file() and sha(p)==v for p,v in pins.items())
out=base/'codegen19653-control'
initialize_output(root,out,reusable_directories=[base/'v18915/compiler-build01',base/'v19080/compiler-build01',base/'v19418/compiler-build01'])
out.mkdir(exist_ok=False)
d={'schemaVersion':1,'status':'running','completed':0,'total':1,'cases':[],'inputHashes':pins,
   'caseBudgetSeconds':180,'scope':'Retained Native978E compiles the changed SLG library through the existing exact fixture runner. Current rebuilt Native CLI qualification remains pending.',
   'claimsCurrentFullCompilerFixed':False,'claimsPhaseComplete':False,'claimsGoalComplete':False}
x=VerificationExecution(root,out,d,stable,sha);error=None
try:
    for fixture in fixtures:
        command=['pwsh','-NoProfile','-File',str(root/'scripts/verify-native-exact-fixture.ps1'),
                 '-Compiler',str(compiler),'-Label','c','-Fixture',fixture,'-Platform','windows',
                 '-LlvmRoot',str(root/'.tools/llvm-22.1.8'),'-StdlibRoot',str(root/'stdlib'),
                 '-RepositoryRoot',str(root),'-OutputDirectory',str(out/'case'),'-Jobs','4',
                 '-TimeoutMilliseconds','180000']
        publication=out/'case'/'.sollang-cache'/('c-exact-'+fixture+'.exe.native-windows-x64-O1.semantic')
        assert 1<=len(str(publication).encode('utf-8'))<=259,('NATIVE_PUBLICATION_PATH_TOO_LONG',str(publication))
        d['publicationPathPreflight']={'path':str(publication),'utf8Bytes':len(str(publication).encode('utf-8')),'maximum':259}
        row={'id':fixture,'status':'running'};d['cases'].append(row);x.save()
        a=x.run(command,out/fixture,timeout=180)
        assert a.returncode==0,('NATIVE_SOURCE_CODEC_FAILED',fixture,a.stderr)
        row.update(status='passed',passed=True);d['completed']+=1;x.save()
    d['status']='passed'
except BaseException as e:error=e
finally:x.finalize(error,cleanup=False)
print(json.dumps({k:d.get(k) for k in ['status','completed','total','failure','inputsStable','processesStopped']}))
sys.exit(0 if d['status']=='passed' else 1)

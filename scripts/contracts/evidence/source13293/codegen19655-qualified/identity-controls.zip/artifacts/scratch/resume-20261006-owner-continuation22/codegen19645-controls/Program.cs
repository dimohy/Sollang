using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

if (args.Length != 4) throw new ArgumentException("compiler, collision input, actual artifact, output required");
var compiler = Path.GetFullPath(args[0]);
var before = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(compiler)));
using var input = JsonDocument.Parse(File.ReadAllBytes(args[1]));
var left = input.RootElement.GetProperty("ordinalOrder")[0].GetString()!;
var right = input.RootElement.GetProperty("ordinalOrder")[1].GetString()!;
var artifactBytes = File.ReadAllBytes(args[2]);
if (artifactBytes.Length % 8 != 0) throw new InvalidDataException("unaligned input");
var original = Enumerable.Range(0, artifactBytes.Length / 8)
    .Select(i => System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian(artifactBytes.AsSpan(i * 8, 8))).ToArray();
var output = Path.GetFullPath(args[3]);
if (Directory.Exists(output)) throw new IOException("output exists");
Directory.CreateDirectory(output);
var assembly = Assembly.LoadFrom(compiler);
var cache = assembly.GetType("Sollang.Compiler.Cli.IncrementalCodegenCache", true)!;
var unit = assembly.GetType("Sollang.Compiler.CodeGen.LlvmCodegenUnit", true)!;
var key = assembly.GetType("Sollang.Compiler.CodeGen.LlvmCodegenKey", true)!;
var kind = assembly.GetType("Sollang.Compiler.CodeGen.LlvmCodegenUnitKind", true)!;
var outputType = assembly.GetType("Sollang.Compiler.CodeGen.LlvmCodegenOutput", true)!;
var read = cache.GetMethod("Read", BindingFlags.Static | BindingFlags.NonPublic)!;
var encode = cache.GetMethod("Encode", BindingFlags.Static | BindingFlags.NonPublic)!;
var checksum = cache.GetMethod("Checksum", BindingFlags.Static | BindingFlags.NonPublic)!;
var hash = unit.GetMethod("StableIdentity", [typeof(ReadOnlySpan<byte>)])!.CreateDelegate<ByteHash>();
var compare = unit.GetMethod("CompareIdentities")!;
var observations = new List<object>();

string Write(string id, ulong[] words)
{
    var path = Path.Combine(output, id + ".cgu");
    using var stream = File.Create(path);
    using var writer = new BinaryWriter(stream);
    foreach (var word in words) writer.Write(word);
    return path;
}
void FixChecksum(ulong[] words) =>
    words[7] = (ulong)checksum.Invoke(null, [words, 8, words.Length - 8, 7809847782465536322UL])!;
void Reject(string id, ulong[] words, Type exception, int expectedSlgStatus)
{
    FixChecksum(words);
    var path = Write(id, words);
    try { read.Invoke(null, [path, 101UL, 202UL, 303UL]); }
    catch (TargetInvocationException error) when (error.InnerException?.GetType() == exception)
    {
        observations.Add(new { id, status = "passed", expectedSlgStatus, artifact = path,
            diagnosticClass = exception.Name, diagnostic = error.InnerException.Message });
        return;
    }
    throw new InvalidDataException("actual compiler accepted or misclassified " + id);
}

const int first = 17;
var length = checked((int)original[first + 4]);
var second = first + 8 + length + checked((int)original[first + 6]);
if (length != 16 || original[second + 4] != 16) throw new InvalidDataException("unexpected actual collision layout");
var malformed = new (string Id, byte[] Bytes, bool AtEnd)[]
{
    ("stray-continuation", [0x80], false),
    ("overlong-two", [0xc0, 0x80], false),
    ("invalid-leading-c1", [0xc1, 0xbf], false),
    ("invalid-continuation", [0xc2, 0x41], false),
    ("overlong-three", [0xe0, 0x80, 0x80], false),
    ("high-surrogate", [0xed, 0xa0, 0x80], false),
    ("surrogate-end", [0xed, 0xbf, 0xbf], false),
    ("overlong-four", [0xf0, 0x80, 0x80, 0x80], false),
    ("beyond-unicode", [0xf4, 0x90, 0x80, 0x80], false),
    ("invalid-leading-f5", [0xf5, 0x80, 0x80, 0x80], false),
    ("truncated-two", [0xc2], true),
    ("truncated-three", [0xe0, 0xa0], true),
    ("truncated-four", [0xf0, 0x90, 0x80], true)
};
foreach (var item in malformed)
{
    var words = original.ToArray();
    var start = first + 8 + (item.AtEnd ? length - item.Bytes.Length : 0);
    for (var i = 0; i < item.Bytes.Length; i++) words[start + i] = item.Bytes[i];
    words[first + 1] = hash(words.AsSpan(first + 8, length).ToArray().Select(v => checked((byte)v)).ToArray());
    Reject(item.Id, words, typeof(DecoderFallbackException), 10);
}
var duplicate = original.ToArray();
Array.Copy(duplicate, first + 8, duplicate, second + 8, length);
Reject("duplicate-complete-identity", duplicate, typeof(InvalidDataException), 10);
var reversed = original.ToArray();
var recordLength = second - first;
Array.Copy(original, second, reversed, first, recordLength);
Array.Copy(original, first, reversed, second, recordLength);
Reject("reversed-complete-identity", reversed, typeof(InvalidDataException), 8);
var notByte = original.ToArray();
notByte[first + 8] = 256;
Reject("identity-word-exceeds-byte", notByte, typeof(InvalidDataException), 7);

// All scalar width boundaries, including NUL, noncharacters and supplementary limits.
const string suffix = "\0\u007f\u0080\u07ff\u0800\ud7ff\ue000\ufffd\uffff\U00010000\U0010ffff";
var values = Array.CreateInstance(unit, 4);
var records = new[] { (0, "", "H"), (1, left + suffix, "A"), (1, right + suffix, "B"), (2, "", "T") };
if (hash(Encoding.UTF8.GetBytes(left + suffix)) != hash(Encoding.UTF8.GetBytes(right + suffix)))
    throw new InvalidDataException("suffix failed to preserve actual identity collision");
for (var i = 0; i < records.Length; i++)
{
    var item = records[i];
    values.SetValue(Activator.CreateInstance(unit, [Enum.ToObject(kind, item.Item1), item.Item2,
        Activator.CreateInstance(key, [101UL, 202UL])!, item.Item3, false]), i);
}
var actual = (IReadOnlyList<ulong>)encode.Invoke(null,
    [Activator.CreateInstance(outputType, [values])!, 101UL, 202UL, 303UL])!;
var unicodePath = Write("unicode-scalar-boundaries", actual.ToArray());
var decoded = read.Invoke(null, [unicodePath, 101UL, 202UL, 303UL])!;
var decodedUnits = ((IEnumerable)decoded.GetType().GetProperty("Units")!.GetValue(decoded)!).Cast<object>().ToArray();
if (!decodedUnits.Select(v => (string)unit.GetProperty("Identity")!.GetValue(v)!)
    .SequenceEqual(records.Select(v => v.Item2))) throw new InvalidDataException("unicode identity roundtrip changed");
observations.Add(new { id = "unicode-scalar-boundaries", status = "passed", expectedSlgStatus = 0, artifact = unicodePath });
var order = (int)compare.Invoke(null, [1UL, "\U00010000", 1UL, "\uff21"])!;
if (order >= 0) throw new InvalidDataException("UTF16 order changed");
observations.Add(new { id = "unicode-ordinal-encoding-order", status = "passed", expectedFirstIdentityByte = 240 });
var after = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(compiler)));
if (before != after) throw new InvalidDataException("compiler changed");
var result = new { schemaVersion = 1, status = "passed", completed = observations.Count, total = observations.Count,
    compilerSha256 = after, observations, claimsGoalComplete = false };
File.WriteAllText(Path.Combine(output, "observation.json"),
    JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine(JsonSerializer.Serialize(new { result.status, result.completed, result.total }));
delegate ulong ByteHash(ReadOnlySpan<byte> bytes);

from pathlib import Path
import json,sys,hashlib,shutil,datetime,importlib.util
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/storage25232-current'
sys.path.insert(0,str(R/'scripts'))
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
write=lambda p,q:Path(p).write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
records={'csharp-registry-result.json':'storage25221-csharp','semantic-result.json':'storage25222-semantic','stdlib-result.json':'storage25223-stdlib','managed-result.json':'storage25225-managed','native-build-result.json':'storage25227-native','paired-result.json':'storage25229-paired'}
for name,folder in records.items():
 q=read(B/folder/'result.json');assert q['status']=='passed' and q['completed']==q['total'] and q['inputsStable'] and q['processesStopped'],folder
 assert all(sha(p)==h for p,h in q['inputHashes'].items()),folder
E.mkdir()
for name,folder in records.items():shutil.copy2(B/folder/'result.json',E/name)
for name,source in [('source-comparison.json','storage25224-source-comparison.json'),('contract.json','storage25224-contract.json'),('oracle.json','storage25224-oracle.json'),('retirement.json','storage25226-retirement.json')]:shutil.copy2(B/source,E/name)
detail=read(R/'scripts/contracts/structural-parity-detail.json');before=read(B/'storage25228-detail-before.json');assert detail==before
semantic=next(p for p in detail['phaseProgress'] if p['phase']=='semantic-analysis')
d=next(d for d in semantic['decisionInventory']['decisions'] if d['id']=='semantic.predeclared-storage-schema-registration')
for k,name in [('qualification','qualification.json'),('currentQualification','qualification.json'),('sourceComparisonRecord','source-comparison.json'),('managedFirstRecord','managed-result.json'),('pairedRecord','paired-result.json')]:d[k]=(E/name).relative_to(R).as_posix()
d['evidenceEpoch']='current-storage25232-source-registration'
spec=importlib.util.spec_from_file_location('audit',R/'scripts/audit-structural-source-connections.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
ph=next(p for p in detail['phaseProgress'] if p['phase']=='type-commit');inv=ph['decisionInventory'];new=dict(d)
new['id']='type-commit.predeclared-storage-shape-registration'
new['completionScope']='Five predeclared shape commitments, atomic missing-element rejection and repeated semantic shape interning. Only the allocation path reached by registration is covered; sparse reservations and source metadata eligibility are separate.'
for side,ext in [('managed','.cs'),('selfhost','.slg')]:
 allowed=a.phase_source_files(R,ph['phase'],inv,side,ext)
 new[side+'Sources']=[s for s in d[side+'Sources'] if s in allowed]
inv['decisions'].append(new);inv['requiredDecisionIds'].append(new['id'])
write(R/'scripts/contracts/structural-parity-detail.json',detail)
audit=a.audit_source_connections(detail,R);count=sum(v['named'] for p in audit['phases'] for v in p['coverage'].values());total=sum(v['actual'] for p in audit['phases'] for v in p['coverage'].values());assert (count,total)==(507,712),(count,total)
write(E/'source-association.json',audit)
q=dict(schemaVersion=1,status='passed',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),completed=3,total=3,scope=new['completionScope'],sourceHashes=read(E/'source-comparison.json')['sourceHashes'],inputsStable=True,processesStopped=True,sourceComparisonRecord=(E/'source-comparison.json').relative_to(R).as_posix(),managedFirstRecord=(E/'managed-result.json').relative_to(R).as_posix(),pairedRecord=(E/'paired-result.json').relative_to(R).as_posix(),associated=dict(completed=507,total=712,percentage=round(507/712*100,2),remaining=205,newAssociations=3,unit='phase-source associations, not unique physical files'),prerequisites=dict(semantic='4/4',stdlib='1/1',canonicalCompiler='1/1'),compilerStabilization=dict(completed=363,total=793,percentage=45.78),sourcePhases=dict(completed=0,total=7),original1999Runs=0,wholeProfileRuns=0,claimsPhaseComplete=False,claimsGoalComplete=False)
write(E/'qualification.json',q)
g=read(R/'scripts/contracts/active-goal-progress.json');assert g==read(B/'storage25228-goal-before.json')
scope=q['scope'];g.update(currentFocusedGate='storage25232-focused3',currentFocusedGateDescription=scope,currentFocusedGateScope=scope,currentStorageRegistrationUnit=dict(status='focused-qualified-final-gates-pending',qualification=(E/'qualification.json').relative_to(R).as_posix(),completed=3,total=3,percentage=100.0,claimsGoalComplete=False))
g['currentSourceAssociationIntake'].update(qualification=(E/'qualification.json').relative_to(R).as_posix(),associationCompleted=507,associationPercentage=round(507/712*100,2),remainingAssociations=205,registeredDecisionsRetained=sum(len(p['decisionInventory']['decisions']) for p in detail['phaseProgress']),addedSourceAssociations=3)
g['focusedGates'].append(dict(name='storage25232-focused3',status='complete',completed=3,total=3,percentage=100.0,failed=0,running=0,unexecuted=0,scope=scope,evidence=(E/'qualification.json').relative_to(R).as_posix()))
write(R/'scripts/contracts/active-goal-progress.json',g)
print(json.dumps(dict(status='qualified',focused='3/3',associated=f'{count}/{total}')))

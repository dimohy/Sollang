from pathlib import Path
import json, hashlib, sys
R=Path.cwd(); B=R/'artifacts/scratch/resume-20261006-owner-continuation22'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
write=lambda p,v:Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
q=read(B/'storage25221-csharp/result.json')
assert q['status']=='passed' and q['inputsStable'] and q['processesStopped']
obs=q['cases'][0]['observation']; ids=obs['builtinTypeIds']; shapes=[]
for category,kind in [('StaticArrays',4),('DynamicArrays',3)]:
 for row in obs['records'][category]:
  if row['Id'] not in ids.values():continue
  elem=row['ElementType']
  if elem==ids['UInt8']:name='UInt8'
  else:
   nominal=[r for r in obs['records']['Structs'] if r['Id']==elem]
   assert len(nominal)==1 and nominal[0]['Name']=='sys.directory.Entry'
   name=nominal[0]['Name']
  shapes.append(f"{kind}:{name}:{row.get('FixedLength',-1)}")
assert len(shapes)==5
old=read(B/'storage23491-contract.json')
case=old['cases'][0]
assert case['stdout']=='\n'.join(['missing:atomic',*shapes,'reuse:stable'])
write(B/'storage25224-contract.json',dict(schemaVersion=1,
 expectedManagedDllSha256=sha(B/'ownership25169-managed/compiler/Sollang.Compiler.dll'),
 harnessBuildJobs=4,harnessBuildOptimization='-O1',
 scope=old['scope'],cases=[case]))
names=['src/Sollang.Compiler/Semantics/StorageTypeDefinitions.cs',
 'src/Sollang.Compiler/Semantics/SemanticCompiler.cs',
 'src/Sollang.Compiler/Shared/Policies/TypeNamePolicy.cs',
 'selfhost/semantic/storage_registration.slg',
 'selfhost/semantic/generated/type_name_policy.slg',
 'selfhost/semantic/type_ids_allocation.slg']
write(B/'storage25224-source-comparison.json',dict(schemaVersion=1,
 status='compared-before-slg-edit',csharpFirst=str((B/'storage25221-csharp/result.json').relative_to(R)),
 decisions=[
 'Actual CSharp registered arrays select only definitions with declared TypeId identities. Compare element declaration names and lengths, never numeric source arena identities.',
 'CSharp factories use the shared fixed/dynamic schema and resolve element names before registration. SLG reads the generated same schema, collects all definitions before mutation, resolves builtins or exact valid concrete nominal names, and interns complete kind/element/length shapes.',
 'SLG source metadata admission is separate from predeclared registration and is not credited by this probe. Existing current shared-policy runtime proof covers its generated Boolean decisions.',
 'Retain unchanged missing-element atomicity, all five shapes and repeat IDs/count. No compiler source edit is needed for this decision. Refresh proofs because current SemanticCompiler and SLG storage module changed since storage23495.',
 'Previous Native57 reuse rejected lifecycle helper drift before execution. One fresh canonical producer is budgeted after current managed semantic and full stdlib preflights; no original1999 or profiling replay.'],
 sourceHashes={n:sha(R/n) for n in names},
 sourceEmitterBudget=dict(timeoutSeconds=180,maximumBuilds=1,output=str((B/'storage25227-native').relative_to(R))),
 requiredNativePreflights=[str((B/n/'result.json').relative_to(R)) for n in ['storage25221-csharp','storage25222-semantic','storage25223-stdlib']],
 original1999Runs=0,claimsGoalComplete=False))
write(B/'storage25224-oracle.json',dict(source=str((B/'storage25221-csharp/result.json').relative_to(R)),
 definitionRows=5,expectedShapes=shapes,selection='Actual CSharp StaticArrays and DynamicArrays definitions with declared enum identities; no copied numeric arena oracle'))
print(json.dumps(dict(status='prepared',definitions=len(shapes))))

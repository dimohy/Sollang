from pathlib import Path
import hashlib,json,re,sys,time
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22'
sys.path.insert(0,str(r/'scripts'))
from verification_execution import VerificationExecution
from completed_artifact_plan import initialize_output
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
selected=[];paths=[Path(__file__),r/'scripts/verification_execution.py']
for id,plan_name,proof_name in [('main-plain','diagnostic19710-controls-plan.json','diagnostic19712-managed-controls/result.json'),
                                ('spaced-function','diagnostic19713-controls-plan.json','diagnostic19715-managed-controls/result.json')]:
    plan=b/plan_name;proof=b/proof_name;data=read(proof)
    assert data['inputsStable'] and data['processesStopped']
    case=next(v for v in read(plan)['cases'] if v['id']==id)
    observed=next(v for v in data['cases'] if v['id']==id);assert observed['passed']
    for p,h in data['inputHashes'].items():assert sha(p)==h,p
    paths += [plan,proof,*map(Path,data['inputHashes'])]
    selected.append((case,observed))
compiler=b/'v19418/compiler-build01/compiler.exe';assert sha(compiler)=='978EC9087CA687D6D84C655B7F6CF81D56684E1420486E901134F71939E69390'
paths += [compiler,r/'selfhost/llvm/emitter/diagnostics.slg',r/'src/Sollang.Compiler/Semantics/SemanticCompiler.cs']
pins={str(p):sha(p) for p in paths};stable=lambda:all(Path(p).is_file() and sha(p)==h for p,h in pins.items())
out=b/'diagnostic19717-native-baseline';initialize_output(r,out,reusable_directories=[b/'v18915/compiler-build01',b/'v19080/compiler-build01',b/'v19418/compiler-build01']);out.mkdir(exist_ok=False)
d={'schemaVersion':1,'status':'running','completed':0,'total':2,'cases':[],'inputHashes':pins,'scope':'Current CSharp controls versus retained Native; module identity baseline only, no fixed compiler claim.','caseBudgetSeconds':180,'claimsGoalComplete':False}
x=VerificationExecution(r,out,d,stable,sha);error=None
try:
    for index,(case,wanted) in enumerate(selected):
        folder=out/str(index);folder.mkdir();started=time.monotonic()
        row={'id':case['id'],'status':'running'};d['cases'].append(row);x.save()
        a=x.run([str(compiler),'build',*[str(r/v['path']) for v in case['sourceInputs']],'-o',str(folder/'probe.exe'),
                 '--stdlib',str(r/'stdlib'),'--llvm',str(r/'.tools/llvm-22.1.8'),'--target','windows-x64','--jobs','4','--keep-temps'],folder/'compile',timeout=180)
        actual=a.stderr.replace('\r\n','\n');expected=wanted['buildStderr'];pattern=r"\[module '([^']*)'\]"
        assert a.returncode==wanted['buildExit']==1 and a.stdout.replace('\r\n','\n')==wanted['buildStdout']
        am=re.search(pattern,actual);em=re.search(pattern,expected);assert am and em
        matched=actual==expected
        module_only=re.sub(pattern,'[module <identity>]',actual)==re.sub(pattern,'[module <identity>]',expected)
        assert module_only,('OTHER_DIAGNOSTIC_DIFFERENCE',case['id'],actual,expected)
        assert time.monotonic()-started<180
        row.update(status='passed' if matched else 'failed',passed=matched,expectedModule=em.group(1),actualModule=am.group(1),
                   expectedStderr=expected,actualStderr=actual,moduleIdentityOnlyDifference=module_only,
                   wholeCaseElapsedSeconds=time.monotonic()-started)
        d['completed']+=int(matched);x.save();print(json.dumps({k:row[k] for k in ['id','status','expectedModule','actualModule']}),flush=True)
    if d['completed']!=2:raise ValueError('MODULE_IDENTITY_BASELINE_MISMATCHES: '+str(2-d['completed']))
    d['status']='passed'
except BaseException as exc:error=exc
finally:x.finalize(error,cleanup=False)
print(json.dumps({k:d.get(k) for k in ['status','completed','total','failure','inputsStable','processesStopped']}))
sys.exit(0 if d['status']=='passed' else 1)

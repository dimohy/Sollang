from pathlib import Path
import sys,json,hashlib,argparse,re
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22'
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output,cleanup_output
p=argparse.ArgumentParser();p.add_argument('--compiler',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();C=a.compiler.resolve();O=a.output.resolve();contract=B/'cpu25017-cases.json';cases=json.loads(contract.read_text(encoding='utf-8-sig'));L=R/'.tools/llvm-22.1.8/bin';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
paths=[Path(__file__),R/'scripts/verification_execution.py',R/'scripts/verification_contract_lease.py',R/'scripts/completed_artifact_plan.py',R/'scripts/ArtifactLifecycle.ps1',contract,C,*[R/x['source'] for x in cases],*[R/x['expectedPath'] for x in cases if 'expectedPath' in x],*sorted((R/'stdlib').rglob('*.slg')),*[L/x for x in ['clang.exe','llvm-as.exe','llvm-readobj.exe']]]
if C.with_suffix('.dll').exists():paths+=managed_runtime_inputs(C)
pins={str(p.resolve()):sha(p) for p in paths};reusable=[B/'return25002-native',B/'product24976-native',B/'v20050/compiler-build01'];initialize_output(R,O,reusable_directories=reusable);O.mkdir()
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=len(cases),inputHashes=pins,cases=[],claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for case in cases:
   source=R/case['source'];product=O/(case['id']+'.exe');llvm=Path(str(product)+'.ll');bc=O/(case['id']+'.bc');done=ex.run([str(C),'build',str(source),'-o',str(product),'--target','windows-x64','-O1','--jobs','4','--keep-temps','--llvm',str(L.parent)],O/(case['id']+'.build'),timeout=60);assert done.returncode==0 and not done.stderr,(done.stdout,done.stderr);assert llvm.is_file(),str(llvm)
   done=ex.run([str(L/'llvm-as.exe'),str(llvm),'-o',str(bc)],O/(case['id']+'.assemble'),timeout=15);assert done.returncode==0 and not done.stderr,(done.stdout,done.stderr)
   pe=ex.run([str(L/'llvm-readobj.exe'),'--file-headers',str(product)],O/(case['id']+'.pe'),timeout=10);assert pe.returncode==0 and not pe.stderr and all(x in pe.stdout for x in ['Format: COFF-x86-64','Arch: x86_64','AddressSize: 64bit','Magic: 0x20B']),pe.stdout+pe.stderr
   ir=llvm.read_text(encoding='utf-8-sig').replace('\r\n','\n');assert 'target triple = "x86_64-pc-windows-msvc"' in ir
   definitions=[(m[1],m[2]) for m in re.finditer(r'^define[^\n]*@([^\s(]+)\([^\n]*\)[^\n]*\{\n(.*?)^\}',ir,re.M|re.S)]
   if case['specialized']:
    x86=[body for name,body in definitions if name.endswith('_x86')];portable=[body for name,body in definitions if name.endswith('_portable')];resolver=[body for name,body in definitions if name.endswith('_resolve')];assert len(x86)==len(portable)==len(resolver)==1,[n for n,_ in definitions if n.endswith(('_x86','_portable','_resolve'))]
    assert len(re.findall(r'@llvm\.x86\.aesni\.aesenc\(',x86[0]))==9 and len(re.findall(r'@llvm\.x86\.aesni\.aesenclast\(',x86[0]))==1
    assert not re.search(r'sollang_cpu_features_once|alloca\s+\[176|memcpy[^\n]*176',x86[0]) and 'llvm.x86.aesni' not in portable[0]
    assert 'target-features"="+aes,+sse2"' in ir and 'cpuid' in ir and '@sollang_aes128_selected = internal global ptr ' in ir and 'store atomic ptr %selected' in resolver[0]
    structure=dict(aesRounds=9,lastRounds=1,portableOptionalInstructions=False,oneTimeDispatch=True,hotKernelProbeOrScheduleCopy=False)
   else:
    assert '@sollang_aes128_selected' not in ir and '@llvm.x86.aesni' not in ir
    structure=dict(aesSpecializationAbsent=True)
   done=ex.run([str(product)],O/(case['id']+'.run'),timeout=10);expected=(R/case['expectedPath']).read_text(encoding='utf-8-sig') if 'expectedPath' in case else case['expected'];assert done.returncode==0 and not done.stderr and done.stdout==expected.replace('\r\n','\n'),(done.stdout,done.stderr,expected)
   result['cases'].append(dict(id=case['id'],source=str(source),passed=True,observedStdout=done.stdout,structure=structure,llvmSha256=sha(llvm),executableSha256=sha(product),peMachine='0x8664'));result['completed']+=1;ex.save()
  result['status']='passed'
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reusable)
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

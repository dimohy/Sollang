from pathlib import Path
import json,hashlib,zipfile,datetime
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/cpu25022-current'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();write=lambda p,d:Path(p).write_bytes((json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
managed=read(B/'cpu25024-csharp/result.json');native=read(B/'cpu25026-native/result.json');validation=read(B/'cpu25027-validation/result.json')
for d in [managed,native,validation]:assert d['status']=='passed' and d['completed']==d['total'] and d['total']==(6 if d is validation else 3) and d['inputsStable'] and d['processesStopped'];assert all(sha(p)==h for p,h in d['inputHashes'].items())
for d in [managed,native,validation]:
 for stream in ['stdout','stderr']:
  assert len({row[stream+'Path'] for row in d['processes']})==len(d['processes'])
  for row in d['processes']:assert sha(row[stream+'Path'])==row[stream+'Sha256']
pairs=[]
for left,right in zip(managed['cases'],native['cases']):
 assert left['id']==right['id'] and left['observedStdout']==right['observedStdout'] and left['structure']==right['structure'];p=left['source'];assert managed['inputHashes'][p]==native['inputHashes'][p]==sha(p);pairs.append(dict(id=left['id'],passed=True,observedStdout=left['observedStdout'],structure=left['structure']))
roles=read(B/'cpu25020-source-roles.json');assert len(roles['files'])==7
for f in roles['files']:assert sha(R/f['path'])==f['sha256']==f['reviewedSha256']
audit=validation['sourceConnections'];completed=sum(v['named'] for r in audit['phases'] for v in r['coverage'].values());total=sum(v['actual'] for r in audit['phases'] for v in r['coverage'].values());assert (completed,total)==(457,712)
detail=read(R/'scripts/contracts/structural-parity-detail.json');before=read(B/'cpu25020-before.json');indexed=read(B/'cpu25020-index.json');assert detail['phaseProgress']==indexed['phaseProgress'];assert [r['decisionInventory']['sourceScopes'] for r in detail['phaseProgress']]==[r['decisionInventory']['sourceScopes'] for r in before['phaseProgress']]
E.mkdir();write(E/'managed.json',managed);write(E/'native.json',native);write(E/'validation.json',validation);write(E/'source-comparison.json',read(B/'cpu25025-source-comparison.json'));write(E/'source-associations.json',roles);write(E/'source-connections.json',audit);write(E/'paired-cases.json',dict(completed=6,total=6,percentage=100.0,programPairs=3,cases=pairs))
entries={}
def add(p,label=None):
 p=Path(p);entries[label or p.relative_to(R).as_posix()]=p.read_bytes()
for p in [Path(__file__),*[B/x for x in ['cpu25024-focused.py','cpu25017-cases.json','cpu25025-source-comparison.json','cpu25020-before.json','cpu25020-index.json','cpu25020-source-roles.json','cpu25027-validation.py']],*[R/f['path'] for f in roles['files']],*[Path(x['source']) for x in managed['cases']],R/'examples/regression/expected/1226-aes128-cpu-dispatch-differential.stdout.txt',R/'src/Sollang.Compiler/CodeGen/LlvmEmitter.Utilities.cs',R/'src/Sollang.Compiler/CodeGen/LlvmEmitter.FunctionDeclarations.cs']:add(p)
for name in ['cpu25024-csharp','cpu25026-native','cpu25027-validation']:
 for p in (B/name).rglob('*'):
  if p.is_file() and not any(x in p.parts for x in ['.sollang-cache','.w0','compiler','obj','bin']) and not any(x.endswith('.slg-tmp') for x in p.parts) and p.suffix.lower() not in ['.exe','.dll','.pdb','.ll','.bc','.obj','.lib','.pyc']:add(p)
for path in ['scripts/verification_execution.py','scripts/test_verification_execution.py','scripts/test_stdlib_preflight_observation.py']:
 add(R/path);entries['before-source/'+path]=__import__('subprocess').run(['git','show','HEAD:'+path],capture_output=True,check=True).stdout
for name in ['qualification.json','qualification.before-log-audit.json']:
 add(B/'cpu25022-log-limited'/name)
for path in B.glob('cpu25023-*.std*'):add(path)
write(E/'log-capture-audit.json',dict(status='resolved-and-reverified',earlierQualification=read(B/'cpu25022-log-limited/qualification.json'),fix='Append extensions to opaque owned step prefixes; exclusive log creation and prelaunch duplicate/path checks; process records retain paths and SHA256.',executionControls=dict(successful=47,total=49,skipped=2,skipReason='POSIX-only controls on Windows',failed=0),consumerControls=dict(completed=40,total=40),currentCommandLogPairs=sum(len(d['processes']) for d in [managed,native,validation]),currentLogPathsDistinct=True,currentLogHashesVerified=True))
archive=E/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,raw in sorted(entries.items()):z.writestr(n,raw)
with zipfile.ZipFile(archive) as z:
 for n,raw in entries.items():assert z.read(n)==raw
write(E/'archive-manifest.json',dict(sha256=sha(archive),readbackVerified=True,entries={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest().upper()) for n,raw in sorted(entries.items())}))
projection=hashlib.sha256(json.dumps(detail['phaseProgress'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest().upper()
q=dict(schemaVersion=1,status='current-windows-cpu-pair-qualified-final-gates-pending',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),owner='C2026-10-20-633',scope='Current Windows exact canonical AES owner admission, LLVM/PE/automatic-dispatch execution. Additional source-role associations are not new whole naming/phase proofs.',paired=dict(completed=6,total=6,percentage=100.0,programPairs=3,evidence='paired-cases.json'),structural='llvm-as and windows-x64 PE for all programs; wrong-owner globals/OtherKey have no AES specialization; actual AES has9+1 rounds, portable fallback and one-time resolver, no hot feature probe/schedule copy.',dispatchMode='automatic',forcedCpuPathsVerified=False,sourceComparison='source-comparison.json',sourceAssociations='source-associations.json',associated=dict(completed=457,total=712,percentage=64.19,remaining=255),previousAssociated=dict(completed=450,total=712),addedSourceAssociations=7,controls=dict(completed=112,total=112),executionControls=dict(successful=47,total=49,skipped=2,failed=0),consumerControls=dict(completed=40,total=40),integrationChecks=dict(completed=6,total=6),logRetention='log-capture-audit.json',fullSourcePhases=dict(completed=0,total=7,percentage=0.0),phaseInventoryProjectionSha256=projection,managedCompiler='artifacts/scratch/resume-20261006-owner-continuation22/review24984-managed/compiler/Sollang.Compiler.exe',nativeCompiler='artifacts/scratch/resume-20261006-owner-continuation22/return25002-native/compiler.exe',compilerSourcesChanged=False,nativeBuilds=0,original1999Runs=0,sourceConnectionProof='source-connections.json',historicalQualification='scripts/contracts/evidence/C2026-10-20-633/canonical-owner11152/qualification.json',archive=dict(path='evidence.zip',sha256=sha(archive),entries=len(entries),readbackVerified=True),claimsWholePhaseComplete=False,claimsGoalComplete=False)
write(E/'qualification.json',q);print(json.dumps(dict(status=q['status'],paired=q['paired'],associated=q['associated'],archiveEntries=len(entries))))

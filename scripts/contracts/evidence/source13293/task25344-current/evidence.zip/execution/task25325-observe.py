from pathlib import Path
import sys,json,hashlib,re
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';sys.path.insert(0,str(R/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from verification_source_proof import current_build_inputs
from completed_artifact_plan import initialize_output,cleanup_output
C=B/'prepared25306-managed/compiler/Sollang.Compiler.exe';N=B/'prepared25318-native/compiler.exe';O=B/'task25325-observe'
reuse=[N.parent,B/'nominal25298-native',B/'v20050/compiler-build01']
fixtures=[R/'scripts/probes/codegen-identity'/n for n in ['library-export-task-readonly.slg','library-export-task-long-readonly.slg']]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
birth=json.loads((N.parent/'result.json').read_text(encoding='utf-8-sig'))
paths=[Path(__file__),*fixtures,*managed_runtime_inputs(C),N,N.parent/'result.json',*current_build_inputs(R,birth),*sorted((R/'stdlib').rglob('*.slg'))]
pins={str(p.resolve()):sha(p) for p in paths}
initialize_output(R,O,reusable_directories=reuse);O.mkdir()
r=dict(schemaVersion=1,status='running',completed=0,total=4,inputHashes=pins,cases=[],scope='Two readonly task library diagnostics against current CSharp and Native. Observation only; mismatch is not passing parity.',claimsGoalComplete=False)
with VerificationContractLease(list(map(Path,pins))):
 x=VerificationExecution(R,O,r,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  expected={}
  for mode,compiler in [('managed',C),('native',N)]:
   for source in fixtures:
    name=mode+'-'+source.stem;d=O/name;d.mkdir();product=d/'math.dll'
    args=[str(compiler),'build',str(source),'-o',str(product),'--library','--target','windows-x64','--llvm',str(R/'.tools/llvm-22.1.8'),'--jobs','1','-O0']
    if mode=='native': args+=['--stdlib',str(R/'stdlib')]
    done=x.run(args,d/'build',timeout=180)
    assert done.returncode==1 and not done.stdout and not product.exists(),(name,done.stdout,done.stderr)
    match=re.fullmatch(r"sollang: type '([0-9]+)' is not a fixed-width library ABI type\n",done.stderr)
    assert match,(name,done.stderr)
    if mode=='managed':expected[source.name]=done.stderr
    r['cases'].append(dict(id=name,passed=True,stderr=done.stderr,typeId=int(match[1]),matchesCSharp=done.stderr==expected[source.name]))
    r['completed']+=1
  r.update(status='passed',parityEqual=all(v['matchesCSharp'] for v in r['cases']),interpretation='All expected rejection observations complete; parity is reported separately.')
 except BaseException as e:error=e
 finally:x.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=reuse)
print(json.dumps({k:r[k] for k in ['status','completed','total','parityEqual','cases']}))

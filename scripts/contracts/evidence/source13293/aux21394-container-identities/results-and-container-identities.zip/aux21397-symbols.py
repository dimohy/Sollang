from pathlib import Path
import json, hashlib, sys, re, struct, time
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B = ROOT / 'artifacts/scratch/resume-20261006-owner-continuation22'
OUT = B / 'aux21397-symbols'
CPP = B / 'managed21139/compiler/Sollang.Compiler.exe'
producerPath = B / 'aux21396-emitter/result.json'
producer = json.loads(producerPath.read_text())
assert producer['status'] == 'passed' and producer['completed'] == producer['total'] == 19 and producer['inputsStable'] and producer['processesStopped']
emitter = B / 'aux21396-emitter/emitter.exe'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert sha(emitter) == producer['generatedOutputHashes'][str(emitter)]
assert all((sha(Path(p)) == h for p, h in producer['inputHashes'].items()))
initialize_output(ROOT, OUT, reusable_directories=[B / x / 'compiler-build01' for x in ['v18915', 'v20050', 'v21323']])
OUT.mkdir(exist_ok=False)
fixtures = OUT / 'variants'
fixtures.mkdir()
texts = {'main.slg': 'import cache.alpha as alpha\nimport cache.beta as beta\nmain { alpha.value() -> beta.apply -> println }\n', 'beta.slg': 'namespace cache.beta\npublic apply value: Int32 -> Int32 uses Console {\n "beta" -> println\n [value, 0; ~] => items!\n value > 0 -> if { items! -> push(3) }\n items![0] + items![(items! -> len) - 1]\n}\n', 'before.slg': 'namespace cache.alpha\npublic value: -> Int32 => 7\n', 'after.slg': 'namespace cache.alpha\npublic value: -> Int32 {\n 7 => number\n number + 1\n}\n'}
for name, text in texts.items():
    (fixtures / name).write_text(text, encoding='utf-8')
project = OUT / 'project'
project.mkdir()
(project / 'main.slg').write_bytes((fixtures / 'main.slg').read_bytes())
(project / 'beta.slg').write_bytes((fixtures / 'beta.slg').read_bytes())
inputs = [Path(__file__), CPP, *managed_runtime_inputs(CPP), producerPath, emitter, *fixtures.iterdir(), *map(Path, producer['inputHashes'])]
inputs = list(dict.fromkeys(inputs))
hashes = {str(p): sha(p) for p in inputs}

def betaFragment(cache):
    words = struct.unpack('<' + 'Q' * (cache.stat().st_size // 8), cache.read_bytes())
    index = 8
    for _ in range(words[5]):
        h = words[index:index + 8]
        name = bytes(words[index + 8:index + 8 + h[4]]).decode()
        start = index + 8 + h[4]
        if h[0] == 1 and name == 'cache.beta':
            return b''.join((v.to_bytes(8, 'little') for v in words[start:start + h[6]]))[:h[5]]
        index = start + h[6]
    raise AssertionError('beta unit missing')
with VerificationContractLease(inputs):
    result = dict(schemaVersion=1, status='running', completed=0, total=6, cases=[], inputHashes=hashes, maximumCaseSeconds=180, scope='CSharp-first branch/string unit-name stability under unrelated body growth: cached and fresh CSharp beta fragments, then actual current SLG emitter beta fragments. Mutable staged sources only change between stopped cases; immutable variants pinned.', claimsGoalComplete=False)
    run = VerificationExecution(ROOT, OUT, result, lambda: all((p.is_file() and sha(p) == hashes[str(p)] for p in inputs)), sha)
    error = None
    cppFragments = []
    slgFragments = []
    try:
        for label, variant, expected, outputName in [('cold', 'before.slg', 'beta\n10\n', 'program'), ('changed', 'after.slg', 'beta\n11\n', 'program'), ('fresh-changed', 'after.slg', 'beta\n11\n', 'fresh')]:
            (project / 'alpha.slg').write_bytes((fixtures / variant).read_bytes())
            live = {str(p): sha(p) for p in project.glob('*.slg')}
            d = OUT / ('csharp-' + label)
            d.mkdir()
            start = time.monotonic()
            budget = lambda: max(1, 180 - (time.monotonic() - start))
            exe = project / (outputName + '.exe')
            done = run.run([str(CPP), 'build', *[str(project / n) for n in ['main.slg', 'alpha.slg', 'beta.slg']], '-o', str(exe), '--target', 'windows-x64', '--llvm', str(ROOT / '.tools/llvm-22.1.8'), '--jobs', '1', '-O0'], d / 'build', timeout=budget())
            assert done.returncode == 0 and (not done.stderr), done.stdout + done.stderr
            cache = next((project / '.sollang-cache').glob(outputName + '.*.cgu'))
            fragment = betaFragment(cache)
            (d / 'beta.ll').write_bytes(fragment)
            cppFragments.append(fragment)
            trace = re.search('\\[codegen-cache\\] ([^;]+); reused (\\d+)/(\\d+) units;', done.stdout)
            assert trace
            done = run.run([str(exe)], d / 'run', timeout=budget())
            assert done.returncode == 0 and done.stdout == expected and (not done.stderr), done.stdout + done.stderr
            assert all((sha(Path(p)) == h for p, h in live.items()))
            result['cases'].append(dict(id='csharp-' + label, passed=True, buildExit=0, runExit=0, stdout=done.stdout, reused=int(trace.group(2)), units=int(trace.group(3)), betaFragmentSha256=sha(d / 'beta.ll'), sourceHashes=live))
            result['completed'] += 1
            run.save()
        assert cppFragments[0] == cppFragments[1] == cppFragments[2], 'CSharp fresh/cached beta changed'
        n = len(list((ROOT / 'stdlib').rglob('*.slg')))
        for label, variant, expected in [('before', 'before.slg', 'beta\n10\n'), ('after', 'after.slg', 'beta\n11\n')]:
            (project / 'alpha.slg').write_bytes((fixtures / variant).read_bytes())
            live = {str(p): sha(p) for p in project.glob('*.slg')}
            d = OUT / ('slg-' + label)
            d.mkdir()
            start = time.monotonic()
            budget = lambda: max(1, 180 - (time.monotonic() - start))
            done = run.run([str(emitter), 'ordinary', 'unused', str(ROOT / 'stdlib'), *[str(project / x) for x in ['main.slg', 'alpha.slg', 'beta.slg']]], d / 'emit', timeout=budget())
            assert done.returncode == 0 and (not done.stderr), done.stdout[-1500:] + done.stderr
            ll = d / 'program.ll'
            ll.write_text(done.stdout, encoding='utf-8')
            body = re.search('^define[^\\n]*@sollang_m' + str(n + 2) + '_s\\d+[^\\n]*\\{.*?^\\}', done.stdout, re.M | re.S)
            assert body
            fragment = body.group(0)
            slgFragments.append(fragment)
            (d / 'beta.ll').write_text(fragment, encoding='utf-8')
            linked = run.run([str(ROOT / '.tools/llvm-22.1.8/bin/clang.exe'), str(ll), '-O0', '-Wno-override-module', '-o', str(d / 'program.exe'), '-lkernel32', '-lshell32', '-lws2_32', '-lbcrypt'], d / 'link', timeout=budget())
            assert linked.returncode == 0, linked.stderr
            done = run.run([str(d / 'program.exe')], d / 'run', timeout=budget())
            assert done.returncode == 0 and done.stdout == expected and (not done.stderr)
            assert all((sha(Path(p)) == h for p, h in live.items()))
            result['cases'].append(dict(id='slg-' + label, passed=True, buildExit=0, runExit=0, stdout=done.stdout, betaFragmentSha256=sha(d / 'beta.ll'), sourceHashes=live))
            result['completed'] += 1
            run.save()
        stable = slgFragments[0] == slgFragments[1]
        result['cases'].append(dict(id='unchanged-module-control-and-global-stability', passed=stable, csharpStable=True, slgStable=stable))
        result['completed'] += int(stable)
        result['status'] = 'passed' if stable else 'observed-not-qualified'
    except BaseException as e:
        error = e
    finally:
        run.finalize(error, cleanup=False)
    if error:
        raise error
print(json.dumps({k: result[k] for k in ['status', 'completed', 'total', 'cases', 'inputsStable', 'processesStopped']}, indent=2))

from pathlib import Path
import json,hashlib,zipfile,subprocess,datetime
R=Path.cwd();B=R/'artifacts/scratch/resume-20261006-owner-continuation22';E=R/'scripts/contracts/evidence/source13293/cache25220-current';E.mkdir();read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));write=lambda p,d:Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
for name,path in [('focused','cache25212-index-validation/result.json'),('cleanup','cache25216-apply/result.json')]:
 d=read(B/path);assert d['status']=='passed' and d['completed']==d['total'] and d['inputsStable'] and d['processesStopped'];assert all(sha(p)==h for p,h in d['inputHashes'].items());write(E/(name+'.json'),d)
write(E/'regression-observation.json',read(B/'cache25215-existing172.json'));write(E/'plan-audit.json',read(B/'cache25214-plan-audit.json'))
original=read(R/'scripts/contracts/evidence/source13293/policy25200-current/msbuild-cache-residue.json');assert all(not (R/t['path']).exists() for t in original['ownedCaches']);protected=read(B/'block24016-protected-inputs.json');assert all(sha(R/p)==h for p,h in protected.items())
entries={}
def add(p):
 p=Path(p);entries[p.relative_to(R).as_posix()]=p.read_bytes()
for name in ['scripts/completed_artifact_plan.py','scripts/test_completed_artifacts.py','scripts/test_msbuild_artifact_caches.py','scripts/ArtifactLifecycle.ps1','scripts/Invoke-CompletedArtifactCleanup.ps1','scripts/contracts/artifact-lifecycle.json','docs/AI_SLG_BEST_PRACTICES.md']:
 add(R/name);old=subprocess.run(['git','show','HEAD:'+name],capture_output=True)
 if old.returncode==0:entries['before-source/'+name]=old.stdout
for item in sorted(B.glob('cache252*')):
 if item.name.endswith('-goal-before.json'):continue
 paths=item.rglob('*') if item.is_dir() else [item]
 for p in paths:
  if p.is_file() and p.suffix.lower() not in ['.exe','.dll','.ll','.bc','.pdb','.obj','.pyc','.zip']:add(p)
for row in read(B/'cache25214-plan-audit.json')['outputs']:
 plan=Path(row['plan']);add(plan);add(Path(str(plan)+'.execution.json'));add(B/row['output']/'PolicyHarness.csproj')
add(Path(__file__));archive=E/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,raw in sorted(entries.items()):z.writestr(n,raw)
with zipfile.ZipFile(archive) as z:
 for n,raw in entries.items():assert z.read(n)==raw
write(E/'archive-manifest.json',dict(sha256=sha(archive),readbackVerified=True,entries={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest().upper()) for n,raw in sorted(entries.items())}))
write(E/'qualification.json',dict(schemaVersion=1,status='owned-msbuild-cache-cleanup-qualified-final-compiler-gates-pending',observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),focused=dict(completed=16,total=16,percentage=100.0,exactStagedImplementation=True,headFixtureAndExecutor=True),worktreeRegression=dict(completed=172,total=172,source='regression-observation.json',limitation='Direct exec terminal observation; no initial input fingerprint or independent stream log. Includes foreign pre-existing fix/test; not committed by this change.'),cleanup=dict(completed=20,total=20,percentage=100.0,reclaimedBytes=2732,idempotentReplay=True,source='cleanup.json'),scope='Only .cache files below a completed stopped dotnet build project-owned obj or explicit artifacts-path/obj inside the verified output. Pinned project bytes must still match; original inputs, failed/cancelled/running/active owners, reusable products and external/unproven caches remain protected.',sharedPlannerAndExecutorValidation=True,stagedAndWorkTargetsIdentical=True,foreignLifecycleHunkExcludedFromCommit=True,foreignTestHunkExcludedFromCommit=True,initialTestHarnessErrors='Two new cases used nonexistent verify_plan; corrected to existing validate_plan and all16 revalidated, including the isolated staged-code run.',protectedInputsVerified=8,compilerStabilization=dict(completed=363,total=793,percentage=45.78),sourceAssociations=dict(completed=504,total=712,percentage=70.79,remaining=208),original1999Runs=0,compilerProducerBuilds=0,overall=dict(completed=None,total=None,percentage=None,unknownReason='Platform and performance denominators remain unfrozen'),progressReportAutomaticValidation='unverified; existing progress schema/Slogs contract issue remains',archive=dict(path='evidence.zip',sha256=sha(archive),entries=len(entries),readbackVerified=True),claimsGoalComplete=False))
p=R/'scripts/contracts/evidence/source13293/policy25200-current/qualification.json';q=read(p);q.update(status='focused-qualified-final-gates-pending',lifecycle='Successful generated binaries/LLVM and private caches were cleaned. The additional20 MSBuild cache files are now removed and idempotent replay passed under the common planner/executor. Failed outputs remain protected.',resolvedCleanup='scripts/contracts/evidence/source13293/cache25220-current/qualification.json');q.pop('pendingCleanup',None);write(p,q)
print(json.dumps(dict(qualified16=True,cleaned='20/20',bytes=2732,archiveEntries=len(entries),goalComplete=False)))

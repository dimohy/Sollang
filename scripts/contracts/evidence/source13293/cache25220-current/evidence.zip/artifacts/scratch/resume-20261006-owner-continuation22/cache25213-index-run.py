from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'cache25212-index-validation'
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import cleanup_output
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();paths=[Path(__file__),*[p for p in (O/'mirror/scripts').rglob('*') if p.is_file()]];pins={str(p.resolve()):sha(p) for p in paths}
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=16,cases=[],inputHashes=pins,scope='Exact staged cleanup code and HEAD fixture/executor: no foreign case-count fix or test changes. Real executor safety and resume tests.',claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  d=ex.run([sys.executable,'-B','-m','unittest','discover','-s',str(O/'mirror/scripts'),'-p','test_msbuild_artifact_caches.py','-v'],O/'tests',timeout=60);assert d.returncode==0 and 'Ran 16 tests' in d.stderr and '\nOK\n' in d.stderr,d.stdout+d.stderr
  names=[line.split()[0] for line in d.stderr.splitlines() if line.startswith('test_')];assert len(names)==len(set(names))==16;result.update(status='passed',completed=16,cases=[dict(id=name,passed=True) for name in names])
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=[B/'ownership25157-native',B/'bitset25123-native',B/'v20050/compiler-build01'])
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped']}))

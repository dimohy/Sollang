from pathlib import Path
import sys,json,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22';O=B/'cache25216-apply';O.mkdir();read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from completed_artifact_plan import cleanup_output
manifest=read(B/'cache25214-plan-audit.json');original=read(R/'scripts/contracts/evidence/source13293/policy25200-current/msbuild-cache-residue.json');targets=original['ownedCaches'];assert len(targets)==20 and all(sha(R/t['path'])==t['sha256'] for t in targets)
paths=[Path(__file__),B/'cache25214-plan-audit.json',R/'scripts/completed_artifact_plan.py',R/'scripts/Invoke-CompletedArtifactCleanup.ps1',R/'scripts/ArtifactLifecycle.ps1',R/'scripts/contracts/artifact-lifecycle.json']
for row in manifest['outputs']:paths += [Path(row['plan']),B/row['output']/'result.json',B/row['output']/'PolicyHarness.csproj']
pins={str(p.resolve()):sha(p) for p in paths}
with VerificationContractLease([Path(p) for p in pins]):
 result=dict(schemaVersion=1,status='running',completed=0,total=20,cases=[],inputHashes=pins,ownedTargetHashes=targets,cleanupExecutions=[],claimsGoalComplete=False);ex=VerificationExecution(R,O,result,lambda:all(sha(p)==h for p,h in pins.items()),sha);error=None
 try:
  for row in manifest['outputs']:
   plan=Path(row['plan']);prefix=O/row['output'];done=ex.run(['pwsh','-NoProfile','-File',str(R/'scripts/Invoke-CompletedArtifactCleanup.ps1'),'-Plan',str(plan),'-Execute'],prefix,timeout=30);assert done.returncode==0,done.stdout+done.stderr
   proof=read(Path(str(plan)+'.execution.json'));assert proof['status']=='completed' and proof['plannedFiles']==5;copy=O/(row['output']+'.execution-first.json');copy.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8');result['cleanupExecutions'].append(dict(output=row['output'],firstExecution=str(copy),reclaimedBytes=proof['reclaimedBytes']))
  assert all(not (R/t['path']).exists() for t in targets)
  for row in manifest['outputs']:
   plan=Path(row['plan']);done=ex.run(['pwsh','-NoProfile','-File',str(R/'scripts/Invoke-CompletedArtifactCleanup.ps1'),'-Plan',str(plan),'-Execute'],O/(row['output']+'.resume'),timeout=30);assert done.returncode==0,done.stdout+done.stderr
   proof=read(Path(str(plan)+'.execution.json'));assert proof['status']=='completed' and proof['reclaimedBytes']==0
  result.update(status='passed',completed=20,cases=[dict(id=t['path'],passed=True) for t in targets],reclaimedBytes=sum(r['reclaimedBytes'] for r in result['cleanupExecutions']),idempotentResumePassed=True)
 except BaseException as e:error=e
 finally:ex.finalize(error,cleanup=False)
 if error:raise error
 cleanup_output(R,O,reusable_directories=[B/'ownership25157-native',B/'bitset25123-native',B/'v20050/compiler-build01'])
print(json.dumps({k:result[k] for k in ['status','completed','total','inputsStable','processesStopped','reclaimedBytes','idempotentResumePassed']}))

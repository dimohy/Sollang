from pathlib import Path
import sys,json,importlib.util,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'));B=R/'artifacts/scratch/resume-20261006-owner-continuation22'
import completed_artifact_plan as work
spec=importlib.util.spec_from_file_location('staged_cleanup',B/'cache25212-index-validation/mirror/scripts/completed_artifact_plan.py');staged=importlib.util.module_from_spec(spec);spec.loader.exec_module(staged)
reuse=[B/'ownership25157-native',B/'bitset25123-native',B/'v20050/compiler-build01'];rows=[]
for name in ['policy25181-export','policy25185-export','policy25190-export','policy25201-export']:
 out=B/name;options=dict(minimum_age_hours=0,selected_outputs={str(out.resolve())},reusable_directories=reuse);a=staged.create_plan(R,B,**options);b=work.create_plan(R,B,**options);assert a['targets']==b['targets'] and a['directoryTargets']==b['directoryTargets'];assert len(a['targets'])==5 and all(Path(t['path']).suffix=='.cache' for t in a['targets']);staged.validate_plan(a);work.validate_plan(a);plan=out/'msbuild-cache-cleanup-plan.json';plan.write_text(json.dumps(a,indent=2)+'\n',encoding='utf-8');rows.append(dict(output=name,plan=str(plan),sha256=hashlib.sha256(plan.read_bytes()).hexdigest().upper(),files=a['files'],bytes=a['logicalBytes'],stageAndWorkTargetsMatch=True))
assert sum(r['files'] for r in rows)==20 and sum(r['bytes'] for r in rows)==2732
(B/'cache25214-plan-audit.json').write_text(json.dumps(dict(status='prepared-and-validated-not-executed',outputs=rows,totalFiles=20,totalBytes=2732,claimsGoalComplete=False),indent=2)+'\n',encoding='utf-8');print('exact20 caches/2732 bytes; staged/work planners agree; both validators pass; no deletion yet')

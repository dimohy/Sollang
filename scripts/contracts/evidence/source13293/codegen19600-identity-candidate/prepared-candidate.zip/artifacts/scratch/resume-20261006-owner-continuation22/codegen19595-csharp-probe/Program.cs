using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;

if (args.Length != 3) throw new ArgumentException("assembly, collision input and new output directory required");
var assemblyPath = Path.GetFullPath(args[0]);
using var input = JsonDocument.Parse(File.ReadAllBytes(args[1]));
var left = input.RootElement.GetProperty("ordinalOrder")[0].GetString()!;
var right = input.RootElement.GetProperty("ordinalOrder")[1].GetString()!;
var expectedHash = ulong.Parse(input.RootElement.GetProperty("identityHashDecimal").GetString()!);
var outputDirectory = Path.GetFullPath(args[2]);
if (Directory.Exists(outputDirectory)) throw new IOException("output already exists");
Directory.CreateDirectory(outputDirectory);
var compilerHashBefore = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(assemblyPath)));
var assembly = Assembly.LoadFrom(assemblyPath);
var unitType = assembly.GetType("Sollang.Compiler.CodeGen.LlvmCodegenUnit", true)!;
var keyType = assembly.GetType("Sollang.Compiler.CodeGen.LlvmCodegenKey", true)!;
var kindType = assembly.GetType("Sollang.Compiler.CodeGen.LlvmCodegenUnitKind", true)!;
var outputType = assembly.GetType("Sollang.Compiler.CodeGen.LlvmCodegenOutput", true)!;
var cacheType = assembly.GetType("Sollang.Compiler.Cli.IncrementalCodegenCache", true)!;
var identity = unitType.GetMethod("StableIdentity", [typeof(string)])!;
var compare = unitType.GetMethod("CompareIdentities")!;
var encode = cacheType.GetMethod("Encode", BindingFlags.NonPublic | BindingFlags.Static)!;
var read = cacheType.GetMethod("Read", BindingFlags.NonPublic | BindingFlags.Static)!;
var observations = new List<object>();

ulong Hash(string value) => (ulong)identity.Invoke(null, [value])!;
var leftHash = Hash(left);
var rightHash = Hash(right);
if (left == right || leftHash != expectedHash || rightHash != expectedHash)
    throw new InvalidDataException("actual CSharp stable hash does not match the collision input");
if ((int)compare.Invoke(null, [leftHash, left, rightHash, right])! >= 0
    || (int)compare.Invoke(null, [rightHash, right, leftHash, left])! <= 0
    || (int)compare.Invoke(null, [leftHash, left, leftHash, left])! != 0)
    throw new InvalidDataException("actual CSharp full identity ordering changed");
observations.Add(new { id = "full-identity-order", status = "passed", leftHash, rightHash });
if ((int)compare.Invoke(null, [0UL, "\U00010000", 0UL, "\uFF21"])! >= 0)
    throw new InvalidDataException("actual CSharp ordering must compare UTF16 ordinal units after a hash tie");
observations.Add(new { id = "unicode-ordinal-tie", status = "passed" });

object MakeOutput(string first, string second)
{
    var values = Array.CreateInstance(unitType, 4);
    var records = new[] { (0, "", "H"), (1, first, "A"), (1, second, "B"), (2, "", "T") };
    for (var i = 0; i < records.Length; i++)
    {
        var item = records[i];
        var key = Activator.CreateInstance(keyType, [101UL, 202UL])!;
        values.SetValue(Activator.CreateInstance(unitType,
            [Enum.ToObject(kindType, item.Item1), item.Item2, key, item.Item3, false]), i);
    }
    return Activator.CreateInstance(outputType, [values])!;
}

IReadOnlyList<ulong> Encode(object value) =>
    (IReadOnlyList<ulong>)encode.Invoke(null, [value, 101UL, 202UL, 303UL])!;

var words = Encode(MakeOutput(left, right));
var artifact = Path.Combine(outputDirectory, "valid-collision.cgu");
using (var stream = File.Create(artifact))
using (var writer = new BinaryWriter(stream))
    foreach (var word in words) writer.Write(word);
var decoded = read.Invoke(null, [artifact, 101UL, 202UL, 303UL])!;
var units = ((IEnumerable)decoded.GetType().GetProperty("Units")!.GetValue(decoded)!).Cast<object>().ToArray();
var names = units.Select(value => (string)unitType.GetProperty("Identity")!.GetValue(value)!).ToArray();
var text = string.Concat(units.Select(value => (string)unitType.GetProperty("Text")!.GetValue(value)!));
if (!names.SequenceEqual(["", left, right, ""]) || text != "HABT")
    throw new InvalidDataException("actual CSharp codec did not preserve distinct colliding identities");
observations.Add(new { id = "codec-distinct-collision-roundtrip", status = "passed", units = units.Length, text });

void Reject(string caseId, object value)
{
    try { Encode(value); }
    catch (TargetInvocationException error) when (error.InnerException is InvalidDataException)
    {
        observations.Add(new { id = caseId, status = "passed", diagnostic = error.InnerException.Message });
        return;
    }
    throw new InvalidDataException("actual CSharp codec accepted " + caseId);
}
Reject("reversed-collision-order", MakeOutput(right, left));
Reject("duplicate-exact-identity", MakeOutput(left, left));
var invalid = words.ToArray();
const int firstModule = 17; // Header8 + prefix record8 + one packed fragment word.
var identityStart = firstModule + 8;
var identityLength = checked((int)invalid[firstModule + 4]);
var invalidIdentity = invalid.AsSpan(identityStart, identityLength).ToArray().Select(value => checked((byte)value)).ToArray();
invalidIdentity[0] = 255;
invalid[identityStart] = 255;
var hashBytes = unitType.GetMethod("StableIdentity", [typeof(ReadOnlySpan<byte>)])!
    .CreateDelegate<ByteIdentityHash>();
invalid[firstModule + 1] = hashBytes(invalidIdentity);
var checksum = cacheType.GetMethod("Checksum", BindingFlags.Static | BindingFlags.NonPublic)!;
invalid[7] = (ulong)checksum.Invoke(null, [invalid, 8, invalid.Length - 8, 7809847782465536322UL])!;
var invalidArtifact = Path.Combine(outputDirectory, "invalid-utf8.cgu");
using (var stream = File.Create(invalidArtifact))
using (var writer = new BinaryWriter(stream))
    foreach (var word in invalid) writer.Write(word);
var rejectedUtf8 = false;
try { read.Invoke(null, [invalidArtifact, 101UL, 202UL, 303UL]); }
catch (TargetInvocationException error) when (error.InnerException is System.Text.DecoderFallbackException)
{
    rejectedUtf8 = true;
    observations.Add(new { id = "malformed-utf8-identity", status = "passed", identityHash = invalid[firstModule + 1] });
}
if (!rejectedUtf8) throw new InvalidDataException("actual CSharp codec accepted malformed UTF8 identity");
var compilerHashAfter = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(assemblyPath)));
if (compilerHashBefore != compilerHashAfter) throw new InvalidDataException("compiler assembly changed");
var result = new
{
    schemaVersion = 1, status = "passed", completed = 6, total = 6,
    compilerAssembly = assemblyPath, compilerSha256 = compilerHashAfter,
    collisionHash = expectedHash, left, right, observations,
    implementation = "Reflection invokes the selected current compiler's actual identity, Encode and Read methods; no copied codec.",
    claimsPhaseComplete = false, claimsGoalComplete = false
};
File.WriteAllText(Path.Combine(outputDirectory, "observation.json"),
    JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine(JsonSerializer.Serialize(new { result.status, result.completed, result.total, result.compilerSha256 }));

delegate ulong ByteIdentityHash(ReadOnlySpan<byte> bytes);

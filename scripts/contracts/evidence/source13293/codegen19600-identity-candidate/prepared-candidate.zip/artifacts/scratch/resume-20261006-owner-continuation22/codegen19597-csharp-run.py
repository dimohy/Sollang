"""Execute the current CSharp codec first, after current parsing is qualified."""
from pathlib import Path
import hashlib
import json
import shutil
import sys
import time

root=Path.cwd();base=root/'artifacts/scratch/resume-20261006-owner-continuation22'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
assert read(base/'parsing19585-closure/qualification.json')['applied'] is True
sys.path.insert(0,str(root/'scripts'))
from verification_execution import VerificationExecution
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output

compiler=base/'managed19361/compiler/Sollang.Compiler.dll'
build=read(base/'managed19361/result.json')
assert build['status']=='passed' and build['inputsStable'] and build['processesStopped']
assert sha(compiler)==build['compilerDllSha256'].upper()=='6C07E2C39D4A21E884B1E4B4B55793964AC0940D20FB47A133DDC0B932CCC12D'
fixture=base/'codegen19595-csharp-probe';data=base/'codegen19592-collision-input.json'
sources=[root/'src/Sollang.Compiler/CodeGen/LlvmCodegenUnit.cs',root/'src/Sollang.Compiler/Cli/IncrementalCodegenCache.cs']
for p in sources:assert sha(p)==build['inputHashes'][str(p)].upper()
dotnet=shutil.which('dotnet');assert dotnet
paths=[Path(__file__),data,*fixture.glob('*.cs'),*fixture.glob('*.csproj'),*sources,*managed_runtime_inputs(compiler),
       root/'global.json',root/'Directory.Build.props',Path(dotnet),root/'scripts/verification_execution.py',
       base/'managed19361/result.json',base/'parsing19585-closure/qualification.json']
pins={str(p):sha(p) for p in paths}
stable=lambda:all(Path(p).is_file() and sha(p)==digest for p,digest in pins.items())
out=base/'codegen19597-csharp-supervised'
retained=[base/'v18915/compiler-build01',base/'v19080/compiler-build01',base/'v19418/compiler-build01']
initialize_output(root,out,reusable_directories=retained);out.mkdir(exist_ok=False)
record={'schemaVersion':1,'status':'running','completed':0,'total':6,'cases':[],
        'scope':'Actual current CSharp identity comparator and cache Encode/Read invoked through reflection; no copied implementation.',
        'caseBudgetSeconds':180,'inputHashes':pins,'pendingConsumerProtection':True,
        'pendingConsumers':['Focused SLG codegen identity reproduction and validation'],
        'claimsPhaseComplete':False,'claimsGoalComplete':False}
x=VerificationExecution(root,out,record,stable,sha);error=None;started=time.monotonic()
def run(command,prefix):
    remaining=180-(time.monotonic()-started)
    if remaining<=0:raise TimeoutError('CODEGEN_REFERENCE_WHOLE_CASE_180_EXHAUSTED')
    return x.run(command,prefix,timeout=remaining)
try:
    products=out/'harness';intermediate=(out/'obj').as_posix()+'/'
    result=run([dotnet,'build',str(fixture/'CodegenIdentityProbe.csproj'),'-c','Release','--output',str(products),
                '-warnaserror','-p:BaseIntermediateOutputPath='+intermediate,
                '-p:MSBuildProjectExtensionsPath='+intermediate],out/'build')
    assert result.returncode==0,('REFERENCE_HARNESS_BUILD_FAILED',result.stderr)
    result=run([dotnet,str(products/'CodegenIdentityProbe.dll'),str(compiler),str(data),str(out/'observations')],out/'execute')
    assert result.returncode==0 and result.stderr=='',('REFERENCE_CODEC_FAILED',result.stderr)
    observed=read(out/'observations/observation.json')
    assert observed['status']=='passed' and observed['completed']==observed['total']==6
    assert observed['compilerSha256']==sha(compiler)
    if time.monotonic()-started>=180:raise TimeoutError('CODEGEN_REFERENCE_WHOLE_CASE_180_EXHAUSTED')
    record.update(status='passed',completed=6,cases=observed['observations'],
                  authoritativeObservation=str(out/'observations/observation.json'),
                  wholeCaseElapsedSeconds=time.monotonic()-started)
except BaseException as e:error=e
finally:x.finalize(error,cleanup=False)
print(json.dumps({k:record.get(k) for k in ['status','completed','total','failure','inputsStable','processesStopped','wholeCaseElapsedSeconds']}))
sys.exit(0 if record['status']=='passed' else 1)

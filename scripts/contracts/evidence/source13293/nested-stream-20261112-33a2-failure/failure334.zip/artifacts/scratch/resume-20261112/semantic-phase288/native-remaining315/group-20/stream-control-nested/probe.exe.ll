; sollang.codegen.unit 0:
; sollang.codegen.key 1931366173152882045:11560731650131413008
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"
declare ptr @GetProcessHeap()
declare ptr @HeapAlloc(ptr, i32, i64)
declare i32 @HeapFree(ptr, i32, ptr)
define internal ptr @sollang_alloc(i64 %bytes) {
entry:
  %heap = call ptr @GetProcessHeap()
  %value = call ptr @HeapAlloc(ptr %heap, i32 0, i64 %bytes)
  ret ptr %value
}
define internal void @sollang_free(ptr %value) {
entry:
  %is_null = icmp eq ptr %value, null
  br i1 %is_null, label %done, label %release
release:
  %heap = call ptr @GetProcessHeap()
  %ignored = call i32 @HeapFree(ptr %heap, i32 0, ptr %value)
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1 immarg)
declare i32 @GetConsoleMode(ptr, ptr)
declare i32 @WriteConsoleW(ptr, ptr, i32, ptr, ptr)
declare i32 @WriteFile(ptr, ptr, i32, ptr, ptr)
declare i32 @MultiByteToWideChar(i32, i32, ptr, i32, ptr, i32)
define internal i32 @sollang_write_stream_chunk(ptr %handle, ptr %data, i32 %len, ptr %written, i1 %is_console) {
entry:
  %empty = icmp eq i32 %len, 0
  br i1 %empty, label %success_empty, label %classify

success_empty:
  store i32 0, ptr %written, align 4
  ret i32 1

classify:
  br i1 %is_console, label %console_prepare, label %redirected

redirected:
  br label %redirected_write

redirected_write:
  %redirected_offset = phi i32 [ 0, %redirected ], [ %redirected_next, %redirected_advance ]
  %redirected_remaining = sub i32 %len, %redirected_offset
  %redirected_offset64 = zext i32 %redirected_offset to i64
  %redirected_data = getelementptr i8, ptr %data, i64 %redirected_offset64
  store i32 0, ptr %written, align 4
  %redirected_ok = call i32 @WriteFile(ptr %handle, ptr %redirected_data, i32 %redirected_remaining, ptr %written, ptr null)
  %redirected_count = load i32, ptr %written, align 4
  %redirected_succeeded = icmp ne i32 %redirected_ok, 0
  %redirected_progress = icmp ugt i32 %redirected_count, 0
  %redirected_bounded = icmp ule i32 %redirected_count, %redirected_remaining
  %redirected_valid0 = and i1 %redirected_succeeded, %redirected_progress
  %redirected_valid = and i1 %redirected_valid0, %redirected_bounded
  br i1 %redirected_valid, label %redirected_advance, label %write_failed

redirected_advance:
  %redirected_next = add i32 %redirected_offset, %redirected_count
  %redirected_complete = icmp eq i32 %redirected_next, %len
  br i1 %redirected_complete, label %write_succeeded, label %redirected_write

console_prepare:
  %wide_chars = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %len, ptr null, i32 0)
  %valid_utf8 = icmp sgt i32 %wide_chars, 0
  br i1 %valid_utf8, label %allocate, label %conversion_failed

allocate:
  %wide_bytes32 = shl i32 %wide_chars, 1
  %wide_bytes = zext i32 %wide_bytes32 to i64
  %heap = call ptr @GetProcessHeap()
  %wide = call ptr @HeapAlloc(ptr %heap, i32 0, i64 %wide_bytes)
  %wide_written = alloca i32, align 4
  %allocated = icmp ne ptr %wide, null
  br i1 %allocated, label %convert, label %conversion_failed

convert:
  %converted = call i32 @MultiByteToWideChar(i32 65001, i32 8, ptr %data, i32 %len, ptr %wide, i32 %wide_chars)
  %converted_all = icmp eq i32 %converted, %wide_chars
  br i1 %converted_all, label %console_write, label %conversion_free

console_write:
  %console_offset = phi i32 [ 0, %convert ], [ %console_next, %console_advance ]
  %console_remaining = sub i32 %wide_chars, %console_offset
  %console_offset64 = zext i32 %console_offset to i64
  %console_data = getelementptr i16, ptr %wide, i64 %console_offset64
  store i32 0, ptr %wide_written, align 4
  %console_ok = call i32 @WriteConsoleW(ptr %handle, ptr %console_data, i32 %console_remaining, ptr %wide_written, ptr null)
  %console_count = load i32, ptr %wide_written, align 4
  %console_succeeded = icmp ne i32 %console_ok, 0
  %console_progress = icmp ugt i32 %console_count, 0
  %console_bounded = icmp ule i32 %console_count, %console_remaining
  %console_valid0 = and i1 %console_succeeded, %console_progress
  %console_valid = and i1 %console_valid0, %console_bounded
  br i1 %console_valid, label %console_advance, label %console_write_failed

console_advance:
  %console_next = add i32 %console_offset, %console_count
  %console_complete = icmp eq i32 %console_next, %wide_chars
  br i1 %console_complete, label %console_write_succeeded, label %console_write

console_write_succeeded:
  %freed = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %write_succeeded

console_write_failed:
  %freed_after_write_failure = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %write_failed

write_succeeded:
  store i32 %len, ptr %written, align 4
  ret i32 1

write_failed:
  store i32 0, ptr %written, align 4
  ret i32 0

conversion_free:
  %freed_after_failure = call i32 @HeapFree(ptr %heap, i32 0, ptr %wide)
  br label %conversion_failed

conversion_failed:
  store i32 0, ptr %written, align 4
  ret i32 0
}

define internal i32 @sollang_write_stream(ptr %handle, ptr %data, i64 %len64, ptr %written, i1 %is_console) {
entry:
  %empty = icmp eq i64 %len64, 0
  br i1 %empty, label %success_empty, label %prepare

success_empty:
  store i32 0, ptr %written, align 4
  ret i32 1

prepare:
  %offset = phi i64 [ 0, %entry ], [ %next, %advance ]
  %remaining = sub i64 %len64, %offset
  %current = getelementptr i8, ptr %data, i64 %offset
  %more = icmp ugt i64 %remaining, 1048576
  %proposed = select i1 %more, i64 1048576, i64 %remaining
  %split_console = and i1 %more, %is_console
  br i1 %split_console, label %trim_boundary, label %write

trim_boundary:
  %boundary = phi i64 [ 1048576, %prepare ], [ %previous, %trim_next ]
  %boundary_ptr = getelementptr i8, ptr %current, i64 %boundary
  %boundary_byte = load i8, ptr %boundary_ptr, align 1
  %prefix = and i8 %boundary_byte, -64
  %continuation = icmp eq i8 %prefix, -128
  br i1 %continuation, label %trim_next, label %write

trim_next:
  %can_trim = icmp ugt i64 %boundary, 1048573
  %previous = sub i64 %boundary, 1
  br i1 %can_trim, label %trim_boundary, label %failure

write:
  %chunk64 = phi i64 [ %proposed, %prepare ], [ %boundary, %trim_boundary ]
  %chunk32 = trunc i64 %chunk64 to i32
  %ok = call i32 @sollang_write_stream_chunk(ptr %handle, ptr %current, i32 %chunk32, ptr %written, i1 %is_console)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %advance, label %failure

advance:
  %next = add i64 %offset, %chunk64
  %complete = icmp eq i64 %next, %len64
  br i1 %complete, label %success, label %prepare

success:
  ret i32 1

failure:
  store i32 0, ptr %written, align 4
  ret i32 0
}

define internal i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %len) {
entry:
  %written = alloca i32, align 4
  %mode = alloca i32, align 4
  %empty = icmp eq i64 %len, 0
  br i1 %empty, label %success, label %classify
classify:
  %console_status = call i32 @GetConsoleMode(ptr %handle, ptr %mode)
  %is_console = icmp ne i32 %console_status, 0
  %ok = call i32 @sollang_write_stream(ptr %handle, ptr %data, i64 %len, ptr %written, i1 %is_console)
  ret i32 %ok
success:
  ret i32 1
}
define internal i32 @sollang_runtime_write_stdout_bytes(ptr %handle, ptr %data, i32 %len) {
entry:
  %length = zext i32 %len to i64
  %ok = call i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %length)
  ret i32 %ok
}
@sollang_runtime_newline = private constant [1 x i8] c"\0A"
@sollang_runtime_stdout_buffer = private global [1048576 x i8] zeroinitializer
@sollang_runtime_stdout_count = private global i64 0
define internal void @sollang_runtime_flush_stdout() {
entry:
  %count = load i64, ptr @sollang_runtime_stdout_count, align 8
  %has_data = icmp ugt i64 %count, 0
  br i1 %has_data, label %write, label %done
write:
  %handle = call ptr @GetStdHandle(i32 -11)
  %count32 = trunc i64 %count to i32
  %ok = call i32 @sollang_runtime_write_stdout_bytes(ptr %handle, ptr @sollang_runtime_stdout_buffer, i32 %count32)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %clear, label %failure
clear:
  store i64 0, ptr @sollang_runtime_stdout_count, align 8
  br label %done
failure:
  call void @llvm.trap()
  unreachable
done:
  ret void
}
define internal void @sollang_runtime_append_stdout(ptr %data, i64 %len) {
entry:
  %count = load i64, ptr @sollang_runtime_stdout_count, align 8
  %total = add i64 %count, %len
  %available = sub i64 1048576, %count
  %fits = icmp ule i64 %len, %available
  br i1 %fits, label %append, label %flush
flush:
  call void @sollang_runtime_flush_stdout()
  %large = icmp ugt i64 %len, 1048576
  br i1 %large, label %direct, label %append_empty
direct:
  %handle = call ptr @GetStdHandle(i32 -11)
  %ok = call i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %len)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %direct_done, label %direct_failure
direct_done:
  ret void
direct_failure:
  call void @llvm.trap()
  unreachable
append_empty:
  call void @llvm.memcpy.p0.p0.i64(ptr @sollang_runtime_stdout_buffer, ptr %data, i64 %len, i1 false)
  store i64 %len, ptr @sollang_runtime_stdout_count, align 8
  ret void
append:
  %slot = getelementptr i8, ptr @sollang_runtime_stdout_buffer, i64 %count
  call void @llvm.memcpy.p0.p0.i64(ptr %slot, ptr %data, i64 %len, i1 false)
  store i64 %total, ptr @sollang_runtime_stdout_count, align 8
  ret void
}
@sollang_runtime_error_newline = private constant [2 x i8] c"\0D\0A"
define internal void @sollang_runtime_eprint(ptr %data, i64 %len, i1 %newline) {
entry:
  %handle = call ptr @GetStdHandle(i32 -12)
  %ok = call i32 @sollang_runtime_write_stdout_all(ptr %handle, ptr %data, i64 %len)
  br i1 %newline, label %write_newline, label %done
write_newline:
  %newline_ok = call i32 @sollang_runtime_write_stdout_bytes(ptr %handle, ptr @sollang_runtime_error_newline, i32 2)
  br label %done
done:
  ret void
}
define internal void @sollang_runtime_eprintln(ptr %data, i64 %len) {
entry:
  call void @sollang_runtime_eprint(ptr %data, i64 %len, i1 true)
  ret void
}
define internal i32 @sollang_context_write(ptr %stdout, ptr %data, i64 %len, ptr %written) {
entry:
  br label %write
write:
  %mode = alloca i32, align 4
  %console_status = call i32 @GetConsoleMode(ptr %stdout, ptr %mode)
  %console = icmp ne i32 %console_status, 0
  %ok = call i32 @sollang_write_stream(ptr %stdout, ptr %data, i64 %len, ptr %written, i1 %console)
  ret i32 %ok
}
define internal i1 @sollang_runtime_print_checked(ptr %stdout, ptr %written, ptr %ok_state, ptr %data, i64 %len, i1 %newline) {
entry:
  %data_status = call i32 @sollang_context_write(ptr %stdout, ptr %data, i64 %len, ptr %written)
  %data_ok = icmp ne i32 %data_status, 0
  br i1 %newline, label %write_newline, label %done
write_newline:
  %newline_status = call i32 @sollang_context_write(ptr %stdout, ptr @sollang_runtime_newline, i64 1, ptr %written)
  %newline_ok = icmp ne i32 %newline_status, 0
  %combined = and i1 %data_ok, %newline_ok
  br label %done
done:
  %ok = phi i1 [ %data_ok, %entry ], [ %combined, %write_newline ]
  %previous = load i1, ptr %ok_state, align 1
  %next_ok = and i1 %previous, %ok
  store i1 %next_ok, ptr %ok_state, align 1
  ret i1 %ok
}
define internal void @sollang_runtime_print(ptr %stdout, ptr %written, ptr %ok_state, ptr %data, i64 %len, i1 %newline) {
entry:
  %ok = call i1 @sollang_runtime_print_checked(ptr %stdout, ptr %written, ptr %ok_state, ptr %data, i64 %len, i1 %newline)
  ret void
}
define internal i64 @sollang_format_u64(ptr %dest, i64 %value) #0 {
entry:
  br label %count

count:
  %count_n = phi i64 [ %value, %entry ], [ %count_q, %count_more ]
  %length = phi i64 [ 1, %entry ], [ %next_length, %count_more ]
  %count_q = udiv i64 %count_n, 10
  %count_done = icmp eq i64 %count_q, 0
  br i1 %count_done, label %write_entry, label %count_more

count_more:
  %next_length = add i64 %length, 1
  br label %count

write_entry:
  %last_index = sub i64 %length, 1
  br label %write

write:
  %write_n = phi i64 [ %value, %write_entry ], [ %write_q, %write ]
  %index = phi i64 [ %last_index, %write_entry ], [ %previous_index, %write ]
  %digit = urem i64 %write_n, 10
  %write_q = udiv i64 %write_n, 10
  %digit8 = trunc i64 %digit to i8
  %ascii = add i8 %digit8, 48
  %slot = getelementptr i8, ptr %dest, i64 %index
  store i8 %ascii, ptr %slot, align 1
  %previous_index = sub i64 %index, 1
  %write_done = icmp eq i64 %write_q, 0
  br i1 %write_done, label %return, label %write

return:
  ret i64 %length
}

define internal i64 @sollang_format_i64(ptr %dest, i64 %value) #0 {
entry:
  %negative = icmp slt i64 %value, 0
  br i1 %negative, label %negative_value, label %positive_value

negative_value:
  store i8 45, ptr %dest, align 1
  %digits_dest = getelementptr i8, ptr %dest, i64 1
  %magnitude = sub i64 0, %value
  %negative_digits = call i64 @sollang_format_u64(ptr %digits_dest, i64 %magnitude)
  %negative_length = add i64 %negative_digits, 1
  ret i64 %negative_length

positive_value:
  %positive_length = call i64 @sollang_format_u64(ptr %dest, i64 %value)
  ret i64 %positive_length
}

define internal void @sollang_runtime_print_i32(ptr %stdout, ptr %written, ptr %ok_state, i32 %value, i1 %newline) {
entry:
  %buffer = alloca [12 x i8], align 1
  %wide = sext i32 %value to i64
  %length = call i64 @sollang_format_i64(ptr %buffer, i64 %wide)
  call void @sollang_runtime_print(ptr %stdout, ptr %written, ptr %ok_state, ptr %buffer, i64 %length, i1 %newline)
  ret void
}
define internal void @sollang_runtime_print_i64(ptr %stdout, ptr %written, ptr %ok_state, i64 %value, i1 %signed, i1 %newline) {
entry:
  %buffer = alloca [21 x i8], align 1
  br i1 %signed, label %signed_value, label %unsigned_value
signed_value:
  %signed_length = call i64 @sollang_format_i64(ptr %buffer, i64 %value)
  br label %emit
unsigned_value:
  %unsigned_length = call i64 @sollang_format_u64(ptr %buffer, i64 %value)
  br label %emit
emit:
  %length = phi i64 [ %signed_length, %signed_value ], [ %unsigned_length, %unsigned_value ]
  call void @sollang_runtime_print(ptr %stdout, ptr %written, ptr %ok_state, ptr %buffer, i64 %length, i1 %newline)
  ret void
}
define internal void @sollang_runtime_eprint_i32(i32 %value, i1 %newline) {
entry:
  %buffer = alloca [12 x i8], align 1
  %wide = sext i32 %value to i64
  %length = call i64 @sollang_format_i64(ptr %buffer, i64 %wide)
  call void @sollang_runtime_eprint(ptr %buffer, i64 %length, i1 %newline)
  ret void
}
define internal void @sollang_runtime_eprint_i64(i64 %value, i1 %signed, i1 %newline) {
entry:
  %buffer = alloca [21 x i8], align 1
  br i1 %signed, label %signed_value, label %unsigned_value
signed_value:
  %signed_length = call i64 @sollang_format_i64(ptr %buffer, i64 %value)
  br label %emit
unsigned_value:
  %unsigned_length = call i64 @sollang_format_u64(ptr %buffer, i64 %value)
  br label %emit
emit:
  %length = phi i64 [ %signed_length, %signed_value ], [ %unsigned_length, %unsigned_value ]
  call void @sollang_runtime_eprint(ptr %buffer, i64 %length, i1 %newline)
  ret void
}
declare dllimport i32 @GetLastError()
declare dllimport ptr @CreateFileA(ptr, i32, i32, ptr, i32, i32, ptr)
declare dllimport ptr @CreateFileW(ptr, i32, i32, ptr, i32, i32, ptr)
declare dllimport i32 @CloseHandle(ptr)
@sollang_bool_true_bytes = private constant [4 x i8] c"true"
@sollang_bool_false_bytes = private constant [5 x i8] c"false"
%sollang.source_text = type { ptr, i64, ptr, i64 }
%sollang.text = type { ptr, i64 }
%sollang.stream = type { ptr, ptr, ptr }
%sollang.event_stream = type { ptr, ptr, ptr }
%sollang.enum.t460 = type { i32, [0 x i64] }
%sollang.enum.t461 = type { i32, [0 x i64] }
%sollang.enum.t462 = type { i32, [0 x i64] }
%sollang.enum.t463 = type { i32, [0 x i64] }
%sollang.enum.t464 = type { i32, [0 x i64] }
%sollang.enum.t465 = type { i32, [0 x i64] }
%sollang.enum.t466 = type { i32, [0 x i64] }
%sollang.enum.t467 = type { i32, [0 x i64] }
%sollang.enum.t468 = type { i32, [0 x i64] }
%sollang.enum.t469 = type { i32, [0 x i64] }
%sollang.enum.t470 = type { i32, [0 x i64] }
%sollang.enum.t471 = type { i32, [0 x i64] }
%sollang.enum.t472 = type { i32, [0 x i64] }
%sollang.enum.t473 = type { i32, [1 x i64] }
%sollang.enum.t474 = type { i32, [1 x i64] }
%sollang.enum.t475 = type { i32, [0 x i64] }
%sollang.enum.t476 = type { i32, [0 x i64] }
%sollang.enum.t477 = type { i32, [5 x i64] }
%sollang.enum.t478 = type { i32, [4 x i64] }
%sollang.enum.t479 = type { i32, [0 x i64] }
%sollang.enum.t480 = type { i32, [1 x i64] }
%sollang.enum.t481 = type { i32, [0 x i64] }
%sollang.enum.t482 = type { i32, [1 x i64] }
%sollang.enum.t483 = type { i32, [0 x i64] }
%sollang.enum.t484 = type { i32, [1 x i64] }
%sollang.enum.t485 = type { i32, [0 x i64] }
%sollang.enum.t486 = type { i32, [1 x i64] }
%sollang.enum.t487 = type { i32, [1 x i64] }
%sollang.enum.t488 = type { i32, [0 x i64] }
%sollang.enum.t489 = type { i32, [66 x i64] }
%sollang.enum.t490 = type { i32, [1 x i64] }
%sollang.enum.t491 = type { i32, [1 x i64] }
%sollang.enum.t492 = type { i32, [0 x i64] }
%sollang.enum.t493 = type { i32, [4 x i64] }
%sollang.enum.t494 = type { i32, [1 x i64] }
%sollang.enum.t495 = type { i32, [1 x i64] }
%sollang.enum.t496 = type { i32, [0 x i64] }
%sollang.enum.t497 = type { i32, [0 x i64] }
%sollang.enum.t498 = type { i32, [0 x i64] }
%sollang.enum.t499 = type { i32, [0 x i64] }
%sollang.enum.t500 = type { i32, [0 x i64] }
%sollang.enum.t501 = type { i32, [1 x i64] }
%sollang.enum.t502 = type { i32, [0 x i64] }
%sollang.enum.t503 = type { i32, [4 x i64] }
%sollang.enum.t504 = type { i32, [1 x i64] }
%sollang.enum.t505 = type { i32, [0 x i64] }
%sollang.enum.t506 = type { i32, [1 x i64] }
%sollang.enum.t507 = type { i32, [1 x i64] }
%sollang.enum.t508 = type { i32, [0 x i64] }
%sollang.enum.t509 = type { i32, [0 x i64] }
%sollang.enum.t510 = type { i32, [0 x i64] }
%sollang.enum.t511 = type { i32, [1 x i64] }
%sollang.enum.t512 = type { i32, [0 x i64] }
%sollang.enum.t513 = type { i32, [0 x i64] }
%sollang.enum.t514 = type { i32, [0 x i64] }
%sollang.enum.t515 = type { i32, [0 x i64] }
%sollang.enum.t516 = type { i32, [0 x i64] }
%sollang.enum.t517 = type { i32, [0 x i64] }
%sollang.enum.t518 = type { i32, [0 x i64] }
%sollang.enum.t519 = type { i32, [0 x i64] }
%sollang.enum.t520 = type { i32, [0 x i64] }
%sollang.enum.t521 = type { i32, [3 x i64] }
%sollang.enum.t522 = type { i32, [0 x i64] }
%sollang.enum.t523 = type { i32, [0 x i64] }
%sollang.enum.t524 = type { i32, [0 x i64] }
%sollang.enum.t525 = type { i32, [0 x i64] }
%sollang.enum.t526 = type { i32, [0 x i64] }
%sollang.enum.t527 = type { i32, [0 x i64] }
%sollang.enum.t528 = type { i32, [0 x i64] }
%sollang.enum.t529 = type { i32, [0 x i64] }
%sollang.enum.t530 = type { i32, [0 x i64] }
%sollang.enum.t531 = type { i32, [0 x i64] }
%sollang.enum.t532 = type { i32, [3 x i64] }
%sollang.enum.t533 = type { i32, [0 x i64] }
%sollang.enum.t534 = type { i32, [2 x i64] }
%sollang.enum.t535 = type { i32, [0 x i64] }
%sollang.enum.t536 = type { i32, [2 x i64] }
%sollang.enum.t537 = type { i32, [4 x i64] }
%sollang.enum.t538 = type { i32, [0 x i64] }
%sollang.enum.t539 = type { i32, [0 x i64] }
%sollang.enum.t540 = type { i32, [0 x i64] }
%sollang.enum.t541 = type { i32, [1 x i64] }
%sollang.enum.t542 = type { i32, [0 x i64] }
%sollang.enum.t543 = type { i32, [0 x i64] }
%sollang.enum.t544 = type { i32, [2 x i64] }
%sollang.enum.t545 = type { i32, [7 x i64] }
%sollang.enum.t546 = type { i32, [0 x i64] }
%sollang.enum.t547 = type { i32, [2 x i64] }
%sollang.enum.t548 = type { i32, [0 x i64] }
%sollang.enum.t549 = type { i32, [0 x i64] }
%sollang.enum.t550 = type { i32, [0 x i64] }
%sollang.enum.t551 = type { i32, [0 x i64] }
%sollang.enum.t552 = type { i32, [2 x i64] }
%sollang.enum.t553 = type { i32, [8 x i64] }
%sollang.enum.t554 = type { i32, [0 x i64] }
%sollang.enum.t555 = type { i32, [0 x i64] }
%sollang.enum.t556 = type { i32, [7 x i64] }
%sollang.enum.t557 = type { i32, [0 x i64] }
%sollang.enum.t558 = type { i32, [0 x i64] }
%sollang.enum.t559 = type { i32, [0 x i64] }
%sollang.enum.t560 = type { i32, [0 x i64] }
%sollang.enum.t561 = type { i32, [0 x i64] }
%sollang.enum.t562 = type { i32, [0 x i64] }
%sollang.enum.t563 = type { i32, [0 x i64] }
%sollang.enum.t564 = type { i32, [1 x i64] }
%sollang.enum.t565 = type { i32, [0 x i64] }
%sollang.enum.t566 = type { i32, [0 x i64] }
%sollang.enum.t567 = type { i32, [16 x i64] }
%sollang.enum.t568 = type { i32, [16 x i64] }
%sollang.enum.t569 = type { i32, [0 x i64] }
%sollang.enum.t570 = type { i32, [0 x i64] }
%sollang.enum.t571 = type { i32, [0 x i64] }
%sollang.enum.t572 = type { i32, [0 x i64] }
%sollang.enum.t573 = type { i32, [0 x i64] }
%sollang.enum.t574 = type { i32, [0 x i64] }
%sollang.enum.t575 = type { i32, [0 x i64] }
%sollang.enum.t576 = type { i32, [0 x i64] }
%sollang.enum.t577 = type { i32, [0 x i64] }
%sollang.enum.t578 = type { i32, [0 x i64] }
%sollang.enum.t579 = type { i32, [0 x i64] }
%sollang.enum.t580 = type { i32, [0 x i64] }
%sollang.enum.t581 = type { i32, [0 x i64] }
%sollang.enum.t582 = type { i32, [0 x i64] }
%sollang.enum.t583 = type { i32, [0 x i64] }
%sollang.enum.t584 = type { i32, [3 x i64] }
%sollang.enum.t585 = type { i32, [1 x i64] }
%sollang.enum.t586 = type { i32, [12 x i64] }
%sollang.enum.t587 = type { i32, [0 x i64] }
%sollang.enum.t588 = type { i32, [0 x i64] }
%sollang.enum.t589 = type { i32, [0 x i64] }
%sollang.enum.t590 = type { i32, [0 x i64] }
%sollang.enum.t591 = type { i32, [0 x i64] }
%sollang.enum.t592 = type { i32, [4 x i64] }
%sollang.enum.t593 = type { i32, [3 x i64] }
%sollang.enum.t594 = type { i32, [0 x i64] }
%sollang.enum.t595 = type { i32, [2 x i64] }
%sollang.enum.t596 = type { i32, [0 x i64] }
%sollang.enum.t597 = type { i32, [0 x i64] }
%sollang.enum.t598 = type { i32, [0 x i64] }
%sollang.enum.t599 = type { i32, [0 x i64] }
%sollang.enum.t600 = type { i32, [2 x i64] }
%sollang.enum.t601 = type { i32, [2 x i64] }
%sollang.enum.t602 = type { i32, [1 x i64] }
%sollang.enum.t647 = type { i32, [1 x i64] }
%sollang.enum.t654 = type { i32, [1 x i64] }
%sollang.enum.t657 = type { i32, [1 x i64] }
%sollang.enum.t670 = type { i32, [3 x i64] }
%sollang.enum.t671 = type { i32, [44 x i64] }
%sollang.enum.t672 = type { i32, [2 x i64] }
%sollang.enum.t673 = type { i32, [13 x i64] }
%sollang.enum.t674 = type { i32, [2 x i64] }
%sollang.enum.t677 = type { i32, [1 x i64] }
%sollang.enum.t678 = type { i32, [7 x i64] }
%sollang.enum.t679 = type { i32, [1 x i64] }
%sollang.enum.t682 = type { i32, [3 x i64] }
%sollang.enum.t685 = type { i32, [1 x i64] }
%sollang.enum.t686 = type { i32, [3 x i64] }
%sollang.enum.t687 = type { i32, [4 x i64] }
%sollang.enum.t688 = type { i32, [105 x i64] }
%sollang.enum.t689 = type { i32, [2 x i64] }
%sollang.enum.t690 = type { i32, [9 x i64] }
%sollang.enum.t691 = type { i32, [26 x i64] }
%sollang.enum.t692 = type { i32, [81 x i64] }
%sollang.enum.t693 = type { i32, [2 x i64] }
%sollang.enum.t696 = type { i32, [3 x i64] }
%sollang.enum.t698 = type { i32, [26 x i64] }
%sollang.enum.t699 = type { i32, [4 x i64] }
%sollang.enum.t700 = type { i32, [2 x i64] }
%sollang.enum.t701 = type { i32, [2 x i64] }
%sollang.enum.t702 = type { i32, [2 x i64] }
%sollang.enum.t703 = type { i32, [50 x i64] }
%sollang.enum.t704 = type { i32, [2 x i64] }
%sollang.enum.t705 = type { i32, [3 x i64] }
%sollang.enum.t706 = type { i32, [2 x i64] }
%sollang.enum.t707 = type { i32, [2 x i64] }
%sollang.enum.t709 = type { i32, [2 x i64] }
%sollang.enum.t710 = type { i32, [2 x i64] }
%sollang.enum.t715 = type { i32, [9 x i64] }
%sollang.enum.t716 = type { i32, [24 x i64] }
%sollang.enum.t717 = type { i32, [2 x i64] }
%sollang.enum.t718 = type { i32, [12 x i64] }
%sollang.enum.t719 = type { i32, [11 x i64] }
%sollang.enum.t720 = type { i32, [2 x i64] }
%sollang.enum.t721 = type { i32, [32 x i64] }
%sollang.enum.t722 = type { i32, [34 x i64] }
%sollang.enum.t723 = type { i32, [2 x i64] }
%sollang.enum.t724 = type { i32, [9 x i64] }
%sollang.enum.t725 = type { i32, [31 x i64] }
%sollang.enum.t726 = type { i32, [2 x i64] }
%sollang.enum.t727 = type { i32, [15 x i64] }
%sollang.enum.t728 = type { i32, [34 x i64] }
%sollang.enum.t729 = type { i32, [2 x i64] }
%sollang.enum.t730 = type { i32, [2 x i64] }
%sollang.enum.t731 = type { i32, [6 x i64] }
%sollang.enum.t732 = type { i32, [2 x i64] }
%sollang.enum.t733 = type { i32, [2 x i64] }
%sollang.enum.t734 = type { i32, [2 x i64] }
%sollang.enum.t736 = type { i32, [14 x i64] }
%sollang.enum.t737 = type { i32, [9 x i64] }
%sollang.enum.t738 = type { i32, [5 x i64] }
%sollang.enum.t739 = type { i32, [5 x i64] }
%sollang.enum.t740 = type { i32, [4 x i64] }
%sollang.enum.t741 = type { i32, [2 x i64] }
%sollang.enum.t743 = type { i32, [2 x i64] }
%sollang.enum.t744 = type { i32, [2 x i64] }
%sollang.enum.t745 = type { i32, [81 x i64] }
%sollang.enum.t746 = type { i32, [2 x i64] }
%sollang.enum.t747 = type { i32, [3 x i64] }
%sollang.enum.t748 = type { i32, [3 x i64] }
%sollang.enum.t749 = type { i32, [5 x i64] }
%sollang.enum.t750 = type { i32, [2 x i64] }
%sollang.enum.t751 = type { i32, [14 x i64] }
%sollang.enum.t752 = type { i32, [2 x i64] }
%sollang.enum.t753 = type { i32, [32 x i64] }
%sollang.enum.t754 = type { i32, [4 x i64] }
%sollang.enum.t755 = type { i32, [2 x i64] }
%sollang.enum.t757 = type { i32, [5 x i64] }
%sollang.enum.t758 = type { i32, [2 x i64] }
%sollang.enum.t759 = type { i32, [2 x i64] }
%sollang.enum.t760 = type { i32, [5 x i64] }
%sollang.enum.t761 = type { i32, [2 x i64] }
%sollang.enum.t762 = type { i32, [2 x i64] }
%sollang.enum.t763 = type { i32, [32 x i64] }
%sollang.enum.t764 = type { i32, [2 x i64] }
%sollang.enum.t765 = type { i32, [4 x i64] }
%sollang.enum.t768 = type { i32, [2 x i64] }
%sollang.enum.t769 = type { i32, [2 x i64] }
%sollang.enum.t770 = type { i32, [4 x i64] }
%sollang.enum.t771 = type { i32, [2 x i64] }
%sollang.enum.t772 = type { i32, [2 x i64] }
%sollang.enum.t773 = type { i32, [2 x i64] }
%sollang.enum.t774 = type { i32, [2 x i64] }
%sollang.enum.t775 = type { i32, [2 x i64] }
%sollang.enum.t776 = type { i32, [2 x i64] }
%sollang.enum.t777 = type { i32, [3 x i64] }
%sollang.enum.t778 = type { i32, [2 x i64] }
%sollang.enum.t780 = type { i32, [3 x i64] }
%sollang.enum.t781 = type { i32, [4 x i64] }
%sollang.enum.t782 = type { i32, [9 x i64] }
%sollang.enum.t783 = type { i32, [2 x i64] }
%sollang.enum.t784 = type { i32, [32 x i64] }
%sollang.enum.t785 = type { i32, [3 x i64] }
%sollang.enum.t787 = type { i32, [5 x i64] }
%sollang.enum.t788 = type { i32, [2 x i64] }
%sollang.enum.t789 = type { i32, [2 x i64] }
%sollang.enum.t790 = type { i32, [4 x i64] }
%sollang.enum.t791 = type { i32, [4 x i64] }
%sollang.enum.t792 = type { i32, [72 x i64] }
%sollang.enum.t793 = type { i32, [2 x i64] }
%sollang.enum.t794 = type { i32, [2 x i64] }
%sollang.enum.t795 = type { i32, [2 x i64] }
%sollang.enum.t796 = type { i32, [13 x i64] }
%sollang.enum.t797 = type { i32, [26 x i64] }
%sollang.enum.t798 = type { i32, [5 x i64] }
%sollang.enum.t799 = type { i32, [2 x i64] }
%sollang.enum.t802 = type { i32, [2 x i64] }
%sollang.enum.t803 = type { i32, [72 x i64] }
%sollang.enum.t804 = type { i32, [3 x i64] }
%sollang.enum.t805 = type { i32, [3 x i64] }
%sollang.enum.t806 = type { i32, [13 x i64] }
%sollang.enum.t807 = type { i32, [70 x i64] }
%sollang.enum.t808 = type { i32, [2 x i64] }
%sollang.enum.t809 = type { i32, [40 x i64] }
%sollang.enum.t813 = type { i32, [3 x i64] }
%sollang.enum.t814 = type { i32, [10 x i64] }
%sollang.enum.t815 = type { i32, [11 x i64] }
%sollang.enum.t816 = type { i32, [2 x i64] }
%sollang.enum.t817 = type { i32, [1 x i64] }
%sollang.enum.t818 = type { i32, [5 x i64] }
%sollang.enum.t819 = type { i32, [3 x i64] }
%sollang.enum.t820 = type { i32, [3 x i64] }
%sollang.enum.t821 = type { i32, [10 x i64] }
%sollang.enum.t822 = type { i32, [33 x i64] }
%sollang.enum.t823 = type { i32, [35 x i64] }
%sollang.enum.t824 = type { i32, [1 x i64] }
%sollang.enum.t831 = type { i32, [8 x i64] }
%sollang.enum.t832 = type { i32, [1 x i64] }
%sollang.enum.t833 = type { i32, [2 x i64] }
%sollang.enum.t834 = type { i32, [2 x i64] }
%sollang.enum.t835 = type { i32, [2 x i64] }
%sollang.enum.t839 = type { i32, [3 x i64] }
%sollang.enum.t842 = type { i32, [2 x i64] }
%sollang.enum.t843 = type { i32, [2 x i64] }
%sollang.enum.t844 = type { i32, [2 x i64] }
%sollang.enum.t845 = type { i32, [5 x i64] }
%sollang.enum.t846 = type { i32, [11 x i64] }
%sollang.enum.t847 = type { i32, [9 x i64] }
%sollang.enum.t849 = type { i32, [3 x i64] }
%sollang.enum.t850 = type { i32, [2 x i64] }
%sollang.enum.t851 = type { i32, [2 x i64] }
%sollang.enum.t852 = type { i32, [2 x i64] }
%sollang.enum.t853 = type { i32, [2 x i64] }
%sollang.enum.t854 = type { i32, [2 x i64] }
%sollang.enum.t855 = type { i32, [2 x i64] }
%sollang.enum.t856 = type { i32, [2 x i64] }
%sollang.enum.t857 = type { i32, [2 x i64] }
%sollang.enum.t858 = type { i32, [3 x i64] }
%sollang.enum.t859 = type { i32, [4 x i64] }
%sollang.enum.t860 = type { i32, [2 x i64] }
%sollang.enum.t861 = type { i32, [3 x i64] }
%sollang.enum.t866 = type { i32, [1 x i64] }
%sollang.enum.t867 = type { i32, [4 x i64] }
%sollang.enum.t868 = type { i32, [4 x i64] }
%sollang.enum.t869 = type { i32, [2 x i64] }
%sollang.enum.t870 = type { i32, [8 x i64] }
%sollang.enum.t871 = type { i32, [2 x i64] }
%sollang.enum.t872 = type { i32, [4 x i64] }
%sollang.enum.t873 = type { i32, [2 x i64] }
%sollang.enum.t874 = type { i32, [2 x i64] }
%sollang.enum.t876 = type { i32, [3 x i64] }
%sollang.enum.t877 = type { i32, [5 x i64] }
%sollang.enum.t878 = type { i32, [10 x i64] }
%sollang.enum.t879 = type { i32, [10 x i64] }
%sollang.enum.t880 = type { i32, [11 x i64] }
%sollang.enum.t881 = type { i32, [11 x i64] }
%sollang.enum.t884 = type { i32, [7 x i64] }
%sollang.enum.t885 = type { i32, [8 x i64] }
%sollang.enum.t886 = type { i32, [7 x i64] }
%sollang.enum.t887 = type { i32, [8 x i64] }
%sollang.enum.t888 = type { i32, [2 x i64] }
%sollang.enum.t889 = type { i32, [7 x i64] }
%sollang.enum.t890 = type { i32, [7 x i64] }
%sollang.enum.t891 = type { i32, [3 x i64] }
%sollang.enum.t893 = type { i32, [2 x i64] }
%sollang.enum.t894 = type { i32, [3 x i64] }
%sollang.enum.t895 = type { i32, [2 x i64] }
%sollang.enum.t896 = type { i32, [2 x i64] }
%sollang.enum.t898 = type { i32, [2 x i64] }
%sollang.enum.t899 = type { i32, [4 x i64] }
%sollang.enum.t901 = type { i32, [3 x i64] }
%sollang.enum.t902 = type { i32, [3 x i64] }
%sollang.enum.t903 = type { i32, [13 x i64] }
%sollang.enum.t904 = type { i32, [12 x i64] }
%sollang.enum.t905 = type { i32, [4 x i64] }
%sollang.enum.t906 = type { i32, [2 x i64] }
%sollang.enum.t907 = type { i32, [2 x i64] }
%sollang.enum.t909 = type { i32, [2 x i64] }
%sollang.enum.t910 = type { i32, [5 x i64] }
%sollang.enum.t911 = type { i32, [3 x i64] }
%sollang.enum.t912 = type { i32, [15 x i64] }
%sollang.enum.t913 = type { i32, [3 x i64] }
%sollang.enum.t914 = type { i32, [2 x i64] }
%sollang.enum.t915 = type { i32, [3 x i64] }
%sollang.enum.t920 = type { i32, [2 x i64] }
%sollang.enum.t921 = type { i32, [3 x i64] }
%sollang.enum.t922 = type { i32, [3 x i64] }
%sollang.enum.t923 = type { i32, [15 x i64] }
%sollang.enum.t924 = type { i32, [25 x i64] }
%sollang.enum.t925 = type { i32, [7 x i64] }
%sollang.enum.t926 = type { i32, [5 x i64] }
%sollang.enum.t927 = type { i32, [9 x i64] }
%sollang.enum.t928 = type { i32, [31 x i64] }
%sollang.enum.t929 = type { i32, [3 x i64] }
%sollang.enum.t930 = type { i32, [8 x i64] }
%sollang.enum.t931 = type { i32, [2 x i64] }
%sollang.enum.t932 = type { i32, [12 x i64] }
%sollang.enum.t933 = type { i32, [6 x i64] }
%sollang.enum.t934 = type { i32, [2 x i64] }
%sollang.enum.t935 = type { i32, [9 x i64] }
%sollang.enum.t936 = type { i32, [6 x i64] }
%sollang.enum.t937 = type { i32, [3 x i64] }
%sollang.enum.t938 = type { i32, [26 x i64] }
%sollang.enum.t939 = type { i32, [4 x i64] }
%sollang.enum.t940 = type { i32, [5 x i64] }
%sollang.enum.t941 = type { i32, [8 x i64] }
%sollang.enum.t942 = type { i32, [40 x i64] }
%sollang.enum.t943 = type { i32, [9 x i64] }
%sollang.enum.t944 = type { i32, [3 x i64] }
%sollang.enum.t955 = type { i32, [2 x i64] }
%sollang.enum.t956 = type { i32, [2 x i64] }
%sollang.enum.t957 = type { i32, [9 x i64] }
%sollang.enum.t958 = type { i32, [21 x i64] }
%sollang.enum.t959 = type { i32, [4 x i64] }
%sollang.enum.t960 = type { i32, [9 x i64] }
%sollang.enum.t961 = type { i32, [2 x i64] }
%sollang.enum.t962 = type { i32, [5 x i64] }
%sollang.enum.t963 = type { i32, [2 x i64] }
%sollang.enum.t964 = type { i32, [14 x i64] }
%sollang.enum.t966 = type { i32, [11 x i64] }
%sollang.enum.t967 = type { i32, [16 x i64] }
%sollang.enum.t968 = type { i32, [7 x i64] }
%sollang.enum.t971 = type { i32, [7 x i64] }
%sollang.enum.t972 = type { i32, [4 x i64] }
%sollang.enum.t973 = type { i32, [6 x i64] }
%sollang.enum.t974 = type { i32, [7 x i64] }
%sollang.enum.t975 = type { i32, [6 x i64] }
%sollang.enum.t976 = type { i32, [5 x i64] }
%sollang.enum.t977 = type { i32, [2 x i64] }
%sollang.enum.t978 = type { i32, [4 x i64] }
%sollang.enum.t979 = type { i32, [10 x i64] }
%sollang.enum.t980 = type { i32, [131 x i64] }
%sollang.enum.t981 = type { i32, [2 x i64] }
%sollang.enum.t982 = type { i32, [16 x i64] }
%sollang.enum.t983 = type { i32, [7 x i64] }
%sollang.enum.t984 = type { i32, [10 x i64] }
%sollang.enum.t986 = type { i32, [5 x i64] }
%sollang.enum.t988 = type { i32, [2 x i64] }
%sollang.enum.t989 = type { i32, [17 x i64] }
%sollang.enum.t990 = type { i32, [2 x i64] }
%sollang.enum.t991 = type { i32, [2 x i64] }
%sollang.enum.t992 = type { i32, [3 x i64] }
%sollang.enum.t994 = type { i32, [10 x i64] }
%sollang.enum.t995 = type { i32, [5 x i64] }
%sollang.enum.t996 = type { i32, [3 x i64] }
%sollang.enum.t997 = type { i32, [8 x i64] }
%sollang.enum.t999 = type { i32, [2 x i64] }
%sollang.enum.t1000 = type { i32, [4 x i64] }
%sollang.enum.t1002 = type { i32, [2 x i64] }
%sollang.enum.t1003 = type { i32, [9 x i64] }
%sollang.enum.t1004 = type { i32, [3 x i64] }
%sollang.enum.t1005 = type { i32, [7 x i64] }
%sollang.enum.t1006 = type { i32, [11 x i64] }
%sollang.enum.t1007 = type { i32, [7 x i64] }
%sollang.enum.t1011 = type { i32, [6 x i64] }
%sollang.enum.t1013 = type { i32, [11 x i64] }
%sollang.enum.t1014 = type { i32, [18 x i64] }
%sollang.enum.t1016 = type { i32, [149 x i64] }
%sollang.enum.t1017 = type { i32, [3 x i64] }
%sollang.enum.t1018 = type { i32, [2 x i64] }
%sollang.enum.t1019 = type { i32, [2 x i64] }
%sollang.enum.t1020 = type { i32, [2 x i64] }
%sollang.enum.t1022 = type { i32, [12 x i64] }
%sollang.enum.t1023 = type { i32, [9 x i64] }
%sollang.enum.t1024 = type { i32, [5 x i64] }
%sollang.enum.t1025 = type { i32, [5 x i64] }
%sollang.enum.t1026 = type { i32, [6 x i64] }
%sollang.enum.t1027 = type { i32, [6 x i64] }
%sollang.enum.t1028 = type { i32, [2 x i64] }
%sollang.enum.t1030 = type { i32, [14 x i64] }
%sollang.enum.t1033 = type { i32, [6 x i64] }
%sollang.enum.t1034 = type { i32, [6 x i64] }
%sollang.enum.t1036 = type { i32, [4 x i64] }
%sollang.enum.t1037 = type { i32, [5 x i64] }
%sollang.enum.t1038 = type { i32, [4 x i64] }
%sollang.enum.t1039 = type { i32, [21 x i64] }
%sollang.enum.t1040 = type { i32, [4 x i64] }
%sollang.enum.t1041 = type { i32, [5 x i64] }
%sollang.enum.t1042 = type { i32, [2 x i64] }
%sollang.enum.t1044 = type { i32, [3 x i64] }
%sollang.enum.t1045 = type { i32, [4 x i64] }
%sollang.enum.t1046 = type { i32, [2 x i64] }
%sollang.enum.t1047 = type { i32, [6 x i64] }
%sollang.enum.t1048 = type { i32, [5 x i64] }
%sollang.enum.t1049 = type { i32, [5 x i64] }
%sollang.enum.t1052 = type { i32, [16 x i64] }
%sollang.enum.t1053 = type { i32, [7 x i64] }
%sollang.enum.t1054 = type { i32, [6 x i64] }
%sollang.enum.t1055 = type { i32, [4 x i64] }
%sollang.enum.t1056 = type { i32, [5 x i64] }
%sollang.enum.t1057 = type { i32, [2 x i64] }
%sollang.enum.t1058 = type { i32, [2 x i64] }
%sollang.enum.t1060 = type { i32, [4 x i64] }
%sollang.enum.t1062 = type { i32, [9 x i64] }
%sollang.enum.t1063 = type { i32, [4 x i64] }
%sollang.enum.t1067 = type { i32, [1 x i64] }
%sollang.enum.t1068 = type { i32, [2 x i64] }
%sollang.enum.t1069 = type { i32, [3 x i64] }
%sollang.enum.t1070 = type { i32, [17 x i64] }
%sollang.enum.t1072 = type { i32, [2 x i64] }
%sollang.enum.t1073 = type { i32, [3 x i64] }
%sollang.enum.t1074 = type { i32, [12 x i64] }
%sollang.enum.t1075 = type { i32, [3 x i64] }
%sollang.enum.t1076 = type { i32, [4 x i64] }
%sollang.enum.t1090 = type { i32, [12 x i64] }
%sollang.enum.t1091 = type { i32, [4 x i64] }
%sollang.enum.t1092 = type { i32, [3 x i64] }
%sollang.enum.t1093 = type { i32, [3 x i64] }
%sollang.enum.t1094 = type { i32, [4 x i64] }
%sollang.enum.t1095 = type { i32, [2 x i64] }
%sollang.enum.t1097 = type { i32, [3 x i64] }
%sollang.enum.t1098 = type { i32, [6 x i64] }
%sollang.enum.t1099 = type { i32, [3 x i64] }
%sollang.enum.t1102 = type { i32, [2 x i64] }
%sollang.enum.t1103 = type { i32, [2 x i64] }
%sollang.enum.t1104 = type { i32, [2 x i64] }
%sollang.enum.t1105 = type { i32, [2 x i64] }
%sollang.enum.t1106 = type { i32, [2 x i64] }
%sollang.enum.t1107 = type { i32, [12 x i64] }
%sollang.enum.t1108 = type { i32, [6 x i64] }
%sollang.enum.t1109 = type { i32, [3 x i64] }
%sollang.enum.t1110 = type { i32, [2 x i64] }
%sollang.enum.t1111 = type { i32, [8 x i64] }
%sollang.enum.t1113 = type { i32, [2 x i64] }
%sollang.enum.t1114 = type { i32, [4 x i64] }
%sollang.enum.t1117 = type { i32, [3 x i64] }
%sollang.enum.t1118 = type { i32, [4 x i64] }
%sollang.enum.t1119 = type { i32, [4 x i64] }
%sollang.enum.t1120 = type { i32, [7 x i64] }
%sollang.enum.t1121 = type { i32, [4 x i64] }
%sollang.enum.t1123 = type { i32, [9 x i64] }
%sollang.enum.t1124 = type { i32, [2 x i64] }
%sollang.enum.t1125 = type { i32, [4 x i64] }
%sollang.enum.t1126 = type { i32, [1 x i64] }
%sollang.enum.t1127 = type { i32, [1 x i64] }
%sollang.enum.t1128 = type { i32, [2 x i64] }
%sollang.enum.t1129 = type { i32, [2 x i64] }
%sollang.enum.t1130 = type { i32, [2 x i64] }
%sollang.enum.t1131 = type { i32, [6 x i64] }
%sollang.enum.t1132 = type { i32, [1 x i64] }
%sollang.enum.t1133 = type { i32, [1 x i64] }
%sollang.enum.t1134 = type { i32, [1 x i64] }
%sollang.enum.t1135 = type { i32, [1 x i64] }
%sollang.enum.t1136 = type { i32, [11 x i64] }
%sollang.enum.t1137 = type { i32, [29 x i64] }
%sollang.enum.t1138 = type { i32, [12 x i64] }
%sollang.enum.t1139 = type { i32, [2 x i64] }
%sollang.enum.t1140 = type { i32, [2 x i64] }
%sollang.enum.t1142 = type { i32, [3 x i64] }
%sollang.enum.t1143 = type { i32, [2 x i64] }
%sollang.enum.t1144 = type { i32, [3 x i64] }
%sollang.enum.t1145 = type { i32, [2 x i64] }
%sollang.enum.t1146 = type { i32, [1 x i64] }
%sollang.enum.t1147 = type { i32, [1 x i64] }
%sollang.enum.t1154 = type { i32, [2 x i64] }
%sollang.enum.t1155 = type { i32, [2 x i64] }
%sollang.enum.t1156 = type { i32, [2 x i64] }
%sollang.enum.t1157 = type { i32, [0 x i64] }
%sollang.enum.t1158 = type { i32, [0 x i64] }
%sollang.enum.t1159 = type { i32, [2 x i64] }
%sollang.enum.t1160 = type { i32, [2 x i64] }
%sollang.enum.t1161 = type { i32, [2 x i64] }
%sollang.enum.t1162 = type { i32, [7 x i64] }
%sollang.enum.t1163 = type { i32, [4 x i64] }
%sollang.enum.t1164 = type { i32, [2 x i64] }
%sollang.enum.t1167 = type { i32, [2 x i64] }
%sollang.enum.t1169 = type { i32, [3 x i64] }
%sollang.enum.t1180 = type { i32, [0 x i64] }
%sollang.enum.t1181 = type { i32, [3 x i64] }
%sollang.enum.t1182 = type { i32, [6 x i64] }
%sollang.enum.t1183 = type { i32, [2 x i64] }
%sollang.enum.t1184 = type { i32, [3 x i64] }
%sollang.enum.t1185 = type { i32, [8 x i64] }
%sollang.enum.t1186 = type { i32, [2 x i64] }
%sollang.enum.t1187 = type { i32, [1 x i64] }
%sollang.enum.t1188 = type { i32, [2 x i64] }
%sollang.enum.t1189 = type { i32, [3 x i64] }
%sollang.enum.t1190 = type { i32, [2 x i64] }
%sollang.enum.t1192 = type { i32, [2 x i64] }
%sollang.enum.t1193 = type { i32, [4 x i64] }
%sollang.enum.t1194 = type { i32, [3 x i64] }
%sollang.enum.t1195 = type { i32, [18 x i64] }
%sollang.enum.t1196 = type { i32, [3 x i64] }
%sollang.enum.t1197 = type { i32, [16 x i64] }
%sollang.enum.t1198 = type { i32, [2 x i64] }
%sollang.enum.t1199 = type { i32, [2 x i64] }
%sollang.enum.t1200 = type { i32, [2 x i64] }
%sollang.enum.t1202 = type { i32, [1 x i64] }
%sollang.enum.t1203 = type { i32, [2 x i64] }
%sollang.enum.t1204 = type { i32, [2 x i64] }
%sollang.enum.t1205 = type { i32, [5 x i64] }
%sollang.enum.t1206 = type { i32, [2 x i64] }
%sollang.enum.t1209 = type { i32, [9 x i64] }
%sollang.enum.t1210 = type { i32, [7 x i64] }
%sollang.enum.t1211 = type { i32, [3 x i64] }
%sollang.enum.t1212 = type { i32, [2 x i64] }
%sollang.struct.x0D7374642E616C676F726974686D010301084F72646572696E6700 = type { %sollang.enum.t460 }
%sollang.struct.x0D7374642E616C676F726974686D0103010A416C676F726974686D7300 = type {  }
%sollang.struct.x0D7374642E616C676F726974686D0103010C536561726368526573756C7400 = type { i32, i1 }
%sollang.struct.x0D7374642E616C676F726974686D0103010A457175616C52616E676500 = type { i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A6970010301054572726F7200 = type { %sollang.enum.t466, i64 }
%sollang.struct.x0F7374642E617263686976652E7A6970010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A697001030105436F64656300 = type { %sollang.struct.x0F7374642E617263686976652E7A6970010301064C696D69747300 }
%sollang.struct.x0F7374642E617263686976652E7A69700103010D4465666C6174654C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A6970010301074465636F64657200 = type { %sollang.struct.x0F7374642E617263686976652E7A6970010301064C696D69747300, %sollang.enum.t464, i32, %sollang.array.i32, %sollang.array.i32, i32, i32, i32, %sollang.array.i32, i32, i32, i32, i32, %sollang.array.i32, i1, %sollang.struct.x0F7374642E617263686976652E7A69700103010D4465666C6174654C696D69747300, i32, %sollang.struct.x0E7374642E686173682E63726333320103010648617368657200, %sollang.array.i32, %sollang.array.i32, i32, i32, i32, %sollang.array.i32, i32, i32, %sollang.array.i32, i32, i1, %sollang.struct.x0F7374642E617263686976652E7A6970010301054572726F7200 }
%sollang.struct.x0F7374642E617263686976652E7A69700103010C5772697465724C696D69747300 = type { i32, i32, i32, i32, i32, i32, i32, i32 }
%sollang.struct.x0F7374642E617263686976652E7A69700103010657726974657200 = type { %sollang.struct.x0F7374642E617263686976652E7A69700103010C5772697465724C696D69747300, %sollang.enum.t465, i32, i32, i32, i32, i32, i32, %sollang.struct.x0E7374642E686173682E63726333320103010648617368657200, %sollang.array.i32 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030110446961676E6F737469634C696D69747300 = type { i32 }
%sollang.struct.x157374642E6173796E632E646961676E6F73746963730103011153757370656E73696F6E4C6F6361746F7200 = type { %sollang.text, %sollang.text, i32, i64, i32, i32 }
%sollang.struct.x157374642E6173796E632E646961676E6F73746963730103010C5461736B536E617073686F7400 = type { i64, %sollang.enum.t677, %sollang.enum.t467, %sollang.enum.t468, %sollang.enum.t677, i64, %sollang.enum.t678 }
%sollang.struct.x157374642E6173796E632E646961676E6F73746963730103010E536E617073686F74526573756C7400 = type { i64, i64, i64, i1 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030111446961676E6F7374696353756D6D61727900 = type { i64, i64, i64 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030111446961676E6F7374696353657373696F6E00 = type { i64 }
%sollang.struct.x157374642E6173796E632E646961676E6F737469637301030116446961676E6F73746963436C6F73654661696C75726500 = type { %sollang.struct.x157374642E6173796E632E646961676E6F737469637301030111446961676E6F7374696353657373696F6E00, %sollang.enum.t471 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301054572726F7200 = type { %sollang.enum.t498, i64 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C6901030105436F64656300 = type { %sollang.struct.x137374642E636F6D70726573732E62726F746C69010301064C696D69747300 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C6901030107456E636F64657200 = type { i32, i32, i32, i32, i32, i32, i1 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301074465636F64657200 = type { i32, i32, i32, i32, i32, i32, %sollang.enum.t497, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010657696E646F7700, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010652656164657200, i32, i1, i32, i32, i32, %sollang.array.i32, i1, %sollang.struct.x137374642E636F6D70726573732E62726F746C69010301054572726F7200 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C690103010942697457726974657200 = type { i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C690103010942697452656164657200 = type { i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C690103010C53747265616D437572736F7200 = type { i32, i32 }
%sollang.struct.x137374642E636F6D70726573732E62726F746C69010301074269745265616400 = type { i1, i64 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301054572726F7200 = type { %sollang.enum.t475, i64 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301084578656375746F7200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273656400, i32, i32, i32, i32 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301074465636F64656400 = type { %sollang.array.i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E640103010652656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273656400, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301085265736F6C76657200, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32, i32, %sollang.enum.t472, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.t472 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E640103010853747265616D656400 = type { %sollang.array.i32 }
%sollang.struct.x1B7374642E636F6D70726573732E62726F746C692E636F6D6D616E64010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301054572726F7200 = type { %sollang.enum.t488, i64 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301064C696D69747300 = type { i32, i32, i32, i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010650617273657200, %sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010650617273657200, i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D5072656C75646552656164657200 = type { %sollang.enum.t476, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.t499, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301075072656C75646500 = type { i32, i32, i32, i32, i32, %sollang.enum.t499, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F68656164657201030111426C6F636B53747265616D52656164657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, %sollang.enum.t479, i32, i32, i32, i32, %sollang.enum.t478, %sollang.enum.t478 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010C48656164657252656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F68656164657201030111426C6F636B53747265616D52656164657200, %sollang.enum.t481, i32, %sollang.array.i32, i32, i32, %sollang.array.i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D4865616465725072656C75646500 = type { %sollang.array.i32, i32, i32, i32, %sollang.array.i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D436F6E7465787452656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D4865616465725072656C75646500, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010652656164657200, %sollang.enum.t483, %sollang.array.i32, %sollang.array.i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010E436F6E746578745072656C75646500 = type { %sollang.array.i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010A5472656552656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010E436F6E746578745072656C75646500, %sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010652656164657200, %sollang.enum.t485, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010B426C6F636B53747265616D00 = type { i32, i32, %sollang.enum.t478, %sollang.enum.t478 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010B426C6F636B53776974636800 = type { i32, i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273656400 = type { %sollang.array.i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F686561646572010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F68656164657201030111506172736564426C6F636B53747265616D00 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010B426C6F636B53747265616D00, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D010301054572726F7200 = type { %sollang.enum.t498, i64 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010C48656164657250726566697800 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010C48656164657252656164657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010D436F6E7465787450726566697800 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010D436F6E7465787452656164657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010A5472656550726566697800 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010A5472656552656164657200, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D0103010652656164657200 = type { %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F6865616465720103010650617273657200, %sollang.struct.x257374642E636F6D70726573732E62726F746C692E636F6D707265737365645F73747265616D010301064C696D69747300, i32, %sollang.array.i32, %sollang.enum.t489 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D6170010301054572726F7200 = type { %sollang.enum.t496, i64 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D6170010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010650617273657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010650617273656400 = type { %sollang.array.i32, i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010652656164657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, i32, %sollang.enum.t492, i32, i32, i32, %sollang.array.i32, %sollang.enum.t493 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D61700103010853747265616D656400 = type { %sollang.array.i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E636F6E746578745F6D6170010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301054572726F7200 = type { %sollang.enum.t505, i64 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301064C696D69747300 = type { i32, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200 = type { %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074275696C64657200, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273656400 = type { %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301055461626C6500, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301154669786564436F64654C656E67746852656164657200 = type { %sollang.enum.t500, i32 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301114465736372697074696F6E52656164657200 = type { %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074275696C64657200, i32, i32, i32, %sollang.enum.t502, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301154669786564436F64654C656E67746852656164657200, %sollang.array.i32, i32, i32, i32, %sollang.enum.t503, i32, i32, i32, i32, i32, i32, %sollang.enum.t503 }
%sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F6465010301044269747300 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301054572726F7200 = type { %sollang.enum.t508, i64 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301064C696D69747300 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074275696C64657200 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301055461626C6500 = type { %sollang.array.i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301074465636F64656400 = type { i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010650726F62656400 = type { i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010C57696E646F774C696D69747300 = type { i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C650103010657696E646F7700 = type { i64, i32, i32 }
%sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C65010301065065656B656400 = type { i32, i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301054572726F7200 = type { %sollang.enum.t510, i64 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301064C696D69747300 = type { i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E617279010301085265736F6C76657200 = type { i32 }
%sollang.struct.x257374642E636F6D70726573732E62726F746C692E7374617469635F64696374696F6E6172790103010A44657363726970746F7200 = type { i32, %sollang.enum.t509, i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F7570010301054572726F7200 = type { %sollang.enum.t512, i64 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F7570010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010650617273657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010650617273656400 = type { %sollang.array.i32, %sollang.struct.x207374642E636F6D70726573732E62726F746C692E7072656669785F7461626C6501030108506F736974696F6E00 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010652656164657200 = type { %sollang.struct.x1F7374642E636F6D70726573732E62726F746C692E7072656669785F636F64650103010650617273657200, i32, i32, i32, i32, i32, i32, i32, i32, %sollang.array.i32 }
%sollang.struct.x1E7374642E636F6D70726573732E62726F746C692E747265655F67726F75700103010853747265616D656400 = type { %sollang.array.i32 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301054572726F7200 = type { %sollang.enum.t514, i64 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301064C696D69747300 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030105436F64656300 = type { %sollang.struct.x117374642E636F6D70726573732E677A6970010301064C696D69747300 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010D4465636F6465724C696D69747300 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030107456E636F64657200 = type { i32, i32, i32, i32, i1, i1, %sollang.struct.x117374642E636F6D70726573732E677A69700103010942697457726974657200 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301074465636F64657200 = type { %sollang.struct.x117374642E636F6D70726573732E677A697001030105436F64656300, i32, i32, i32, i32, i32, i32, %sollang.enum.t513, i32, i32, i32, i32, i32, i32, i32, i1, i32, i32, i32, i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, i32, i32, i32, i32, i32, i32, i32, %sollang.array.i32, %sollang.array.i32, i32, i1, %sollang.struct.x117374642E636F6D70726573732E677A6970010301054572726F7200, i1, i1 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301115261774465666C6174654465636F64657200 = type { %sollang.struct.x117374642E636F6D70726573732E677A6970010301074465636F64657200 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A456E636F6465506C616E00 = type { i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A4465636F6465506C616E00 = type { i32, i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030109426974437572736F7200 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010942697457726974657200 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010B4465666C617465436F646500 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A4C656E677468436F646500 = type { i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C44697374616E6365436F646500 = type { i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301054D6174636800 = type { i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00 = type { %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010B487566666D616E5061697200 = type { %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00, %sollang.struct.x117374642E636F6D70726573732E677A697001030107487566666D616E00 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C496E666C617465537461746500 = type { %sollang.struct.x117374642E636F6D70726573732E677A697001030109426974437572736F7200, i32, %sollang.array.i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C4D656D6265724465636F646500 = type { i32, %sollang.array.i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C496E666C617465436F756E7400 = type { i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010C53747265616D437572736F7200 = type { i32 }
%sollang.struct.x117374642E636F6D70726573732E677A6970010301074269745265616400 = type { i1, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A55496E7433325265616400 = type { i1, i32 }
%sollang.struct.x117374642E636F6D70726573732E677A69700103010A53796D626F6C5265616400 = type { i1, i32 }
%sollang.struct.x117374642E636F6D70726573732E7A737464010301054572726F7200 = type { %sollang.enum.t516, i64 }
%sollang.struct.x117374642E636F6D70726573732E7A7374640103010F436F6D70726573736564426C6F636B00 = type { %sollang.array.i32, %sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500, i1, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E7A737464010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x117374642E636F6D70726573732E7A7374640103010C4672616D654F7074696F6E7300 = type { i1 }
%sollang.struct.x117374642E636F6D70726573732E7A73746401030105436F64656300 = type { %sollang.struct.x117374642E636F6D70726573732E7A737464010301064C696D69747300, %sollang.struct.x117374642E636F6D70726573732E7A7374640103010C4672616D654F7074696F6E7300 }
%sollang.struct.x117374642E636F6D70726573732E7A73746401030107456E636F64657200 = type { i32, i32, i32, i32, i1, i1, %sollang.struct.x117374642E686173682E78786861736836340103010648617368657200 }
%sollang.struct.x117374642E636F6D70726573732E7A737464010301074465636F64657200 = type { i32, i32, i32, i32, i32, i32, i32, i32, %sollang.enum.t515, i64, i32, i32, i32, i32, i32, i1, i64, i1, %sollang.struct.x117374642E686173682E78786861736836340103010648617368657200, i32, i32, i32, i32, i1, %sollang.array.i32, %sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500, i1, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32, %sollang.array.i32, i1, %sollang.struct.x117374642E636F6D70726573732E7A737464010301054572726F7200 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500 = type { %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i32 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E6673650103010B4465736372697074696F6E00 = type { %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i32 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E6673650103010B466F72776172644269747300 = type { i32 }
%sollang.struct.x157374642E636F6D70726573732E7A7374642E6673650103010B526576657273654269747300 = type { i32, i32, i32 }
%sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500 = type { %sollang.array.i32, i32 }
%sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E0103010B4465736372697074696F6E00 = type { %sollang.struct.x197374642E636F6D70726573732E7A7374642E687566666D616E010301055461626C6500, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E636501030106437572736F7200 = type { i32, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E636501030108507265706172656400 = type { %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E63650103010D526563656E744F66667365747300 = type { i32, i32, i32 }
%sollang.struct.x1A7374642E636F6D70726573732E7A7374642E73657175656E6365010301074465636F64656400 = type { %sollang.array.i32, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, %sollang.struct.x157374642E636F6D70726573732E7A7374642E667365010301055461626C6500, i1, i1, i1, i32, i32, i32 }
%sollang.struct.x117374642E63727970746F2E616573313238010301034B657900 = type { %sollang.array.i32 }
%sollang.struct.x117374642E63727970746F2E6165733132380103010A426C6F636B56616C756500 = type { %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E6165733132385F67636D010301065365616C656400 = type { %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E6165733132385F67636D010301034B657900 = type { %sollang.struct.x117374642E63727970746F2E616573313238010301034B657900, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E6165733132385F67636D0103010A426C6F636B56616C756500 = type { %sollang.int_slice }
%sollang.struct.x127374642E63727970746F2E65643235353139010301054572726F7200 = type { %sollang.enum.t522 }
%sollang.struct.x127374642E63727970746F2E6564323535313901030105506F696E7400 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x167374642E63727970746F2E686D61635F7368613235360103010648617368657200 = type { %sollang.struct.x117374642E63727970746F2E7368613235360103010648617368657200, %sollang.struct.x117374642E63727970746F2E7368613235360103010648617368657200 }
%sollang.struct.x117374642E63727970746F2E72616E646F6D0103010C53656375726552616E646F6D00 = type { i8 }
%sollang.struct.x117374642E63727970746F2E7368613235360103010648617368657200 = type { %sollang.int_slice, %sollang.int_slice, i32, i64 }
%sollang.struct.x157374642E63727970746F2E746C7331335F6B6579730103011048616E647368616B655365637265747300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E746C7331335F6B6579730103010C4561726C795365637265747300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x157374642E63727970746F2E746C7331335F6B657973010301124170706C69636174696F6E5365637265747300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x137374642E656E636F64696E672E626173653634010301054572726F7200 = type { %sollang.enum.t524, i64 }
%sollang.struct.x137374642E656E636F64696E672E6261736536340103010A456E636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x137374642E656E636F64696E672E6261736536340103010A4465636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x137374642E656E636F64696E672E62617365363401030105436F64656300 = type { %sollang.enum.t525, %sollang.enum.t526 }
%sollang.struct.x137374642E656E636F64696E672E62617365363401030107456E636F64657200 = type { %sollang.struct.x137374642E656E636F64696E672E62617365363401030105436F64656300, i32, i32, i64, i8, i8, i32 }
%sollang.struct.x137374642E656E636F64696E672E626173653634010301074465636F64657200 = type { %sollang.struct.x137374642E656E636F64696E672E62617365363401030105436F64656300, i32, i32, i64, i32, i32, i32, i32, i64, i64, i64, i64, i32, i1 }
%sollang.struct.x137374642E656E636F64696E672E6261736536340103010F4465636F64655772697465506C616E00 = type { i32, i32, i64, i32, i32, i32, i32, i64, i64, i64, i64, i32, i1 }
%sollang.struct.x137374642E656E636F64696E672E62696E617279010301054572726F7200 = type { %sollang.enum.t528, i64 }
%sollang.struct.x137374642E656E636F64696E672E62696E6172790103010652656164657200 = type { %sollang.enum.t527, i64 }
%sollang.struct.x137374642E656E636F64696E672E62696E6172790103010657726974657200 = type { %sollang.enum.t527, i32, i32 }
%sollang.struct.x107374642E656E636F64696E672E686578010301054572726F7200 = type { %sollang.enum.t529, i64 }
%sollang.struct.x107374642E656E636F64696E672E6865780103010A456E636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x107374642E656E636F64696E672E6865780103010A4465636F6465506C616E00 = type { i32, i32 }
%sollang.struct.x107374642E656E636F64696E672E68657801030105436F64656300 = type { i1 }
%sollang.struct.x107374642E656E636F64696E672E68657801030107456E636F64657200 = type { %sollang.struct.x107374642E656E636F64696E672E68657801030105436F64656300, i32, i32, i64 }
%sollang.struct.x107374642E656E636F64696E672E686578010301074465636F64657200 = type { i32, i32, i64, i32, i64 }
%sollang.struct.x0E7374642E686173682E63726333320103010648617368657200 = type { %sollang.enum.t530, i32 }
%sollang.struct.x117374642E686173682E7878686173683634010301045365656400 = type { i64 }
%sollang.struct.x117374642E686173682E78786861736836340103010648617368657200 = type { i64, i64, i64, i64, i64, i64, i64, %sollang.int_slice, i32 }
%sollang.struct.x067374642E696F010301054572726F7200 = type { %sollang.enum.t531, i64 }
%sollang.struct.x067374642E696F0103010B436F70794F7574636F6D6500 = type { i32, %sollang.enum.t533 }
%sollang.struct.x067374642E696F0103010E5472616E73666572506F6C69637900 = type { i32, i32 }
%sollang.struct.x067374642E696F0103010C5265706C617942756666657200 = type { %sollang.array.i32, i32, %sollang.array.i32, i32, i32 }
%sollang.struct.x067374642E696F0103010C4D656D6F727952656164657200 = type { %sollang.array.i32, i32, i32 }
%sollang.struct.x067374642E696F0103010C4D656D6F727957726974657200 = type { %sollang.array.i32, i32 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C43616E63656C6C6174696F6E00 = type { i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010B526561645375636365737300 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727952656164657200, %sollang.array.i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010B526561644661696C75726500 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727952656164657200, %sollang.array.i32, %sollang.enum.t534 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C57726974655375636365737300 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727957726974657200, %sollang.array.i32, i32 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C57726974654661696C75726500 = type { %sollang.struct.x067374642E696F0103010C4D656D6F727957726974657200, %sollang.array.i32, %sollang.enum.t534 }
%sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500 = type { %sollang.array.i32, i32, i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C4F666665725375636365737300 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C4F666665724661696C75726500 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, %sollang.enum.t534 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C447261696E5375636365737300 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, i32, i1 }
%sollang.struct.x0C7374642E696F2E6173796E630103010C447261696E4661696C75726500 = type { %sollang.struct.x0C7374642E696F2E6173796E630103010B427566666572517565756500, %sollang.array.i32, %sollang.enum.t534 }
%sollang.struct.x0B7374642E696F2E66696C650103010A4279746552656164657200 = type { %sollang.struct.x087379732E66696C650103010446696C6500, i64 }
%sollang.struct.x0B7374642E696F2E66696C650103010A4279746557726974657200 = type { %sollang.struct.x087379732E66696C650103010A46696C6557726974657200, i64 }
%sollang.struct.x0B7374642E696F2E66696C65010301104173796E63526561645375636365737300 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746552656164657200, %sollang.array.i32, i32, i1 }
%sollang.struct.x0B7374642E696F2E66696C65010301104173796E63526561644661696C75726500 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746552656164657200, %sollang.array.i32, %sollang.enum.t595 }
%sollang.struct.x0B7374642E696F2E66696C65010301114173796E6357726974655375636365737300 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746557726974657200, %sollang.array.i32, i32 }
%sollang.struct.x0B7374642E696F2E66696C65010301114173796E6357726974654661696C75726500 = type { %sollang.struct.x0B7374642E696F2E66696C650103010A4279746557726974657200, %sollang.array.i32, %sollang.enum.t595 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, i64 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010D4372656174654661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010B526561645375636365737300 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, i64, i1 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010B526561644661696C75726500 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010C57726974655375636365737300 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, i64 }
%sollang.struct.x0D7374642E696F2E736F636B65740103010C57726974654661696C75726500 = type { %sollang.struct.x0D7374642E696F2E736F636B65740103010B4173796E6353747265616D00, %sollang.array.i32, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x077374642E6C6F67010301054669656C6400 = type { %sollang.text, %sollang.text }
%sollang.struct.x077374642E6C6F67010301054572726F7200 = type { %sollang.text }
%sollang.struct.x077374642E6C6F67010301065265636F726400 = type { %sollang.enum.t535, %sollang.text }
%sollang.struct.x077374642E6C6F67010301064C6F6767657200 = type { %sollang.enum.t535 }
%sollang.struct.x077374642E6E65740103010B497076344164647265737300 = type { i8, i8, i8, i8 }
%sollang.struct.x077374642E6E65740103010C49707634456E64706F696E7400 = type { %sollang.struct.x077374642E6E65740103010B497076344164647265737300, i16 }
%sollang.struct.x077374642E6E65740103010B497076364164647265737300 = type { i16, i16, i16, i16, i16, i16, i16, i16 }
%sollang.struct.x077374642E6E65740103010C49707636456E64706F696E7400 = type { %sollang.struct.x077374642E6E65740103010B497076364164647265737300, i16, i32, i32 }
%sollang.struct.x077374642E6E65740103010A50617273654572726F7200 = type { %sollang.enum.t554, i64 }
%sollang.struct.x0B7374642E6E65742E646E73010301054572726F7200 = type { %sollang.enum.t539, i32 }
%sollang.struct.x0B7374642E6E65742E646E73010301085265736F6C76657200 = type { %sollang.enum.t538, i64, i64 }
%sollang.struct.x0C7374642E6E65742E68747470010301054572726F7200 = type { %sollang.enum.t546, i64 }
%sollang.struct.x0C7374642E6E65742E68747470010301064C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x0C7374642E6E65742E68747470010301045370616E00 = type { i64, i64 }
%sollang.struct.x0C7374642E6E65742E68747470010301054669656C6400 = type { %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00 }
%sollang.struct.x0C7374642E6E65742E687474700103010650617273657200 = type { %sollang.struct.x0C7374642E6E65742E68747470010301064C696D69747300 }
%sollang.struct.x0C7374642E6E65742E687474700103010B526571756573744865616400 = type { %sollang.source_text, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.enum.t540, %sollang.array.i32, i64 }
%sollang.struct.x0C7374642E6E65742E687474700103010C526573706F6E73654865616400 = type { %sollang.source_text, %sollang.enum.t540, i32, %sollang.struct.x0C7374642E6E65742E68747470010301045370616E00, %sollang.array.i32, i64 }
%sollang.struct.x0C7374642E6E65742E687474700103010C5061727365644669656C647300 = type { %sollang.array.i32, i64 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300 = type { i32, i32, i32, i32, i32 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900 = type { %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300 }
%sollang.struct.x117374642E6E65742E687474702E626F647901030113526573706F6E7365426F6479436F6E7465787400 = type { %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, %sollang.text }
%sollang.struct.x117374642E6E65742E687474702E626F647901030108426F6479506C616E00 = type { %sollang.enum.t541, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010C426F647950726F677265737300 = type { i64, i64, i1 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010B426F64794465636F64657200 = type { %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F64794C696D69747300, %sollang.enum.t542, %sollang.enum.t543, i64, i64, i64, i64, %sollang.array.i32, i1, i64, i32 }
%sollang.struct.x117374642E6E65742E687474702E626F64790103010D4865616465724672616D696E6700 = type { i1, i64, i1, i1 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E740103010D436C69656E744F7074696F6E7300 = type { %sollang.enum.t537, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E7401030106436C69656E7400 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E740103010845786368616E676500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32, %sollang.enum.t549, %sollang.enum.t548 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E7401030108526573706F6E736500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32, %sollang.enum.t549, %sollang.enum.t548, %sollang.array.i32, %sollang.struct.x0C7374642E6E65742E687474700103010C526573706F6E73654865616400, i64 }
%sollang.struct.x137374642E6E65742E687474702E636C69656E740103010C526573706F6E7365426F647900 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, %sollang.struct.x117374642E6E65742E687474702E626F64790103010A426F6479506F6C69637900, i32, i32, %sollang.array.i32, i64, %sollang.array.i32, i64, %sollang.struct.x117374642E6E65742E687474702E626F64790103010B426F64794465636F64657200, i1, i1, i1 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010D526571756573744C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010D52657175657374506F6C69637900 = type { %sollang.struct.x147374642E6E65742E687474702E726571756573740103010D526571756573744C696D69747300 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010D5265717565737457726974657200 = type { %sollang.struct.x147374642E6E65742E687474702E726571756573740103010D526571756573744C696D69747300, %sollang.array.i32, %sollang.text, i32, i32, i1, i1, i1, i64, %sollang.enum.t548, %sollang.enum.t549 }
%sollang.struct.x147374642E6E65742E687474702E726571756573740103010B526571756573744865616400 = type { %sollang.array.i32, i64, %sollang.enum.t548, %sollang.enum.t549 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E73654C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E7365506F6C69637900 = type { %sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E73654C696D69747300 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E736557726974657200 = type { %sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010E526573706F6E73654C696D69747300, %sollang.array.i32, i32, i32, i1, i1, i1, i64, %sollang.enum.t551 }
%sollang.struct.x157374642E6E65742E687474702E726573706F6E73650103010C526573706F6E73654865616400 = type { %sollang.array.i32, i64, %sollang.enum.t551, %sollang.enum.t550 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010D5365727665724F7074696F6E7300 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4C697374656E4F7074696F6E7300, %sollang.struct.x0C7374642E6E65742E68747470010301064C696D69747300 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010653657276657200 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010B5463704C697374656E657200, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010A436F6E6E656374696F6E00 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32, %sollang.array.i32, i64 }
%sollang.struct.x137374642E6E65742E687474702E736572766572010301075265717565737400 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32, %sollang.array.i32, %sollang.struct.x0C7374642E6E65742E687474700103010B526571756573744865616400, i64, %sollang.array.i32, i64, i1 }
%sollang.struct.x137374642E6E65742E687474702E7365727665720103010B52657175657374426F647900 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0C7374642E6E65742E687474700103010650617273657200, i32, %sollang.array.i32, %sollang.struct.x0C7374642E6E65742E687474700103010B526571756573744865616400, i64, %sollang.array.i32, i64, %sollang.struct.x117374642E6E65742E687474702E626F64790103010B426F64794465636F64657200 }
%sollang.struct.x0C7374642E6E65742E7175696301030109517569634572726F7200 = type { %sollang.enum.t555, i64 }
%sollang.struct.x0C7374642E6E65742E71756963010301084964656E7469747900 = type { %sollang.int_slice }
%sollang.struct.x0C7374642E6E65742E7175696301030108456E64706F696E7400 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030109556470536F636B657400, %sollang.enum.t537, i1, %sollang.array.i32, %sollang.array.i32, i64 }
%sollang.struct.x0C7374642E6E65742E71756963010301125265636569766557696E646F7753697A657300 = type { i64, i64, i64, i64 }
%sollang.struct.x0C7374642E6E65742E7175696301030111436F6E6E656374696F6E4F7074696F6E7300 = type { i64, i64, i32, i32, i32, i64, %sollang.struct.x0C7374642E6E65742E71756963010301125265636569766557696E646F7753697A657300 }
%sollang.struct.x0C7374642E6E65742E71756963010301084C697374656E657200 = type { %sollang.struct.x0C7374642E6E65742E71756963010301084964656E7469747900, %sollang.enum.t537, %sollang.struct.x0C7374642E6E65742E7175696301030111436F6E6E656374696F6E4F7074696F6E7300, i1 }
%sollang.struct.x0C7374642E6E65742E717569630103010A436F6E6E656374696F6E00 = type { %sollang.array.i32, %sollang.enum.t537, %sollang.enum.t537, i1, i32, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301084B6579537461746500, %sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301084B6579537461746500, i64, i64, i1, %sollang.int_slice, %sollang.array.i32, %sollang.int_slice, %sollang.array.i32, i1, i1, %sollang.array.i32, %sollang.struct.x177374642E6E65742E717569632E7265617373656D626C7901030105517565756500, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i64, i32, i64, i1, i1, %sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F76657279010301074A6F75726E616C00, %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F7665727901030108527474537461746500, %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F766572790103010F436F6E67657374696F6E537461746500, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E436F6E6E656374696F6E466C6F7700, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E53747265616D526567697374727900, i64, i64, i64, i64, i64, i64, i8, i64, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103010D53656E64446972656374696F6E00 = type { %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010853656E64466C6F7700, i1, i1, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103011052656365697665446972656374696F6E00 = type { %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010B52656365697665466C6F7700, i1, i1, i64, i1, i64 }
%sollang.struct.x0C7374642E6E65742E7175696301030108426953747265616D00 = type { i64, %sollang.struct.x0C7374642E6E65742E717569630103010D53656E64446972656374696F6E00, %sollang.struct.x0C7374642E6E65742E717569630103011052656365697665446972656374696F6E00 }
%sollang.struct.x0C7374642E6E65742E717569630103010A53656E6453747265616D00 = type { i64, %sollang.struct.x0C7374642E6E65742E717569630103010D53656E64446972656374696F6E00 }
%sollang.struct.x0C7374642E6E65742E717569630103010D5265636569766553747265616D00 = type { i64, %sollang.struct.x0C7374642E6E65742E717569630103011052656365697665446972656374696F6E00 }
%sollang.struct.x0C7374642E6E65742E7175696301030105526F75746500 = type { i64, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103010B5061636B6574526F75746500 = type { i64, i8 }
%sollang.struct.x0C7374642E6E65742E717569630103010D506565725472616E73706F727400 = type { i64, i64, i64, i64, i64, i64, i64, i8, i64, i64 }
%sollang.struct.x0C7374642E6E65742E717569630103011048616E647368616B654D65737361676500 = type { %sollang.array.i32, i64 }
%sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301084B6579537461746500 = type { i1, i32, %sollang.int_slice, %sollang.struct.x197374642E6E65742E717569632E747261666669635F6B657973010301044B65797300 }
%sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E65010301064F70656E656400 = type { i64, i1, %sollang.enum.t556 }
%sollang.struct.x1F7374642E6E65742E717569632E6170706C69636174696F6E5F656E67696E650103010A4F70656E65644D616E7900 = type { i64, i1, %sollang.array.i32 }
%sollang.struct.x1D7374642E6E65742E717569632E636F6E6E656374696F6E5F737461746501030105537461746500 = type { i1, i1, i1, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E436F6E6E656374696F6E466C6F7700, %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010C53747265616D4C696D69747300 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D010301084279746543656C6C00 = type { i64, i8 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D0103010D5265636569766542756666657200 = type { %sollang.array.i32, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D0103010A53656E6442756666657200 = type { %sollang.array.i32, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D010301045265616400 = type { %sollang.array.i32, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E63727970746F5F73747265616D010301054368756E6B00 = type { i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6572726F72010301054572726F7200 = type { %sollang.enum.t555, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010643727970746F00 = type { i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010653747265616D00 = type { i64, i64, i1, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010B526573657453747265616D00 = type { i64, i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010B53746F7053656E64696E6700 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D6501030108446174616772616D00 = type { %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010D4D617853747265616D4461746100 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010A4D617853747265616D7300 = type { i1, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103011153747265616D44617461426C6F636B656400 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010E53747265616D73426C6F636B656400 = type { i1, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010F436F6E6E656374696F6E436C6F736500 = type { i1, i64, i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010F4E6577436F6E6E656374696F6E496400 = type { i64, i64, %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010841636B52616E676500 = type { i64, i64 }
%sollang.struct.x127374642E6E65742E717569632E6672616D650103010341636B00 = type { i64, i64, i64, %sollang.array.i32 }
%sollang.struct.x127374642E6E65742E717569632E6672616D65010301074465636F64656400 = type { %sollang.enum.t556, i64 }
%sollang.struct.x1D7374642E6E65742E717569632E68616E647368616B655F656E67696E65010301064F70656E656400 = type { i32, i64, i64, %sollang.array.i32, i64 }
%sollang.struct.x1B7374642E6E65742E717569632E696E697469616C5F656E67696E65010301154163636570746564436C69656E74496E697469616C00 = type { i32, %sollang.array.i32, %sollang.array.i32, i64, %sollang.array.i32 }
%sollang.struct.x1B7374642E6E65742E717569632E696E697469616C5F656E67696E65010301134F70656E6564536572766572496E697469616C00 = type { %sollang.array.i32, i64, %sollang.array.i32 }
%sollang.struct.x117374642E6E65742E717569632E6B6579730103010B496E697469616C4B65797300 = type { %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F7665727901030108527474537461746500 = type { i1, i64, i64, i64, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F766572790103010F436F6E67657374696F6E537461746500 = type { i64, i64, i64, i64, i1 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400 = type { %sollang.int_slice }
%sollang.struct.x107374642E6E65742E717569632E703270010301084964656E7469747900 = type { %sollang.struct.x0C7374642E6E65742E71756963010301084964656E7469747900, %sollang.int_slice, %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010A506565725265636F726400 = type { %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400, %sollang.int_slice, %sollang.struct.x077374642E6E65740103010C49707634456E64706F696E7400, i64, %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x107374642E6E65742E717569632E7032700103010753657373696F6E00 = type { %sollang.struct.x0C7374642E6E65742E717569630103010A436F6E6E656374696F6E00, %sollang.struct.x0C7374642E6E65742E7175696301030108426953747265616D00, %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010E50726F746F636F6C53747265616D00 = type { %sollang.array.i32 }
%sollang.struct.x107374642E6E65742E717569632E7032700103010D41757468656E7469636174656400 = type { %sollang.struct.x107374642E6E65742E717569632E7032700103010650656572496400, %sollang.struct.x0C7374642E6E65742E7175696301030108426953747265616D00 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010D4F70656E6564496E697469616C00 = type { i32, i64, %sollang.array.i32, i64 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010D496E697469616C48656164657200 = type { i32, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, i64, i64 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010F4F70656E656448616E647368616B6500 = type { i32, i64, %sollang.array.i32, i64 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010F48616E647368616B6548656164657200 = type { i32, %sollang.array.i32, %sollang.array.i32, i64, i64 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010C4F70656E65644F6E6552747400 = type { i1, i64, %sollang.array.i32 }
%sollang.struct.x137374642E6E65742E717569632E7061636B6574010301134F70656E656450726F7465637465644C6F6E6700 = type { i8, i64, %sollang.array.i32 }
%sollang.struct.x137374642E6E65742E717569632E7061636B65740103010950726F746563746F7200 = type { %sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E0103011150726570617265645061636B65744B657900, %sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301094865616465724B657900 }
%sollang.struct.x1A7374642E6E65742E717569632E7061636B65745F6E756D626572010301095472756E636174656400 = type { i32, i64 }
%sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F766572790103010A53656E745061636B657400 = type { i64, i64, i64, i1, i1 }
%sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F766572790103010655706461746500 = type { %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F7665727901030108527474537461746500, %sollang.struct.x1A7374642E6E65742E717569632E6C6F73735F7265636F766572790103010F436F6E67657374696F6E537461746500, i64, i64, i64, i64 }
%sollang.struct.x1C7374642E6E65742E717569632E7061636B65745F7265636F76657279010301074A6F75726E616C00 = type { %sollang.array.i32 }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301094D61736B56616C756500 = type { %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E0103010A4E6F6E636556616C756500 = type { %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301095061636B65744B657900 = type { %sollang.int_slice, %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E010301094865616465724B657900 = type { %sollang.struct.x117374642E63727970746F2E616573313238010301034B657900 }
%sollang.struct.x177374642E6E65742E717569632E70726F74656374696F6E0103011150726570617265645061636B65744B657900 = type { %sollang.struct.x157374642E63727970746F2E6165733132385F67636D010301034B657900, %sollang.int_slice }
%sollang.struct.x177374642E6E65742E717569632E7265617373656D626C79010301094163636F756E74656400 = type { %sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010B52656365697665466C6F7700, i64 }
%sollang.struct.x177374642E6E65742E717569632E7265617373656D626C7901030105517565756500 = type { %sollang.array.i32, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E53747265616D4964656E7469747900 = type { i64, i64, %sollang.enum.t557, %sollang.enum.t558 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010B52656365697665466C6F7700 = type { i64, i64, i64, i1, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010853656E64466C6F7700 = type { i64, i64, i1, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E436F6E6E656374696F6E466C6F7700 = type { i64, i64, i64, i64, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010C53747265616D4C696D69747300 = type { i64, i64 }
%sollang.struct.x197374642E6E65742E717569632E73747265616D5F73746174650103010E53747265616D526567697374727900 = type { i1, i64, i64, i1, i1, i64, i64, i64, i64, i64, i64, i32, %sollang.array.i32, i32, i32, i32, i32, %sollang.array.i32, i32, i32, i32 }
%sollang.struct.x157374642E6E65742E717569632E746C735F617574680103010B436572746966696361746500 = type { %sollang.array.i32 }
%sollang.struct.x157374642E6E65742E717569632E746C735F6175746801030111436572746966696361746556657269667900 = type { i16, %sollang.array.i32 }
%sollang.struct.x1D7374642E6E65742E717569632E746C735F636C69656E745F737461746501030105537461746500 = type { %sollang.enum.t559, %sollang.struct.x1B7374642E6E65742E717569632E746C735F7472616E7363726970740103010A5472616E73637269707400, %sollang.int_slice }
%sollang.struct.x1A7374642E6E65742E717569632E746C735F68616E647368616B65010301074465636F64656400 = type { i8, %sollang.array.i32, i64 }
%sollang.struct.x1A7374642E6E65742E717569632E746C735F68616E647368616B65010301104465636F646564457874656E73696F6E00 = type { i16, %sollang.array.i32, i64 }
%sollang.struct.x167374642E6E65742E717569632E746C735F68656C6C6F0103010B436C69656E7448656C6C6F00 = type { %sollang.int_slice, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32, %sollang.int_slice, %sollang.array.i32 }
%sollang.struct.x167374642E6E65742E717569632E746C735F68656C6C6F0103010B53657276657248656C6C6F00 = type { %sollang.int_slice, %sollang.array.i32, %sollang.int_slice }
%sollang.struct.x167374642E6E65742E717569632E746C735F68656C6C6F01030113456E63727970746564457874656E73696F6E7300 = type { %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x1D7374642E6E65742E717569632E746C735F7365727665725F737461746501030105537461746500 = type { %sollang.enum.t560, %sollang.struct.x1B7374642E6E65742E717569632E746C735F7472616E7363726970740103010A5472616E73637269707400 }
%sollang.struct.x1B7374642E6E65742E717569632E746C735F7472616E7363726970740103010A5472616E73637269707400 = type { %sollang.array.i32 }
%sollang.struct.x197374642E6E65742E717569632E747261666669635F6B657973010301044B65797300 = type { %sollang.struct.x137374642E6E65742E717569632E7061636B65740103010950726F746563746F7200 }
%sollang.struct.x217374642E6E65742E717569632E7472616E73706F72745F706172616D6574657273010301074465636F64656400 = type { i64, %sollang.array.i32, i64 }
%sollang.struct.x217374642E6E65742E717569632E7472616E73706F72745F706172616D65746572730103010B53747265616D436F756E7400 = type { i64 }
%sollang.struct.x137374642E6E65742E717569632E766172696E74010301074465636F64656400 = type { i64, i64 }
%sollang.struct.x207374642E6E65742E717569632E76657273696F6E5F6E65676F74696174696F6E0103010B496E666F726D6174696F6E00 = type { i32, %sollang.array.i32 }
%sollang.struct.x1B7374642E6E65742E717569632E76657273696F6E5F7061636B6574010301065061636B657400 = type { %sollang.array.i32, %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x197374642E6E65742E717569632E783530395F6564323535313901030107456C656D656E7400 = type { i8, i64, i64, i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D4C697374656E4F7074696F6E7300 = type { %sollang.enum.t537, i32, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030113446174616772616D42696E644F7074696F6E7300 = type { %sollang.enum.t537, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010B5463704C697374656E657200 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030109556470536F636B657400 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010A53656E6442756666657200 = type { ptr, i64, i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D5265636569766542756666657200 = type { %sollang.array.i32 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030108496E74657265737400 = type { i64, %sollang.enum.t564, %sollang.enum.t563 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010A52656164794576656E7400 = type { i64, i1, i1, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030118436F6D706C6574696F6E52656163746F724F7074696F6E7300 = type { i64, i64, i64 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200 = type { i64 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400 = type { i64, %sollang.enum.t565, %sollang.array.i32, i64, i64, %sollang.enum.t566, %sollang.enum.t1067, %sollang.enum.t1068, %sollang.enum.t677 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030119536F636B6574526567697374726174696F6E4661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010D52656D6F76656453747265616D00 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010954637053747265616D00 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030115436F6D706C6574696F6E576169744661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030110536F636B6574436F6D706C6574696F6E00 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103011B436F6D706C6574696F6E5375626D697373696F6E4661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B657401030111436F6D706C6574696F6E52656163746F7200, %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030115536C6F745472616E736974696F6E4661696C75726500 = type { %sollang.struct.x0E7374642E6E65742E736F636B65740103010D4F7065726174696F6E536C6F7400, %sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010752656163746F7200 = type { i64, %sollang.array.i32 }
%sollang.struct.x0E7374642E6E65742E736F636B657401030108446174616772616D00 = type { %sollang.enum.t537, %sollang.array.i32, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010F446174616772616D5265636569707400 = type { %sollang.enum.t537, i64, i1 }
%sollang.struct.x0E7374642E6E65742E736F636B65740103010B536F636B65744572726F7200 = type { %sollang.enum.t569, i32 }
%sollang.struct.x087374642E70617468010301054572726F7200 = type { %sollang.enum.t571, i64 }
%sollang.struct.x087374642E70617468010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x087374642E7061746801030109436F6D706F6E656E7400 = type { %sollang.enum.t570, i64, i64 }
%sollang.struct.x087374642E706174680103010648656164657200 = type { %sollang.enum.t570, i64, i1 }
%sollang.struct.x087374642E706174680103010A436F6D706F6E656E747300 = type { %sollang.source_text, i64, i64, i32, i1, %sollang.struct.x087374642E70617468010301064C696D69747300, %sollang.struct.x087374642E706174680103010648656164657200 }
%sollang.struct.x0C7374642E746578742E637376010301054572726F7200 = type { %sollang.enum.t573, i64, i32 }
%sollang.struct.x0C7374642E746578742E637376010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0C7374642E746578742E6373760103010C5772697465724C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0C7374642E746578742E63737601030106466F726D617400 = type { %sollang.enum.t572, i32 }
%sollang.struct.x0C7374642E746578742E637376010301054669656C6400 = type { i32, i32, i32, i1 }
%sollang.struct.x0C7374642E746578742E6373760103010652656164657200 = type { %sollang.source_text, i64, i64, i32, i32, i1, %sollang.struct.x0C7374642E746578742E63737601030106466F726D617400, %sollang.struct.x0C7374642E746578742E637376010301064C696D69747300 }
%sollang.struct.x0C7374642E746578742E6373760103010657726974657200 = type { %sollang.struct.x0C7374642E746578742E6373760103010C5772697465724C696D69747300, i32, i32, i32, i32 }
%sollang.struct.x0C7374642E746578742E6373760103010C5363616E6E65644669656C6400 = type { i64, i64, i64, i32, i1, i1 }
%sollang.struct.x0D7374642E746578742E676C6F62010301064C696D69747300 = type { i32, i32, i32 }
%sollang.struct.x0D7374642E746578742E676C6F62010301054572726F7200 = type { %sollang.enum.t574, i64, i64 }
%sollang.struct.x0D7374642E746578742E676C6F62010301075061747465726E00 = type { %sollang.source_text, i64, i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E010301054572726F7200 = type { %sollang.enum.t577, i64 }
%sollang.struct.x0D7374642E746578742E6A736F6E010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E01030105546F6B656E00 = type { %sollang.enum.t575, i64, i64, i64, i64, i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E010301064D656D62657200 = type { %sollang.array.i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010556616C756500 = type { %sollang.enum.t576, i64, i64, i1, %sollang.array.i32, %sollang.array.i32, %sollang.array.i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E01030108446F63756D656E7400 = type { %sollang.array.i32, i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010652656164657200 = type { %sollang.source_text, i64, i64, i8, i32, %sollang.struct.x0D7374642E746578742E6A736F6E010301064C696D69747300, %sollang.array.i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010657726974657200 = type { %sollang.array.i32, i32, i32, i32, i8, %sollang.array.i32 }
%sollang.struct.x0D7374642E746578742E6A736F6E0103010A537472696E675363616E00 = type { i64, i64, i32 }
%sollang.struct.x0E7374642E746578742E7265676578010301064C696D69747300 = type { i32, i32, i32, i32 }
%sollang.struct.x0E7374642E746578742E7265676578010301054572726F7200 = type { %sollang.enum.t578, i64, i64, i64 }
%sollang.struct.x0E7374642E746578742E7265676578010301054D6174636800 = type { i64, i64 }
%sollang.struct.x0E7374642E746578742E7265676578010301075061747465726E00 = type { %sollang.source_text, i64, i64, i32, i32, i1, i1, i32, i32 }
%sollang.struct.x0E7374642E746578742E72656765780103010441746F6D00 = type { %sollang.enum.t579, i64, i64, i64, i1, %sollang.enum.t580, i64 }
%sollang.struct.x0E7374642E746578742E726567657801030109436C617373556E697400 = type { i8, i64 }
%sollang.struct.x0E7374642E746578742E726567657801030104576F726B00 = type { i32 }
%sollang.struct.x087374642E74696D65010301084475726174696F6E00 = type { i64 }
%sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400 = type { i64, i64 }
%sollang.struct.x087374642E74696D650103010A557463496E7374616E7400 = type { i64 }
%sollang.struct.x087374642E74696D650103010C43616C656E6461724461746500 = type { i64, i64, i64 }
%sollang.struct.x087374642E74696D650103010E4D6F6E6F746F6E6963436C6F636B00 = type { i8 }
%sollang.struct.x087374642E74696D650103010957616C6C436C6F636B00 = type { i8 }
%sollang.struct.x087374642E74696D650103010B4D616E75616C436C6F636B00 = type { i64, i64 }
%sollang.struct.x087374642E74696D650103010F4D616E75616C57616C6C436C6F636B00 = type { i64 }
%sollang.struct.x087374642E74696D6501030108446561646C696E6500 = type { %sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400 }
%sollang.struct.x087374642E74696D650103010A4669786564436C6F636B00 = type { %sollang.struct.x087374642E74696D650103010A557463496E7374616E7400 }
%sollang.struct.x087374642E74696D650103010B4F6666736574436C6F636B00 = type { i64 }
%sollang.struct.x087374642E74696D6501030111436C6F636B4361706162696C697469657300 = type { %sollang.struct.x087374642E74696D65010301084475726174696F6E00, %sollang.enum.t581, %sollang.struct.x087374642E74696D65010301084475726174696F6E00 }
%sollang.struct.x087374642E74696D650103010554696D657200 = type { %sollang.array.i32, %sollang.struct.x087374642E74696D65010301084475726174696F6E00, i64, %sollang.enum.t582 }
%sollang.struct.x087374642E74696D650103010954696D65725469636B00 = type { %sollang.struct.x087374642E74696D650103010554696D657200, %sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400, %sollang.struct.x087374642E74696D65010301104D6F6E6F746F6E6963496E7374616E7400, i64 }
%sollang.struct.x087374642E74696D65010301054572726F7200 = type { %sollang.enum.t583 }
%sollang.struct.x077374642E757269010301054572726F7200 = type { %sollang.enum.t587, i64 }
%sollang.struct.x077374642E757269010301045370616E00 = type { i64, i64, i1 }
%sollang.struct.x077374642E75726901030109417574686F7269747900 = type { %sollang.struct.x077374642E757269010301045370616E00, %sollang.enum.t584, %sollang.enum.t585, %sollang.struct.x077374642E757269010301045370616E00 }
%sollang.struct.x077374642E757269010301095265666572656E636500 = type { %sollang.source_text, %sollang.struct.x077374642E757269010301045370616E00, %sollang.enum.t586, %sollang.struct.x077374642E757269010301045370616E00, %sollang.struct.x077374642E757269010301045370616E00, %sollang.struct.x077374642E757269010301045370616E00 }
%sollang.struct.x077374642E757269010301134E6F726D616C697A6174696F6E506F6C69637900 = type { i1, i1, i1, i1, i1 }
%sollang.struct.x0F7374642E7572692E70657263656E74010301054572726F7200 = type { %sollang.enum.t588, i64 }
%sollang.struct.x0F7374642E7572692E70657263656E7401030104506C616E00 = type { i32, i32 }
%sollang.struct.x0F7374642E7572692E70657263656E7401030105436F64656300 = type { %sollang.enum.t589 }
%sollang.struct.x087374642E75756964010301054572726F7200 = type { %sollang.enum.t591, i64 }
%sollang.struct.x087374642E75756964010301045575696400 = type { %sollang.int_slice }
%sollang.struct.x087374642E7575696401030105436F64656300 = type { i8 }
%sollang.struct.x087374642E757569640103010947656E657261746F7200 = type { %sollang.struct.x087374642E74696D650103010957616C6C436C6F636B00, %sollang.struct.x117374642E63727970746F2E72616E646F6D0103010C53656375726552616E646F6D00 }
%sollang.struct.x0D7379732E6469726563746F72790103010352617700 = type { %sollang.array.i32, i64 }
%sollang.struct.x0D7379732E6469726563746F727901030105456E74727900 = type { %sollang.struct.x087379732E70617468010301045061746800, %sollang.enum.t594 }
%sollang.struct.x087379732E66696C650103010446696C6500 = type { i64 }
%sollang.struct.x087379732E66696C650103010A46696C6557726974657200 = type { i64 }
%sollang.struct.x087379732E66696C650103011441746F6D69635265706C6163655265717565737400 = type { %sollang.text, %sollang.text }
%sollang.struct.x087379732E66696C650103010A536F757263655465787400 = type {  }
%sollang.struct.x087379732E66696C650103010D5265616441745375636365737300 = type { %sollang.struct.x087379732E66696C650103010446696C6500, %sollang.array.i32, i64, i1 }
%sollang.struct.x087379732E66696C650103010D5265616441744661696C75726500 = type { %sollang.struct.x087379732E66696C650103010446696C6500, %sollang.array.i32, %sollang.enum.t595 }
%sollang.struct.x087379732E66696C650103010E577269746541745375636365737300 = type { %sollang.struct.x087379732E66696C650103010A46696C6557726974657200, %sollang.array.i32, i64 }
%sollang.struct.x087379732E66696C650103010E577269746541744661696C75726500 = type { %sollang.struct.x087379732E66696C650103010A46696C6557726974657200, %sollang.array.i32, %sollang.enum.t595 }
%sollang.struct.x0F7379732E696E7075742E6D6F757365010301054576656E7400 = type { i32, i32, i32, i32, %sollang.enum.t596 }
%sollang.struct.x0F7379732E696E7075742E6D6F757365010301054572726F7200 = type { %sollang.enum.t598, i32 }
%sollang.struct.x0F7379732E696E7075742E6D6F75736501030106536F7572636500 = type { i32, %sollang.enum.t597 }
%sollang.struct.x087379732E70617468010301045061746800 = type { %sollang.array.i32, %sollang.enum.t599 }
%sollang.struct.x087379732E7061746801030107526177496E666F00 = type { %sollang.array.i32, i8, i64, i64 }
%sollang.struct.x087379732E7061746801030104496E666F00 = type { %sollang.struct.x087379732E70617468010301045061746800, %sollang.enum.t594, i64, i64 }
%sollang.struct.x0B7379732E70726F6365737301030111456E7669726F6E6D656E744368616E676500 = type { %sollang.text, %sollang.text, i1 }
%sollang.struct.x0B7379732E70726F636573730103010D436170747572654C696D69747300 = type { i64, i64 }
%sollang.struct.x0B7379732E70726F636573730103010E43617074757265644F757470757400 = type { %sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300, %sollang.array.i32, %sollang.array.i32, i1, i1 }
%sollang.struct.x0B7379732E70726F6365737301030107436F6D6D616E6400 = type { %sollang.array.i32, %sollang.text, i1, %sollang.array.i32, i1, %sollang.enum.t600, %sollang.enum.t601, %sollang.enum.t601 }
%sollang.struct.x0B7379732E70726F636573730103010A4578697453746174757300 = type { i32 }
%sollang.struct.x0B7379732E70726F636573730103010C5369676E616C53746174757300 = type { i32 }
%sollang.struct.x0B7379732E70726F636573730103010950726F63657373496400 = type { i64 }
%sollang.struct.x0B7379732E70726F63657373010301054368696C6400 = type { i64, %sollang.struct.x0B7379732E70726F636573730103010950726F63657373496400, i32, i32 }
%sollang.struct.x0B7379732E70726F63657373010301094368696C64506F6C6C00 = type { i32, i32 }
%sollang.struct.x067374642E696F0105010652656164657200 = type {  }
%sollang.struct.x067374642E696F0105010657726974657200 = type {  }
@_fltused = global i32 0
define dso_local ptr @memset(ptr %dest, i32 %value, i64 %count) #0 {
entry:
  %byte = trunc i32 %value to i8
  br label %loop

loop:
  %i = phi i64 [ 0, %entry ], [ %next, %body ]
  %active = icmp ult i64 %i, %count
  br i1 %active, label %body, label %done

body:
  %slot = getelementptr i8, ptr %dest, i64 %i
  store i8 %byte, ptr %slot, align 1
  %next = add i64 %i, 1
  br label %loop

done:
  ret ptr %dest
}

define dso_local ptr @memcpy(ptr %dest, ptr %source, i64 %count) #0 {
entry:
  br label %loop

loop:
  %i = phi i64 [ 0, %entry ], [ %next, %body ]
  %active = icmp ult i64 %i, %count
  br i1 %active, label %body, label %done

body:
  %src_slot = getelementptr i8, ptr %source, i64 %i
  %dst_slot = getelementptr i8, ptr %dest, i64 %i
  %byte = load i8, ptr %src_slot, align 1
  store i8 %byte, ptr %dst_slot, align 1
  %next = add i64 %i, 1
  br label %loop

done:
  ret ptr %dest
}

define dso_local ptr @memmove(ptr %dest, ptr %source, i64 %count) #0 {
entry:
  %same = icmp eq ptr %dest, %source
  %empty = icmp eq i64 %count, 0
  %done_early = or i1 %same, %empty
  br i1 %done_early, label %done, label %choose_direction

choose_direction:
  %forward = icmp ult ptr %dest, %source
  br i1 %forward, label %forward_loop, label %backward_loop

forward_loop:
  %forward_i = phi i64 [ 0, %choose_direction ], [ %forward_next, %forward_body ]
  %forward_active = icmp ult i64 %forward_i, %count
  br i1 %forward_active, label %forward_body, label %done

forward_body:
  %forward_src = getelementptr i8, ptr %source, i64 %forward_i
  %forward_dst = getelementptr i8, ptr %dest, i64 %forward_i
  %forward_byte = load i8, ptr %forward_src, align 1
  store i8 %forward_byte, ptr %forward_dst, align 1
  %forward_next = add i64 %forward_i, 1
  br label %forward_loop

backward_loop:
  %backward_i = phi i64 [ %count, %choose_direction ], [ %backward_next, %backward_body ]
  %backward_active = icmp ugt i64 %backward_i, 0
  br i1 %backward_active, label %backward_body, label %done

backward_body:
  %backward_next = sub i64 %backward_i, 1
  %backward_src = getelementptr i8, ptr %source, i64 %backward_next
  %backward_dst = getelementptr i8, ptr %dest, i64 %backward_next
  %backward_byte = load i8, ptr %backward_src, align 1
  store i8 %backward_byte, ptr %backward_dst, align 1
  br label %backward_loop

done:
  ret ptr %dest
}
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture)
%sollang.dyn = type { ptr, ptr }
%sollang.mutable_container = type { ptr, ptr, ptr }
%sollang.int_slice = type { ptr, i64 }
%sollang.array.i32 = type { ptr, i64, i64 }
declare void @llvm.trap()
declare dllimport void @ExitProcess(i32)
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011764657269766545787465726E616C42696E6465724B65794E01067075626C6963011764657269766545787465726E616C42696E6465724B6579010370736B18013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [10 x i8] c"ext binder"
@sollang_str_x157374642E63727970746F2E746C7331335F6B65797301070119646572697665526573756D7074696F6E42696E6465724B65795001067075626C69630119646572697665526573756D7074696F6E42696E6465724B6579010370736B18013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [10 x i8] c"res binder"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701136465726976654561726C7946726F6D486173687201067075626C696301136465726976654561726C7946726F6D48617368010370736B18013A07015B010555496E743808015D0E012C0119636C69656E7448656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E010C4561726C7953656372657473_00 = private unnamed_addr constant [11 x i8] c"c e traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701136465726976654561726C7946726F6D486173687201067075626C696301136465726976654561726C7946726F6D48617368010370736B18013A07015B010555496E743808015D0E012C0119636C69656E7448656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E010C4561726C7953656372657473_01 = private unnamed_addr constant [12 x i8] c"e exp master"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_00 = private unnamed_addr constant [7 x i8] c"derived"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_01 = private unnamed_addr constant [12 x i8] c"c hs traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_02 = private unnamed_addr constant [12 x i8] c"s hs traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011E64657269766548616E647368616B655769746850736B46726F6D486173689C0101067075626C6963011E64657269766548616E647368616B655769746850736B46726F6D48617368010370736B18013A07015B010555496E743808015D0E012C010C73686172656453656372657418013A07015B010555496E743808015D0E012C011368656C6C6F5472616E7363726970744861736818013A07015B010555496E743808015D16022D3E011048616E647368616B6553656372657473_03 = private unnamed_addr constant [7 x i8] c"derived"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701196465726976654170706C69636174696F6E46726F6D48617368880101067075626C696301196465726976654170706C69636174696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C73657276657246696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E01124170706C69636174696F6E53656372657473_00 = private unnamed_addr constant [12 x i8] c"c ap traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701196465726976654170706C69636174696F6E46726F6D48617368880101067075626C696301196465726976654170706C69636174696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C73657276657246696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E01124170706C69636174696F6E53656372657473_01 = private unnamed_addr constant [12 x i8] c"s ap traffic"
@sollang_str_x157374642E63727970746F2E746C7331335F6B657973010701196465726976654170706C69636174696F6E46726F6D48617368880101067075626C696301196465726976654170706C69636174696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C73657276657246696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E01124170706C69636174696F6E53656372657473_02 = private unnamed_addr constant [10 x i8] c"exp master"
@sollang_str_x157374642E63727970746F2E746C7331335F6B65797301070118646572697665526573756D7074696F6E46726F6D48617368870101067075626C69630118646572697665526573756D7074696F6E46726F6D48617368010A6D61696E53656372657418013A07015B010555496E743808015D0E012C011C636C69656E7446696E69736865645472616E7363726970744861736818013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [10 x i8] c"res master"
@sollang_str_x157374642E63727970746F2E746C7331335F6B6579730107011A66696E69736865645665726966794461746146726F6D486173687801067075626C6963011A66696E69736865645665726966794461746146726F6D486173680107626173654B657918013A07015B010555496E743808015D0E012C010E7472616E7363726970744861736818013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [8 x i8] c"finished"
@sollang_str_x157374642E63727970746F2E746C7331335F6B65797301070113757064617465547261666669635365637265744D01067075626C6963011375706461746554726166666963536563726574010673656372657418013A07015B010555496E743808015D16022D3E07015B010555496E74380F013B0402333208015D_00 = private unnamed_addr constant [11 x i8] c"traffic upd"
@sollang_str_x0C7374642E6E65742E687474700107010C706172736556657273696F6E8401010C706172736556657273696F6E0106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C0105737461727418013A010855496E7453697A650E012C0103656E6418013A010855496E7453697A6516022D3E0106526573756C741E013C010756657273696F6E0E012C01054572726F721F013E_00 = private unnamed_addr constant [8 x i8] c"HTTP/1.0"
@sollang_str_x0C7374642E6E65742E687474700107010C706172736556657273696F6E8401010C706172736556657273696F6E0106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C0105737461727418013A010855496E7453697A650E012C0103656E6418013A010855496E7453697A6516022D3E0106526573756C741E013C010756657273696F6E0E012C01054572726F721F013E_01 = private unnamed_addr constant [8 x i8] c"HTTP/1.1"
@sollang_str_x117374642E6E65742E687474702E626F64790107011570617273655472616E73666572456E636F64696E678301011570617273655472616E73666572456E636F64696E670106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C010576616C756518013A0104687474700D012E01045370616E16022D3E0106526573756C741E013C0104426F6F6C0E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [7 x i8] c"chunked"
@sollang_str_x117374642E6E65742E687474702E626F64790107010D6865616465724672616D696E67B101010D6865616465724672616D696E670106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C01066669656C647318013A010372656607015B0104687474700D012E01054669656C640F013B0C017E08015D0E012C01066C696D69747318013A010A426F64794C696D69747316022D3E0106526573756C741E013C010D4865616465724672616D696E670E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x117374642E6E65742E687474702E626F64790107010D6865616465724672616D696E67B101010D6865616465724672616D696E670106736F7572636518013A0103726566010466696C650D012E010A536F75726365546578740E012C01066669656C647318013A010372656607015B0104687474700D012E01054669656C640F013B0C017E08015D0E012C01066C696D69747318013A010A426F64794C696D69747316022D3E0106526573756C741E013C010D4865616465724672616D696E670E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F76616C6964617465547261696C65725A010F76616C6964617465547261696C657201076465636F64657218013A0103726566010B426F64794465636F64657216022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F76616C6964617465547261696C65725A010F76616C6964617465547261696C657201076465636F64657218013A0103726566010B426F64794465636F64657216022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F73656C6563745265706C79426F64798901010F73656C6563745265706C79426F64790107636F6E7465787418013A0113526573706F6E7365426F6479436F6E746578740E012C01046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0108426F6479506C616E0E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x117374642E6E65742E687474702E626F64790107010F73656C6563745265706C79426F64798901010F73656C6563745265706C79426F64790107636F6E7465787418013A0113526573706F6E7365426F6479436F6E746578740E012C01046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0108426F6479506C616E0E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x137374642E6E65742E687474702E636C69656E7401070119726573706F6E7365416C6C6F777350657273697374656E6365620119726573706F6E7365416C6C6F777350657273697374656E636501046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_00 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x137374642E6E65742E687474702E636C69656E7401070119726573706F6E7365416C6C6F777350657273697374656E6365620119726573706F6E7365416C6C6F777350657273697374656E636501046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"close"
@sollang_str_x137374642E6E65742E687474702E636C69656E7401070119726573706F6E7365416C6C6F777350657273697374656E6365620119726573706F6E7365416C6C6F777350657273697374656E636501046865616418013A01037265660104687474700D012E010C526573706F6E73654865616416022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_02 = private unnamed_addr constant [10 x i8] c"keep-alive"
@sollang_str_x137374642E6E65742E687474702E636C69656E7402060108526573706F6E7365100104696D706C0108526573706F6E73651F01086F70656E426F64794B01067075626C696301086F70656E426F647918013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365426F64790E012C01054572726F721F013E_00 = private unnamed_addr constant [3 x i8] c"GET"
@sollang_str_x137374642E6E65742E687474702E636C69656E7402060108526573706F6E7365100104696D706C0108526573706F6E73651F01086F70656E426F64794B01067075626C696301086F70656E426F647918013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365426F64790E012C01054572726F721F013E_01 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x137374642E6E65742E687474702E636C69656E7402060108526573706F6E7365100104696D706C0108526573706F6E73651F01086F70656E426F64794B01067075626C696301086F70656E426F647918013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365426F64790E012C01054572726F721F013E_02 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E7265717565737401070119636C617373696679526573706F6E736553656D616E74696373430119636C617373696679526573706F6E736553656D616E7469637301066D6574686F6418013A01045465787416022D3E0111526573706F6E736553656D616E74696373_00 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x147374642E6E65742E687474702E7265717565737401070119636C617373696679526573706F6E736553656D616E74696373430119636C617373696679526573706F6E736553656D616E7469637301066D6574686F6418013A01045465787416022D3E0111526573706F6E736553656D616E74696373_01 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_00 = private unnamed_addr constant [4 x i8] c"Host"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_01 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_02 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_03 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_04 = private unnamed_addr constant [7 x i8] c"Trailer"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_00 = private unnamed_addr constant [8 x i8] c"HTTP/1.0"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_01 = private unnamed_addr constant [8 x i8] c"HTTP/1.1"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_00 = private unnamed_addr constant [2 x i8] c": "
@sollang_str_x147374642E6E65742E687474702E726571756573740107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x147374642E6E65742E687474702E7265717565737401070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_00 = private unnamed_addr constant [16 x i8] c"Content-Length: "
@sollang_str_x147374642E6E65742E687474702E7265717565737401070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x147374642E6E65742E687474702E726571756573740107010E76616C69646174655461726765748001010E76616C696461746554617267657401066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C0109617574686F7269747918013A01045465787416022D3E0106526573756C741E013C0104556E69740E012C0104687474700D012E01054572726F721F013E_03 = private unnamed_addr constant [7 x i8] c"OPTIONS"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374506F6C696379150104696D706C010D52657175657374506F6C6963791F010772657175657374F50101067075626C696301077265717565737418013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010674617267657418013A010D526571756573745461726765740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C0109617574686F7269747918013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010D526571756573745772697465720E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"Host"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [5 x i8] c"close"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_03 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_04 = private unnamed_addr constant [10 x i8] c"keep-alive"
@sollang_str_x147374642E6E65742E687474702E726571756573740206010D52657175657374577269746572150104696D706C010D526571756573745772697465721F010666696E6973685101067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010B52657175657374486561640E012C0104687474700D012E01054572726F721F013E_05 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_00 = private unnamed_addr constant [14 x i8] c"Content-Length"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_01 = private unnamed_addr constant [17 x i8] c"Transfer-Encoding"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_02 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010F697352657365727665644669656C642A010F697352657365727665644669656C6401046E616D6518013A01045465787416022D3E0104426F6F6C_03 = private unnamed_addr constant [7 x i8] c"Trailer"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_00 = private unnamed_addr constant [8 x i8] c"HTTP/1.0"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010D617070656E6456657273696F6E5D010D617070656E6456657273696F6E01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E16022D3E0104556E6974_01 = private unnamed_addr constant [8 x i8] c"HTTP/1.1"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_00 = private unnamed_addr constant [2 x i8] c": "
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650107010B617070656E644669656C645F010B617070656E644669656C6401066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01046E616D6518013A0104546578740E012C010576616C756518013A01045465787416022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E736501070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_00 = private unnamed_addr constant [16 x i8] c"Content-Length: "
@sollang_str_x157374642E6E65742E687474702E726573706F6E736501070113617070656E64436F6E74656E744C656E6774685A0113617070656E64436F6E74656E744C656E67746801066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C01066C656E67746818013A010855496E7453697A6516022D3E0104556E6974_01 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365506F6C696379160104696D706C010E526573706F6E7365506F6C6963791F0108726573706F6E7365EA0101067075626C69630108726573706F6E736518013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C010673746174757318013A0103496E740E012C0106726561736F6E18013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010E526573706F6E73655772697465720E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [7 x i8] c"CONNECT"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365506F6C696379160104696D706C010E526573706F6E7365506F6C6963791F0108726573706F6E7365EA0101067075626C69630108726573706F6E736518013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C010673746174757318013A0103496E740E012C0106726561736F6E18013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010E526573706F6E73655772697465720E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [4 x i8] c"HEAD"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365506F6C696379160104696D706C010E526573706F6E7365506F6C6963791F0108726573706F6E7365EA0101067075626C69630108726573706F6E736518013A010473656C660E012C01066D6574686F6418013A0104546578740E012C010776657273696F6E18013A0104687474700D012E010756657273696F6E0E012C010673746174757318013A0103496E740E012C0106726561736F6E18013A0104546578740E012C010A626F64794C656E67746818013A010855496E7453697A650E012C010A636F6E6E656374696F6E18013A010E436F6E6E656374696F6E4D6F646516022D3E0106526573756C741E013C010E526573706F6E73655772697465720E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_00 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"close"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_02 = private unnamed_addr constant [10 x i8] c"Connection"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_03 = private unnamed_addr constant [10 x i8] c"keep-alive"
@sollang_str_x157374642E6E65742E687474702E726573706F6E73650206010E526573706F6E7365577269746572160104696D706C010E526573706F6E73655772697465721F010666696E6973685201067075626C6963010666696E69736818013A01046D6F7665010473656C6616022D3E0106526573756C741E013C010C526573706F6E7365486561640E012C0104687474700D012E01054572726F721F013E_04 = private unnamed_addr constant [2 x i8] c"\0D\0A"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_00 = private unnamed_addr constant [9 x i8] c"client in"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_01 = private unnamed_addr constant [9 x i8] c"server in"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_02 = private unnamed_addr constant [10 x i8] c"quicv2 key"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_03 = private unnamed_addr constant [8 x i8] c"quic key"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_04 = private unnamed_addr constant [9 x i8] c"quicv2 iv"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_05 = private unnamed_addr constant [7 x i8] c"quic iv"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_06 = private unnamed_addr constant [9 x i8] c"quicv2 hp"
@sollang_str_x117374642E6E65742E717569632E6B6579730107010D646572697665496E697469616C6801067075626C6963010D646572697665496E697469616C010776657273696F6E18013A010655496E7433320E012C011764657374696E6174696F6E436F6E6E656374696F6E496418013A07015B010555496E743808015D16022D3E010B496E697469616C4B657973_07 = private unnamed_addr constant [7 x i8] c"quic hp"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_00 = private unnamed_addr constant [10 x i8] c"quicv2 key"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_01 = private unnamed_addr constant [8 x i8] c"quic key"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_02 = private unnamed_addr constant [9 x i8] c"quicv2 iv"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_03 = private unnamed_addr constant [7 x i8] c"quic iv"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_04 = private unnamed_addr constant [9 x i8] c"quicv2 hp"
@sollang_str_x197374642E6E65742E717569632E747261666669635F6B657973010701066465726976655001067075626C69630106646572697665010776657273696F6E18013A010655496E7433320E012C010673656372657418013A07015B010555496E74380F013B0402333208015D16022D3E01044B657973_05 = private unnamed_addr constant [7 x i8] c"quic hp"
@sollang_str_x0D7374642E746578742E6A736F6E020601065265616465720E0104696D706C01065265616465721F0107626F6F6C65616E5001067075626C69630107626F6F6C65616E18013A010473656C660E012C0105746F6B656E18013A0105546F6B656E16022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E020601065265616465720E0104696D706C01065265616465721F0107626F6F6C65616E5001067075626C69630107626F6F6C65616E18013A010473656C660E012C0105746F6B656E18013A0105546F6B656E16022D3E0106526573756C741E013C0104426F6F6C0E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x0D7374642E746578742E6A736F6E020601065265616465720E0104696D706C01065265616465721F01096E756C6C56616C75655201067075626C696301096E756C6C56616C756518013A010473656C660E012C0105746F6B656E18013A0105546F6B656E16022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E010701097363616E56616C75655801097363616E56616C7565010672656164657218013A01036D757401065265616465720E012C0105646570746818013A0103496E7416022D3E0106526573756C741E013C0105546F6B656E0E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E010701097363616E56616C75655801097363616E56616C7565010672656164657218013A01036D757401065265616465720E012C0105646570746818013A0103496E7416022D3E0106526573756C741E013C0105546F6B656E0E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x0D7374642E746578742E6A736F6E010701097363616E56616C75655801097363616E56616C7565010672656164657218013A01036D757401065265616465720E012C0105646570746818013A0103496E7416022D3E0106526573756C741E013C0105546F6B656E0E012C01054572726F721F013E_02 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E0107011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E748501011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E74010576616C756518013A0103726566010556616C75650E012C01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C0108646F63756D656E7418013A01037265660108446F63756D656E7416022D3E0104556E6974_00 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E0107011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E748501011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E74010576616C756518013A0103726566010556616C75650E012C01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C0108646F63756D656E7418013A01037265660108446F63756D656E7416022D3E0104556E6974_01 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E0107011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E748501011E617070656E64456E636F6465644D6F64656C56616C7565436F6E74656E74010576616C756518013A0103726566010556616C75650E012C01066F757470757418013A01036D757407015B010555496E74380F013B0C017E08015D0E012C0108646F63756D656E7418013A01037265660108446F63756D656E7416022D3E0104556E6974_02 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F0105696E7436345301067075626C69630105696E74363418013A01036D7574010473656C660E012C010576616C756518013A0105496E74363416022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [6 x i8] c"$value"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F010675696E7436345501067075626C6963010675696E74363418013A01036D7574010473656C660E012C010576616C756518013A010655496E74363416022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [6 x i8] c"$value"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F01096E756C6C56616C75654301067075626C696301096E756C6C56616C756518013A01036D7574010473656C6616022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"null"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F0107626F6F6C65616E5401067075626C69630107626F6F6C65616E18013A01036D7574010473656C660E012C010576616C756518013A0104426F6F6C16022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_00 = private unnamed_addr constant [4 x i8] c"true"
@sollang_str_x0D7374642E746578742E6A736F6E020601065772697465720E0104696D706C01065772697465721F0107626F6F6C65616E5401067075626C69630107626F6F6C65616E18013A01036D7574010473656C660E012C010576616C756518013A0104426F6F6C16022D3E0106526573756C741E013C0104556E69740E012C01054572726F721F013E_01 = private unnamed_addr constant [5 x i8] c"false"
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F0115617574686F7269747955736572496E666F546578743201067075626C69630115617574686F7269747955736572496E666F5465787418013A010473656C6616022D3E010454657874_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F010E726567697374657265644E616D652B01067075626C6963010E726567697374657265644E616D6518013A010473656C6616022D3E010454657874_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F010E726567697374657265644E616D652B01067075626C6963010E726567697374657265644E616D6518013A010473656C6616022D3E010454657874_01 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x077374642E757269020601095265666572656E6365110104696D706C01095265666572656E63651F010E726567697374657265644E616D652B01067075626C6963010E726567697374657265644E616D6518013A010473656C6616022D3E010454657874_02 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_00 = private unnamed_addr constant [1 x i8] c"0"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_01 = private unnamed_addr constant [1 x i8] c"1"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_02 = private unnamed_addr constant [1 x i8] c"2"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_03 = private unnamed_addr constant [1 x i8] c"3"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_04 = private unnamed_addr constant [1 x i8] c"4"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_05 = private unnamed_addr constant [1 x i8] c"5"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_06 = private unnamed_addr constant [1 x i8] c"6"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_07 = private unnamed_addr constant [1 x i8] c"7"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_08 = private unnamed_addr constant [1 x i8] c"8"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_09 = private unnamed_addr constant [1 x i8] c"9"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0A = private unnamed_addr constant [1 x i8] c"a"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0B = private unnamed_addr constant [1 x i8] c"b"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0C = private unnamed_addr constant [1 x i8] c"c"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0D = private unnamed_addr constant [1 x i8] c"d"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0E = private unnamed_addr constant [1 x i8] c"e"
@sollang_str_x087374642E757569640107010868657844696769742301086865784469676974010576616C756518013A0103496E7416022D3E010454657874_0F = private unnamed_addr constant [1 x i8] c"f"
@sollang_str_x087374642E7575696402060104557569640C0104696D706C0104557569641F0104746578743C01067075626C696301047465787418013A010473656C660E012C010773746F7261676518013A01036D757401054172656E6116022D3E010454657874_00 = private unnamed_addr constant [1296 x i8] c"$((Int(self.bytes[0]) / 16) -> hexDigit)$((Int(self.bytes[0]) % 16) -> hexDigit)$((Int(self.bytes[1]) / 16) -> hexDigit)$((Int(self.bytes[1]) % 16) -> hexDigit)$((Int(self.bytes[2]) / 16) -> hexDigit)$((Int(self.bytes[2]) % 16) -> hexDigit)$((Int(self.bytes[3]) / 16) -> hexDigit)$((Int(self.bytes[3]) % 16) -> hexDigit)-$((Int(self.bytes[4]) / 16) -> hexDigit)$((Int(self.bytes[4]) % 16) -> hexDigit)$((Int(self.bytes[5]) / 16) -> hexDigit)$((Int(self.bytes[5]) % 16) -> hexDigit)-$((Int(self.bytes[6]) / 16) -> hexDigit)$((Int(self.bytes[6]) % 16) -> hexDigit)$((Int(self.bytes[7]) / 16) -> hexDigit)$((Int(self.bytes[7]) % 16) -> hexDigit)-$((Int(self.bytes[8]) / 16) -> hexDigit)$((Int(self.bytes[8]) % 16) -> hexDigit)$((Int(self.bytes[9]) / 16) -> hexDigit)$((Int(self.bytes[9]) % 16) -> hexDigit)-$((Int(self.bytes[10]) / 16) -> hexDigit)$((Int(self.bytes[10]) % 16) -> hexDigit)$((Int(self.bytes[11]) / 16) -> hexDigit)$((Int(self.bytes[11]) % 16) -> hexDigit)$((Int(self.bytes[12]) / 16) -> hexDigit)$((Int(self.bytes[12]) % 16) -> hexDigit)$((Int(self.bytes[13]) / 16) -> hexDigit)$((Int(self.bytes[13]) % 16) -> hexDigit)$((Int(self.bytes[14]) / 16) -> hexDigit)$((Int(self.bytes[14]) % 16) -> hexDigit)$((Int(self.bytes[15]) / 16) -> hexDigit)$((Int(self.bytes[15]) % 16) -> hexDigit)"
@sollang_str_x0D7379732E6469726563746F727901070104726561644701067075626C696301047265616401096469726563746F727918013A0104706174680D012E01045061746816022D3E010A52656164526573756C74010475736573010446696C65_00 = private unnamed_addr constant [2 x i8] c"io"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F010571756572794501067075626C69630105717565727918013A010473656C6616022D3E0106526573756C741E013C0104496E666F0E012C0104546578741F013E010475736573010446696C65_00 = private unnamed_addr constant [2 x i8] c"io"
@sollang_str_x087379732E706174680107010966726F6D42797465736B01067075626C6963010966726F6D4279746573010576616C756518013A01046D6F766507015B010555496E74380F013B0C017E08015D0E012C01057374796C6518013A01055374796C6516022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [23 x i8] c"path is not valid UTF-8"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01046A6F696E5101067075626C696301046A6F696E18013A01046D6F7665010473656C660E012C01056368696C6418013A01045465787416022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [19 x i8] c"absolute child path"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01086A6F696E506174685401067075626C696301086A6F696E5061746818013A010473656C660E012C01056368696C6418013A010372656601045061746816022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [18 x i8] c"path styles differ"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01086A6F696E506174685401067075626C696301086A6F696E5061746818013A010473656C660E012C01056368696C6418013A010372656601045061746816022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_01 = private unnamed_addr constant [29 x i8] c"cannot join an absolute child"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F0111636F6E7461696E734C65786963616C6C796101067075626C69630111636F6E7461696E734C65786963616C6C7918013A010473656C660E012C010963616E64696461746518013A010372656601045061746816022D3E0106526573756C741E013C0104426F6F6C0E012C0104546578741F013E_00 = private unnamed_addr constant [18 x i8] c"path styles differ"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_00 = private unnamed_addr constant [17 x i8] c"path contains NUL"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_01 = private unnamed_addr constant [20 x i8] c"invalid drive prefix"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_02 = private unnamed_addr constant [26 x i8] c"unsupported path namespace"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_03 = private unnamed_addr constant [26 x i8] c"unsupported path namespace"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_04 = private unnamed_addr constant [16 x i8] c"invalid UNC path"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_05 = private unnamed_addr constant [17 x i8] c"path escapes root"
@sollang_str_x087379732E7061746802060104506174680C0104696D706C0104506174681F01116E6F726D616C697A65436F6E66696E65644B01067075626C696301116E6F726D616C697A65436F6E66696E656418013A01046D6F7665010473656C6616022D3E0106526573756C741E013C0104506174680E012C0104546578741F013E_06 = private unnamed_addr constant [19 x i8] c"incomplete UNC path"
@sollang_str_x0B7379732E70726F6365737301070107636F6D6D616E643001067075626C69630107636F6D6D616E64010770726F6772616D18013A01045465787416022D3E0107436F6D6D616E64_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x0B7379732E70726F6365737302060107436F6D6D616E640F0104696D706C0107436F6D6D616E641F011172656D6F7665456E7669726F6E6D656E744501067075626C6963011172656D6F7665456E7669726F6E6D656E7418013A01036D7574010473656C660E012C01046E616D6518013A01045465787416022D3E0104556E6974_00 = private unnamed_addr constant [0 x i8] c""
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F0112747279576169745465726D696E6174696F6E7501067075626C69630112747279576169745465726D696E6174696F6E18013A01036D7574010473656C6616022D3E0106526573756C741E013C01064F7074696F6E1E013C01115465726D696E6174696F6E5374617475731F013E0E012C0104546578741F013E010475736573010750726F63657373_00 = private unnamed_addr constant [4 x i8] c"wait"
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F0112747279576169745465726D696E6174696F6E7501067075626C69630112747279576169745465726D696E6174696F6E18013A01036D7574010473656C6616022D3E0106526573756C741E013C01064F7074696F6E1E013C01115465726D696E6174696F6E5374617475731F013E0E012C0104546578741F013E010475736573010750726F63657373_01 = private unnamed_addr constant [4 x i8] c"wait"
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F0107747279576169746301067075626C696301077472795761697418013A01036D7574010473656C6616022D3E0106526573756C741E013C01064F7074696F6E1E013C010A457869745374617475731F013E0E012C0104546578741F013E010475736573010750726F63657373_00 = private unnamed_addr constant [6 x i8] c"signal"
@sollang_str_x0B7379732E70726F63657373020601054368696C640D0104696D706C01054368696C641F01046B696C6C4C01067075626C696301046B696C6C18013A01036D7574010473656C6616022D3E0106526573756C741E013C0104556E69740E012C0104546578741F013E010475736573010750726F63657373_00 = private unnamed_addr constant [4 x i8] c"kill"
; sollang.codegen.unit 2:
; sollang.codegen.key 10997868353068918418:276858762849914159
define i32 @sollang_start() {
entry:
  %stdin = call ptr @GetStdHandle(i32 -10)
  %stdout = call ptr @GetStdHandle(i32 -11)
  %written = alloca i32, align 4
  %read = alloca i32, align 4
  %ok_state = alloca i1, align 1
  store i32 0, ptr %written, align 4
  store i32 0, ptr %read, align 4
  store i1 true, ptr %ok_state, align 1
  %stream_scope1_cancelled = alloca i1, align 1
  %each14_index_slot = alloca i64, align 8
  %each29_index_slot = alloca i64, align 8
  %each29_limit_slot = alloca i64, align 8
  %each43_index_slot = alloca i64, align 8
  %each43_limit_slot = alloca i64, align 8
  %each64_index_slot = alloca i64, align 8
  %each64_limit_slot = alloca i64, align 8
  %stream_scope81_cancelled = alloca i1, align 1
  store i1 false, ptr %stream_scope1_cancelled, align 1
  %v53_start = insertvalue { i32, i32 } poison, i32 0, 0
  %v53 = insertvalue { i32, i32 } %v53_start, i32 1, 1
  %v65 = freeze { i32, i32 } %v53
  %each64_range = freeze { i32, i32 } %v65
  %each64_first = extractvalue { i32, i32 } %each64_range, 0
  %each64_last = extractvalue { i32, i32 } %each64_range, 1
  %each64_start = sext i32 %each64_first to i64
  %each64_limit = sext i32 %each64_last to i64
  store i64 %each64_start, ptr %each64_index_slot, align 8
  store i64 %each64_limit, ptr %each64_limit_slot, align 8
  br label %each64_header
each64_header:
  %each64_index = load i64, ptr %each64_index_slot, align 8
  %each64_bound = load i64, ptr %each64_limit_slot, align 8
  %each64_done = icmp sgt i64 %each64_index, %each64_bound
  br i1 %each64_done, label %each64_exit, label %each64_body
each64_body:
  %each64_item = trunc i64 %each64_index to i32
  %v32 = freeze i32 %each64_item
  %v46 = freeze i32 %each64_item
  %v67 = freeze i32 %each64_item
  %v71 = freeze i32 %v67
  %v70 = add i32 %v71, 1
  %v77 = freeze i32 %v70
  %v76 = icmp sgt i32 %v77, 0
  br i1 %v76, label %if79_then, label %if79_merge
if79_then:
  store i1 false, ptr %stream_scope81_cancelled, align 1
  %v97_start = insertvalue { i32, i32 } poison, i32 0, 0
  %v97 = insertvalue { i32, i32 } %v97_start, i32 1, 1
  br label %stream_scope81_cleanup
stream_scope81_cleanup:
  br label %if79_merge
if79_merge:
  br label %stream_scope66_cleanup
stream_scope66_cleanup:
  %each64_stream_cancelled = load i1, ptr %stream_scope1_cancelled, align 1
  br i1 %each64_stream_cancelled, label %each64_exit, label %each64_continue
each64_continue:
  %each64_current = load i64, ptr %each64_index_slot, align 8
  %each64_next = add i64 %each64_current, 1
  store i64 %each64_next, ptr %each64_index_slot, align 8
  br label %each64_header
each64_exit:
  br label %stream_scope1_cleanup
stream_scope1_cleanup:
  call void @sollang_runtime_flush_stdout()
  %context_ok = load i1, ptr %ok_state, align 1
  %exit_code = select i1 %context_ok, i32 0, i32 1
  ret i32 %exit_code
}
attributes #0 = { nounwind }
declare dllimport ptr @GetStdHandle(i32)
%sollang.legacy_int_result = type { i64, i32 }
@sollang_legacy_int_writer_buffer = internal global [8192 x i64] zeroinitializer
@sollang_legacy_int_writer_buffer_count = internal global i64 0
define internal i32 @sollang_legacy_int_copy_text_to_c_path(ptr %data, i64 %len, ptr %out) {
entry:
  %too_long = icmp ugt i64 %len, 259
  br i1 %too_long, label %fail, label %copy

copy:
  %i = phi i64 [ 0, %entry ], [ %next, %copy_body ]
  %done = icmp eq i64 %i, %len
  br i1 %done, label %nul, label %copy_body

copy_body:
  %src = getelementptr i8, ptr %data, i64 %i
  %ch = load i8, ptr %src, align 1
  %dst = getelementptr i8, ptr %out, i64 %i
  store i8 %ch, ptr %dst, align 1
  %next = add i64 %i, 1
  br label %copy

nul:
  %nul_ptr = getelementptr i8, ptr %out, i64 %len
  store i8 0, ptr %nul_ptr, align 1
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_open_write_i64_file(ptr %path, i64 %len) {
entry:
  store i64 0, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %ok = call i32 @sollang_legacy_int_platform_open_write_file(ptr %path, i64 %len)
  ret i32 %ok
}

define internal i32 @sollang_legacy_int_flush_i64_file() {
entry:
  %count = load i64, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %empty = icmp eq i64 %count, 0
  br i1 %empty, label %success, label %flush

flush:
  %bytes = mul i64 %count, 8
  %ok = call i32 @sollang_legacy_int_platform_write_file_bytes(ptr @sollang_legacy_int_writer_buffer, i64 %bytes)
  %is_ok = icmp ne i32 %ok, 0
  br i1 %is_ok, label %reset, label %fail

reset:
  store i64 0, ptr @sollang_legacy_int_writer_buffer_count, align 8
  br label %success

success:
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_write_i64_file(i64 %value) {
entry:
  %count = load i64, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %slot = getelementptr inbounds [8192 x i64], ptr @sollang_legacy_int_writer_buffer, i64 0, i64 %count
  store i64 %value, ptr %slot, align 8
  %next = add i64 %count, 1
  store i64 %next, ptr @sollang_legacy_int_writer_buffer_count, align 8
  %full = icmp eq i64 %next, 8192
  br i1 %full, label %flush, label %success

flush:
  %ok = call i32 @sollang_legacy_int_flush_i64_file()
  ret i32 %ok

success:
  ret i32 1
}

define internal i32 @sollang_legacy_int_close_write_i64_file() {
entry:
  %flush_ok = call i32 @sollang_legacy_int_flush_i64_file()
  %flush_is_ok = icmp ne i32 %flush_ok, 0
  br i1 %flush_is_ok, label %close, label %fail

close:
  %close_ok = call i32 @sollang_legacy_int_platform_close_write_file()
  ret i32 %close_ok

fail:
  ret i32 0
}

define internal %sollang.legacy_int_result @sollang_legacy_int_closest_i64_file(i64 %target) {
entry:
  %count_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_i64_file_count()
  %count = extractvalue %sollang.legacy_int_result %count_result, 0
  %count_ok = extractvalue %sollang.legacy_int_result %count_result, 1
  %count_is_ok = icmp ne i32 %count_ok, 0
  %has_values = icmp sgt i64 %count, 0
  %can_search = and i1 %count_is_ok, %has_values
  br i1 %can_search, label %search, label %fail

search:
  br label %loop

loop:
  %low = phi i64 [ 0, %search ], [ %next_low, %step ]
  %high = phi i64 [ %count, %search ], [ %next_high, %step ]
  %active = icmp slt i64 %low, %high
  br i1 %active, label %probe, label %choose

probe:
  %span = sub i64 %high, %low
  %half = sdiv i64 %span, 2
  %mid = add i64 %low, %half
  %mid_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %mid)
  %mid_value = extractvalue %sollang.legacy_int_result %mid_result, 0
  %mid_ok = extractvalue %sollang.legacy_int_result %mid_result, 1
  %mid_is_ok = icmp ne i32 %mid_ok, 0
  br i1 %mid_is_ok, label %compare_mid, label %fail

compare_mid:
  %less = icmp slt i64 %mid_value, %target
  br i1 %less, label %move_low, label %move_high

move_low:
  %low_plus = add i64 %mid, 1
  br label %step

move_high:
  br label %step

step:
  %next_low = phi i64 [ %low_plus, %move_low ], [ %low, %move_high ]
  %next_high = phi i64 [ %high, %move_low ], [ %mid, %move_high ]
  br label %loop

choose:
  %at_start = icmp eq i64 %low, 0
  br i1 %at_start, label %read_low, label %check_end

check_end:
  %at_end = icmp eq i64 %low, %count
  br i1 %at_end, label %read_prev_only, label %read_pair

read_low:
  %first_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 0)
  ret %sollang.legacy_int_result %first_result

read_prev_only:
  %last_index = sub i64 %count, 1
  %last_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %last_index)
  ret %sollang.legacy_int_result %last_result

read_pair:
  %prev_index = sub i64 %low, 1
  %prev_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %prev_index)
  %next_result = call %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %low)
  %prev_ok = extractvalue %sollang.legacy_int_result %prev_result, 1
  %next_ok = extractvalue %sollang.legacy_int_result %next_result, 1
  %prev_is_ok = icmp ne i32 %prev_ok, 0
  %next_is_ok = icmp ne i32 %next_ok, 0
  %both_ok = and i1 %prev_is_ok, %next_is_ok
  br i1 %both_ok, label %compare_pair, label %fail

compare_pair:
  %prev_value = extractvalue %sollang.legacy_int_result %prev_result, 0
  %next_value = extractvalue %sollang.legacy_int_result %next_result, 0
  %prev_diff = sub i64 %target, %prev_value
  %next_diff = sub i64 %next_value, %target
  %prefer_prev = icmp sle i64 %prev_diff, %next_diff
  br i1 %prefer_prev, label %return_prev, label %return_next

return_prev:
  ret %sollang.legacy_int_result %prev_result

return_next:
  ret %sollang.legacy_int_result %next_result

fail:
  %fail0 = insertvalue %sollang.legacy_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.legacy_int_result %fail0, i32 0, 1
  ret %sollang.legacy_int_result %fail1
}
define internal void @sollang_legacy_int_require(i32 %status) {
entry:
  %ok = icmp ne i32 %status, 0
  br i1 %ok, label %done, label %failure
failure:
  call void @ExitProcess(i32 1)
unreachable
done:
  ret void
}
define internal void @sollang_fn_sys_runtime_openIntWriter(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  %ok = call i32 @sollang_legacy_int_open_write_i64_file(ptr %data, i64 %length)
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define internal void @sollang_fn_sys_runtime_writeInt(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, i32 %arg) {
entry:
  %wide = sext i32 %arg to i64
  %ok = call i32 @sollang_legacy_int_write_i64_file(i64 %wide)
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define internal void @sollang_fn_sys_runtime_closeIntWriter(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) {
entry:
  %ok = call i32 @sollang_legacy_int_close_write_i64_file()
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define internal void @sollang_fn_sys_runtime_openIntReader(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  %ok = call i32 @sollang_legacy_int_platform_open_read_file(ptr %data, i64 %length)
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define internal void @sollang_fn_sys_runtime_closeIntReader(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) {
entry:
  %ok = call i32 @sollang_legacy_int_platform_close_read_file()
  call void @sollang_legacy_int_require(i32 %ok)
  ret void
}
define internal i32 @sollang_fn_sys_runtime_closestInt(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, i32 %arg) {
entry:
  %wide = sext i32 %arg to i64
  %result = call %sollang.legacy_int_result @sollang_legacy_int_closest_i64_file(i64 %wide)
  %status = extractvalue %sollang.legacy_int_result %result, 1
  call void @sollang_legacy_int_require(i32 %status)
  %value = extractvalue %sollang.legacy_int_result %result, 0
  %narrow = trunc i64 %value to i32
  ret i32 %narrow
}
declare dllimport i32 @ReadFile(ptr, ptr, i32, ptr, ptr)
declare dllimport i32 @SetFilePointerEx(ptr, i64, ptr, i32)
@sollang_legacy_int_file_writer = internal global ptr null
@sollang_legacy_int_file_reader = internal global ptr null

define internal i32 @sollang_legacy_int_platform_open_write_file(ptr %path, i64 %len) {
entry:
  %buf = alloca [260 x i8], align 1
  %buf_ptr = getelementptr inbounds [260 x i8], ptr %buf, i64 0, i64 0
  %copy_ok = call i32 @sollang_legacy_int_copy_text_to_c_path(ptr %path, i64 %len, ptr %buf_ptr)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileA(ptr %buf_ptr, i32 1073741824, i32 0, ptr null, i32 2, i32 128, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  store ptr %handle, ptr @sollang_legacy_int_file_writer, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_platform_write_file_bytes(ptr %data, i64 %len64) {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_writer, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %write, label %fail

write:
  %written = alloca i32, align 4
  %len = trunc i64 %len64 to i32
  %ok = call i32 @WriteFile(ptr %handle, ptr %data, i32 %len, ptr %written, ptr null)
  %written32 = load i32, ptr %written, align 4
  %written64 = zext i32 %written32 to i64
  %write_ok = icmp ne i32 %ok, 0
  %full = icmp eq i64 %written64, %len64
  %all_ok = and i1 %write_ok, %full
  %result = zext i1 %all_ok to i32
  ret i32 %result

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_platform_close_write_file() {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_writer, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %close, label %fail

close:
  %ok = call i32 @CloseHandle(ptr %handle)
  %close_ok = icmp ne i32 %ok, 0
  br i1 %close_ok, label %success, label %fail

success:
  store ptr null, ptr @sollang_legacy_int_file_writer, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal i32 @sollang_legacy_int_platform_open_read_file(ptr %path, i64 %len) {
entry:
  %buf = alloca [260 x i8], align 1
  %buf_ptr = getelementptr inbounds [260 x i8], ptr %buf, i64 0, i64 0
  %copy_ok = call i32 @sollang_legacy_int_copy_text_to_c_path(ptr %path, i64 %len, ptr %buf_ptr)
  %copy_is_ok = icmp ne i32 %copy_ok, 0
  br i1 %copy_is_ok, label %open, label %fail

open:
  %handle = call ptr @CreateFileA(ptr %buf_ptr, i32 -2147483648, i32 1, ptr null, i32 3, i32 128, ptr null)
  %handle_int = ptrtoint ptr %handle to i64
  %invalid = icmp eq i64 %handle_int, -1
  br i1 %invalid, label %fail, label %success

success:
  store ptr %handle, ptr @sollang_legacy_int_file_reader, align 8
  ret i32 1

fail:
  ret i32 0
}

define internal %sollang.legacy_int_result @sollang_legacy_int_platform_i64_file_count() {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %size, label %fail

size:
  %size_ptr = alloca i64, align 8
  %ok = call i32 @GetFileSizeEx(ptr %handle, ptr %size_ptr)
  %size_ok = icmp ne i32 %ok, 0
  br i1 %size_ok, label %check, label %fail

check:
  %bytes = load i64, ptr %size_ptr, align 8
  %rem = urem i64 %bytes, 8
  %aligned = icmp eq i64 %rem, 0
  br i1 %aligned, label %success, label %fail

success:
  %count = udiv i64 %bytes, 8
  %ok0 = insertvalue %sollang.legacy_int_result poison, i64 %count, 0
  %ok1 = insertvalue %sollang.legacy_int_result %ok0, i32 1, 1
  ret %sollang.legacy_int_result %ok1

fail:
  %fail0 = insertvalue %sollang.legacy_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.legacy_int_result %fail0, i32 0, 1
  ret %sollang.legacy_int_result %fail1
}

define internal %sollang.legacy_int_result @sollang_legacy_int_platform_read_i64_at(i64 %index) {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %seek, label %fail

seek:
  %offset = mul i64 %index, 8
  %seek_ok = call i32 @SetFilePointerEx(ptr %handle, i64 %offset, ptr null, i32 0)
  %seek_is_ok = icmp ne i32 %seek_ok, 0
  br i1 %seek_is_ok, label %read, label %fail

read:
  %value_ptr = alloca i64, align 8
  %read_bytes = alloca i32, align 4
  %ok = call i32 @ReadFile(ptr %handle, ptr %value_ptr, i32 8, ptr %read_bytes, ptr null)
  %read_ok = icmp ne i32 %ok, 0
  %read_count = load i32, ptr %read_bytes, align 4
  %read_full = icmp eq i32 %read_count, 8
  %all_ok = and i1 %read_ok, %read_full
  br i1 %all_ok, label %success, label %fail

success:
  %value = load i64, ptr %value_ptr, align 8
  %ok0 = insertvalue %sollang.legacy_int_result poison, i64 %value, 0
  %ok1 = insertvalue %sollang.legacy_int_result %ok0, i32 1, 1
  ret %sollang.legacy_int_result %ok1

fail:
  %fail0 = insertvalue %sollang.legacy_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.legacy_int_result %fail0, i32 0, 1
  ret %sollang.legacy_int_result %fail1
}

define internal i32 @sollang_legacy_int_platform_close_read_file() {
entry:
  %handle = load ptr, ptr @sollang_legacy_int_file_reader, align 8
  %has_handle = icmp ne ptr %handle, null
  br i1 %has_handle, label %close, label %fail

close:
  %ok = call i32 @CloseHandle(ptr %handle)
  %close_ok = icmp ne i32 %ok, 0
  br i1 %close_ok, label %success, label %fail

success:
  store ptr null, ptr @sollang_legacy_int_file_reader, align 8
  ret i32 1

fail:
  ret i32 0
}
declare dllimport i32 @GetFileSizeEx(ptr, ptr)
declare dllimport ptr @CreateFileMappingA(ptr, ptr, i32, i32, i32, ptr)
declare dllimport ptr @MapViewOfFile(ptr, i32, i32, i32, i64)
declare dllimport i32 @UnmapViewOfFile(ptr)
declare dllimport i64 @GetTickCount64()
declare dllimport void @GetSystemTimePreciseAsFileTime(ptr)
@sollang_stage2_random_state = internal global i64 88172645463325252
%sollang.read_int_result = type { i64, i32 }
define internal %sollang.read_int_result @sollang_read_i64(ptr %stdin, ptr %read) #0 {
entry:
  %buf = alloca [64 x i8], align 1
  %ok = call i32 @sollang_read_stdin(ptr %stdin, ptr %buf, i64 64, ptr %read)
  %read_ok = icmp ne i32 %ok, 0
  br i1 %read_ok, label %prepare, label %fail

prepare:
  %read32 = load i32, ptr %read, align 4
  %len = zext i32 %read32 to i64
  br label %skip

skip:
  %skip_idx = phi i64 [ 0, %prepare ], [ %skip_next, %skip_ws ]
  %skip_has = icmp ult i64 %skip_idx, %len
  br i1 %skip_has, label %skip_char, label %fail

skip_char:
  %skip_ptr = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 %skip_idx
  %skip_ch = load i8, ptr %skip_ptr, align 1
  %skip_sp = icmp eq i8 %skip_ch, 32
  %skip_tab = icmp eq i8 %skip_ch, 9
  %skip_cr = icmp eq i8 %skip_ch, 13
  %skip_lf = icmp eq i8 %skip_ch, 10
  %skip_sp_tab = or i1 %skip_sp, %skip_tab
  %skip_cr_lf = or i1 %skip_cr, %skip_lf
  %skip_is_ws = or i1 %skip_sp_tab, %skip_cr_lf
  br i1 %skip_is_ws, label %skip_ws, label %digit_entry

skip_ws:
  %skip_next = add i64 %skip_idx, 1
  br label %skip

digit_entry:
  %first_ge = icmp uge i8 %skip_ch, 48
  %first_le = icmp ule i8 %skip_ch, 57
  %first_digit = and i1 %first_ge, %first_le
  br i1 %first_digit, label %digits, label %fail

digits:
  %digit_idx = phi i64 [ %skip_idx, %digit_entry ], [ %digit_next, %digit_continue ]
  %value = phi i64 [ 0, %digit_entry ], [ %value_next, %digit_continue ]
  %digit_has = icmp ult i64 %digit_idx, %len
  br i1 %digit_has, label %digit_char, label %success

digit_char:
  %digit_ptr = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 %digit_idx
  %digit_ch = load i8, ptr %digit_ptr, align 1
  %digit_ge = icmp uge i8 %digit_ch, 48
  %digit_le = icmp ule i8 %digit_ch, 57
  %is_digit = and i1 %digit_ge, %digit_le
  br i1 %is_digit, label %digit_continue, label %trail_entry

digit_continue:
  %digit64 = zext i8 %digit_ch to i64
  %digit_value = sub i64 %digit64, 48
  %value_x10 = mul i64 %value, 10
  %value_next = add i64 %value_x10, %digit_value
  %digit_next = add i64 %digit_idx, 1
  br label %digits

trail_entry:
  br label %trail

trail:
  %trail_idx = phi i64 [ %digit_idx, %trail_entry ], [ %trail_next, %trail_ws ]
  %trail_has = icmp ult i64 %trail_idx, %len
  br i1 %trail_has, label %trail_char, label %success

trail_char:
  %trail_ptr = getelementptr inbounds [64 x i8], ptr %buf, i64 0, i64 %trail_idx
  %trail_ch = load i8, ptr %trail_ptr, align 1
  %trail_sp = icmp eq i8 %trail_ch, 32
  %trail_tab = icmp eq i8 %trail_ch, 9
  %trail_cr = icmp eq i8 %trail_ch, 13
  %trail_lf = icmp eq i8 %trail_ch, 10
  %trail_sp_tab = or i1 %trail_sp, %trail_tab
  %trail_cr_lf = or i1 %trail_cr, %trail_lf
  %trail_is_ws = or i1 %trail_sp_tab, %trail_cr_lf
  br i1 %trail_is_ws, label %trail_ws, label %fail

trail_ws:
  %trail_next = add i64 %trail_idx, 1
  br label %trail

success:
  %success_value = phi i64 [ %value, %digits ], [ %value, %trail ]
  %success0 = insertvalue %sollang.read_int_result poison, i64 %success_value, 0
  %success1 = insertvalue %sollang.read_int_result %success0, i32 1, 1
  ret %sollang.read_int_result %success1

fail:
  %fail0 = insertvalue %sollang.read_int_result poison, i64 0, 0
  %fail1 = insertvalue %sollang.read_int_result %fail0, i32 0, 1
  ret %sollang.read_int_result %fail1
}
define internal i32 @sollang_read_stdin(ptr %stdin, ptr %data, i64 %len64, ptr %read) #0 {
entry:
  %exceeds_dword = icmp ugt i64 %len64, 4294967295
  %bounded_len = select i1 %exceeds_dword, i64 4294967295, i64 %len64
  %len = trunc i64 %bounded_len to i32
  %ok = call i32 @ReadFile(ptr %stdin, ptr %data, i32 %len, ptr %read, ptr null)
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %success, label %inspect_error

inspect_error:
  %error = call i32 @GetLastError()
  %broken_pipe = icmp eq i32 %error, 109
  br i1 %broken_pipe, label %eof, label %failure

eof:
  store i32 0, ptr %read, align 4
  ret i32 1

success:
  ret i32 1

failure:
  ret i32 0
}
define internal void @sollang_fn_sys_runtime_print(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_print(ptr %stdout, ptr %written, ptr %ok_state, ptr %data, i64 %length, i1 false)
  ret void
}
define internal void @sollang_fn_sys_runtime_println(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_print(ptr %stdout, ptr %written, ptr %ok_state, ptr %data, i64 %length, i1 true)
  ret void
}
define internal i32 @sollang_fn_sys_runtime_readInt(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_print(ptr %stdout, ptr %written, ptr %ok_state, ptr %data, i64 %length, i1 false)
  %result = call %sollang.read_int_result @sollang_read_i64(ptr %stdin, ptr %read)
  %ok = extractvalue %sollang.read_int_result %result, 1
  %succeeded = icmp ne i32 %ok, 0
  br i1 %succeeded, label %success, label %failure
success:
  %value = extractvalue %sollang.read_int_result %result, 0
  %narrowed = trunc i64 %value to i32
  ret i32 %narrowed
failure:
  call void @sollang_runtime_flush_stdout()
  call void @ExitProcess(i32 1)
  unreachable
}
define internal void @sollang_fn_sys_runtime_seedRandom(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, i32 %arg) {
entry:
  %seed = sext i32 %arg to i64
  store i64 %seed, ptr @sollang_stage2_random_state, align 8
  ret void
}
define internal i32 @sollang_fn_sys_runtime_randomBelow(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, i32 %arg) {
entry:
  %valid = icmp sgt i32 %arg, 0
  br i1 %valid, label %next, label %failure
next:
  %state = load i64, ptr @sollang_stage2_random_state, align 8
  %product = mul i64 %state, 6364136223846793005
  %updated = add i64 %product, 1442695040888963407
  store i64 %updated, ptr @sollang_stage2_random_state, align 8
  %bound = zext i32 %arg to i64
  %value = urem i64 %updated, %bound
  %result = trunc i64 %value to i32
  ret i32 %result
failure:
  ret i32 0
}

define internal i64 @sollang_now_millis() {
entry:
  %value = call i64 @GetTickCount64()
  ret i64 %value
}
define internal i64 @sollang_fn_sys_runtime_nowMillis(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) {
  %value = call i64 @sollang_now_millis()
  ret i64 %value
}
define internal i64 @sollang_fn_sys_runtime_utcNowMillis(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) {
entry:
  %filetime = alloca [2 x i32], align 4
  call void @GetSystemTimePreciseAsFileTime(ptr %filetime)
  %low_ptr = getelementptr inbounds [2 x i32], ptr %filetime, i64 0, i64 0
  %high_ptr = getelementptr inbounds [2 x i32], ptr %filetime, i64 0, i64 1
  %low32 = load i32, ptr %low_ptr, align 4
  %high32 = load i32, ptr %high_ptr, align 4
  %low = zext i32 %low32 to i64
  %high = zext i32 %high32 to i64
  %shifted = shl i64 %high, 32
  %ticks = or i64 %shifted, %low
  %unix_ticks = sub i64 %ticks, 116444736000000000
  %millis = udiv i64 %unix_ticks, 10000
  ret i64 %millis
}
define internal i8 @sollang_fn_sys_runtime_monotonicSuspendPolicy(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) { ret i8 0 }
define internal void @sollang_fn_sys_runtime_eprint(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_eprint(ptr %data, i64 %length, i1 false)
  ret void
}
define internal void @sollang_fn_sys_runtime_eprintln(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, %sollang.text %arg) {
entry:
  %data = extractvalue %sollang.text %arg, 0
  %length = extractvalue %sollang.text %arg, 1
  call void @sollang_runtime_eprintln(ptr %data, i64 %length)
  ret void
}
define internal void @sollang_fn_sys_runtime_flushStandardOutput(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state) {
entry:
  call void @sollang_runtime_flush_stdout()
  ret void
}
; sollang.codegen.end

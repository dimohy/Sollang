define i32 @sollang_m146_s0(i32 %arg) {
entry:
  %stack_slot0 = alloca [24 x i8], align 8
  %slot631360192515 = getelementptr i8, ptr %stack_slot0, i64 0
  %v631360192517_ptr = insertvalue %sollang.text poison, ptr @sollang_str_631360192517, 0
  %v631360192517 = insertvalue %sollang.text %v631360192517_ptr, i64 4, 1
  call void @sollang_runtime_print(ptr @sollang_str_631360192517, i64 4, i1 true)
  %heap_v631360192518 = call ptr @sollang_alloc(i64 8)
  %v631360192518_data = getelementptr i8, ptr %heap_v631360192518, i64 0
  %v631360192518_allocation_ok = icmp ne ptr %v631360192518_data, null
  br i1 %v631360192518_allocation_ok, label %v631360192518_allocation_ready, label %v631360192518_allocation_failed
v631360192518_allocation_failed:
  %v631360192518_allocation_diagnostic = alloca [45 x i8], align 1
  store [45 x i8] c"\63\61\63\68\65\2E\62\65\74\61\2E\63\61\63\68\65\2E\62\65\74\61\2E\61\70\70\6C\79\3A\61\6C\6C\6F\63\61\74\69\6F\6E\5F\66\61\69\6C\65\64", ptr %v631360192518_allocation_diagnostic, align 1
  call void @sollang_runtime_eprint(ptr %v631360192518_allocation_diagnostic, i64 45, i1 false)
  call void @llvm.trap()
  unreachable
v631360192518_allocation_ready:
  %v631360192518_ptr0 = getelementptr i32, ptr %v631360192518_data, i64 0
  store i32 %arg, ptr %v631360192518_ptr0, align 4
  %v631360192518_ptr1 = getelementptr i32, ptr %v631360192518_data, i64 1
  store i32 0, ptr %v631360192518_ptr1, align 4
  %v631360192518_0 = insertvalue %sollang.array.i32 poison, ptr %v631360192518_data, 0
  %v631360192518_1 = insertvalue %sollang.array.i32 %v631360192518_0, i64 2, 1
  %v631360192518 = insertvalue %sollang.array.i32 %v631360192518_1, i64 2, 2
  %v631360192522 = icmp sgt i32 %arg, 0
  call void @llvm.lifetime.start.p0(i64 24, ptr %stack_slot0)
  store %sollang.array.i32 %v631360192518, ptr %slot631360192515, align 8
  br i1 %v631360192522, label %if631360192525_then, label %if631360192525_merge
if631360192525_then:
  %v631360192528 = load %sollang.array.i32, ptr %slot631360192515, align 8
  %push118131_data = extractvalue %sollang.array.i32 %v631360192528, 0
  %push118131_length = extractvalue %sollang.array.i32 %v631360192528, 1
  %push118131_capacity = extractvalue %sollang.array.i32 %v631360192528, 2
  %push118131_full = icmp eq i64 %push118131_length, %push118131_capacity
  %push118131_empty = icmp eq i64 %push118131_capacity, 0
  %push118131_doubled = mul i64 %push118131_capacity, 2
  %push118131_grown_capacity = select i1 %push118131_empty, i64 4, i64 %push118131_doubled
  %push118131_append_capacity = select i1 %push118131_full, i64 %push118131_grown_capacity, i64 %push118131_capacity
  %push118131_append_bytes = mul i64 %push118131_append_capacity, 4
  br i1 %push118131_full, label %push118131_grow, label %push118131_keep
push118131_keep:
  br label %push118131_ready
push118131_grow:
  %push118131_grown_data = call ptr @sollang_alloc(i64 %push118131_append_bytes)
  %push118131_allocated = icmp ne ptr %push118131_grown_data, null
  br i1 %push118131_allocated, label %push118131_copy, label %push118131_allocation_failed
push118131_allocation_failed:
  call void @llvm.trap()
  unreachable
push118131_copy:
  %push118131_copy_bytes = mul i64 %push118131_length, 4
  call void @llvm.memcpy.p0.p0.i64(ptr %push118131_grown_data, ptr %push118131_data, i64 %push118131_copy_bytes, i1 false)
  call void @sollang_free(ptr %push118131_data)
  br label %push118131_ready
push118131_ready:
  %push118131_append_data = phi ptr [ %push118131_data, %push118131_keep ], [ %push118131_grown_data, %push118131_copy ]
  %push118131_slot = getelementptr i32, ptr %push118131_append_data, i64 %push118131_length
  store i32 3, ptr %push118131_slot, align 4
  %push118131_new_length = add i64 %push118131_length, 1
  %push118131_array0 = insertvalue %sollang.array.i32 poison, ptr %push118131_append_data, 0
  %push118131_array1 = insertvalue %sollang.array.i32 %push118131_array0, i64 %push118131_new_length, 1
  %push118131_array2 = insertvalue %sollang.array.i32 %push118131_array1, i64 %push118131_append_capacity, 2
  store %sollang.array.i32 %push118131_array2, ptr %slot631360192515, align 8
  br label %if631360192525_merge
if631360192525_merge:
  %v631360192532 = load %sollang.array.i32, ptr %slot631360192515, align 8
  %v631360192535 = load %sollang.array.i32, ptr %slot631360192515, align 8
  %v631360192538 = load %sollang.array.i32, ptr %slot631360192515, align 8
  %v631360192531_data = extractvalue %sollang.array.i32 %v631360192532, 0
  %v631360192531_length = extractvalue %sollang.array.i32 %v631360192532, 1
  %v631360192531_in_bounds = icmp ult i64 0, %v631360192531_length
  br i1 %v631360192531_in_bounds, label %v631360192531_index_ok, label %v631360192531_index_fail
v631360192531_index_fail:
  call void @llvm.trap()
  unreachable
v631360192531_index_ok:
  %v631360192531_ptr = getelementptr i32, ptr %v631360192531_data, i64 0
  %v631360192531 = load i32, ptr %v631360192531_ptr, align 4
  %v631360192537_raw = extractvalue %sollang.array.i32 %v631360192538, 1
  %v631360192537 = trunc i64 %v631360192537_raw to i32
  %v631360192536 = sub i32 %v631360192537, 1
  %v631360192534_data = extractvalue %sollang.array.i32 %v631360192535, 0
  %v631360192534_length = extractvalue %sollang.array.i32 %v631360192535, 1
  %v631360192534_index = sext i32 %v631360192536 to i64
  %v631360192534_in_bounds = icmp ult i64 %v631360192534_index, %v631360192534_length
  br i1 %v631360192534_in_bounds, label %v631360192534_index_ok, label %v631360192534_index_fail
v631360192534_index_fail:
  call void @llvm.trap()
  unreachable
v631360192534_index_ok:
  %v631360192534_ptr = getelementptr i32, ptr %v631360192534_data, i64 %v631360192534_index
  %v631360192534 = load i32, ptr %v631360192534_ptr, align 4
  %v631360192530 = add i32 %v631360192531, %v631360192534
  %drop118119_current = load %sollang.array.i32, ptr %slot631360192515, align 8
  call void @sollang_drop_t371(%sollang.array.i32 %drop118119_current)
  call void @llvm.lifetime.end.p0(i64 24, ptr %stack_slot0)
  ret i32 %v631360192530
}
@.slg.str.module.x63616368652E62657461.0 = private unnamed_addr constant [4 x i8] c"beta", align 1
@.slg.str.module.x63616368652E62657461.1 = private unnamed_addr constant [1 x i8] c"\0A", align 1
@.slg.str.module.x63616368652E62657461.2 = private unnamed_addr constant [45 x i8] c"cache.beta.cache.beta.apply:allocation_failed", align 1
@.slg.str.module.x63616368652E62657461.3 = private unnamed_addr constant [45 x i8] c"cache.beta.cache.beta.apply:allocation_failed", align 1
@.slg.str.module.x63616368652E62657461.4 = private unnamed_addr constant [50 x i8] c"cache.beta.cache.beta.apply:bb_array_bounds_fail13", align 1
@.slg.str.module.x63616368652E62657461.5 = private unnamed_addr constant [50 x i8] c"cache.beta.cache.beta.apply:bb_array_bounds_fail15", align 1
define internal i32 @sollang_fn_cache_beta_apply(ptr %stdin, ptr %stdout, ptr %written, ptr %read, ptr %ok_state, i32 %it) #0 {
entry:
  %stack_slot0 = alloca [24 x i8], align 8
  %trap_written11 = alloca i32, align 4
  %trap_written30 = alloca i32, align 4
  %trap_written48 = alloca i32, align 4
  %trap_written62 = alloca i32, align 4
  %write0 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.module.x63616368652E62657461.0, i64 4, ptr %written)
  %is_ok1 = icmp ne i32 %write0, 0
  %previous_ok2 = load i1, ptr %ok_state, align 1
  %ok3 = and i1 %previous_ok2, %is_ok1
  store i1 %ok3, ptr %ok_state, align 1
  %write4 = call i32 @sollang_write(ptr %stdout, ptr @.slg.str.module.x63616368652E62657461.1, i64 1, ptr %written)
  %is_ok5 = icmp ne i32 %write4, 0
  %previous_ok6 = load i1, ptr %ok_state, align 1
  %ok7 = and i1 %previous_ok6, %is_ok5
  store i1 %ok7, ptr %ok_state, align 1
  %heap8 = call ptr @sollang_alloc(i64 8)
  %heap_ok9 = icmp ne ptr %heap8, null
  br i1 %heap_ok9, label %bb_alloc_ok0, label %bb_alloc_fail1

bb_alloc_fail1:
  %trap_stderr10 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr10, ptr @.slg.str.module.x63616368652E62657461.2, i32 45, ptr %trap_written11, ptr null)
  call void @llvm.trap()
  unreachable

bb_alloc_ok0:
  %array_slot12 = getelementptr i32, ptr %heap8, i64 0
  store i32 %it, ptr %array_slot12, align 4
  %array_slot13 = getelementptr i32, ptr %heap8, i64 1
  store i32 0, ptr %array_slot13, align 4
  call void @llvm.lifetime.start.p0(i64 24, ptr %stack_slot0)
  %mutable_len_addr14 = getelementptr i8, ptr %stack_slot0, i64 8
  %mutable_capacity_addr15 = getelementptr i8, ptr %stack_slot0, i64 16
  store ptr %heap8, ptr %stack_slot0, align 8
  store i64 2, ptr %mutable_len_addr14, align 8
  store i64 2, ptr %mutable_capacity_addr15, align 8
  %cmp16 = icmp sgt i32 %it, 0
  br i1 %cmp16, label %bb_if_then2, label %bb_if_end3
bb_if_then2:
  %mutable_ptr17 = load ptr, ptr %stack_slot0, align 8
  %mutable_len18 = load i64, ptr %mutable_len_addr14, align 8
  %mutable_capacity19 = load i64, ptr %mutable_capacity_addr15, align 8
  %array_has_capacity20 = icmp ult i64 %mutable_len18, %mutable_capacity19
  br i1 %array_has_capacity20, label %bb_array_push_append4, label %bb_array_push_grow5

bb_array_push_append4:
  %array_slot21 = getelementptr i32, ptr %mutable_ptr17, i64 %mutable_len18
  store i32 3, ptr %array_slot21, align 4
  %array_next_len22 = add i64 %mutable_len18, 1
  br label %bb_array_push_done6

bb_array_push_grow5:
  %array_has_any_capacity23 = icmp eq i64 %mutable_capacity19, 0
  %array_doubled_capacity24 = mul i64 %mutable_capacity19, 2
  %array_new_capacity25 = select i1 %array_has_any_capacity23, i64 4, i64 %array_doubled_capacity24
  %array_new_bytes26 = mul i64 %array_new_capacity25, 4
  %heap27 = call ptr @sollang_alloc(i64 %array_new_bytes26)
  %heap_ok28 = icmp ne ptr %heap27, null
  br i1 %heap_ok28, label %bb_alloc_ok7, label %bb_alloc_fail8

bb_alloc_fail8:
  %trap_stderr29 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr29, ptr @.slg.str.module.x63616368652E62657461.3, i32 45, ptr %trap_written30, ptr null)
  call void @llvm.trap()
  unreachable

bb_alloc_ok7:
  br label %bb_array_copy9

bb_array_copy9:
  %array_copy_i32 = phi i64 [ 0, %bb_alloc_ok7 ], [ %array_copy_next_i31, %bb_array_copy_body10 ]
  %array_copy_active33 = icmp ult i64 %array_copy_i32, %mutable_len18
  br i1 %array_copy_active33, label %bb_array_copy_body10, label %bb_array_copy_done11

bb_array_copy_body10:
  %array_copy_src34 = getelementptr i32, ptr %mutable_ptr17, i64 %array_copy_i32
  %array_copy_dst35 = getelementptr i32, ptr %heap27, i64 %array_copy_i32
  %array_copy_value36 = load i32, ptr %array_copy_src34, align 4
  store i32 %array_copy_value36, ptr %array_copy_dst35, align 4
  %array_copy_next_i31 = add i64 %array_copy_i32, 1
  br label %bb_array_copy9

bb_array_copy_done11:
  call void @sollang_free(ptr %mutable_ptr17)
  %array_slot37 = getelementptr i32, ptr %heap27, i64 %mutable_len18
  store i32 3, ptr %array_slot37, align 4
  %array_next_len38 = add i64 %mutable_len18, 1
  br label %bb_array_push_done6

bb_array_push_done6:
  %array_ptr39 = phi ptr [ %mutable_ptr17, %bb_array_push_append4 ], [ %heap27, %bb_array_copy_done11 ]
  %array_len40 = phi i64 [ %array_next_len22, %bb_array_push_append4 ], [ %array_next_len38, %bb_array_copy_done11 ]
  %array_capacity41 = phi i64 [ %mutable_capacity19, %bb_array_push_append4 ], [ %array_new_capacity25, %bb_array_copy_done11 ]
  store ptr %array_ptr39, ptr %stack_slot0, align 8
  store i64 %array_len40, ptr %mutable_len_addr14, align 8
  store i64 %array_capacity41, ptr %mutable_capacity_addr15, align 8
  br label %bb_if_end3
bb_if_end3:
  %mutable_ptr42 = load ptr, ptr %stack_slot0, align 8
  %mutable_len43 = load i64, ptr %mutable_len_addr14, align 8
  %mutable_capacity44 = load i64, ptr %mutable_capacity_addr15, align 8
  %index_size45 = sext i32 0 to i64
  %array_in_bounds46 = icmp ult i64 %index_size45, %mutable_len43
  br i1 %array_in_bounds46, label %bb_array_bounds_ok12, label %bb_array_bounds_fail13

bb_array_bounds_fail13:
  %trap_stderr47 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr47, ptr @.slg.str.module.x63616368652E62657461.4, i32 50, ptr %trap_written48, ptr null)
  call void @llvm.trap()
  unreachable

bb_array_bounds_ok12:
  %array_slot49 = getelementptr i32, ptr %mutable_ptr42, i64 %index_size45
  %array_item50 = load i32, ptr %array_slot49, align 4
  %mutable_ptr51 = load ptr, ptr %stack_slot0, align 8
  %mutable_len52 = load i64, ptr %mutable_len_addr14, align 8
  %mutable_capacity53 = load i64, ptr %mutable_capacity_addr15, align 8
  %mutable_ptr54 = load ptr, ptr %stack_slot0, align 8
  %mutable_len55 = load i64, ptr %mutable_len_addr14, align 8
  %mutable_capacity56 = load i64, ptr %mutable_capacity_addr15, align 8
  %array_len_value57 = trunc i64 %mutable_len55 to i32
  %sub58 = sub i32 %array_len_value57, 1
  %index_size59 = sext i32 %sub58 to i64
  %array_in_bounds60 = icmp ult i64 %index_size59, %mutable_len52
  br i1 %array_in_bounds60, label %bb_array_bounds_ok14, label %bb_array_bounds_fail15

bb_array_bounds_fail15:
  %trap_stderr61 = call ptr @GetStdHandle(i32 -12)
  call i32 @WriteFile(ptr %trap_stderr61, ptr @.slg.str.module.x63616368652E62657461.5, i32 50, ptr %trap_written62, ptr null)
  call void @llvm.trap()
  unreachable

bb_array_bounds_ok14:
  %array_slot63 = getelementptr i32, ptr %mutable_ptr51, i64 %index_size59
  %array_item64 = load i32, ptr %array_slot63, align 4
  %add65 = add i32 %array_item50, %array_item64
  %mutable_ptr66 = load ptr, ptr %stack_slot0, align 8
  %mutable_len67 = load i64, ptr %mutable_len_addr14, align 8
  %mutable_capacity68 = load i64, ptr %mutable_capacity_addr15, align 8
  call void @sollang_free(ptr %mutable_ptr66)
  call void @llvm.lifetime.end.p0(i64 24, ptr %stack_slot0)
  ret i32 %add65
}


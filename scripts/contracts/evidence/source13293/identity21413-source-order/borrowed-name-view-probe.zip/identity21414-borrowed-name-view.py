from pathlib import Path
import sys,json,hashlib,time
ROOT=Path(__file__).resolve().parents[3];sys.path.insert(0,str(ROOT/'scripts'))
from verification_execution import VerificationExecution
from verification_contract_lease import VerificationContractLease
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
B=ROOT/'artifacts/scratch/resume-20261006-owner-continuation22';OUT=B/'identity21414-borrowed-name-view';managed=B/'managed21139/compiler/Sollang.Compiler.exe';native=B/'v21323/compiler-build01/compiler.exe';sources=[B/'identity21414-borrowed-name-view.slg'];oracle=ROOT/'scripts/contracts/evidence/source13293/identity21413-source-order/source-comparison-and-gap.json';inputs=[Path(__file__),managed,*managed_runtime_inputs(managed),native,native.parent/'result.json',*sources,oracle,*sorted((ROOT/'stdlib').rglob('*.slg'))];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper();hashes={str(p):sha(p) for p in inputs};initialize_output(ROOT,OUT,reusable_directories=[B/x/'compiler-build01' for x in ['v18915','v20050','v21323']]);OUT.mkdir(exist_ok=False);expected='ab\n'
with VerificationContractLease(inputs):
 result=dict(schemaVersion=1,status='running',completed=0,total=2,cases=[],inputHashes=hashes,maximumCaseSeconds=180,scope='Representation probe only: return borrowed Text from immutable owned-byte field through existing file.borrowBytes; CSharp first, then retained Native seed. No production naming/cache implementation claim.',claimsGoalComplete=False);run=VerificationExecution(ROOT,OUT,result,lambda:all(p.is_file() and sha(p)==hashes[str(p)] for p in inputs),sha);error=None
 try:
  for role,compiler in [('managed',managed),('retained-native',native)]:
   d=OUT/role;d.mkdir();start=time.monotonic();budget=lambda:max(1,180-(time.monotonic()-start));done=run.run([str(compiler),'build',*map(str,sources),'-o',str(d/'probe.exe'),'--target','windows-x64','--llvm',str(ROOT/'.tools/llvm-22.1.8'),'--jobs','1','-O0','--keep-temps'],d/'build',timeout=budget());assert done.returncode==0 and not done.stderr,done.stdout[-1800:]+done.stderr;built=done.returncode;done=run.run([str(d/'probe.exe')],d/'run',timeout=budget());passed=done.returncode==0 and not done.stderr and done.stdout==expected;result['cases'].append(dict(id=role,passed=passed,buildExit=built,runExit=done.returncode,stdout=done.stdout,expected=expected,checks=1));result['completed']+=int(passed);run.save();assert passed,done.stdout+done.stderr
  result['status']='passed'
 except BaseException as e:error=e
 finally:run.finalize(error,cleanup=False)
 if error:raise error
print(json.dumps({k:result[k] for k in ['status','completed','total','cases','inputsStable','processesStopped']},indent=2))

define i32 @sollang_m145_s0(i32 %arg) {
entry:
  %v627065225219 = add i32 %arg, 3
  ret i32 %v627065225219
}
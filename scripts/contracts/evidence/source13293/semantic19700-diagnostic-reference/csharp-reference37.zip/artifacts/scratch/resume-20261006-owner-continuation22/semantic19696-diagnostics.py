"""Current CSharp diagnostic reference capture under unchanged original constraints."""
from pathlib import Path
import hashlib,json,sys,time
r=Path.cwd();b=r/'artifacts/scratch/resume-20261006-owner-continuation22'
sys.path.insert(0,str(r/'scripts'))
from verification_execution import VerificationExecution
from verification_fingerprints import managed_runtime_inputs
from completed_artifact_plan import initialize_output
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest().upper()
plan_path=b/'semantic19690-execution-plan.json';plan=read(plan_path);chosen={}
for row in plan['cases']:
    candidate=row['originalCandidate'];original=candidate.get('originalCase',{});resolved=candidate.get('resolvedCandidate',{})
    key=next((k for k in ['expectedDiagnostic','expectedDiagnosticSubstring','diagnostic']
              if original.get(k) and original.get('expectedBuildExit',original.get('exit'))==1),None)
    mode=None;text=None
    if key:mode='stderr-contains';text=original[key]
    elif resolved.get('expectedPolicy')=='contains-diagnostic-needs-exact-current-observation':
        mode='combined-contains';text=(r/resolved['expectedFile']['path']).read_text(encoding='utf-8-sig').replace('\r\n','\n').strip()
    elif resolved.get('expected',{}).get('expectedDiagnostic'):
        mode='stderr-exact-normalized';text=resolved['expected']['expectedDiagnostic'].strip()
    if mode:
        assert isinstance(text,str) and text
        if row['executionGroup'] in chosen:continue
        original=row['originalCandidate'].get('originalCase',{})
        target=original.get('target','windows-x64')
        source=row['sourceInputs'][0]['path']
        if mode=='combined-contains' and '-wasm32-' in Path(source).name:target='wasm32-browser'
        chosen[row['executionGroup']]={'id':row['id'],'group':row['executionGroup'],'mode':mode,'text':text,
            'exitPolicy':'nonzero' if mode=='combined-contains' else 'exact1','target':target,
            'sourceInputs':row['sourceInputs'],'runtimeInputFiles':row['runtimeInputFiles'],
            'requireNoLlvm':original.get('requireNoLlvm',resolved.get('expected',{}).get('requireNoLlvm',False))}
assert len(chosen)==37
intent_path=b/'semantic19696-diagnostic-inputs.json'
assert not intent_path.exists()
intent={'schemaVersion':1,'scope':'Reference capture only; original diagnostic constraints preserved. Exact new streams are prepared evidence, not SLG or phase acceptance.',
        'cases':list(chosen.values()),'claimsPhaseComplete':False,'claimsGoalComplete':False}
intent_path.write_text(json.dumps(intent,indent=2)+'\n',encoding='utf-8')
compiler=b/'managed19361/compiler/Sollang.Compiler.exe';dll=compiler.with_suffix('.dll')
assert sha(dll)=='6C07E2C39D4A21E884B1E4B4B55793964AC0940D20FB47A133DDC0B932CCC12D'
paths=[Path(__file__),plan_path,intent_path,*managed_runtime_inputs(compiler),r/'docs/SPEC.md',
       r/'scripts/verification_execution.py',r/'tests/Sollang.ExampleTests/Program.cs',
       *sorted((r/'stdlib').rglob('*.slg'))]
for case in chosen.values():
    for ref in case['sourceInputs']+case['runtimeInputFiles']:
        p=r/ref['path'];assert sha(p)==ref['sha256'];paths.append(p)
pins={str(p):sha(p) for p in paths};stable=lambda:all(Path(p).is_file() and sha(p)==v for p,v in pins.items())
out=b/'semantic19697-managed-diagnostics'
initialize_output(r,out,reusable_directories=[b/'v18915/compiler-build01',b/'v19080/compiler-build01',b/'v19418/compiler-build01']);out.mkdir(exist_ok=False)
d={'schemaVersion':1,'status':'running','completed':0,'total':37,'cases':[],'inputHashes':pins,
   'scope':intent['scope'],'caseBudgetSeconds':180,'claimsPhaseComplete':False,'claimsGoalComplete':False}
x=VerificationExecution(r,out,d,stable,sha);error=None
try:
    for index,case in enumerate(chosen.values()):
        folder=out/str(index);folder.mkdir();started=time.monotonic()
        row={'id':case['id'],'group':case['group'],'status':'running'};d['cases'].append(row);x.save()
        a=x.run([str(compiler),'build',*[str(r/v['path']) for v in case['sourceInputs']],'-o',str(folder/'probe.exe'),
                 '--target',case['target'],'--llvm',str(r/'.tools/llvm-22.1.8'),'--jobs','4','--keep-temps'],folder/'compile',timeout=180)
        stdout=a.stdout.replace('\r\n','\n');stderr=a.stderr.replace('\r\n','\n')
        code_ok=a.returncode!=0 if case['exitPolicy']=='nonzero' else a.returncode==1
        diagnostic_ok=(case['text'] in (stdout+stderr) if case['mode']=='combined-contains' else
                       stderr.strip()==case['text'] if case['mode']=='stderr-exact-normalized' else case['text'] in stderr)
        row.update(buildExit=a.returncode,buildStdout=stdout,buildStderr=stderr,originalConstraintSatisfied=code_ok and diagnostic_ok,
                   wholeCaseBudgetSeconds=180,wholeCaseElapsedSeconds=time.monotonic()-started)
        if case['requireNoLlvm']:assert not any(p.stat().st_size for p in folder.glob('*.ll')),'UNEXPECTED_LLVM_ON_REJECTION'
        assert time.monotonic()-started<180,'WHOLE_CASE_BUDGET_EXHAUSTED'
        assert code_ok and diagnostic_ok,('ORIGINAL_DIAGNOSTIC_CONSTRAINT_FAILED',case['id'],case['text'],a.returncode,stderr)
        row.update(status='passed',passed=True);d['completed']+=1;x.save();print(case['id']+': reference captured',flush=True)
    d['status']='passed'
except BaseException as exc:error=exc
finally:x.finalize(error,cleanup=False)
print(json.dumps({k:d.get(k) for k in ['status','completed','total','failure','inputsStable','processesStopped']}))
sys.exit(0 if d['status']=='passed' else 1)
